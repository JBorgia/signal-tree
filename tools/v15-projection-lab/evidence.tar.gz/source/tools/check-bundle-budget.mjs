#!/usr/bin/env node
/**
 * Bundle-budget gate. Re-measures SignalTree's own gzip cost and fails on a
 * regression.
 *
 * TWO BUDGETS PER TARGET, and the split is the point.
 *
 *   - `prodKB`  — built with `ngDevMode: false`, which is what a production
 *     Angular app actually ships. THIS is the number that guards users.
 *   - `devKB`   — the default build, dev diagnostics and all. A loose ceiling
 *     that catches a genuinely leaked module, not a tightrope.
 *
 * Before 14.0.0 there was one budget, measured on the DEV build. It moved five
 * times in two releases — 5.8 → 6.9 → 7.1 → 7.2 → 7.3 for the bare tree — and
 * every single bump comment says some version of "entirely dev-only text,
 * production is unchanged". The gate was fighting the project's own policy of
 * making silent failures loud: every new ST-code diagnostic is a string, every
 * string costs gzip, and the ritual response was to raise the number and write
 * a paragraph explaining why it did not matter.
 *
 * A number that gets raised whenever it fires is not a budget. Splitting it
 * puts the tight constraint where the cost is real (production) and lets dev
 * text grow, which is the trade this codebase deliberately makes.
 *
 * Budgets are gzip KB, own-code only (@angular/rxjs/tslib external). Bump them
 * deliberately in a commit if a real feature justifies it — never silently. A
 * PROD bump needs a genuine justification; a DEV bump usually means a new
 * diagnostic and can just say so.
 */
import { build } from 'esbuild';
import { gzipSync } from 'node:zlib';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const CORE = new URL('../dist/packages/kernel/dist/index.js', import.meta.url)
  .pathname;
const REPO_NODE_MODULES = new URL('../node_modules', import.meta.url).pathname;

/**
 * This gate measures BUILT OUTPUT (`dist/`), not source — and for a long time
 * it never checked whether that output matched the source it was run against.
 * It could not fail on a stale `dist`; it measured whatever was lying there.
 *
 * Not hypothetical. `npm run build` was itself broken (it resolved to a project
 * with no build target and exited 1), so nothing rebuilt `dist`, so this gate
 * reported a green number from an artifact several commits old through an
 * entire release-hardening session. Two bugs, each survivable alone: the dead
 * script let the artifact go stale, and the missing freshness check made the
 * staleness invisible. Every budget "verification" in between was measuring
 * code nobody had written yet.
 *
 * `verify-gates.mjs` now owns one production build for the whole verification
 * run and seals `dist/` while checks consume it. Rebuilding here would violate
 * that artifact boundary and make concurrent checks observe different output.
 *
 * Timestamps were tried first and rejected: an Nx cache RESTORE writes correct
 * output without bumping mtimes, so "source newer than dist" reports a stale
 * build that is not stale. A check with false alarms gets disabled, which
 * leaves you back here.
 */
// id -> { code, budgetKB }
const TARGETS = {
  'signaltree-bare': {
    // Bumped 5.8 → 6.9 for 13.5.0. Measured 6.81KB. Attributed, minified bytes in
    // the bare bundle: signal-tree.js +2137 (the ST2018 entity-array
    // diagnostic, the compared() marker interception, and the materializeNode
    // wiring), shared/deep-equal.js +538 (the Error / primitive-wrapper /
    // prototype-gate correctness fixes — a leaf holding an Error used to
    // compare equal to any other Error), utils.js +241 (the per-node
    // materialisation memo), markers/compared.js +113.
    //
    // NOT a tree-shaking regression: compared.js contributes 113 bytes because
    // only its type guard survives, and the rest tree-shakes. Roughly 0.7KB of
    // the gzip growth is dev-only text that folds — the same bundles built with
    // `define: { ngDevMode: false }` grow only +0.37KB, which is the real cost a
    // production app pays for materialisation memoisation.
    //
    // What it bought (measured, docs/architecture/optimisation-options.md):
    // reading the whole state with nothing changed 1400us → 0.044us, time
    // travel flat in state size (340.60ms → 0.04ms at 10k rows), and a
    // diagnostic for an idiom mistake worth ~30x.    //
    // Bumped 6.9 → 7.1 for 14.0.0: the ST2020 (duplicate stored() key) and
    // ST2021 (marker inside an array) diagnostic messages. Measured 6.99KB.
    // Entirely dev-only text — production is 5.46 / 8.04 / 7.42KB, unchanged
    // by these two beyond the O(1) non-enumerable defineProperty that closes
    // the stored() storage leak. check-devmode-foldable confirms it folds.    //
    // Bumped 7.1 → 7.2 for the marker snapshot/hydrate registry. Measured 7.04KB;
    // production 5.53KB (dev code still folds fully — check-devmode-foldable
    // confirms ~1.5-1.9KB reclaimed per tree).
    //
    // What it bought: `form()` and `entityMap()` values reach snapshots at
    // all — before this, `persistence()` wrote `{}` for a form and reported
    // success. The cost is the snapshot/hydrate hooks on status, form and
    // entityMap plus the O(1) processor stamp; it REPLACED two hardcoded
    // duck-type tests, so part of the growth is offset.    //
    // Bumped 7.2 → 7.3 for the async-marker snapshot hooks and ST2022.
    // Measured 7.12KB; production 5.59KB.
    //
    // What it bought: `asyncSource`/`asyncStream` values reach
    // snapshots at all — before this `tree.$()` dropped them entirely, the same
    // defect `form()` had — plus ST2022, which fires when a marker registers
    // without declaring what of it is state. That diagnostic is the guard
    // against a SEVENTH instance of this defect class, so its bytes are the
    // cheapest on this list.
    // 14.0.0: split into dev/prod. Measured dev 7.35KB, prod 5.59KB. The dev
    // figure grew ~50 bytes for ST2023's message; prod is unchanged, because
    // the guard is inline at the call site and folds.
    //
    // Bumped 5.7 → 5.8 at the 14.0.0 RC. Measured prod 5.70KB — EXACTLY the
    // budget, which passes and is the least useful state a budget can be in:
    // the next byte fails it, and the failure would be attributed to whatever
    // change happened to be next rather than to the 0.05KB the marker snapshot
    // memo added here. Raised deliberately so the number reflects a measurement
    // with headroom, not a coincidence.
    //
    // Bumped again for ST2027 (the deep-equal-copy no-op write). The diagnostic
    // hooks the LEAF COMPARATOR rather than `recursiveUpdate`, because a direct
    // `tree.$.x.set(v)` never reaches the latter — and that is the write form
    // the corrupted benchmarks used, so hooking the cheaper site would have
    // missed the case that motivated it. That needs a `path` threaded through
    // `createSignalStore` and a ternary at five leaf-creation sites. Both are
    // ngDevMode-guarded INLINE and fold; what cannot fold is the ternary's
    // existence and the extra parameter in the signature. Measured: prod
    // +0.07KB, dev +0.30KB.
    // 15.0.0 release hardening: the causal runtime and entity identity kernel are
    // now reachable from the default signalTree() construction path. Measured
    // after rebuilding from source: prod 9.45KB, dev 11.45KB.
    //
    // ⚠️ 15.0.0 DECLARATIVE CONSTRUCTION — +0.47KB prod, +0.49KB dev, and this
    // one is a DESIGN COST, not a diagnostic. Read it before bumping again.
    //
    // Enhancers used to arrive through `.with()`, so a tree that never called it
    // never linked the enhancer machinery and esbuild dropped the whole resolver.
    // They arrive in `signalTree`'s config now, which puts two modules on the
    // MANDATORY construction path of every tree, including one with no
    // enhancers at all. Measured attribution, minified prod bytes:
    //
    //     enhancers/index.js                    +851  (resolveEnhancerOrder)
    //     lib/internals/enhancer-requirements.js +817  (config validation)
    //     lib/internals/tree-capabilities.js     +99   (the plan sees enhancers)
    //     lib/signal-tree.js                     -432  (canonicalWith deleted)
    //     ─────────────────────────────────────────────
    //     net                                   +1335  ≈ +0.47KB gzip
    //
    // A runtime `if (enhancers.length === 0)` short-circuit does NOT recover it:
    // tree-shaking is static, and the call site keeps both modules alive however
    // the guard resolves. The only real reductions are a leaner resolver (Kahn's
    // algorithm with adjacency maps and cycle detection, for a set already
    // validated by the pass beside it) or folding validation INTO ordering so the
    // provided-capability set is computed once. Both are their own change; do not
    // attempt either as a side effect of a budget bump.
    //
    // Measured after the migration: prod 9.91KB, dev 11.94KB.
    //
    // Then 15.0 REMOVED lazy signal creation, and the bare bundle came back
    // down to prod 9.51KB / dev 11.50KB — 0.41KB, which is most of the 0.47KB
    // declarative construction cost above. Not a coincidence worth reading into:
    // one is the enhancer resolver arriving, the other is a proxy and a memory
    // manager leaving. They are unrelated and happen to be similar in size.
    //
    // Re-tightened rather than left at 10.0: a budget kept loose after a shrink
    // stops measuring, which is the defect just fixed in dead-exports and the
    // lint ledger.
    // Bumped 11.7 → 11.9 for MARKER-GRAMMAR-DIAGNOSTICS-0: ST2021 grew arms for
    // Map values and Set members, so it carries two more diagnostic sentences.
    // Raised only because PROD IS FLAT — 9.66 KB before and after — and
    // `check-devmode-foldable` is green, so the strings provably do not ship.
    // That is the condition this file's own guidance states for a dev bump; a
    // prod change would have been a regression to fix instead.
    // Universal locations add vanilla subscriptions, coherent grouped
    // publication, exception-safe settlement, and weak reverse dependency
    // edges so abandoned derived recipes collect. After removing duplicate
    // dispatch and notification code, the generator measures 9.76KB prod and
    // 11.91KB dev. Raised by 0.1KB rather than weakening those invariants.
    //
    // Callable terminal locations replace `.set`/`.update` with one read /
    // replace / derive grammar and add `leaf(value)` as explicit topology.
    // After moving entity projections off the mandatory runtime object,
    // restoring scalar-owned mutation emission, deleting the legacy setter
    // fallback, and consolidating terminal construction, the final floor is
    // 9.93KB prod / 12.09KB dev. Against archived 84837fb3, equivalent runnable
    // bundles differ by 430 minified bytes: location-runtime +503, signal-tree
    // +158, leaf +133, intrinsic observers +35, offset by owned-mutation -268
    // and scalar-runtime -126. This is the callable contract, not an optional
    // module leak.
    // Framework-native leaf realization now lives behind the adapter entry.
    // The first implementation left its native branches in the mandatory
    // location/scalar modules and measured 10.80KB prod / 12.95KB dev here.
    // Splitting complete kernel-owned native runtimes behind `kernel/adapter`
    // restores the neutral floor to 9.95KB prod / 12.10KB dev without changing
    // Angular or Vue semantics.
    // 15.2.0: the framework-specialized epoch architecture. Measured 10.19KB
    // prod / 12.31KB dev, up from the 9.95/12.10 floor the adapter split
    // established. This is NOT an optional module leaking back onto the
    // mandatory path -- verified: native-location-realization.ts is still
    // imported only by kernel/adapter.ts, and the one import added to a
    // mandatory module (registerIntrinsicMutationSource) points at
    // intrinsic-mutation, which the bare path already reached. The cost is
    // distributed inline across location-runtime, intrinsic-mutation,
    // tree-scalar-slot-runtime, signal-tree and write-participation
    // (+308/-76 lines), which is the paired createEpoch/advanceEpoch contract
    // itself. Raised to the measurement plus the usual narrow headroom rather
    // than clawed back, because reclaiming it is a performance change and
    // belongs in its own release.
    // 15.3.1: owner-approved containment/reporting lifetime cost, 2026-09-28.
    // Fresh output: 10501 B gzip, 5 B above the former 10496 B ceiling.
    // Retain narrow headroom; no other target or development budget changes.
    // 15.4.4 hidden-location port (v16 integration slices 8b-8e), owner-
    // approved within 10.9 KB: b2107f43 measured 9,929 B prod / 12,079 B dev,
    // the port 10,706 B / 12,856 B (+777 B each). Every tree now carries the
    // absent-read liveness slot, the re-add along a written path and the
    // per-tree structural scope (member-membership, +1,448 minified bytes;
    // v16 measured +576 B gzip for 8b-8e at source level), plus the
    // structured position-address registry v15 lacked (position-registry,
    // signal-tree and materialize-markers: about +210 B gzip over v16's
    // cost). Data, not diagnostics: it does not fold. Raised only as far as
    // needed: 10.46 KB = 10,711 B prod, 12.56 KB = 12,861 B dev (the gate
    // compares bytes / 1024).
    // 15.4.4 permanent repairs, owner-approved October 7: candidate
    // 851542c5, fresh verify-gates --release output, measured 10,989 B prod
    // and 13,138 B dev with this fixture. Current-reader publication and
    // tree-scoped membership caching add data-path cost, not diagnostics.
    // Retain bounded headroom approved for the final verified corrections.
    devKB: 12.9,
    prodKB: 10.8,
    code: `
      import { signalTree } from ${JSON.stringify(CORE)};
      const t = signalTree({ count: 0, user: { name: 'a' } });
      t.$.count(1); t.$.user.name('b');
      globalThis.__sink = [t.$.count(), t.$.user.name()];
    `,
  },
  'signaltree-entities': {
    // Bumped 8.6 → 9.9 for 11.4.1: the 11.4.0 entityMap cache-aware fold
    // (load/staleTime/persist/tags, RFC 0003) raised the measured floor to
    // 9.67KB and shipped that way — the gate was not updated with the
    // feature. Measured breakdown (11.5.0): entity-loader.js is ~3.5KB
    // minified (~1.1KB gzip) of that.
    //
    // Lowered 9.9 → 8.6 for 12.0.0 (RFC 0005 §6): the reclaim landed. v12
    // removed the raw `load: fn` path and entity-map.ts's static `attachLoader`
    // import, so the loader/cache/SWR/persist machinery is reached ONLY through
    // the `loader()` helper. A plain `entityMap()` (measured here) now
    // tree-shakes it out entirely — measured 8.36KB gzip, down from 9.89KB in
    // the 11.6 dual-path interim (~1.53KB reclaimed). Cache-aware collections
    // pay for the machinery via `loader()`; plain collections do not. This
    // budget locks the win in — a regression back toward 9.9 means something
    // re-introduced a static reference to the loader machinery on the plain path.
    //
    // Bumped 8.6 → 8.7 for 13.4.0: the traversal diagnostics (ST2008-ST2011)
    // added in that release live in recursiveUpdate/unwrap/applyState — paths
    // EVERY tree reaches, so they cannot tree-shake for a consumer who never
    // triggers them. Measured 8.66KB; +0.06KB of guarded message strings, not
    // a leaked optional module. Defining `ngDevMode: false` removes them
    // entirely (see docs/performance/dropping-dev-code.md, which measures
    // ~1.15KB reclaimed for this scenario). Deliberate, not a regression.
    //
    // Bumped 8.7 → 9.8 for 13.5.0. Measured 9.71KB. Attributed, minified bytes in
    // the bare bundle: signal-tree.js +2137 (the ST2018 entity-array
    // diagnostic, the compared() marker interception, and the materializeNode
    // wiring), shared/deep-equal.js +538 (the Error / primitive-wrapper /
    // prototype-gate correctness fixes — a leaf holding an Error used to
    // compare equal to any other Error), utils.js +241 (the per-node
    // materialisation memo), markers/compared.js +113.
    //
    // NOT a tree-shaking regression: compared.js contributes 113 bytes because
    // only its type guard survives, and the rest tree-shakes. Roughly 0.7KB of
    // the gzip growth is dev-only text that folds — the same bundles built with
    // `define: { ngDevMode: false }` grow only +0.37KB, which is the real cost a
    // production app pays for materialisation memoisation.
    //
    // What it bought (measured, docs/architecture/optimisation-options.md):
    // reading the whole state with nothing changed 1400us → 0.044us, time
    // travel flat in state size (340.60ms → 0.04ms at 10k rows), and a
    // diagnostic for an idiom mistake worth ~30x.    //
    // Bumped 9.8 → 10.0 for 14.0.0: the ST2020 (duplicate stored() key) and
    // ST2021 (marker inside an array) diagnostic messages. Measured 9.89KB.
    // Entirely dev-only text — production is 5.46 / 8.04 / 7.42KB, unchanged
    // by these two beyond the O(1) non-enumerable defineProperty that closes
    // the stored() storage leak. check-devmode-foldable confirms it folds.    //
    // Bumped 10.0 → 10.2 for the marker snapshot/hydrate registry. Measured 10.05KB;
    // production 8.16KB (dev code still folds fully — check-devmode-foldable
    // confirms ~1.5-1.9KB reclaimed per tree).
    //
    // What it bought: `form()` and `entityMap()` values reach snapshots at
    // all — before this, `persistence()` wrote `{}` for a form and reported
    // success. The cost is the snapshot/hydrate hooks on status, form and
    // entityMap plus the O(1) processor stamp; it REPLACED two hardcoded
    // duck-type tests, so part of the growth is offset.    //
    // Bumped 10.2 → 10.4 for the async-marker snapshot hooks and ST2022.
    // Measured 10.30KB; production 8.24KB.
    //
    // What it bought: `asyncSource`/`asyncStream` values reach
    // snapshots at all — before this `tree.$()` dropped them entirely, the same
    // defect `form()` had — plus ST2022, which fires when a marker registers
    // without declaring what of it is state. That diagnostic is the guard
    // against a SEVENTH instance of this defect class, so its bytes are the
    // cheapest on this list.
    // 14.0.0: split into dev/prod. Measured dev 10.50KB, prod 8.25KB.
    //
    // Bumped 8.4 → 8.7 at the 14.0.0 RC. Measured prod 8.57KB, and the overage
    // was ATTRIBUTED before raising rather than after: rebuilding at 1b79fd26
    // (before the two 14.0.0 perf fixes) gives 8.48KB, so 0.08KB of it predates
    // them and the budget had been quietly red for earlier RC work. The
    // remaining 0.09KB is the weak `byId()` node cache (WeakRef +
    // FinalizationRegistry) and the marker snapshot memo.
    //
    // What those 90 bytes bought, both measured: reading `byId()` across a 10k
    // collection went from 4,149 to 844 B/entity, 39.6MB to 8.05MB
    // (docs/architecture/memory-profile.md), and a marker's snapshot wrapper
    // stopped being re-allocated on every UNRELATED write, which is what makes
    // `computed(() => tree.$().rows)` stable for an OnPush consumer. On the axis
    // that matters for a phone this is 90 bytes of download against 31MB of
    // heap — see docs/architecture/size-structure-review.md for why retained
    // heap is weighted above gzip here.
    //
    // Bumped 8.7 → 9.3 prod / 11.2 → 11.8 dev for the 14.0.0 RC. Measured 9.13
    // and 11.56. Attributed: prepend (which re-orders the storage map rather
    // than rebuilding every per-entity signal), active-entity tracking
    // (activeId/activeEntity/setActiveId/clearActiveId), changeId, and the
    // ST2026 predicate-churn diagnostic. Prod and dev grew by almost the same
    // amount — 0.56 against 0.53 — which confirms the diagnostic is folding:
    // its ~500 characters of message text are absent from the prod figure, and
    // `check-devmode-foldable` passes.
    //
    // What it bought: three capabilities the audit found in peer stores and
    // not here, and a diagnostic for a 75x cost (0.27ms hoisted against 20.54ms
    // inline over 1,000 entities) that is otherwise symptomless — the cache is
    // weak, so nothing leaks and nothing breaks; the app is just slow forever.
    // Bumped for ST2027 — see the attribution on `signaltree-bare`. Measured
    // prod +0.07KB, dev +0.30KB from threading the leaf path for the
    // diagnostic's message.
    //
    // ⚠️ RE-BASELINED for 14.0.0, and read the reason before trusting anything
    // above. Until `ensureBuilt()` was added, this gate measured whatever was
    // in `dist/` without checking it matched the source — and `npm run build`
    // was broken, so `dist/` was stale for an entire hardening session. Every
    // number attributed above was computed that way. They are recorded as
    // written, not silently corrected, because a fabricated correction would be
    // no better; treat the pre-14.0.0 attributions as indicative, not measured.
    //
    // First honest baseline, both ends rebuilt from source:
    //
    //     b254edc1 (14.0.0 hardening start)   9.13 prod   11.56 dev
    //     after the hardening work            9.40 prod   12.07 dev
    //
    // +0.27 prod, +0.51 dev. `signaltree-bare` moved +0.09/+0.35 over the same
    // span, so ~0.18KB of the prod growth is entity-specific: the `where`/`find`
    // storage-scan fast path and `entityMap`'s `history` flag (RFC 0012). The
    // shared remainder is ST2027's leaf-path threading and ST2028's structural
    // clone. Dev outgrows prod roughly 2:1, which is the expected shape when
    // most of what landed is diagnostic text that folds — `ngDevMode: false`
    // reclaims it (see check-devmode-foldable).
    // Bumped for ST2031 — the changeId held-node diagnostic. Measured cost:
    // 9.40 -> 9.69 prod, 12.07 -> 12.36 dev, all of it in entity-signal.ts, so
    // `signaltree-bare` and `signaltree-form` are unmoved.
    //
    // The cost is a `Map<K,K>` of retired ids plus a `Set` of already-reported
    // ones. Those are DATA, not strings, so they do not fold away under
    // `ngDevMode: false` the way the message does — which is why the dev and prod
    // deltas are the same 0.29KB rather than dev-only.
    //
    // Paid deliberately: `changeId` drops the old per-entity signal on purpose,
    // so a node held across a rekey reads `undefined` forever with nothing said.
    // 0.29KB to convert a permanent silent failure into a named one is the trade
    // this library's diagnostics exist to make. If it needs reclaiming, the Map
    // is the thing to make dev-only, not the message.
    // 15.0.0 release hardening: plain entityMap() now pays for the same causal
    // runtime plus structural identity machinery. Measured after rebuilding
    // from source: prod 20.77KB, dev 23.45KB.
    //
    // Post-RC declarative restoration closure moved the final measured floor to
    // 21.49KB prod / 24.18KB dev. Before rebaselining, the closed active-index
    // experiment's two shadow resolvers and public parity hooks were deleted;
    // that recovered 0.17KB but left 21.49/24.18 stable across repeat builds.
    // The remaining code is on the plain EntityMap path: owner-scoped target
    // preparation, compact historical projection, and physical identity/order
    // machinery. Dev foldability remains green (24.18 -> 21.48KB), so no
    // diagnostic text leaked into production. Budgets retain about 0.2KB of
    // headroom rather than rounding the measured values down.
    // Callable EntityMap fields add writable projections over stable entity
    // identity. With the shared callable kernel included, the measured floor is
    // 21.96KB prod / 24.60KB dev. The ceilings retain narrow headroom without
    // weakening field identity, raw ingress, or terminal topology.
    // Carrier-specific query and field realizations move that floor to 22.01KB
    // prod / 24.66KB dev after adapter-only runtime splitting; the native
    // implementation remains absent from neutral bundles.
    // Native-name collision rejection adds declaration-time validation to the
    // existing computed-slice builder. Measured 22.20KB prod / 24.84KB dev.
    // The compact exact-name list prevents slices from corrupting collection
    // accessors or writers before materialization; it must also run in prod.
    // Deliberate correctness cost (~0.19KB), not a diagnostic folding regression.
    // 15.2.0: same epoch architecture, measured here at 22.47KB prod /
    // 25.10KB dev. entity-signal.ts carries the per-subject epoch registry
    // (subjectEpochs / pendingSubjectEpochs) on top of the shared kernel
    // growth above. Same disposition and same reason.
    // October 1 owner approval: 22.54KiB prod / 25.37KiB dev after safe
    // reductions and diagnostic folding checks. Only development headroom
    // increases; the production ceiling remains unchanged. See the takeover audit.
    // 15.4.4 Link repairs, within the owner's ~100 B entities allowance: base
    // f8ff7431 measured 23,134 B prod gzip, this branch 23,157 B (+23 B). The
    // bytes are data the entity bundle must carry for Link to be correct,
    // not diagnostics, so they do not fold: destroy() closing the tree's
    // position registry (+8 B: link() refuses a destroyed tree, and Links are
    // disposed), and entityMap handing its sortComparer to the Link seed
    // (+12 B: endpoints receive all() order). The Link order tier added 0 B;
    // skipping setAll's capture-order walk while capture is inactive, +3 B.
    // Offsets tried and rejected (each worse or a few bytes at the cost of
    // opaque names) are recorded with the commit. 22.62 KB is 23,162 B: the
    // gate compares bytes / 1024 against it, and 23,163 / 1024 = 22.6201.
    // 15.4.4 order-frontier hook (reversal stream (a)+(d)), within the same
    // allowance (owner's maximum 22.7 KB = 23,244 B): 1e1503e0 measured
    // 23,130 B, the hook 23,191 B (+61 B). One frontier transition per
    // collection operation (frame commits and the prependMany move) plus the
    // binding's frontier read/install: without them a reversal cannot tell a
    // turn's own order endpoints or reinstate the order token it replaced,
    // and undo/rollback of an order change refused after any add or remove in
    // or after the same turn. Data, not diagnostics; it does not fold.
    // Offsets tried: separate read and install accessors (+15 B worse), a
    // single merged accessor (taken). 22.66 KB = 23,203 B left ~12 B; the
    // (a)+(d) repair (d33138f6) then published the transitions of clear()
    // and of a setAll that adds or removes rows without reordering survivors
    // (the fuzz found both unpublished): 23,202 B (+11 B), ~1.8 B left, no
    // raise. Dev 26,096 B of 26,112.
    // 15.4.4 combination (the merge of the reversal and entity/Link lines,
    // 42d2f6b4), within the owner's maximum (22.7 KB prod, +100 B dev = 25.6
    // KB): the reversal line alone measured 23,183 B prod / 26,076 B dev at
    // 03075e5a after two offsets in its own frontier code (publishOrderChange
    // takes the frontier first, 312f54e6, -9 B; one instance accessor that
    // reads or installs the token, 4cc1f486, -10 B). The merged tree measures
    // 23,199 B prod / 26,150 B dev: the entity line's interceptor runner,
    // replay-start counting and topology refusals add +16 B prod and +74 B dev
    // here. Prod fits 22.66 KB (23,203 B): no raise. Dev was over 25.5 KB
    // (26,112 B) by 38 B; tools/check-devmode-foldable.mjs confirms the dev
    // code folds (entities 25.53 -> 22.64 KB). Raised only as far as needed:
    // 25.54 KB = 26,152 B (the gate compares bytes / 1024).
    // 15.4.4 hidden-location port (v16 integration slices 8b-8e), approved by
    // the owner (2026-10-06, up to 23.89 KB): b2107f43 measured 23,199 B
    // prod / 26,150 B dev, the port 24,424 B / 27,335 B (+1,225 / +1,185 B).
    // Two parts, both data rather than diagnostics, so neither folds:
    // - the structured position-address registry v15 lacked (67012241:
    //   registerPositionAddress / addressFor, node addresses threaded through
    //   materialization), which the hidden-member walk reads. About +190 B,
    //   the whole difference from v16's own cost for 8b-8e (source-level
    //   attribution: position-registry +206, signal-tree and
    //   materialize-markers +251 minified bytes beyond v16's);
    // - the hidden-location and data-loss fixes themselves (5f34fb7e): absent
    //   reads, the re-add along a written path and the per-tree structural
    //   scope (member-membership +1,472 minified bytes), and the absent
    //   entity collection (entity-signal +924). Without them a reversal or a
    //   write under an omitted member reached storage nothing could read, and
    //   a rejected value could come back through a later re-add. v16 measured
    //   +1,024 B for them.
    // Offsets taken, -38 B together: addresses stored as given rather than as
    // frozen copies (-13 B at source level), and no address for the two
    // lazily allocated positions, which only a tree without position topology
    // allocates and no address reader reaches. A walk-based address lookup
    // confined to the enhancers (estimated -190 B) was not pursued, by the
    // owner's decision. Raised only as far as needed: 23.86 KB = 24,432 B
    // prod, 26.70 KB = 27,340 B dev (bytes / 1024).
    // 15.4.4 permanent repairs, owner-approved October 7: candidate
    // 851542c5, fresh verify-gates --release output, measured 25,107 B prod
    // and 28,040 B dev with this fixture. The reviewed membership/current-read
    // repairs account for growth; attribution found no optional enhancer leak.
    // Final candidate must be rebuilt and measured against these ceilings.
    // 2026-11-11 maintenance publication: the owner explicitly authorized
    // release after accepting the retention/lazy-field repairs and weighing
    // budgets against cost and feasibility. Fresh unchanged-runtime build at
    // 197baa287 measures 24.63 KB; the 24.60 failure remains in the audit.
    // Retain the verified fixes rather than introduce runtime churn to recover
    // roughly 30 gzip bytes. This explicit policy allowance is not a size
    // optimization; all other ceilings and the oversized-artifact proof stay.
    // See docs/audits/2026-11-11-v15-maintenance-release/README.md.
    devKB: 27.5,
    prodKB: 24.7,
    code: `
      import { signalTree, entityMap } from ${JSON.stringify(CORE)};
      const t = signalTree({ count: 0, users: entityMap() });
      t.$.users.addOne({ id: 1, name: 'a' }); t.$.users.updateOne(1, { name: 'b' });
      globalThis.__sink = t.$.users.all();
    `,
  },
};

const EXTERNAL = ['@angular/*', 'rxjs', 'rxjs/*', 'tslib'];
const dir = mkdtempSync(join(tmpdir(), 'st-budget-'));
let failed = false;

async function measure(entry, define) {
  const out = await build({
    entryPoints: [entry],
    bundle: true,
    minify: true,
    format: 'esm',
    platform: 'browser',
    treeShaking: true,
    external: EXTERNAL,
    nodePaths: [REPO_NODE_MODULES],
    write: false,
    legalComments: 'none',
    logLevel: 'silent',
    define,
  });
  return (
    gzipSync(Buffer.from(out.outputFiles[0].contents), { level: 9 }).length /
    1024
  );
}

console.log('target                   prod (ships)      dev (diagnostics)');
console.log('─'.repeat(66));

for (const [id, { code, devKB, prodKB }] of Object.entries(TARGETS)) {
  const entry = join(dir, `${id}.js`);
  writeFileSync(entry, code, 'utf8');

  const prod = await measure(entry, { ngDevMode: 'false' });
  const dev = await measure(entry, {});

  const prodOk = prod <= prodKB;
  const devOk = dev <= devKB;
  if (!prodOk || !devOk) failed = true;

  console.log(
    `${id.padEnd(22)} ` +
      `${prodOk ? '✅' : '❌'} ${prod.toFixed(2)}/${prodKB}KB   ` +
      `${devOk ? '✅' : '❌'} ${dev.toFixed(2)}/${devKB}KB`
  );
}

if (failed) {
  console.error(
    '\n❌ Bundle budget exceeded.\n\n' +
      '  PROD over  — this is what users ship, so treat it as a real regression.\n' +
      '               Find the statically-reachable optional module and make it\n' +
      '               tree-shakeable (subpath or injected feature).\n\n' +
      '  DEV over   — usually a new diagnostic string. Check it FOLDS first\n' +
      '               (`node tools/check-devmode-foldable.mjs`): the ngDevMode\n' +
      '               guard must be inline at the call site, not inside the\n' +
      '               callee, or the message ships to production. If prod is\n' +
      '               flat, raising the dev budget is the right call.\n'
  );
  process.exit(1);
}
console.log('\n✅ Bundle within budget (prod and dev).');
