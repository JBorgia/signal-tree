export { signalTree, entityMap } from "/Users/jonathanborgia/code/signaltree/.worktrees/v15-long-lived-projection/dist/packages/kernel/dist/index.js";
