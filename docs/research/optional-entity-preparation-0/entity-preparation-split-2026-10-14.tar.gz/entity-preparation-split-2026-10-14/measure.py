import subprocess,json,random,pathlib,statistics,hashlib
out=pathlib.Path(__file__).parent;node='/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node'
arms={'before':str(out/'baseline-kernel/dist/index.js'),'after':'/private/tmp/signaltree-optional-preparation-20261014/dist/packages/kernel/dist/index.js'}
protocol={'rounds':6,'seed':241014,'modes':['rollback','confirm'],'count':2000,'warmup':200,'rows':16,'scope':'synchronous checked reorder and scalar transactions, settlement and reads; excludes setup, warmup, deferred flush and explicit GC; includes incidental GC','heap':'post-GC whole-process retained heap difference after 2000 operations, not peak allocation or dominator memory','quiet':'host not certified quiet; run after builds/tests complete'}
(out/'cost-protocol.json').write_text(json.dumps(protocol,indent=2));rng=random.Random(protocol['seed']);data=[]
for round in range(6):
 jobs=[(arm,mode)for arm in arms for mode in protocol['modes']];rng.shuffle(jobs)
 for arm,mode in jobs:
  path=out/f'cost-{round}-{arm}-{mode}.json';assert not path.exists()
  p=subprocess.run([node,'--expose-gc',str(out/'cost.mjs'),arms[arm],mode],capture_output=True,text=True)
  path.with_suffix('.stderr').write_text(p.stderr)
  if p.returncode: path.with_suffix('.failed').write_text(p.stdout);raise RuntimeError((arm,mode,p.returncode,p.stderr))
  row=json.loads(p.stdout);row.update(arm=arm,round=round);path.write_text(json.dumps(row,indent=2));data.append(row)
summary={}
for mode in protocol['modes']:
 summary[mode]={}
 for metric in ['wallNs','cpuNs','heapDelta']:
  vals={a:[x[metric]for x in data if x['arm']==a and x['mode']==mode]for a in arms}
  result={a:{'median':statistics.median(v),'min':min(v),'max':max(v)}for a,v in vals.items()}
  if metric!='heapDelta':
   ratios=[next(x[metric]for x in data if x['round']==r and x['arm']=='after' and x['mode']==mode)/next(x[metric]for x in data if x['round']==r and x['arm']=='before' and x['mode']==mode)for r in range(6)];result['pairedRatios']=ratios;result['medianRatio']=statistics.median(ratios)
  summary[mode][metric]=result
(out/'cost-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
