import {createRequire} from 'node:module';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const dir=dirname(fileURLToPath(import.meta.url));
const require=createRequire('/Users/jonathanborgia/code/signaltree/package.json');
const {build}=require('esbuild');
const arms={before:resolve(dir,'baseline-kernel/dist/index.js'),after:resolve(dir,'candidate-kernel/dist/index.js')};
const receipts=[];
for(const [arm,core]of Object.entries(arms))for(const enhanced of [false,true]){
 const name=enhanced?'enhanced':'plain';const out=resolve(dir,arm+'-'+name);mkdirSync(out,{recursive:true});
 const source=`import {signalTree,entityMap${enhanced?',transactions,restoration':''}} from ${JSON.stringify(core)};
const tree=signalTree({rows:entityMap({selectId:r=>r.id}),x:0}${enhanced?',{enhancers:[transactions(),restoration()]}':''});
tree.$.rows.setAll([{id:'a',v:1},{id:'b',v:2}]);const held=tree.$.rows.byIdOrFail('a');
${enhanced?"const p=tree.transact(()=>{tree.$.rows.setAll([{id:'b',v:2},{id:'a',v:10}]);tree.$.x(1);});p.rollback();":"tree.$.rows.updateOne('a',{v:1});"}
globalThis.__splitResult={ids:tree.$.rows.ids(),row:held(),x:tree.$.x()};tree.destroy();`;
 writeFileSync(out+'/fixture.mjs',source);
 const r=await build({entryPoints:[out+'/fixture.mjs'],bundle:true,minify:true,format:'esm',platform:'browser',treeShaking:true,external:['@angular/*','rxjs','rxjs/*','tslib'],nodePaths:['/Users/jonathanborgia/code/signaltree/node_modules'],write:false,legalComments:'none',logLevel:'silent',define:{ngDevMode:'false'},metafile:true});
 const bytes=r.outputFiles[0].contents;writeFileSync(out+'/bundle.mjs',bytes);writeFileSync(out+'/meta.json',JSON.stringify(r.metafile,null,2));
 await import(pathToFileURL(out+'/bundle.mjs'));assert.deepEqual(globalThis.__splitResult,{ids:['a','b'],row:{id:'a',v:1},x:0});
 const prepareInputs=Object.entries(r.metafile.outputs).flatMap(([,o])=>Object.entries(o.inputs)).filter(([p,v])=>p.includes('/prepare-entity-target.js')&&v.bytesInOutput>0);
 if(arm==='after')assert.equal(prepareInputs.length>0,enhanced,'optional preparation must be absent in plain and present in enhanced');
 receipts.push({arm,fixture:name,gzipBytes:gzipSync(bytes,{level:9}).length,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),preparation:prepareInputs,behavior:globalThis.__splitResult,inputHashes:Object.fromEntries(Object.keys(r.metafile.inputs).map(p=>[p,createHash('sha256').update(readFileSync(p)).digest('hex')]))});
}
writeFileSync(dir+'/bundle-comparison.json',JSON.stringify(receipts,null,2));console.log(receipts.map(({inputHashes,...x})=>x));
