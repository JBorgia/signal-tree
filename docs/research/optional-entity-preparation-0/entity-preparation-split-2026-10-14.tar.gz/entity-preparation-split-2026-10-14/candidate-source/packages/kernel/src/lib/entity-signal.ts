import type {
  Location,
  ReadableCell,
  WritableCell,
} from './internals/cell-runtime';
import type { EpochHandle } from './internals/observation-adapter';
import {
  createWritableProjection,
  deriveLocation,
  NEUTRAL_LOCATION_RUNTIME,
  replaceLocation,
  type LocationRuntime,
} from './internals/location-runtime';
import { deepClone } from './internals/utilities/deep-clone';
import { deepEqual } from './internals/utilities/deep-equal';

import {
  EntityMutationFrame,
  type PreparedFreshSubject,
  type PreparedKeyTransfer,
  type PreparedRetainedValueRetirement,
  type PreparedSubjectRestore,
  type PreparedSubjectTombstone,
  type PreparedValueReplacement,
} from './physical/entity-mutation-frame';
import { resolveEntityHandle } from './physical/entity-handle-resolution';
import { EntityValueStore } from './physical/entity-value-store';
import {
  StructuralStore,
  type AcquiredSubjectHandle,
  type SubjectLifetimeRecord,
} from './physical/structural-store';
import { defineOwnedOwnerPath } from './internals/owned-mutation';
import {
  defineEntityMembershipSource,
  MEMBERSHIP_CLOSE,
  MEMBERSHIP_FACTS,
  MEMBERSHIP_OPEN,
  MEMBERSHIP_OPEN_ORDER,
  type EntityMembershipTap,
} from './internals/entity-membership-source';
import type { PhysicalCommitClock } from './internals/physical-commit-clock';
// Only `notify` is ever called on this — the neutral port contract, not the
// delivery engine's full surface.
import type { PathObservationPort } from './internals/path-observation-port';
import { getActiveWriteContext } from '../lib/write-context';
import { recordProductionSubstrateStat } from './internals/production-substrate-stats';
import {
  defineEntityLocationBinding,
  defineEntityProjectionSeed,
} from './internals/entity-projection-seed';
import {
  definePositionRegistry,
  getNodeAddress,
  getPositionRegistry,
} from './internals/position-registry';
import { markOwnerInvalidated } from './internals/owner-invalidation-port';
import {
  inStructuralWrite,
  isAbsentMember,
  MEMBERSHIP_CHANGED,
  reactivatePathOnWrite,
  structuralWrites,
} from './internals/member-membership';
import { physicalRows, taps } from './internals/physical-rows';
import {
  MUTATION_CAPTURE_RUNTIME,
  type CommittedEntityMutation,
  type MutationCaptureRuntime,
} from './internals/mutation-capture-runtime';
import type {
  CollectionTransitionTarget,
  CollectionTransitionTargetBinding,
} from './internals/causal-runtime/target-transition';

// Angular's global dev-mode flag (defined by the Angular CLI; undefined in
// plain test/node contexts, treated as dev there).
declare const ngDevMode: boolean | undefined;

/**
 * Wrong entityMap method names AI agents and devs reach for (from other state
 * libraries), mapped to the SignalTree equivalent. Used by a dev-mode proxy
 * guardrail to turn a cryptic "undefined is not a function" into an actionable
 * hint. Sourced from the documented cross-library hallucination table.
 */
const WRONG_ENTITY_METHODS: Record<string, string> = {
  upsert: 'upsertOne(entity) / upsertMany(entities)',
  add: 'addOne(entity) / addMany(entities)',
  insert: 'addOne(entity)',
  update: 'updateOne(id, changes) / updateMany(ids, changes)',
  remove: 'removeOne(id) / removeMany(ids)',
  delete: 'removeOne(id)',
  getAll: 'all() (a signal)',
  selectAll: 'all() (a signal)',
  selectMany: 'where(predicate)',
  selectEntity: 'byId(id)',
  addEntities: 'addMany(entities)',
  setEntities: 'setAll(entities)',
  setProps: 'set leaves directly — entityMap has no props object',
  next: 'set leaves directly — not an RxJS Subject',
  asObservable: 'use the signal directly — not an RxJS Subject',
};

type EntityPositionIdAllocator = () => number | undefined;
let nextStandaloneEntityPositionId = 1;
const standaloneEntityPositionIdAllocator: EntityPositionIdAllocator = () =>
  nextStandaloneEntityPositionId++;
let entityPositionIdAllocatorOverride: EntityPositionIdAllocator | undefined;
let entityPositionIdNotifyEnabled = true;

/** @internal Bench/test-only hook for owner PositionId allocation experiments. */
// ⚠️ NOT EXPORTED. Used only inside this module; the `export` was surplus.
// (ORPHAN sweep, 15.0. Same-file-only proves the EXPORT is unnecessary — it says
// nothing about who owns the code, and this code is live.)
function setEntityPositionIdAllocatorForTesting(
  allocator?: EntityPositionIdAllocator
): void {
  entityPositionIdAllocatorOverride = allocator;
}

/** @internal Bench/test-only hook to isolate owner-id carriage from stamping. */
// ⚠️ NOT EXPORTED. Used only inside this module; the `export` was surplus.
// (ORPHAN sweep, 15.0. Same-file-only proves the EXPORT is unnecessary — it says
// nothing about who owns the code, and this code is live.)
function setEntityPositionIdNotifyEnabledForTesting(enabled = true): void {
  entityPositionIdNotifyEnabled = enabled;
}

export type EntitySubjectPhysicalInventory<K extends string | number> = {
  subjectId: number;
  state: 'active' | 'tombstoned';
  subjectRevision: number;
  activeKey: K | undefined;
  retainedSubjectState: boolean;
  entitySignal: boolean;
  activationToken: boolean;
  nodeFacadeMaterialized: boolean;
  fieldFacadesMaterialized: readonly string[];
  positionIds: readonly PositionId[] | undefined;
  retainedValueBacking:
    | {
        kind: 'retained-entity-signal';
      }
    | undefined;
};

export type EntitySubjectReclamationResource =
  | 'subject-lifetime-record'
  | 'retained-value-backing'
  | 'subject-activation-channel'
  | 'row-facade'
  | 'field-facades'
  | 'ownership-metadata';

export type EntitySubjectReclamationUnresolved = {
  resource: EntitySubjectReclamationResource;
  reason: 'terminal-facade-dependency-unknown';
};

export type EntitySubjectReclamationPlan = {
  subjectId: number;
  eligible: boolean;
  retire: readonly EntitySubjectReclamationResource[];
  retain: readonly EntitySubjectReclamationResource[];
  unresolved: readonly EntitySubjectReclamationUnresolved[];
};

export type PreparedEntitySubjectReclamation = {
  subjectId: number;
  expectedLifetime: 'tombstoned';
  expectedSubjectRevision: number;
  retire: readonly EntitySubjectReclamationResource[];
  retain: readonly EntitySubjectReclamationResource[];
};

export type EntitySubjectReclamationPlanningOptions = {
  causallyEligible: boolean;
  /**
   * Also drop the subject's LIFETIME RECORD, not just its value bytes.
   *
   * Off by default because the two have different safety arguments. Retiring
   * the value is invisible: nothing reads `backingForSubject` on a tombstoned
   * subject, and every restorer holds its own copy. Forgetting the lifetime is
   * what makes the subject unrestorable, so it needs a caller that has
   * established nothing can still restore it.
   *
   * It is also the only half that BOUNDS retention. The value is ~132 B of the
   * measured 249 B/retired and the lifetime record is the other ~111 B, and the
   * ledger is what grows with every subject the collection has ever retired.
   * A sink that retires only the value leaves a slope — measured, after the
   * first version of this did exactly that and the inventory looked bounded
   * because `__listSubjectReclamationCandidates` only counts value-backed
   * subjects.
   */
  reclaimLifetimeRecord?: boolean;
};

export function planEntitySubjectReclamation<K extends string | number>(
  inventory: EntitySubjectPhysicalInventory<K>,
  options: EntitySubjectReclamationPlanningOptions
): EntitySubjectReclamationPlan {
  const retain: EntitySubjectReclamationResource[] = [];

  if (inventory.retainedSubjectState) {
    retain.push('subject-lifetime-record');
  }
  if (inventory.retainedValueBacking) {
    retain.push('retained-value-backing');
  }
  if (inventory.activationToken) {
    retain.push('subject-activation-channel');
  }
  if (inventory.nodeFacadeMaterialized) {
    retain.push('row-facade');
  }
  if (inventory.fieldFacadesMaterialized.length > 0) {
    retain.push('field-facades');
  }
  if ((inventory.positionIds?.length ?? 0) > 0) {
    retain.push('ownership-metadata');
  }

  if (inventory.state !== 'tombstoned') {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: [],
    };
  }

  if (!options.causallyEligible) {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: [],
    };
  }

  const retire: EntitySubjectReclamationResource[] = [];
  const remaining = [...retain];
  const promote = (resource: EntitySubjectReclamationResource) => {
    retire.push(resource);
    const index = remaining.indexOf(resource);
    if (index !== -1) {
      remaining.splice(index, 1);
    }
  };

  if (inventory.retainedValueBacking) {
    promote('retained-value-backing');
  }
  if (options.reclaimLifetimeRecord && inventory.retainedSubjectState) {
    promote('subject-lifetime-record');
  }

  return {
    subjectId: inventory.subjectId,
    eligible: true,
    retire,
    retain: remaining,
    unresolved: [],
  };
}

/**
 * EntitySignal Implementation (Composition Pattern)
 *
 * Map-based reactive entity collections with:
 * - Full CRUD operations (addOne, updateOne, removeOne, upsertOne)
 * - Query signals (all, count, ids, byId, where, find)
 * - Entity hooks (tap for observation)
 * - Entity interceptors (intercept for blocking/transforming)
 * - Deep signal access (tree.$.users['id'].name())
 *
 * Uses composition (closures) instead of classes to avoid
 * Proxy + class `this` binding issues.
 *
 * @internal
 */

import type {
  EntityConfig,
  EntitySignal,
  TapHandlers,
  InterceptHandlers,
  InterceptContext,
  EntityNode,
  AddOptions,
  AddManyOptions,
  WriteMetadata,
  PositionId,
  StructuralEffect,
} from '../lib/types';

/**
 * True when the subjects present at both endpoints appear in a different
 * relative order. Subjects present at only one endpoint are ignored.
 */
function survivingOrderChanged(
  before: readonly number[],
  after: readonly number[]
): boolean {
  const inAfter = new Set(after);
  const inBefore = new Set(before);
  const survivingBefore = before.filter((subject) => inAfter.has(subject));
  const survivingAfter = after.filter((subject) => inBefore.has(subject));
  return survivingBefore.some(
    (subject, index) => subject !== survivingAfter[index]
  );
}

/**
 * Creates an EntitySignal using composition pattern.
 * All state is stored in closures - no `this` binding issues possible.
 *
 * @internal
 */
export function createEntitySignal<
  E extends Record<string, unknown>,
  K extends string | number = string
>(
  config: EntityConfig<E, K>,
  pathNotifier: PathObservationPort,
  basePath: string,
  options?: {
    physicalCommitClock?: PhysicalCommitClock;
    mutationCaptureRuntime?: MutationCaptureRuntime;
    positionIdAllocator?: EntityPositionIdAllocator;
    ownerMetadataEnabled?: boolean;
    subjectMetadataEnabled?: boolean;
    positionMetadataEnabled?: boolean;
    /**
     * Registry namespace of the tree this collection belongs to.
     *
     * OWNER-REPLAY-2. Collections notify the path notifier DIRECTLY rather than
     * through the owned-write wrapper, so an authored `addOne`/`removeOne`
     * reached subscribers with `ownerId: undefined` while the restoration and
     * rollback replays of the SAME operation carried it. An owner-filtered
     * observer was therefore blind to every authored collection change.
     */
    ownerId?: number;
    locationRuntime?: LocationRuntime;
    /**
     * Whether anything in this tree could restore a subject after it retires.
     *
     * Comes from the finalized build plan (`RuntimeTreePlan`) and cannot change
     * for the life of the tree. `false` is what licenses zero-owner reclamation
     * at the retirement boundary below.
     *
     * DEFAULTS TO TRUE — retain. A collection created outside `signalTree`'s
     * construction path has no plan to consult, and reclaiming a subject some
     * unseen owner could restore is unrecoverable.
     */
    hasRestorationAuthority?: boolean;
  }
): EntitySignal<E, K> {
  const locations = options?.locationRuntime ?? NEUTRAL_LOCATION_RUNTIME;
  // ==================
  // CLOSURE STATE (no `this` needed)
  // ==================

  // Derived materialized projection only.
  // Authoritative structural state lives in structuralStore.
  // Authoritative subject values live in valueStore.

  /**
   * Collection version. Bumped once per mutation; every collection query below
   * derives from it LAZILY.
   *
   * This replaced eager rebuilding, which made a single-entity update O(size).
   * `updateSignals()` used to run on EVERY mutation and do three full copies of
   * the collection — `Array.from(storage.values())`, `Array.from(storage.keys())`
   * and `new Map(storage)` — plus a `.set()` on each derived signal, which then
   * deep-compared them. Measured on a 50,000-row collection: 2.8ms PER
   * `updateOne`, scaling cleanly with size (38us @1k, 510us @10k). That defeats
   * the entire point of a Map-backed entity store, whose storage write is O(1).
   *
   * (It was not the deep equality: shallow comparison measured the same. It was
   * the copying.)
   *
   * Now the copies happen only when a query is actually READ, and Angular's
   * computed caches them until the next mutation — so a grid that reads `all()`
   * once per frame pays once per frame instead of once per write.
   */
  const version = locations.createCell(0);
  /**
   * `SUBJECT-EPOCH-0`. Epochs to advance when the batch flushes.
   *
   * It holds the CELLS, not subject ids, and that is load bearing. `removeOne`
   * runs `tombstoneSubjectSignal` -> `reclaimRetiredSubjectsWithoutOwner` ->
   * `updateSignals`, and the middle step deletes the registry entry. Staging an
   * id means the flush looks up an epoch that no longer exists, skips the
   * advance, and a `computed` that read this row never learns it was removed.
   * Holding the cell keeps the pending invalidation alive across its own
   * reclamation — which is exactly why the map this replaced staged `Location`
   * objects rather than keys.
   *
   * No value is staged: the value is already in `EntityValueStore` before
   * anything lands here, so a copy would be a second truth.
   */
  const pendingSubjectEpochs = new Set<EpochHandle>();

  const createVersionedProjection = <TValue>(
    compute: () => TValue
  ): ReadableCell<TValue> => {
    let projectedVersion = -1;
    let initialized = false;
    let value: TValue;
    return locations.createDerived(() => {
      const currentVersion = version();
      if (!initialized || projectedVersion !== currentVersion) {
        value = compute();
        projectedVersion = currentVersion;
        initialized = true;
      }
      return value;
    });
  };

  function getProjectedEntity(id: K): E | undefined {
    const subjectId = structuralStore.subjectIdForKey(id);
    return subjectId === undefined
      ? undefined
      : valueStore.backingForSubject(subjectId);
  }

  function getProjectedEntries(): Array<readonly [K, E]> {
    const entries: Array<readonly [K, E]> = [];
    for (const id of structuralStore.activeKeysSnapshot()) {
      const entity = getProjectedEntity(id);
      if (entity !== undefined) {
        entries.push([id, entity] as const);
      }
    }
    return entries;
  }

  function getProjectedEntities(): E[] {
    return getProjectedEntries().map(([, entity]) => entity);
  }

  /**
   * ⚠️ PUBLIC READS ARE ABSENT WHILE THE COLLECTION IS (v16 8e). A collection
   * omitted itself or under an omitted member is an absent, empty collection
   * to every public read and to every write that names a row: "DORMANT
   * STORAGE MUST NOT SUPPLY THE REACTIVATED VALUE"
   * (`whole-value-membership.spec.ts` 18). Its retained rows stay physical
   * truth for restoration and transactions, which keep the `getProjected*`
   * reads. One symbol lookup on a collection that was never under an
   * omission.
   */
  const absent = (): boolean => isAbsentMember(api);
  // Row reads and row writes use physical truth only while a reversal or a
  // rollback is being applied to this collection's tree (`physicalRows`).
  // Projections never do, so nothing they cache can hold retained rows.
  // A tap reads absent-aware even inside the window, unless it started the
  // reversal itself: the window records the tap depth it opened at.
  const rowAbsent = (): boolean => {
    if (!absent()) return false;
    if (!physicalRows.length) return true;
    const registry = getPositionRegistry(api);
    return !physicalRows.some(
      ([open, depth]) => open === registry && depth === taps.depth
    );
  };
  const presentEntity = (id: K): E | undefined =>
    rowAbsent() ? undefined : getProjectedEntity(id);
  const presentEntries = (): Array<readonly [K, E]> =>
    absent() ? [] : getProjectedEntries();
  const presentEntities = (): E[] => (absent() ? [] : getProjectedEntities());

  function acquireEntityHandleForTesting(
    id: K
  ): AcquiredSubjectHandle | undefined {
    return structuralStore.acquireSubjectHandleForKey(id);
  }

  function resolveEntityHandleForTesting(handle: AcquiredSubjectHandle) {
    return resolveEntityHandle(structuralStore, valueStore, handle);
  }

  function rebuildActiveProjectionFromOwners(): ReadonlyMap<K, E> {
    return new Map(getProjectedEntries());
  }

  function createEntityMutationFrame(): EntityMutationFrame<K, E> {
    return new EntityMutationFrame(valueStore, structuralStore);
  }

  /** Existing-lifetime value plans: all reflection precedes physical installation. */
  function preparePointValues(
    values: readonly { subjectId: number; key: string | number; value: unknown }[]
  ): { install(): void; invalidate(): void; publish(): void } {
    const prepared = values.map(({ subjectId, key, value }) => {
      if (structuralStore.activeKeyForSubject(subjectId) !== key) {
        throw new Error('Point realization subject is no longer active at its key');
      }
      const before = valueStore.backingForSubject(subjectId);
      const after = deepClone(value) as E;
      return { subjectId, key: key as K, before, after,
        changed: !deepEqual(before, after), epoch: subjectEpochs.get(subjectId) };
    });
    return {
      install(): void {
        for (const row of prepared) valueStore.retainSubjectValue(row.subjectId, row.after);
      },
      invalidate(): void {
        let failed = false;
        let firstError: unknown;
        const stage = (fn: () => void) => { try { fn(); } catch (error) {
          if (!failed) { failed = true; firstError = error; }
        } };
        for (const row of prepared) {
          const epoch = row.epoch;
          if (epoch) stage(() => advanceEpochHandle(epoch));
        }
        stage(() => updateSignals());
        if (failed) throw firstError;
      },
      publish(): void {
        for (const row of prepared) {
          pathNotifier.notify(`${basePath}.${String(row.key)}`, row.after, row.before,
            basePath, [row.subjectId], getPositionIdsForNotify(),
            { ...(ambientMeta() ?? {}), intent: 'system', participation: 'realized' });
          if (row.changed) emitTap('onUpdate', row.key, row.after, row.after);
        }
      },
    };
  }

  function readTransitionSource(): CollectionTransitionTarget {
    if (positionId === undefined) {
      throw new Error('Collection transition binding has no owner PositionId');
    }
    const subjects = structuralStore.activeKeysSnapshot().map((key) => {
      const subject = structuralStore.subjectIdForKey(key);
      const value =
        subject === undefined
          ? undefined
          : valueStore.backingForSubject(subject);
      if (subject === undefined || value === undefined) {
        throw new Error(
          'Collection transition source is missing active subject truth'
        );
      }
      return { subject, key, value };
    });
    return {
      owner: positionId,
      subjects,
      order: subjects.map(({ subject }) => subject),
      orderFrontier: structuralStore.activeOrderFrontier(),
    };
  }

  function commitAndProjectEntityMutationFrame(
    frame: EntityMutationFrame<K, E>,
    options?: { advancePhysicalRevision?: boolean }
  ) {
    const revision=physicalCommitClock?.revision();
    const changes: Array<import('./internals/mutation-capture-runtime').CommittedEntityMutation> = [];
    // Only fresh subjects need the pre-install tail. Preserve the sampling
    // boundary before record cloning, using the existing constant-time index.
    const hasFreshSubjects = frame.mutations.some(
      (mutation) => mutation.kind === 'create-fresh-subject'
    );
    const tailKey = hasFreshSubjects ? structuralStore.lastActiveKey() : undefined;
    let tail = tailKey === undefined
      ? undefined
      : structuralStore.subjectIdForKey(tailKey);
    for (const m of frame.mutations) {
      const key = 'key' in m ? m.key : structuralStore.activeKeyForSubject(m.subjectId);
      const before = valueStore.backingForSubject(m.subjectId);
      const path = `${basePath}.${String(key)}`;
      if (m.kind === 'replace-value') changes.push({subject:m.subjectId,before,after:m.nextValue,structural:false,path});
      else if (m.kind === 'create-fresh-subject') {
        changes.push({subject:m.subjectId,before:undefined,after:m.nextValue,structural:true,path,structuralRecord:{kind:'add',subject:m.subjectId,key:m.key,value:deepClone(m.nextValue),beforeSubject:tail}});
        tail=m.subjectId;
      } else if (m.kind === 'tombstone-subject') {
        const neighbors=getNeighborSubjects(m.key);
        changes.push({subject:m.subjectId,before,after:undefined,structural:true,path,structuralRecord:{kind:'remove',subject:m.subjectId,key:m.key,value:deepClone(before),...neighbors}});
      } else if(m.kind === 'transfer-key') {
        changes.push({subject:m.subjectId,before,after:before,structural:true,path:`${basePath}.${String(m.fromKey)}`,structuralRecord:{kind:'rekey',subject:m.subjectId,beforeKey:m.fromKey,afterKey:m.toKey}});
      }
    }
    const responsibility = changes.length ? mutationCaptureRuntime?.prepareEntityResponsibility?.({owner:getPositionIds()?.[0] as number,ownerPath:basePath,meta:ambientMeta(),changes}) : undefined;
    if(physicalCommitClock?.revision()!==revision)throw new Error('Entity frame responsibility preparation reentered installation');
    const result = frame.commit(committedEntityObserver(),responsibility);
    if (options?.advancePhysicalRevision !== false) {
      physicalCommitClock?.advance();
    }
    // Membership observation: the committed instructions, before publication.
    membershipTap?.(MEMBERSHIP_FACTS, frame.mutations);
    return result;
  }

  /** Reactive signals for queries — all derived, none eagerly maintained. */
  const computeAll = (): E[] => {
    const entities = presentEntities();
    // `sortComparer` gives `all`/`ids` a stable sorted order (parity with
    // @ngrx/entity); `map` keeps insertion order.
    if (config.sortComparer) entities.sort(config.sortComparer);
    return entities;
  };
  const allSignal: ReadableCell<E[]> = createVersionedProjection(computeAll);
  // O(1) — this used to be `entities.length` on a freshly built array.
  const computeCount = (): number =>
    absent() ? 0 : structuralStore.activeKeyCount();
  const countSignal: ReadableCell<number> =
    createVersionedProjection(computeCount);
  /**
   * ⚠️ INSIDE A TAP, A PROJECTION IS READ FRESH (v16 8f). A tap runs inside
   * its write, and inside a grouped write (a transaction, a reversal) the
   * cached projections hear of it only when the group ends: read through them,
   * a tap saw the collection as it was before the group. While a tap runs, a
   * projection is handed out as an uncached reader of the same computation.
   * It still reads `version`, so a derived computed inside a tap (a snapshot,
   * an adapter's computed) depends on the collection as the cached projection
   * would. Outside taps this is one comparison per access.
   */
  const fresh = <T>(read: () => T): ReadableCell<T> =>
    (() => {
      version();
      return read();
    }) as ReadableCell<T>;
  const inTap = <T>(cell: ReadableCell<T>, read: () => T): ReadableCell<T> =>
    taps.depth ? fresh(read) : cell;
  // Identity-stable across value-only writes: the key snapshot is shared until
  // the list or a key changes, so the copy (and every consumer) is reused.
  let idsSource: readonly K[] | undefined;
  let idsValue: K[] = [];
  // `all` is the cached projection or, in a tap, the fresh one (v16 8f).
  const computeIds = (all: () => E[]): K[] => {
    if (absent()) return [];
    if (config.sortComparer) return all().map((e) => selectId(e));
    const keys = structuralStore.activeKeysSnapshot();
    if (keys !== idsSource) {
      idsSource = keys;
      idsValue = [...keys];
    }
    return idsValue;
  };
  const idsSignal: ReadableCell<K[]> = createVersionedProjection(() =>
    computeIds(allSignal)
  );
  // Still a copy: callers may hold the result across mutations and must not
  // see it change underneath them. But it is paid on read, not on write.
  const computeMap = (): ReadonlyMap<K, E> => new Map(presentEntries());
  const mapSignal: ReadableCell<ReadonlyMap<K, E>> =
    createVersionedProjection(computeMap);

  /**
   * Per-entity signals — the body-granular reactivity layer.
   *
   * Each entity that is read via `byId()`/node access gets its own
   * `Location<E | undefined>`. Per-entity field reads and `node()` depend ONLY
   * on this location, not on the whole-collection `mapSignal`, so
   * updating one entity dirties only that entity's readers (fan-out 1) instead
   * of every entity's computeds (fan-out N). Collection queries (`all`, `map`,
   * `count`, `ids`, `where`, `find`, computed slices) still depend on the
   * collection signals and recompute on any change — which is correct.
   *
   * Materialized lazily (on first `byId`/node access) and kept O(1) per
   * mutation by only syncing the entities that actually changed.
   */
  /**
   * `SUBJECT-EPOCH-0`. One stable reactive anchor per REALIZED subject, held
   * strongly and deliberately.
   *
   * This replaces `entitySignals`, a full `Location<E>` per subject holding a
   * copy of the entity. That copy was never the durable record —
   * `getEntitySignal` seeded every cell from
   * `valueStore.backingForSubject(subjectId)` — so it was authority duplicated
   * into the framework. Reads now take a dependency here and then read
   * `EntityValueStore` directly, which is the only copy.
   *
   * STRONG on purpose, and that is the design. `ENTITY-SIGNAL-SEMANTIC-0`
   * proved a weakly held carrier is unsafe: a non-live Angular `computed` does
   * not retain its producers, so `computed(() => rows.byId(k)?.()?.x)` loses
   * its carrier to a collection and silently freezes. An epoch is cheap enough
   * to simply keep — 562 B/entity against 1,248 B for the `Location` it
   * replaces — so reachability is guaranteed by retention rather than hoped
   * for.
   */
  const subjectEpochs = new Map<number, EpochHandle>();
  /**
   * `ANGULAR-NATIVE-EPOCH-0`. Advance through the RUNTIME, never by writing the
   * handle. A framework-supplied handle belongs to its adapter; the kernel
   * assuming it could write one is what left Vue's epoch permanently dead.
   */
  const advanceEpochHandle = (handle: EpochHandle): void => {
    locations.advanceEpoch?.(handle);
  };
  const structuralStore = new StructuralStore<K>();
  /**
   * Membership observation seam (`entityMembershipReader`, internals only):
   * undefined until a reader first observes this collection. Each structural
   * operation then reports its facts once (see `entity-membership-source.ts`);
   * nothing is derived, retained or delivered here.
   */
  let membershipTap: EntityMembershipTap | undefined;
  /** One observed unit for a compound operation (prepend = add + move). */
  function withMembershipGroup<R>(run: () => R): R {
    const tap = membershipTap;
    tap?.(MEMBERSHIP_OPEN);
    try {
      return run();
    } finally {
      tap?.(MEMBERSHIP_CLOSE);
    }
  }
  const valueStore = new EntityValueStore<E>();
  /**
   * `SUBJECT-STATE-SEMANTIC-0`. Held WEAKLY.
   *
   * This carrier has no durable semantic value. Its number is a nonce: nothing
   * reads it, `currentKey` only subscribes to it, and the durable truth it
   * stands for is `structuralStore.subjectRevision`. So there is nothing here
   * to persist — only a carrier to FIND while something is still listening.
   *
   * Strongly held, it was the single largest item in the released residue: a
   * full `Location<number>` per realized subject, measured at 1,249 B/entity of
   * a 2,709 B residue. Weak, a released subject keeps a `WeakRef` and a `Map`
   * entry instead.
   *
   * THE INVARIANT. Every public dependency on subject structural state also
   * depends on a SECOND, permanently retained reactive path, so invalidation
   * reaches an observer that holds nothing here. That path is now
   * [[subjectEpochs]]: `tombstoneSubjectSignal` stages an epoch advance, and
   * the epoch is strong.
   *
   * It is NOT true that live consumers retain this carrier. Angular does not
   * give that property: measured across a forced GC, a `computed` closing over
   * the node retains its carrier, but `computed(() => rows.byId(k)?.()?.x)` —
   * an equally live observer that re-resolves each evaluation — does NOT, and
   * its carrier is collected. `ENTITY-SIGNAL-SEMANTIC-0` records the attempt
   * that proved it, by removing the stable path and watching that exact shape
   * freeze.
   *
   * So this stays safe only while the epoch stays strong, and the entry here is
   * replaced only when `deref()` comes back empty.
   */
  const subjectStateSignals = new Map<number, WeakRef<Location<number>>>();
  const ownerMetadataEnabled = options?.ownerMetadataEnabled ?? true;
  const subjectMetadataEnabled =
    options?.subjectMetadataEnabled ?? ownerMetadataEnabled;
  const positionMetadataEnabled = options?.positionMetadataEnabled ?? true;
  const hasRestorationAuthority = options?.hasRestorationAuthority ?? true;
  const ownerId = options?.ownerId;
  const physicalCommitClock = options?.physicalCommitClock;
  const mutationCaptureRuntime = options?.mutationCaptureRuntime;
  let positionId = (
    options?.positionIdAllocator ??
    (positionMetadataEnabled
      ? entityPositionIdAllocatorOverride ?? standaloneEntityPositionIdAllocator
      : undefined)
  )?.();
  let lastSubjectIds: number[] | undefined;

  type PendingStructuralEffect = StructuralEffect;
  type PendingAddStructuralEffect = Extract<
    PendingStructuralEffect,
    { kind: 'add' }
  >;

  // Callable intent belongs to this producer's egress footprint. Do not stamp
  // generic causal metadata: that would change transaction dependency policy.
  let callableWriteIntent: 'replace' | 'derive' | undefined;
  function withCallableWriteIntent(
    intent: 'replace' | 'derive',
    write: () => void
  ): void {
    const previous = callableWriteIntent;
    callableWriteIntent = intent;
    try {
      write();
    } finally {
      callableWriteIntent = previous;
    }
  }
  function consumeCallableWriteIntent(): 'replace' | 'derive' | undefined {
    const intent = callableWriteIntent;
    callableWriteIntent = undefined;
    return intent;
  }

  /**
   * The ambient write context, ALWAYS carrying this collection's owning tree.
   *
   * Every meta this file builds goes through here rather than calling
   * `ambientMeta()` directly, so a new notification site cannot
   * silently omit the namespace — which is how OWNER-REPLAY-2's defect existed
   * across eighteen sites at once.
   */
  function ambientMeta(): WriteMetadata | undefined {
    const active = getActiveWriteContext();
    if (ownerId === undefined) return active;
    return { ...(active ?? {}), ownerId };
  }

  function getPositionIds(): number[] | undefined {
    if (positionId === undefined) {
      const registry = getPositionRegistry(api);
      if (registry) {
        const allocated = registry.allocate();
        registry.registerCollectionPath(allocated, basePath);
        const address = getNodeAddress(proxy);
        if (address) registry.registerPositionAddress(allocated, address);
        positionId = allocated;
      }
    }
    return positionId === undefined ? undefined : [positionId];
  }

  function getPositionIdsForNotify(): number[] | undefined {
    return entityPositionIdNotifyEnabled &&
      (positionId !== undefined || mutationCaptureRuntime?.isCaptureActive())
      ? getPositionIds()
      : undefined;
  }

  function createStructuralEffectMeta(
    effect: PendingStructuralEffect
  ): WriteMetadata {
    const meta = ambientMeta();
    return {
      ...(meta ?? {}),
      structuralEffect: effect,
    };
  }

  /**
   * ST2026 — the inline-predicate trap, caught in dev.
   *
   * `where`/`find` memoise per predicate IDENTITY, so the natural template form
   *
   *     @for (row of tree.$.rows.where(r => !r.done)(); track row.id) { … }
   *
   * allocates a NEW arrow on every change-detection cycle, misses the cache
   * every time, and re-filters the whole collection. Measured over 1,000
   * entities: 0.27ms with a hoisted predicate against 20.54ms inline — **75x**.
   *
   * It is not a leak (the cache is a `WeakMap`; 50,000 inline calls retain ~0MB
   * after forced GC) which is exactly why it needs a diagnostic: nothing grows,
   * nothing breaks, the app is simply slow forever.
   *
   * Detection is by SOURCE TEXT plus RATE, and the rate half is load-bearing.
   *
   * Byte-identical source across many distinct identities is necessary but NOT
   * sufficient: `v => v.x > threshold`, rebuilt whenever `threshold` changes, has
   * identical source too. Counting identities alone cannot tell the two apart,
   * and it eventually accuses BOTH — the first version of this warned after 12
   * distinct identities however long they took to accumulate, so a legitimately
   * dynamic predicate warned during any long session, and the advice it gave
   * ("hoist it") was actively wrong for that shape, because the closure really
   * does differ each time.
   *
   * Rate separates them cleanly, and it is derivable rather than guessed. The
   * trap is driven by CHANGE DETECTION, so it produces a new identity every CD
   * cycle — tens per second. A predicate rebuilt from user input or a filter
   * control produces one per interaction, which is orders of magnitude slower.
   * Anything above ~6/second is a frame loop; nothing a user does reaches it.
   */
  const predicateWindows = new Map<string, { count: number; start: number }>();
  const warnedPredicates = new Set<string>();
  /** Distinct identities within {@link PREDICATE_CHURN_WINDOW_MS} to accuse. */
  const PREDICATE_CHURN_THRESHOLD = 12;
  /** ~6 identities/second is well above user-driven, well below a frame loop. */
  const PREDICATE_CHURN_WINDOW_MS = 2000;

  function warnOnPredicateChurn(
    method: 'where' | 'find',
    predicate: (entity: E) => boolean
  ): void {
    const source = String(predicate);
    // Guard against pathological state growth in a long dev session: the map is
    // only ever as large as the number of DISTINCT predicate sources.
    if (predicateWindows.size > 200 || warnedPredicates.has(source)) return;

    const now =
      typeof performance !== 'undefined' ? performance.now() : Date.now();
    const window = predicateWindows.get(source);
    if (!window || now - window.start > PREDICATE_CHURN_WINDOW_MS) {
      // A fresh window, not an increment. This is what makes a slow drip of
      // legitimately-rebuilt predicates never accumulate to an accusation.
      predicateWindows.set(source, { count: 1, start: now });
      return;
    }
    window.count++;
    if (window.count < PREDICATE_CHURN_THRESHOLD) return;

    warnedPredicates.add(source);
    const perSecond = Math.round(
      (window.count / Math.max(now - window.start, 1)) * 1000
    );
    console.warn(
      `SignalTree: \`${method}()\` received ${window.count} DIFFERENT functions ` +
        `with identical source in ${Math.round(now - window.start)}ms ` +
        `(~${perSecond}/second) — a rate only change detection produces. ` +
        `Results are memoised per predicate IDENTITY, so an inline arrow misses ` +
        `the cache every cycle and re-scans the collection: measured at 75x a ` +
        `hoisted predicate over 1,000 entities. Hoist it to a stable reference ` +
        `(a class field or module constant) and call ` +
        `\`${method}(thePredicate)()\`. Source: ${source.slice(0, 80)} [ST2026]`
    );
  }

  /** Subjects that have moved to a new key and must not fall back to the old one. */
  const rekeyedSubjects = new Set<number>();

  function planRekey(
    from: K,
    to: K
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    const entity = getProjectedEntity(from);
    if (!entity) {
      throw new Error(`Entity with id ${String(from)} not found`);
    }
    if (from === to) {
      // A no-op rekey still ADDRESSES this subject, and the leaf-signal
      // interceptor fires on every mutator call — including one that changes
      // nothing. Every sibling mutator narrows the latch unconditionally, so
      // the no-op must too: leaving the latch at the previous write's
      // participation set lets a no-op rekey re-publish a bulk write's
      // subject inventory into the capture bucket of whatever designated
      // write shares the tick. RESTORATION-REKEY-CLAIM-WIDTH-0.
      const noOpSubjectId = allocateSubjectId(from);
      return {
        commit(): void {
          lastSubjectIds = [noOpSubjectId];
        },
        publish(): void {
          // no-op
        },
      };
    }
    if (structuralStore.hasActiveKey(to)) {
      throw new Error(`Cannot change id to ${String(to)}: already in use`);
    }

    return planPreparedRekey(from, to, allocateSubjectId(from), entity);
  }

  function planPreparedRekey(
    from: K,
    to: K,
    subjectId: number,
    entity: E
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    if (from === to) {
      // Same rule as `planRekey`'s no-op branch: the interceptor fires on the
      // call, so the latch must name the addressed subject even when the
      // rekey changes nothing. RESTORATION-REKEY-CLAIM-WIDTH-0.
      return {
        commit(): void {
          lastSubjectIds = [subjectId];
        },
        publish(): void {
          // no-op
        },
      };
    }

    const structuralEffect: PendingStructuralEffect = {
      kind: 'rekey',
      subject: subjectId,
      beforeKey: from,
      afterKey: to,
    };

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const transfer: PreparedKeyTransfer<K> = {
          kind: 'transfer-key',
          fromKey: from,
          toKey: to,
          subjectId,
        };
        const frame = createEntityMutationFrame();
        frame.stageKeyTransfer(transfer);
        const result = commitAndProjectEntityMutationFrame(frame, options);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        rekeyedSubjects.add(subjectId);
        // Narrow last-write participation to the one rekeyed subject. The
        // leaf-signal interceptor re-reads `__subjectIds` after `changeId`
        // returns; without this it reports every subject of the prior
        // collection write as a participant, and restoration then retains a
        // claim per live subject. Sibling mutators all narrow this latch.
        // RESTORATION-REKEY-CLAIM-WIDTH-0.
        lastSubjectIds = [subjectId];

        if (activeIdSignal() === from) {
          replaceLocation(activeIdSignal, to);
        }

        syncEntitySignal(to);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        const meta = metaOverride ?? ambientMeta();
        pathNotifier.notify(
          `${basePath}.${String(to)}`,
          entity,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...(meta ?? {}),
            structuralEffect,
          }
        );
      },
    };
  }

  /** Active-entity selection. See the `activeId`/`activeEntity` accessors. */
  const activeIdSignal = locations.createCell<K | undefined>(undefined);
  let cachedActiveEntity: ReadableCell<E | undefined> | undefined;

  function publishOrderChange(
    beforeSubjects: number[],
    afterSubjects: number[],
    beforeFrontier: unknown
  ): void {
    if (positionId === undefined) return;
    mutationCaptureRuntime?.publishCollectionOrder?.({
      owner: positionId,
      ownerPath: basePath,
      beforeSubjects,
      afterSubjects,
      beforeFrontier,
      afterFrontier: structuralStore.activeOrderFrontier(),
      meta: ambientMeta(),
    });
  }

  /**
   * Re-orders `storage` so the given ids come first, in the order given.
   *
   * Only the map's iteration order changes; no per-entity signal is touched, so
   * prepending does not invalidate any row's consumers. The derived collection
   * signals pick the new order up from the version bump.
   */
  function moveToFront(ids: K[]): void {
    const tap = membershipTap;
    tap?.(MEMBERSHIP_OPEN_ORDER);
    try {
      structuralStore.moveKeysToFront(ids);
    } finally {
      tap?.(MEMBERSHIP_CLOSE);
    }
    physicalCommitClock?.advance();
    updateSignals();
  }

  function resolveSubjectId(id: K): number | undefined {
    return structuralStore.subjectIdForKey(id);
  }

  function resolveSubjectState(
    subjectId: number
  ): SubjectLifetimeRecord<K> | undefined {
    return structuralStore.stateForSubject(subjectId);
  }

  function getSubjectRevision(subjectId: number): number {
    return structuralStore.subjectRevision(subjectId);
  }

  function bumpSubjectRevision(subjectId: number): void {
    structuralStore.bumpSubjectRevision(subjectId);
  }

  /** Get (or lazily create) the per-entity signal, seeded from storage. */
  /** Stage an advance only for a subject something has actually realized. */
  function stageSubjectEpoch(subjectId: number): void {
    const epoch = subjectEpochs.get(subjectId);
    if (epoch) pendingSubjectEpochs.add(epoch);
  }

  /** Materialized lazily: a subject nobody has read has no epoch. */
  function getSubjectEpoch(subjectId: number): EpochHandle {
    let epoch = subjectEpochs.get(subjectId);
    if (!epoch) {
      epoch = locations.createEpoch ? locations.createEpoch() : neutralEpoch();
      subjectEpochs.set(subjectId, epoch);
    }
    return epoch;
  }

  function neutralEpoch(): EpochHandle {
    const cell = locations.createCell(0);
    const epoch = (() => cell()) as WritableCell<number>;
    epoch.set = (value: number) => cell(value);
    epoch.update = (fn: (current: number) => number) => cell(fn);
    epoch.asReadonly = () => cell;
    return epoch as unknown as EpochHandle;
  }

  /**
   * Take the stable dependency, then read the ONE copy of the value.
   *
   * Order matters: canonical stores are written by `install()` before
   * `publish()` advances any epoch, so a reader can observe a new value before
   * its invalidation, but never an invalidation before its value.
   */
  function readSubjectEntity(subjectId: number): E | undefined {
    getSubjectEpoch(subjectId)();
    return rowAbsent() ? undefined : valueStore.backingForSubject(subjectId);
  }

  function readEntityByKey(id: K): E | undefined {
    const subjectId = resolveSubjectId(id);
    if (subjectId === undefined) return presentEntity(id);
    return readSubjectEntity(subjectId);
  }

  function getSubjectStateSignal(subjectId: number): Location<number> {
    const existing = subjectStateSignals.get(subjectId)?.deref();
    if (existing) return existing;
    // Starting a replacement back at 0 is sound precisely because the value is
    // a nonce: every observer that could have compared against the old count
    // was retaining the old carrier, which is why this branch was not taken.
    const created = locations.createCell(0);
    subjectStateSignals.set(subjectId, new WeakRef(created));
    return created;
  }

  function bumpSubjectStateSignal(subjectId: number): void {
    // Publish only to an activation token that already exists. Interning here
    // would recreate eager realization through the write path: any subject that
    // is ever mutated would acquire a token whether or not anything observes it.
    const signal = subjectStateSignals.get(subjectId)?.deref();
    if (signal) deriveLocation(signal, (value) => value + 1);
  }

  function publishSubjectPhysicalChange(subjectId: number): void {
    bumpSubjectRevision(subjectId);
    bumpSubjectStateSignal(subjectId);
  }

  function allocateSubjectId(id: K): number {
    const existing = structuralStore.subjectIdForKey(id);
    if (existing !== undefined) {
      return existing;
    }

    return commitFreshSubject(id);
  }

  function commitFreshSubject(id: K): number {
    const subjectId = structuralStore.allocateFreshSubjectId();
    structuralStore.createSubject(subjectId, id);
    return subjectId;
  }

  /**
   * `UPDATEONE-FAST-0`. The single-subject form of `rememberSubjectIds`, which
   * allocates twice for one id — once for the caller's `[id]` literal and once
   * for `.map`.
   */
  function rememberSubjectId(id: K): number {
    const resolved = allocateSubjectId(id);
    lastSubjectIds = [resolved];
    return resolved;
  }

  /**
   * The value-replacement commit for a subject that already exists.
   *
   * NOT yet a single shared implementation, and the distinction matters.
   * `valueStore.retainSubjectValue` IS the true primitive and both routes call
   * it; what is duplicated is the REVISION advance, which happens here for the
   * fast path and in `commitAndProjectEntityMutationFrame` for the frame path.
   * Behaviour is equivalent and pinned by
   * `entity-update-one-equivalence.spec.ts`, which runs against both — but two
   * call sites advance the physical clock, so a change to revision semantics
   * has to find both.
   *
   * CLEANUP OWED: have `EntityMutationFrame`'s `replace-value` instruction go
   * through this function, or move the advance into `retainSubjectValue`, so
   * there is one place that decides what a value replacement costs.
   *
   * Admissible ONLY when the mutation is exactly one value replacement with no
   * structural consequence: the subject exists, keeps its SubjectId and
   * lifetime, does not change key, ordering, membership or structural owner,
   * and nothing is created, restored or retired. `updateOne` is that case by
   * construction — it stages one `replace-value` and nothing else — which is
   * why it can call this directly rather than testing for it.
   *
   * Profiled: the frame path cost `entity-mutation-frame.commit` 20.3% of
   * `updateOne` plus 9.4% GC, because `commit()` allocates a prepared-
   * instruction array, a `Set` and an id array per mutation regardless of size.
   * For a one-field update that machinery is the mutation.
   */
  function commitExistingSubjectValue(subjectId: number, nextValue: E): void {
    const capture = committedEntityObserver();
    const before = capture
      ? valueStore.backingForSubject(subjectId)
      : undefined;
    const revision = physicalCommitClock?.revision();
    const plan = mutationCaptureRuntime?.prepareEntityResponsibility?.({
      owner: getPositionIds()?.[0] as number, ownerPath: basePath,
      changes: [{subject: subjectId, before: valueStore.backingForSubject(subjectId), after: nextValue, structural: false, path: `${basePath}.${String(structuralStore.activeKeyForSubject(subjectId))}`} ],
      meta: ambientMeta(),
    });
    if (physicalCommitClock?.revision() !== revision) throw new Error('Entity responsibility preparation reentered installation');
    valueStore.retainSubjectValue(subjectId, nextValue);
    if (plan) {
      for (let i=0;i<plan.writes.length;i++) { const w=plan.writes[i]; w.map.set(w.key,w.value); }
      for (let i=0;i<plan.adds.length;i++) { const a=plan.adds[i]; a.set.add(a.value); }
    }
    capture?.([
      { subject: subjectId, before, after: nextValue, structural: false },
    ]);
    physicalCommitClock?.advance();
  }

  /**
   * Source-owned committed evidence for open transaction/restoration capture.
   *
   * Runs after the physical write it describes and before this collection
   * notifies the path notifier for the operation, so an observer re-entering
   * from notifier delivery of the first row cannot find a later row of the
   * same operation unclaimed. Frame commits and single-row writes report once,
   * after every touched row has applied. The batch writers (`upsertMany`,
   * `clear`, `setAll`) report row by row, interleaved only with staged epoch
   * and state-token publications, which a transaction callback's invalidation
   * group defers until the callback returns. Attribution is frozen here,
   * before any callback can change the ambient write context. Pay-for-use:
   * undefined unless an observer is active.
   */
  function committedEntityObserver():
    | ((changes: readonly CommittedEntityMutation[]) => void)
    | undefined {
    if (!mutationCaptureRuntime?.hasCommittedEntityObservers?.())
      return undefined;
    const owner = getPositionIds()?.[0];
    if (owner === undefined) return undefined;
    const meta = ambientMeta();
    return (changes) =>
      mutationCaptureRuntime.publishCommittedEntity?.({
        owner,
        ownerPath: basePath,
        changes,
        meta,
      });
  }

  function rememberSubjectIds(ids: K[]): number[] {
    const resolved = ids.map((id) => allocateSubjectId(id));
    lastSubjectIds = resolved;
    return resolved;
  }

  function findKeyBySubjectId(subjectId: number): K | undefined {
    return structuralStore.activeKeyForSubject(subjectId);
  }

  function getNeighborSubjects(id: K): {
    beforeSubject?: number;
    afterSubject?: number;
  } {
    return structuralStore.neighborSubjectsForKey(id);
  }

  function restoreOne(
    key: K,
    entity: E,
    subjectId: number,
    beforeSubject?: number,
    afterSubject?: number
  ): void {
    const planned = planRestore(
      key,
      entity,
      subjectId,
      beforeSubject,
      afterSubject
    );
    planned.commit();
    planned.publish();
  }

  function planRestore(
    key: K,
    entity: E,
    subjectId: number,
    beforeSubject?: number,
    afterSubject?: number,
    /**
     * Keys the caller's frame will vacate before this restore commits.
     * RESTORE-P0 P0-D: the frame's own removals commit BEFORE its restores, so
     * a key listed here is free by the time this plan runs even though it is
     * occupied right now.
     */
    vacatingKeys?: ReadonlySet<string | number>
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    // The occupancy check answers "is this key free?" — but the honest question
    // is "will this key be free when I commit?". Undoing a turn that removed
    // 'a' and re-added 'a' produces two effects on two DIFFERENT subjects (a
    // removed key is tombstoned, so re-adding mints a new subject). Reversing
    // them frees 'a' and reclaims it in one frame, and asking the pre-frame
    // question turned a correct undo into a crash.
    if (structuralStore.hasActiveKey(key) && !vacatingKeys?.has(key)) {
      throw new Error(`Entity with id ${String(key)} already exists`);
    }

    const state = resolveSubjectState(subjectId);
    if (state && !state.restoreAllowed) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} has retired backing and cannot be restored.`
      );
    }

    const restoration: PreparedSubjectRestore<K, E> = {
      kind: 'restore-subject',
      key,
      subjectId,
      restoreAllowed: state?.restoreAllowed ?? true,
      beforeSubject,
      afterSubject,
      realizedValue: entity,
    };

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const frame = createEntityMutationFrame();
        frame.stageSubjectRestore(restoration);
        const result = commitAndProjectEntityMutationFrame(frame, options);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        // A restored lifetime re-enters collection membership. Value-only
        // delivery cannot reinsert it into an observer's collection topology
        // (a Link's egress projection drops a value for an absent subject).
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          undefined,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...(metaOverride ?? ambientMeta() ?? {}),
            structuralEffect: {
              kind: 'add',
              subject: subjectId,
              key,
              value: deepClone(entity),
              beforeSubject,
              afterSubject,
            },
          }
        );
        emitTap('onAdd', entity, key);
      },
    };
  }

  function planFreshAdd(
    key: K,
    entity: E,
    subjectId: number
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    const existingState = resolveSubjectState(subjectId);
    if (existingState) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} already exists and cannot be realized as fresh.`
      );
    }

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const frame = createEntityMutationFrame();
        frame.stageFreshSubject({
          kind: 'create-fresh-subject',
          key,
          subjectId,
          nextValue: entity,
        });
        commitAndProjectEntityMutationFrame(frame, options);
        lastSubjectIds = [subjectId];
        invalidateNodeCache(key);
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          undefined,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          metaOverride
        );
        emitTap('onAdd', entity, key);
      },
    };
  }

  function planRemove(
    key: K,
    subjectId: number
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    const entity = getProjectedEntity(key);
    if (!entity) {
      throw new Error(`Entity with id ${String(key)} not found`);
    }

    const { beforeSubject, afterSubject } = getNeighborSubjects(key);
    const structuralEffect: PendingStructuralEffect = {
      kind: 'remove',
      subject: subjectId,
      key,
      value: deepClone(entity),
      beforeSubject,
      afterSubject,
    };
    const currentState = resolveSubjectState(subjectId);
    const tombstone: PreparedSubjectTombstone<K> = {
      kind: 'tombstone-subject',
      key,
      subjectId,
      restoreAllowed: currentState?.restoreAllowed ?? true,
    };

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const frame = createEntityMutationFrame();
        frame.stageSubjectTombstone(tombstone);
        const result = commitAndProjectEntityMutationFrame(frame, options);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        tombstoneSubjectSignal(subjectId);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          undefined,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...(metaOverride ?? ambientMeta() ?? {}),
            structuralEffect,
          }
        );

        emitTap('onRemove', key, entity);
      },
    };
  }

  function rewritePendingAddEffect(
    effect: PendingAddStructuralEffect,
    beforeSubject?: number,
    afterSubject?: number
  ): void {
    effect.beforeSubject = beforeSubject;
    effect.afterSubject = afterSubject;
  }

  function assertSynchronousInterceptorFunction(
    handler: unknown,
    hookName: string
  ): void {
    if (
      typeof handler === 'function' &&
      handler.constructor?.name === 'AsyncFunction'
    ) {
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. ` +
          `Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }

  function assertSynchronousInterceptorResult(
    result: void | Promise<void> | undefined,
    hookName: string
  ): void {
    if (result && typeof result.then === 'function') {
      void result.catch(() => undefined);
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. ` +
          `Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }

  function assertSynchronousInterceptors(
    handlers: InterceptHandlers<E, K>
  ): void {
    assertSynchronousInterceptorFunction(handlers.onAdd, 'onAdd');
    assertSynchronousInterceptorFunction(handlers.onUpdate, 'onUpdate');
    assertSynchronousInterceptorFunction(handlers.onRemove, 'onRemove');
  }

  function interceptAddedEntity(entity: E): E {
    // Already run for this call (a re-adding write, below).
    if (interceptsSuppressed) return entity;
    let transformedEntity = entity;
    for (const handler of interceptHandlers) {
      const ctx: InterceptContext<E> = {
        block: (reason?: string) => {
          throw new Error(
            `Cannot add entity: ${reason || 'blocked by interceptor'}`
          );
        },
        transform: (value: E) => {
          transformedEntity = value;
        },
        blocked: false,
        blockReason: undefined,
      };
      assertSynchronousInterceptorResult(handler.onAdd?.(entity, ctx), 'onAdd');
    }

    return transformedEntity;
  }

  /** `setAll`'s whole-row replacement interceptor (a transform replaces it). */
  function interceptReplacedEntity(id: K, entity: E): E {
    // Already run for this call (a re-adding write, below).
    if (interceptsSuppressed) return entity;
    let replacement = entity;
    for (const handler of interceptHandlers) {
      const ctx: InterceptContext<Partial<E>> = {
        block: (reason?: string) => {
          throw new Error(
            `Cannot replace entity: ${reason || 'blocked by interceptor'}`
          );
        },
        transform: (value: Partial<E>) => {
          replacement = value as E;
        },
        blocked: false,
        blockReason: undefined,
      };
      assertSynchronousInterceptorResult(
        handler.onUpdate?.(id, entity as Partial<E>, ctx),
        'onUpdate'
      );
    }
    return replacement;
  }

  function interceptUpdatedEntity(id: K, changes: Partial<E>): Partial<E> {
    // Already run for this call (a re-adding write, below).
    if (interceptsSuppressed) return changes;
    let transformedChanges = changes;
    for (const handler of interceptHandlers) {
      const ctx: InterceptContext<Partial<E>> = {
        block: (reason?: string) => {
          throw new Error(
            `Cannot update entity: ${reason || 'blocked by interceptor'}`
          );
        },
        transform: (value: Partial<E>) => {
          transformedChanges = value;
        },
        blocked: false,
        blockReason: undefined,
      };
      assertSynchronousInterceptorResult(
        handler.onUpdate?.(id, changes, ctx),
        'onUpdate'
      );
    }

    return transformedChanges;
  }

  /** Shared admission/install path; prepend finishes topology before delivery. */
  function addManyInOrder(
    entities: E[],
    opts?: AddManyOptions<E, K>,
    prepend = false
  ): K[] {
    const mode = opts?.mode ?? 'strict';
    const beforeSubjects =
      prepend && mutationCaptureRuntime?.publishCollectionOrder
        ? ([] as number[])
        : undefined;
    const beforeFrontier = beforeSubjects
      ? structuralStore.activeOrderFrontier()
      : undefined;
    if (beforeSubjects) structuralStore.snapshotActiveOrder([], beforeSubjects);
    // addMany appends: an added row's predecessor is the previous added row,
    // or for the first one the last row before the call. Only that key is
    // needed, not a copy of every key.
    const lastPreviousKey = structuralStore.lastActiveKey();

    // First pass: validate/filter based on mode. The rows apply as if one
    // at a time, so an earlier copy of an id in this call counts as
    // existing: strict throws (before anything is intercepted or written),
    // skip keeps the first copy, overwrite keeps the last in the first
    // copy's place. Two rows under one key was the result in every mode
    // before (v15 778f86ef and e02238f4, carried in v16 8f): prependMany
    // then linked the row to itself and the next read never ended.
    const toProcess: Array<{
      entity: E;
      id: K;
      existingSubjectId?: number;
    }> = [];
    // Every copy that applies, in input order.
    const copies: Array<[(typeof toProcess)[number], E]> = [];
    const earlier = new Map<K, (typeof toProcess)[number]>();
    for (const entity of entities) {
      const id = deriveId(entity, opts);
      const existingSubjectId = structuralStore.subjectIdForKey(id);
      let processed = earlier.get(id);
      if (existingSubjectId !== undefined || processed) {
        if (mode === 'strict') {
          throw new Error(`Entity with id ${String(id)} already exists`);
        } else if (mode === 'skip') {
          continue;
        }
        // 'overwrite': fall through — the projection helper below replaces the existing entry
      }
      if (!processed) {
        processed = { entity, id, existingSubjectId };
        earlier.set(id, processed);
        toProcess.push(processed);
      }
      copies.push([processed, entity]);
    }

    if (toProcess.length === 0) return [];

    // Interceptors run once per applied copy, in input order, as successive
    // single calls would; the last intercepted value wins. Staged before
    // mutating runtime state so a block cannot partially allocate fresh
    // subject lifetimes.
    for (const [processed, entity] of copies) {
      processed.entity = interceptAddedEntity(entity);
    }
    const stagedAdds = toProcess;
    const plannedFreshSubjectIds = structuralStore.planFreshSubjectIds(
      stagedAdds.filter(
        ({ existingSubjectId }) => existingSubjectId === undefined
      ).length
    );
    let plannedFreshIndex = 0;
    const preparedAdds = stagedAdds.map(
      ({ id, entity, existingSubjectId }) => ({
        id,
        entity,
        existingSubjectId,
        // A replacement retains its lifetime; capture what it replaces
        // before the physical frame installs the new value.
        prev:
          existingSubjectId === undefined
            ? undefined
            : valueStore.backingForSubject(existingSubjectId),
        subjectId:
          existingSubjectId ?? plannedFreshSubjectIds[plannedFreshIndex++],
      })
    );

    const frame = createEntityMutationFrame();
    for (const {
      id,
      entity: transformedEntity,
      existingSubjectId,
      subjectId,
    } of preparedAdds) {
      if (existingSubjectId === undefined) {
        frame.stageFreshSubject({
          kind: 'create-fresh-subject',
          key: id,
          subjectId,
          nextValue: transformedEntity,
        });
        continue;
      }

      frame.stageValueReplacement({
        kind: 'replace-value',
        key: id,
        subjectId: existingSubjectId,
        nextValue: transformedEntity,
      });
    }

    commitAndProjectEntityMutationFrame(frame);
    const subjectIdsByKey = new Map<K, number>();
    for (const { id, subjectId } of preparedAdds) {
      subjectIdsByKey.set(id, subjectId);
    }

    // Process all entities without triggering per-entity signal updates
    const processedIds: K[] = [];
    const addedEntities: Array<{ id: K; entity: E; subjectId: number }> = [];

    for (const { entity: transformedEntity, id } of preparedAdds) {
      const subjectId = subjectIdsByKey.get(id);
      if (subjectId === undefined) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      invalidateNodeCache(id);
      syncEntitySignal(id);
      processedIds.push(id);
      addedEntities.push({ id, entity: transformedEntity, subjectId });
    }

    // Finish the compound topology before path observers or taps can copy
    // metadata or flush history. No shared collector or later backpatching.
    if (prepend) moveToFront(processedIds);
    else updateSignals();
    if (beforeSubjects) {
      if (mutationCaptureRuntime?.isCaptureActive()) getPositionIds();
      const afterSubjects: number[] = [];
      structuralStore.snapshotActiveOrder([], afterSubjects);
      if (survivingOrderChanged(beforeSubjects, afterSubjects)) {
        publishOrderChange(beforeSubjects, afterSubjects, beforeFrontier);
      }
    }

    const subjectIdsForWrite = processedIds.map((id) => {
      const subjectId = subjectIdsByKey.get(id);
      if (subjectId === undefined) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      return subjectId;
    });
    lastSubjectIds = subjectIdsForWrite;

    // Notify PathNotifier for each processed entity.
    //
    // Reproduced on 15.3.1: indexing the pre-add key list at
    // `i + previous - added` anchored [x, y] after k4 and k5 instead of after
    // k5 and x, so redo reinserted them out of order. A fresh row's
    // predecessor is the previous FRESH row of this call, else the last row
    // before it: an 'overwrite' replacement stays where it was, so it is not
    // an anchor for the rows appended after it (v16 refinement of 7463f4eb,
    // which anchored to the previous processed row).
    let previousAppendedSubject =
      lastPreviousKey === undefined
        ? undefined
        : allocateSubjectId(lastPreviousKey);
    for (let i = 0; i < addedEntities.length; i++) {
      const { id, entity } = addedEntities[i];
      const beforeSubject = previousAppendedSubject;
      if (preparedAdds[i].existingSubjectId === undefined) {
        previousAppendedSubject = subjectIdsForWrite[i];
      }
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        entity,
        preparedAdds[i].prev,
        basePath,
        [subjectIdsForWrite[i]],
        getPositionIdsForNotify(),
        preparedAdds[i].existingSubjectId === undefined
          ? createStructuralEffectMeta({
              kind: 'add',
              subject: subjectIdsForWrite[i],
              key: id,
              value: deepClone(entity),
              ...(prepend ? getNeighborSubjects(id) : { beforeSubject }),
            })
          : ambientMeta()
      );
    }

    // Run tap handlers for each processed entity
    for (const { id, entity } of addedEntities) {
      emitTap('onAdd', entity, id);
    }

    return processedIds;
  }

  function addOneWithStructuralEffect(
    entity: E,
    opts?: AddOptions<E, K>
  ): { id: K; structuralEffect: PendingAddStructuralEffect } {
    const id = deriveId(entity, opts);
    const previousLastKey = structuralStore.lastActiveKey();
    recordProductionSubstrateStat('publicAddPreviousTailReads');

    if (structuralStore.hasActiveKey(id)) {
      throw new Error(`Entity with id ${String(id)} already exists`);
    }

    const transformedEntity = interceptAddedEntity(entity);
    const subjectId = structuralStore.planFreshSubjectIds(1)[0];
    if (subjectId === undefined) {
      throw new Error(
        `Fresh subject planning for ${String(id)} did not produce an id.`
      );
    }

    const frame = createEntityMutationFrame();
    const freshSubject: PreparedFreshSubject<K, E> = {
      kind: 'create-fresh-subject',
      key: id,
      subjectId,
      nextValue: transformedEntity,
    };
    frame.stageFreshSubject(freshSubject);
    commitAndProjectEntityMutationFrame(frame);
    const structuralEffect: PendingAddStructuralEffect = {
      kind: 'add',
      subject: subjectId,
      key: id,
      value: deepClone(transformedEntity),
      beforeSubject:
        previousLastKey === undefined
          ? undefined
          : allocateSubjectId(previousLastKey),
    };
    lastSubjectIds = [subjectId];
    invalidateNodeCache(id);
    syncEntitySignal(id);
    updateSignals();

    pathNotifier.notify(
      `${basePath}.${String(id)}`,
      transformedEntity,
      undefined,
      basePath,
      [subjectId],
      getPositionIdsForNotify(),
      createStructuralEffectMeta(structuralEffect)
    );

    emitTap('onAdd', transformedEntity, id);

    return { id, structuralEffect };
  }

  /**
   * Sync one entity's signal from storage after a mutation. No-op if the
   * entity was never materialized (nothing is observing it yet), keeping
   * single-entity writes O(1) regardless of collection size.
   */
  function syncEntitySignal(id: K): void {
    const subjectId = resolveSubjectId(id);
    if (subjectId === undefined) {
      return;
    }

    stageSubjectEpoch(subjectId);
  }

  /**
   * Release one subject's entity signal on removal: notify current observers
   * that the entity is gone (set undefined). The signal itself is kept keyed by
   * SubjectId so held field references stay valid (they read undefined) and a
   * restore of the same subject re-publishes through the same signal.
   */
  function tombstoneSubjectSignal(subjectId: number): void {
    stageSubjectEpoch(subjectId);
  }

  // TOMBSTONE: `resetEntitySignals()` — a bulk `forEach(set(undefined))` +
  // `clear()` of the signal map, once called by `clear()`. It is gone because
  // dropping the MAP ENTRY is what made `clear()` un-undoable: a held reference
  // reads through the signal it was given, and a restore into a fresh signal is
  // a different subject wearing the same key. `clear()` now tombstones
  // per-subject exactly as `removeOne` does. Do not reintroduce a bulk reset as
  // a memory optimization — reclamation at the retirement boundary already
  // sheds zero-owner entries, and it sheds only the ones nothing can restore.

  /**
   * Cache for entity nodes (deep access proxies), held WEAKLY.
   *
   * `byId()` materialises a per-entity node so that row can be bound and
   * written independently — the whole point of granular reactivity. It used to
   * be a strong `Map`, which meant READING permanently allocated: entries were
   * removed on mutation or removal, but nothing bounded growth from reads.
   *
   * Measured at 10,000 entities: 315 B/entity for the collection, and
   * **4,149 B/entity once `byId()` has been called on every row** — 3.0 MB
   * against 39.6 MB, 46x the data. That is the documented pattern for granular
   * updates, so the recommended usage was the expensive one, and on a low-end
   * device it is the shape that runs a list out of memory.
   *
   * A node should live exactly as long as someone holds it. A `WeakRef` gives
   * that: a node no component retains becomes collectable, and a node nobody
   * holds cannot observe its own identity changing, so the next `byId()` simply
   * builds a fresh one. The `FinalizationRegistry` sweeps the dead map entry so
   * the Map itself does not grow with empty refs.
   *
   * ⚠️ A HELD reference must still survive churn — see
   * entity-granular-reactivity.spec.ts, which pins that a node held across
   * remove -> re-add keeps working. Weakness must not weaken THAT: while a
   * caller holds the node, the WeakRef cannot be cleared, so the existing
   * behaviour is unchanged for every reference anyone can actually observe.
   */
  const nodeCache = new Map<number, WeakRef<EntityNode<E>>>();
  const nodeFinalizer =
    typeof FinalizationRegistry === 'function'
      ? new FinalizationRegistry<number>((subjectId) => {
          // Only drop the slot if it is still the dead ref — a later byId()
          // may already have installed a live replacement.
          if (nodeCache.get(subjectId)?.deref() === undefined) {
            nodeCache.delete(subjectId);
          }
        })
      : null;

  function invalidateNodeCache(id: K): void {
    const subjectId = resolveSubjectId(id);
    if (subjectId !== undefined) {
      nodeCache.delete(subjectId);
    }
  }

  /** Cached `empty` computed — created on first access. */
  let cachedEmpty: ReadableCell<boolean> | null = null;

  /** Function to extract key from entity */
  const selectId: (entity: E) => K =
    config.selectId ??
    ((entity: E) => (entity as unknown as Record<string, K>)['id']);

  // Dev-mode guard state: warn once if entities resolve to a null/undefined id.
  let warnedMissingId = false;

  /**
   * Resolve an entity's id (per-call selectId override → config selectId →
   * default `.id`). Dev-mode guardrail: a null/undefined id means the entity
   * has no `id` field and no `selectId` was provided, so every such entity
   * collides under one key — a common mistake (especially in AI-generated
   * code). Warn once with an actionable fix.
   */
  function deriveId(entity: E, opts?: { selectId?: (e: E) => K }): K {
    const id = opts?.selectId?.(entity) ?? selectId(entity);
    if (
      id == null &&
      (typeof ngDevMode === 'undefined' || ngDevMode) &&
      !warnedMissingId
    ) {
      warnedMissingId = true;
      console.warn(
        `SignalTree entityMap${
          basePath ? ` at "${basePath}"` : ''
        }: an entity ` +
          `resolved to id=${String(
            id
          )}. Entities need a stable key — give them ` +
          `an \`id\` field or pass entityMap({ selectId: (e) => e.yourKey }). ` +
          `Without it, entities collide under a single key. [ST2001]`
      );
    }
    return id;
  }

  /** Handlers for observation */
  const tapHandlers: TapHandlers<E, K>[] = [];
  /**
   * Run every tap's `method`. A tap reads collections as any consumer does:
   * absent-aware, even while a reversal is applied to their tree and its own
   * row writes read hidden rows physically (`taps`, v16 8f).
   */
  const emitTap = <M extends keyof TapHandlers<E, K>>(
    method: M,
    ...args: Parameters<NonNullable<TapHandlers<E, K>[M]>>
  ): void => {
    // A re-adding write re-adds its path before anyone hears of its rows: a
    // tap reads the collection present, as on an empty one (v16 8f review).
    if (pendingReAdd) {
      pendingReAdd = false;
      reactivatePathOnWrite(api);
    }
    // A tap's own writes are ordinary writes: interceptors run for them, even
    // inside a re-adding write that already ran its own (v16 8f review).
    const suppressed = interceptsSuppressed;
    const nested = reAdding;
    interceptsSuppressed = 0;
    reAdding = false;
    taps.depth++;
    try {
      for (const handler of tapHandlers)
        (handler[method] as ((...input: unknown[]) => void) | undefined)?.(
          ...args
        );
    } finally {
      taps.depth--;
      interceptsSuppressed = suppressed;
      reAdding = nested;
    }
  };
  /** A re-adding write already ran this call's interceptors (v16 8f). */
  let interceptsSuppressed = 0;
  /** A re-adding write is running on this collection (v16 8f). */
  let reAdding = false;
  /** It has written its rows and not yet re-added its path. */
  let pendingReAdd = false;
  /** A re-adding write's removal of retained rows: no tap sees it (v16 8e). */
  let silentClear = 0;

  /** Handlers for blocking/transforming */
  const interceptHandlers: InterceptHandlers<E, K>[] = [];

  // ==================
  // INTERNAL HELPERS
  // ==================

  /** Mark the collection dirty. O(1) — see the `version` docs above. */
  function updateSignals(): void {
    const pending = [...pendingSubjectEpochs];
    pendingSubjectEpochs.clear();
    // An absent collection reads empty before and after: nothing a consumer
    // reads changed. Its membership hook wakes them when it comes back, so a
    // reversal writing its hidden rows re-runs nobody while those rows are
    // read physically (v16 8e).
    if (absent()) return;
    locations.runInvalidationGroup(() => {
      for (const epoch of pending) {
        advanceEpochHandle(epoch);
      }
      deriveLocation(version, (value) => value + 1);
      markOwnerInvalidated(ownerId);
    });
  }

  function createEntityNode(
    subjectId: number,
    initialKey: K,
    entity: E
  ): EntityNode<E> {
    // Entity-level callable:
    //   node()           → reads current entity (reactive via mapSignal)
    //   node(value)      → full entity REPLACE (throws if entity removed)
    //   node(updater)    → replace with the updater's return (throws if removed)
    //
    // These replace, and they always claimed to. Until 14.1.1 they delegated to
    // `updateOne`, which spreads (`{ ...entity, ...changes }`) — so the docs said
    // replace and the code merged. The updater form was the worse half: the
    // updater returns a full `E`, it was spread as `Partial<E>`, so an updater
    // that REMOVED a key left the old value in place and nothing said so.
    //
    // Fixed by changing the CODE, not the comment, and the updater form is why
    // there was no other choice: an updater returns a full `E`, so under merge
    // semantics it is IMPOSSIBLE to express removing a key — the spread puts the
    // old value straight back. Merge cannot host this signature. Either the
    // callable replaces or the updater form has to be deleted.
    //
    // Not `setOne(entity)`: that would derive the key via `selectId(entity)`, and
    // `changeId` can leave `entity.id` disagreeing with the storage key, so it has
    // a silent wrong-slot write built in. The explicit form is `replaceOne(id, next)`,
    // which is public and is what this delegates to.
    //
    // MERGE is still available and still positional: `updateOne(id, changes)` for
    // a patch, or `byId(id).field.set(v)` for one field.
    // Resolve the per-entity signal on EVERY read rather than capturing it
    // once. Capturing it made a held node reference permanently dead across a
    // remove -> re-add of the same id: `removeEntitySignal` deletes the signal
    // from the map, the re-add creates a NEW one, and the captured reference
    // kept reading the orphaned signal — `undefined` forever, while a fresh
    // `byId()` worked. Holding a reference to a nested position is the
    // capability this library has and its competitors do not, so it must
    // survive the collection churning underneath it.
    //
    // Subject reachability is now independent from subject retention. A
    // removed subject becomes structurally unreachable by clearing its active
    // key binding, while the retained subject id, signal, and cached node can
    // survive until a separate restoration or reclamation decision.
    const handle = acquireEntityHandleForTesting(initialKey);
    if (handle === undefined || handle.subjectId !== subjectId) {
      throw new Error(
        `Entity with id ${String(initialKey)} has no acquired subject handle`
      );
    }

    // `SUBJECT-STATE-SEMANTIC-0`. The registry is weak, so THIS closure is what
    // keeps the activation carrier alive: while a caller holds this node, its
    // carrier cannot be collected out from under a pending bump. Captured on
    // first read rather than at node creation, so `byId` alone still realizes
    // nothing.
    let activationCarrier: Location<number> | undefined;
    const currentKey = (): K | undefined => {
      (activationCarrier ??= getSubjectStateSignal(subjectId))();
      const resolved = structuralStore.resolveSubjectHandle(handle);
      return resolved.state === 'active' ? resolved.key : undefined;
    };

    const entitySig = () => {
      const key = currentKey();
      return key === undefined ? undefined : readEntityByKey(key);
    };

    const node = ((valueOrUpdater?: E | ((current: E) => E)): E | undefined => {
      if (valueOrUpdater === undefined) {
        return entitySig();
      }
      const key = currentKey();
      if (key === undefined) {
        throw new Error(`Entity with subject ${String(subjectId)} not found`);
      }
      const current = presentEntity(key);
      if (current === undefined) {
        throw new Error(`Entity with id ${String(key)} not found`);
      }
      const next =
        typeof valueOrUpdater === 'function'
          ? (valueOrUpdater as (c: E) => E)(current)
          : (valueOrUpdater as E);
      withCallableWriteIntent(
        typeof valueOrUpdater === 'function' ? 'derive' : 'replace',
        () => api.replaceOne(key, next)
      );
      return undefined;
    }) as unknown as EntityNode<E>;

    // A retained row/field belongs to a lifetime, not its mutable storage key.
    // Carry only identities; binding metadata must not retain retired values.
    const registry = getPositionRegistry(api);
    const owner = registry ? getPositionIds()?.[0] : undefined;
    const bindLocation = (location: object, fieldKey?: string): void => {
      if (!registry || owner === undefined) return;
      definePositionRegistry(location, registry);
      defineEntityLocationBinding(location, { owner, subjectId, fieldKey });
      if (mutationCaptureRuntime) {
        Object.defineProperty(location, MUTATION_CAPTURE_RUNTIME, {
          value: mutationCaptureRuntime,
        });
      }
    };
    bindLocation(node);

    // Field projections derive their read from the subject-owned entity location.
    // Writes delegate to api.updateOne so interceptors and tap handlers still run.
    for (const key of Object.keys(entity)) {
      const fieldKey = key as keyof E;
      const computeField = () => {
        const current = entitySig();
        return current &&
          Object.prototype.hasOwnProperty.call(current, fieldKey)
          ? current[fieldKey]
          : undefined;
      };
      const writeField = (
        value: E[typeof fieldKey] | undefined,
        intent: 'replace' | 'derive'
      ) => {
        const key = currentKey();
        if (key === undefined) {
          throw new Error(`Entity with subject ${String(subjectId)} not found`);
        }
        withCallableWriteIntent(intent, () =>
          api.updateOne(key, { [fieldKey]: value } as Partial<E>)
        );
      };
      const fieldSignal = locations.createWritableProjection
        ? locations.createWritableProjection(computeField, writeField)
        : createWritableProjection(
            locations.createDerived(computeField),
            writeField
          );
      bindLocation(fieldSignal, key);

      if (ownerMetadataEnabled) {
        Object.defineProperty(fieldSignal, '__ownerPath', {
          get: () => {
            const key = currentKey();
            return key === undefined ? undefined : `${basePath}.${String(key)}`;
          },
          enumerable: false,
          configurable: true,
        });
      }
      if (subjectMetadataEnabled) {
        Object.defineProperty(fieldSignal, '__subjectIds', {
          get: () => [subjectId],
          enumerable: false,
          configurable: true,
        });
      }
      if (positionMetadataEnabled) {
        Object.defineProperty(fieldSignal, '__positionIds', {
          get: getPositionIds,
          enumerable: false,
          configurable: true,
        });
      }

      Object.defineProperty(node, key, {
        get: () => fieldSignal,
        enumerable: true,
        configurable: true,
      });
    }

    return node;
  }

  function getOrCreateNode(id: K, entity: E): EntityNode<E> {
    const subjectId = resolveSubjectId(id);
    if (subjectId === undefined) {
      throw new Error(`Entity with id ${String(id)} has no subject id`);
    }

    let node = nodeCache.get(subjectId)?.deref();
    if (!node) {
      node = createEntityNode(subjectId, id, entity);
      nodeCache.set(subjectId, new WeakRef(node));
      nodeFinalizer?.register(node, subjectId);
    }
    return node;
  }

  function inspectSubjectResources(
    subjectId: number
  ): EntitySubjectPhysicalInventory<K> | undefined {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState) {
      return undefined;
    }

    const node = nodeCache.get(subjectId)?.deref();
    const fieldFacadesMaterialized =
      node === undefined
        ? []
        : Object.keys(node as Record<string, unknown>)
            .filter(
              (key) =>
                typeof (node as Record<string, unknown>)[key] === 'function'
            )
            .sort((left, right) => left.localeCompare(right));

    return {
      subjectId,
      state: subjectState.active ? 'active' : 'tombstoned',
      subjectRevision: getSubjectRevision(subjectId),
      activeKey: subjectState.active ? subjectState.key : undefined,
      retainedSubjectState: structuralStore.hasSubject(subjectId),
      entitySignal: subjectEpochs.has(subjectId),
      activationToken:
        subjectStateSignals.get(subjectId)?.deref() !== undefined,
      nodeFacadeMaterialized: node !== undefined,
      fieldFacadesMaterialized,
      positionIds: getPositionIds(),
      retainedValueBacking: valueStore.hasRetainedValueBacking(subjectId)
        ? { kind: 'retained-entity-signal' }
        : undefined,
    };
  }

  function listSubjectReclamationCandidates(): readonly number[] {
    return structuralStore
      .tombstonedSubjectsSnapshot()
      .filter((subjectId) => valueStore.hasRetainedValueBacking(subjectId));
  }

  function prepareSubjectReclamation(
    subjectId: number,
    options: EntitySubjectReclamationPlanningOptions
  ): PreparedEntitySubjectReclamation | undefined {
    const inventory = inspectSubjectResources(subjectId);
    if (!inventory) {
      return undefined;
    }

    const plan = planEntitySubjectReclamation(inventory, options);
    if (!plan.eligible) {
      return undefined;
    }

    return {
      subjectId,
      expectedLifetime: 'tombstoned',
      expectedSubjectRevision: inventory.subjectRevision,
      retire: plan.retire,
      retain: plan.retain,
    };
  }

  function applyPreparedSubjectReclamation(
    prepared: PreparedEntitySubjectReclamation
  ): void {
    const state = resolveSubjectState(prepared.subjectId);
    if (prepared.expectedLifetime !== 'tombstoned') {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} has an unsupported expected lifetime.`
      );
    }
    if (!state) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }
    if (
      getSubjectRevision(prepared.subjectId) !==
      prepared.expectedSubjectRevision
    ) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} is stale.`
      );
    }
    if (state.active) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }

    const frame = createEntityMutationFrame();
    const forgetLifetime = prepared.retire.includes('subject-lifetime-record');
    const retiresValue = prepared.retire.includes('retained-value-backing');
    if (forgetLifetime || retiresValue) {
      // ONE mutation covers both: `retire-retained-value` deletes the value and
      // then either `retireSubject` (keep a `{active:false,
      // restoreAllowed:false}` record) or `forgetSubject` (drop it entirely).
      // Staging it even when there is no value left is what lets a subject
      // whose bytes went earlier still lose its ledger entry.
      const retirement: PreparedRetainedValueRetirement = {
        kind: 'retire-retained-value',
        subjectId: prepared.subjectId,
        forgetLifetime,
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(prepared.subjectId);
    }

    const result = commitAndProjectEntityMutationFrame(frame);
    for (const changedSubjectId of result.physicallyChangedSubjectIds) {
      if (forgetLifetime && changedSubjectId === prepared.subjectId) {
        // NO PUBLISH for a forgotten subject, and this is load-bearing rather
        // than an optimization. `publishSubjectPhysicalChange` ->
        // `bumpSubjectRevision` does `subjectRevisions.set(id, ...)`, which
        // RE-INTERNS the entry `forgetSubject` just deleted. Deleting from a
        // Map does not stay deleted if a later step in the same operation
        // interns by the same key.
        //
        // `reclaimRetiredSubjectsWithoutOwner` documents this as the 79 B
        // versus 6 B measurement, and the sink reintroduced it here: with the
        // publish in place `subjectRevisions` grew to one entry per subject
        // ever created — 64,200 at 320 rounds while every other structure sat
        // at 4,200 — and it was the whole remaining retention slope.
        //
        // Nothing is left to notify either: the entity signal was deleted
        // above, and the activation channel is interned lazily, so a subject
        // nobody read has none.
        continue;
      }
      publishSubjectPhysicalChange(changedSubjectId);
    }
  }

  /**
   * ZERO-OWNER RECLAMATION — the only reclamation that runs automatically.
   *
   * When the tree has no restoration authority, a tombstoned subject's retained
   * value backing is unreachable: nothing can undo, roll back, or re-project it,
   * so the bytes are held against a restore that cannot be requested. This
   * releases them at the moment of retirement.
   *
   * ## Why this needs no causal assessment
   *
   * `runPhysicalMaintenance` exists for the hard case and asks a real question —
   * is any turn, pending turn, applied-restoration history entry or redo entry still
   * referencing this subject? Answering it requires a `TurnStore` and an
   * `AppliedTurnProjection`, which a tree without `causal-runtime` does not have. That
   * absence is not a gap to work around; it IS the answer. With no owner there
   * are no turns, so there is nothing a turn could be holding.
   *
   * This is therefore NOT a bypass of the coordinator, and must not grow into
   * one. The moment a tree has restoration authority this function returns
   * immediately, and reclaiming there stays the coordinator's problem — it needs
   * history-aware eligibility, which is a separate piece of work.
   *
   * ## What it reclaims: EVERYTHING physical, the lifetime ledger included
   *
   * The value backing, the entity signal, the subject lifetime record and the
   * revision entry. Retention is 6 B per retired subject, down from 249 B before
   * any reclamation and 117 B when the ledger was kept — and it no longer grows
   * with the number of retirements at all.
   *
   * Keeping the ledger was believed to be what stale-handle isolation rested on.
   * It is not, and that was FALSIFIED rather than assumed: every semantic gate,
   * including the four GC-dependent properties in
   * `check-signal-identity-durability.mjs`, passes with it deleted.
   *
   * Isolation is anchored in SUBJECT identity, not key identity. `nextSubjectId`
   * only increases and `tombstoneSubject` already removed the key -> subject
   * mapping, so a re-add of the same business key is a different subject by
   * construction. A held reference keeps reading `undefined` because the
   * CONSUMER holds the orphaned signal and, with the map entry gone, nothing can
   * ever write to it again.
   *
   * The price, both on internal surfaces: `resolveSubjectHandle` reports
   * `missing` rather than `tombstoned` for a forgotten subject, and the subject
   * leaves `__listSubjectReclamationCandidates` — correct, since it has nothing
   * left to reclaim. `entity-lifetime-ledger-null.spec.ts` pins both.
   *
   * ⚠️ `planRestore`'s "has retired backing and cannot be restored" guard loses
   * its input for a forgotten subject. Acceptable ONLY because a tree with no
   * restoration authority has no reachable restore at all, so the guard becomes
   * unreachable rather than unenforced. If a restorer can exist, none of this
   * runs.
   *
   * See docs/architecture/retired-subject-churn.md and
   * docs/architecture/restoration-ownership-inventory.md.
   */
  function reclaimRetiredSubjectsWithoutOwner(
    subjectIds: readonly number[]
  ): void {
    if (hasRestorationAuthority || subjectIds.length === 0) {
      return;
    }

    const frame = createEntityMutationFrame();
    let staged = 0;
    for (const subjectId of subjectIds) {
      const state = resolveSubjectState(subjectId);
      // Still active means this was not a retirement after all. A missing state
      // means the subject is already gone. Neither is reclaimable.
      if (!state || state.active) {
        continue;
      }
      if (!valueStore.hasRetainedValueBacking(subjectId)) {
        continue;
      }
      const retirement: PreparedRetainedValueRetirement = {
        kind: 'retire-retained-value',
        subjectId,
        forgetLifetime: true,
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(subjectId);
      staged += 1;
    }

    if (staged === 0) {
      return;
    }

    commitAndProjectEntityMutationFrame(frame);

    // DELIBERATELY NO PUBLISH, and this is load-bearing rather than an omission.
    // `publishSubjectPhysicalChange` -> `bumpSubjectRevision` writes
    // `subjectRevisions.set(id, 1)`, which RESURRECTS the entry the forget just
    // deleted — measured at 79 B/retired instead of 6 B until it was found.
    // Deleting from a Map does not stay deleted if a later step in the same
    // operation interns by the same key.
    //
    // There is also nothing left to notify: the entity signal was deleted in the
    // loop above, and the activation token is interned lazily, so a subject
    // nobody read has none.
  }

  function retireSubjectRetainedValueBackingForTesting(
    subjectId: number
  ): void {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState || subjectState.active) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} must be tombstoned before retiring retained value backing.`
      );
    }

    valueStore.retireSubjectValue(subjectId);
    subjectEpochs.delete(subjectId);
  }

  // ==================
  // API OBJECT
  // ==================

  // Caches for predicate-based queries. Uses WeakMap keyed by function
  // reference so callers that pass the same function object will receive the
  // same computed Signal instance (reduces redundant computed creation).
  // NOTE: This only works reliably when callers pass stable, named
  // predicate references. Inline anonymous predicates will not be cached.
  const whereCache: WeakMap<
    (entity: E) => boolean,
    ReadableCell<E[]>
  > = new WeakMap();
  const findCache: WeakMap<
    (entity: E) => boolean,
    ReadableCell<E | undefined>
  > = new WeakMap();

  const api = {
    // ==================
    // EXPLICIT ACCESS
    // ==================

    byId(id: K): EntityNode<E> | undefined {
      if (!rowAbsent() && structuralStore.hasActiveKey(id)) {
        // Present: subscribe to the PER-ENTITY signal only, so callers re-run
        // when THIS entity changes but not when others do (body-granular).
        // Materialized lazily here — bounded by the number of live entities.
        const entity = readEntityByKey(id);
        return entity ? getOrCreateNode(id, entity) : undefined;
      }
      // Absent: subscribe to the shared ids signal for "appears later"
      // reactivity WITHOUT materializing a permanent per-entity signal for an
      // id that may never exist (which would leak one signal per probed id).
      idsSignal();
      return undefined;
    },

    byIdOrFail(id: K): EntityNode<E> {
      const node = api.byId(id);
      if (!node) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      return node;
    },

    // ==================
    // QUERIES (return Signals)
    // ==================

    get all(): ReadableCell<E[]> {
      return inTap(allSignal, computeAll);
    },

    get count(): ReadableCell<number> {
      return inTap(countSignal, computeCount);
    },

    get ids(): ReadableCell<K[]> {
      return inTap(idsSignal, () => computeIds(computeAll));
    },

    /**
     * The collection as a `ReadonlyMap`, keyed by id.
     *
     * Named `asMap` since 14.1.1. It was `map`, which read as a PROJECTION beside
     * `all()` — every JS developer expects `.map(fn)` to transform elements, and an
     * agent or newcomer reaching for that is a documented failure class (see
     * `WRONG_ENTITY_METHODS`). `asMap` says what it returns.
     */
    get asMap(): ReadableCell<ReadonlyMap<K, E>> {
      return inTap(mapSignal, computeMap);
    },

    // ── Active entity ───────────────────────────────────────────────────────
    get activeId(): ReadableCell<K | undefined> {
      return activeIdSignal.asReadonly();
    },

    /**
     * Resolved through the per-entity signal, NOT through `mapSignal`.
     *
     * That is the whole reason to build this here rather than leave it to the
     * app: a hand-rolled `getDerivedRuntime().createDerived(() => all().find(e => id(e) === activeId()))`
     * depends on the entire collection, so it recomputes when ANY row changes.
     * This depends on the active row's own signal, so it recomputes only when
     * that row changes — which is what `byId` exists for.
     */
    get activeEntity(): ReadableCell<E | undefined> {
      const read = () => {
        const id = activeIdSignal();
        if (id === undefined) return undefined;
        // A selection names a key even while no subject occupies it. Keep the
        // membership edge only while absent; a present selection stays scoped
        // to its subject, and dependency cleanup drops the old edge on reentry.
        if (resolveSubjectId(id) === undefined) idsSignal();
        return readEntityByKey(id);
      };
      if (taps.depth) return fresh(read);
      return (cachedActiveEntity ??= locations.createDerived(read));
    },

    setActiveId(id: K | undefined): void {
      // Not an error when the id is absent: selection frequently outlives the
      // row (a delete arriving from a socket while a detail pane is open), and
      // `activeEntity` already resolves to undefined in that case.
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, id);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },

    clearActiveId(): void {
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, undefined);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },

    has(id: K): ReadableCell<boolean> {
      const read = () => !absent() && structuralStore.hasActiveKey(id);
      return taps.depth ? fresh(read) : createVersionedProjection(read);
    },

    // Bare canonical name (the `.isEmpty` alias was removed in v11).
    get empty(): ReadableCell<boolean> {
      if (taps.depth) return fresh(() => computeCount() === 0);
      return (cachedEmpty ??= locations.createDerived(
        () => countSignal() === 0
      ));
    },

    where(predicate: (entity: E) => boolean): ReadableCell<E[]> {
      if (taps.depth) return fresh(() => computeAll().filter(predicate));
      const cached = whereCache.get(predicate);
      if (cached) return cached;

      if (typeof ngDevMode === 'undefined' || ngDevMode) {
        warnOnPredicateChurn('where', predicate);
      }
      // Filter DURING iteration rather than materialising `all` and discarding
      // most of it. `allSignal()` builds an array of every entity; `.filter()`
      // then walks it again and keeps a few. Iterating `storage.values()`
      // straight into the result array skips the intermediate entirely.
      //
      // MEASURED in situ, one process per arm, updateOne baseline subtracted.
      // Ranges because the spread across runs is wide — quote the shape, not a
      // point figure:
      //     N=100      1.2us -> 1.3us   (neutral; not worth it at this size)
      //     N=1,000    6.9us -> 2.6us
      //     N=10,000  67-73us -> 24-47us
      //     N=100,000  826us -> 328us
      // So roughly 2-3x from N=1,000 up, and nothing below a few hundred.
      //
      // ⚠️ Measured on a machine running other work. Alternating order
      // (after/before/after) held the ordering and the two `after` runs
      // agreed, so the DIRECTION is sound and the ranges do not overlap —
      // but treat the magnitudes as indicative and re-measure quiet before
      // publishing any of them.
      //
      // Only valid WITHOUT `sortComparer`. With one, `allSignal()` sorts, so
      // bypassing it would silently return insertion order instead of sorted
      // order — a behaviour change, not an optimisation. Without one,
      // `allSignal()` is `Array.from(storage.values())`, so the fast path is
      // order-IDENTICAL rather than merely order-equivalent.
      //
      // `version()` is read directly for the same invalidation `allSignal()`
      // has; the sorted branch gets it transitively.
      const s = createVersionedProjection(() => {
        if (config.sortComparer) return allSignal().filter(predicate);
        const out: E[] = [];
        for (const entity of presentEntities()) {
          if (predicate(entity)) out.push(entity);
        }
        return out;
      });
      whereCache.set(predicate, s);
      return s;
    },

    find(predicate: (entity: E) => boolean): ReadableCell<E | undefined> {
      if (taps.depth) return fresh(() => computeAll().find(predicate));
      const cached = findCache.get(predicate);
      if (cached) return cached;

      if (typeof ngDevMode === 'undefined' || ngDevMode) {
        warnOnPredicateChurn('find', predicate);
      }
      // Same bypass as `where`, and the win here is algorithmic rather than a
      // constant factor: `allSignal().find()` builds the WHOLE array before
      // looking at the first element, so a match at index 5 of 10,000 still
      // costs O(N). Iterating stops at the match.
      //
      // MEASURED in situ at 10k, updateOne baseline subtracted:
      //     match at the END    52-61us -> 12-20us   (~3-5x)
      //     match at index 5      13.6us -> 0.2us    (~50x)
      // The second is the point: `find` goes from O(N) ALWAYS to O(position).
      // The first is the same intermediate-array saving as `where`.
      //
      // Sorted collections keep the old path: `find` returns the FIRST match,
      // which is order-dependent, so with a `sortComparer` the sorted array is
      // the only correct thing to scan. See the note on `where` above.
      const s = createVersionedProjection(() => {
        if (config.sortComparer) return allSignal().find(predicate);
        for (const entity of presentEntities()) {
          if (predicate(entity)) return entity;
        }
        return undefined;
      });
      findCache.set(predicate, s);
      return s;
    },

    // ==================
    // MUTATIONS: ADD
    // ==================

    addOne(entity: E, opts?: AddOptions<E, K>): K {
      return addOneWithStructuralEffect(entity, opts).id;
    },

    /**
     * Insert at the FRONT, reusing `addOne` and then moving the entry.
     *
        if (structuralStore.hasActiveKey(id)) {
     * so the entry order is rebuilt — O(n) in the number of entities. That is
     * still markedly cheaper than the `setAll([entity, ...existing])` this
     * replaces, which rebuilds the storage map AND resets every per-entity
     * signal: only the newcomer's signal changes here, so held nodes survive and
     * no unrelated row's consumers are invalidated.
     *
     * Reusing `addOne` rather than duplicating it keeps duplicate-detection,
     * interceptors, notifier and tap handlers on exactly one path.
     */
    prependOne(entity: E, opts?: AddOptions<E, K>): K {
      // One membership event for add + move: readers never see the row at
      // the end of the list first.
      return withMembershipGroup(() => {
        const previousFirstKey = structuralStore.firstActiveKey();
        const { id, structuralEffect } = addOneWithStructuralEffect(
          entity,
          opts
        );
        moveToFront([id]);
        rewritePendingAddEffect(
          structuralEffect,
          undefined,
          previousFirstKey === undefined
            ? undefined
            : allocateSubjectId(previousFirstKey)
        );
        return id;
      });
    },

    prependMany(entities: E[], opts?: AddManyOptions<E, K>): K[] {
      return withMembershipGroup(() => addManyInOrder(entities, opts, true));
    },

    /**
     * Change an entity's id in place — the missing half of optimistic creation.
     *
     * Insert with a temp id, then adopt the id the server assigned. Everything
     * keyed by the old id moves together: storage (keeping list position), the
     * per-entity signal, the node cache, and the active-entity selection.
     *
     * Held row/field references follow the rekey by SUBJECT identity rather than
     * by the old key. The old lookup disappears, but already-materialized row
     * state, metadata, and field signals remain attached to the same subject.
     * That keeps list position, active selection, and row-local reactivity while
     * still allowing the freed id to be reused by a different subject.
     */
    changeId(from: K, to: K): void {
      // An absent collection has no row to rekey (v16 8e).
      if (rowAbsent())
        throw new Error(`Entity with id ${String(from)} not found`);
      const planned = planRekey(from, to);
      planned.commit();
      planned.publish();
    },

    addMany(entities: E[], opts?: AddManyOptions<E, K>): K[] {
      return addManyInOrder(entities, opts);
    },

    // ==================
    // MUTATIONS: UPDATE
    // ==================

    updateOne(id: K, changes: Partial<E>): void {
      const callableIntent = consumeCallableWriteIntent();
      const entity = presentEntity(id);
      if (!entity) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }

      const prev = entity;

      // Run interceptors
      let transformedChanges = changes;
      for (const handler of interceptHandlers) {
        const ctx: InterceptContext<Partial<E>> = {
          block: (reason?: string) => {
            throw new Error(
              `Cannot update entity: ${reason || 'blocked by interceptor'}`
            );
          },
          transform: (value: Partial<E>) => {
            transformedChanges = value;
          },
          blocked: false,
          blockReason: undefined,
        };
        assertSynchronousInterceptorResult(
          handler.onUpdate?.(id, changes, ctx),
          'onUpdate'
        );
      }

      const finalUpdated = { ...entity, ...transformedChanges };
      // One value replacement, no structural consequence — commit it directly.
      // See `commitExistingSubjectValue` for why this is the whole case.
      const subjectIdForWrite = rememberSubjectId(id);
      commitExistingSubjectValue(subjectIdForWrite, finalUpdated);
      syncEntitySignal(id);
      updateSignals();

      // Notify PathNotifier
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        finalUpdated,
        prev,
        basePath,
        lastSubjectIds,
        getPositionIdsForNotify(),
        ambientMeta(),
        undefined,
        (callableIntent ?? getActiveWriteContext()?.mutationIntent) === 'derive'
          ? undefined
          : Object.keys(transformedChanges)
      );

      // Run tap handlers
      emitTap('onUpdate', id, transformedChanges, finalUpdated);
    },

    /**
     * Replace, not merge — and the write path behind `byId(id)(next)`.
     *
     * Identical to `updateOne` except the one line that matters: assign the whole
     * entity instead of spreading it over the current one. That single difference
     * is the only way to REMOVE a key, which `updateOne` cannot express at all.
     *
     * **Why `replaceOne(id, entity)` and not `setOne(entity)`.** The id comes from
     * the caller on purpose. A `setOne` deriving it via `selectId(entity)` writes
     * to whatever slot the entity's own id field names — and `changeId` can leave
     * `entity.id` disagreeing with the storage key, so that form has a silent
     * wrong-slot write built into it. This one cannot drift.
     */
    replaceOne(id: K, entity: E): void {
      const callableIntent = consumeCallableWriteIntent();
      const prev = presentEntity(id);
      if (!prev) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }

      let next = entity;
      for (const handler of interceptHandlers) {
        const ctx: InterceptContext<Partial<E>> = {
          block: (reason?: string) => {
            throw new Error(
              `Cannot replace entity: ${reason || 'blocked by interceptor'}`
            );
          },
          transform: (value: Partial<E>) => {
            next = value as E;
          },
          blocked: false,
          blockReason: undefined,
        };
        assertSynchronousInterceptorResult(
          handler.onUpdate?.(id, entity as Partial<E>, ctx),
          'onUpdate'
        );
      }

      const subjectId = structuralStore.subjectIdForKey(id);
      if (subjectId === undefined) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }

      const replacement: PreparedValueReplacement<K, E> = {
        kind: 'replace-value',
        key: id,
        subjectId,
        nextValue: next,
      };
      const frame = createEntityMutationFrame();
      frame.stageValueReplacement(replacement);
      commitAndProjectEntityMutationFrame(frame);
      syncEntitySignal(id);
      updateSignals();
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        next,
        prev,
        basePath,
        // REPLACE-ONE-SUBJECT-1. This was `undefined`, and it was the ONLY
        // entity notification in this file that dropped subject identity —
        // `updateOne`, `updateMany` and `removeOne` all pass theirs. The id
        // above is DATA; `subjectId` is IDENTITY, and it was already resolved
        // from `structuralStore` a few lines up, so nothing new is looked up
        // here.
        //
        // Without it, reversal effects arrive with `subjectId: undefined`,
        // `hasInlineSubjectAddress` is false, no inline subject address is
        // derived, and no fallback descriptor can be keyed — so rollback and
        // undo both REFUSE, at TOP level as well as nested.
        [subjectId],
        getPositionIdsForNotify(),
        ambientMeta(),
        undefined,
        (callableIntent ?? getActiveWriteContext()?.mutationIntent) === 'derive'
          ? undefined
          : null
      );
      emitTap('onUpdate', id, next as Partial<E>, next);
    },

    updateMany(ids: K[], changes: Partial<E>): void {
      if (ids.length === 0) return;

      // Collect entities and run interceptors first
      const updatedEntities: Array<{
        id: K;
        subjectId: number;
        prev: E;
        finalUpdated: E;
        transformedChanges: Partial<E>;
      }> = [];

      for (const id of ids) {
        const entity = presentEntity(id);
        if (!entity) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        const prev = entity;

        // Run interceptors
        let transformedChanges = changes;
        for (const handler of interceptHandlers) {
          const ctx: InterceptContext<Partial<E>> = {
            block: (reason?: string) => {
              throw new Error(
                `Cannot update entity: ${reason || 'blocked by interceptor'}`
              );
            },
            transform: (value: Partial<E>) => {
              transformedChanges = value;
            },
            blocked: false,
            blockReason: undefined,
          };
          assertSynchronousInterceptorResult(
            handler.onUpdate?.(id, changes, ctx),
            'onUpdate'
          );
        }

        const finalUpdated = { ...entity, ...transformedChanges };
        const subjectId = structuralStore.subjectIdForKey(id);
        if (subjectId === undefined) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }

        updatedEntities.push({
          id,
          subjectId,
          prev,
          finalUpdated,
          transformedChanges,
        });
      }

      const frame = createEntityMutationFrame();
      for (const { id, subjectId, finalUpdated } of updatedEntities) {
        frame.stageValueReplacement({
          kind: 'replace-value',
          key: id,
          subjectId,
          nextValue: finalUpdated,
        });
      }
      commitAndProjectEntityMutationFrame(frame);

      for (const { id } of updatedEntities) {
        syncEntitySignal(id);
      }

      // Single signal update after all entities are updated
      updateSignals();

      const subjectIdsForWrite = rememberSubjectIds(ids);

      // Notify PathNotifier for each updated entity
      for (let i = 0; i < updatedEntities.length; i++) {
        const { id, prev, finalUpdated, transformedChanges } =
          updatedEntities[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          finalUpdated,
          prev,
          basePath,
          [subjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          ambientMeta(),
          undefined,
          getActiveWriteContext()?.mutationIntent === 'derive'
            ? undefined
            : Object.keys(transformedChanges)
        );
      }

      // Run tap handlers for each updated entity
      for (const { id, transformedChanges, finalUpdated } of updatedEntities) {
        emitTap('onUpdate', id, transformedChanges, finalUpdated);
      }
    },

    updateWhere(
      predicate: (entity: E) => boolean,
      changes: Partial<E>
    ): number {
      const idsToUpdate: K[] = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToUpdate.push(id);
        }
      }
      if (idsToUpdate.length > 0) {
        api.updateMany(idsToUpdate, changes);
      }
      return idsToUpdate.length;
    },

    // ==================
    // MUTATIONS: REMOVE
    // ==================

    removeOne(id: K): void {
      const entity = presentEntity(id);
      if (!entity) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      const { beforeSubject, afterSubject } = getNeighborSubjects(id);

      // Run interceptors
      for (const handler of interceptHandlers) {
        const ctx: InterceptContext<void> = {
          block: (reason?: string) => {
            throw new Error(
              `Cannot remove entity: ${reason || 'blocked by interceptor'}`
            );
          },
          transform: () => {
            // void transform - no transformation possible
          },
          blocked: false,
          blockReason: undefined,
        };
        assertSynchronousInterceptorResult(
          handler.onRemove?.(id, entity, ctx),
          'onRemove'
        );
      }

      // Delete and update signals
      const subjectIdsForWrite = rememberSubjectIds([id]);
      const structuralEffect: PendingStructuralEffect = {
        kind: 'remove',
        subject: subjectIdsForWrite[0],
        key: id,
        value: deepClone(entity),
        beforeSubject,
        afterSubject,
      };
      const currentState = resolveSubjectState(subjectIdsForWrite[0]);
      const tombstone: PreparedSubjectTombstone<K> = {
        kind: 'tombstone-subject',
        key: id,
        subjectId: subjectIdsForWrite[0],
        restoreAllowed: currentState?.restoreAllowed ?? true,
      };
      const frame = createEntityMutationFrame();
      frame.stageSubjectTombstone(tombstone);
      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }
      tombstoneSubjectSignal(subjectIdsForWrite[0]);
      reclaimRetiredSubjectsWithoutOwner([subjectIdsForWrite[0]]);
      updateSignals();

      // Notify PathNotifier
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        undefined,
        entity,
        basePath,
        subjectIdsForWrite,
        getPositionIdsForNotify(),
        createStructuralEffectMeta(structuralEffect)
      );

      // Run tap handlers
      emitTap('onRemove', id, entity);
    },

    removeMany(ids: K[]): void {
      if (ids.length === 0) return;

      // Collect entities and run interceptors first
      const preparedRemovals: Array<{
        id: K;
        entity: E;
        subjectId: number;
        beforeSubject?: number;
        afterSubject?: number;
      }> = [];
      for (const id of ids) {
        const entity = presentEntity(id);
        if (!entity) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        const subjectId = resolveSubjectId(id);
        if (subjectId === undefined) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        const { beforeSubject, afterSubject } = getNeighborSubjects(id);

        // Run interceptors
        for (const handler of interceptHandlers) {
          const ctx: InterceptContext<void> = {
            block: (reason?: string) => {
              throw new Error(
                `Cannot remove entity: ${reason || 'blocked by interceptor'}`
              );
            },
            transform: () => {
              // void transform - no transformation possible
            },
            blocked: false,
            blockReason: undefined,
          };
          assertSynchronousInterceptorResult(
            handler.onRemove?.(id, entity, ctx),
            'onRemove'
          );
        }

        preparedRemovals.push({
          id,
          entity,
          subjectId,
          beforeSubject,
          afterSubject,
        });
      }

      const subjectIdsForWrite = preparedRemovals.map(
        ({ subjectId }) => subjectId
      );
      lastSubjectIds = subjectIdsForWrite;

      const frame = createEntityMutationFrame();

      for (const { id, subjectId } of preparedRemovals) {
        const currentState = resolveSubjectState(subjectId);
        frame.stageSubjectTombstone({
          kind: 'tombstone-subject',
          key: id,
          subjectId,
          restoreAllowed: currentState?.restoreAllowed ?? true,
        });
      }

      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }

      for (const { subjectId } of preparedRemovals) {
        tombstoneSubjectSignal(subjectId);
      }
      reclaimRetiredSubjectsWithoutOwner(
        preparedRemovals.map(({ subjectId }) => subjectId)
      );

      // Single signal update after all entities are removed
      updateSignals();

      // Notify PathNotifier for each removed entity
      for (let i = 0; i < preparedRemovals.length; i++) {
        const { id, entity, beforeSubject, afterSubject } = preparedRemovals[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          undefined,
          entity,
          basePath,
          [subjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          createStructuralEffectMeta({
            kind: 'remove',
            subject: subjectIdsForWrite[i],
            key: id,
            value: deepClone(entity),
            beforeSubject,
            afterSubject,
          })
        );
      }

      // Run tap handlers for each removed entity
      for (const { id, entity } of preparedRemovals) {
        emitTap('onRemove', id, entity);
      }
    },

    removeWhere(predicate: (entity: E) => boolean): number {
      const idsToRemove: K[] = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToRemove.push(id);
        }
      }
      if (idsToRemove.length > 0) {
        api.removeMany(idsToRemove);
      }
      return idsToRemove.length;
    },

    // ==================
    // MUTATIONS: UPSERT
    // ==================

    upsertOne(entity: E, opts?: AddOptions<E, K>): K {
      const id = deriveId(entity, opts);
      if (structuralStore.hasActiveKey(id)) {
        api.updateOne(id, entity);
      } else {
        api.addOne(entity, opts);
      }
      return id;
    },

    upsertMany(entities: E[], opts?: AddOptions<E, K>): K[] {
      if (entities.length === 0) return [];
      const lastPreviousKey = structuralStore.lastActiveKey();

      // Upserted one at a time, as successive upsertOne calls would be: every
      // id is resolved first (nothing intercepted or written yet), then the
      // interceptors run once per COPY, in input order: onAdd for a new id's
      // first copy, onUpdate for each later copy (the raw copy), merged over
      // the running value. Each key is announced and tapped once, with its
      // final value (v15 778f86ef and e02238f4, carried in v16 8f).
      type Upsert = {
        id: K;
        prev?: E;
        subjectId?: number;
        /** The running value: the stored row, then each intercepted copy. */
        entity?: E;
        changes?: Partial<E>;
      };
      const toAdd: Upsert[] = [];
      const toUpdate: Upsert[] = [];
      const copies: Array<[Upsert, E]> = [];
      const earlier = new Map<K, Upsert>();
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        let row = earlier.get(id);
        if (!row) {
          const prev = getProjectedEntity(id);
          if (prev === undefined) row = { id };
          else {
            const subjectId = resolveSubjectId(id);
            if (subjectId === undefined) {
              throw new Error(`Entity with id ${String(id)} has no subject id`);
            }
            row = { id, prev, entity: prev, subjectId };
          }
          (prev === undefined ? toAdd : toUpdate).push(row);
          earlier.set(id, row);
        }
        copies.push([row, entity]);
      }
      for (const [row, entity] of copies) {
        if (row.entity === undefined) {
          row.entity = interceptAddedEntity(entity);
        } else {
          const changes = interceptUpdatedEntity(row.id, entity);
          row.changes = { ...row.changes, ...changes };
          row.entity = { ...row.entity, ...changes };
        }
      }

      const stagedAdds = toAdd as Array<{ id: K; entity: E }>;
      const stagedUpdates = toUpdate.map(
        ({ id, subjectId, prev, entity, changes }) => ({
          id,
          subjectId: subjectId as number,
          prev: prev as E,
          transformedChanges: changes as Partial<E>,
          finalUpdated: entity as E,
        })
      );

      // One observed membership unit; a throw still closes it.
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      const addedEntities: Array<{ id: K; entity: E; subjectId: number }> = [];
      try {
        const freshSubjectIds = structuralStore.planFreshSubjectIds(stagedAdds.length);
        const frame=createEntityMutationFrame();
        for(let i=0;i<stagedAdds.length;i++) frame.stageFreshSubject({kind:'create-fresh-subject',key:stagedAdds[i].id,subjectId:freshSubjectIds[i],nextValue:stagedAdds[i].entity});
        for(const row of stagedUpdates) frame.stageValueReplacement({kind:'replace-value',key:row.id,subjectId:row.subjectId,nextValue:row.finalUpdated});
        commitAndProjectEntityMutationFrame(frame);
        const addedSubjectIdsByKey = new Map<K, number>();
        for (let i = 0; i < stagedAdds.length; i++) {
          addedSubjectIdsByKey.set(stagedAdds[i].id, freshSubjectIds[i]);
        }

        // Process adds
        for (const { entity: transformedEntity, id } of stagedAdds) {
          const subjectId = addedSubjectIdsByKey.get(id);
          if (subjectId === undefined) {
            throw new Error(`Entity with id ${String(id)} has no subject id`);
          }

          invalidateNodeCache(id);
          syncEntitySignal(id);
          addedEntities.push({ id, entity: transformedEntity, subjectId });
        }
      } finally {
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }

      const updatedEntities: Array<{
        id: K;
        subjectId: number;
        prev: E;
        finalUpdated: E;
        transformedChanges: Partial<E>;
      }> = [];
      for (const {
        id,
        subjectId,
        prev,
        finalUpdated,
        transformedChanges,
      } of stagedUpdates) {

        syncEntitySignal(id);
        updatedEntities.push({
          id,
          subjectId,
          prev,
          finalUpdated,
          transformedChanges,
        });
      }

      // Single signal update after all entities are processed
      updateSignals();

      const addedSubjectIdsForWrite = addedEntities.map(
        ({ subjectId }) => subjectId
      );
      const updatedSubjectIdsForWrite = updatedEntities.map(
        ({ subjectId }) => subjectId
      );
      lastSubjectIds = [
        ...addedSubjectIdsForWrite,
        ...updatedSubjectIdsForWrite,
      ];

      // Fresh lifetimes require an add effect, not a whole-row value write.
      // Each appended row follows the previous fresh row of this call.
      let beforeSubject =
        lastPreviousKey === undefined
          ? undefined
          : allocateSubjectId(lastPreviousKey);
      for (let i = 0; i < addedEntities.length; i++) {
        const { id, entity } = addedEntities[i];
        const subject = addedSubjectIdsForWrite[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          undefined,
          basePath,
          [subject],
          getPositionIdsForNotify(),
          createStructuralEffectMeta({
            kind: 'add',
            subject,
            key: id,
            value: deepClone(entity),
            beforeSubject,
          })
        );
        beforeSubject = subject;
      }

      // Notify PathNotifier for updated entities
      for (let i = 0; i < updatedEntities.length; i++) {
        const { id, prev, finalUpdated, transformedChanges } =
          updatedEntities[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          finalUpdated,
          prev,
          basePath,
          [updatedSubjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          ambientMeta(),
          undefined,
          getActiveWriteContext()?.mutationIntent === 'derive'
            ? undefined
            : Object.keys(transformedChanges)
        );
      }

      // Run tap handlers for added entities
      for (const { id, entity } of addedEntities) {
        emitTap('onAdd', entity, id);
      }

      // Run tap handlers for updated entities
      for (const { id, transformedChanges, finalUpdated } of updatedEntities) {
        emitTap('onUpdate', id, transformedChanges, finalUpdated);
      }

      return [...toAdd.map((a) => a.id), ...toUpdate.map((u) => u.id)];
    },

    // ==================
    // MUTATIONS: CLEAR/RESET
    // ==================

    clear(): void {
      // AUTHORS THE SAME STRUCTURAL REMOVALS `removeMany` DOES, and that is the
      // whole fix. Until 15.0 this tombstoned subjects and told the notifier
      // nothing, so the turn restoration recorded carried no structural effect:
      // `canUndo()` reported true, the first undo silently restored nothing, and
      // the next threw "Unsupported scoped undo effect at structural-drift".
      // Removing the same rows one at a time and undoing worked correctly, which
      // is what made it a defect rather than a limitation — see
      // `clear-not-undoable.spec.ts`.
      //
      // The entity VALUES and the neighbour subjects have to be captured BEFORE
      // anything is tombstoned: a `remove` effect carries the value it removed
      // and where it sat, and after the tombstone neither is reachable.
      const activeIds = structuralStore.activeKeysSnapshot();
      const activeSubjects = activeIds.map((id) => {
        const subjectId = resolveSubjectId(id);
        if (subjectId === undefined) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        const entity = getProjectedEntity(id);
        const { beforeSubject, afterSubject } = getNeighborSubjects(id);
        return { id, subjectId, entity, beforeSubject, afterSubject };
      });

      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      try {
        const frame=createEntityMutationFrame();
        for (const {id,subjectId} of activeSubjects) frame.stageSubjectTombstone({kind:'tombstone-subject',key:id,subjectId,restoreAllowed:resolveSubjectState(subjectId)?.restoreAllowed ?? true});
        commitAndProjectEntityMutationFrame(frame);
      } finally {
        // Observed once every row is tombstoned, before reactive publication.
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      for (const { subjectId } of activeSubjects)
        publishSubjectPhysicalChange(subjectId);

      // Per-subject, exactly as `removeOne` does — never a bulk reset (see the
      // tombstone above). A held reference has to keep reading through the SAME
      // signal so an undo re-publishes into it, which is the property
      // `check-signal-identity-durability.mjs` pins for `removeOne`. Zero-owner
      // trees still shed the entries, one line below.
      for (const { subjectId } of activeSubjects) {
        tombstoneSubjectSignal(subjectId);
      }
      reclaimRetiredSubjectsWithoutOwner(
        activeSubjects.map(({ subjectId }) => subjectId)
      );
      replaceLocation(activeIdSignal, undefined);
      lastSubjectIds = activeSubjects.map(({ subjectId }) => subjectId);
      updateSignals();

      for (const {
        id,
        subjectId,
        entity,
        beforeSubject,
        afterSubject,
      } of activeSubjects) {
        if (!entity) continue;
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          undefined,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          createStructuralEffectMeta({
            kind: 'remove',
            subject: subjectId,
            key: id,
            value: deepClone(entity),
            beforeSubject,
            afterSubject,
          })
        );
      }

      for (const { id, entity } of activeSubjects) {
        if (!entity || silentClear) continue;
        emitTap('onRemove', id, entity);
      }
    },

    setAll(entities: E[], opts?: AddOptions<E, K>): void {
      // Pre-state from ONE walk of the structural order: each row's key and
      // subject come off its node, so nothing below re-resolves a current row
      // or searches the pre-state for a removed row's position.
      const currentKeys: K[] = [];
      const currentSubjects: number[] = [];
      structuralStore.snapshotActiveOrder(currentKeys, currentSubjects);
      const beforeOrderFrontier = structuralStore.activeOrderFrontier();

      // The incoming order, deduplicated (first position, last value), in
      // index-aligned arrays. `incomingSubjects` holds an update's existing
      // subject and receives each add's fresh subject once it exists.
      const incomingIndex = new Map<K, number>();
      const incomingIds: K[] = [];
      const incomingEntities: E[] = [];
      const incomingSubjects: Array<number | undefined> = [];
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        const existing = structuralStore.subjectIdForKey(id);
        const transformedEntity =
          existing !== undefined
            ? interceptReplacedEntity(id, entity)
            : interceptAddedEntity(entity);

        const index = incomingIndex.get(id);
        if (index === undefined) {
          incomingIndex.set(id, incomingIds.length);
          incomingIds.push(id);
          incomingEntities.push(transformedEntity);
          incomingSubjects.push(existing);
          continue;
        }
        incomingEntities[index] = transformedEntity;
      }

      const stagedRemovals: Array<{
        id: K;
        entity: E;
        subjectId: number;
        /** Position in the pre-state order, for the removal's neighbours. */
        index: number;
      }> = [];
      for (let index = 0; index < currentKeys.length; index += 1) {
        const id = currentKeys[index];
        if (incomingIndex.has(id)) continue;
        const subjectId = currentSubjects[index];
        const entity = valueStore.backingForSubject(subjectId);
        if (entity === undefined) continue;
        for (const handler of interceptHandlers) {
          const ctx: InterceptContext<void> = {
            block: (reason?: string) => {
              throw new Error(
                `Cannot remove entity: ${reason || 'blocked by interceptor'}`
              );
            },
            transform: () => {
              // void transform - no transformation possible
            },
            blocked: false,
            blockReason: undefined,
          };
          assertSynchronousInterceptorResult(
            handler.onRemove?.(id, entity, ctx),
            'onRemove'
          );
        }
        stagedRemovals.push({ id, entity, subjectId, index });
      }

      // An interceptor or selector may have changed membership, keys or order.
      // Those completed writes stand, but this operation must not commit its
      // now-stale topology plan (an applied rekey would otherwise be undone by
      // the reorder below, or a removal recorded against a moved neighbour).
      if (
        structuralStore.activeOrderFrontier() !== beforeOrderFrontier ||
        currentKeys.some(
          (key, index) =>
            structuralStore.subjectIdForKey(key) !== currentSubjects[index]
        )
      ) {
        throw new Error(
          'Cannot setAll: collection topology changed during staging'
        );
      }

      const stagedUpdates: Array<{
        id: K;
        prev: E;
        entity: E;
        subjectId: number;
      }> = [];
      const stagedAdds: Array<{ id: K; entity: E; index: number }> = [];
      for (let index = 0; index < incomingIds.length; index += 1) {
        const id = incomingIds[index];
        const entity = incomingEntities[index];
        const subjectId = incomingSubjects[index];
        if (subjectId === undefined) {
          stagedAdds.push({ id, entity, index });
          continue;
        }
        // Read after every callback: a field-only reentrant write is the
        // value this replacement supersedes.
        const prev = valueStore.backingForSubject(subjectId);
        if (prev === undefined) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        stagedUpdates.push({ id, prev, entity, subjectId });
      }

      // From the first fresh subject to the order capture is one membership
      // unit; a throw still closes it.
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      let addedSubjectIds: readonly number[];
      let afterSubjects: number[];
      const stagedRemovalStructuralEffects: PendingStructuralEffect[] = [];
      try {
        // Index-aligned with `stagedAdds`.
        addedSubjectIds = structuralStore.planFreshSubjectIds(stagedAdds.length);
        for (let k = 0; k < stagedAdds.length; k += 1) {
          incomingSubjects[stagedAdds[k].index] = addedSubjectIds[k];
        }
        // Every incoming row now has its subject: this IS the after-order.
        afterSubjects = incomingSubjects as number[];

        // Immediate pre-state neighbours, removed or surviving, exactly as
        // clear() and removeMany() record them. Anchoring only to survivors left
        // adjacent removals with identical anchors, so their reversal order
        // depended on replay order: [a,b,c] -> [q,a] rolled back to [a,c,b], and
        // replacing every row undid to [c,b,a].
        for (const { id, entity, subjectId, index } of stagedRemovals) {
          stagedRemovalStructuralEffects.push({
            kind: 'remove',
            subject: subjectId,
            key: id,
            value: deepClone(entity),
            beforeSubject: index > 0 ? currentSubjects[index - 1] : undefined,
            afterSubject: currentSubjects[index + 1],
          });
        }

        const frame=createEntityMutationFrame();
        for (const {id,subjectId} of stagedRemovals) frame.stageSubjectTombstone({kind:'tombstone-subject',key:id,subjectId,restoreAllowed:resolveSubjectState(subjectId)?.restoreAllowed ?? true});
        for (const {id,subjectId,entity} of stagedUpdates) frame.stageValueReplacement({kind:'replace-value',key:id,subjectId,nextValue:entity});
        for(let k=0;k<stagedAdds.length;k++) frame.stageFreshSubject({kind:'create-fresh-subject',key:stagedAdds[k].id,subjectId:addedSubjectIds[k],nextValue:stagedAdds[k].entity});
        commitAndProjectEntityMutationFrame(frame);
        for(const {subjectId} of stagedRemovals) tombstoneSubjectSignal(subjectId);
        for(const {id} of stagedAdds) syncEntitySignal(id);

        for (const { id } of stagedUpdates) {
          syncEntitySignal(id);
        }

        structuralStore.reorderActiveKeys(incomingIds);

        lastSubjectIds = [
          ...stagedRemovals.map(({ subjectId }) => subjectId),
          ...stagedUpdates.map(({ subjectId }) => subjectId),
          ...addedSubjectIds,
        ];

        if (mutationCaptureRuntime?.isCaptureActive()) getPositionIds();
        // Captured whenever SURVIVING subjects change relative order, not only
        // for a pure reorder. Neighbour hints on the structural effects cannot
        // restore survivors that moved: reversing [a,b,c] -> [c,a] yielded
        // [b,c,a]. The order delta carries both endpoints, including subjects
        // present at only one of them. Membership-only changes keep relying on
        // the structural effects.
        if (
          positionId !== undefined &&
          mutationCaptureRuntime?.publishCollectionOrder &&
          survivingOrderChanged(currentSubjects, afterSubjects)
        ) {
          publishOrderChange(currentSubjects, afterSubjects, beforeOrderFrontier);
        }
      } finally {
        // The whole replacement has installed (or stopped): the observed
        // membership unit closes before the removed rows' reactive publication.
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      for (const { subjectId } of stagedRemovals)
        publishSubjectPhysicalChange(subjectId);
      reclaimRetiredSubjectsWithoutOwner(
        stagedRemovals.map(({ subjectId }) => subjectId)
      );

      // Every incoming row is active by now, so the nearest neighbour with a
      // subject is the adjacent one in the after-order.
      const stagedAddStructuralEffects: PendingStructuralEffect[] = [];
      for (let k = 0; k < stagedAdds.length; k += 1) {
        const { id, entity, index } = stagedAdds[k];
        stagedAddStructuralEffects.push({
          kind: 'add',
          subject: addedSubjectIds[k],
          key: id,
          value: deepClone(entity),
          beforeSubject: index > 0 ? afterSubjects[index - 1] : undefined,
          afterSubject: afterSubjects[index + 1],
        });
      }

      updateSignals();

      for (let index = 0; index < stagedRemovals.length; index += 1) {
        const { id, entity, subjectId } = stagedRemovals[index];
        const structuralEffect = stagedRemovalStructuralEffects[index];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          undefined,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(structuralEffect)
        );
      }

      for (const { id, prev, entity, subjectId } of stagedUpdates) {
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          prev,
          basePath,
          subjectId === undefined ? undefined : [subjectId],
          getPositionIdsForNotify(),
          ambientMeta(),
          undefined,
          getActiveWriteContext()?.mutationIntent === 'derive'
            ? undefined
            : null
        );
      }

      for (let i = 0; i < stagedAdds.length; i++) {
        const { id, entity } = stagedAdds[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          undefined,
          basePath,
          [addedSubjectIds[i]],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(stagedAddStructuralEffects[i])
        );
      }

      for (const { id, entity } of stagedRemovals) {
        emitTap('onRemove', id, entity);
      }

      for (const { id, entity } of stagedAdds) {
        emitTap('onAdd', entity, id);
      }

      for (const { id, entity } of stagedUpdates) {
        emitTap('onUpdate', id, entity as Partial<E>, entity);
      }
    },

    // ==================
    // HOOKS
    // ==================

    tap(handlers: TapHandlers<E, K>): () => void {
      tapHandlers.push(handlers);
      return () => {
        const idx = tapHandlers.indexOf(handlers);
        if (idx > -1) tapHandlers.splice(idx, 1);
      };
    },

    intercept(handlers: InterceptHandlers<E, K>): () => void {
      assertSynchronousInterceptors(handlers);
      interceptHandlers.push(handlers);
      return () => {
        const idx = interceptHandlers.indexOf(handlers);
        if (idx > -1) interceptHandlers.splice(idx, 1);
      };
    },
  };

  // HISTORY SCOPE — removed in 15.0 with `recordHistory`. A collection is no
  // longer excludable from history by location; eligibility belongs to the
  // authored operation. See `undoable()` and the tombstone in utils.ts.
  if (subjectMetadataEnabled) {
    Object.defineProperty(api, '__subjectIds', {
      get: () => lastSubjectIds,
      enumerable: false,
      configurable: true,
    });
  }
  Object.defineProperty(api, '__positionIds', {
    get: getPositionIds,
    enumerable: false,
    configurable: true,
  });
  defineOwnedOwnerPath(api, basePath);

  // ⚠️ A ROW-ADDING WRITE TO AN ABSENT COLLECTION RE-ADDS ITS PATH, CARRYING
  // ONLY THE WRITTEN ROWS (v16 8e). The collection reads empty while it is
  // absent, so the write applies to an empty collection:
  // 1. it is validated and intercepted as on an empty collection, before
  //    anything changes, so a block or bad input changes nothing (v16 8f;
  //    8e intercepted after the removal below, which then stayed);
  // 2. the retained rows are removed through the ordinary `clear()`, which
  //    records them, so a reversal restores them; no tap sees it;
  // 3. the write runs with the rows already intercepted, interceptors
  //    suppressed, so each runs exactly once;
  // 4. every omitted member on its path comes back with only that path
  //    (`reactivatePathOnWrite`).
  // Retained rows never resurface, and undo, redo, jumpTo and rollback
  // reverse all of it. Writes that name an existing row refuse instead, as on
  // an empty collection. Only a structural write on this collection's own
  // tree (the whole value hydrating it, a reversal) writes it as it is.
  const clearRetained = api.clear;
  /**
   * The call's rows after its interceptors, as the write would intercept them
   * on an empty collection: ids resolved first (a strict duplicate throws
   * before any interceptor runs), then once per applied copy in input order —
   * `onAdd` for a key's first copy; for upserts, `onUpdate` with each later
   * raw copy, merged; otherwise the last copy wins in the first copy's place.
   * Ids stay those the raw rows give (`selectId`), as the write would key them.
   */
  const interceptAsEmpty = (
    name: string,
    args: unknown[]
  ): [unknown, AddManyOptions<E, K>] => {
    const opts = args[1] as AddManyOptions<E, K> | undefined;
    const many = name.endsWith('Many') || name === 'setAll';
    const input = (many ? args[0] : [args[0]]) as E[];
    const upsert = name.startsWith('upsert');
    const mode =
      name === 'addMany' || name === 'prependMany'
        ? opts?.mode ?? 'strict'
        : 'overwrite';
    const copies: Array<[K, E]> = [];
    const firsts = new Set<K>();
    for (const row of input) {
      const id = deriveId(row, opts);
      if (firsts.has(id)) {
        if (mode === 'strict')
          throw new Error(`Entity with id ${String(id)} already exists`);
        if (mode === 'skip') continue;
      }
      firsts.add(id);
      copies.push([id, row]);
    }
    const rows = new Map<K, E>();
    for (const [id, row] of copies) {
      const running = rows.get(id);
      rows.set(
        id,
        upsert && running !== undefined
          ? { ...running, ...interceptUpdatedEntity(id, row) }
          : interceptAddedEntity(row)
      );
    }
    const keys = new Map<E, K>();
    const out: E[] = [];
    for (const [id, row] of rows) {
      // One object for two ids (an interceptor that returns a shared object):
      // each id writes its own copy, keyed as the interceptors were.
      const own = keys.has(row) ? ({ ...row } as E) : row;
      keys.set(own, id);
      out.push(own);
    }
    const resolved = {
      ...opts,
      selectId: (row: E) => keys.get(row) ?? deriveId(row, opts),
    };
    return [many ? out : out[0], resolved];
  };
  for (const name of [
    'addOne',
    'prependOne',
    'addMany',
    'prependMany',
    'upsertOne',
    'upsertMany',
    'setAll',
    'clear',
  ] as const) {
    const write = api[name] as (...args: unknown[]) => unknown;
    (api as Record<string, unknown>)[name] = (...args: unknown[]) => {
      if (reAdding || !absent() || inStructuralWrite(proxy))
        return write(...args);
      const prepared = name === 'clear' ? [] : interceptAsEmpty(name, args);
      const writePrepared = () => {
        interceptsSuppressed++;
        try {
          return write(...prepared);
        } finally {
          interceptsSuppressed--;
        }
      };
      // An interceptor that wrote this collection may have re-added it; and
      // a call that adds nothing (`addMany([])`) changes nothing, as on an
      // empty collection. Either way the write is an ordinary one now, its
      // interceptors already run (v16 8f review).
      if (
        !absent() ||
        (name !== 'setAll' &&
          Array.isArray(prepared[0]) &&
          !(prepared[0] as unknown[]).length)
      )
        return writePrepared();
      reAdding = pendingReAdd = true;
      try {
        // The retained rows were never visible, so their removal is no row
        // change to observe: taps do not see it (`silentClear`).
        silentClear++;
        try {
          clearRetained();
        } finally {
          silentClear--;
        }
        const result = writePrepared();
        // Re-added already if a tap was told of a row (`emitTap`).
        if (pendingReAdd) {
          pendingReAdd = false;
          reactivatePathOnWrite(api);
        }
        return result;
      } finally {
        reAdding = pendingReAdd = false;
      }
    };
  }
  // Its presence changed (it, or a member above it, was omitted or re-added):
  // every query and every held row re-reads (`republishMembers`).
  const wake = () =>
    locations.runInvalidationGroup(() => {
      for (const epoch of subjectEpochs.values()) advanceEpochHandle(epoch);
      deriveLocation(version, (value) => value + 1);
      markOwnerInvalidated(ownerId);
    });
  // Inside a structural write it wakes them once, after the write has closed
  // (`structuralWrites.end`, chained in order): a reversal being applied reads
  // rows physically (`physicalRows`), so a consumer re-run inside it would
  // cache what storage holds rather than the collection's absence. Installed
  // by the first such change, so a tree without collections carries none of
  // this. Every queued wake runs even if an earlier one throws.
  let wakeQueued = false;
  Object.defineProperty(api, MEMBERSHIP_CHANGED, {
    value: () => {
      if (!structuralWrites.depth) return wake();
      if (wakeQueued) return;
      wakeQueued = true;
      const earlier = structuralWrites.end;
      structuralWrites.end = (failed) => {
        structuralWrites.end = undefined;
        wakeQueued = false;
        // Every queued wake runs; the first consumer error is kept.
        let caught: { error: unknown } | undefined;
        for (const run of [() => earlier?.(failed), wake]) {
          try {
            run();
          } catch (error) {
            caught ??= { error };
          }
        }
        if (!caught) return;
        // Closing a reversal that threw: its own error is what surfaces, and
        // a consumer's is reported asynchronously.
        if (!failed) throw caught.error;
        const { error } = caught;
        queueMicrotask(() => {
          throw error;
        });
      };
    },
  });
  // Membership observation attaches its tap here on first use.
  defineEntityMembershipSource(api, (tap) => {
    membershipTap = tap;
    return structuralStore;
  });
  // ⚠️ THE PROJECTION SEED — internal, WeakMap-carried, never public.
  //
  // Built from the SAME ordered active-key snapshot `getProjectedEntries()`
  // uses, and the SAME `getProjectedEntity` row path, so a consumer's seeded
  // projection cannot drift from `all()` by construction.
  //
  // `key` is carried explicitly alongside `subjectId` because it is genuinely
  // separate information: after `changeId(1, 77)` the row payload still reads
  // `{ id: 1 }` while the address is 77, so `selectId(row)` cannot recover it.
  defineEntityProjectionSeed(api as object, () => {
    const seed: Array<{ subjectId: number; key: K; row: E }> = [];
    // An absent collection seeds an empty projection, as `all()` reads.
    for (const key of absent() ? [] : structuralStore.activeKeysSnapshot()) {
      const subjectId = structuralStore.subjectIdForKey(key);
      if (subjectId === undefined) continue;
      const row = getProjectedEntity(key);
      if (row === undefined) continue;
      seed.push({ subjectId, key, row });
    }
    return seed as readonly {
      subjectId: number;
      key: string | number;
      row: unknown;
    }[];
  });

  Object.defineProperty(api, '__findKeyBySubjectId', {
    value: findKeyBySubjectId,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__preparePointValues', {
    value: preparePointValues, enumerable: false, configurable: true,
  });
  Object.defineProperty(api, '__planFreshAdd', {
    value: planFreshAdd,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__restoreOne', {
    value: restoreOne,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planRekey', {
    value: planRekey,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planPreparedRekey', {
    value: planPreparedRekey,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planRemove', {
    value: planRemove,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planRestore', {
    value: planRestore,
    enumerable: false,
    configurable: true,
  });
  if (positionId !== undefined) {
    Object.defineProperty(api, '__prepareTransitionTarget', {
      value: {
        owner: positionId,
        ownerPath: basePath,
        readSource: readTransitionSource,
        prepareTarget: (target, prepare) => prepare({
          positionId, structuralStore, valueStore, activeIdSignal,
          subjectEpochs, subjectStateSignals,
          get membershipTap() { return membershipTap; },
          advanceEpochHandle, updateSignals, physicalCommitClock, pathNotifier,
          basePath, getPositionIdsForNotify, createStructuralEffectMeta,
          ambientMeta, emitTap,
        }, target),
      } satisfies CollectionTransitionTargetBinding,
      enumerable: false,
      configurable: true,
    });
  }
  Object.defineProperty(api, '__inspectSubjectResources', {
    value: inspectSubjectResources,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__listSubjectReclamationCandidates', {
    value: listSubjectReclamationCandidates,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__acquireEntityHandleForTesting', {
    value: acquireEntityHandleForTesting,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__resolveEntityHandleForTesting', {
    value: resolveEntityHandleForTesting,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__rebuildActiveProjectionFromOwnersForTesting', {
    value: rebuildActiveProjectionFromOwners,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planSubjectReclamation', {
    value: (
      subjectId: number,
      options: EntitySubjectReclamationPlanningOptions
    ) => {
      const inventory = inspectSubjectResources(subjectId);
      return inventory
        ? planEntitySubjectReclamation(inventory, options)
        : undefined;
    },
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__prepareSubjectReclamation', {
    value: prepareSubjectReclamation,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__applyPreparedSubjectReclamation', {
    value: applyPreparedSubjectReclamation,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__retireSubjectRetainedValueBackingForTesting', {
    value: retireSubjectRetainedValueBackingForTesting,
    enumerable: false,
    configurable: true,
  });

  // ==================
  // PROXY FOR BRACKET NOTATION
  // ==================

  // The Proxy only handles bracket notation access (signal[id])
  // All methods are direct properties on api - no binding needed
  const warnedWrongMethods = new Set<string>();
  const proxy = new Proxy(api as unknown as EntitySignal<E, K>, {
    get: (target: EntitySignal<E, K>, prop: string | symbol) => {
      // Handle string/number bracket access: signal[123] or signal['abc']
      if (typeof prop === 'string' && !isNaN(Number(prop))) {
        return api.byId(Number(prop) as K);
      }
      // Dev-mode guardrail: a known wrong-method name from another state
      // library → actionable hint instead of a later "undefined is not a
      // function". Only fires for names that are NOT real api members.
      if (
        typeof prop === 'string' &&
        !(prop in (target as object)) &&
        WRONG_ENTITY_METHODS[prop] &&
        (typeof ngDevMode === 'undefined' || ngDevMode) &&
        !warnedWrongMethods.has(prop)
      ) {
        warnedWrongMethods.add(prop);
        console.warn(
          `SignalTree entityMap has no \`.${prop}()\`. Did you mean: ` +
            `${WRONG_ENTITY_METHODS[prop]}? [ST2002]`
        );
      }
      // All other access goes directly to api
      return (target as unknown as Record<string | symbol, unknown>)[prop];
    },
  });
  return proxy;
}

Object.defineProperty(
  createEntitySignal,
  '__setPositionIdAllocatorForTesting',
  {
    value: setEntityPositionIdAllocatorForTesting,
    enumerable: false,
    configurable: true,
  }
);
Object.defineProperty(
  createEntitySignal,
  '__setPositionIdNotifyEnabledForTesting',
  {
    value: setEntityPositionIdNotifyEnabledForTesting,
    enumerable: false,
    configurable: true,
  }
);
