import {signalTree,entityMap,transactions,restoration} from "/Users/jonathanborgia/code/signaltree/artifacts/entity-preparation-split-2026-10-14/baseline-kernel/dist/index.js";
const tree=signalTree({rows:entityMap({selectId:r=>r.id}),x:0},{enhancers:[transactions(),restoration()]});
tree.$.rows.setAll([{id:'a',v:1},{id:'b',v:2}]);const held=tree.$.rows.byIdOrFail('a');
const p=tree.transact(()=>{tree.$.rows.setAll([{id:'b',v:2},{id:'a',v:10}]);tree.$.x(1);});p.rollback();
globalThis.__splitResult={ids:tree.$.rows.ids(),row:held(),x:tree.$.x()};tree.destroy();