import {signalTree,entityMap} from "/private/tmp/signaltree-optional-preparation-20261014/dist/packages/kernel/dist/index.js";
const tree=signalTree({rows:entityMap({selectId:r=>r.id}),x:0});
tree.$.rows.setAll([{id:'a',v:1},{id:'b',v:2}]);const held=tree.$.rows.byIdOrFail('a');
tree.$.rows.updateOne('a',{v:1});
globalThis.__splitResult={ids:tree.$.rows.ids(),row:held(),x:tree.$.x()};tree.destroy();