globalThis.ngDevMode=false;
import assert from 'node:assert/strict';import {performance} from 'node:perf_hooks';import {loadavg} from 'node:os';
const [core,mode]=process.argv.slice(2);const {signalTree,entityMap,transactions}=await import(core);
const {peekInternalTransactionRuntime}=await import(new URL('./enhancers/transactions/transactions.js', 'file://'+core));
const started=new Date().toISOString();const beforeLoad=loadavg();const t=signalTree({rows:entityMap(),x:0},{enhancers:[transactions()]});
const original=Array.from({length:16},(_,i)=>({id:String(i),v:0}));t.$.rows.setAll(original);const initialIds=original.map(x=>x.id);
const binding=t.$.rows.__prepareTransitionTarget,prepare=binding.prepareTarget;let calls=0;binding.prepareTarget=function(...args){calls++;return prepare.apply(this,args)};
const warm=500,count=5000;let current=0;
function step(i){const prior=current;const ids=t.$.rows.ids();const rows=ids.slice().reverse().map(id=>({id,v:i}));const p=t.transact(()=>{t.$.rows.setAll(rows);t.$.x(i)});assert.deepEqual(t.$.rows.ids(),ids.slice().reverse());assert.equal(t.$.x(),i);assert.equal(peekInternalTransactionRuntime(t).getPendingTurnCount(),1);p[mode]();assert.equal(peekInternalTransactionRuntime(t).getPendingTurnCount(),0);current=mode==='confirm'?i:prior;assert.equal(t.$.x(),current);assert.deepEqual(t.$.rows.ids(),mode==='confirm'?ids.slice().reverse():ids);for(const id of initialIds)assert.equal(t.$.rows.byIdOrFail(id)().v,current);}
for(let i=1;i<=warm;i++)step(i);await new Promise(r=>setTimeout(r,0));for(let i=0;i<3;i++)global.gc();
const heapBefore=process.memoryUsage().heapUsed,cpu=process.cpuUsage(),start=performance.now();for(let i=warm+1;i<=warm+count;i++)step(i);const wall=performance.now()-start,used=process.cpuUsage(cpu);await new Promise(r=>setTimeout(r,0));for(let i=0;i<3;i++)global.gc();const heapAfter=process.memoryUsage().heapUsed;
assert.equal(calls,mode==='rollback'?warm+count:0);t.destroy();console.log(JSON.stringify({started,finished:new Date().toISOString(),pid:process.pid,nodeEnv:process.env.NODE_ENV,mode,count,warm,rows:16,preparations:calls,wallNs:wall*1e6/count,cpuNs:(used.user+used.system)*1000/count,heapBefore,heapAfter,heapDelta:heapAfter-heapBefore,loadBefore:beforeLoad,loadAfter:loadavg(),node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch}));
