import subprocess,json,random,pathlib,statistics,hashlib,os,datetime,math
out=pathlib.Path(__file__).parent;node='/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node'
arms={'before':str(out.parent/'baseline-kernel/dist/index.js'),'after':str(out.parent/'candidate-kernel/dist/index.js')}
protocol={'rounds':6,'seed':241014,'modes':['rollback','confirm'],'count':5000,'warmup':500,'rows':16,'scope':'synchronous checked reorder and scalar transactions, settlement and reads; excludes setup, warmup, deferred flush and explicit GC; includes incidental GC','heap':'post-GC whole-process retained heap difference after 5000 operations, not peak allocation or dominator memory','quiet':'host not certified quiet; run after builds/tests complete'}
def inventory():
 return {a:{str(p.relative_to(pathlib.Path(core).parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path(core).parent.rglob('*.js')}for a,core in arms.items()}
initial=inventory();(out/'inputs-before.json').write_text(json.dumps(initial,indent=2))
protocol.update(harnessHash=hashlib.sha256((out/'cost.mjs').read_bytes()).hexdigest(),driverHash=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),nodeEnv='production',beforeArtifact=arms['before'],afterArtifact=arms['after'])
(out/'cost-protocol.json').write_text(json.dumps(protocol,indent=2));rng=random.Random(protocol['seed']);data=[]
for round in range(6):
 jobs=[(arm,mode)for arm in arms for mode in protocol['modes']];rng.shuffle(jobs)
 for arm,mode in jobs:
  path=out/f'cost-{round}-{arm}-{mode}.json';assert not path.exists()
  cmd=[node,'--expose-gc',str(out/'cost.mjs'),arms[arm],mode]
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=60,env=dict(os.environ,NODE_ENV='production'))
  with (out/'receipts.jsonl').open('a') as f:f.write(json.dumps({'round':round,'arm':arm,'mode':mode,'command':cmd,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode})+'\n')
  path.with_suffix('.stderr').write_text(p.stderr)
  if p.returncode: path.with_suffix('.failed').write_text(p.stdout);raise RuntimeError((arm,mode,p.returncode,p.stderr))
  row=json.loads(p.stdout);assert all(math.isfinite(row[k]) for k in ['wallNs','cpuNs','heapDelta']);row.update(arm=arm,round=round);path.write_text(json.dumps(row,indent=2));data.append(row)
summary={}
for mode in protocol['modes']:
 summary[mode]={}
 for metric in ['wallNs','cpuNs','heapDelta']:
  vals={a:[x[metric]for x in data if x['arm']==a and x['mode']==mode]for a in arms}
  result={a:{'median':statistics.median(v),'min':min(v),'max':max(v)}for a,v in vals.items()}
  if metric!='heapDelta':
   ratios=[next(x[metric]for x in data if x['round']==r and x['arm']=='after' and x['mode']==mode)/next(x[metric]for x in data if x['round']==r and x['arm']=='before' and x['mode']==mode)for r in range(6)];result['pairedRatios']=ratios;result['medianRatio']=statistics.median(ratios)
  summary[mode][metric]=result
(out/'cost-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

final=inventory();(out/'inputs-after.json').write_text(json.dumps(final,indent=2));assert final==initial;(out/'complete.json').write_text(json.dumps({'runs':len(data),'exit':0,'inputsUnchanged':True}))
