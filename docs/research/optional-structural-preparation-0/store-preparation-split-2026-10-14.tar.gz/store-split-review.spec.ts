import { describe, expect, it } from 'vitest';
import { StructuralStore } from './structural-store';
import { prepareStructuralTarget } from './prepare-structural-target';

function seed() {
  const store = new StructuralStore<string>();
  store.createSubject(1, 'a'); store.createSubject(2, 'b'); store.createSubject(3, 'c');
  store.tombstoneSubject(3, 'c', true);
  return store;
}
describe('independent store planner split', () => {
  it('prepares without mutation, then rekeys/removes/restores with exact lifetime revisions and order', () => {
    const store = seed();
    const a = store.acquireSubjectHandleForKey('a')!;
    const before = [1,2,3].map(id => store.subjectRevision(id));
    const frontier = {};
    const plan = store.prepareTarget([{subjectId:1,key:'z'}, {subjectId:3,key:'c'}], [3,1], frontier, prepareStructuralTarget);
    expect(store.activeKeysSnapshot()).toEqual(['a','b']);
    expect([1,2,3].map(id => store.subjectRevision(id))).toEqual(before);
    store.installPreparedTarget(plan);
    expect(store.activeKeysSnapshot()).toEqual(['c','z']);
    expect(store.firstActiveKey()).toBe('c'); expect(store.lastActiveKey()).toBe('z');
    expect(store.subjectIdForKey('z')).toBe(1);
    expect(store.resolveSubjectHandle(a)).toMatchObject({state:'active', key:'z', subjectId:1});
    expect([1,2,3].map(id => store.subjectRevision(id))).toEqual(before.map(n => n+1));
    expect(store.stateForSubject(2)).toEqual({active:false,restoreAllowed:true});
    expect(store.activeOrderFrontier()).toBe(frontier);
  });
  it('does not bump revisions for an order-only change or an untouched tombstone', () => {
    const store = seed();
    const before = [1,2,3].map(id => store.subjectRevision(id));
    store.installPreparedTarget(store.prepareTarget([{subjectId:1,key:'a'},{subjectId:2,key:'b'}], [2,1], {}, prepareStructuralTarget));
    expect(store.activeKeysSnapshot()).toEqual(['b','a']);
    expect([1,2,3].map(id => store.subjectRevision(id))).toEqual(before);
  });
  it('refuses duplicate keys/identities, malformed order, missing and retired lifetimes without installation', () => {
    const store = seed(); store.retireSubject(3);
    const cases: Array<[Array<{subjectId:number;key:string}>,number[]]> = [
      [[{subjectId:1,key:'x'},{subjectId:2,key:'x'}],[1,2]],
      [[{subjectId:1,key:'x'},{subjectId:1,key:'y'}],[1,1]],
      [[{subjectId:1,key:'a'}],[2]],
      [[{subjectId:1,key:'a'}],[1,1]],
      [[{subjectId:4,key:'d'}],[4]],
      [[{subjectId:3,key:'c'}],[3]],
    ];
    const before = [1,2,3].map(id => store.subjectRevision(id));
    for (const [subjects,order] of cases) {
      expect(() => store.prepareTarget(subjects,order,{},prepareStructuralTarget)).toThrow();
      expect(store.activeKeysSnapshot()).toEqual(['a','b']);
      expect([1,2,3].map(id => store.subjectRevision(id))).toEqual(before);
    }
  });
  it('passes live readonly views, not cloned or frozen source maps', () => {
    const store = seed();
    let called = false;
    store.prepareTarget([{subjectId:1,key:'a'}],[1],{}, (states,revisions,subjects,order,frontier) => {
      called = true;
      expect(states).toBe(store['subjectStates']);
      expect(revisions).toBe(store['subjectRevisions']);
      expect(Object.isFrozen(states)).toBe(false);
      return prepareStructuralTarget(states,revisions,subjects,order,frontier);
    });
    expect(called).toBe(true);
    expect(store.activeKeysSnapshot()).toEqual(['a','b']);
  });
});
