from pathlib import Path
root=Path('/private/tmp/signaltree-store-preparation-20261014/packages/kernel/src/lib/physical')
p=root/'structural-store.ts'; s=p.read_text(); start=s.index('  prepareTarget('); end=s.index('\n  installPreparedTarget(',start); old=s[start:end]
body=old[old.index('    const subjectIds'):]; body=body.rsplit('\n  }',1)[0]
body=body.replace('this.subjectStates','sourceStates').replace('this.subjectRevisions','sourceRevisions').replace('this.subjectRevision(subjectId)','(sourceRevisions.get(subjectId) ?? 0)')
body='\n'.join(line[2:] if line.startswith('  ') else line for line in body.splitlines())
planner="""import type {
  ActiveNode,
  PreparedStructuralTarget,
  StructuralTargetSubject,
  SubjectLifetimeRecord,
} from './structural-store';

/** Detached planning; the StructuralStore retains installation authority. */
export function prepareStructuralTarget<K extends string | number>(
  sourceStates: ReadonlyMap<number, Readonly<SubjectLifetimeRecord<K>>>,
  sourceRevisions: ReadonlyMap<number, number>,
  subjects: readonly StructuralTargetSubject<K>[],
  order: readonly number[],
  orderFrontier: unknown
): PreparedStructuralTarget<K> {
"""+body+'\n}\n'
(root/'prepare-structural-target.ts').write_text(planner)
s="import type { prepareStructuralTarget } from './prepare-structural-target';\n"+s[:start]+"""  prepareTarget(
    subjects: readonly StructuralTargetSubject<K>[],
    order: readonly number[],
    orderFrontier: unknown,
    prepare: typeof prepareStructuralTarget<K>
  ): PreparedStructuralTarget<K> {
    return prepare(
      this.subjectStates,
      this.subjectRevisions,
      subjects,
      order,
      orderFrontier
    );
  }
"""+s[end:]
p.write_text(s)
p=root/'prepare-entity-target.ts'; s=p.read_text(); s="import { prepareStructuralTarget } from './prepare-structural-target';\n"+s; s=s.replace('    target.orderFrontier\n  );','    target.orderFrontier,\n    prepareStructuralTarget\n  );');p.write_text(s)
