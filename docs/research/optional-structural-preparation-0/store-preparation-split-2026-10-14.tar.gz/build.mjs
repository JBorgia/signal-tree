import {createRequire} from 'node:module';
const root='/private/tmp/signaltree-store-preparation-20261014';
const require=createRequire(root+'/package.json');
const {rollup}=require('rollup');
process.chdir(root+'/packages/kernel');
process.env.NX_TASK_TARGET_PROJECT='kernel';
process.env.NX_TASK_TARGET_TARGET='build';
process.env.NX_DAEMON='false';
try {
 const configs=require(root+'/packages/kernel/rollup.config.cjs');
 for(const config of Array.isArray(configs)?configs:[configs]){
  const bundle=await rollup(config);
  try {for(const output of Array.isArray(config.output)?config.output:[config.output])await bundle.write(output);}
  finally {await bundle.close();}
 }
 require('esbuild').stop();
 console.log('ALL_CONFIGS_WRITTEN_AND_CLOSED');
 process.exit(0);
}catch(e){console.error(e);process.exit(1);}
