import pathlib,subprocess,json,shutil,sys
cwd='/private/tmp/signaltree-v16-acceptance';r=pathlib.Path('/Users/jonathanborgia/code/signaltree/artifacts/v16-acceptance-20261014')
proof=json.loads((r/'selftest-8d-frozen.receipt.json').read_text())
assert proof['exit']==0 and proof['statusAfter']=='',proof
assert '84/84 gates PROVEN' in (r/'selftest-8d-frozen.log').read_text()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip()=='8d220643e0d4e34cbdbc6e55e6ef692b25d5e023'
assert subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)==''
dist=pathlib.Path(cwd)/'dist';assert not dist.is_symlink();shutil.rmtree(dist)
steps=[('final-build',['pnpm','nx','run-many','-t','build','--projects=kernel,angular,react,vue,solid','--parallel=1','--skip-nx-cache']),('final-versions',['node','-e',"for(const p of ['kernel','angular','react','vue','solid']){const v=require('./dist/packages/'+p+'/package.json').version; if(v!=='16.0.0-dev')throw Error(p+':'+v);console.log(p,v)}"]),('final-tarball',['node','tools/verify-tarball-consumer.mjs']),('final-consumer-types',['node','tools/verify-consumer-typecheck.mjs']),('final-angular-aot',['node','tools/verify-angular-aot-consumer.mjs']),('final-demo',['pnpm','nx','build','demo','--configuration=production','--skip-nx-cache']),('final-routes',['pnpm','run','smoke:routes']),('final-version-claims',['node','scripts/verify-version-claims.js']),('final-release-state',['node','scripts/verify-release-state.js'])]
for name,cmd in steps:
 result=subprocess.run([sys.executable,'/private/tmp/st-acceptance-run.py',name,cwd,*cmd])
 if result.returncode:sys.exit(result.returncode)
assert subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)==''
print('POST_MUTATION_ARTIFACTS_COMPLETE',flush=True)
