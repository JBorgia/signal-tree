import subprocess,sys
cwd='/private/tmp/signaltree-v16-acceptance'
for label,flags in [('gates-8d-frozen',['--release']),('selftest-8d-frozen',['--self-test','--release'])]:
 r=subprocess.run([sys.executable,'/private/tmp/st-acceptance-run.py',label,cwd,'node','tools/verify-gates.mjs',*flags])
 if r.returncode:sys.exit(r.returncode)
sys.exit(subprocess.run([sys.executable,'/private/tmp/st-final-artifacts.py']).returncode)
