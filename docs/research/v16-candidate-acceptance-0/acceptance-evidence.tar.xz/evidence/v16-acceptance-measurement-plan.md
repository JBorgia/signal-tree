# V16 acceptance measurement plan — independent read-only review

Reviewed 2026-10-14. Checkout: `/Users/jonathanborgia/.codex/worktrees/capture-point-owner/signaltree`, clean at `ecf0487862f08de0e6fc4ff8704cc5fa2e660b0f`. No tests, builds, benchmarks, gates or replay scripts executed. Only this report written. Commands below are proposed future execution, serially after the imminent gates release the host.

**Reuse is sufficient.** There is an executable four-part semantic characterization runner and parameterized whole-package CPU/heap replay. Neither the existing split measurements nor the standard performance gates establish complete-candidate cost against `19a5bd03`. The principal gaps are final artifact identity, current semantic verdict reconciliation, and a new matched comparison using those final bytes—not another architecture experiment.

## Identity and current authority

Read `RELEASE-CURRENT.md`, `.github/VALIDATION_GUIDE.md`, `docs/performance/measurement-contract.md`, and research packets `v16-candidate-acceptance-0`, `optional-structural-preparation-0`, `capture-cost-0`, `point-owner-cost-0`, and `member-point-composition-0`.

The acceptance packet supersedes earlier budget refusals: approved ceilings are bare production/development 11.75/14.10 KiB, entities 25.60/28.40 KiB, demo error 570 kB (warning remains 525 kB). This is cost-ceiling approval, not runtime neutrality or publication approval. HEAD differs from runtime `4742ecbcf8af8e225a618ce6555d04dc35b216f4` only in evidence/docs and budget/demo configuration. Record HEAD as the candidate; do not silently label the older experiment “final.”

Use Node 24.15.0 and pnpm 10.17.0. Clear any `NX_WORKSPACE_ROOT_PATH` pointing elsewhere. Freeze complete post-mutation package output, metadata, source SHA, lockfile, build command/exits and hashes. A sidecar asserting a commit does not independently prove a build came from it.

## 1. Full existing semantic characterization

From the candidate root, with a **new, precreated absolute output directory** in `SEM_OUT`:

```sh
node tools/run-semantics-supplemental.mjs current "$SEM_OUT/scalar.json"
node tools/run-semantics-supplemental.mjs current "$SEM_OUT/structural.json" structural
node tools/run-semantics-supplemental.mjs current "$SEM_OUT/composition.json" composition
node tools/run-semantics-supplemental.mjs current "$SEM_OUT/authority.json" authority
SEMANTICS_REPORT="$SEM_OUT/original-13.txt" NX_DAEMON=false NX_ISOLATE_PLUGINS=false pnpm nx test kernel --skip-nx-cache --testFile=src/enhancers/transactions/semantics-current.spec.ts --reporter=json --outputFile="$SEM_OUT/original-13-vitest.json"
```

Execute each command separately and retain its exit/stdout/stderr; do not let expected characterization exit 1 prevent later matrices from running. The supplemental runner exits 0 only when every row is held; unsupported, not-exercised and violated rows all produce 1, as do execution errors. Input drift produces 2. Therefore neither “exit 1 means runtime regression” nor “zero execution errors means semantics pass” is correct.

Inputs: `semantics-{contract,current-adapter,supplemental,structural,structural-domain,structural-adapter,composition,composition-domain,composition-adapter,authority}.ts` under `packages/kernel/src/enhancers/transactions/`, plus transitive kernel sources. Structural/composition/authority validate their frozen oracle manifests:

- `docs/audits/2026-09-23-semantics-structural/FROZEN-v2.json`
- `docs/audits/2026-09-23-semantics-composition/FROZEN-v3.json`
- `docs/audits/2026-09-23-semantics-authority/FROZEN.json`

The runner records loaded source hashes and checks working inputs again after execution. It bundles source with esbuild, not installed package artifacts. The original-13 spec tests execution integrity and reports semantic outcomes; green Vitest is not thirteen held semantics. Preserve runner selftests in the full kernel suite, including supplemental/composition/authority and authority-trace selftests.

**Baseline trap:** the CLI's `baseline` mode is hard-coded to `7ade0e3ecb25ff0d06da4355b5f7d67844e147b7`. It is not `19a5bd03`. Even `current` reports that historical revision in a field named `baseline`; interpret the actual loaded `inputs` and checkout identity. To characterize `19a5bd034d5ebef262f637c397bb41fe50a6a1e3`, run the same `current` commands from a separate exact-baseline source checkout. Compare harness/adapter/oracle hashes between checkouts before attributing verdict changes to runtime; if different, establish a separately recorded common harness overlay without changing oracle assertions. Do not casually change the hard-coded baseline in production tooling.

The controller's October 1 baseline is **628d302d**, with 35 scalar, 207 structural, 171 composition and 11 authority rows; it is useful historical evidence, not the requested cost baseline. Compare row IDs, assertions, capabilities, observations and failure reasons—not only totals. Explain every changed verdict and retain unsupported/refused/not-exercised distinctions. Refusal safety does not prove successful surgical settlement.

The 37 CPRF controls/36 work cases are useful narrower regressions, but `CPRF-replay-controls.py` reconstructs historical CPRF. Running it unchanged does not qualify HEAD. Similarly, `member-point-composition-0/run.mjs` patch lanes reconstruct experiments. Existing committed Nx tests and full suites exercise HEAD; do not substitute reconstructed lanes. `semantic-discoverability` is a documentation gate; `update-matrix` is a benchmark, neither runs the four semantic matrices.

## 2. Existing whole-graph CPU/heap replay

Portable scripts already accept package paths:

- `docs/research/capture-cost-0/replay/g1-long-timing/replay.mjs`
- `docs/research/capture-cost-0/replay/g1-comparison/replay.mjs`

Use `docs/research/capture-cost-0/st-cost-final-packages.tar.xz`, SHA-256 `514920267d3616d78285719422e0c5a9f57849890437bfcda712947fb9e7dc4d`, its adjacent receipt and `source-linkage.json`. Validate archive and **every lane file** against receipt when staging. It contains `baseline/kernel`, `original/kernel`, `optimized/kernel`; the first is linked to `19a5bd03`. These are historical artifacts; hashing confirms byte identity, while source/build provenance comes from the retained evidence. Stronger same-toolchain attribution requires rebuilding the baseline with a recorded comparable build, not merely relabeling archived bytes.

For commands below, `BASE_KERNEL` is the staged verified baseline package, `FINAL_KERNEL` the complete frozen final candidate package (each contains `dist/index.js`), and `COST_OUT` a new parent output directory. These are explicit future input variables, not already-created artifacts.

```sh
node docs/research/capture-cost-0/replay/g1-long-timing/replay.mjs --baseline-package "$BASE_KERNEL" --original-package "$BASE_KERNEL" --optimized-package "$FINAL_KERNEL" --output "$COST_OUT/long"
node docs/research/capture-cost-0/replay/g1-comparison/replay.mjs --baseline-package "$BASE_KERNEL" --original-package "$BASE_KERNEL" --optimized-package "$FINAL_KERNEL" --output "$COST_OUT/matrix"
```

Mapping both baseline and original slots to baseline deliberately reuses the unchanged three-slot runner with another same-arm observation. Record this mapping prominently: its output label `candidate` then means a second baseline, and `optimized` means complete HEAD. Compare optimized/baseline in matched ABC rounds; do not treat the duplicate baseline observations as independent rounds. Alternatively retain the archived original candidate in the middle slot for attribution, at the same process count.

These wrappers inventory all JS pre/post, preserve child/harness hashes, exact commands, timestamps, exits and raw output, reject nonempty output directories and fail on changed inputs/child failures. Add the external source/build/package-metadata receipt: their own inventories cover JS, not full provenance. They were packaged with syntax checks; this review did not execute the portable wrappers.

Long timing covers pure scalar and mixed-tree scalar, existing-row update, add/remove, and scalar/entity/mixed confirm/rollback. Counts are fixed: scalar 200,000/20,000 warmup; entity 50,000/5,000; add/remove 10,000/1,000; transactions 5,000/500. There are three rotated triads and two baseline A/A pairs, 26 child processes. Mixed workloads share a child in fixed order; isolation is per suite, not workload. Historical short scalar blocks remained below 50 ms even here. Report all samples, paired CPU and wall ratios and A/A spread; do not selectively lengthen/retry favorable cases.

The matrix wrapper runs 156 children across its 12 configs, including mixed bare/transaction-idle/pending fixtures at 32/128 trees, leaf scaling at 1/16/32/128 as configured, and a separate pure scalar fixture. Keep tree-count scaling separate from leaf-count scaling when tabulating. Its pending endpoint settles half confirm and half rollback: **it cannot supply separate disposition heap deltas or prove terminal handles collect while trees live**. It watches trees/row nodes and later destruction. Do not interpret its combined settlement endpoint as either disposition alone.

## 3. Reuse the stronger disposition/handle controls separately

Local inputs: `/Users/jonathanborgia/code/signaltree/artifacts/capture-cost-qualified-2026-10-14/{child.mjs,run.mjs,heap-quiescence.mjs,harness-negative-controls.json}`. The child supplies fresh-process per-workload timing and separate memory-confirm/memory-rollback, strong live trees, pending checks, dropped terminal handles and WeakRef collection before destruction.

Its driver is **not parameterized**: it uses relative `packages/{baseline,original,optimized}/kernel`, an absolute old worktree receipt path, and refuses existing runs. It cannot accept final candidate bytes against that historical receipt. Do not edit/reuse the original evidence directory or bypass identity checks. Stage the unchanged child/helper in a fresh measurement directory, baseline in its baseline slot and final package in its optimized slot. Representative exact child commands are:

```sh
NODE_ENV=production node --expose-gc "$QUAL_DIR/child.mjs" baseline tx-rollback 12000 16 1
NODE_ENV=production node --expose-gc "$QUAL_DIR/child.mjs" optimized tx-rollback 12000 16 1
NODE_ENV=production node --expose-gc "$QUAL_DIR/child.mjs" baseline memory-confirm 200 16 64
NODE_ENV=production node --expose-gc "$QUAL_DIR/child.mjs" optimized memory-confirm 200 16 64
NODE_ENV=production node --expose-gc "$QUAL_DIR/child.mjs" baseline memory-rollback 200 16 64
NODE_ENV=production node --expose-gc "$QUAL_DIR/child.mjs" optimized memory-rollback 200 16 64
```

Reuse the driver's fixed seeded six timing/three memory-round schedule and receipts through a separately recorded path/identity adaptation; this small harness preparation remains work to do, not an executable final-candidate driver already present. Its other timing configs are scalar 3,000,000 at 16/128 leaves, demanded derived 1,000,000/16, entity 300,000/16, confirm 12,000/16. Memory configs include bare 32 trees/16 or128 leaves, and each disposition at 16 trees/16 leaves, 64/16, 16/128. Baseline A/A timing controls exist; no comparable A/A memory schedule. Avoid unnecessarily running overlapping timing matrices twice: select and freeze coverage before execution.

For the optional planner path, also reuse `/Users/jonathanborgia/code/signaltree/artifacts/store-preparation-split-2026-10-14/cost/{cost.mjs,measure.py}`. Direct CLI:

```sh
NODE_ENV=production node --expose-gc "$PLANNER_CHILD" "$BASE_KERNEL/dist/index.js" rollback
NODE_ENV=production node --expose-gc "$PLANNER_CHILD" "$FINAL_KERNEL/dist/index.js" rollback
```

Repeat both with `confirm`; reuse six paired rounds, seed 241014, 500 warmups/5,000 measured, 16 rows. Stage its driver beside `baseline-kernel` and `candidate-kernel` graphs in a fresh directory, then `python3 "$PLANNER_COST_DIR/measure.py"`. The child wraps `__prepareTransitionTarget.prepareTarget` and requires 5,500 rollback/zero confirm calls. The hook exists in `19a5bd03` source, but execution compatibility/counts remain to be checked; do not weaken that assertion silently. This measures checked reversed-order setAll plus scalar transactions, not the point-update workload. Instrumentation is part of measured cost. Three post-job GCs provide a whole-process delta, not the qualified harness's convergence/handle control. Existing split results compare 5c29bceb to the split—not baseline to complete HEAD.

All these costs are synchronous checked operations, including reads/assertions and incidental GC, excluding explicit GC/setup/destruction and later deferred stabilization. Production runtime flags on unbundled ESM are not compile-folded browser bundles or framework-render latency. Whole-process post-GC deltas are not journal retained/dominator size; finite collection is not universal leak freedom. Mixed enhanced versus pure bare subtraction also changes fixture shape. No quiet-host certificate or statistical equivalence follows from A/A observations.

## 4. Meaningful remaining acceptance work

1. Finish the already-authorized registry `node tools/verify-gates.mjs --release` and mutation proof `node tools/verify-gates.mjs --self-test --release`, serially. Preserve first failures, BLIND/UNPROVEN/vacuous outcomes and restored-source hashes. Their competitor benchmarks/memory checks do not replace a two-version complete-candidate comparison.
2. After all mutations, discard known generated root `dist/` and rebuild restored source. Use the previously successful explicit form: `pnpm nx run-many -t build --projects=kernel,angular,react,vue,solid --parallel=1 --skip-nx-cache`. Then `node tools/verify-tarball-consumer.mjs`, `node tools/verify-consumer-typecheck.mjs`, `node tools/verify-angular-aot-consumer.mjs`. Run production demo and route smoke per validation guide. Freeze those final outputs before cost work. Do not measure dist while selftests may mutate it.
3. Reconcile current four-matrix and original-13 semantics by row. Existing expected failures/skips require dispositions; do not erase them or infer universal correctness from five green suites. Frozen-oracle mismatch, execution error or an unexplained changed verdict is actionable; historical unsupported features alone do not establish a new regression.
4. Complete matched whole-candidate CPU/heap evidence above after gates, with declared arm mapping, hashes, raw distributions and host conditions. Do not add percentage improvements from separate experiments or pool different harness versions. Report any remaining baseline-relative cost candidly; approved bundle ceilings are not a runtime performance threshold.

The earlier missing-Angular-dist check is already closed by `8342ec6b`'s exact-source five-package artifact follow-up. Packed resolution there did not establish strict consumer typing/AOT. Old bundle/demo failures remain valid historical results but are not current blockers merely because they exceeded superseded ceilings. No new architecture, public API, release, merge or ceiling decision is needed from this review.
