# V16 maintenance review

2026-10-14. Reviewed the five uncommitted files in `/Users/jonathanborgia/.codex/worktrees/capture-point-owner/signaltree` against their HEAD diff and actual source types/exports. No production edits, tests, builds or benchmarks performed. This is source review, not a passing-gate claim.

**No acceptance blocker demonstrated in these corrections.** The diff is four documentation updates plus the single `xz` alternative in the binary-suffix classifier. Runtime and existing test assertions are unchanged.

## Reader claims

- `packages/kernel/src/internals.ts:233–279` exports all five named readers; `packages/kernel/package.json` declares `./internals`. These are supported tooling seams, not newly invented root application APIs.
- `state-location-view.ts:15–41` supports structured property/entity segments and current location lookup using position, lifetimeId and optional fieldSegments. It does not parse dotted labels. Precision improvement, optional: say “locates positions/entity lifetimes as current structured addresses”; the reader consumes lifetime identity, rather than manufacturing or exposing new lifetime authority. Unreachable targets return undefined.
- `entity-membership-view.ts:23–55` exposes current ordered membership snapshots and structural-unit changes. The new prose does not promise an attempt log or historical inventory.
- `link-state-view.ts:9–55` exposes activity snapshots/events, not remote durable-persistence proof. Unlike several other readers, `linkStateReader` itself returns a nonoptional reader (`:146`); “check optional-reader availability” does not incorrectly declare every reader optional.
- `transaction-lifecycle-view.ts:12–68` supports pending snapshots, confirmed/rolled-back/refused observations, and explicit `pendingRetained` plus `consequencesReleased`. The new prose correctly avoids equating refusal with loss of settlement authority.
- `restoration-reader.ts:15–57` supports entry status, explicitly recorded transaction relations, and undo/redo/jump outcomes. “Lineage” is acceptable shorthand, but “recorded transaction lineage” would better preserve the type's limitation; it is not complete causal ancestry.
- `confirmed-turn-view.ts:17–37` defines optional fieldSegments (including [] for whole entity) and explicit before/after membership booleans. `internals.ts:130–136` copies those producer facts into the view. Retention is separately explicit; the text does not promise retained audit completeness.

The readers' methods provide observation/subscription, not mutation or settlement methods. Observation can install its own observation plumbing; the documentation only says it does not install enhancers, which is the appropriate narrower claim. Subscription cleanup and owned-tree teardown guidance is consistent with these interfaces.

`docs/README.md:9` replaces an unsupported publication assertion with the actual unreleased verification status; it does not infer publication from package version. The three reader blocks teach behavior and limits rather than merely listing names to appease the coverage scanner. Minor placement issue only: the kernel README block is currently beneath License; move it before License when convenient.

## Source-controls and nonvacuity

`tools/check-source-controls.mjs:49` adds only an anchored, case-insensitive `.xz` suffix to the existing binary-format exclusion policy. This fixes classification of compressed evidence; it does not skip a research directory, relax byte rules, or exempt `.xz.ts` text. Text NUL detection, exit behavior and the registry's constants.ts NUL mutation remain unchanged. As with existing `.gz`/`.png` handling, classification is by extension, not validated binary content; no stronger guarantee should be claimed.

Existing `--self-test` (`:76–102`) tests byte classification directly, not whether tracked files reach that classifier. Thus it alone could stay green if the file filter accidentally excluded all source. This is an existing coverage gap, not a weakened assertion in the proposed correction.

Suggested additional tests: `/private/tmp/v16-source-controls-regression.patch` adds a standalone Node test file that invokes the real checker against isolated temporary Git inventories. It asserts:

- .xz/.XZ and existing .gz/.png binary suffixes are excluded;
- NUL-bearing .ts, .md, unknown and extensionless files still fail with the precise filename/NUL diagnostic;
- .xz.ts, .XZ.md and files under an .xz-named directory still fail;
- clean TAB/LF/CR text is counted and accepted;
- the existing planted-NUL self-test remains successful.

The mixed positive and negative cases prevent an “exclude everything” implementation from passing. Removing xz acceptance would fail the xz controls; loosening matching to an unanchored substring would fail the text-name controls. This patch does not copy the production regexp or change production code.

**Patch is proposed, unapplied and unrun.** After parent gates finish, apply in an isolated checkout and run `node --test tools/check-source-controls.spec.mjs`; also retain the registered source-controls gate and its mutation proof. No passing result or mutation kill is asserted here. These maintenance corrections do not settle the other previously reported harness/environment failures or establish final combined acceptance.
