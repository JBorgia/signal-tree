import os, sys, json, subprocess, hashlib, datetime, pathlib
root=pathlib.Path('/Users/jonathanborgia/code/signaltree/artifacts/v16-acceptance-20261014')
name,cwd,*cmd=sys.argv[1:]
env=os.environ.copy();env['PATH']='/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin:'+env['PATH'];env['NX_DAEMON']='false';env['npm_config_cache']='/private/tmp/st-v16-acceptance-npm';env.pop('NX_WORKSPACE_ROOT_PATH',None)
log=root/(name+'.log'); receipt=root/(name+'.receipt.json')
if log.exists() or receipt.exists(): raise SystemExit('Refusing to overwrite prior evidence '+name)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
r={'command':cmd,'cwd':cwd,'started':now(),'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip(),'statusBefore':subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True),'node':subprocess.check_output(['node','-v'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['pnpm','-v'],env=env,text=True).strip()}
with log.open('w') as out: r['exit']=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
r.update(finished=now(),log=str(log),logSha256=sha(log),statusAfter=subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True),lockSha256=sha(pathlib.Path(cwd)/'pnpm-lock.yaml'))
package=pathlib.Path(cwd)/'dist/packages/kernel'
if package.exists() and name.endswith('build'):
 r.update(sourceRoot=cwd,packageRoot=str(package),packageInventory=[{'path':str(p.relative_to(package)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(package.rglob('*')) if p.is_file()])
r['installedLockSha256']=sha(pathlib.Path(cwd)/'node_modules/.pnpm/lock.yaml');r['dependencyRoot']=str((pathlib.Path(cwd)/'node_modules').resolve());r['frozenInstallReceipt']=str(root/'frozen-install.receipt.json');r['frozenInstallReceiptSha256']=sha(root/'frozen-install.receipt.json')
receipt.write_text(json.dumps(r,indent=2)+'\n'); print(json.dumps({'name':name,'exit':r['exit'],'receipt':str(receipt)}),flush=True);sys.exit(r['exit'])
