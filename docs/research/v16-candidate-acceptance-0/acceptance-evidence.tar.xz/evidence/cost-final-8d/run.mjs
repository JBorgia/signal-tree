// Prepared for explicit execution only after the coordinator certifies all mutations finished; no extra owner approval.
import assert from 'node:assert/strict';
import {spawnSync, execFileSync} from 'node:child_process';
import {readFileSync, writeFileSync, readdirSync, mkdirSync, lstatSync, cpSync, realpathSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname, join, resolve, isAbsolute, sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {loadavg, cpus, platform, arch, release} from 'node:os';
const root=dirname(fileURLToPath(import.meta.url));
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const json=p=>JSON.parse(readFileSync(p,'utf8'));
const save=(p,v)=>writeFileSync(p,JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const now=()=>new Date().toISOString();
function inventory(dir,prefix='') {
  assert.ok(lstatSync(dir).isDirectory()&&!lstatSync(dir).isSymbolicLink(),'real package directory required');
  return readdirSync(dir).sort().flatMap(name=>{
    const path=join(dir,name), rel=prefix+name, st=lstatSync(path);
    assert.ok(!st.isSymbolicLink(),'package symlink refused: '+path);
    if(st.isDirectory()) return inventory(path,rel+'/');
    assert.ok(st.isFile(),'non-regular package input: '+path);
    return [{path:rel,bytes:st.size,sha256:hash(path)}];
  });
}
function git(cwd,args){return execFileSync('git',args,{cwd,encoding:'utf8'}).trim();}
function sourceIdentity(spec) {
  assert.ok(isAbsolute(spec.sourceRoot)&&isAbsolute(spec.packageRoot));
  assert.match(spec.sourceCommit,/^[a-f0-9]{40}$/);
  const head=git(spec.sourceRoot,['rev-parse','HEAD']);
  assert.equal(head,spec.sourceCommit,'source HEAD mismatch');
  const status=git(spec.sourceRoot,['status','--porcelain','--untracked-files=no']);
  assert.equal(status,'','tracked source must be clean before freezing');
  return {head,status,sourceRoot:spec.sourceRoot,packageRoot:spec.packageRoot,
    lockHash:hash(join(spec.sourceRoot,'pnpm-lock.yaml')),
    rootPackageHash:hash(join(spec.sourceRoot,'package.json')),
    nodeVersionFile:readFileSync(join(spec.sourceRoot,'.nvmrc'),'utf8').trim(),
    dependencyRoot:realpathSync(join(spec.sourceRoot,'node_modules')),
    installedLockHash:hash(join(spec.sourceRoot,'node_modules/.pnpm/lock.yaml'))};
}
function toolchainIdentity(path,protocol) {
  assert.ok(isAbsolute(path));
  assert.equal(hash(path),protocol.toolchain.receiptSha256,'frozen install receipt mismatch');
  const receipt=json(path);
  assert.equal(receipt.exit,0);assert.equal(receipt.node,'v24.15.0');assert.equal(receipt.pnpm,'10.17.0');
  assert.equal(receipt.sourceCommit,protocol.toolchain.sourceCommit);
  assert.deepEqual(receipt.command,['pnpm','install','--frozen-lockfile']);
  assert.ok(Number.isFinite(Date.parse(receipt.receiptObservedAt)));
  assert.ok(receipt.limits?.trim(),'retain install timestamp limitation');
  assert.equal(receipt.sourceLockSha256,protocol.expectedSourceLockSha256);
  assert.equal(receipt.installedLockSha256,protocol.expectedInstalledLockSha256);
  assert.equal(hash(join(receipt.cwd,'pnpm-lock.yaml')),receipt.sourceLockSha256);
  const dependencyRoot=realpathSync(receipt.nodeModules);
  assert.equal(hash(join(dependencyRoot,'.pnpm/lock.yaml')),receipt.installedLockSha256);
  assert.equal(hash(receipt.log),receipt.logSha256);
  return {receipt,receiptPath:path,receiptHash:hash(path),dependencyRoot};
}
function buildIdentity(spec,toolchain,protocol) {
  assert.ok(isAbsolute(spec.buildReceipt));
  const receipt=json(spec.buildReceipt);
  assert.equal(receipt.sourceCommit,spec.sourceCommit);
  assert.equal(resolve(receipt.sourceRoot),resolve(spec.sourceRoot));
  assert.equal(resolve(receipt.cwd),resolve(spec.sourceRoot));
  assert.equal(resolve(receipt.packageRoot),resolve(spec.packageRoot));
  assert.ok(Array.isArray(receipt.command)&&receipt.command.length>0);
  assert.ok(receipt.command.every(x=>typeof x==='string'&&x.length));
  assert.equal(receipt.exit,0,'build receipt must record successful exit');
  assert.ok(Number.isFinite(Date.parse(receipt.started))&&Number.isFinite(Date.parse(receipt.finished)));
  assert.ok(Date.parse(receipt.finished)>=Date.parse(receipt.started));
  // Observed-completion bound, NOT a fabricated exact install finish timestamp.
  assert.ok(Date.parse(receipt.started)>=Date.parse(toolchain.receipt.receiptObservedAt),'build must follow observed frozen-install completion');
  assert.equal(receipt.node,'v24.15.0');assert.equal(receipt.pnpm,'10.17.0');
  assert.equal(receipt.lockSha256,protocol.expectedSourceLockSha256);
  assert.equal(receipt.statusBefore,'');assert.equal(receipt.statusAfter,'');
  assert.ok(isAbsolute(receipt.log));assert.equal(hash(receipt.log),receipt.logSha256);
  assert.deepEqual(receipt.packageInventory,inventory(spec.packageRoot),'build-time package seal mismatch');
  return {receipt,receiptPath:spec.buildReceipt,receiptHash:hash(spec.buildReceipt)};
}
function validateRow(row,s) {
  for(const key of ['kind','count','leaves'])assert.equal(row[key],s[key]);
  if(s.phase!=='construction')assert.equal(row.treeCount,s.trees);assert.equal(row.arm,s.childArm);
  assert.equal(row.node,process.version);assert.equal(row.nodeEnv,'production');assert.equal(row.ngDevMode,false);
  assert.ok(Number.isSafeInteger(row.pid)&&row.pid>0);
  if(s.phase==='timing'||s.phase==='construction') {
    assert.equal(row.timing.iterations,s.count);assert.equal(row.timing.warmup,s.phase==='construction'?s.warmup:Math.floor(s.count/10));
    if(s.phase==='construction'){assert.equal(row.validation.created,s.count);assert.equal(row.validation.allLeafValuesChecked,true);assert.equal(row.validation.independentTrees,true);if(s.kind==='construct-transactions')assert.equal(row.validation.pendingZero,true);}
    for(const k of ['elapsedMs','cpuNsPerOp','wallNsPerOp','opsPerSecond'])assert.ok(Number.isFinite(row.timing[k])&&row.timing[k]>0,k);
    for(const k of ['user','system'])assert.ok(Number.isFinite(row.timing.cpuMicros[k])&&row.timing.cpuMicros[k]>=0,k);
  } else {
    const bare=s.kind==='memory-bare', labels=bare?['idle','destroyed']:['idle','pending','settled-handles-dropped','cycles-1','cycles-2','destroyed'];
    assert.deepEqual(row.memory.checkpoints.map(x=>x.label),labels);
    assert.ok(Number.isFinite(row.memory.before.heapUsed));assert.equal(row.memory.alive,0);
    for(const c of row.memory.checkpoints){
      for(const k of ['heapUsed','deltaBytes','rounds','pending','treesAlive','handlesAlive','watchedHandles'])assert.ok(Number.isFinite(c[k]),k);
      assert.ok(c.rounds>=3&&c.rounds<=40);
      assert.equal(c.pending,c.label==='pending'?s.trees:0);
      assert.equal(c.treesAlive,c.label==='destroyed'?0:s.trees);
      assert.equal(c.handlesAlive,c.label==='pending'?s.trees:0);
    }
  }
}
const median=xs=>{const s=[...xs].sort((a,b)=>a-b);const i=Math.floor(s.length/2);return s.length%2?s[i]:(s[i-1]+s[i])/2;};
const stats=xs=>({values:xs,median:median(xs),min:Math.min(...xs),max:Math.max(...xs)});
function summarize(rows,protocol) {
  const timing={},memory={},construction={};
  for(const cfg of protocol.timingConfigs){
    const samples=rows.filter(r=>r.spec.configId===cfg.id);
    assert.equal(samples.length,18);
    const metrics={};
    for(const metric of ['wallNsPerOp','cpuNsPerOp']){
      const paired=[];
      for(let round=0;round<6;round++){
        const value=label=>samples.find(r=>r.spec.round===round&&r.spec.label===label).row.timing[metric];
        const a=value('baseline-A'),b=value('baseline-B'),c=value('candidate');
        paired.push({round,baselineA:a,baselineB:b,candidate:c,candidateOverA:c/a,candidateOverB:c/b,candidateOverBaselineMean:c/((a+b)/2),baselineBOverA:b/a});
      }
      metrics[metric]={paired,primaryRatio:stats(paired.map(x=>x.candidateOverBaselineMean)),candidateOverA:stats(paired.map(x=>x.candidateOverA)),candidateOverB:stats(paired.map(x=>x.candidateOverB)),aaRatio:stats(paired.map(x=>x.baselineBOverA))};
    }
    timing[cfg.id]={metrics,shortBlocks:samples.filter(x=>x.row.timing.elapsedMs<100).map(x=>({id:x.spec.id,elapsedMs:x.row.timing.elapsedMs}))};
  }
  for(const cfg of protocol.memoryConfigs){
    const samples=rows.filter(r=>r.spec.configId===cfg.id);assert.equal(samples.length,6);
    const labels=samples[0].row.memory.checkpoints.map(x=>x.label);
    memory[cfg.id]=Object.fromEntries(labels.map(label=>{
      const value=(round,arm)=>samples.find(r=>r.spec.round===round&&r.spec.label===arm).row.memory.checkpoints.find(c=>c.label===label).deltaBytes;
      return [label,{baseline:stats([0,1,2].map(r=>value(r,'baseline'))),candidate:stats([0,1,2].map(r=>value(r,'candidate'))),pairedCandidateMinusBaselineBytes:stats([0,1,2].map(r=>value(r,'candidate')-value(r,'baseline')))}];
    }));
  }
  for(const cfg of protocol.constructionConfigs){
    const samples=rows.filter(r=>r.spec.configId===cfg.id);assert.equal(samples.length,12);
    construction[cfg.id]={metrics:Object.fromEntries(['wallNsPerOp','cpuNsPerOp'].map(metric=>{
      const paired=Array.from({length:6},(_,round)=>{
        const value=label=>samples.find(r=>r.spec.round===round&&r.spec.label===label).row.timing[metric];
        const baseline=value('baseline'),candidate=value('candidate');
        return {round,baseline,candidate,ratio:candidate/baseline};
      });
      return [metric,{paired,ratio:stats(paired.map(x=>x.ratio))}];
    })),shortBlocks:samples.filter(x=>x.row.timing.elapsedMs<100).map(x=>({id:x.spec.id,elapsedMs:x.row.timing.elapsedMs}))};
  }
  return {timing,memory,construction,limits:protocol.limits};
}
function main(){
  const args=process.argv.slice(2), sealing=args[0]==='--seal-inputs';
  const options=sealing?args.slice(1):args;
  assert.equal(options.length,sealing?4:8,'Use --seal-inputs --inputs ABS --output NEW_SEAL, or --inputs ABS --output NEW_RUN --input-seal ABS --input-seal-sha256 HASH');
  assert.equal(options[0],'--inputs');assert.equal(options[2],'--output');
  assert.ok(isAbsolute(options[1])&&isAbsolute(options[3]));
  if(!sealing){assert.equal(options[4],'--input-seal');assert.equal(options[6],'--input-seal-sha256');assert.ok(isAbsolute(options[5]));assert.match(options[7],/^[a-f0-9]{64}$/);}
  assert.equal(process.version,'v24.15.0');assert.ok(!process.env.NODE_OPTIONS);
  const seal=json(join(root,'preregistration-seal.json'));
  for(const [file,expected] of Object.entries(seal.files))assert.equal(hash(join(root,file)),expected,'preregistered file changed: '+file);
  const protocol=json(join(root,'protocol.json')),inputs=json(options[1]),inputsHash=hash(options[1]);
  assert.equal(inputs.baseline.sourceCommit,protocol.baseline.sourceCommit);
  assert.equal(inputs.candidate.sourceCommit,protocol.candidate.sourceCommit,'candidate must be approved 8d commit');
  assert.notEqual(inputs.candidate.sourceCommit,inputs.baseline.sourceCommit);
  assert.notEqual(realpathSync(inputs.candidate.sourceRoot),realpathSync(inputs.baseline.sourceRoot),'source alias');
  assert.notEqual(realpathSync(inputs.candidate.packageRoot),realpathSync(inputs.baseline.packageRoot),'package alias');
  const cert=inputs.coordinatorCertification;
  assert.equal(cert?.mutationsFinished,true);assert.ok(cert.coordinator?.trim()&&cert.evidence?.trim());
  assert.ok(Number.isFinite(Date.parse(cert.mutationsCompletedAt))&&Number.isFinite(Date.parse(cert.certifiedAt)));
  assert.ok(Date.parse(cert.certifiedAt)>=Date.parse(cert.mutationsCompletedAt));
  const toolchain=toolchainIdentity(inputs.toolchainReceipt,protocol);
  const identities=Object.fromEntries(['baseline','candidate'].map(arm=>[arm,{...sourceIdentity(inputs[arm]),build:buildIdentity(inputs[arm],toolchain,protocol),inventory:inventory(inputs[arm].packageRoot),metadata:json(join(inputs[arm].packageRoot,'package.json'))}]));
  for(const i of Object.values(identities)){
    assert.equal(i.metadata.name,'@signal-tree/kernel');assert.equal(i.lockHash,protocol.expectedSourceLockSha256);
    assert.equal(i.installedLockHash,protocol.expectedInstalledLockSha256);assert.equal(i.dependencyRoot,toolchain.dependencyRoot);
  }
  assert.ok(Date.parse(identities.candidate.build.receipt.started)>=Date.parse(cert.mutationsCompletedAt),'candidate rebuild must follow all mutations');
  const inventoryDigests=Object.fromEntries(Object.entries(identities).map(([arm,i])=>[arm,{full:digest(i.inventory),javascript:digest(i.inventory.filter(f=>f.path.endsWith('.js')))}]));
  assert.notEqual(inventoryDigests.baseline.full,inventoryDigests.candidate.full,'baseline-as-candidate: identical full packages');
  assert.notEqual(inventoryDigests.baseline.javascript,inventoryDigests.candidate.javascript,'baseline-as-candidate: identical JS graphs; stop for documented review');
  const frozen={preregistrationSealSha256:hash(join(root,'preregistration-seal.json')),inputsHash,inputs,identities,inventoryDigests,toolchain};
  if(sealing){save(options[3],{sealedAt:now(),...frozen});console.log(JSON.stringify({inputSeal:options[3],sha256:hash(options[3]),inventoryDigests,workloadsExecuted:0}));return;}
  assert.equal(hash(options[5]),options[7],'reviewed input seal digest mismatch');
  const inputSeal=json(options[5]);const {sealedAt,...expected}=inputSeal;
  assert.ok(Number.isFinite(Date.parse(sealedAt)));assert.deepEqual(frozen,expected,'inputs drifted from sealed final artifacts');
  const output=resolve(options[3]);
  for(const arm of ['baseline','candidate']){const pkg=resolve(inputs[arm].packageRoot);assert.ok(output!==pkg&&!output.startsWith(pkg+sep)&&!pkg.startsWith(output+sep),'output and input package paths must be disjoint');}
  // mkdir without recursive/exist_ok: never reuse even an empty prior run directory.
  mkdirSync(output);const runs=join(output,'runs');mkdirSync(runs);
  const packages=join(output,'packages');mkdirSync(packages);
  let status='preparing',failure,rows=[],receipts=[],after,identitiesUnchanged=false;
  const started=now();
  try {
    for(const f of [...Object.keys(seal.files),'preregistration-seal.json'])cpSync(join(root,f),join(output,f),{errorOnExist:true,force:false});
    save(join(output,'inputs.json'),inputs);save(join(output,'inputs-before.json'),identities);
    save(join(output,'toolchain-identity.json'),toolchain);save(join(output,'final-input-seal.json'),inputSeal);
    for(const [name,path] of Object.entries({sourceLock:join(toolchain.receipt.cwd,'pnpm-lock.yaml'),installedLock:join(toolchain.dependencyRoot,'.pnpm/lock.yaml'),installLog:toolchain.receipt.log}))writeFileSync(join(output,'toolchain-'+name),readFileSync(path),{flag:'wx'});
    for(const [logical,slot] of [['baseline','baseline'],['candidate','optimized']]){
      mkdirSync(join(packages,slot));cpSync(inputs[logical].packageRoot,join(packages,slot,'kernel'),{recursive:true,dereference:false,errorOnExist:true,force:false});
      assert.deepEqual(inventory(join(packages,slot,'kernel')),identities[logical].inventory);
      writeFileSync(join(output,logical+'-build.log'),readFileSync(identities[logical].build.receipt.log),{flag:'wx'});
      assert.equal(hash(join(output,logical+'-build.log')),identities[logical].build.receipt.logSha256);

    }
    const env={...process.env,NODE_ENV:'production'};
    save(join(output,'environment.json'),{started,node:process.version,v8:process.versions.v8,platform:platform(),arch:arch(),osRelease:release(),cpu:cpus(),load:loadavg(),nodeEnv:'production',nodeOptions:process.env.NODE_OPTIONS??null,invocation:process.argv,driverHash:hash(join(root,'run.mjs')),childHash:hash(join(root,'child.mjs')),helperHash:hash(join(root,'heap-quiescence.mjs')),constructionChildHash:hash(join(root,'construction-child.mjs')),inputsFileHash:inputsHash});
    function invoke(id,child,argv){
      const command=[process.execPath,'--expose-gc',join(output,child),...argv], start=now();
      const r=spawnSync(command[0],command.slice(1),{cwd:output,env,encoding:'utf8',timeout:180000,maxBuffer:4*1024*1024});
      writeFileSync(join(runs,id+'.stdout'),r.stdout??'',{flag:'wx'});writeFileSync(join(runs,id+'.stderr'),r.stderr??'',{flag:'wx'});
      const receipt={id,command,started:start,finished:now(),exit:r.status,signal:r.signal,error:r.error?.message??null,childHash:hash(join(output,child))};
      save(join(runs,id+'.receipt.json'),receipt);receipts.push(receipt);return r;
    }
    status='negative-controls';
    const positive=readFileSync(join(output,'child.mjs'),'utf8'),needle='delete h.p;';
    assert.equal(positive.split(needle).length-1,1);
    const mutant=positive.replace(needle,'/* negative control: retain h.p while tree stays live */');
    writeFileSync(join(output,'negative-held-child.mjs'),mutant,{flag:'wx'});
    const cycleNeedle="const p=h.t.transact(()=>{h.t.$.fields.f0(value);h.t.$.rows.updateOne('0',{value});});";
    assert.equal(positive.split(cycleNeedle).length-1,1);
    writeFileSync(join(output,'negative-noop-child.mjs'),positive.replace(cycleNeedle,'const p={confirm(){},rollback(){}};'),{flag:'wx'});
    const controls=[];
    for(const arm of ['baseline','optimized'])for(const c of protocol.negativeControls){
      const argv=[arm,...c.args],r=invoke('negative-'+arm+'-'+c.id,c.child,argv);
      const matched=r.status===1&&!r.signal&&!r.error&&r.stderr.includes('AssertionError')&&r.stderr.includes(c.expectedError);
      controls.push({arm,...c,matched});save(join(runs,'negative-'+arm+'-'+c.id+'.check.json'),controls.at(-1));
      assert.ok(matched,'negative control did not fail for the intended reason: '+c.id);
    }
    save(join(output,'negative-controls.json'),controls);
    status='measuring';
    for(const spec of protocol.schedule){
      const r=invoke(spec.id,spec.phase==='construction'?'construction-child.mjs':'child.mjs',[spec.childArm,spec.kind,String(spec.count),String(spec.leaves),String(spec.phase==='construction'?spec.warmup:spec.trees)]);
      assert.equal(r.status,0,'child failed: '+spec.id);assert.ok(!r.signal&&!r.error);
      const row=JSON.parse(r.stdout);validateRow(row,spec);rows.push({spec,row});
      save(join(runs,spec.id+'.validated.json'),{spec,row});
      console.log(JSON.stringify({id:spec.id,complete:rows.length,total:protocol.schedule.length}));
    }
    assert.equal(rows.length,204);
    save(join(output,'summary.json'),summarize(rows,protocol));status='complete';
  } catch(e){failure=e.stack??String(e);status='failed';process.exitCode=1;console.error(failure);}
  finally {
    try {
      after=Object.fromEntries(['baseline','candidate'].map(arm=>[arm,{...sourceIdentity(inputs[arm]),inventory:inventory(inputs[arm].packageRoot),stagedInventory:inventory(join(packages,arm==='baseline'?'baseline':'optimized','kernel'))}]));
      save(join(output,'inputs-after.json'),after);
      for(const arm of ['baseline','candidate']){
        assert.deepEqual(after[arm].inventory,identities[arm].inventory);
        assert.deepEqual(after[arm].stagedInventory,identities[arm].inventory);
        for(const key of ['head','lockHash','rootPackageHash','dependencyRoot','installedLockHash'])assert.equal(after[arm][key],identities[arm][key]);
        assert.equal(hash(inputs[arm].buildReceipt),identities[arm].build.receiptHash);
        assert.equal(hash(identities[arm].build.receipt.log),identities[arm].build.receipt.logSha256);
        assert.equal(hash(join(output,arm+'-build.log')),identities[arm].build.receipt.logSha256);

      }
      for(const [file,expected] of Object.entries(seal.files))assert.equal(hash(join(root,file)),expected);
      for(const f of ['child.mjs','construction-child.mjs','heap-quiescence.mjs','run.mjs','protocol.json'])assert.equal(hash(join(output,f)),seal.files[f]);
      assert.equal(hash(options[1]),inputsHash);
      assert.equal(hash(inputs.toolchainReceipt),toolchain.receiptHash);
      assert.deepEqual(toolchainIdentity(inputs.toolchainReceipt,protocol),toolchain);
      assert.equal(hash(join(output,'toolchain-sourceLock')),protocol.expectedSourceLockSha256);
      assert.equal(hash(join(output,'toolchain-installedLock')),protocol.expectedInstalledLockSha256);
      assert.equal(hash(join(output,'toolchain-installLog')),toolchain.receipt.logSha256);
      assert.equal(hash(options[5]),options[7]);
      identitiesUnchanged=true;
    } catch(e){failure=(failure??'')+'\nFinal identity verification: '+(e.stack??e);status='failed';process.exitCode=1;}
    save(join(output,'receipts.json'),receipts);
    save(join(output,'finished.json'),{started,finished:now(),status,completedSamples:rows.length,expectedSamples:204,expectedNegativeControls:8,childProcesses:receipts.length,failure:failure??null,identitiesUnchanged,load:loadavg()});
  }
}
try{main();}catch(e){console.error(e.stack??e);process.exitCode=1;}
