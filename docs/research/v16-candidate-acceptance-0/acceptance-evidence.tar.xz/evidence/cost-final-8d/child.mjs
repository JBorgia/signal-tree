globalThis.ngDevMode=false;
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {loadavg} from 'node:os';
import {quiesce} from './heap-quiescence.mjs';
const [arm,kind,countText,leavesText='16',treesText='1']=process.argv.slice(2);
const count=Number(countText), leaves=Number(leavesText), treeCount=Number(treesText);
assert.ok(['baseline','original','optimized'].includes(arm),'known artifact arm');
assert.ok(['scalar','derived','entity','tx-confirm','tx-rollback','memory-bare','memory-confirm','memory-rollback'].includes(kind),'known workload');
for(const [name,value] of Object.entries({count,leaves,treeCount}))assert.ok(Number.isSafeInteger(value)&&value>0,`${name} must be a positive safe integer`);
const dir=new URL(`./packages/${arm}/kernel/dist/`,import.meta.url);
const {signalTree,entityMap,transactions}=await import(new URL('index.js',dir));
const {peekInternalTransactionRuntime}=await import(new URL('enhancers/transactions/transactions.js',dir));
const result={arm,kind,count,leaves,treeCount,node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch,ngDevMode:false,nodeEnv:process.env.NODE_ENV,pid:process.pid,loadBefore:loadavg(),started:new Date().toISOString()};
function fixture(enhanced=false,mixed=false,derived=false){return signalTree({fields:Object.fromEntries(Array.from({length:leaves},(_,i)=>['f'+i,0])),...(mixed?{rows:entityMap()}: {})},{...(enhanced?{enhancers:[transactions()]}:{}),...(derived?{derived:$=>({double:()=>$.fields.f0()*2})}:{})});}
function init(enhanced,mixed,derived){const t=fixture(enhanced,mixed,derived);if(mixed)t.$.rows.setAll(Array.from({length:8},(_,i)=>({id:String(i),value:0})));return t;}
if(!kind.startsWith('memory')){
 const enhanced=kind.startsWith('tx-'),mixed=enhanced||kind==='entity',derived=kind==='derived';
 const t=init(enhanced,mixed,derived), row=mixed?t.$.rows.byIdOrFail('0'):null;
 let current=0;
 function step(i){
  if(enhanced){const prior=current;const p=t.transact(()=>{t.$.fields.f0(i);t.$.rows.updateOne('0',{value:i});});assert.equal(t.$.fields.f0(),i);assert.equal(row().value,i);assert.equal(peekInternalTransactionRuntime(t).getPendingTurnCount(),1);p[kind==='tx-confirm'?'confirm':'rollback']();current=kind==='tx-confirm'?i:prior;assert.equal(t.$.fields.f0(),current);assert.equal(row().value,current);assert.equal(peekInternalTransactionRuntime(t).getPendingTurnCount(),0);}
  else if(kind==='entity'){t.$.rows.updateOne('0',{value:i});assert.equal(row().value,i);}
  else{t.$.fields.f0(i);assert.equal(t.$.fields.f0(),i);if(derived)assert.equal(t.$.double(),i*2);}
 }
 try{const warmup=Math.floor(count/10);for(let i=1;i<=warmup;i++)step(i);await quiesce({label:'post-warmup'});const cpu=process.cpuUsage(),start=performance.now();for(let i=warmup+1;i<=warmup+count;i++)step(i);const elapsedMs=performance.now()-start,cpuUsed=process.cpuUsage(cpu);result.timing={warmup,iterations:count,elapsedMs,cpuMicros:cpuUsed,cpuNsPerOp:(cpuUsed.user+cpuUsed.system)*1000/count,wallNsPerOp:elapsedMs*1e6/count,opsPerSecond:count*1000/elapsedMs,scope:'checked operations including direct/derived reads and settlement; excludes setup, warmup, GC and destroy'};}finally{t.destroy();}
}else{
 const enhanced=kind!=='memory-bare';let held=[],treeRefs=[],handleRefs=[];
 const before=await quiesce({label:'before'});
 function populate(){for(let i=0;i<treeCount;i++){const t=init(enhanced,enhanced,false);assert.equal(t.$.fields.f0(),0);held.push({t});treeRefs.push(new WeakRef(t));}}
 populate();globalThis.held=held;
 const checkpoints=[];
 async function checkpoint(label){const m=await quiesce({label});const pending=enhanced?held.reduce((n,h)=>n+peekInternalTransactionRuntime(h.t).getPendingTurnCount(),0):0;
 const expected=label==='pending'?treeCount:0; assert.equal(pending,expected,'pending responsibility at '+label);
 const treesAlive=treeRefs.filter(r=>r.deref()!==undefined).length,handlesAlive=handleRefs.filter(r=>r.deref()!==undefined).length;
 assert.equal(treesAlive,label==='destroyed'?0:treeCount,'live tree sentinels at '+label);
 assert.equal(handlesAlive,label==='pending'?treeCount:0,'terminal handles must collect while trees remain alive at '+label);
 checkpoints.push({label,...m,deltaBytes:m.heapUsed-before.heapUsed,pending,treesAlive,handlesAlive,watchedHandles:handleRefs.length});} 
 await checkpoint('idle');
 if(enhanced){
  function pending(){for(const h of held){h.p=h.t.transact(()=>{h.t.$.fields.f0(1);h.t.$.rows.updateOne('0',{value:1});});assert.equal(h.t.$.fields.f0(),1);assert.equal(h.t.$.rows.byIdOrFail('0')().value,1);handleRefs.push(new WeakRef(h.p));}}
  pending();await checkpoint('pending');
  function settle(){for(let i=0;i<held.length;i++){const h=held[i];h.p[kind==='memory-confirm'?'confirm':'rollback']();const value=kind==='memory-confirm'?1:0;assert.equal(h.t.$.fields.f0(),value);assert.equal(h.t.$.rows.byIdOrFail('0')().value,value);assert.equal(peekInternalTransactionRuntime(h.t).getPendingTurnCount(),0);delete h.p;}}
  settle();await checkpoint('settled-handles-dropped');
  function cycle(offset){for(let j=1;j<=count;j++)for(const h of held){const prior=h.t.$.fields.f0(),value=offset+j+1;const p=h.t.transact(()=>{h.t.$.fields.f0(value);h.t.$.rows.updateOne('0',{value});});assert.equal(peekInternalTransactionRuntime(h.t).getPendingTurnCount(),1,'cycle must create pending responsibility');assert.equal(h.t.$.fields.f0(),value,'cycle speculative scalar value');assert.equal(h.t.$.rows.byIdOrFail('0')().value,value,'cycle speculative entity value');if(j===1||j===count)handleRefs.push(new WeakRef(p));p[kind==='memory-confirm'?'confirm':'rollback']();const expected=kind==='memory-confirm'?value:prior;assert.equal(h.t.$.fields.f0(),expected);assert.equal(h.t.$.rows.byIdOrFail('0')().value,expected);assert.equal(peekInternalTransactionRuntime(h.t).getPendingTurnCount(),0);}}
  cycle(0);await checkpoint('cycles-1');cycle(count);await checkpoint('cycles-2');
 }
 function destroy(){for(const h of held)h.t.destroy();}destroy();held=[];globalThis.held=undefined;await checkpoint('destroyed');
 result.memory={before,checkpoints,watchedTrees:treeRefs.length,watchedHandles:handleRefs.length,alive:treeRefs.filter(r=>r.deref()!==undefined).length+handleRefs.filter(r=>r.deref()!==undefined).length,metric:'whole-process post-GC heap deltas; not journal dominator sizes'};
}
result.loadAfter=loadavg();result.finished=new Date().toISOString();console.log(JSON.stringify(result));
