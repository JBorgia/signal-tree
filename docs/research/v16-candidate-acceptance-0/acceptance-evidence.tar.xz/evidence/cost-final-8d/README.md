# Complete-candidate cost preregistration — revision 5

**Preparation only. No measurements or workload controls executed.** Revision5 repins the test-policy-only successor; Revision3 addressed the three Euclid findings. Original preparation and revision2/revision3/revision4 directories/seals are untouched. `original-qualified-child.mjs` preserves the original copied child; `child.mjs` is now a separately identified revised harness. **Do not pool its results with earlier revisions/historical harnesses.**

## Fixed identities and final sealing

- Baseline source: `19a5bd034d5ebef262f637c397bb41fe50a6a1e3`.
- Candidate source: **`8d220643e0d4e34cbdbc6e55e6ef692b25d5e023`**, hard-bound in protocol and checked before any workload.
- Source and installed lock SHA-256: `5e1ccb86b533ff4241d8a6ae5ac32ee9a56c6e10a416a8d1be3322d0ba531239`.
- Frozen install: the exact receipt at `/Users/jonathanborgia/code/signaltree/artifacts/v16-acceptance-20261014/frozen-install.receipt.json`, whose digest is pinned in protocol. Its original installed-source commit `e4672b9e7efce02c1e42663f67d38bd621680981` is explicitly fixed separately from the successor candidate. Its command, observed exit0, Node/pnpm, source lock, installed lock and log are checked. The receipt is not required to claim installation at the later candidate commit. Both source checkouts must resolve node_modules to this same actual installed dependency root. Both source locks and installed locks are checked, before and after.

Read-only preparation verified the actual install source lock, installed lock and baseline source lock all equal the expected hash. The install receipt explicitly lacks instrumented start/finish timestamps. We preserve that limitation and use its **observed completion time** as a lower bound for subsequent builds, not as an invented install finish time. No replacement receipt or fabricated timestamps are required. Same-root/lock checks bind the provided provenance; they do not hash every installed dependency byte or independently prove past build execution.

**The baseline frozen-build receipt remains valid; its inventory will be revalidated. The successor candidate inventory remains pending the final post-mutation rebuild.** Fill a copy of `inputs.template.json` outside this preparation. The actual `/private/tmp/st-acceptance-run.py` wrapper's build receipts are supported: sourceRoot/packageRoot/cwd, full package inventory, command/timestamps/exit, clean statusBefore/statusAfter, sourceCommit, Node/pnpm, lockSha256 and log/hash. Use wrapper labels ending in `build` to obtain its package inventory. Do not rewrite receipts to assert missing evidence. Source commits must match actual clean checkouts. Candidate build must start after certified completion of all mutations; both builds must follow observed frozen-install completion.

`coordinatorCertification` records coordinator identity, actual mutation completion time, certification time and supporting log/receipt reference. **Coordinator certification after actual completion suffices; no additional owner notification/approval is required.** This is evidence, not a process lock. The coordinator must also arrange serial host availability.

After rebuilding, the metadata-only sealing command validates all provenance, captures complete inventories and their digests, and creates a new immutable input record:

```sh
node /private/tmp/v16-acceptance-cost-plan-20261014-r5/run.mjs --seal-inputs --inputs /ABS/completed-inputs.json --output /ABS/NEW-final-input-seal.json
```

This mode spawns no workload; it reads files and Git identity only. It prints the input-seal SHA-256 for coordinator/reviewer inspection. Candidate/baseline commits, real source paths and real package paths must differ. Both full-package and JS-graph inventories must differ; identical bytes fail closed for documented investigation, not an automatic A/A result labeled candidate. There is no identical-artifact override in this revision.

Eventual measurement command, **only after completion certification and review of the finalized seal**:

```sh
node /private/tmp/v16-acceptance-cost-plan-20261014-r5/run.mjs --inputs /ABS/completed-inputs.json --output /ABS/NEW-cost-run --input-seal /ABS/NEW-final-input-seal.json --input-seal-sha256 EXACT_REVIEWED_SHA256
```

The driver compares current inputs, receipt hashes, install identity, full inventories and inventory digests against that exact sealed record before spawning anything. The output parent must exist; output itself must not exist, even empty. Node24.15.0; unset NODE_OPTIONS. No automatic execution, polling, build/install command, resume or favorable retry exists.

## Unchanged measurement schedule

The 204 measurement IDs/configurations/seeded ordering are identical to prior revisions:

- 108 write timing:6 configs ×6 rounds ×baseline-A/candidate/baseline-B. Scalar3,000,000 at16/128 leaves; derived1,000,000/16; entity300,000/16; transaction confirm and rollback12,000/16. Fixed10% warmup.
- 48 memory:8 configs ×3 rounds ×baseline/candidate. Bare32 trees at16/128 leaves. Each disposition at16trees/16leaves,64/16,16/128;200 cycles in each of two blocks.
- 48 construction:bare/transactions ×16/128leaves ×6 paired rounds.128 measured trees after32 warmups, fresh prebuilt inputs, all measured trees retained together. Creation and enhancer construction timed; input allocation, postwarmup GC, leaf materialization/value/identity/independence checks and teardown outside. Creation, not just writes, is measured; no entity initialization claim.

Seed20261014 LCG/Fisher–Yates, fixed phases timing/memory/construction. Logical candidate uses the original child's `optimized` import slot; no original artifact arm. Timing primary ratio uses candidate divided by the arithmetic mean of both same-round baselines; retain individual ratios and B/A. Construction uses candidate/baseline. Memory retains signed whole-process deltas and paired byte differences by separate checkpoint/disposition. No confidence interval or equivalence verdict. Blocks below100ms flagged, not rerun. Every child has180s timeout and4MiB output limit.

## Revised cycle contract and eight controls

Before **each** repeated memory-cycle settlement, revised child asserts:

1. pending responsibility equals1;
2. speculative scalar equals the value authored by this cycle;
3. speculative entity value equals the same authored value.

Existing postsettlement scalar/entity and pending0 assertions, initial pending checks, sampled handle WeakRefs, live-tree checkpoints and collection checks remain unchanged. Only this repeated-cycle block changes in the positive qualified child. The stronger assertions can affect memory endpoints; this is a revised harness even though setup/measurement schedule is unchanged. Construction child and heap helper are byte-identical to revision2.

Eight scheduled pre-measurement negative controls: zero count, unknown workload, retained actual terminal handle, and **no-op repeated rollback cycle**, each against both arms. The no-op mutant replaces only the repeated-cycle transact expression with a dummy confirm/rollback object: initial real transaction/checkpoints remain intact. It must fail the new `cycle must create pending responsibility` assertion, closing the vacuous-cycle case. Each mutant is a separate saved script; positive child stays untouched. Controls must exit1 with the prescribed AssertionError, no timeout/signal/unrelated failure. Historical controls remain labeled prior evidence. **No fresh control kill is claimed yet.** Total eventual child invocations:204 measured +8 expected failures =212.

## Evidence and limits

The driver copies all complete packages (metadata/docs/declarations included) into a fresh output, rejects package symlinks/nonregular files, saves exact command/timestamps/exit/signal/error/script hashes and raw streams per child, and rechecks original/staged packages, source/dependency root/locks, build/install receipts/logs, preparation files and final input seal afterward. A summary is qualified only by `finished.json` status complete with identitiesUnchanged. First failures/incomplete output survive; no overwrite/resume.

Receipt/hash agreement establishes consistency with supplied provenance, not independent attestation that a command generated bytes. Current shared dependency-root identity is observed at sealing/run; the wrapper does not independently instrument every module resolution during the earlier build. Preserve that limitation and coordinator build provenance. Frozen install's original timestamps remain unknown.

Write timing is checked synchronous operation cost including assertions/reads/settlement and incidental GC. Its inherited “excludes GC” wording means explicit GC only; deferred flush is excluded. Construction has its own interval and excludes full read materialization. Unbundled production-runtime-flag ESM is not browser-folded code/framework latency. Heap movement convergence is finite heuristic evidence, not proof every deferred consequence settled; whole-process deltas are not journal/dominator ownership or universal leak freedom. Bare memory lacks rows present in enhanced fixtures. No quiet-host certificate or memory/construction A/A claim. Add/remove, broad reorder/restoration and all optional planner paths remain outside this bounded matrix. No overlapping long harness or production algorithm changes.

## Historical revision4 provenance-only delta

Candidate c1714eaef8fe96863bf3bcf84117378354175e51 changes verification proofs/docs; runtime sources match4742ecbc. The only package-directory difference from4742 is packages/kernel/README.md. Git source locks at baseline19a5, installed-source e467 and successor c171 all match the fixed expected hash. The install receipt/hash and dependency root stay unchanged; no new install claimed. Measurement schedule, all children, controls, assertions and analysis are byte-identical to revision3. Both final inventories remain pending rebuild/sealing; no measurements.

## Revision5 identity-only delta

Candidate is `8d220643e0d4e34cbdbc6e55e6ef692b25d5e023`. Git diff againstc171 contains only the browser budget test and acceptance rationale; the entire packages subtree is unchanged. Source lock hash is unchanged. The isolated install remains explicitly sourced at e467 and its receipt/locks are unchanged.

The baseline input template reuses the completed `baseline-frozen-build.receipt.json` at19a5 under the same fixed toolchain. Its original receipt/inventory binding is retained in `historical-c171-final-input-seal.json`; future metadata sealing will revalidate the baseline's actual files, not blindly trust that historical record. Candidate input points to `artifacts/v16-acceptance-20261014/final-build.receipt.json`; certification evidence points to `selftest-8d-frozen.receipt.json`. These are pending pipeline inputs, not inspected/completed results in this preparation. Completion fields remain false/placeholders.

R4 and the original c171 final-input seal remain untouched. Do not use the historical c171 seal as R5's run seal. Create a distinct final8d input seal only after proof completion, fresh final build and coordinator certification. No inventory or completion time is guessed. Schedule, construction/memory/timing children, controls, checks and analysis are unchanged; no workload executed.
