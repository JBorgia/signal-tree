globalThis.ngDevMode=false;
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {loadavg} from 'node:os';
import {quiesce} from './heap-quiescence.mjs';
const [arm,kind,countText,leavesText,warmupText]=process.argv.slice(2);
assert.ok(['baseline','optimized'].includes(arm));
assert.ok(['construct-bare','construct-transactions'].includes(kind));
const count=Number(countText),leaves=Number(leavesText),warmup=Number(warmupText);
for(const x of [count,leaves,warmup])assert.ok(Number.isSafeInteger(x)&&x>0);
assert.ok(count>=2,'independence requires multiple trees');
const {signalTree,transactions}=await import(new URL(`./packages/${arm}/kernel/dist/index.js`,import.meta.url));
const {peekInternalTransactionRuntime}=await import(new URL(`./packages/${arm}/kernel/dist/enhancers/transactions/transactions.js`,import.meta.url));
const enhanced=kind==='construct-transactions';
const input=i=>({fields:Object.fromEntries(Array.from({length:leaves},(_,k)=>['f'+k,i+k]))});
const construct=value=>enhanced?signalTree(value,{enhancers:[transactions()]}):signalTree(value);
const result={arm,kind,count,leaves,warmup,node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch,nodeEnv:process.env.NODE_ENV,ngDevMode:false,pid:process.pid,started:new Date().toISOString(),loadBefore:loadavg()};
// Warmups have distinct input objects and complete teardown before measurement.
for(let i=0;i<warmup;i++){
  const t=construct(input(i));
  try {assert.equal(t.$.fields.f0(),i);assert.equal(t.$.fields['f'+(leaves-1)](),i+leaves-1);}
  finally {t.destroy();}
}
const inputs=Array.from({length:count},(_,i)=>input(i));
assert.equal(new Set(inputs).size,count);assert.equal(new Set(inputs.map(x=>x.fields)).size,count);
const held=new Array(count);let created=0;
try {
  await quiesce({label:'construction-post-warmup'});
  const cpu=process.cpuUsage(),start=performance.now();
  for(let i=0;i<count;i++){held[i]=construct(inputs[i]);created++;}
  const elapsedMs=performance.now()-start,cpuUsed=process.cpuUsage(cpu);
  // Materialize/check all leaves after timing; the timed work is actual creation,
  // not an update loop, and does not include verification or destruction.
  assert.equal(new Set(held).size,count);
  assert.equal(new Set(held.map(t=>t.$.fields.f0)).size,count);
  for(let i=0;i<count;i++){
    assert.equal(Object.keys(held[i].$().fields).length,leaves);
    for(let k=0;k<leaves;k++)assert.equal(held[i].$.fields['f'+k](),i+k);
    if(enhanced)assert.equal(peekInternalTransactionRuntime(held[i]).getPendingTurnCount(),0);
  }
  held[0].$.fields.f0(-1000000);
  assert.equal(held[0].$.fields.f0(),-1000000);
  for(let i=1;i<count;i++)assert.equal(held[i].$.fields.f0(),i,'trees must be independent');
  result.timing={warmup,iterations:count,elapsedMs,cpuMicros:cpuUsed,cpuNsPerOp:(cpuUsed.user+cpuUsed.system)*1000/count,wallNsPerOp:elapsedMs*1e6/count,opsPerSecond:count*1000/elapsedMs,
    scope:'creation and retention of fresh scalar trees, including transaction enhancer creation when enabled; excludes input generation, warmup, explicit GC, validation, later deferred stabilization and teardown; includes incidental GC'};
  result.validation={created,allLeafValuesChecked:true,independentTrees:true,pendingZero:enhanced?true:null};
}finally {for(let i=0;i<created;i++)held[i].destroy();}
result.finished=new Date().toISOString();result.loadAfter=loadavg();console.log(JSON.stringify(result));
