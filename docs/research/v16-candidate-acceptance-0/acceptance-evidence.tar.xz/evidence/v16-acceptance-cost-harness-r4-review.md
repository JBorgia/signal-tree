# Independent r4 identity delta review

Static/metadata-only review of r4 against r3. No source-checkout inspection, builds, measurements, driver preflight or workload controls executed.

**No blocker demonstrated. The identity split is appropriate and preserves truthful install provenance.**

Reviewed r4 seal: `7b2d5f0b30f969ada0661aef07743f92c6238e456b9f8cf014a4acd510203165`. Every sealed file matches. The preserved revision3 seal is byte-identical to the reviewed r3 seal.

The executable diff is exactly two lines: toolchainIdentity compares the frozen-install receipt sourceCommit against protocol.toolchain.sourceCommit rather than protocol.candidate.sourceCommit; the candidate mismatch diagnostic now names c171. Protocol and inputs template pin candidate `c1714eaef8fe96863bf3bcf84117378354175e51`, while toolchain.sourceCommit independently pins `e4672b9e7efce02c1e42663f67d38bd621680981`. The receipt itself and its digest are unchanged. No claim that installation happened at c171 is introduced.

Metadata controls remain meaningful by source inspection:
- Old e467 candidate inputs fail the candidate pin; changing candidate to baseline cannot bypass that check.
- Substituting a different install receipt fails its pinned hash; the accepted receipt must still name e467, record the exact frozen install command, versions/exit, and expected source/installed lock identities.
- Both actual source/installed locks and real dependency roots still must match the pinned provenance before and after execution. Build receipt roots/commits, clean statuses, inventory/log hashes and timestamp bounds are unchanged.
- Candidate rebuild still must follow certified mutation completion; both builds follow observed install completion. The receipt's missing exact install timestamps remain explicit.
- Source/package alias rejection, identical full/JS inventory rejection, metadata-only final sealing and exact externally supplied final-seal digest verification are unchanged.

All 204 schedule entries, configuration/count/order, eight control definitions, analysis and measurement limits are unchanged. Positive child, original child, construction child, helper, build-receipt template and historical control evidence are unchanged. The scoped cycle mutant and stronger pre-settlement assertions remain as reviewed in r3. No fresh control kill or metadata-falsifier execution is claimed by this review.

Final artifact inventories/build receipts and the finalized input seal remain pending. The plan's statements that runtime source is unchanged and source locks match are carried provenance claims; I did not reread active checkouts to independently refresh those facts during this static delta review. Verify actual identities through the final sealing workflow after the active proof completes. Prior scientific limitations remain unchanged; this repin supplies no measurement result or release acceptance.
