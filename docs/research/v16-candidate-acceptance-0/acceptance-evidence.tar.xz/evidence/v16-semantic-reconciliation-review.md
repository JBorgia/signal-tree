# Independent semantic reconciliation

Read-only artifact/source review, 2026-10-14. No tests or benchmark execution.

Confirmed 424 matched row IDs: 188 held, 68 violated, 168 unsupported; zero verdict changes, errors or not-exercised rows. Scalar (35), composition (171) and authority (11) rows are entirely identical. Structural (207) has exactly 48 changed rows. Recursive comparison of the original result JSON reproduces semantic-trace-differences.json exactly, not merely its summary.

Verified every recorded input SHA-256 against Git source: baseline inputs match 19a5bd03; candidate inputs match ecf04878, with no mismatches in any suite. Runner, consumed semantics adapters/cases/contracts and frozen manifests match between arms. Both receipts use current mode; both reports have empty changedInputs. The report's `baseline: 7ade0e3...` is the runner's hardcoded historical baseline-mode constant, NOT the selected revision for these current-mode executions. Exact source attribution here comes from the verified input hashes. Node/esbuild dependency versions are not fingerprinted by these input maps; this is strong source/harness attribution, not a hermetic environment certificate.

The only changed fields are diagnostic rekey paths:
- 8 T06b rows: trace[0].result.reason.cause.pendingEffect.path.
- 32 T10 rows: trace[0].reason.cause.compensation[0].path.
- 8 T10 rows: trace[1].reason.cause.compensation[0].path.

Cause matches the D2 prepared-responsibility change. Baseline entity-signal.ts planRekey publication notified `${basePath}.${String(to)}` and captured the destination label. Current entity-signal.ts:587 constructs the transfer responsibility with `${basePath}.${String(m.fromKey)}` before installation; transactions.ts:2023–2033 preserves change.path in the structural effect. Thus A→destination reports rows.A instead of rows.destination; B→C reports rows.B instead of rows.C. Subject, position, ownerPath, beforeKey/afterKey, refusal classification, state/assertions and all other serialized fields are unchanged. Point lookup/planner extraction is not needed to explain this difference. This is an observable diagnostic-label change, not byte-identical behavior; paths are not identity or lookup authority.

Interpretation: no new regression demonstrated by these fixed supplemental cases. NOT a semantic green result. T06b's held assertion measures safe refusal and explicitly does not exercise successful surgery. T10 still violates the requirement that structural surgical rejection settle successfully (structural-drift refusal). The authority suite has zero held rows, one violated and ten unsupported. All eight suite invocations exit 1, consistent with supplementalExitCode requiring every row held. Existing violations remain violations; unsupported cases supply no positive coverage. This evidence neither repairs old limitations nor independently accepts the combined runtime or release.
