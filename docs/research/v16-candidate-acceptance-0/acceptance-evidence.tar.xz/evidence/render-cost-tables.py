import json,statistics,pathlib,sys
r=pathlib.Path(sys.argv[1]);d=json.loads((r/'cost-final-8d/summary.json').read_text())
lines=['# Matched complete-candidate costs','','Generated with `python3 render-cost-tables.py <evidence-directory>` from cost-final-8d/summary.json. Six timing rounds, three memory pairs, six construction pairs. All raw samples, protocol and qualifications remain authoritative.','','| Checked timing workload | Baseline ns/op median of round means | Candidate ns/op median | Paired wall ratio median (range) | CPU ratio median | Baseline A/A range |','|---|---:|---:|---:|---:|---:|']
for k,v in d['timing'].items():
 m=v['metrics']['wallNsPerOp'];p=m['paired'];q=m['primaryRatio'];a=m['aaRatio'];cpu=v['metrics']['cpuNsPerOp']['primaryRatio'];b=statistics.median([(x['baselineA']+x['baselineB'])/2 for x in p]);c=statistics.median([x['candidate'] for x in p]);lines.append(f"| {k} | {b:.1f} | {c:.1f} | {q['median']:.3f} ({q['min']:.3f}–{q['max']:.3f}) | {cpu['median']:.3f} | {a['min']:.3f}–{a['max']:.3f} |")
lines+=['','| Heap fixture/checkpoint | Baseline median MB | Candidate median MB | Paired additional bytes median |','|---|---:|---:|---:|']
for k,v in d['memory'].items():
 for label,x in v.items():lines.append(f"| {k}/{label} | {x['baseline']['median']/1e6:.3f} | {x['candidate']['median']/1e6:.3f} | {x['pairedCandidateMinusBaselineBytes']['median']:.0f} |")
lines+=['','| Construction fixture | Baseline µs/tree median | Candidate µs/tree median | Paired wall ratio median (range) | CPU ratio median | Blocks below 100 ms |','|---|---:|---:|---:|---:|---:|']
for k,v in d['construction'].items():
 m=v['metrics']['wallNsPerOp'];p=m['paired'];q=m['ratio'];c=v['metrics']['cpuNsPerOp']['ratio'];lines.append(f"| {k} | {statistics.median(x['baseline'] for x in p)/1000:.2f} | {statistics.median(x['candidate'] for x in p)/1000:.2f} | {q['median']:.3f} ({q['min']:.3f}–{q['max']:.3f}) | {c['median']:.3f} | {len(v['shortBlocks'])}/12 |")
(r/'cost-tables.md').write_text('\n'.join(lines)+'\n')
