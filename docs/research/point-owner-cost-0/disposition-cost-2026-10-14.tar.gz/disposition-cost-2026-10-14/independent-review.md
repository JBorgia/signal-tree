# Disposition candidate — bounded code review

**Accept for the existing internally produced effect records. No weakening of complete-key comparison or missing-disposition refusal/retry found.** No performance conclusion. This acceptance is not a claim of equivalence for arbitrary accessor/proxy objects that mutate during comparison.

Reviewed `/private/tmp/signaltree-point-owner-experiment-20261014` against `/Users/jonathanborgia/code/signaltree/artifacts/disposition-cost-2026-10-14/transactions.before.ts`. Source inspection and supplied evidence only: I ran no tests, benchmarks, or builds and changed no source/test files in this review.

## Semantics

- The original visits the union of both `Object.keys` lists, expected keys first. The helper visits expected keys, then actual keys that are not enumerable own expected keys. For stable records these are the same keys, in the same order, exactly once. `propertyIsEnumerable.call` is appropriate: `hasOwnProperty` alone would incorrectly skip an actual enumerable field shadowed by an expected non-enumerable field.
- Unknown enumerable string fields remain checked on either side. Missing and explicitly undefined remain equivalent through property reads. Inherited/non-enumerable properties can supply a value when the other side contributes the key, as before. Symbol keys and keys non-enumerable on both sides are excluded by both versions. “Complete-key” here means the incumbent enumerable-string union, not Reflect.ownKeys or exact property-descriptor equality.
- Scalar/opaque values retain `Object.is` (including NaN equality, signed-zero distinction and object identity). Membership before/after images retain deep comparison only for expected set effects with membership metadata. `subjectFieldSegments`, `fieldPresence`, and `plainBranchMembership` retain the same deep comparator and argument orientation. Kind mismatch and missing actual effect still refuse.
- Dense retained effect arrays populate the Map in identical order; duplicate keys remain last-entry-wins. The key function is unchanged, including structural add/remove/rekey collision by owner/position/subject. The kind guard still rejects the wrong structural kind at the same key. No new rule permits a missing expected effect.
- The validation call remains before lifecycle transition, physical rollback, scope retirement and consequence release. On mismatch it constructs the same typed refusal, publishes it and throws. Neither installed-operation nor expected-disposition cleanup moved. Retry and terminal idempotence therefore retain their ordering. The unchanged early return for an empty expected fold is not a new bypass.

## Supplied executable evidence inspected

`focused.log` reports 27 passing tests in `operation-disposition.spec.ts` and `transaction-safety.spec.ts`. The helper tests include missing/extra unknown facts, primitive and structured differential cases, inherited/non-enumerable properties, and missing/undefined equivalence. These are owner-run results, not independently rerun results.

Inspected the original `docs/research/operation-record-boundary-0/disposition.mjs`, replay loader, receipt, and both JSON results. The loader modifies exactly the retained-disposition seam to drop a subject effect; the receipt records one injection and exit 0 in both modes. Both probes assert first refusal leaves values [1,1], pending=1, scope open and durable consequences=0. Removing the fault allows confirm to retain [1,1] and release one consequence, or rollback to restore [0,0] and release none; a repeated terminal call leaves state unchanged.

Current source hashes match receipt source hashes:

- helper: `b2057275d651a6121cf0770a04b17f50a128f3d9bfd5cb2565ec54ec56296288`
- transactions: `0daa813c885bb26859682db562aef05761c0f62cd93c9f73d830b79311d6e898`
- original probe: `374fe7bcdafa5d907a40cfcdf13bf3941ad8a8b5eee93c061183452c6aa39d1c`

The transactions loaded hash differs intentionally because of that recorded fault injection. The helper and original probe loaded hashes match their source hashes. This evidence supports the requested missing-disposition and retry contract; it does not establish unrelated fault behavior.

## Desired additional falsifiers, if validation is expanded

No extra run is required for this bounded disposition; these are focused follow-ups, not a full-suite request. Do not run during benchmarks.

1. Table-test add/remove/rekey: same-key wrong kind, changed beforeKey/afterKey or placement metadata, and an extra unknown enumerable field in either operand. The current differential matrix primarily exercises set effects; source reasoning covers the structural branches.
2. Dense duplicate-key retained effects: corrupt last entry must refuse; restoring that last entry must allow retry. Both Map constructions choose the same last entry; pinning it would guard a future change.
3. Positive deep membership-image comparison plus one nested mismatch, without membership metadata (must remain identity-based), and symbol-only differences (must retain the incumbent exclusion). This records distinctions rather than broadening equality.
4. Accessor-mutation diagnostic only if arbitrary effect objects become supported: expected.before getter changes actual.before from 0 to 1 and returns 0. Original reads expected first and rejects; helper reads actual first and can accept. Also, actual keys are now enumerated after expected-field comparisons, and membership classification is hoisted. Thus neither unconditional observational equivalence nor safety against hostile descriptor mutation is established.

The last case is a source-derived counterexample, not an executed test or supported-production blocker. Producers construct ordinary records; `cloneTurnEffect` spreads effect properties, `foldOperationDisposition` clones expected effects, and authority `buildTurn` maps retained effects through that clone. These boundaries remove top-level accessors. The candidate adds no callback or public input accepting arbitrary effect records. Deep comparison of exotic nested values and externally tampered internal records remains outside this bounded acceptance; it should not be silently claimed as proven.

## Appendix — revised helper, read-only confirmation

Reviewed revised helper SHA-256 `b98196f9039ff9ba17457f2e360c690b439bacb0620c5ef363d82f90c94781b5` during the owner's benchmark. **Prior bounded acceptance stands; no worsening found.** No tests, builds, benchmarks, or source edits performed.

The revision restores the original expected-value-before-actual-value read order, snapshots both Object.keys lists before field comparison, and evaluates membership-image classification per field after reading both values. This addresses the specific evaluation-order counterexample above and the delayed actual-key enumeration/hoisted classification differences. Equality predicates, unknown enumerable string-field coverage, missing-actual refusal, and the caller's refusal/retry ordering remain unchanged for stable internal records.

One boundary remains: second-pass deduplication asks the expected object's *current* propertyIsEnumerable status, whereas the original Set deduplicated the initial key snapshots. Side-effecting accessors/proxies that add, remove, or change enumerability during comparison can therefore still change which keys are compared or cause repeated comparisons. This does not reopen the bounded acceptance for ordinary internally cloned records; it prevents upgrading that acceptance to arbitrary mutation-during-comparison equivalence.

The earlier executable evidence belongs to the preceding helper hash. Revised missing-disposition replays and tests remain pending, as the owner stated; this appendix supplies source confirmation only. The owner also reports that a bounded Rollup API wrapper using the same configs and explicit close succeeded after the CLI hung idle following emission. I did not independently inspect or rerun that build, and it supplies no additional equality/refusal evidence for this review.
