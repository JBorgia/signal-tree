import {createRequire} from 'node:module';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {dirname,resolve,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const out=dirname(fileURLToPath(import.meta.url)),root='/private/tmp/signaltree-point-owner-experiment-20261014';
if(existsSync(out+'/disposition-receipt.json'))throw Error('Preserve existing results');
const require=createRequire(root+'/package.json'),{build}=require('esbuild');const inputs=[];let injected=0;
const hash=x=>createHash('sha256').update(x).digest('hex');
const r=await build({entryPoints:[root+'/docs/research/operation-record-boundary-0/disposition.mjs'],bundle:true,platform:'node',format:'esm',target:'node24',write:false,nodePaths:[root+'/node_modules'],tsconfigRaw:{compilerOptions:{}},plugins:[{name:'current-experiment',setup(b){
 b.onResolve({filter:/^@signal-tree\/kernel\/adapter$/},()=>({path:root+'/packages/kernel/src/adapter.ts'}));
 b.onResolve({filter:/^@signal-tree\/kernel$/},()=>({path:root+'/packages/kernel/src/index.ts'}));
 b.onResolve({filter:/^@proof\//},a=>({path:a.path.replace('@proof',root)}));
 b.onLoad({filter:/\.(mjs|js|ts|json)$/},a=>{
  let contents=readFileSync(a.path,'utf8');const before=hash(contents);
  if(a.path===root+'/packages/kernel/src/enhancers/transactions/transactions.ts'){
   const anchor='const retained=authority.getPendingTurn(turnId)?.__effects ?? [];';
   if(contents.split(anchor).length!==2)throw Error('Unique fault seam missing');
   contents=contents.replace(anchor,'const retained=(authority.getPendingTurn(turnId)?.__effects ?? []).filter(e => !(globalThis as any).__dropDisposition?.(e));');injected++;
  }
  inputs.push({path:a.path,sourceHash:before,loadedHash:hash(contents)});
  return{contents,loader:extname(a.path)==='.ts'?'ts':extname(a.path)==='.json'?'json':'js',resolveDir:dirname(a.path)};
 });
}}]});
if(injected!==1)throw Error('Fault seam was not loaded exactly once');
writeFileSync(out+'/disposition-bundle.mjs',r.outputFiles[0].text);
const runs=[];
for(const mode of ['confirm','rollback']){
 const command=[out+'/disposition-bundle.mjs',mode],r=spawnSync(process.execPath,command,{encoding:'utf8',timeout:20000});
 writeFileSync(out+'/disposition-'+mode+'.json',r.stdout);writeFileSync(out+'/disposition-'+mode+'.stderr',r.stderr);
 runs.push({mode,exit:r.status,signal:r.signal});
}
writeFileSync(out+'/disposition-receipt.json',JSON.stringify({inputs,injected,runs},null,2));console.log(runs);if(runs.some(r=>r.exit!==0))process.exitCode=1;
