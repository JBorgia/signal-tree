import { describe, expect, it } from 'vitest';
import { deepEqual } from '../../lib/utils';
import type { TurnEffect } from './transactions';
import { sameOperationDisposition } from './operation-disposition';

const base = (): TurnEffect => ({kind: 'set', position: 1, path: 'x', ownerPath: '', before: 0, after: 1});
function legacy(expected: TurnEffect, actual: TurnEffect | undefined): boolean {
  return !!actual && actual.kind === expected.kind && [...new Set([...Object.keys(expected), ...Object.keys(actual)])].every(key => {
    const left = (expected as unknown as Record<string, unknown>)[key];
    const right = (actual as unknown as Record<string, unknown>)[key];
    return ((key === 'before' || key === 'after') && expected.kind === 'set' && expected.plainBranchMembership !== undefined) || key === 'subjectFieldSegments' || key === 'fieldPresence' || key === 'plainBranchMembership'
      ? deepEqual(right, left) : Object.is(right, left);
  });
}

describe('complete operation disposition comparison', () => {
  it('requires a retained disposition and detects changed or extra facts', () => {
    expect(sameOperationDisposition(base(), undefined)).toBe(false);
    expect(sameOperationDisposition(base(), {...base(), after: 2})).toBe(false);
    expect(sameOperationDisposition(base(), {...base(), unrecognizedFact: 1} as TurnEffect)).toBe(false);
    expect(sameOperationDisposition({...base(), unrecognizedFact: 1} as TurnEffect, base())).toBe(false);
    expect(sameOperationDisposition(base(), base())).toBe(true);
  });
  it('preserves Object.is for scalar values and deep comparison for structured coordinates', () => {
    expect(sameOperationDisposition({...base(), before: NaN}, {...base(), before: NaN})).toBe(true);
    expect(sameOperationDisposition({...base(), before: 0}, {...base(), before: -0})).toBe(false);
    expect(sameOperationDisposition({...base(), after: {}}, {...base(), after: {}})).toBe(false);
    expect(sameOperationDisposition({...base(), subjectFieldSegments: ['a.b']}, {...base(), subjectFieldSegments: ['a.b']})).toBe(true);
    expect(sameOperationDisposition({...base(), subjectFieldSegments: ['a.b']}, {...base(), subjectFieldSegments: ['a', 'b']})).toBe(false);
  });
  it('matches the prior complete-key contract across injected missing, extra and structured facts', () => {
    const values: unknown[] = [undefined, null, 0, -0, NaN, 1, '1', [], ['a.b'], {after: false}, {after: true}];
    let matches = 0, mismatches = 0;
    for (const key of ['before', 'after', 'subjectFieldSegments', 'fieldPresence', 'plainBranchMembership', 'extra']) {
      for (const x of values) for (const y of values) {
        // Deliberately malformed metadata exercises refusal comparison, not public producer types.
        const left = {...base(), [key]: x} as TurnEffect;
        const right = {...base(), [key]: y} as TurnEffect;
        const expected = legacy(left, right);
        if (expected) matches++; else mismatches++;
        expect(sameOperationDisposition(left, right)).toBe(expected);
      }
    }
    expect(matches).toBeGreaterThan(0); expect(mismatches).toBeGreaterThan(0);
  });
  it('retains missing/undefined and non-enumerable/inherited-key behavior', () => {
    const expected = base();
    Object.defineProperty(expected, 'extra', {value: 2, enumerable: false});
    const actual = {...base(), extra: 2} as TurnEffect;
    expect(sameOperationDisposition(expected, actual)).toBe(legacy(expected, actual));
    expect(sameOperationDisposition(base(), {...base(), extra: undefined} as TurnEffect)).toBe(true);
    const inherited = Object.assign(Object.create({extra: 2}), base()) as TurnEffect;
    expect(sameOperationDisposition(inherited, actual)).toBe(legacy(inherited, actual));
  });
});
