import pathlib,json,statistics
p=pathlib.Path(__file__).resolve().parent
assert json.loads((p/'finished.json').read_text())['samples']==24
runs={}
for r in json.loads((p/'receipts.json').read_text()):
 assert r['exit']==0
 d=json.loads((p/'runs'/(r['name']+'.json')).read_text());assert d['arm']==r['arm'] and d['kind']==r['kind']
 runs[(r['round'],r['arm'],r['kind'])]=d['timing']
result={}
for kind in ['tx-confirm','tx-rollback']:
 result[kind]={}
 for metric in ['wallNsPerOp','cpuNsPerOp']:
  ratios=[runs[(i,'after',kind)][metric]/runs[(i,'before',kind)][metric] for i in range(6)]
  result[kind][metric]={'medianBefore':statistics.median(runs[(i,'before',kind)][metric] for i in range(6)),'medianAfter':statistics.median(runs[(i,'after',kind)][metric] for i in range(6)),'ratios':ratios,'ratioMedian':statistics.median(ratios),'ratioMin':min(ratios),'ratioMax':max(ratios)}
(p/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
