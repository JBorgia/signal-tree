import { deepEqual } from '../../lib/utils';
import type { TurnEffect } from './transactions';

/** Compare the complete recorded disposition, including unknown own fields.
 * Missing and explicitly undefined fields retain the incumbent equivalence.
 * Membership images and structured coordinates retain their deep comparison. */
export function sameOperationDisposition(expected: TurnEffect, actual: TurnEffect | undefined): boolean {
  if (!actual || actual.kind !== expected.kind) return false;
  const left = expected as unknown as Record<string, unknown>;
  const right = actual as unknown as Record<string, unknown>;
  const expectedKeys = Object.keys(expected);
  const actualKeys = Object.keys(actual);
  const sameField = (key: string): boolean => {
    const expectedValue = left[key];
    const actualValue = right[key];
    const memberImage = (key === 'before' || key === 'after') && expected.kind === 'set' && expected.plainBranchMembership !== undefined;
    return memberImage || key === 'subjectFieldSegments' || key === 'fieldPresence' || key === 'plainBranchMembership'
      ? deepEqual(actualValue, expectedValue)
      : Object.is(actualValue, expectedValue);
  };
  for (const key of expectedKeys) if (!sameField(key)) return false;
  // Check fields present only on actual too; an allowlist would hide corruption.
  for (const key of actualKeys) {
    if (!Object.prototype.propertyIsEnumerable.call(expected, key) && !sameField(key)) return false;
  }
  return true;
}
