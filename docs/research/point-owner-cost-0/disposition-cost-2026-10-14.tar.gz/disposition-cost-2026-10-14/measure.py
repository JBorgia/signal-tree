import pathlib,subprocess,os,json,hashlib,random
root=pathlib.Path(__file__).resolve().parent
if (root/'protocol.json').exists():raise SystemExit('Refusing overwrite')
def hashes():return {arm:{str(p.relative_to(root/'packages'/arm)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'packages'/arm/'kernel'/'dist').rglob('*.js'))} for arm in ['before','after']}
initial=hashes();assert all(initial.values());rng=random.Random(2026101403);plan=[]
for repeat in range(6):
 batch=[{'round':repeat,'arm':arm,'kind':kind} for arm in initial for kind in ['tx-confirm','tx-rollback']];rng.shuffle(batch);plan+=batch
(root/'protocol.json').write_text(json.dumps({'plan':plan,'hashes':initial,'iterations':50000,'warmup':5000,'leaves':16,'rows':8,'seed':2026101403,'scope':'fresh processes, synchronous checked operations only; no host-isolation claim'},indent=2));(root/'runs').mkdir();receipts=[]
for i,p in enumerate(plan):
 name=f'{i:02d}-{p["arm"]}-{p["kind"]}';cmd=['/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node','--expose-gc',str(root/'child.mjs'),p['arm'],p['kind'],'50000','16','1']
 r=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'NODE_ENV':'production'},timeout=120)
 (root/'runs'/(name+'.json')).write_text(r.stdout);(root/'runs'/(name+'.stderr')).write_text(r.stderr);receipts.append({**p,'name':name,'exit':r.returncode,'command':cmd});(root/'receipts.json').write_text(json.dumps(receipts,indent=2));print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
assert hashes()==initial
(root/'finished.json').write_text(json.dumps({'samples':len(receipts),'failures':0,'hashesUnchanged':True}))
