# Point-owner experiment: independent performance interpretation

**Retain as a bounded optimization candidate.** The supplied experiment provides consistent evidence of lower synchronous rollback cost versus G1 for this workload, especially with more unrelated scalar leaves. I found no measurement blocker to retaining the candidate. This is not a semantic approval, architectural verdict, integration recommendation, or release-readiness claim. The host was not certified quiet.

Scope: read-only inspection of the six profiles, profiling/analysis scripts, patch and source identity, comparison scripts/protocol/receipts/completion/summary, and all 48 comparison outputs. No benchmarks, builds, tests, or source edits. I did not consult the other reviewers' verdicts. Only this report was written.

## Supported results

The comparison is three arms × two settlement modes × two leaf counts × four fresh-process rounds, each with 3,000 warmup and 30,000 timed operations. Each operation changes one scalar and one field of an existing row in a fixed eight-row EntityMap, checks optimistic values and pending=1, settles, then checks final values and pending=0. Increasing leaves changes unrelated scalar structure, not the number of effects or rows.

The following are **medians of within-round P1/G1 ratios**, not ratios of arm medians. “Lower” is relative reduction in measured time per operation, not throughput increase.

| Workload | Leaves | Wall time lower | Process CPU lower | Observed P1/G1 ratio ranges, wall / CPU |
|---|---:|---:|---:|---|
| Confirm | 16 | 1.1% | 1.4% | 0.983–1.018 / 0.970–1.009 |
| Confirm | 128 | 1.0% | 0.2% | 0.984–1.016 / 0.986–1.018 |
| Rollback | 16 | 33.7% | 22.6% | 0.633–0.677 / 0.740–0.781 |
| Rollback | 128 | 65.7% | 53.4% | 0.331–0.353 / 0.459–0.484 |

All eight rollback round comparisons favor P1 on both metrics. Confirmation crosses parity and supports no persuasive improvement claim. G1 median rollback wall time rises from 43.25 to 83.87 microseconds/op between 16 and 128 leaves; P1 is 28.38 and 28.60. This is consistent with avoiding traversal of unrelated structure for the tested point workload, not proof of constant complexity or general scaling.

P1 still costs approximately **28–31% more wall time and 28% more process CPU than baseline** on median within-round ratios across these cells. “Restores baseline performance,” “eliminates transaction overhead,” and general application/framework speedup claims are unsupported.

Numbers were independently recomputed by a read-only Python JSON parse of `comparison/runs`, keyed by receipt round/arm/kind/leaves, using the same metric division as `summarize.py`; every reported ratio matched `summary.json`. All 48 outputs matched the plan and successful receipts, with Node v24.15.0 / V8 13.6.233.17-node.48, production mode, one tree. Timed blocks span 412–2,521 ms, so none has the earlier sub-100-ms limitation. Recorded sample interval: 2026-10-15 03:20:50.760–03:21:39.507 UTC.

## Attribution and identity

- The six profiles are baseline/original/G1 × confirm/rollback, **not P1 profiles**. Independently summing sample intervals along parent chains reproduces G1 rollback's `step` 1,360.177 ms, `preparePointRealization` 574.890 ms and `indexStructuralOwnerPaths` 338.251 ms. Original shows the same hotspot; confirmation barely samples the index. This identifies a plausible target. It does not directly demonstrate P1's new call distribution or assign the observed savings exclusively to that function.
- `analyze.py` weights samples by `timeDeltas`, includes startup/warmup/forced GC/destruction, and aggregates by function name plus filename basename. Inclusive entries overlap and must not be summed. Same-named functions/anonymous frames can merge; line and full-module identity are lost. These sampled elapsed intervals are not process CPU accounting or exact per-operation costs. Profiling is one fixed-order run per cell at nominal 250-microsecond sampling; use it diagnostically, not as a comparative benchmark or Amdahl forecast.
- I rehashed all 98 recorded dist JavaScript files per comparison arm and the child; all match the comparison protocol. `finished.json` reports 48 samples, no failures, unchanged artifact hashes. Optimized versus P1 differs in exactly one recorded JavaScript module: `lib/internals/causal-runtime/tree-realization-adapter.js`. The temporary adapter source hash matches `source-identity.json` (`c3fec9f52a71aba93314cb1715003b27084548cf4f9914b4deb548299e2faea0`). These are strong identity controls for this experiment, not a complete reproducible source-to-build attestation.
- The patch routes structural/plain-branch-membership effects to the existing full index; point effects resolve visible owners through structured registry addresses with fallback. That matches the proposed optimization's scope. Structural performance and fallback behavior were not exercised by this benchmark.

## Controls and interpretation limits

1. **Synchronous checked-loop cost only.** The timer ends without draining deferred consequences. Reads, assertions, runtime lookups, incidental GC and background runtime work during the interval count; setup, warmup, explicit preloop quiescence and destroy do not. The protocol correctly states this, but the child output's “excludes ... GC” label remains misleading. CPU is whole-process user+system CPU, potentially across runtime threads, not main-thread latency; it can exceed wall time. Neither metric includes all lifecycle work.
2. **Descriptive repeated evidence, not host isolation.** Seeded shuffled rounds and fresh processes reduce order/carryover confounding. Four samples per cell, one seed, and no duplicated A/A arm in this comparison do not quantify same-build noise or establish confidence bounds. Within-round ratios pair different sequential processes, not simultaneous matched host conditions. The large, consistent rollback effect supports candidate status; the small confirmation differences do not. Load averages cannot certify quietness. Fixed warmup is not a demonstrated steady-state criterion.
3. **Narrow applicability.** One shallow visible collection owner, two point effects, serial successful settlement, default history and demanded reads are tested. No deep addresses, multiple owners, changing row counts, structural/fallback cases, overlapping turns, conflict/refusal/failure paths, framework subscribers, or varying effect counts. There are no P1 heap or collectability results in this comparison. Do not transfer G1's prior memory outcomes to P1 or claim lower retained heap from lower CPU.
4. **Preservation gaps, not evidence of corrupted results.** `run.py` hashes dist `*.js`, but does not pin all package metadata/dependencies, quiescence helper or runner bytes in the comparison protocol. It also permits an existing output directory and overwrites matching files; a rerun could replace first results and leave a stale `finished.json` if interrupted. The currently supplied plan/48 receipts/outputs are consistent, so this is a future reproducibility hazard rather than a demonstrated failure here. Archive the present evidence immutably if keeping it as a decision record.
5. **Candidate retention versus correctness.** The assertions establish useful behavior for the measured operations, not equivalence of sparse/full owner resolution. Visibility, aliasing, stale addresses, omission rules and fallback semantics require their own correctness evidence. No performance finding here requires discarding the candidate; none licenses bypassing that semantic review.

Suggested retained claim: “In this archived Node experiment, P1 consistently reduced checked synchronous rollback wall time and process CPU versus G1 for one-scalar/one-row updates at 16 and 128 leaves. The larger gain at 128 leaves is consistent with avoiding unrelated owner-index traversal. Confirmation showed no persuasive change, and P1 remained slower than the older baseline.”
