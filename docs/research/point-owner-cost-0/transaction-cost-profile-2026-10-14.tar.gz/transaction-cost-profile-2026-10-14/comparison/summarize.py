import pathlib,json,statistics,collections,math
root=pathlib.Path(__file__).resolve().parent
finish=json.loads((root/'finished.json').read_text());assert finish['samples']==48 and finish['failures']==0
receipts=json.loads((root/'receipts.json').read_text());assert len(receipts)==48
samples={};groups=collections.defaultdict(list)
for receipt in receipts:
 assert receipt['exit']==0
 d=json.loads((root/'runs'/(receipt['name']+'.json')).read_text())
 assert (d['arm'],d['kind'],d['leaves'])==(receipt['arm'],receipt['kind'],receipt['leaves'])
 for key in ['wallNsPerOp','cpuNsPerOp']:assert math.isfinite(d['timing'][key]) and d['timing'][key]>0
 samples[(receipt['round'],d['arm'],d['kind'],d['leaves'])]=d['timing']
 groups[(d['kind'],d['leaves'],d['arm'])].append(d['timing'])
output=[]
for kind in ['tx-confirm','tx-rollback']:
 for leaves in [16,128]:
  row={'kind':kind,'leaves':leaves,'nPerArm':4}
  for metric in ['wallNsPerOp','cpuNsPerOp']:
   row[metric]={'medianByArm':{a:statistics.median(v[metric] for v in groups[(kind,leaves,a)]) for a in ['baseline','optimized','p1']}}
   for denom in ['baseline','optimized']:
    ratios=[samples[(r,'p1',kind,leaves)][metric]/samples[(r,denom,kind,leaves)][metric] for r in range(4)]
    row[metric]['p1/'+denom]={'min':min(ratios),'median':statistics.median(ratios),'max':max(ratios),'all':ratios}
  output.append(row)
(root/'summary.json').write_text(json.dumps(output,indent=2))
for r in output:print(r['kind'],r['leaves'],json.dumps(r['wallNsPerOp']))
