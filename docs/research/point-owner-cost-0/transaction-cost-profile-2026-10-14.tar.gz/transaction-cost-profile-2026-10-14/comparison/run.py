import pathlib,subprocess,os,json,random,hashlib
root=pathlib.Path(__file__).resolve().parent;node='/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node'
def hashes():
 return {arm:{str(f.relative_to(root/'packages'/arm)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((root/'packages'/arm/'kernel'/'dist').rglob('*.js'))} for arm in ['baseline','optimized','p1']}
if any((root/name).exists() for name in ['protocol.json','receipts.json','finished.json','runs']):
 raise SystemExit('Refusing to overwrite existing experiment; copy scripts and packages into a fresh directory')
initial=hashes();assert all(initial.values())
plan=[];rng=random.Random(2026101402)
for repeat in range(4):
 batch=[{'round':repeat,'arm':arm,'kind':kind,'leaves':leaves} for arm in initial for kind in ['tx-confirm','tx-rollback'] for leaves in [16,128]]
 rng.shuffle(batch);plan+=batch
protocol={'seed':2026101402,'iterations':30000,'warmup':3000,'plan':plan,'artifacts':initial,'arms':{'baseline':'19a5bd03','optimized':'4b37f3f G1','p1':'4b37f3f plus point-owner-experiment.patch, temporary checkout'},'childSha256':hashlib.sha256((root/'child.mjs').read_bytes()).hexdigest(),'scope':'synchronous checked operation loop; deferred stabilization excluded; incidental GC included; host is not certified quiet'}
(root/'protocol.json').write_text(json.dumps(protocol,indent=2));(root/'runs').mkdir(exist_ok=True)
receipts=[]
for i,row in enumerate(plan):
 name=f'{i:02d}-{row["arm"]}-{row["kind"]}-{row["leaves"]}'
 command=[node,'--expose-gc',str(root/'child.mjs'),row['arm'],row['kind'],'30000',str(row['leaves']),'1']
 result=subprocess.run(command,capture_output=True,text=True,env={**os.environ,'NODE_ENV':'production'},timeout=120)
 (root/'runs'/f'{name}.json').write_text(result.stdout);(root/'runs'/f'{name}.stderr').write_text(result.stderr)
 receipts.append({**row,'name':name,'exit':result.returncode,'command':command});(root/'receipts.json').write_text(json.dumps(receipts,indent=2))
 print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
assert hashes()==initial,'artifacts changed during experiment'
(root/'finished.json').write_text(json.dumps({'samples':len(receipts),'failures':0,'artifactHashesUnchanged':True},indent=2))
