# Point-owner candidate: independent bounded acceptance

**Accept within the implemented scope; no concrete blocker found.** This is correctness acceptance for the nonstructural, non-membership lookup optimization, not performance or release sign-off.

Reviewed `/private/tmp/signaltree-point-owner-experiment-20261014`, supplied archive of `4b37f3f`. Candidate SHA-256 (`packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter.ts`): `c3fec9f52a71aba93314cb1715003b27084548cf4f9914b4deb548299e2faea0`. Added only `packages/kernel/src/lib/point-owner-review.spec.ts`; did not alter the candidate or owner's `point-owner-resolution-cost.spec.ts` (SHA-256 `d543a1aeb17a6de17e4a3001a1aed74128f443dcba291e9d8b87b1b08adfe038`). Hashes rechecked after testing.

## Why the prior objection is addressed

`preparePointRealization` retains full indexing whenever any effect is structural or carries plain-branch membership. `indexPointOwnerPaths` only accepts enumerable own data-property steps, rejects the walker's excluded keys and depths beyond 32, checks collection shape and the first owned position, and requires the diagnostic owner path. An unsupported owner discards the sparse attempt and returns the complete incumbent index. Hidden retained storage therefore cannot become a successful fast-path hit solely because its position matches. No persistent node cache or public contract was added.

The base revision is captured before indexing; post-preparation and pre-install checks remain. Subject resolution still uses lifetime identity and the active key, rather than interpreting row keys from registry addresses.

## Executable adversarial evidence

Seven new tests passed:

1. Registry address deliberately points to another live collection: full traversal occurs; mixed scalar/entity rollback restores its actual target and leaves the wrong collection unchanged.
2. Whole-value omission hides the ancestor branch: its property is demonstrably non-enumerable; direct preparation falls back and returns undefined, without reactivating it.
3. Whole-value omission hides the collection itself: same result.
4. A one-shot write injected during registry lookup changes physical revision: preparation throws the reentry error and leaves the target row uncompensated.
5. A write between preparation and installation makes the plan stale: installation throws without changing the row.
6. Rekey moves the existing lifetime: point realization resolves the new key and restores the correct value.
7. Remove/add at the historical key creates a fresh lifetime: the retired subject cannot prepare against the replacement row, whose value remains unchanged.

These direct preparation tests deliberately isolate the owner lookup and physical guards; they do not claim to exercise transaction admission. Test 1 exercises public mixed rollback. The reentry test injects a callback through an internal registry spy to test the guard deterministically; it is not a claim that normal address lookup calls application callbacks.

Existing suites also passed: designated collection omission, heterogeneous atomicity, and literal dotted collection restoration/rollback: **118 tests across 3 files**. Total bounded validation: **125 passing tests across 4 files**.

## Commands and first failure

Node `24.15.0`, pnpm `10.17.0`; commands run from the temp archive:

```sh
NX_DAEMON=false NX_ISOLATE_PLUGINS=false pnpm nx test kernel --testFile=packages/kernel/src/lib/point-owner-review.spec.ts --skipNxCache
NX_DAEMON=false NX_ISOLATE_PLUGINS=false pnpm nx test kernel --testFile=packages/kernel/src/enhancers/restoration/designated-collection-omission.spec.ts src/lib/heterogeneous-atomicity.spec.ts src/enhancers/restoration/literal-dotted-collection.spec.ts --skipNxCache
```

The initial existing-suite invocation supplied the three files as one comma-separated `--testFile` value. The runner treated that as a single filter and exited 1 with “No test files found”; no assertions ran. The corrected positional-filter invocation above passed. No test assertion failures occurred.

A process check before execution showed no active test/benchmark run (only idle Nx plugin workers). Runs were sequential; no benchmarks, builds, full suite, or typecheck were run.

## Limits

Acceptance covers canonical materialized tree topology and this helper's restricted entry branch. Arbitrary externally replaced proxies/descriptors, deliberately forged position metadata, and collections embedded inside entity row values were not established as supported contracts and are not certified here. Direct descriptor traversal is not observationally identical to enumerating arbitrary user-modified object graphs. The tested hidden cases preserve incumbent fallback behavior; this review does not authorize bypassing membership admission or compensating hidden storage through a newly expanded fast path.

No recommendation to extend the optimization into structural or membership planning, no inference about CPU savings, and no public API change.
