import pathlib,subprocess,os,json,hashlib
root=pathlib.Path('artifacts/transaction-cost-profile-2026-10-14').resolve();child=pathlib.Path('artifacts/capture-cost-qualified-2026-10-14/child.mjs').resolve(); node='/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node'
plan=[(a,k) for k in ['tx-confirm','tx-rollback'] for a in ['baseline','original','optimized']]
(root/'protocol.json').write_text(json.dumps({'plan':plan,'iterations':30000,'warmup':3000,'samplingUs':250,'childSha256':hashlib.sha256(child.read_bytes()).hexdigest(),'scope':'CPU attribution only; profiler includes startup, forced GC, warmup and destruction, not performance verdict'},indent=2))
results=[]
for a,k in plan:
 name=a+'-'+k;cmd=[node,'--expose-gc','--cpu-prof','--cpu-prof-interval=250','--cpu-prof-dir='+str(root),'--cpu-prof-name='+name+'.cpuprofile',str(child),a,k,'30000','16','1']
 r=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'NODE_ENV':'production'},timeout=120)
 (root/(name+'.json')).write_text(r.stdout);(root/(name+'.stderr')).write_text(r.stderr);results.append({'name':name,'command':cmd,'exit':r.returncode});(root/'receipts.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True)
