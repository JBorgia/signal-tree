import collections,json,pathlib
root=pathlib.Path(__file__).resolve().parent
result={}
for path in sorted(root.glob('*.cpuprofile')):
    profile=json.loads(path.read_text()); nodes={n['id']:n for n in profile['nodes']}
    parents={c:n['id'] for n in profile['nodes'] for c in n.get('children',[])}
    own=collections.Counter(); inclusive=collections.Counter()
    for node_id,elapsed in zip(profile['samples'],profile['timeDeltas']):
        frame=nodes[node_id]['callFrame']; own[(frame['functionName'],frame['url'].split('/')[-1])]+=elapsed
        seen=set()
        while node_id in nodes:
            frame=nodes[node_id]['callFrame']; key=(frame['functionName'],frame['url'].split('/')[-1])
            if key not in seen: inclusive[key]+=elapsed; seen.add(key)
            node_id=parents.get(node_id)
    def rows(counts):
        return [{'fn':key[0],'file':key[1],'ms':round(value/1000,3)} for key,value in counts.most_common()]
    result[path.stem]={'sampledMs':sum(profile['timeDeltas'])/1000,'self':rows(own),'inclusive':rows(inclusive)}
(root/'function-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
