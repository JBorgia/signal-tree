import {createRequire} from 'node:module';import {writeFileSync,readFileSync} from 'node:fs';import {dirname,resolve} from 'node:path';import {fileURLToPath} from 'node:url';import {gzipSync} from 'node:zlib';import {createHash} from 'node:crypto';
const root=dirname(fileURLToPath(import.meta.url)),require=createRequire('/Users/jonathanborgia/code/signaltree/package.json'),{build}=require('esbuild');
const core=resolve(root,'../transaction-cost-profile-2026-10-14/comparison/packages/p1/kernel/dist/index.js');
const fixtures={bare:`import {signalTree} from ${JSON.stringify(core)};const t=signalTree({count:0,user:{name:'a'}});t.$.count(1);t.$.user.name('b');globalThis.__sink=[t.$.count(),t.$.user.name()];`,entities:`import {signalTree,entityMap} from ${JSON.stringify(core)};const t=signalTree({count:0,users:entityMap()});t.$.users.addOne({id:1,name:'a'});t.$.users.updateOne(1,{name:'b'});globalThis.__sink=t.$.users.all();`};
const summary={};
for(const[name,code]of Object.entries(fixtures)){
 const entry=resolve(root,name+'.mjs');writeFileSync(entry,code);
 const r=await build({entryPoints:[entry],bundle:true,minify:true,format:'esm',platform:'browser',treeShaking:true,external:['@angular/*','rxjs','rxjs/*','tslib'],nodePaths:['/Users/jonathanborgia/code/signaltree/node_modules'],write:false,legalComments:'none',logLevel:'silent',define:{ngDevMode:'false'},metafile:true});
 writeFileSync(resolve(root,name+'.bundle.js'),r.outputFiles[0].contents);writeFileSync(resolve(root,name+'.meta.json'),JSON.stringify(r.metafile,null,2));
 const modules=Object.values(r.metafile.outputs).flatMap(o=>Object.entries(o.inputs).map(([path,v])=>({path,bytes:v.bytesInOutput}))).sort((a,b)=>b.bytes-a.bytes);
 summary[name]={bytes:r.outputFiles[0].contents.length,gzipBytes:gzipSync(r.outputFiles[0].contents,{level:9}).length,modules,inputs:Object.fromEntries(Object.keys(r.metafile.inputs).map(p=>[p,createHash('sha256').update(readFileSync(p)).digest('hex')]))};
 console.log(name,summary[name].gzipBytes,modules.slice(0,15));
}
writeFileSync(resolve(root,'attribution.json'),JSON.stringify(summary,null,2));
