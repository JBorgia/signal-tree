import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
declare const __CANDIDATE__:boolean;
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];for(const scenario of ['genuine-noop','scope-exit','ordinary-equal','transaction-equal','ordinary-different','declared-equal','declared-different','incoming-equal']){
const t=signalTree({y:scenario==='genuine-noop'?99:7,x:0},{enhancers:[transactions()]});const sent:number[]=[];const c:any=link(t.$.y,{get:()=>99,set:(v:number)=>{sent.push(v);}});const events:any[]=[];let receipt:any;let p:any;
const snapshot=(name:string)=>events.push({name,physical:t.$.y(),sent:[...sent],receipt:receipt?.read()});
try{
 snapshot('initial');if(scenario!=='genuine-noop'){withWriteContext({participation:'inspection'},()=>{t.$.y(99);snapshot('inside-inspection');});snapshot('after-inspection-scope');await tick();snapshot('inspection-drained');}
 if(scenario==='genuine-noop'||scenario==='ordinary-equal')t.$.y(99);
 if(scenario==='transaction-equal'){p=t.transact(()=>t.$.y(99));events.push({name:'pending-inspection',inspection:p.inspect()});await tick();snapshot('equal-transaction-drained');p.rollback();events.push({name:'terminal-inspection',inspection:p.inspect()});}
 if(scenario==='ordinary-different')t.$.y(100);
 if(scenario==='declared-equal'||scenario==='declared-different'){
 const value=scenario==='declared-equal'?99:100;
 if(__CANDIDATE__)receipt=c.declare({kind:'independent'},()=>t.$.y(value));else t.$.y(value);
 }
 if(scenario==='incoming-equal'){await c.retrieve();await tick();snapshot('incoming-equal-acquired');t.$.y(7);}
 await tick();snapshot('final');rows.push({arm:__CANDIDATE__?'candidate':'baseline',scenario,events,proposalFalsifier:['ordinary-equal','declared-equal'].includes(scenario)?{unapprovedExpectation:[99],actual:[...sent],pass:JSON.stringify(sent)==='[99]',classification:'proposed meaningful-adoption semantics, not established native contract'}:undefined});
}catch(e){rows.push({scenario,error:String(e),events});}finally{c.dispose();t.destroy();await tick();}
}return rows;}
