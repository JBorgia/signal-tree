# Native equal-value participation boundary

Nine identical direct-source scenarios on baseline and frozen private candidate. No runtime repair. Source-loader diagnostic `researchReadEligible()` added equally to both arms solely to read Link-local eligible closure; original unobserved standalone bundles retained. First candidate diagnostic insertion mistakenly overwritten by candidate return-object substitution: nine TypeErrors preserved diagnostic-hook-first.log; corrected diagnostic only, no semantic/source change.

| Scenario | Baseline and candidate |
| --- | --- |
| Genuine ordinary99->99 | physical99 eligible99 sends[] |
| ordinary7, inspection99, exit context without write | physical99 eligible7 sends[] |
| same followed ordinary99 | physical99 eligible7 sends[] |
| transaction equal99 then rollback | inspect.changes[]; physical99 eligible7 sends[] |
| differing ordinary100 | physical100 eligible100 sends[100] |
| declared equal99 | same native no-op; candidate receipt no-write |
| declared differing100 | sends[100]; candidate started declared receipt |
| incoming equal99 then ordinary7 | acquisition makes eligible99 despite physical equality; then sends7 |
| pending transaction0->7, inspection99, ordinary99, rollback | transaction remains current; rollback succeeds physical0 eligible0 sends[0] |

Equal-adoption expectation `[99]` is separately labeled unapproved proposed meaningful-adoption semantics, not established native regression. No claim that ordinary setter means `acquire`.

`withWriteContext` exits metadata scope only: physical99 remains after return. DevTools implementation source inspected: JUMP and ROLLBACK apply inspection state; COMMIT sends initialization; disconnect unregisters observers, not automatic physical restoration. No actual browser DevTools replay performed. No global ordinary canonical truth established; eligible here is per-Link closure observed with readonly diagnostic.

Read contracts/tests: inspection-egress-conformance.spec.ts225–270 differing authored controls;424 inbound equal acquisition; link-authority-carrier.spec.ts208 equal external acquisition; write-participation.ts declared inspection exclusion. owned-mutation.ts245 gates emitted mutation on changed, still invokes observation callbacks with changed flag. History inspected (git log file histories); no concrete equal authored adoption promise found.

Direct esbuild source execution only, not Nx/package qualification. No tests weakened or production edits. Await owner semantics before repair.

Replay Node24.15.0 standalone baseline-bundle.mjs or bundle.mjs exports run(). Rebuild BASELINE=1 node loader.mjs / node loader.mjs requires recorded worktree paths; overwrites generic outputs.
