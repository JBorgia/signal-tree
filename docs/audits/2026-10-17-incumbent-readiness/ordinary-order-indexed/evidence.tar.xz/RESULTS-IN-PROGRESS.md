# Indexed ordinary-order experiment — evidence accounting

This is an experiment record, not production acceptance. Production87f6831f and accepted slice191058393 are unchanged. B remains closed. Native work is isolated under /private/tmp/ordinary-order-indexed/native. Later slices remain gated.

## Model gate: independently passed

The indexed model preserves the byte-identical 26-fixture harness, including all four semantic witnesses and existing cycles/reference controls. Supplemental32 work rows and3 many-live-lease rows passed. Independent replay and additional partial-convergence/shared-lease checks passed. Source model SHA256 is7f9354d7932eafea6069d82700f053319cc2d4d3f463cf38609f107d21cc0dbd.

Fixed-local work with N16/256/1024/4096 unrelated divergence processes two normalized source slots across local installation/inversion and retires two indexed recovery facts; no exception-map scan at drain. Independent four-of-N convergence touches four agreement records and retains N-4. Full divergence/convergence legitimately visits N. Shared recovery facts survive until their last lease; recovery-only facts never become current authority. These are finite instrumented operation/retention results, not CPU/heap/native performance claims. See model/RESULT-RECORD.md, review/FINAL-REVIEW.md and ROOT-MODEL-VERIFICATION.json.

## Native evidence by exact revision

| Execution | Result | Qualification |
| --- | --- | --- |
| Preserved source control, NATIVE-FIRST-RED | 4fail/9pass | Three prepend redo failures and compound ordinary order leak, unchanged assertions |
| First implementation | 1fail/12pass | Historical observation only; complete first-run source was not preserved before editing |
| Diagnostic freeze | Compound fails | Independent raw trace establishes source OABC, outbound CAB; exact six-file diagnostic manifest |
| Third version | 13pass | Blanket ordinary selector closes original four but is not valid across relationship baselines |
| Fourth version | 68pass/2fail | Selected-inverse-only handoff and single payload owner; both updater reds also fail on preserved predecessor (13pass/2fail in that file) |
| Fourth boundary run | 11pass/2timeouts | Eight indexed-work controls pass; two new tests incorrectly await pending Link delivery before rollback. Original tests/results retained; production hold is not a runtime failure |
| Fifth version | 28pass/1fail | New prepend test sampled accessor identity before an established overwrite cache replacement; both control/candidate show this. Original retained; corrected holder acquisition preserves placement assertions |
| Fifth corrected new prepend test | 1pass | Runtime unchanged; original and corrected test/source identities preserved |
| Fifth unchanged qualification vector | 251pass | Original22-file vector; does not qualify later edits or untested full-order companion |

Do not add these counts together: suites overlap. Expected failures, inherited failures, harness mistakes and runtime failures have separate dispositions.

## Newly exposed facts

- Placement metadata retaining E.value introduced a real regression: inspected reorder, ordinary B44, remove/reject restored B2. Predecessor restores44. Corrected by leaving payload ownership in EntityValueStore and retaining only placement facts; original first red remains archived.
- Ordinary source responsibility is not the complete operation for every Link baseline. A connection created after inspection may adopt X; later ordinary removal must remove it even when source ordinaryChanges=[]; ordinary field adoption uses existing latent topology. Blanket source tuple substitution is invalid. Selected inverse disposition is carried explicitly at the private handoff; it does not select authority or redefine eligibility.
- Full-order rejection still lacks ordinary-before endpoint in the pre-companion candidate: OABC, inspectedCBA, ownACB rejects to outboundCBA and a later field write retainsCBA. This is separate from the four original failures. The independently reviewed bounded correction carries separate source-prepared O endpoints alongside existing P deltas/frontiers, without changing selection authority.
- Full-order requests omitting an ordinary-present, physically hidden lifetime require a separately established source footprint rule. Relationship-local reorder policy is not by itself that rule. Investigation is ongoing; no implicit semantic choice or full-target qualification is recorded.

No full suites, artifacts, budgets, heap/CPU benchmarks or release verification are claimed. Native source coverage, fault/reentry/refusal, cleanup and exact final source review remain required before acceptance within this bounded experiment.

## Subsequent freezes (supersedes unfinished-state descriptions above)

| Execution | Result | Qualification |
| --- | --- | --- |
| Sixth | 39 pass / 1 fail | Same-membership order inverse still lost O endpoints at a private wrapper forwarding only four arguments. The later-field assertion failed before immediate rollback order was asserted; independent trace also shows rollback CBA. |
| Seventh | 40 pass | Private wrapper carries both prepared O endpoint and selected-disposition arguments. No complete prefix qualification follows. |
| Eighth cumulative union | 334 pass / 4 fail | Two unchanged updater failures are inherited. Two newly authored subset controls assert a physical lens for inspection-hidden B; their ordinary topology/publication assertions pass. Original tests and first errors retained before correction. |
| Corrected subset controls | 2 pass | No runtime change; ordinary B2, owned lifetime identity and source O occupancy replace unsupported physical lens expectation. |
| Eighth independent prefix control | Fail | Existing-row prepend already satisfied by inspection mutates O without capture. Actual-moving prefix also omits O endpoint capture. Exact source and compatibility controls retained. |

Subset compatibility is now established for the bounded public operation: ordinary ABC with inspection-hidden B, explicit CA order gives ordinary CBA; rejection restores ordinary ABC. Both predecessor and candidate public baselines agree. This resolves that earlier source-footprint question without selecting new semantics.

The reviewed model and native indexed controls remain separate. Existing-key prefix work inherited two physical snapshots totaling 2N entries; fresh-prefix sixth measurement eliminates them, with 26 stage reads at all N16/256/1024. This is selected work at the measured freeze, not a final-source or CPU claim.

Workspace source and typing checks passed on the eighth runtime. Spec-types first found three mistakes in new test instrumentation; a guarded owner-type correction is recorded. Changed-runtime lint first found four unused declarations and four warnings. These results do not qualify a later runtime correction.

The final finite experiment corrects common prepared order intent/capture for fresh, mixed, actual-moving and physically satisfied prefixes. It must preserve known relationship-relative fresh placement and later foreign ordinary membership. The new forward owner post-plan fault/reentry tests close a missing evidence seam, not a previously demonstrated public-input defect. Final disposition is pending; no later slice is resumed.
