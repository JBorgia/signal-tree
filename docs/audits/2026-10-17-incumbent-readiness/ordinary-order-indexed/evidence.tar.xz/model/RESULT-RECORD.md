# Indexed successor result

Frozen source model SHA256 7f9354d7932eafea6069d82700f053319cc2d4d3f463cf38609f107d21cc0dbd; predecessor source untouched. Snapshot ordinary representation unchanged. Common lease bookkeeping is now indexed for both options; it is distinct from current source storage.

First commands, all exit0 with no rerun:
- `node /private/tmp/ordinary-order-indexed/model/acceptance.mjs > /private/tmp/ordinary-order-indexed/model/ACCEPTANCE-FIRST.log 2>&1`
- `node /private/tmp/ordinary-order-indexed/model/indexed-tests.mjs > /private/tmp/ordinary-order-indexed/model/INDEXED-FIRST.log 2>&1`
- `node /private/tmp/ordinary-order-indexed/model/live-tests.mjs > /private/tmp/ordinary-order-indexed/model/LIVE-FIRST.log 2>&1`

Acceptance harness is byte-identical to frozen original run.mjs SHA7e944eb44c3bcf3a668531324716c725e70483029de95ba81778374c6c28032b: four semantic failures and all other existing assertions unchanged, original observation cost criteria preserved. 26 fixture runs pass. Indexed supplemental32 rows cover N16/256/1024/4096 and cycles1/8/32/128. Live supplement3 rows covers16/128/512 concurrent leases plus a shared receipt. Preregistered design and live supplement preceded respective execution.

With N reversed current divergences, local field+inverse+drain normalizes two changed slots across its two installations and retires two indexed fact records. Prepare/install/inverse/release selected counter total187 at every N; current divergence retains N entries. Drain visits zero exception entries. Actual full convergence normalizes the full changed-slot union and deletes all current exceptions at installation, charging that N work there. Local order move/return cycles do not accumulate current exceptions.

Recovery index keys are immutable fact identities with live-lease refcounts. Shared receipts survive first lease retirement, retire at last lease, and never participate in current ordinary lookup. Staggered oldB/D removals plus fresh same-key B preserve useful D recovery and reject stale oldB field/rekey before install. Failed/stale prepared current updates leave live recovery/current index unchanged. Many-live tests drain obligations while current installed field value persists, explicitly separating obligations from current authority.

Limits: finite trusted internal lifetime commands, no general ownership/public authorization proof. Counts cover selected instrumented operations, not every map read, JavaScript allocation, CPU, heap, bytes or GC. Lease index Set/Map private preparation and per-fact maintenance are counted, but transient wrapper arrays and report serialization are not exhaustive allocations. No universal OOM atomicity claim. Caller-held receipts, prepared closures, descriptor arrays, and inverse descriptors may retain facts/model independently; internal index zero is not total collectibility. Snapshot cleanup retains its original whole-map scan. No native edits, no production or release claim.
