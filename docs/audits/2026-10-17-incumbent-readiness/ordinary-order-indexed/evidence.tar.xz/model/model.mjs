import assert from 'node:assert/strict';

const NONE = Symbol('ordinary head/tail follows physical');
const absent = (id, counts, category = 'physical') => { if (counts) counts.add(`${category}.absentRecordsAllocated`); return { id, present: false, key: undefined, n: undefined, prev: undefined, next: undefined }; };
const equalNode = (a, b) => !a?.present && !b?.present || !!a?.present && !!b?.present && a.id === b.id && a.key === b.key && a.n === b.n && a.prev === b.prev && a.next === b.next;
export class Counts {
  values = {}; phase = 'work';
  add(key, n = 1) { key = `${this.phase}.${key}`; this.values[key] = (this.values[key] ?? 0) + n; }
  during(phase, fn) { const before = this.phase; this.phase = phase; try { return fn(); } finally { this.phase = before; } }
  reset() { this.values = {}; }
  read() { return { ...this.values }; } // Reporting copy, excluded from mutation counts.
}
const copied = (node, counts, category) => {
  counts.add(`${category}.recordsCopied`); counts.add(`${category}.fieldSlotsCopied`, 6);
  return { id: node.id, present: node.present, key: node.key, n: node.n, prev: node.prev, next: node.next };
};
const arrayCopy = (array, counts, category) => { counts.add(`${category}.arraysAllocated`); counts.add(`${category}.arrayEntriesCopied`, array.length); return array.slice(); };

// Shared physical index. No global lifetime/tombstone registry exists.
class Physical {
  nodes = new Map(); head; tail;
  constructor(counts) { this.counts = counts; counts.add('physical.mapsAllocated'); }
  read(id) { this.counts.add('physical.nodeReads'); return this.nodes.get(id) ?? absent(id, this.counts); }
  install(stage) {
    for (const [id, node] of stage.patch) {
      this.counts.add('physical.patchEntriesScanned'); this.counts.add('physical.nodeWrites');
      if (node.present) this.nodes.set(id, node); else this.nodes.delete(id);
    }
    this.head = stage.head; this.tail = stage.tail; this.counts.add('physical.headTailWrites', 2);
  }
}
class Stage {
  patch = new Map();
  constructor(baseRead, head, tail, counts, category) { Object.assign(this, { baseRead, head, tail, counts, category }); counts.add(`${category}.mapsAllocated`); counts.add(`${category}.headTailReads`, 2); }
  read(id) { this.counts.add(`${this.category}.stageReads`); return this.patch.get(id) ?? this.baseRead(id); }
  write(node) { this.counts.add(`${this.category}.patchWrites`); this.counts.add(`${this.category}.recordsAllocated`); this.patch.set(node.id, node); }
  change(id, delta) { this.write({ ...this.read(id), ...delta }); this.counts.add(`${this.category}.fieldSlotsCopied`, 6); }
  remove(id) {
    const node = this.read(id); if (!node.present) throw new Error(`missing lifetime ${id}`);
    if (node.prev !== undefined) this.change(node.prev, { next: node.next }); else this.head = node.next;
    if (node.next !== undefined) this.change(node.next, { prev: node.prev }); else this.tail = node.prev;
    this.write(absent(id, this.counts, this.category));
  }
  insert(life, placement = {}) {
    if (this.read(life.id).present) throw new Error(`already present lifetime ${life.id}`);
    let prev, next;
    const hasNext = placement.next !== undefined && this.read(placement.next).present;
    const hasPrev = placement.prev !== undefined && this.read(placement.prev).present;
    if (hasNext) { next = placement.next; prev = this.read(next).prev; }
    else if (hasPrev) { prev = placement.prev; next = this.read(prev).next; }
    else if (placement.next !== undefined || placement.prev !== undefined) throw new Error('both placement anchors missing');
    else if (placement.edge === 'head') { next = this.head; }
    else { prev = this.tail; }
    if (prev !== undefined) this.change(prev, { next: life.id }); else this.head = life.id;
    if (next !== undefined) this.change(next, { prev: life.id }); else this.tail = life.id;
    this.write({ id: life.id, present: true, key: life.key, n: life.n, prev, next });
  }
  order(ids) {
    const seen = new Set(); this.counts.add(`${this.category}.setsAllocated`);
    for (let i = 0; i < ids.length; i++) {
      this.counts.add(`${this.category}.orderEntriesScanned`); this.counts.add(`${this.category}.setWrites`);
      this.counts.add(`${this.category}.setReads`);
      if (seen.has(ids[i]) || !this.read(ids[i]).present) throw new Error('invalid explicit order');
      seen.add(ids[i]); this.change(ids[i], { prev: ids[i - 1], next: ids[i + 1] });
    }
    // Completeness is checked against the maintained present-count, no hidden full scan.
    if (ids.length !== this.presentCount) throw new Error('incomplete explicit order');
    this.head = ids[0]; this.tail = ids.at(-1);
  }
}
function sequence(read, head, counts, category) {
  const result = []; const seen = new Set(); counts.add(`${category}.arraysAllocated`); counts.add(`${category}.setsAllocated`);
  let id = head;
  while (id !== undefined) {
    counts.add(`${category}.entriesScanned`); counts.add(`${category}.arrayWrites`); counts.add(`${category}.setWrites`);
    counts.add(`${category}.setReads`); assert(!seen.has(id), 'cycle'); seen.add(id); const node = read(id); assert(node.present, 'nonpresent sequence member');
    result.push(id); id = node.next;
  }
  return result;
}

class SnapshotOrdinary {
  snapshot; // { sequence, records }; absent means certified identical to P.
  constructor(physical, counts) { Object.assign(this, { physical, counts }); }
  read(id) { this.counts.add('ordinary.nodeReads'); return this.snapshot?.records.get(id) ?? (this.snapshot ? absent(id, this.counts, 'ordinary') : this.physical.read(id)); }
  get head() { return this.snapshot ? this.snapshot.sequence[0] : this.physical.head; }
  get tail() { return this.snapshot ? this.snapshot.sequence.at(-1) : this.physical.tail; }
  begin() {
    let privateSnapshot;
    if (this.snapshot) {
      privateSnapshot = { sequence: arrayCopy(this.snapshot.sequence, this.counts, 'ordinary'), records: new Map() };
      this.counts.add('ordinary.mapsAllocated');
      for (const [id, node] of this.snapshot.records) {
        this.counts.add('ordinary.mapEntriesCopied'); this.counts.add('ordinary.mapWrites');
        privateSnapshot.records.set(id, copied(node, this.counts, 'ordinary'));
      }
    }
    const stage = new Stage(id => privateSnapshot ? privateSnapshot.records.get(id) ?? absent(id, this.counts, 'ordinary') : this.physical.read(id), this.head, this.tail, this.counts, 'ordinary');
    return { stage, privateSnapshot };
  }
  finish(prepared, physicalStage) {
    const { stage, privateSnapshot } = prepared;
    if (!this.snapshot) {
      // Exact local proof: unchanged base records share one physical source.
      // Every changed slot and both heads/tails must agree, not merely keys.
      const ids = new Set(); this.counts.add('ordinary.setsAllocated');
      for (const id of stage.patch.keys()) { ids.add(id); this.counts.add('ordinary.patchEntriesScanned'); this.counts.add('ordinary.setWrites'); }
      for (const id of physicalStage.patch.keys()) { ids.add(id); this.counts.add('ordinary.patchEntriesScanned'); this.counts.add('ordinary.setWrites'); }
      let same = stage.head === physicalStage.head && stage.tail === physicalStage.tail;
      for (const id of ids) { this.counts.add('ordinary.agreementEntriesScanned'); same = equalNode(stage.read(id), physicalStage.read(id)) && same; }
      if (same) return undefined;
    }
    const ids = sequence(id => stage.read(id), stage.head, this.counts, 'ordinary');
    const records = privateSnapshot?.records ?? new Map();
    if (!privateSnapshot) this.counts.add('ordinary.mapsAllocated');
    // If already forked the complete map was copied at begin. Apply all patches,
    // including removals; otherwise build the complete fork now.
    if (privateSnapshot) {
      for (const [id, node] of stage.patch) {
        this.counts.add('ordinary.patchEntriesScanned'); this.counts.add('ordinary.mapWrites');
        if (node.present) records.set(id, node); else records.delete(id);
      }
    } else for (const id of ids) { records.set(id, copied(stage.read(id), this.counts, 'ordinary')); this.counts.add('ordinary.mapWrites'); }
    return { sequence: ids, records };
  }
  install(prepared) { this.snapshot = prepared; }
  cleanup() {
    if (!this.snapshot) return;
    let same = this.head === this.physical.head && this.tail === this.physical.tail && this.snapshot.records.size === this.physical.nodes.size;
    for (const [id, node] of this.snapshot.records) { this.counts.add('cleanup.snapshotEntriesScanned'); same = equalNode(node, this.physical.read(id)) && same; }
    if (same) this.snapshot = undefined;
  }
  retained() { return { ordinaryRecords: this.snapshot?.records.size ?? 0, ordinarySequenceSlots: this.snapshot?.sequence.length ?? 0 }; }
}
class SparseOrdinary {
  exceptions = new Map(); headOverride = NONE; tailOverride = NONE;
  constructor(physical, counts) { Object.assign(this, { physical, counts }); counts.add('ordinary.mapsAllocated'); }
  read(id) { this.counts.add('ordinary.nodeReads'); return this.exceptions.get(id) ?? this.physical.read(id); }
  get head() { return this.headOverride === NONE ? this.physical.head : this.headOverride; }
  get tail() { return this.tailOverride === NONE ? this.physical.tail : this.tailOverride; }
  begin() { return { stage: new Stage(id => this.read(id), this.head, this.tail, this.counts, 'ordinary') }; }
  finish({ stage }, physicalStage) {
    // All physical slots about to change must have a retained ordinary answer.
    // Changed prev/next endpoints are in the physical patch just like the row.
    for (const id of physicalStage.patch.keys()) {
      this.counts.add('ordinary.preservationEntriesScanned');
      this.counts.add('ordinary.patchMembershipReads', 2);
      if (!stage.patch.has(id) && !this.exceptions.has(id)) stage.write(copied(this.read(id), this.counts, 'ordinary'));
      assert(stage.patch.has(id) || this.exceptions.has(id), 'uncertified physical fallback');
    }
    // Normalize the complete changed-slot union against prepared physical truth.
    const updates = new Map(); this.counts.add('ordinary.indexMapsAllocated');
    for (const id of stage.patch.keys()) {
      this.counts.add('ordinary.normalizationEntriesScanned');
      updates.set(id, equalNode(stage.read(id), physicalStage.read(id)) ? undefined : stage.read(id));
      this.counts.add('ordinary.indexPatchWrites');
    }
    for (const id of physicalStage.patch.keys()) if (!stage.patch.has(id)) {
      this.counts.add('ordinary.normalizationEntriesScanned');
      updates.set(id, equalNode(this.read(id), physicalStage.read(id)) ? undefined : this.read(id));
      this.counts.add('ordinary.indexPatchWrites');
    }
    return { stage, updates };
  }
  install({stage, updates}) {
    for (const [id, node] of updates) {
      this.counts.add('ordinary.indexUpdatesInstalled');
      if (node === undefined) this.exceptions.delete(id); else this.exceptions.set(id, node);
    }
    this.headOverride = stage.head === this.physical.head ? NONE : stage.head;
    this.tailOverride = stage.tail === this.physical.tail ? NONE : stage.tail;
    this.counts.add('ordinary.headTailWrites', 2);
  }
  cleanup() { this.counts.add('cleanup.indexedNoScanDrains'); }
  retained() { return { ordinaryRecords: this.exceptions.size, ordinarySequenceSlots: 0 }; }
}

function apply(stage, intent, count) {
  count.add('intent.operationsRead');
  if (intent.kind === 'add') { stage.insert(intent.life, intent); stage.presentCount++; }
  else if (intent.kind === 'remove') { stage.remove(intent.id); stage.presentCount--; }
  else if (intent.kind === 'field' || intent.kind === 'rekey') {
    if (!stage.read(intent.id).present) throw new Error('missing lifetime for field/key');
    stage.change(intent.id, intent.kind === 'field' ? { n: intent.n } : { key: intent.key });
  } else if (intent.kind === 'order') stage.order(intent.ids);
  else throw new Error('unknown authored intent');
}
function capture(stage, intent, counts, admission) {
  if (intent.kind === 'order') {
    const before = sequence(id => stage.read(id), stage.head, counts, 'facts');
    apply(stage, intent, counts);
    const after = arrayCopy(intent.ids, counts, 'facts'); counts.add('facts.recordsAllocated');
    return Object.freeze({ kind: 'order', before: Object.freeze(before), after: Object.freeze(after), admission });
  }
  const id = intent.life?.id ?? intent.id;
  const before = copied(stage.read(id), counts, 'facts');
  apply(stage, intent, counts);
  const after = copied(stage.read(id), counts, 'facts'); counts.add('facts.recordsAllocated');
  return Object.freeze({ kind: intent.kind, id, before: Object.freeze(before), after: Object.freeze(after), admission });
}
export function inverseIntents(units, counts) {
  const intents = []; counts.add('history.arraysAllocated');
  for (let u = units.length - 1; u >= 0; u--) for (let f = units[u].ordinary.length - 1; f >= 0; f--) {
    const fact = units[u].ordinary[f]; counts.add('history.factsRead'); counts.add('history.intentRecordsAllocated'); counts.add('history.arrayWrites');
    if (fact.kind === 'order') intents.push({ kind: 'order', ids: arrayCopy(fact.before, counts, 'history') });
    else if (fact.kind === 'add') intents.push({ kind: 'remove', id: fact.id });
    else if (fact.kind === 'remove') intents.push({ kind: 'add', life: fact.before, prev: fact.before.prev, next: fact.before.next });
    else if (fact.kind === 'field') intents.push({ kind: 'field', id: fact.id, n: fact.before.n });
    else intents.push({ kind: 'rekey', id: fact.id, key: fact.before.key });
  }
  return intents;
}
export function redoIntents(units, counts) {
  const intents = []; counts.add('history.arraysAllocated');
  for (const unit of units) for (const fact of unit.ordinary) {
    counts.add('history.factsRead'); counts.add('history.intentRecordsAllocated'); counts.add('history.arrayWrites');
    if (fact.kind === 'order') intents.push({ kind: 'order', ids: arrayCopy(fact.after, counts, 'history') });
    else if (fact.kind === 'add') intents.push({ kind: 'add', life: fact.after, prev: fact.after.prev, next: fact.after.next });
    else if (fact.kind === 'remove') intents.push({ kind: 'remove', id: fact.id });
    else if (fact.kind === 'field') intents.push({ kind: 'field', id: fact.id, n: fact.after.n });
    else intents.push({ kind: 'rekey', id: fact.id, key: fact.after.key });
  }
  return intents;
}
export class Model {
  counts = new Counts(); physical = new Physical(this.counts); revision = 0; nextLife = 0; admission = 0; leases = new Map(); recoveryIndex = new Map(); leaseFacts = new Map(); ordinaryCount = 0; physicalCount = 0;
  constructor(kind) { this.kind = kind; this.counts.add('history.mapsAllocated'); this.ordinary = kind === 'snapshot' ? new SnapshotOrdinary(this.physical, this.counts) : new SparseOrdinary(this.physical, this.counts); }
  life(key, n = 0) { this.counts.add('identity.handlesAllocated'); return Object.freeze({ id: ++this.nextLife, key, n }); }
  prepare(ordinaryIntents = [], physicalIntents = ordinaryIntents, { fail = false } = {}) {
    const revision = this.revision, admission = ++this.admission;
    let o = this.ordinary.begin(), p = new Stage(id => this.physical.read(id), this.physical.head, this.physical.tail, this.counts, 'physical'), ready;
    o.stage.presentCount = this.ordinaryCount; p.presentCount = this.physicalCount;
    const ordinary = [], physical = []; this.counts.add('facts.arraysAllocated', 2);
    for (const intent of ordinaryIntents) { ordinary.push(capture(o.stage, intent, this.counts, admission)); this.counts.add('facts.arrayWrites'); }
    for (const intent of physicalIntents) apply(p, intent, this.counts);
    ready = this.ordinary.finish(o, p);
    for (const [id, after] of p.patch) {
      this.counts.add('facts.physicalPatchEntriesScanned'); this.counts.add('facts.recordsAllocated'); this.counts.add('facts.arrayWrites');
      physical.push(Object.freeze({ id, before: Object.freeze(copied(this.physical.read(id), this.counts, 'facts')), after: Object.freeze(copied(after, this.counts, 'facts')) }));
    }
    const facts = Object.freeze({ ordinary: Object.freeze(ordinary), physical: Object.freeze(physical), admission });
    let active = true;
    const release = () => { o = p = ready = undefined; active = false; };
    if (fail) { release(); throw new Error('prepared unit failed'); }
    return { facts, install: () => {
      if (!active) throw new Error('prepared unit already consumed');
      if (this.revision !== revision) { release(); throw new Error('stale prepared revision'); }
      this.ordinaryCount = o.stage.presentCount; this.physicalCount = p.presentCount;
      this.physical.install(p); this.ordinary.install(ready); this.revision++;
      this.counts.add('publication.unitsInstalled'); release(); return facts;
    }, discard: release };
  }
  commit(ordinary = [], physical = ordinary, publish) {
    const facts = this.prepare(ordinary, physical).install();
    this.counts.add('publication.factsReadyBeforeCallback', facts.ordinary.length + facts.physical.length);
    if (publish) publish(facts);
    return facts;
  }
  inspection(physical) { return this.commit([], physical); }
  retain(name, units) {
    // Build private distinct fact membership before installing index updates.
    const owned = arrayCopy(units, this.counts, 'history'), facts = new Set();
    this.counts.add('recovery.setsAllocated');
    for (const unit of owned) for (const rows of [unit.ordinary, unit.physical]) for (const fact of rows) {
      this.counts.add('recovery.preparedFactsVisited'); facts.add(fact); this.counts.add('recovery.setWrites');
    }
    const updates = new Map(); this.counts.add('recovery.mapsAllocated');
    for (const fact of this.leaseFacts.get(name) ?? []) { updates.set(fact, (this.recoveryIndex.get(fact) ?? 0)-1); this.counts.add('recovery.replacementFactsVisited'); }
    for (const fact of facts) { updates.set(fact, (updates.get(fact) ?? this.recoveryIndex.get(fact) ?? 0)+1); this.counts.add('recovery.newFactsVisited'); }
    for (const [fact, count] of updates) { if(count) this.recoveryIndex.set(fact,count); else this.recoveryIndex.delete(fact); this.counts.add('recovery.indexWrites'); }
    this.leaseFacts.set(name,facts); this.leases.set(name,owned); this.counts.add('history.leaseWrites');
  }
  drain(name) {
    for(const fact of this.leaseFacts.get(name) ?? []) {
      const count=this.recoveryIndex.get(fact); this.counts.add('recovery.releaseFactsVisited');
      if(count===1){this.recoveryIndex.delete(fact);this.counts.add('recovery.lastObligationRecordsReleased');}
      else this.recoveryIndex.set(fact,count-1);
      this.counts.add('recovery.indexWrites');
    }
    this.leaseFacts.delete(name);this.leases.delete(name);this.counts.add('history.leaseDeletes');
    this.counts.during('cleanup',()=>this.ordinary.cleanup());
  }
  undo(units, physical) { const intents = inverseIntents(units, this.counts); return this.commit(intents, physical ?? intents); }
  redo(units) { const intents = redoIntents(units, this.counts); return this.commit(intents); }
  state(which = 'ordinary') { return this.counts.during('verification', () => {
    const source = which === 'physical' ? this.physical : this.ordinary;
    const ids = sequence(id => source.read(id), source.head, this.counts, 'verification');
    this.counts.add('verification.arraysAllocated');
    return ids.map(id => { this.counts.add('verification.arrayWrites'); this.counts.add('verification.nodeOutputs'); const n = source.read(id); return { id: n.id, key: n.key, n: n.n }; });
  }); }
  verify() { return this.counts.during('verification', () => {
    for (const which of ['physical', 'ordinary']) {
      const source = which === 'physical' ? this.physical : this.ordinary, state = this.state(which), keys = new Set();
      this.counts.add('verification.setsAllocated');
      assert.equal(state.length, which === 'physical' ? this.physicalCount : this.ordinaryCount);
      for (let i = 0; i < state.length; i++) {
        this.counts.add('verification.entriesScanned'); const node = source.read(state[i].id);
        assert.equal(node.prev, state[i - 1]?.id); assert.equal(node.next, state[i + 1]?.id);
        assert(!keys.has(node.key), 'duplicate active key'); keys.add(node.key); this.counts.add('verification.setWrites');
      }
      assert.equal(source.tail, state.at(-1)?.id);
    }
  }); }
  retained() { return this.counts.during('retention', () => {
    let facts = 0, copiedNodes = 0, sequenceSlots = 0; const retired = new Set(); this.counts.add('retention.setsAllocated');
    for (const units of this.leases.values()) for (const unit of units) {
      this.counts.add('retention.unitsScanned');
      for (const fact of unit.ordinary) {
        this.counts.add('retention.factsScanned'); facts++;
        if (fact.kind === 'order') sequenceSlots += fact.before.length + fact.after.length;
        else { copiedNodes += 2; if (!this.physical.read(fact.id).present && !this.ordinary.read(fact.id).present) retired.add(fact.id); }
      }
      facts += unit.physical.length; copiedNodes += 2 * unit.physical.length;
      for (const fact of unit.physical) { this.counts.add('retention.factsScanned'); if (!this.physical.read(fact.id).present && !this.ordinary.read(fact.id).present) retired.add(fact.id); }
    }
    return { physicalRecords: this.physical.nodes.size, ...this.ordinary.retained(), leases: this.leases.size, internalRetainedFacts: facts, internalRetainedNodeImages: copiedNodes, internalRetainedOrderSlots: sequenceSlots, internalRetiredRecoveryIdentities: retired.size };
  }); }
}
export const add = (life, placement = {}) => ({ kind: 'add', life, ...placement });
export const remove = life => ({ kind: 'remove', id: life.id });
export const field = (life, n) => ({ kind: 'field', id: life.id, n });
export const reorder = lives => ({ kind: 'order', ids: lives.map(life => life.id) });
