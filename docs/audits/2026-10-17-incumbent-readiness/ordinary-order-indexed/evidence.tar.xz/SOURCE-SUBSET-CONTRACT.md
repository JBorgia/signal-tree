# Source subset-order contract audit

Read-only narrow source/decision inspection October24. Native remains mutable; no source edit or execution. Sequence: source ordinaryABC; inspection removesB leaving physicalAC; ordinary setAll(C,A), a real explicit surviving-subset reorder. No new lifetimes.

No exact governing **source** rule found for disposition of ordinary-present but physically absentB under this explicit subset full order. Existing W8 plan promises exact input order and explicit membership facts, but original source implementation determines omitted members from physical currentKeys, so absent B produces no explicit ordinary remove. Approved inverse-footprint rule restores ordinary topology within authored footprint and leaves unrelated inspection; it does not explicitly define this new forward full-order footprint when supplied membership is smaller than ordinary source membership.

Evidence bounds:
- semantic-transition-plan W5 says rekey does not implicitly adopt order; W8 says supplied exact input order with explicit M, pure order not field delta. Neither identifies whether missing physicalB is omitted ordinary membership or untouched outside supplied reorder.
- entity-inspection-egress.spec.ts270–285 shows ordinary setAll(C,A) replaces a normal live collection and publishes exactCA. It has no physically-absent/ordinary-present B.
- EntityEgressProjection.reorder preserves absent eligible members while permuting visible subset, but this is connection-relative projection policy. It is insufficient authority to select source CBA.
- Existing compound OABC/P-CBX ownsetAllCAX has no surviving-order capture; it demonstrates no incidental order adoption, not this explicit subset reorder.
- Field/key-only operations remain outside this ambiguity: they do not author incidental order.

## Exact owner decision if required

For ordinaryABC, inspection-hiddenB, ordinarysetAll(C,A):

1. Treat setAll as complete ordinary replacement: ordinaryCA, dropB from ordinary membership. Inspection absence becomes explicit ordinary omission because operation supplies complete collection. Rollback of a transactional call must restoreB and ordinaryABC.
2. Treat actual visible-set reorder as authored subset order and preserve ordinaryB: specify relative placement explicitly, e.g permute A/C slots yieldingCBA. This extends source semantics beyond merely reusing connection projection behavior; rollback returnsABC.
3. Refuse this ambiguous whole-value operation atomically until ordinary/physical membership agree or application authors explicit membership action. Changes existing useful operation availability and requires compatibility approval.

Recommendation for decision framing: choose intended meaning of **whole-value setAll membership** first. Do not pick CBA solely because helper can permute slots, or CA solely because fulltarget has that array. This is a semantic decision only for differing membership with explicit full-order intent. Same-membership three-lifetime separate-O carrier implementation can continue independently; no reason to block it on this subset question.
