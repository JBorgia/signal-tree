# Independent acceptance criteria: indexed ordinary-obligation successor

Written before successor design/code/result review. Scope is an isolated successor model with indexed agreement normalization and recovery-obligation retirement. Native remains paused unless the separately reviewed bounded-experiment authorization condition is satisfied; model success is not native adoption, a public API or later-slice release.

## Frozen semantic controls

Preserve original four assertions and frozen baseline evidence: compound ordinaryABC/physical recordedCAB after inspectedCBX and ownCAX rejection (held oldA/B restored, X/freshA absent, laterB field keeps ordinaryABC); prepend-flushXA/undoA/redoXA; nested appendXAY/undoA/redoXAY; nested prependYXA/undoA/redoYXA. Ordinary facts derive from source intent before install/callback, not fixture targets or late physical neighbors. Physical99/ordinary7, successor-first lifetime-sensitive placement and atomic interleaved-full-order refusal stay unchanged.

Original snapshot/sparse controls and old linear cleanup expectations remain preserved, not edited into successor results. New bounded-work assertions are preregistered separately. The successor must expose the same meaningful operation surface; unsupported cases are explicit gaps.

## Distinct indexed responsibilities

1. Current ordinary agreement: exceptions remain while O differs from P, independent of recovery/history lease counts. Drain cannot erase needed ordinary divergence merely because the last recovery lease ended.
2. Recovery/history obligations: immutable admitted fact images remain indexed while at least one live lease requires them. A current exception converging to P does not authorize deletion of a still-live inverse image. Source admission/settlement authority remains separate from index maintenance.
3. External roots: held identity descriptors, returned immutable facts, consumed/discarded prepared handles and closures can retain objects outside model-owned indexes. Report these separately; internal count zero is not GC or universal stale-handle authorization proof.

Index keys must be lifetime/owner or exact admitted unit identity as appropriate, never business key. Same-key freshB cannot inherit oldB's obligations or retired-neighbor aliases. Do not create a permanent retired-lifetime inventory just to enforce a test.

## Agreement normalization invariant

For every admitted unit, privately determine union of changed physical and ordinary presence/key/adjacency slots, including reciprocal neighbors and head/tail. Existing O exceptions in a P-only changed slot MUST be reconsidered; excluding them recreated the prior missed-convergence problem. Missing override may fall back only under a maintained agreement certificate. Normalizing unrelated entries is unnecessary and cannot be hidden in prepare/install/lease indexing.

At full divergenceN, local convergence of exactlyfour adjacency records must retire thosefour semantic overrides by touching the changed/dependent union, without scanning allN retained exceptions. RemainingN-4 exceptions stay correct. A local operation that convergesnothing likewise must not rescanN. Full reorder/full output genuinely touchingN may costN; count it separately.

## Last-obligation and alias lifecycle

- Two leases sharing the SAME immutable unit: releasing one keeps all required unit images usable; releasing the last drops model-owned recovery metadata once no other current obligation requires it.
- Two distinct units sharing one lifetime or placement anchor: release is by exact unit/lease membership, not broad lifetime deletion. Either inverse remains available while its lease lives.
- Same lease name replaced/extended: prior membership removed and new membership installed coherently; duplicate unit references need a stated set-or-multiset rule. Repeated retain/drain cannot leak refcounts, underflow or prematurely retire images.
- Repeated drain/nonexistent lease is defined and cannot clear current divergence or another live lease. Retired index keys and empty sets/maps must not accumulate after churn and last-lease release.
- Held oldB while fresh same-key B is active: stale field/rekey cannot retarget; recovering a different still-leased D must stay useful after oldB lease drains. No invalid resurrection over an occupied key is needed to establish that fact.

## Failure and reentry atomicity

Index preparation must not mutate live agreement or lease maps. A controlled failure after partial index preparation installs neither new index entries nor partial refcounts, does not lose old lease membership, and leaves useful recovery intact. Stale revision after independent reentry refuses before any physical/ordinary/index install; source facts and index plans cannot be paired across revisions. Preparation allocation/copy work is counted even on failure.

Successful installation presents complete physical, ordinary and index state before callbacks; callbacks may prepare/retain/release other units without outer delayed work overwriting them. Post-install callback throw must leave coherent installed obligations. Last-lease release does not silently reopen terminal authority.

## Accounting and bounded-work evidence

Inspect code, hash sources/harness/preregistered expectations before execution and preserve first failures. Count actual index key/member reads/writes/allocations, stage clones, cleanup visits, fact/anchor traversals, touched-union construction, retired-key deletion and immutable payload copies. A full-index clone/scan moved from drain to retain or prepare is still linear work. Reporting scans may be separate, but a scan needed to perform retirement cannot be relabeled verification.

UseN16/256/1024 fixed local workloads, partialfourofN convergence, unrelated divergence, local repeated cycles1/8/32, shared/multiple staggered leases, same-key old/fresh descriptors and full-order controls. Report prepare/install/retain/release/current-semantic state/internal recovery metadata/external roots separately. Specify whether counters represent unique stored nodes, references or cumulative allocations; no CPU/bytes/GC conclusions.

Pass requires correct semantics plus bounded touched/dependent work for local normalization and lease release, with no hidden whole-index scan. If correctness passes but requested locality does not, report that negative result without optimizing beyond authorization. A reviewed model pass can support only the user-authorized bounded native experiment decision, not automatic adoption or a waived recurrence gate.
