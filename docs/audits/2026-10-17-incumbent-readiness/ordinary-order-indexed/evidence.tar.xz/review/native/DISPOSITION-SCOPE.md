# Independent interpretation: private selected-disposition carrier and payload owner

Read CONSUMER-CONTRACT.md and cross-baseline/FINDING.md under this review/native directory, plus source-owner design and current adapter publication seam. No implementation change or new executable pass is claimed by this interpretation.

## Scope ruling

An explicit private selected-ordinary-disposition marker at the prepared inverse publication handoff is within the authorized bounded six-path handoff, provided it identifies a selection the existing transaction/restoration authority already made. It does not inherently add a public API, a canonical store or a new architectural authority. Original operation/adoption versus an already-selected inverse are materially different responsibilities that existing ordinaryChanges metadata did not discriminate; naming that existing distinction is a private carrier completion.

This remains narrower than a new consumer policy. The marker must not select which contribution should be removed, waive refusal, manufacture order intent, authorize new adoption, or globally reseed a relationship from source ordinary state. Nor may the consumer infer the distinction from origin-string coincidence. Existing authority selects disposition; source prepares exact immutable facts; consumer applies that explicit footprint under its existing relationship authority while still observing the original physical event once.

The prohibition on downstream repair substituting for source preservation does not forbid this handoff: source ordinaryABC and A/C removal facts were independently verified before the consumer. A consumer adding its own neighbor repair, expected baseline, source reread or alternate order engine would violate it. If preserving connection semantics requires such an expansion rather than consuming selected facts, stop with that concrete finding.

## Why the marker is necessary but not sufficient evidence

Cross-baseline evidence establishes that ordinaryChanges is source responsibility, not a complete connection-relative operation. An ordinary remove of inspection-createdX can have empty source contribution yet must removeX from a later-created relationship whose baseline adopted it. Ordinary point adoption of inspection-createdX uses latent physical placement, and diagnostic source ordinary anchors can differ without invalidating existing relationship semantics. Therefore blanket selection/suppression by presence or emptiness of ordinaryChanges is wrong.

A selected inverse is the point at which source already holds an explicit authorized ordinary footprint, so a separate discriminator avoids applying that interpretation to ordinary operation/adoption. But 'exact preparedO' must mean explicit selected edits, not replace the whole relationship with globalO. A relationship created after inspection may legitimately have different eligible members/payload/order. The model's ABC ordinary baseline is not an oracle for that relationship.

## Bounded falsifiers before accepting implementation

- Preserve original pre-inspection compound test: selected inverse produces eligibleABC, later B update retainsABC, held lifetime/absence checks unchanged; record P independently.
- Preserve both cross-baseline ordinary controls: before/after-inspection connections; source-empty ordinary remove still affects later connection; latent inspectedX then field adoption remainsX,A where established. Marker absent for these original operations regardless of participation/origin.
- Two simultaneous connections process one marked unit independently, without a global 'already consumed' bit or cross-seeding.
- Selected inverse with empty ordinary facts updates P context but cannot fabricate an eligible add/remove; repeated physical records carrying one selected fact apply it at most once per relationship/operation. Identity dedup must not become an unbounded tombstone inventory.
- Root/nested collection and row/field projections retain exact field footprints, baseline payloads, rekey and same-key lifetime isolation. No whole-row adoption from a field fact.
- Metadata copying, batching/coalescing, multiple units and mixed original/selected events preserve disposition identity. A selected marker cannot bleed into a later ordinary event; partial/empty summaries remain affirmative and correctly paired.
- Observers/reentry see complete P and eligible updates; callback throw or refused/stale inverse does not emit a successful marked disposition. Mark only after existing selection/preparation, never on a refusal or every realized writer.
- Later-created-link compound rejection is an interpretation discriminator: assert established explicit source/relationship footprints, not an invented unconditional globalABC outcome. If expected behavior cannot be derived from existing contract, report that semantic question rather than encoding a preferred result.

A tiny internal method separating physical observation from eligible selected edits can preserve existing authority; it still needs these falsifiers. Full declared-Link lifecycle/adoption remains later-slice qualification. No current corrected consumer is accepted by this scope ruling alone.

## Payload correction

Removing persistent E.value from placement-only owner records and obtaining current payload exclusively from EntityValueStore (with private per-unit staged values) is directly required by the already-approved source-owner design. It is not an architecture expansion. The previous cached owner payload demonstrably restored2 after an ordinary44 write; this violates the sole-payload-owner premise.

The correction must retain ordinary values for physically absent/relocated lifetimes through the existing value owner/backing claims, not drop necessary existence semantics or substitute physical display. Private staged values during ordered preparation are appropriate to represent earlier operations in the same unit; immutable captured inverse payloads remain required recovery facts. No persistent alternate payload cache is justified solely by placement divergence.

Required replay: unchanged SOURCE-PAYLOAD probe (inspection order then ordinary44 then structural remove/inverse preserves44), pure placement divergence plus direct point realization/field update, physically absent ordinary-present row, ordinary adoption/rekey, P99/O7 relocation, failed/stale source preparation. Implementation source/types and these results still require review; current native files inspected here still contain the old E.value representation, so no claim of completed payload correction is made.
