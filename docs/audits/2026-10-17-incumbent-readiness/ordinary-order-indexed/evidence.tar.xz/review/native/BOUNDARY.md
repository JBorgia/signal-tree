# Independent native handoff boundary adjudication

The frozen source owner now prepares correct ordinary facts for the compound witness. The unchanged ordinary-only test still fails at Link egress. A narrow consumption of existing prepared ordinary evidence is within the authorized finite source-owner/consumer handoff requirement; it is not a substitute for source preservation. This does not authorize changing Link baseline/declaration eligibility, inventing neighbors downstream, or broad later-slice Link migration. An implementation must preserve the distinct local physical-context protocol; blindly replacing every physical notification with an ordinary tuple is not proven safe by this witness.

## Exact identity and independent execution

Verified all six diagnostic-source/MANIFEST.sha256 files match native before execution, including entity-signal cca2036d0dcda3d982ca73761df2b00e5d28bc6cf0f13e94910d93fc5bab0950 and tree-realization-adapter78867a0b66073ac14f32089607792f7e6e037d7c463fac91977301798a90b2af. Additional Link/projection/selector/test hashes recorded in BOUNDARY-BEFORE.sha256; raw probe source hash in BOUNDARY-PROBE-BEFORE.sha256.

Executed unchanged Nx test with Node24.15.0/pinned corepack pnpm, COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false:

    corepack pnpm exec nx test kernel --testFile=src/enhancers/transactions/native-compound-ordinary-order-regression.spec.ts --skip-nx-cache

Result: RED at original ordinary egress assertion, expectedABC actualCAB. BOUNDARY-NX.log preserves it. No test assertion/runtime edits.

Independent boundary-probe.ts logs existing PathNotifier metadata, observable physical rows and Link payloads; fresh esbuild replay BOUNDARY-PROBE.log. On this exact diagnostic source physical final order isABC, while Link publishesCAB immediately and after later B5. Earlier descriptions of physicalCAB are not an execution result for this exact source. This review does not prescribe physicalABC; it records it.

## Last correct fact and first consumer loss

Raw own capture removal B is ordinary A/C, not inspected C/X. Existing source diagnostic OWNERORDER logs1/2/3 at inverse preparation. Adapter ordinary changes are remove freshA; add oldA beforeC; removeX; addB betweenA/C. No sourceordinaryABC fact is absent at this boundary.

Actual inverse notification for oldA carries two different valid descriptions:

- physical structuralEffect: add oldA, afterSubject:B (physical realization context);
- prepared ordinaryChanges: add oldA, afterSubject:C (source-admitted ordinary execution context).

B notification includes ordinary A/C anchors. The two channels coexist in existing metadata. Adapter publicationMeta groups prepared ordinary changes per affected lifetime using withEntityOrdinaryChanges. The ordinary sequence is not reconstructed from fixture targets or Link state.

Link.ts entityProjection branch around676 reads only `meta.structuralEffect` and feeds it to EntityEgressProjection.apply. The nested collection branch657 does the same. Neither branch calls ordinaryEntityEntries/getEntityOrdinaryChanges. apply first topology.observe(effect), then for add places into eligible order using that local topology. OldA's physical successorB is not yet present in this notification prefix, so local topology placement can fall back afterC; the consumer thereby uses physical execution context to advance ordinary eligible order. Later B insertion and ordinary field update do not repair that eligible order. This is the first demonstrated loss after correct source ordinary preparation, not a remaining missing source B-anchor fact or a Link flush timing issue.

## Contract/scope ruling

The approved premises require every inverse consumer to use the retained ordinary placement consistently. SOURCE-OWNER-DESIGN specifies immutable source facts before inversion/publication, ordinary inverse consumers using them, no Link-owned order authority, and existing Link connection-local baseline/eligibility remaining separate. NATIVE-PLAN requires same prepared facts and no consumer protocol/public API change. Existing ordinaryEntityEntries already selects prepared source ordinary records for transaction/restoration consumers; the metadata mechanism is not newly invented for Link.

Accordingly, advancing Link's eligible ordinary contribution from the already-prepared ordinary records is an unmigrated existing handoff within this finite witness. It does not violate the prohibition on a downstream adjustment *substituting* for source preservation: source preservation is independently verified here and no replacement ordinary target/neighbor is proposed. This is not automatic permission to change consumer authority or qualify full declared-Link lifecycle/later slices.

The important constraint is dual context. entity-egress-projection.ts explicitly defines local topology as current source reality, including inspection, and eligible authority as connection-local authored/adopted state. Existing common ordinary selector strips physical transition metadata and yields ordinary tuples; a blanket substitution could lose the physical latent context used by later adoption, or alter row/field/nested source behavior. The witness does not prove that one selector call alone preserves those protocols. A bounded implementation may consume existing O evidence while preserving the existing physical-context path and footprint/baseline eligibility, without creating a second source authority. If doing so requires new public metadata/API, a new eligibility/adoption rule, new generic topology engine or broader consumer redesign, that concrete expansion must stop for authority rather than being called a selector fix.

## Required falsifiers before accepting that handoff

Keep source-owner assertions/diagnostic identities and original ordinary regression unchanged. Verify root and nested collection egress, empty ordinaryChanges (affirmative no ordinary contribution), multiple/displaced lifetime records, inspection-only topology followed by later necessary adoption, Link created before/after inspection baseline, row/field footprints, rekey and existing declaration eligibility. Existing eligible relationship state cannot be reseeded from current physical or global ordinary snapshot to obtain green. No catch/drop or writer-specific neighbor exception is acceptable.

These are bounded compatibility checks for the proposed handoff; they are not a demand to implement later-slice product behavior. No corrected Link implementation was executed or accepted by this report, and current native experiment remains failing the unchanged ordinary witness. No native source/test edits performed.
