# Independent bounded subset-order adjudication

For this exact matched-baseline case, compatibility entails ordinaryCBA after confirm and ordinaryABC after reject. No additional owner choice is needed to preserve that behavior. This does not authorize dropping ordinaryB toCA or importing every connection-relative rule into source authority.

## Evidence and premise

Read subset-probe/FINDING.md and its recorded sequence: control and frozen fifth both begin ordinaryABC with a preinspection Link whose baseline is alsoABC; inspection removesB physically but contributes no ordinary removal; own setAllCA emits a visible A/C reorder. Confirm publishesCBA and later ordinary field preservesCBA. Reject publishesABC and later field preservesABC. Physical output is separately AC/CA as recorded, not forced to ordinary order.

These are root/other-reviewer executable evidence, not newly rerun by this interpretation. The fixture excludes the connection-created-after-inspection difference that previously made source-versus-relationship inference ambiguous. The required same-source-facts agreement and nonauthoring inspection premises therefore align source ordinary state with this known public outcome in this bounded fixture.

## Derived authored source footprint

1. Before own operation, O remainsABC; B's physical inspection removal cannot silently become ordinary removal.
2. The own native operation's physical surviving subset isA/C, explicitly orderedC/A. No source-selected ordinary removal of B exists in that operation. Order intent cannot itself remove a lifetime.
3. Apply that order footprint to the included A/C slots of ordinaryABC, retaining B's omitted slot and membership. ResultCBA. This is an order-only permutation over the affected subset, not a full ordinary membership replacement.
4. Prepare immutable ordinary beforeABC/afterCBA (or equivalent certified delta) while both endpoints exist. Keep physical beforeAC/afterCA and physical frontier separately.
5. Confirm retainsCBA. Reject uses the selected inverse ordinary order footprint to restoreABC under existing authority. No physicalAC/CA expectation is changed and no global relationship reseed is required.

An implementable source-owner mechanism is: stage ordinary membership effects first; identify the explicitly authored surviving order domain from the existing operation; replace only those domain slots in the staged ordinary sequence with the requested domain order; preserve ordinary-present lifetimes outside that order domain. Validate all requested domain lifetimes/uniqueness against staged ordinary presence, then capture both full ordinary endpoints at this explicit-order boundary. A full order operation may process its required sequenceN; point work must not call this machinery.

This uses the one existing source owner and existing authority. It does not grant order-only intent a new removal/adoption permission, create another canonical store, or reinterpret Pfrontier as Oproof. Necessary membership adoption/displacement remains separately explicit source facts.

## Scope qualification

My earlier warning that the relationship helper alone is not source authority still stands generally. The new matched-baseline controlled public trace supplies the previously missing compatibility derivation for this exact subset. Reusing its *derived footprint* at the source is justified; reverse-calling Link or copying the helper's mutable eligible state is not.

Relationships created after inspection can retain different eligible baselines, so selected ordinary order must still be applied as an explicit eligible footprint, not replace those baselines wholesale. Cases with membership adoption, replaced lifetimes, removed anchors or independent intervening ordinary order continue to use their established semantics/refusal; this finding does not invent outcomes for them.

Required bounded controls: preserve both confirmCBA/laterfieldCBA and rejectABC/laterfieldABC on the unchanged subset fixture; preserve same-three-lifetime S4 discriminator and no-explicit-order compound; assertB remains the same ordinary lifetime, not an adopted replacement. No additional owner permission is required merely to carry separate private O endpoint proof and implement this already-observed authored subset permutation. If actual implementation needs a new selection rule beyond that footprint, report the exact new case rather than treating this established outcome as undecided.
