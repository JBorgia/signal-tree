# Independent criteria: bounded indexed-owner native experiment

Written before final changed-source review/execution. Governed by NATIVE-PLAN.md, SOURCE-OWNER-DESIGN.md, native obligation audit and unchanged contracts. Control is rejected770-file source manifestd1ff7c33a380d578390879a79e142950d0655920710a818af7d49fe2a017521b. Native worker may be editing: no final execution until explicit source freeze and exact diff/manifest.

## Finite success witnesses

Run unchanged prepend-publication-boundary.spec.ts and native-compound-ordinary-order-regression.spec.ts, preserving original first reds (three redo anchor failures plus ordinary egress leak). Compound ordinaryABC must survive rejection and later ordinaryB write; record physical order independently without imposing exactCAB from the model input. Any physical change needs justification under the approved footprint/successor/reentry semantics; oldA/B lifetime identities restored, X/freshA absent. Do not substitute the older physicalABC hypothesis assertion for ordinary egress. Prepend outer source facts must already carry final placement before onAdd flush/nested append/prepend; undo/redo must consume the same admitted facts.

Independent post-freeze falsifier must inspect observable ordinary egress separately from physical order, not just aggregate pass count. Add a bounded challenge selected from concrete source risks (e.g. existing full inspection divergence followed by point write/inverse, source preparation failure after capture staging, inspected lifetime existence adoption, direct reentry/full target). Hash before execution and preserve first failure.

## Six actual route obligations

S1: commitExistingSubjectValue is physically adjacency-neutral but can adopt necessary ordinary existence; preserve approved field/key/absence semantics and P99/O7. __preparePointValues directly installs values without a frame; justify its unchanged membership/key preconditions, ordinary payload participation and no accidental placement inference.
S2: frames plus direct prepend/full-order/create bypasses. create/restore/tombstone/transfer/placement must preserve every changed reciprocal physical edge and head/tail before install. Direct allocateSubjectId/createSubject1532 must not silently install unprepared adjacency. Final prepend placement is one prepared unit, not frame append followed by delayed move. setAll distinguishes real order intent from incidental survivor order under inspection divergence.
S3: point/sparse inverse uses source ordinary facts and approved physical realization; selected inverse sequence/authority unchanged. Existing exceptions in P-only touched slots must normalize too.
S4: complete target installation must stage ordinary disposition and physical target together, with revision validation before installing any member/value/selection. Physical target cannot seed ordinary order.
S5: key/lifetime restore/revival honors non-reused IDs, same-key replacement, successor-first placement, missing/occupied destination refusal; key agreement cannot discharge ordinary placement divergence.
S6: reclamation/forget/retire and logical destroy. Current ordinary divergence survives zero recovery leases; existing pending/history claims protect backing independently. No new cross-consumer lifetime registry or instantaneous last-claim callback is smuggled in. Cleanup attaches to actual tree/source lifecycle; public clear is not destruction.

Hidden collection wrappers and marker hydration must enter these same seams; parent membership remains existing authority. Inventory requirements are not executable coverage proof. All changes stay internal; no public adapter/type/activation/budget change, no new settlement authority or blanket refusal.

## Atomicity, reentry and responsibility

All source ordinary-before/after facts, final physical footprint and installed owner updates share one revision. Preparation may allocate private indexes/patches but cannot mutate live owner maps, linked state, source responsibilities or leases. Controlled failure after owner/capture preparation leaves both domains and useful inverse authority unchanged. Source callback/getter reentry must invalidate the entire stale plan, preserving newer writes; do not revalidate only part after physical mutation.

Installation must be callback-free and free of ordinary recoverable throws after the first live target installs, under the established native contract. Capture/publication observes complete ordinary+physical state. Post-install observer throw preserves installed responsibility and usable recovery; failed automatic abort must not strand authority. No delayed outer placement overwrites callback-authored changes. Order conflict refuses before any scalar/entity inverse or rollback publication and retains retry/confirm.

## Indexed work and retention

Count native source owner probes/edits, physical footprint visits, ordinary neighbor reads, agreement updates and cleanup, not merely active-key scans. AtN16/256/1024 fixed point mutation/inverse while whole inspection order diverges, touched/dependent owner work must not scan all exceptions or clone a complete ordinary index. Four-ofN physical convergence must touch/normalize those dependent slots and preserveN-4 divergence. Full requested order/target/output can processN, labeled separately.

No global exception scan hidden in preparation, install, retain/release, descriptor cleanup or telemetry consumed by semantics. Current ordinary state, pending/history responsibility, ordinary payload ownership and externally held references are separately accounted. Ordinary placement should not copy payload graphs solely for neighbors. Existing values may remain owned by EntityValueStore; any new strong references need justification. Zero pending/claims is not enough to clear current ordinary presence/edges.

Retained terminal handles and same-key stale references cannot become permanent source registries or retarget replacement lifetimes. Repeated local cycles with drain must not accumulate empty index entries. Internal logical count zero is not GC while tree/handle roots remain. Existing transaction claim release-before-restoration-capture ordering must remain intact; no premature sink invocation.

## Verification and disposition

Review exact frozen source diff and manifests against the control. Run focused Nx checks using Node24.15/pnpm10.17, one recorded deduplicated combined argument union and relevant type/spec-type/lint gates; independent review owns only its own executions. Preserve unrelated code and old failed artifacts; do not widen to broad suites or benchmarks.

Pass can establish only this bounded experiment's correctness/cost observations. A new semantic conflict, required public API, separate authority, writer-specific downstream repair, unsupported full-source rewrite or repeated failure of the claimed source boundary is a concrete escalation under existing recurrence/later-slice rules. No native adoption or later activation is implied even if finite tests pass.


## Physical-order qualification

Initial criteria preserved as ACCEPTANCE-CRITERIA.initial.md. The original ordinary-only compound test deliberately does not prescribe physical placement. RecordedCAB was an observed native realization and shared model input, not a separately established mandatory public outcome. This correction preserves all original assertions: ordinaryABC and later ordinaryB update, oldA/B identities and rejected lifetime absence remain required. Any changed P output must be reviewed against existing authorized footprint and successor/reentry contracts; neither exactCAB nor the older physicalABC hypothesis is assumed.
