# Source ordinary records and connection-relative projection

Read-only native review, October24. No edits or execution. Current source owner can prepare O ABC while physical projection remains CAB. Consumer source references inspected: ordinary-entity-entries.ts9–27; entity-egress-projection.ts82–207; link.ts310–338,650–690; experimental-publication/projection.ts entire module.

## Concrete mismatch

Link passes notification structuralEffect to EntityEgressProjection.apply. apply first topology.observe(effect), then for ordinary add calls place(), whose topology.placement derives position from the **physical** topology. Even feeding corrected ordinary add anchors through ordinaryEntityEntries is not automatically sufficient: it would mutate that physical latent topology using ordinary anchors, and subsequent physical notifications could overwrite the basis. This violates two distinct channels, not merely a missing array reorder.

ordinaryEntityEntries intentionally selects source ordinary mutations (empty list is affirmative). It replaces effect/value/subject with prepared ordinary facts and strips their envelope. Appropriate for responsibility/history consumers, but Link also needs the original physical event to update its latent topology on inspection. Replacing the entire callback input with ordinaryEntityEntries alone discards information.

## Existing contract that must survive

Link relationship creation explicitly adopts its current display, including prior inspection (link.ts310–338). EntityProjectionSeed snapshots current active physical order. Two connections created before/after inspection may legitimately have different eligible lifetimes/order/payload baseline. Source ordinary current state cannot reseed either relationship globally. Similarly an inspection-created lifetime adopted at connection construction can remain eligible even if source ordinary records report no change for later inspection-neutral removal; the relationship must apply its existing participation semantics, not erase its baseline by source normalization.

## Bounded mechanism for executable falsification

Preserve original P structural event for local latent topology, exactly once per source notification. Separately supply prepared ordinary edits as **authored semantic footprint**, not a replacement snapshot/baseline. For ordinary eligible installation whose source record has explicit placement, resolve position using its ordinary lifetime anchors filtered through this connection's eligible lifetimes, under existing lifetime-sensitive successor/predecessor policy. Keep connection-only eligible members/payloads that source did not explicitly author/remove; source O ABC must not force a connection seeded inspectionCBX back to ABC wholesale.

This requires an internal projection method separating observePhysical(effect) from applyEligible(edit); not a new public API or second source authority. The projection remains connection-owned eligibility authority, as it already is. Exact pairing/operation identity prevents applying one source ordinary edit multiple times across physical row notifications. Field projection still uses semantic field footprint and relationship prior values. Collection order events likewise need P topology update separate from authorized eligible order intent; never promote inspection order.

Critical caveat: source ordinaryChanges is a responsibility footprint, not necessarily the complete operation as experienced by a relationship whose baseline adopted prior inspection. Therefore do not simply suppress all relationship updates when source list is empty. Implementation must retain existing physical ordinary operation semantics for relationship-adopted members while using source ordinary placement evidence where a source inverse explicitly restores ordinary facts. If event metadata cannot distinguish original operation participation from selected ordinary inverse disposition, this is a concrete private carrier gap requiring review before a blanket selector change.

## Required controls before choosing implementation

1. Existing connection before inspection: compound regression O ABC/P CAB must publishABC after rollback and retain it after ordinary B field update.
2. Connection created during inspected CBX: baseline staysCBX; source ordinaryABC does not retroactively replace it. Exercise own compound operation/rejection, specifying only established authored footprint; no automatic ABC expectation for this later-created connection.
3. Pre-inspection and post-inspection connections simultaneously: same source event updates each coherently without cross-seeding.
4. Inspection-created member is eligible at connection creation; ordinary remove of it still removes it from that relationship, even when source ordinaryChanges is empty.
5. Inspection-only add after connection stays latent; later explicit field adoption reveals only necessary member, preserving connection eligible order.
6. Removed/replaced anchors, rekey and same-key lifetime isolation, repeated source notifications and callbacks/reentry retain existing semantics.
7. Experimental projection identity layer consumes **native Link's resulting payload** only (module comment); it must not resolve source truth or reorder rows. Its project/refresh ticket identity remains separate from ordinary disposition.

No inherent public-semantic conflict is proved by source inspection. A dual-channel private projection is a plausible bounded correction, but the relationship-baseline cases above are necessary falsifiers, and existing ordinaryChanges alone is not demonstrated to supply all needed connection-relative operation information. No recommendation to reverse-call Link or replace its baseline with source owner state.
