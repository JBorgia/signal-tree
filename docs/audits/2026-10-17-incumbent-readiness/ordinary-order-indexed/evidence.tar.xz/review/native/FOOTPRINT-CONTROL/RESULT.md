# Preserved predecessor footprint control

Executed unchanged file from /private/tmp/inverse-disposition-native/candidate using Node24.15.0 / Corepack pnpm10.17.0:

 COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false corepack pnpm exec nx test kernel --testFile=src/lib/entity-egress-footprint.spec.ts --skip-nx-cache

Result:13 pass /2 fail. Both reported fourth-candidate reds reproduce: updater expected ordinary x0/y2 receives inspected x99/y2 (line180); identical replacement/identity updater expects no send but publishes inspected x99/y0 (line216). Thus these two assertions are inherited in this preserved predecessor control, not newly introduced by fourth candidate. This establishes neither production provenance nor permission to ignore their public contract consequences.

Raw control.log retained. before.sha256 and after.sha256 of test/entity-signal/link are identical; no source changes performed. These three hashes are bounded identity checks, not complete package manifest. Exit1 is actual test failure, not runner/tool failure.
