# Independent source-owner payload retention falsifier

Concrete source blocker demonstrated on the exact diagnostic owner implementation. Placement-only retained records cache row payload E.value; an ordinary point update does not necessarily refresh that cache, and a later structural inverse captures/restores stale payload. No Link consumer is involved.

## Identity and execution

Bundle overrides all six owner/adapter implementation files with immutable diagnostic-source copies, identified in payload-replay/BEFORE.sha256 and diagnostic-source/MANIFEST.sha256. Relevant owner SHA990d176db8b2f5667a6072f1a66e9c4c7f0882775cc7c66143efbd9da1651df4; entity-signal cca2036d0dcda3d982ca73761df2b00e5d28bc6cf0f13e94910d93fc5bab0950. This isolates the source question while the worker changes an unrelated consumer. Script/build/log live only in this review's payload-replay directory; no native/test edits.

Commands:

    node review/native/payload-replay/build.cjs
    node review/native/payload-replay/probe.mjs > review/native/payload-replay/FIRST.log 2>&1

Node24.15.0, fresh esbuild standalone public-operation probe with established inspection write-context harness. First execution RED, preserved.

Sequence: seed ordinary a1/b2/c3; inspection-only setAll order c3/b2/a1; ordinary updateOne b.n44, assert held b reads44; pending transaction removeOne b; rollback; assert same held b lifetime restored and n44 preserved.

Actual: rollback restores same b lifetime with n2. Source diagnostic capture already shows removeB value2, A/C neighbors. FIRST.log preserves exact expected44/actual2 assertion. No physical order expectation is imposed.

Comparator: fresh bundle redirects native source imports to preserved rejected candidate /private/tmp/inverse-disposition-native/candidate. CONTROL-BEFORE.sha256 records comparator source/build identities. Same unchanged probe passes, restores heldB44. CONTROL.log records result. Thus the new placement-retention behavior introduces this counterexample relative to the preserved pre-successor source, even though that older source has other rejected defects.

## First loss and mechanism

EntityOrdinaryTopology.prepareInstall stores `{...ordinaryPlacement,value:value(subject)}` for every divergent presence/key/adjacency record. Inspection full reorder therefore creates placement-only records caching original b2.

commitExistingSubjectValue prepares current EntityValueStore ordinary transition to44 and calls prepareOrdinaryTopology. Its field-change branch stages the new value, but the write helper only edits placement for absence/adoption/key changes. A normal field-only update leaves the ordinary placement patch empty; physical value update also has no placement patch. prepareInstall processes only union of placement patch keys, so it does not refresh existing B's cached value.

Later prepareOrdinaryTopology.read prioritizes `staged.get(subject) ?? ordinaryTopology.read(subject)` and selects known.value when present, ahead of EntityValueStore.ordinaryForSubject. It therefore uses stale2 as the remove ordinary payload and captures stale structuralRecord.value before inversion. The inverse restores exactly that stale captured value. This is source contamination before consumers, not Link metadata selection, replay sorting or a model index-retirement failure.

## Boundary classification

The old owner already held values for membership/key exceptions. The discriminator intentionally introduces only inspection order divergence, for which old source created no B occupancy exception; its same probe passes. New placement exceptions expand the stale value path to ordinary present members, so dismissing this as merely pre-existing presence behavior is unsupported.

This is a concrete incomplete implementation of the explicitly approved payload/placement ownership boundary: source-owner design keeps EntityValueStore as ordinary payload authority, and native plan says not to duplicate payload ownership solely for placement. The indexed placement representation can express correct neighbors; the failure comes from reading a second cached payload without synchronizing an unchanged-field route. It does not prove ordinary placement itself is unrepresentable or require new public semantics. Whether it triggers the user's recurrence-stop rule is a contract adjudication separate from this source trace; no repair is authorized/performed here.

Current native diagnostic remains unaccepted for this new public mutation regression. Any correction must preserve necessary ordinary existence/physically absent payload semantics and P99/O7, not simply delete fields or weaken the expected44 assertion. A source fix needs paired point/structural/adoption/failure controls before being called complete.
