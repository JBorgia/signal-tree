import {getPathNotifier} from '../../native/packages/kernel/src/lib/path-notifier';
import {getEntityOrdinaryChanges} from '../../native/packages/kernel/src/lib/internals/entity-value-transition';
import { signalTree, entityMap, transactions, link } from '../../native/packages/kernel/src/index';
import { withWriteContext } from '../../native/packages/kernel/src/lib/write-context';
import { getMutationCaptureRuntime } from '../../native/packages/kernel/src/lib/internals/mutation-capture-runtime';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
const t=signalTree({x:0,rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
const r=t.$.rows,sent:unknown[]=[];const offMeta=getPathNotifier().subscribe('**',(v,prev,path,ownerPath,origin,subjects,positions,meta)=>{if(origin==='transaction-rollback')console.log('HANDOFF',JSON.stringify({path,subjects,physical:meta?.structuralEffect,ordinary:getEntityOrdinaryChanges(meta)}));});
const off=getMutationCaptureRuntime(t)!.subscribeCollectionOrder!(capture=>console.log('order-admission',JSON.stringify({before:capture.beforeSubjects,after:capture.afterSubjects,meta:capture.meta})));
try {
r.setAll([{id:'a',n:1},{id:'b',n:2},{id:'c',n:3}]);await tick();
const c=link(r,{set:v=>{sent.push(structuredClone(v));}});
try{const oldA=r.byIdOrFail('a'), heldB=r.byIdOrFail('b');r.updateOne('b',{n:4});await tick();await c.settled();
withWriteContext({participation:'inspection'},()=>{r.removeOne('a');r.addOne({id:'x',n:99});r.setAll([{id:'c',n:3},{id:'b',n:4},{id:'x',n:99}]);});await tick();await c.settled();
console.log('pre-authored',JSON.stringify({physical:r.all(),sent}));
const heldX=r.byIdOrFail('x');
const p=t.transact(()=>r.setAll([{id:'c',n:3},{id:'a',n:9},{id:'x',n:99}]));
const freshA=r.byIdOrFail('a');
console.log('pending',JSON.stringify({physical:r.all(),inspect:p.inspect(),sent}));
p.rollback();await tick();await c.settled();
console.log('post-rejection',JSON.stringify({physical:r.all(),inspect:p.inspect(),sent,held:{oldA:oldA(),b:heldB(),x:heldX(),freshA:freshA(),aIdentity:r.byIdOrFail('a')===oldA,bIdentity:r.byIdOrFail('b')===heldB}}));
r.updateOne('b',{n:5});await tick();await c.settled();console.log('later-ordinary',JSON.stringify({physical:r.all(),sent}));
}finally{c.dispose();}
}finally{offMeta();off();t.destroy();}
