# Native source-boundaries spec preregistration

Only edited packages/kernel/src/lib/ordinary-order-source-boundaries.spec.ts. Existing raw first failures (payload-replay/FIRST.log and cross-baseline logs) remain untouched. Hash recorded in SOURCE-BOUNDARIES-PREREG.sha256 before any test execution. Runtime is still being edited; no execution yet.

Five tests: payload44 after placement inspection then structural rejection; collection and nested-branch original remove/adoption controls with simultaneous pre/post-inspection connections; collection and nested-branch selected field inverse preserving each different relationship baseline. Selected inverse asserts only the explicit A field footprint: A7->A1, inspection-only X stays excluded from preexisting connection and stays in later-created connection baseline. No globalABC expectation is invented for a later-created relationship's compound structural inverse.

Publication assertions examine exact payloads after useful updates and require increased send counts for both forward and inverse. Silence is asserted only for the actual inspection/no-op relationship boundary. No native runtime edits or weakened original assertions. Execution is held for worker freeze; root will include spec in combined focused gate.
