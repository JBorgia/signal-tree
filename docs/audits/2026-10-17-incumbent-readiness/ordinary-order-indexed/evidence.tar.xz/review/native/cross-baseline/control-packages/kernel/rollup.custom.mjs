import path from 'node:path';
import { fileURLToPath } from 'node:url';

import typescript from '@rollup/plugin-typescript';
import { dts } from 'rollup-plugin-dts';
import { createLibraryRollupConfig } from '../../tools/build/create-rollup-config.mjs';

const packageRoot = path.dirname(fileURLToPath(import.meta.url));

const baseConfigFactory = createLibraryRollupConfig({ packageRoot });

export default (config, options) => {
  const baseConfig = baseConfigFactory(config, options);
  const statsStubPath = path.join(
    packageRoot,
    'src',
    'lib',
    'internals',
    'production-substrate-stats.prod.ts'
  );

  const productionStatsStubPlugin = {
    name: 'signaltree-core-production-stats-stub',
    resolveId(source, importer) {
      if (!importer) {
        return null;
      }

      const normalizedSource = source.endsWith('.js')
        ? source.slice(0, -3)
        : source;

      if (!normalizedSource.endsWith('/production-substrate-stats')) {
        return null;
      }

      return statsStubPath;
    },
  };

  const stripProductionStatsCallsPlugin = {
    name: 'signaltree-strip-production-stats-calls',
    transform(code, id) {
      if (
        !id.startsWith(path.join(packageRoot, 'src')) ||
        !id.endsWith('.ts')
      ) {
        return null;
      }

      const source = this.parse(code);
      const removals = [];

      const visit = (node) => {
        if (
          node.type === 'ExpressionStatement' &&
          node.expression?.type === 'CallExpression' &&
          node.expression.callee?.type === 'Identifier' &&
          node.expression.callee.name === 'recordProductionSubstrateStat'
        ) {
          removals.push([node.start, node.end]);
          return;
        }
        for (const value of Object.values(node)) {
          if (Array.isArray(value)) {
            for (const child of value) {
              if (child?.type) visit(child);
            }
          } else if (value?.type) {
            visit(value);
          }
        }
      };
      visit(source);

      if (removals.length === 0) {
        return null;
      }

      let transformed = code;
      for (const [start, end] of removals.reverse()) {
        transformed = transformed.slice(0, start) + transformed.slice(end);
      }
      return { code: transformed, map: null };
    },
  };

  const existingPlugins = Array.isArray(baseConfig.plugins)
    ? baseConfig.plugins
    : baseConfig.plugins
    ? [baseConfig.plugins]
    : [];

  const runtimePlugins = existingPlugins.filter(
    (plugin) => plugin?.name !== 'typescript' && plugin?.name !== 'dts-bundle'
  );

  const runtimeConfig = {
    ...baseConfig,
    plugins: [
      productionStatsStubPlugin,
      ...runtimePlugins,
      typescript({
        tsconfig: path.join(packageRoot, 'tsconfig.lib.prod.json'),
        declaration: false,
        declarationMap: false,
        declarationDir: undefined,
      }),
      stripProductionStatsCallsPlugin,
    ],
  };

  // One declaration graph preserves every nominal identity across the public
  // entry points, including private construction metadata. Separate bundles
  // duplicate unique symbols; rewriting them as root imports would require
  // exporting private types. Shared chunks stay private package files instead.
  return [
    runtimeConfig,
    {
      input: {
        index: path.join(packageRoot, 'src/index.ts'),
        adapter: path.join(packageRoot, 'src/adapter.ts'),
        internals: path.join(packageRoot, 'src/internals.ts'),
      },
      output: {
        dir: path.join(packageRoot, '../../dist/packages/kernel/dist'),
        format: 'es',
        entryFileNames: '[name].d.ts',
        chunkFileNames: '_[name]-[hash].d.ts',
      },
      plugins: [dts({ respectExternal: true })],
    },
  ];
};
