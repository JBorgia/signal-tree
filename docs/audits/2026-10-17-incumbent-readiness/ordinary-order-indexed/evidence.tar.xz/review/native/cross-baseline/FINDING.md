# Executable cross-baseline findings

Isolated copies; no worker/native source modified. control-packages copied frozen predecessor; diagnostic-packages same baseline plus six frozen diagnostic-source files. before.json hashes all TS inputs and harness before esbuild/runs. Node control.mjs and node diagnostic.mjs each exited0. esbuild reported missing inherited tsconfig warning; native source bundles executed. Diagnostic contains preserved source instrumentation, evident raw CAPTURETRACE logs; no claimed pristine production artifact.

Both arms demonstrate:
- Link before inspection-created x sees no new eligible member; Link created after x adopts x into its baseline.
- Ordinary remove x has source ordinaryChanges=[] and physical remove(x). Later-created Link usefully publishes [a]; earlier connection sends nothing. Thus affirmative empty source contribution cannot globally suppress connection-relative ordinary remove. It means no source ordinary responsibility, not no independently authorized relationship operation.
- Inspection adds new-lifetime x and reorders x,a; ordinary field update x.n10 adopts x. Both connections publish [x10,a1]. This uses latent physical topology under established minimal-adoption semantics.
- Diagnostic ordinary add(x) anchors x after a, while its current Link still correctly publishes x,a from physical latent topology. A blanket switch to ordinary placement for every relationship adoption would regress this unchanged behavior. Selected ordinary inverse disposition needs discrimination from fresh connection-relative adoption.

Replay:
 node control.mjs
 node diagnostic.mjs
Harness template and emitted bundles retained. These are application-shaped native operations with established internal inspection context, not uninstrumented devtools trigger claims. No compound-after-inspection rollback expectation selected here.
