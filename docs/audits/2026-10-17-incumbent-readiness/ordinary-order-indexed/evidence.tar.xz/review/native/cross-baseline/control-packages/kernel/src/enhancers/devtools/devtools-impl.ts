declare const ngDevMode: boolean | undefined;
import type { ReadableCell } from '../../lib/internals/cell-runtime';
import {
  deriveLocation,
  getLocationRuntime,
  NEUTRAL_LOCATION_RUNTIME,
} from '../../lib/internals/location-runtime';
import { rootAuthorityFor } from '../../lib/internals/root-source';

import { applyState } from '../../lib/utils';
import { interceptLeafSignals } from '../../lib/internals/intercept-leaf-signals';
import { getPathNotifier } from '../../lib/path-notifier';
import { withWriteContext } from '../../lib/write-context';

/**
 * v6 DevTools Enhancer
 *
 * Contract: (config?) => Enhancer<DevToolsMethods>
 */
import type {
  Enhancer,
  ISignalTree,
  DevToolsConfig,
  EnhancerMeta,
} from '../../lib/types';
import type {
  DevToolsLogEntry,
  DevToolsMethods,
  DevToolsModuleMetadata,
  DevToolsPerformanceMetrics,
} from './devtools.types';
import { ENHANCER_META } from '../../lib/types';
import { appendAll } from '../../lib/internals/utilities/append-all';

// Heavy devtools implementation. Imported by ./devtools.ts ONLY past its
// ngDevMode prod-strip guard, so a production build (ngDevMode=false) drops the
// dead import and this whole module (~12KB gzip) tree-shakes out.

// ============================================================================
// Types
// ============================================================================

// `ModuleMetadata`, `ModularPerformanceMetrics` and the log-entry shape are
// PUBLIC now — `DevToolsMethods.exportDebugSession()` returns them, so
// `lib/types.ts` owns the declarations and these are aliases onto it. Keeping
// private copies here is what let the public interface drift out of step with
// what the enhancer actually returns.
type ModuleMetadata = DevToolsModuleMetadata;

type ModularPerformanceMetrics = DevToolsPerformanceMetrics;

interface ModuleActivityTracker {
  trackMethodCall: (module: string, method: string, duration: number) => void;
  trackError: (module: string, error: Error, context?: string) => void;
  getModuleActivity: (module: string) => ModuleMetadata | undefined;
  getAllModules: () => ModuleMetadata[];
}

interface CompositionLogger {
  logMethodExecution: (
    module: string,
    method: string,
    args: unknown[],
    result: unknown
  ) => void;
  logStateChange: (
    module: string,
    path: string,
    oldValue: unknown,
    newValue: unknown
  ) => void;
  logPerformanceWarning: (
    module: string,
    operation: string,
    duration: number,
    threshold: number
  ) => void;
  exportLogs: () => DevToolsLogEntry[];
}

interface ModularDevToolsInterface {
  activityTracker: ModuleActivityTracker;
  logger: CompositionLogger;
  metrics: ReadableCell<ModularPerformanceMetrics>;
  startModuleProfiling: (module: string) => string;
  endModuleProfiling: (profileId: string) => void;
  connectDevTools: () => void;
  exportDebugSession: () => {
    metrics: ModularPerformanceMetrics;
    modules: ModuleMetadata[];
    logs: Array<unknown>;
  };
}

type DevToolsActionMeta = {
  timestamp: number;
  origin?: string;
  duration?: number;
  slow?: boolean;
  paths?: string[];
  txId?: string;
};

type DevToolsAction = {
  type: string;
  payload?: unknown;
  meta?: DevToolsActionMeta;
};

type ReduxDevToolsConnection = {
  send: (action: unknown, state: unknown) => void;
  subscribe?: (listener: (message: unknown) => void) => void | (() => void);
  disconnect?: () => void;
  unsubscribe?: () => void;
  init?: (state: unknown) => void;
};

type ReduxDevToolsExtension = {
  connect: (config: Record<string, unknown>) => ReduxDevToolsConnection;
};

type DevToolsRegistryHost = typeof globalThis & {
  __REDUX_DEVTOOLS_EXTENSION__?: ReduxDevToolsExtension;
  [GLOBAL_GROUPS_KEY]?: Map<string, DevToolsGroup>;
  [GLOBAL_MARKER_KEY]?: string;
  [GLOBAL_CONNECTIONS_KEY]?: Map<string, DevToolsConnectionEntry>;
};

type LiftedStatePayload = {
  computedStates?: Array<{ state?: unknown }>;
  currentStateIndex?: number;
};

// ============================================================================
// Helpers
// ============================================================================

function createActivityTracker(options?: {
  enableConsole?: boolean;
}): ModuleActivityTracker {
  const modules = new Map<string, ModuleMetadata>();
  const enableConsole = options?.enableConsole === true;

  return {
    trackMethodCall: (module: string, method: string, duration: number) => {
      const existing = modules.get(module);
      if (existing) {
        existing.lastActivity = new Date();
        existing.operationCount++;
        existing.averageExecutionTime =
          (existing.averageExecutionTime * (existing.operationCount - 1) +
            duration) /
          existing.operationCount;
      } else {
        modules.set(module, {
          name: module,
          methods: [method],
          addedAt: new Date(),
          lastActivity: new Date(),
          operationCount: 1,
          averageExecutionTime: duration,
          errorCount: 0,
        });
      }
    },

    trackError: (module: string, error: Error, context?: string) => {
      const existing = modules.get(module);
      if (existing) {
        existing.errorCount++;
      }
      if ((typeof ngDevMode === 'undefined' || ngDevMode) && enableConsole) {
        console.error(
          `❌ [${module}] Error${context ? ` in ${context}` : ''}:`,
          error
        );
      }
    },

    getModuleActivity: (module: string) => modules.get(module),

    getAllModules: () => Array.from(modules.values()),
  };
}

function createCompositionLogger(options?: {
  enableConsole?: boolean;
}): CompositionLogger {
  const logs: Array<{
    timestamp: Date;
    module: string;
    type: 'composition' | 'method' | 'state' | 'performance';
    data: unknown;
  }> = [];

  const enableConsole = options?.enableConsole === true;

  const addLog = (
    module: string,
    type: 'composition' | 'method' | 'state' | 'performance',
    data: unknown
  ) => {
    logs.push({ timestamp: new Date(), module, type, data });
    if (logs.length > 1000) {
      logs.splice(0, logs.length - 1000);
    }
  };

  return {
    logMethodExecution: (
      module: string,
      method: string,
      args: unknown[],
      result: unknown
    ) => {
      addLog(module, 'method', { method, args, result });
      if ((typeof ngDevMode === 'undefined' || ngDevMode) && enableConsole) {
        console.debug(`🔧 [${module}] ${method}`, { args, result });
      }
    },

    logStateChange: (
      module: string,
      path: string,
      oldValue: unknown,
      newValue: unknown
    ) => {
      addLog(module, 'state', { path, oldValue, newValue });
      if ((typeof ngDevMode === 'undefined' || ngDevMode) && enableConsole) {
        console.debug(`📝 [${module}] State change at ${path}:`, {
          from: oldValue,
          to: newValue,
        });
      }
    },

    logPerformanceWarning: (
      module: string,
      operation: string,
      duration: number,
      threshold: number
    ) => {
      addLog(module, 'performance', { operation, duration, threshold });
      if ((typeof ngDevMode === 'undefined' || ngDevMode) && enableConsole) {
        console.warn(
          `⚠️ [${module}] Slow ${operation}: ${duration.toFixed(
            2
          )}ms (threshold: ${threshold}ms)`
        );
      }
    },

    exportLogs: () => [...logs],
  };
}

function createNoopLogger(): CompositionLogger {
  return {
    logMethodExecution: () => {
      /* noop */
    },
    logStateChange: () => {
      /* noop */
    },
    logPerformanceWarning: () => {
      /* noop */
    },
    exportLogs: () => [],
  };
}

function createModularMetrics(tree: object) {
  const metricsSignal = (
    getLocationRuntime(tree) ?? NEUTRAL_LOCATION_RUNTIME
  ).createCell<ModularPerformanceMetrics>({
    totalUpdates: 0,
    moduleUpdates: {},
    modulePerformance: {},
    signalGrowth: {},
    memoryDelta: {},
    moduleCacheStats: {},
  });

  return {
    signal: metricsSignal.asReadonly(),
    updateMetrics: (updates: Partial<ModularPerformanceMetrics>) => {
      deriveLocation(metricsSignal, (current) => ({ ...current, ...updates }));
    },
    trackModuleUpdate: (module: string, duration: number) => {
      deriveLocation(metricsSignal, (current) => ({
        ...current,
        totalUpdates: current.totalUpdates + 1,
        moduleUpdates: {
          ...current.moduleUpdates,
          [module]: (current.moduleUpdates[module] || 0) + 1,
        },
        modulePerformance: {
          ...current.modulePerformance,
          [module]: duration,
        },
      }));
    },
  };
}

function toArray(value?: string[] | string): string[] {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function matchesPattern(pattern: string, path: string): boolean {
  if (pattern === '**') return true;
  if (pattern === path) return true;

  if (pattern.endsWith('.*')) {
    const prefix = pattern.slice(0, -2);
    return path.startsWith(prefix + '.');
  }

  return false;
}

function defaultFormatPath(path: string): string {
  const segments = path.split('.');
  let formatted = '';
  for (const segment of segments) {
    if (!segment) continue;
    if (/^\d+$/.test(segment)) {
      formatted += `[${segment}]`;
    } else {
      formatted += formatted ? `.${segment}` : segment;
    }
  }
  return formatted || path;
}

function computeChangedPaths(
  prev: unknown,
  next: unknown,
  maxDepth: number,
  maxArrayLength: number,
  path = '',
  depth = 0,
  output: string[] = []
): string[] {
  if (prev === next) return output;

  if (depth >= maxDepth) {
    if (path) output.push(path);
    return output;
  }

  if (
    prev === null ||
    next === null ||
    prev === undefined ||
    next === undefined
  ) {
    if (path) output.push(path);
    return output;
  }

  const prevType = typeof prev;
  const nextType = typeof next;
  if (prevType !== 'object' || nextType !== 'object') {
    if (path) output.push(path);
    return output;
  }

  if (Array.isArray(prev) && Array.isArray(next)) {
    if (prev.length !== next.length) {
      if (path) output.push(path);
      return output;
    }
    if (prev.length > maxArrayLength) {
      if (path) output.push(path);
      return output;
    }
    for (let i = 0; i < prev.length; i += 1) {
      computeChangedPaths(
        prev[i],
        next[i],
        maxDepth,
        maxArrayLength,
        path ? `${path}.${i}` : `${i}`,
        depth + 1,
        output
      );
    }
    return output;
  }

  const prevObj = prev as Record<string, unknown>;
  const nextObj = next as Record<string, unknown>;
  const keys = new Set<string>([
    ...Object.keys(prevObj),
    ...Object.keys(nextObj),
  ]);
  if (keys.size === 0) {
    if (path) output.push(path);
    return output;
  }

  for (const key of keys) {
    computeChangedPaths(
      prevObj[key],
      nextObj[key],
      maxDepth,
      maxArrayLength,
      path ? `${path}.${key}` : key,
      depth + 1,
      output
    );
  }

  return output;
}

/**
 * Make truncation VISIBLE. Strings already do this (`…`); collections did not,
 * so a 200-entity collection rendered as exactly 50 rows with nothing to say so
 * — a debugger showing evidence that looks complete and is not.
 */
function withTruncationMarker(
  items: unknown[],
  totalLength: number,
  maxArrayLength: number
): unknown[] {
  if (totalLength <= maxArrayLength) return items;
  return [...items, `…${totalLength - maxArrayLength} more (truncated)`];
}

/** The `entityMap` snapshot signature: exactly one key, `all`, holding an array. */
function isEntitySnapshotShape(obj: Record<string, unknown>): boolean {
  const keys = Object.keys(obj);
  return keys.length === 1 && keys[0] === 'all' && Array.isArray(obj['all']);
}

/**
 * Build the id-keyed display view. The devtools layer does not know the
 * collection's `selectId`, so it probes the common identity fields and gives up
 * entirely if any entity lacks one — a partially-keyed view would be worse than
 * none, since a missing row would look like a missing entity.
 */
function buildKeyedEntityView(
  all: unknown[],
  options: {
    maxDepth: number;
    maxArrayLength: number;
    maxStringLength: number;
    entityKeyedView?: boolean;
  },
  depth: number,
  seen: WeakSet<object>
): Record<string, unknown> | undefined {
  if (all.length === 0) return undefined;
  const slice = all.slice(0, options.maxArrayLength);
  const keyed: Record<string, unknown> = {};
  for (const entity of slice) {
    if (entity === null || typeof entity !== 'object') return undefined;
    const record = entity as Record<string, unknown>;
    const rawKey = record['id'] ?? record['key'] ?? record['uuid'];
    if (typeof rawKey !== 'string' && typeof rawKey !== 'number') {
      return undefined;
    }
    keyed[String(rawKey)] = sanitizeState(entity, options, depth + 1, seen);
  }
  if (all.length > options.maxArrayLength) {
    keyed['…'] = `${all.length - options.maxArrayLength} more (truncated)`;
  }
  return keyed;
}

function sanitizeState(
  value: unknown,
  options: {
    maxDepth: number;
    maxArrayLength: number;
    maxStringLength: number;
    entityKeyedView?: boolean;
  },
  depth = 0,
  seen = new WeakSet<object>()
): unknown {
  const { maxDepth, maxArrayLength, maxStringLength, entityKeyedView } =
    options;

  if (value === null || value === undefined) return value;

  if (typeof value === 'string') {
    if (value.length > maxStringLength) {
      return `${value.slice(0, maxStringLength)}…`;
    }
    return value;
  }
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (typeof value === 'bigint') return `${value.toString()}n`;
  if (typeof value === 'symbol') return String(value);
  if (typeof value === 'function') return undefined;

  if (depth >= maxDepth) return '[MaxDepth]';

  if (value instanceof Date) return value.toISOString();
  if (value instanceof RegExp) return value.toString();
  if (value instanceof Error) {
    return { name: value.name, message: value.message, stack: value.stack };
  }

  if (typeof value === 'object') {
    const obj = value as Record<string, unknown>;
    if (seen.has(obj)) return '[Circular]';
    seen.add(obj);

    if (value instanceof Map) {
      const entries = Array.from(value.entries()).slice(0, maxArrayLength);
      const mapped: unknown[] = entries.map(([k, v]) => [
        sanitizeState(k, options, depth + 1, seen),
        sanitizeState(v, options, depth + 1, seen),
      ]);
      return withTruncationMarker(mapped, value.size, maxArrayLength);
    }

    if (value instanceof Set) {
      const values = Array.from(value.values()).slice(0, maxArrayLength);
      const mapped: unknown[] = values.map((v) =>
        sanitizeState(v, options, depth + 1, seen)
      );
      return withTruncationMarker(mapped, value.size, maxArrayLength);
    }

    if (Array.isArray(value)) {
      const list = value.slice(0, maxArrayLength);
      const mapped: unknown[] = list.map((item) =>
        sanitizeState(item, options, depth + 1, seen)
      );
      return withTruncationMarker(mapped, value.length, maxArrayLength);
    }

    const result: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(obj)) {
      if (typeof val === 'function') continue;
      result[key] = sanitizeState(val, options, depth + 1, seen);
    }

    // ENTITY KEYED VIEW (opt-in, display only).
    //
    // `entityMap`'s snapshot contract is exactly `{ all: [...] }` — see
    // `entity-map.ts`, which guarantees that shape and explains why the JS
    // `Map` form was withdrawn (it serialised as `{}`, claiming an empty
    // collection while holding 10,000 entities).
    //
    // Redux DevTools' Chart tab labels array children by INDEX, so a
    // collection renders as `all[0] … all[49]` with no entity identity
    // anywhere. Adding a keyed sibling gives Chart real ids to label with.
    //
    // `all` is left untouched deliberately: `hydrate` reads `value.all`, so
    // time-travel round-trips unchanged and the extra key is ignored on the
    // way back in. Reshaping `all` itself would silently break restore — the
    // partial-hydrate failure `entity-map.ts` warns about, where "the parts
    // that DID apply make it look like it worked".
    if (entityKeyedView && depth < maxDepth - 1 && isEntitySnapshotShape(obj)) {
      const keyed = buildKeyedEntityView(
        obj['all'] as unknown[],
        options,
        depth,
        seen
      );
      if (keyed) result['byId'] = keyed;
    }

    return result;
  }

  return value;
}

function parseDevToolsState(state: unknown): unknown {
  if (typeof state === 'string') {
    try {
      return JSON.parse(state);
    } catch {
      return undefined;
    }
  }
  return state;
}

function buildDevToolsAction(
  type: string,
  payload?: unknown,
  meta?: DevToolsActionMeta
): DevToolsAction {
  return {
    type,
    ...(payload !== undefined && { payload }),
    ...(meta && { meta: meta }),
  };
}

const GLOBAL_GROUPS_KEY = '__SIGNALTREE_DEVTOOLS_GROUPS__';
const GLOBAL_MARKER_KEY = '__SIGNALTREE_DEVTOOLS_GLOBAL_MARKER__';

function getRegistryHost(): DevToolsRegistryHost {
  return (
    typeof window !== 'undefined' ? window : globalThis
  ) as DevToolsRegistryHost;
}

function ensureGlobalMarker(): string {
  const host = getRegistryHost();
  if (!host[GLOBAL_MARKER_KEY]) {
    host[GLOBAL_MARKER_KEY] = `marker_${Math.random().toString(36).slice(2)}`;
  }
  return host[GLOBAL_MARKER_KEY];
}

interface DevToolsGroup {
  registerTree: (
    treeKey: string,
    tree: {
      readSnapshot: () => unknown;
      buildSerializedState: (state: unknown) => unknown;
      applyInspectionState: (state: unknown) => void;
      formatPathFn: (path: string) => string;
      isPathAllowed: (path: string) => boolean;
      enableTimeTravel: boolean;
      maxDepth: number;
      maxArrayLength: number;
      maxStringLength: number;
      sendRateLimitMs: number;
    }
  ) => () => void;
  enqueue: (
    treeKey: string,
    pendingPaths: string[],
    action?: DevToolsAction,
    meta?: DevToolsActionMeta
  ) => void;
  connect: () => void;
}

function getGlobalDevToolsGroups(): Map<string, DevToolsGroup> {
  const host = getRegistryHost();
  if (!host[GLOBAL_GROUPS_KEY]) {
    host[GLOBAL_GROUPS_KEY] = new Map();
  }
  return host[GLOBAL_GROUPS_KEY];
}

const devToolsGroups = getGlobalDevToolsGroups();

const GLOBAL_CONNECTIONS_KEY = '__SIGNALTREE_DEVTOOLS_CONNECTIONS__';

interface DevToolsConnectionEntry {
  status: 'connecting' | 'connected';
  connection: ReduxDevToolsConnection | null;
  tools: Pick<ReduxDevToolsConnection, 'send' | 'subscribe'> | null;
  subscribed: boolean;
  unsubscribe: (() => void) | null;
  waiters: Set<(entry: DevToolsConnectionEntry) => void>;
}

function getGlobalDevToolsConnections(): Map<string, DevToolsConnectionEntry> {
  const host = getRegistryHost();
  ensureGlobalMarker();
  if (!host[GLOBAL_CONNECTIONS_KEY]) {
    host[GLOBAL_CONNECTIONS_KEY] = new Map();
  }
  return host[GLOBAL_CONNECTIONS_KEY];
}

const devToolsConnections = getGlobalDevToolsConnections();

function getOrCreateDevToolsGroup(
  groupId: string,
  displayName: string
): DevToolsGroup {
  const existingGroup = devToolsGroups.get(groupId);
  if (existingGroup) {
    return existingGroup;
  }

  const trees = new Map<
    string,
    {
      readSnapshot: () => unknown;
      buildSerializedState: (state: unknown) => unknown;
      applyInspectionState: (state: unknown) => void;
      formatPathFn: (path: string) => string;
      isPathAllowed: (path: string) => boolean;
      enableTimeTravel: boolean;
      maxDepth: number;
      maxArrayLength: number;
      maxStringLength: number;
      sendRateLimitMs: number;
    }
  >();
  const lastSnapshots = new Map<string, unknown>();
  const lastSerialized = new Map<string, unknown>();
  const pendingPathsByTree = new Map<string, string[]>();

  let browserDevToolsConnection: ReduxDevToolsConnection | null = null;
  let browserDevTools: Pick<
    ReduxDevToolsConnection,
    'send' | 'subscribe'
  > | null = null;
  let unsubscribeDevTools: (() => void) | null = null;
  let isConnected = false;
  let isApplyingInspectionState = false;

  let sendScheduled = false;
  let sendTimer: ReturnType<typeof setTimeout> | null = null;
  let lastSendAt = 0;
  let sendRateLimitMs = 0;

  let pendingAction: DevToolsAction | null = null;
  let pendingExplicitAction = false;
  let pendingOrigin: string | undefined;
  let pendingDuration: number | undefined;

  const sendAggregated = (actionType: string, payload: unknown) => {
    if (!browserDevTools) return;
    const aggregated = buildAggregatedState();
    browserDevTools.send(buildDevToolsAction(actionType, payload), aggregated);
  };

  const sendEmptyState = () => {
    try {
      sendAggregated('SignalTree/empty', {
        groupId,
      });
    } catch {
      // ignore
    }
    pendingPathsByTree.clear();
    lastSnapshots.clear();
    lastSerialized.clear();
  };

  const updateRateLimit = () => {
    sendRateLimitMs = 0;
    for (const tree of trees.values()) {
      if (typeof tree.sendRateLimitMs === 'number') {
        sendRateLimitMs = Math.max(sendRateLimitMs, tree.sendRateLimitMs);
      }
    }
  };

  const buildAggregatedState = () => {
    const aggregated: Record<string, unknown> = {};
    for (const [treeKey, tree] of trees) {
      const snapshot = tree.readSnapshot();
      const lastSnapshot = lastSnapshots.get(treeKey);

      let serialized: unknown;
      if (lastSnapshot === snapshot && lastSerialized.has(treeKey)) {
        serialized = lastSerialized.get(treeKey);
      } else {
        lastSnapshots.set(treeKey, snapshot);
        serialized = tree.buildSerializedState(snapshot);
        lastSerialized.set(treeKey, serialized);
      }

      aggregated[treeKey] = serialized;
    }
    return aggregated;
  };

  const sendInit = () => {
    if (!browserDevTools) return;
    const aggregated = buildAggregatedState();
    browserDevTools.send('@@INIT', aggregated);
  };

  const applyInspectionState = (state: unknown) => {
    if (state === undefined || state === null) return;
    isApplyingInspectionState = true;
    try {
      const stateByTree = state as Record<string, unknown>;
      for (const [treeKey, tree] of trees) {
        if (!tree.enableTimeTravel) continue;
        const treeState = stateByTree[treeKey];
        if (treeState !== undefined) {
          tree.applyInspectionState(treeState);
        }
      }
    } finally {
      isApplyingInspectionState = false;
      for (const treeKey of trees.keys()) {
        lastSnapshots.delete(treeKey);
        pendingPathsByTree.delete(treeKey);
      }
    }
  };

  const handleDevToolsMessage = (message: unknown) => {
    if (!message || typeof message !== 'object') return;
    const msg = message as {
      type?: unknown;
      payload?: { type?: unknown; nextLiftedState?: unknown };
      state?: unknown;
    };

    const messageType = typeof msg.type === 'string' ? msg.type : undefined;

    // Redux DevTools sends { type: 'START' } when the panel is (re)opened.
    // Re-send current state so the instance becomes visible in the panel.
    if (messageType === 'START') {
      if (browserDevTools && trees.size > 0) {
        const elapsed = Date.now() - lastSendAt;
        if (elapsed < 500) return;
        const aggregated = buildAggregatedState();
        browserDevTools.send({ type: 'SignalTree/reconnect' }, aggregated);
        lastSendAt = Date.now();
      }
      return;
    }

    const anyDevtoolsTimelineEnabled = Array.from(trees.values()).some(
      (t) => t.enableTimeTravel
    );
    if (!anyDevtoolsTimelineEnabled) return;

    if (messageType !== 'DISPATCH') return;

    const actionType =
      msg.payload && typeof msg.payload.type === 'string'
        ? msg.payload.type
        : undefined;
    if (!actionType) return;

    if (actionType === 'JUMP_TO_STATE' || actionType === 'JUMP_TO_ACTION') {
      const nextState = parseDevToolsState(msg.state);
      applyInspectionState(nextState);
      return;
    }

    if (actionType === 'ROLLBACK') {
      const nextState = parseDevToolsState(msg.state);
      applyInspectionState(nextState);
      sendInit();
      return;
    }

    if (actionType === 'COMMIT') {
      sendInit();
      return;
    }

    if (actionType === 'IMPORT_STATE') {
      const lifted = msg.payload?.nextLiftedState as
        | LiftedStatePayload
        | undefined;
      const computedStates = Array.isArray(lifted?.computedStates)
        ? lifted.computedStates
        : [];
      const indexRaw =
        typeof lifted?.currentStateIndex === 'number'
          ? lifted.currentStateIndex
          : computedStates.length - 1;
      const index = Math.max(0, Math.min(indexRaw, computedStates.length - 1));
      const entry = computedStates[index];
      const nextState = parseDevToolsState(entry?.state);
      applyInspectionState(nextState);
      sendInit();
    }
  };

  const initBrowserDevTools = () => {
    if (isConnected) return;

    if (
      typeof window === 'undefined' ||
      !('__REDUX_DEVTOOLS_EXTENSION__' in window)
    ) {
      return;
    }

    const waiters = new Set<(entry: DevToolsConnectionEntry) => void>();
    devToolsConnections.set(groupId, {
      status: 'connecting',
      connection: null,
      tools: null,
      subscribed: false,
      unsubscribe: null,
      waiters,
    });

    try {
      const devToolsExt = getRegistryHost().__REDUX_DEVTOOLS_EXTENSION__;
      if (!devToolsExt) {
        devToolsConnections.delete(groupId);
        return;
      }
      const connection = devToolsExt.connect({
        name: displayName,
        instanceId: groupId,
        features: {
          dispatch: true,
          jump: true,
          skip: true,
        },
      });

      browserDevToolsConnection = connection;
      browserDevTools = {
        send: connection.send,
        subscribe: connection.subscribe,
      };

      if (browserDevTools.subscribe && !unsubscribeDevTools) {
        const maybeUnsubscribe = browserDevTools.subscribe(
          handleDevToolsMessage
        );
        if (typeof maybeUnsubscribe === 'function') {
          unsubscribeDevTools = maybeUnsubscribe;
        } else {
          unsubscribeDevTools = () => {
            browserDevTools?.subscribe?.(() => void 0);
          };
        }
      }

      const connEntry = devToolsConnections.get(groupId);
      if (connEntry) {
        connEntry.status = 'connected';
        connEntry.connection = browserDevToolsConnection;
        connEntry.tools = browserDevTools;
        connEntry.subscribed = !!browserDevTools?.subscribe;
        connEntry.unsubscribe = unsubscribeDevTools;
        for (const waiter of connEntry.waiters) {
          try {
            waiter(connEntry);
          } catch {
            // ignore
          }
        }
        connEntry.waiters.clear();
      }

      sendInit();
      isConnected = true;
    } catch (e: unknown) {
      devToolsConnections.delete(groupId);
      console.warn('[SignalTree] Failed to connect to Redux DevTools:', e);
    }
  };

  const flushSend = () => {
    sendScheduled = false;
    if (!browserDevTools || isApplyingInspectionState) return;

    const aggregatedState: Record<string, unknown> = {};
    const allFormattedPaths: string[] = [];

    for (const [treeKey, tree] of trees) {
      const currentSnapshot = tree.readSnapshot();
      lastSnapshots.set(treeKey, currentSnapshot);
      const serialized = tree.buildSerializedState(currentSnapshot);
      lastSerialized.set(treeKey, serialized);
      aggregatedState[treeKey] = serialized;

      // Aggregated mode is driven by PathNotifier flushes (and explicit meta
      // events like `tree.update`). Avoid deep diffing entire trees here.
      const pendingRaw = pendingPathsByTree.get(treeKey) ?? [];
      const allowedRaw = pendingRaw.filter((p) => p && tree.isPathAllowed(p));
      if (allowedRaw.length > 0) {
        const formatted = Array.from(new Set(allowedRaw)).map((path) =>
          tree.formatPathFn(`${treeKey}.${path}`)
        );
        appendAll(allFormattedPaths, formatted);
      }
    }

    const hasMeta =
      pendingOrigin !== undefined || pendingDuration !== undefined;
    if (allFormattedPaths.length === 0 && !pendingExplicitAction && !hasMeta) {
      pendingAction = null;
      pendingExplicitAction = false;
      pendingOrigin = undefined;
      pendingDuration = undefined;
      pendingPathsByTree.clear();
      lastSendAt = Date.now();
      return;
    }

    const effectiveAction =
      pendingExplicitAction && pendingAction
        ? pendingAction
        : allFormattedPaths.length === 1
        ? buildDevToolsAction(
            `SignalTree/${allFormattedPaths[0]}`,
            allFormattedPaths[0]
          )
        : allFormattedPaths.length > 1
        ? buildDevToolsAction('SignalTree/update', allFormattedPaths)
        : buildDevToolsAction('SignalTree/update');

    const actionMeta: DevToolsActionMeta = {
      timestamp: Date.now(),
      ...(pendingOrigin && { origin: pendingOrigin }),
      ...(pendingDuration !== undefined && {
        duration: pendingDuration,
        slow: pendingDuration > 16,
      }),
      ...(allFormattedPaths.length > 0 && { paths: allFormattedPaths }),
    };

    const actionToSend = buildDevToolsAction(
      effectiveAction?.type ?? 'SignalTree/update',
      effectiveAction?.payload,
      actionMeta
    );

    try {
      browserDevTools.send(actionToSend, aggregatedState);
    } catch {
      // ignore
    } finally {
      pendingAction = null;
      pendingExplicitAction = false;
      pendingOrigin = undefined;
      pendingDuration = undefined;
      pendingPathsByTree.clear();
      lastSendAt = Date.now();
    }
  };

  const scheduleSend = (action?: DevToolsAction, meta?: DevToolsActionMeta) => {
    if (isApplyingInspectionState) return;

    if (action !== undefined) {
      if (!pendingExplicitAction && pendingAction == null) {
        pendingAction = action;
        pendingExplicitAction = true;
      } else {
        // If an explicit action was already pending, we might have merged/clobbered.
        // For simplicity, we reset to avoid confusing action chains.
        pendingAction = null;
        pendingExplicitAction = false;
      }
    }

    if (meta?.origin) {
      if (!pendingOrigin) {
        pendingOrigin = meta.origin;
      } else if (pendingOrigin !== meta.origin) {
        pendingOrigin = 'mixed';
      }
    }

    if (meta?.duration !== undefined) {
      pendingDuration =
        pendingDuration === undefined
          ? meta.duration
          : Math.max(pendingDuration, meta.duration);
    }

    if (!browserDevTools) return;
    if (sendScheduled) return;

    sendScheduled = true;
    queueMicrotask(() => {
      if (!browserDevTools) {
        sendScheduled = false;
        return;
      }

      const now = Date.now();
      const waitMs = Math.max(0, sendRateLimitMs - (now - lastSendAt));

      if (waitMs > 0) {
        if (sendTimer) return;
        sendTimer = setTimeout(() => {
          sendTimer = null;
          flushSend();
        }, waitMs);
        return;
      }

      flushSend();
    });
  };

  const registerTree = (
    treeKey: string,
    tree: {
      readSnapshot: () => unknown;
      buildSerializedState: (state: unknown) => unknown;
      applyInspectionState: (state: unknown) => void;
      formatPathFn: (path: string) => string;
      isPathAllowed: (path: string) => boolean;
      enableTimeTravel: boolean;
      maxDepth: number;
      maxArrayLength: number;
      maxStringLength: number;
      sendRateLimitMs: number;
    }
  ) => {
    const wasConnected = isConnected;
    trees.set(treeKey, tree);
    updateRateLimit();
    initBrowserDevTools();

    if (browserDevTools) {
      const snapshot = tree.readSnapshot();
      lastSnapshots.set(treeKey, snapshot);
      lastSerialized.set(treeKey, tree.buildSerializedState(snapshot));
      if (trees.size === 1 && !wasConnected) {
        sendInit();
      } else {
        sendAggregated('SignalTree/register', { treeKey });
      }
    }

    return () => {
      trees.delete(treeKey);
      pendingPathsByTree.delete(treeKey);
      lastSnapshots.delete(treeKey);
      lastSerialized.delete(treeKey);
      updateRateLimit();

      if (trees.size === 0) {
        // Last tree removed: reset DevTools instance and clean up globals.
        sendEmptyState();
        try {
          unsubscribeDevTools?.();
        } catch {
          // ignore
        }
        try {
          browserDevToolsConnection?.unsubscribe?.();
        } catch {
          // ignore
        }
        try {
          browserDevToolsConnection?.disconnect?.();
        } catch {
          // ignore
        }

        unsubscribeDevTools = null;
        browserDevToolsConnection = null;
        browserDevTools = null;
        isConnected = false;

        devToolsConnections.delete(groupId);
        devToolsGroups.delete(groupId);
        return;
      }

      if (browserDevTools) {
        sendAggregated('SignalTree/unregister', { treeKey });
      }
    };
  };

  const enqueue = (
    treeKey: string,
    pendingPaths: string[],
    action?: DevToolsAction,
    meta?: DevToolsActionMeta
  ) => {
    if (pendingPaths && pendingPaths.length > 0) {
      const existing = pendingPathsByTree.get(treeKey) ?? [];
      pendingPathsByTree.set(treeKey, [...existing, ...pendingPaths]);
    }
    scheduleSend(action, meta);
  };

  const group: DevToolsGroup = {
    registerTree,
    enqueue,
    connect() {
      initBrowserDevTools();
    },
  };

  devToolsGroups.set(groupId, group);
  return group;
}

// ============================================================================
// Main Enhancer (v6 Pattern)
// ============================================================================

/**
 * Enhances a SignalTree with DevTools capabilities.
 *
 * @param config - DevTools configuration
 * @returns Polymorphic enhancer function
 */

export function createDevToolsEnhancer(
  config: DevToolsConfig = {}
): Enhancer<DevToolsMethods> {
  const {
    enabled = true,
    name = 'SignalTree',
    enableBrowserDevTools = true,
    enableTimeTravel = true,
    enableLogging = false,
    performanceThreshold = 16,
    includePaths,
    excludePaths,
    formatPath,
    rateLimitMs,
    maxSendsPerSecond,
    maxDepth = 10,
    maxArrayLength = 50,
    entityKeyedView = false,
    maxStringLength = 2000,
    serialize,
    aggregatedReduxInstance,
  } = config;

  const displayName = name;
  const groupId = aggregatedReduxInstance?.id ?? displayName;
  const pathInclude = toArray(includePaths);
  const pathExclude = toArray(excludePaths);
  const sendRateLimitMs =
    maxSendsPerSecond && maxSendsPerSecond > 0
      ? Math.ceil(1000 / maxSendsPerSecond)
      : rateLimitMs ?? 0;
  const formatPathFn = formatPath ?? defaultFormatPath;

  const enhancerFn = <T>(
    tree: ISignalTree<T>
  ): ISignalTree<T> & DevToolsMethods => {
    // ========================================================================
    // Disabled path
    // ========================================================================
    if (!enabled) {
      const noopMethods: DevToolsMethods = {
        connectDevTools(): void {
          /* disabled */
        },
        disconnectDevTools(): void {
          /* disabled */
        },
        // An EMPTY session, not a missing method. The disabled path used to
        // omit `exportDebugSession` entirely, so `devTools({ enabled: false })`
        // produced a tree where calling it threw — invisible while the method
        // was undeclared, because reaching it already required a cast.
        exportDebugSession() {
          return {
            metrics: {
              totalUpdates: 0,
              moduleUpdates: {},
              modulePerformance: {},
              signalGrowth: {},
              memoryDelta: {},
              moduleCacheStats: {},
            },
            modules: [],
            logs: [],
          };
        },
      };
      return Object.assign(tree, noopMethods) as unknown as ISignalTree<T> &
        DevToolsMethods;
    }

    // ========================================================================
    // Enabled path
    // ========================================================================
    const activityTracker = createActivityTracker({
      enableConsole: enableLogging,
    });
    const logger = enableLogging
      ? createCompositionLogger({ enableConsole: true })
      : createNoopLogger();
    const metrics = createModularMetrics(tree);
    const rootAuthority = rootAuthorityFor(tree);

    const activeProfiles = new Map<
      string,
      { module: string; operation: string; startTime: number }
    >();

    // Browser DevTools integration
    let browserDevToolsConnection: ReduxDevToolsConnection | null = null;
    let browserDevTools: Pick<
      ReduxDevToolsConnection,
      'send' | 'subscribe'
    > | null = null;
    let isConnected = false;
    let isApplyingInspectionState = false;
    let unsubscribeDevTools: (() => void) | null = null;

    // PathNotifier subscriptions (batched mutation streaming)
    let pendingPaths: string[] = [];

    // Effect + send scheduling for leaf-signal updates
    let sendScheduled = false;
    let pendingAction: DevToolsAction | null = null;
    let pendingExplicitAction = false;
    let pendingOrigin: string | undefined;
    let pendingDuration: number | undefined;
    let lastSnapshot: unknown = undefined;
    let lastSendAt = 0;
    let sendTimer: ReturnType<typeof setTimeout> | null = null;

    const isPathAllowed = (path: string): boolean => {
      if (pathInclude.length > 0) {
        const matched = pathInclude.some((pattern) =>
          matchesPattern(pattern, path)
        );
        if (!matched) return false;
      }
      if (pathExclude.length > 0) {
        const blocked = pathExclude.some((pattern) =>
          matchesPattern(pattern, path)
        );
        if (blocked) return false;
      }
      return true;
    };

    const readSnapshot = (): unknown => {
      return rootAuthority.read();
    };

    const buildSerializedState = (rawState: unknown): unknown => {
      if (serialize) {
        try {
          return serialize(rawState);
        } catch {
          // fall through to safe sanitization
        }
      }
      return sanitizeState(rawState, {
        maxDepth,
        maxArrayLength,
        maxStringLength,
        entityKeyedView,
      });
    };

    const buildAction = (
      type: string,
      payload?: unknown,
      meta?: Partial<DevToolsActionMeta>
    ): DevToolsAction => ({
      type,
      ...(payload !== undefined && { payload }),
      ...(meta && { meta: meta as DevToolsActionMeta }),
    });

    let lastSerializedJson: string | undefined;

    const flushSend = (): void => {
      sendScheduled = false;
      if (!browserDevTools || isApplyingInspectionState) return;

      const rawSnapshot = readSnapshot();
      const currentSnapshot = rawSnapshot ?? {};
      const sanitized = buildSerializedState(currentSnapshot);

      // Compare serialized JSON to detect actual state changes.
      // snapshotState()/unwrap() always creates new object references, so
      // reference-based comparisons (computeChangedPaths) produce false positives.
      // JSON comparison is stable and correctly detects no-change scenarios.
      let currentSerializedJson: string;
      try {
        currentSerializedJson = JSON.stringify(sanitized);
      } catch {
        currentSerializedJson = '';
      }

      const stateActuallyChanged =
        lastSerializedJson === undefined ||
        currentSerializedJson !== lastSerializedJson;

      const pendingAllowedPaths = pendingPaths.filter(
        (path) => path && isPathAllowed(path)
      );

      // Paths are hints for action naming, not triggers for sending.
      // If state didn't actually change, don't send an action—even if
      // PathNotifier reported paths (which can happen with cross-tree
      // notifications when multiple standalone trees share property names).
      if (!stateActuallyChanged && !pendingExplicitAction) {
        pendingAction = null;
        pendingExplicitAction = false;
        pendingOrigin = undefined;
        pendingDuration = undefined;
        pendingPaths = [];
        lastSnapshot = currentSnapshot;
        lastSerializedJson = currentSerializedJson;
        return;
      }

      // Compute changed paths for action naming (best-effort).
      // If PathNotifier already provided hints, avoid deep diffing the whole tree.
      const rawPathsForNaming =
        pendingAllowedPaths.length > 0
          ? Array.from(new Set(pendingAllowedPaths))
          : lastSnapshot === undefined
          ? []
          : computeChangedPaths(
              lastSnapshot,
              currentSnapshot,
              maxDepth,
              maxArrayLength
            ).filter((path) => path && isPathAllowed(path));

      const formattedPaths = rawPathsForNaming.map((path) =>
        formatPathFn(path)
      );

      if (
        pathInclude.length > 0 &&
        formattedPaths.length === 0 &&
        !pendingExplicitAction
      ) {
        pendingAction = null;
        pendingExplicitAction = false;
        pendingOrigin = undefined;
        pendingDuration = undefined;
        pendingPaths = [];
        lastSnapshot = currentSnapshot;
        return;
      }

      const effectiveAction = pendingExplicitAction
        ? pendingAction
        : formattedPaths.length === 1
        ? buildAction(`SignalTree/${formattedPaths[0]}`, formattedPaths[0])
        : formattedPaths.length > 1
        ? buildAction('SignalTree/update', formattedPaths)
        : buildAction('SignalTree/update');

      const actionMeta: DevToolsActionMeta = {
        timestamp: Date.now(),
        ...(pendingOrigin && { origin: pendingOrigin }),
        ...(pendingDuration !== undefined && {
          duration: pendingDuration,
          slow: pendingDuration > performanceThreshold,
        }),
        ...(formattedPaths.length > 0 && { paths: formattedPaths }),
      };

      const actionToSend = buildAction(
        effectiveAction?.type ?? 'SignalTree/update',
        effectiveAction?.payload,
        actionMeta
      );

      try {
        browserDevTools.send(actionToSend, sanitized);
      } catch {
        // Ignore send failures
      } finally {
        pendingAction = null;
        pendingExplicitAction = false;
        pendingOrigin = undefined;
        pendingDuration = undefined;
        pendingPaths = [];
        lastSnapshot = currentSnapshot;
        lastSerializedJson = currentSerializedJson;
        lastSendAt = Date.now();
      }
    };

    const scheduleSend = (
      action?: DevToolsAction,
      meta?: Partial<DevToolsActionMeta>
    ): void => {
      if (isApplyingInspectionState) return;
      if (action !== undefined) {
        pendingAction = action;
        pendingExplicitAction = true;
      }
      if (meta?.origin) {
        if (!pendingOrigin) {
          pendingOrigin = meta.origin;
        } else if (pendingOrigin !== meta.origin) {
          pendingOrigin = 'mixed';
        }
      }
      if (meta?.duration !== undefined) {
        pendingDuration =
          pendingDuration === undefined
            ? meta.duration
            : Math.max(pendingDuration, meta.duration);
      }

      if (!browserDevTools) return;
      if (sendScheduled) return;
      sendScheduled = true;

      queueMicrotask(() => {
        if (!browserDevTools) {
          sendScheduled = false;
          return;
        }

        const now = Date.now();
        const waitMs = Math.max(0, sendRateLimitMs - (now - lastSendAt));
        if (waitMs > 0) {
          if (sendTimer) return;
          sendTimer = setTimeout(() => {
            sendTimer = null;
            flushSend();
          }, waitMs);
          return;
        }

        flushSend();
      });
    };

    const sendInit = (): void => {
      if (!browserDevTools) return;
      const rawSnapshot = readSnapshot() ?? {};
      const serialized = buildSerializedState(rawSnapshot);
      browserDevTools.send('@@INIT', serialized);
      lastSnapshot = rawSnapshot;
      try {
        lastSerializedJson = JSON.stringify(serialized);
      } catch {
        lastSerializedJson = undefined;
      }
      lastSendAt = Date.now();

      // Clear pending state as it's now part of the init snapshot
      pendingPaths = [];
      pendingAction = null;
      pendingExplicitAction = false;
      pendingOrigin = undefined;
      pendingDuration = undefined;
    };

    const applyInspectionState = (state: unknown): void => {
      if (state === undefined || state === null) return;
      isApplyingInspectionState = true;
      try {
        // Tag every leaf write performed during this replay with
        // `origin: 'devtools'` — NOT `'restoration'`, which is what this used
        // to send and is what made devtools scrubbing indistinguishable from a
        // user pressing Ctrl+Z.
        //
        // The two are not the same act. An undo is the user changing their
        // mind, and its side effects are wanted: a `stored()` value should
        // write the old value back, because the user is undoing the persisted
        // change too. Scrubbing a devtools timeline is INSPECTION — nobody
        // expects dragging a slider to rewrite their localStorage.
        //
        // `'devtools'` was already in the `WriteMetadata['origin']` union and
        // simply unused. Enhancers read this via `getActiveWriteContext()`; the
        // context is synchronous, so applyState's recursive calls inherit it.
        // DEVTOOLS-JUMP-0 closed as D: this is INSPECTION participation, and it
        // is declared rather than inferred from `origin`. Provenance answers
        // "where did this come from"; participation answers "how may this take
        // part in causal mechanisms". Deriving the second from the first would
        // recouple two axes this audit separated on evidence.
        withWriteContext(
          { intent: 'system', origin: 'devtools', participation: 'inspection' },
          () => {
            if ('$' in tree) {
              // Imported inspection state is untyped input at this boundary.
              applyState<unknown>(tree.$, state);
            } else {
              rootAuthority.replace(state as T);
            }
          }
        );
      } finally {
        isApplyingInspectionState = false;
        lastSnapshot = readSnapshot();
        pendingPaths = [];
      }
    };

    const handleDevToolsMessage = (message: unknown): void => {
      if (!message || typeof message !== 'object') return;

      const msg = message as {
        type?: unknown;
        payload?: { type?: unknown; nextLiftedState?: unknown };
        state?: unknown;
      };

      const messageType = typeof msg.type === 'string' ? msg.type : undefined;

      // Redux DevTools sends { type: 'START' } when the panel is (re)opened.
      // Re-send current state so the instance becomes visible in the panel.
      if (messageType === 'START') {
        if (lastSnapshot === undefined) {
          // First time: send @@INIT to establish the instance
          sendInit();
        } else if (browserDevTools) {
          // Already initialized: re-send current state. Skip if we sent
          // recently (avoids spurious reconnect when another instance
          // connects/disconnects causing START to be broadcast).
          const elapsed = Date.now() - lastSendAt;
          if (elapsed < 500) return;

          const rawSnapshot = readSnapshot() ?? {};
          const serialized = buildSerializedState(rawSnapshot);
          browserDevTools.send({ type: 'SignalTree/reconnect' }, serialized);
          lastSnapshot = rawSnapshot;
          try {
            lastSerializedJson = JSON.stringify(serialized);
          } catch {
            lastSerializedJson = undefined;
          }
          lastSendAt = Date.now();
        }
        return;
      }

      if (!enableTimeTravel) return;

      if (messageType !== 'DISPATCH') return;

      const actionType =
        msg.payload && typeof msg.payload.type === 'string'
          ? msg.payload.type
          : undefined;
      if (!actionType) return;
      if (actionType === 'JUMP_TO_STATE' || actionType === 'JUMP_TO_ACTION') {
        const nextState = parseDevToolsState(msg.state);
        applyInspectionState(nextState);
        return;
      }

      if (actionType === 'ROLLBACK') {
        const nextState = parseDevToolsState(msg.state);
        applyInspectionState(nextState);
        sendInit();
        return;
      }

      if (actionType === 'COMMIT') {
        sendInit();
        return;
      }

      if (actionType === 'IMPORT_STATE') {
        const lifted = msg.payload?.nextLiftedState as
          | LiftedStatePayload
          | undefined;
        const computedStates = Array.isArray(lifted?.computedStates)
          ? lifted.computedStates
          : [];
        const indexRaw =
          typeof lifted?.currentStateIndex === 'number'
            ? lifted.currentStateIndex
            : computedStates.length - 1;
        const index = Math.max(
          0,
          Math.min(indexRaw, computedStates.length - 1)
        );
        const entry = computedStates[index];
        const nextState = parseDevToolsState(entry?.state);
        applyInspectionState(nextState);
        sendInit();
      }
    };

    // For aggregated mode: holds the unregister function returned by group.registerTree()
    let groupUnregister: (() => void) | null = null;

    const initBrowserDevTools = (): void => {
      if (aggregatedReduxInstance) {
        const group = getOrCreateDevToolsGroup(
          aggregatedReduxInstance.id,
          aggregatedReduxInstance.name ?? displayName
        );
        if (!groupUnregister) {
          groupUnregister = group.registerTree(displayName, {
            readSnapshot,
            buildSerializedState,
            applyInspectionState,
            formatPathFn,
            isPathAllowed,
            enableTimeTravel,
            maxDepth,
            maxArrayLength,
            maxStringLength,
            sendRateLimitMs,
          });
        }
        return;
      }

      if (isConnected) return;
      if (
        !enableBrowserDevTools ||
        typeof window === 'undefined' ||
        !('__REDUX_DEVTOOLS_EXTENSION__' in window)
      ) {
        return;
      }

      const waiters = new Set<(entry: DevToolsConnectionEntry) => void>();
      devToolsConnections.set(groupId, {
        status: 'connecting',
        connection: null,
        tools: null,
        subscribed: false,
        unsubscribe: null,
        waiters,
      });

      try {
        const devToolsExt = getRegistryHost().__REDUX_DEVTOOLS_EXTENSION__;
        if (!devToolsExt) {
          devToolsConnections.delete(groupId);
          return;
        }
        const connection = devToolsExt.connect({
          name: displayName,
          instanceId: groupId,
          features: { dispatch: true, jump: true, skip: true },
        });
        browserDevToolsConnection = connection;
        browserDevTools = {
          send: connection.send,
          subscribe: connection.subscribe,
        };
        if (browserDevTools.subscribe && !unsubscribeDevTools) {
          const maybeUnsubscribe = browserDevTools.subscribe(
            handleDevToolsMessage
          );
          if (typeof maybeUnsubscribe === 'function') {
            unsubscribeDevTools = maybeUnsubscribe;
          } else {
            unsubscribeDevTools = () => {
              // Some Redux DevTools implementations don't expose an unsubscribe;
              // overwrite handler by no-op as a best-effort fallback.
              browserDevTools?.subscribe?.(() => void 0);
            };
          }
        }

        const connEntry = devToolsConnections.get(groupId);
        if (connEntry) {
          connEntry.status = 'connected';
          connEntry.connection = browserDevToolsConnection;
          connEntry.tools = browserDevTools;
          connEntry.subscribed = !!browserDevTools?.subscribe;
          connEntry.unsubscribe = unsubscribeDevTools;
          for (const waiter of connEntry.waiters) {
            try {
              waiter(connEntry);
            } catch {
              // ignore
            }
          }
          connEntry.waiters.clear();
        }

        sendInit();
        isConnected = true;
        if ((typeof ngDevMode === 'undefined' || ngDevMode) && enableLogging) {
          console.log(`🔗 Connected to Redux DevTools as "${displayName}"`);
        }
      } catch (e) {
        devToolsConnections.delete(groupId);
        console.warn('[SignalTree] Failed to connect to Redux DevTools:', e);
      }
    };

    const enhancedTree = tree;

    // DevTools interface
    const devToolsInterface: ModularDevToolsInterface = {
      activityTracker,
      logger,
      metrics: metrics.signal,

      startModuleProfiling: (module: string) => {
        const profileId = `${module}_${Date.now()}`;
        activeProfiles.set(profileId, {
          module,
          operation: 'profile',
          startTime: performance.now(),
        });
        return profileId;
      },

      endModuleProfiling: (profileId: string) => {
        const profile = activeProfiles.get(profileId);
        if (profile) {
          const duration = performance.now() - profile.startTime;
          metrics.trackModuleUpdate(profile.module, duration);
          activeProfiles.delete(profileId);
        }
      },
      connectDevTools: () => {
        initBrowserDevTools();
      },
      exportDebugSession: () => {
        return {
          metrics: metrics.signal(),
          modules: activityTracker.getAllModules(),
          logs: logger.exportLogs(),
        };
      },
    };

    // PathNotifier is a global singleton, so we filter out events from other
    // trees based on top-level keys. This prevents cross-tree path leakage
    // when multiple standalone trees exist with overlapping property names.
    const treeTopKeys = new Set<string>();
    const refreshTreeTopKeys = (): void => {
      treeTopKeys.clear();
      try {
        if ('$' in tree) {
          for (const key of Object.keys(tree.$ as Record<string, unknown>)) {
            treeTopKeys.add(key);
          }
        }
      } catch {
        // ignore
      }
    };

    // Always populate keys so we can observe owned locations and filter
    // PathNotifier events by tree ownership.
    refreshTreeTopKeys();

    const isPathOwnedByTree = (path: string): boolean => {
      if (treeTopKeys.size === 0) return true;
      const root = path.split('.')[0];
      if (treeTopKeys.has(root)) return true;

      // If new keys were added after initialization, refresh once.
      refreshTreeTopKeys();
      return treeTopKeys.has(root);
    };

    // Observe intrinsic location mutations throughout the tree to emit
    // PathNotifier notifications. Entity collections already notify via their
    // own internals. We recurse through location nodes so nested writes like
    // `tree.$.user.profile.name(...)` are also captured.
    const notifier = getPathNotifier();
    const restoreInterceptors: Array<() => void> = [];

    try {
      if ('$' in tree) {
        const restore = interceptLeafSignals(
          tree.$ as Record<string, unknown>,
          (path, next, prev, _meta, ownerPath) => {
            notifier.notify(path, next, prev, ownerPath);
          }
        );
        restoreInterceptors.push(restore);
      }
    } catch {
      // Ignore errors during signal interception
    }

    // PathNotifier subscription: collect path hints for action naming.
    let unsubscribePathNotifier: (() => void) | null = null;
    let unsubscribePathFlush: (() => void) | null = null;

    unsubscribePathNotifier = notifier.subscribe(
      '**',
      (_value, _prev, path) => {
        if (isApplyingInspectionState) return;
        if (!isPathOwnedByTree(path)) return;
        if (!isPathAllowed(path)) return;
        pendingPaths.push(path);
      }
    );

    // PathNotifier flush handler. For aggregated mode this triggers group sends.
    // For standalone mode this is a fallback when Angular effect() is unavailable
    // (e.g. tree created outside injection context). When effect() IS available,
    // flushSend's no-change guard prevents duplicate sends.
    unsubscribePathFlush = notifier.onFlush(() => {
      if (isApplyingInspectionState) return;
      if (pendingPaths.length === 0) return;

      if (aggregatedReduxInstance) {
        const group = devToolsGroups.get(aggregatedReduxInstance.id);
        if (group) {
          group.enqueue(displayName, pendingPaths, undefined, {
            timestamp: Date.now(),
            origin: 'path-notifier',
          });
          pendingPaths = [];
        }
      } else {
        if (!browserDevTools) {
          pendingPaths = [];
          return;
        }
        scheduleSend(undefined, { origin: 'path-notifier' });
      }
    });

    // Capture direct location updates (e.g. $.count(1)) via the recursive
    // observer above (interceptLeafSignals). PathNotifier flush is then
    // the sole trigger that schedules sends to Redux DevTools (both standalone
    // and aggregated). Angular effect() was removed because:
    // 1. tree.$ may contain computed signals (entity collections) that produce
    //    new object references on every read, causing infinite effect re-runs.
    // 2. the legacy controller read does not reliably create signal dependencies when
    //    the tree is wrapped by enhancers like batching().
    // NOTE: The signalTree mutation pipeline (recursiveUpdate) writes to
    // locations directly and does NOT call PathNotifier.notify itself — only
    // entity collections do. The observer above is what makes direct writes
    // visible to this enhancer; do not remove it without a replacement.

    // Always return the enhanced tree with DevTools methods (only those required by DevToolsMethods)
    const result = Object.assign(enhancedTree, {
      __devTools: devToolsInterface,
      connectDevTools: devToolsInterface.connectDevTools,
      exportDebugSession: devToolsInterface.exportDebugSession,
      disconnectDevTools: () => {
        // Unsubscribe from PathNotifier
        if (unsubscribePathNotifier) {
          unsubscribePathNotifier();
          unsubscribePathNotifier = null;
        }
        if (unsubscribePathFlush) {
          unsubscribePathFlush();
          unsubscribePathFlush = null;
        }

        // Restore any intercepted signal methods
        for (const restore of restoreInterceptors) {
          try {
            restore();
          } catch {
            // ignore
          }
        }

        if (aggregatedReduxInstance) {
          // Unregister from the shared group
          if (groupUnregister) {
            groupUnregister();
            groupUnregister = null;
          }
        } else {
          // Standalone: reset devtools to empty state, clearing action history.
          // connection.init() sends an INIT message which resets the lifted state
          // to a single @@INIT action with the provided (empty) state.
          if (browserDevToolsConnection) {
            try {
              browserDevToolsConnection.init?.({});
            } catch {
              // ignore
            }
          }
          try {
            unsubscribeDevTools?.();
          } catch {
            /* ignore */
          }
          try {
            browserDevToolsConnection?.unsubscribe?.();
          } catch {
            /* ignore */
          }
          try {
            browserDevToolsConnection?.disconnect?.();
          } catch {
            /* ignore */
          }
          browserDevToolsConnection = null;
          browserDevTools = null;
          isConnected = false;
          unsubscribeDevTools = null;
          devToolsConnections.delete(groupId);
        }

        // Reset pending state
        if (sendTimer) {
          clearTimeout(sendTimer);
          sendTimer = null;
        }
        pendingPaths = [];
        sendScheduled = false;
        pendingAction = null;
        pendingExplicitAction = false;
        pendingOrigin = undefined;
        pendingDuration = undefined;
        lastSnapshot = undefined;
        lastSerializedJson = undefined;
      },
    }) as ISignalTree<T> & DevToolsMethods;

    // Auto-connect to DevTools on creation
    if (enableBrowserDevTools) {
      initBrowserDevTools();
    }

    // Register cleanup so destroy() disconnects DevTools automatically
    if (typeof tree.registerCleanup === 'function') {
      tree.registerCleanup(() => {
        result.disconnectDevTools();
      });
    }

    return result;
  };

  const meta: EnhancerMeta = { name: 'devTools', provides: ['devTools'] };
  (enhancerFn as unknown as { metadata: EnhancerMeta }).metadata = meta;
  (enhancerFn as unknown as Record<symbol, EnhancerMeta>)[ENHANCER_META] = meta;

  // THE ONE BOUNDARY CAST for the identity-REPLACING half of the dispatch.
  // Re-justified rather than copied: `enhancerFn` reads the realized tree, so
  // its parameter is `ISignalTree<T>`, while `Enhancer<TAdded>` takes the
  // neutral `EnhancerHost` and parameters are contravariant under
  // `strictFunctionTypes`. Body untouched.
  return enhancerFn as unknown as Enhancer<DevToolsMethods>;
}
