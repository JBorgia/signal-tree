/**
 * TYPE-TEST — compile-time only (`*typing*.spec.ts` is excluded from vitest).
 *
 * THE CONSUMER CONTRACT for `transactions()`, pinned so the
 * `Enhancer<TransactionMethods>` migration can be proven not to change it.
 * Proven GREEN BEFORE the signature change, re-run unchanged after.
 *
 * SIXTH SHAPE, characterized rather than assumed:
 *
 *   - it MUTATES and returns the SAME tree (`return tree as …`), assigning
 *     `transaction` onto it directly;
 *   - it stores per-tree state on a SIDE CHANNEL — a module-level
 *     `Symbol(INTERNAL_TRANSACTION_RUNTIME)` keyed off the tree —
 *     which is the reason a generic `tree + additions` combiner cannot express
 *     this enhancer, and is untouched by a signature change;
 *   - its metadata declares `capabilities: ['causal-runtime']`, so like
 *     `restoration` it participates in `buildTreePlan` substrate provisioning;
 *   - `TransactionMethods` is a single method with no `this`, no conditional
 *     types and no state generic, so there is no receiver-derived precision at
 *     risk.
 *
 * `TransactionMethods` is also INHERITED by `RestorationMethods`, so this
 * contract is reachable two ways. The rows here cover the direct application;
 * `restoration-contract.typing.spec.ts` covers the inherited path.
 *
 * v15: enhancers are DECLARED, so the call site is
 * `signalTree(state, { enhancers: [transactions()] })` and the added surface arrives
 * through the return type. Note the state is a separate annotated `const`
 * rather than `signalTree<AppState>(...)` — an explicit type argument would
 * have to name the enhancer tuple parameter too, and naming it is exactly the
 * ceremony this file exists to forbid.
 */
import { signalTree } from '../../lib/signal-tree';
import { transactions } from './transactions';

import type { WritableLeaf, Enhancer, PendingTransaction } from '../../index';

// --- compile-time assertion helpers -----------------------------------------
type Equal<A, B> = (<T>() => T extends A ? 1 : 2) extends <T>() => T extends B
  ? 1
  : 2
  ? true
  : false;
type Expect<T extends true> = T;
type ExpectFalse<T extends false> = T;

interface AppState {
  count: number;
  user: { name: string; age: number };
}

const initial: AppState = { count: 0, user: { name: 'Ada', age: 36 } };
const tree = signalTree(initial);
const txn = signalTree(initial, { enhancers: [transactions()] });

// ============================================================================
// 1 — the method is inferred, with its exact signature
// ============================================================================
export type _MethodType = Expect<
  Equal<(typeof txn)['transact'], (fn: () => void) => PendingTransaction>
>;
export const _pending: PendingTransaction = txn.transact(() => undefined);

// ============================================================================
// 2 — the state surface is untouched by enhancement
// ============================================================================
export type _StateSurvives = [
  Expect<Equal<(typeof txn)['$']['count'], WritableLeaf<number>>>,
  Expect<Equal<(typeof txn)['$']['user']['name'], WritableLeaf<string>>>
];
export const _count: number = txn.$.count();
export const _user: { name: string; age: number } = txn.$.user();
txn.$.user({ name: 'Ada', age: 37 });
export const _snapshot: AppState = txn.$();
txn.$({ count: 1, user: { name: 'Ada', age: 37 } });

// ============================================================================
// 3 — accumulation in BOTH orders
// ============================================================================
declare const labeller: Enhancer<{ label(): string }>;

const txnThenLabelled = signalTree(initial, {
  enhancers: [transactions(), labeller],
});
const labelledThenTxn = signalTree(initial, {
  enhancers: [labeller, transactions()],
});

export const _f1: string = txnThenLabelled.label();
export const _f2: PendingTransaction = txnThenLabelled.transact(
  () => undefined
);
export const _f3: string = labelledThenTxn.label();
export const _f4: PendingTransaction = labelledThenTxn.transact(
  () => undefined
);
export const _f5: number = txnThenLabelled.$.count();

// ============================================================================
// 4 — config surface (L15 retention)
// ============================================================================
// `transactions()` previously took no arguments; it now takes an optional
// TransactionsConfig. The old @ts-expect-error here asserted "takes no
// arguments" and went stale rather than failing, so it is replaced with cases
// that pin the CURRENT contract in both directions.
// Directives are kept on the SAME line the error lands on: a multi-line call
// puts the diagnostic on the inner line and the directive above the statement
// then suppresses nothing, which is how the stale one above survived.
signalTree(initial, { enhancers: [transactions()] });
signalTree(initial, { enhancers: [transactions({ history: { retain: 10 } })] });
// `retain` is required once `history` is given.
// @ts-expect-error missing required property `retain`
transactions({ history: {} });
// `retain` is a number, not a string.
// @ts-expect-error wrong type for `retain`
transactions({ history: { retain: 'lots' } });
// An unknown option is rejected rather than silently ignored.
// @ts-expect-error unknown option
transactions({ nope: true });

// ============================================================================
// 5 — negative controls
// ============================================================================
// @ts-expect-error `transaction` requires transactions()
export type _NoTransactionBefore = (typeof tree)['transact'];
export type _EnhancedDiffers = ExpectFalse<Equal<typeof txn, typeof tree>>;
