import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions,link} from './ARM/kernel/src/index';
import {withWriteContext} from './ARM/kernel/src/lib/write-context';
import {getPathNotifier} from './ARM/kernel/src/lib/path-notifier';
import {getEntityOrdinaryChanges} from './ARM/kernel/src/lib/internals/entity-value-transition';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});const r=t.$.rows;const sends:any[][]=[[],[]];let cs:any[]=[];
const off=getPathNotifier().subscribe('**',(v,p,path,op,o,s,ps,m)=>console.log('META',JSON.stringify({path,P:m?.structuralEffect,O:getEntityOrdinaryChanges(m),participation:m?.participation})));
try{
r.addOne({id:'a',n:1});await tick();cs.push(link(r,{set:v=>sends[0].push(structuredClone(v))}));
withWriteContext({participation:'inspection'},()=>r.addOne({id:'x',n:9}));await tick();cs.push(link(r,{set:v=>sends[1].push(structuredClone(v))}));
r.removeOne('x');await tick();await Promise.all(cs.map(c=>c.settled()));
console.log('REMOVE',JSON.stringify(sends));assert.deepEqual(sends[1].at(-1)?.map((x:any)=>x.id),['a']);
withWriteContext({participation:'inspection'},()=>{r.addOne({id:'x',n:9});r.setAll([{id:'x',n:9},{id:'a',n:1}]);});await tick();r.updateOne('x',{n:10});await tick();await Promise.all(cs.map(c=>c.settled()));
console.log('ADOPT',JSON.stringify(sends));assert.deepEqual(sends[0].at(-1)?.map((x:any)=>x.id),['x','a']);assert.equal(sends[0].at(-1)?.[0].n,10);
}finally{for(const c of cs)c.dispose();off();t.destroy();}
