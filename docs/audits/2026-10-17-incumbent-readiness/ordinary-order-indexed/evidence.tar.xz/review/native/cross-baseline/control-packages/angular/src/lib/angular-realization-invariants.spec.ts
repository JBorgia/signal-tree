import {
  Component,
  computed,
  isSignal,
  provideZonelessChangeDetection,
  untracked,
  type WritableSignal,
} from '@angular/core';
import { TestBed } from '@angular/core/testing';

import { entityMap, signalTree, transactions } from '../index';

const causal = () =>
  signalTree({ a: 1, b: 2 }, { capabilities: ['causal-runtime'] });
const native = <T>(value: unknown): WritableSignal<T> =>
  value as WritableSignal<T>;

describe('Angular realization invariants', () => {
  it('uses stable native Angular carriers for ordinary leaves', () => {
    TestBed.configureTestingModule({});
    const tree = signalTree({ a: 1, nested: { b: 2 } });

    expect(isSignal(tree.$.a)).toBe(true);
    expect('set' in tree.$.a).toBe(true);
    expect(tree.$.a()).toBe(1);
    expect(tree.$.a).toBe(tree.$.a);
    expect(tree.$.nested).toBe(tree.$.nested);
    expect(tree.$.nested.b).toBe(tree.$.nested.b);
    tree.destroy();
  });

  it('participates directly in Angular dependency tracking', () => {
    TestBed.configureTestingModule({});
    const tree = signalTree({ a: 1 });
    let runs = 0;
    const doubled = computed(() => {
      runs++;
      return tree.$.a() * 2;
    });

    expect(doubled()).toBe(2);
    const before = runs;
    native<number>(tree.$.a).set(5);
    expect(doubled()).toBe(10);
    expect(runs).toBeGreaterThan(before);
    tree.destroy();
  });

  it('keeps one ordinary cell across merge writes', () => {
    TestBed.configureTestingModule({});
    const tree = signalTree({ a: 1 });
    const leaf = tree.$.a;

    tree.$({ a: 7 });

    expect(tree.$.a).toBe(leaf);
    expect(untracked(() => leaf())).toBe(7);
    tree.destroy();
  });

  it('uses one stable native carrier per causal scalar leaf', () => {
    TestBed.configureTestingModule({});
    const tree = causal();
    const leaf = tree.$.a;

    expect(isSignal(leaf)).toBe(true);
    expect('set' in leaf).toBe(true);
    expect(tree.$.a).toBe(leaf);
    expect(tree.$.a).not.toBe(tree.$.b);
    untracked(() => tree.$.a());
    untracked(() => tree.$.a());
    expect(tree.$.a).toBe(leaf);
    tree.destroy();
  });

  it('schedules a zoneless template after a direct location write', async () => {
    @Component({
      standalone: true,
      template: `{{ tree.$.count() }}`,
    })
    class HostComponent {
      readonly tree = signalTree(
        { count: 0 },
        { capabilities: ['causal-runtime'] }
      );
    }

    TestBed.configureTestingModule({
      imports: [HostComponent],
      providers: [provideZonelessChangeDetection()],
    });
    const fixture = TestBed.createComponent(HostComponent);
    await fixture.whenStable();
    expect(fixture.nativeElement.textContent.trim()).toBe('0');

    native<number>(fixture.componentInstance.tree.$.count).set(1);
    await fixture.whenStable();

    expect(fixture.nativeElement.textContent.trim()).toBe('1');
    fixture.destroy();
  });

  it('connects causal scalar leaves directly to Angular computations', () => {
    TestBed.configureTestingModule({});
    const tree = causal();
    let runs = 0;
    const doubled = computed(() => {
      runs++;
      return tree.$.a() * 2;
    });

    expect(untracked(() => doubled())).toBe(2);
    const before = runs;
    native<number>(tree.$.a).set(5);
    expect(untracked(() => doubled())).toBe(10);
    expect(runs).toBeGreaterThan(before);
    tree.destroy();
  });

  it('keeps the causal cell stable across merge writes', () => {
    TestBed.configureTestingModule({});
    const tree = causal();
    const leaf = tree.$.a;

    tree.$({ a: 9, b: 2 });

    expect(untracked(() => leaf())).toBe(9);
    expect(tree.$.a).toBe(leaf);
    tree.destroy();
  });

  it('keeps branches as SignalTree accessors rather than Angular signals', () => {
    const tree = signalTree({ count: 0, user: { name: 'x' } });

    expect(isSignal(tree.$.count)).toBe(true);
    expect(isSignal(tree.$.user)).toBe(false);
    tree.destroy();
  });

  it('keeps EntityMap as a collection API rather than an Angular signal', () => {
    const tree = signalTree({
      rows: entityMap<{ id: string; value: number }, string>({
        selectId: (row) => row.id,
      }),
      plain: 1,
    });

    expect(isSignal(tree.$.plain)).toBe(true);
    expect(isSignal(tree.$.rows as never)).toBe(false);
    expect(typeof tree.$.rows).toBe('object');
    tree.destroy();
  });

  /**
   * Covers the adapter's `token.invalidate` publication path specifically.
   *
   * A scalar write publishes the committed value straight through `commit`.
   * Once that arrived, every test in this spec went through `commit` and none
   * touched `invalidate` -- which made the c6-neutrality gate BLIND: replacing
   * `invalidate` with a no-op no longer failed the suite the gate runs, even
   * though 35 tests elsewhere in the package caught it.
   *
   * A rollback republishes a prior value through the location publisher, which
   * notifies via `token.invalidate()`. Verified in both directions: this fails
   * under that mutation and passes without it.
   */
  it('republishes a rolled-back value through Angular dependency tracking', () => {
    TestBed.configureTestingModule({
      providers: [provideZonelessChangeDetection()],
    });
    const tree = signalTree({ count: 0 }, { enhancers: [transactions()] });
    const observed = computed(() => tree.$.count());

    const pending = tree.transact(() => tree.$.count.set(9));
    expect(observed()).toBe(9);

    pending.rollback();
    expect(observed()).toBe(0);

    tree.destroy();
  });
});
