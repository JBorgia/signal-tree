import { describe, expect, it, vi, beforeEach, afterEach } from 'vitest';

import { batching } from './batching';
import { signalTree } from '../../lib/signal-tree';
import type { Location } from '../../lib/internals/cell-runtime';
import { interceptLocationWrites } from '../../lib/internals/location-runtime';

function createFakeTree(initial: any) {
  return signalTree(initial) as any;
}

describe('batching behavior', () => {
  /**
   * IMPORTANT: This test documents the NEW synchronous batching behavior.
   *
   * In v6.1.0+, signal writes are SYNCHRONOUS:
   * - Values update immediately when .set() is called
   * - Only CD notifications are batched
   *
   * (v12 removed the legacy global getBatchQueueSize/hasPendingUpdates/
   * flushBatchedUpdates helpers — pending state is observed via the tree's
   * hasPendingNotifications()/flushNotifications() methods.)
   */
  it('applies updates synchronously (v6.1.0+ behavior)', () => {
    const tree = createFakeTree({ count: 0 });
    const enhanced = batching()(tree as any) as any;

    // Update is applied immediately (synchronous!)
    enhanced.$({ count: 1 });

    // Value is already updated - no queue
    expect(enhanced.$().count).toBe(1);
  });

  it('tracks pending CD notifications via tree methods', () => {
    const tree = createFakeTree({ count: 0 });
    const enhanced = batching({ notificationDelayMs: 100 })(tree as any) as any;

    expect(enhanced.hasPendingNotifications()).toBe(false);

    // Update via $.count.set() which wraps the setter
    enhanced.$.count(5);

    // Value is updated immediately
    expect(enhanced.$().count).toBe(5);

    // But CD notification is pending
    expect(enhanced.hasPendingNotifications()).toBe(true);

    // Flush notifications
    enhanced.flushNotifications();
    expect(enhanced.hasPendingNotifications()).toBe(false);
  });

  describe('batch() groups CD notifications', () => {
    beforeEach(() => vi.useFakeTimers());
    afterEach(() => vi.useRealTimers());

    it('batches multiple updates into single CD notification', () => {
      const tree = createFakeTree({ count: 0 });
      let notificationCount = 0;

      (tree as any).__notifyChangeDetection = () => {
        notificationCount++;
      };

      const enhanced = batching({ notificationDelayMs: 100 })(
        tree as any
      ) as any;

      enhanced.batch(() => {
        enhanced.$.count(1);
        enhanced.$.count(2);
        enhanced.$.count(3);
      });

      // Values update immediately inside batch
      expect(enhanced.$().count).toBe(3);

      // But only one notification scheduled
      vi.advanceTimersByTime(100);
      expect(notificationCount).toBe(1);
    });
  });

  describe('setter wrapping reaches callable accessors', () => {
    // Regression: NodeAccessors are typeof 'function', and wrapSignalSetters
    // used to skip non-objects entirely — so no leaf setter was ever wrapped
    // and coalesce() never deduped. Count actual writes by wrapping the raw
    // setter BEFORE the enhancer, then assert coalesce applies only the last.
    //
    // "Before the enhancer" is a probe enhancer declared ahead of `batching`,
    // since v15 builds the tree and its enhancers in one call — there is no
    // moment between them for the test to reach in.
    const rejectCounterWrites = (failure: Error) =>
      <TTree>(tree: TTree): TTree => {
        const counter = (tree as unknown as { $: { counter: unknown } }).$
          .counter as Location<number>;
        const release = interceptLocationWrites(counter, () => {
          throw failure;
        });
        (tree as unknown as { registerCleanup(fn: () => void): void }).registerCleanup(
          release
        );
        return tree;
      };

    it('coalesce() dedupes same-path writes down to one applied write', () => {
      let applied = 0;
      const countRawWrites = <TTree>(t: TTree): TTree => {
        const counter = (t as unknown as { $: { counter: unknown } }).$
          .counter as Location<number>;
        const release = interceptLocationWrites(counter, (_operation, proceed) => {
          applied++;
          proceed();
        });
        (t as unknown as { registerCleanup(fn: () => void): void }).registerCleanup(release);
        return t;
      };

      const tree = signalTree(
        { counter: 0 },
        {
          enhancers: [
            countRawWrites,
            batching({ enabled: true, notificationDelayMs: 0 }),
          ],
        }
      );
      tree.coalesce(() => {
        for (let i = 0; i < 100; i++) tree.$.counter(i + 1);
      });

      expect(tree.$.counter()).toBe(100);
      expect(applied).toBe(1);
    });

    it('coalesce() propagates a deferred replacement failure', () => {
      const failure = new Error('coalesced write failed');
      const tree = signalTree(
        { counter: 0 },
        { enhancers: [rejectCounterWrites(failure), batching()] }
      );

      expect(() => tree.coalesce(() => tree.$.counter(1))).toThrow(failure);
      expect(tree.$.counter()).toBe(0);
    });

    it('preserves the callback failure when its deferred replacement also fails', () => {
      const callbackFailure = new Error('callback failed');
      const writeFailure = new Error('coalesced write failed');
      const tree = signalTree(
        { counter: 0 },
        { enhancers: [rejectCounterWrites(writeFailure), batching()] }
      );

      expect(() =>
        tree.coalesce(() => {
          tree.$.counter(1);
          throw callbackFailure;
        })
      ).toThrow(callbackFailure);
      expect(tree.$.counter()).toBe(0);
    });

    it('wraps nested leaf setters too', () => {
      let applied = 0;
      const countRawWrites = <TTree>(t: TTree): TTree => {
        const leaf = (t as unknown as { $: { a: { b: { value: unknown } } } })
          .$.a.b
          .value as Location<number>;
        const release = interceptLocationWrites(leaf, (_operation, proceed) => {
          applied++;
          proceed();
        });
        (t as unknown as { registerCleanup(fn: () => void): void }).registerCleanup(release);
        return t;
      };

      const tree = signalTree(
        { a: { b: { value: 0 } } },
        {
          enhancers: [
            countRawWrites,
            batching({ enabled: true, notificationDelayMs: 0 }),
          ],
        }
      );
      tree.coalesce(() => {
        tree.$.a.b.value(1);
        tree.$.a.b.value(2);
        tree.$.a.b.value(3);
      });

      expect(tree.$.a.b.value()).toBe(3);
      expect(applied).toBe(1);
    });
  });
});
