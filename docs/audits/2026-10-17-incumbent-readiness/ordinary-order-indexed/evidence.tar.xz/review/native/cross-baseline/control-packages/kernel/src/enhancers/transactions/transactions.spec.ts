import { describe, expect, it, vi } from 'vitest';

import { getTreeRealizationPort } from '../../lib/internals/causal-runtime/tree-realization-adapter';
import { getOwnedPositionIds } from '../../lib/internals/owned-mutation';
import { entityMap } from '../../lib/markers/entity-map';
import { signalTree } from '../../lib/signal-tree';
import { SignalTreeRollbackError } from '../../lib/types';
import { transactions } from './transactions';

describe('transactions enhancer', () => {
  const expectRollbackError = (
    attempt: () => void,
    expectedCause: Record<string, unknown>
  ): void => {
    try {
      attempt();
      throw new Error('Expected rollback to throw');
    } catch (error) {
      expect(error).toBeInstanceOf(SignalTreeRollbackError);
      const rollbackError = error as SignalTreeRollbackError;
      expect(rollbackError.code).toBe('SIGNALTREE_ROLLBACK_FAILED');
      expect(rollbackError.cause).toMatchObject(expectedCause);
    }
  };

  it('adds transaction semantics without exposing temporal history methods', () => {
    const store = signalTree(
      { count: 0 },
      { enhancers: [transactions()] }
    ) as Record<string, unknown>;

    expect(typeof store.transact).toBe('function');
    expect(store.undo).toBeUndefined();
    expect(store.redo).toBeUndefined();
    expect(store.canUndo).toBeUndefined();
    expect(store.canRedo).toBeUndefined();
    expect(store.getRestorationHistory).toBeUndefined();
    expect(store.jumpTo).toBeUndefined();
    expect(store.getCurrentIndex).toBeUndefined();
    expect(store.__restoration).toBeUndefined();
  });

  it('keeps pending transactions out of confirmed causal turns until confirm', async () => {
    const { resetPathNotifier } = await import('../../lib/path-notifier');
    resetPathNotifier();

    // Declares diagnostic history because it COUNTS confirmed turns. Under the
    // L15 default those records are released once nothing pending can need
    // them, so counting them is a diagnostic question, not a correctness one.
    const store = signalTree(
      { count: 0 },
      { enhancers: [transactions({ history: { retain: 1000 } })] }
    ) as unknown as {
      $: { (): { count: number }; count: () => number };
      transact: (fn: () => void) => { confirm(): void; rollback(): void };
      __transactions: {
        getConfirmedTurnCount(): number;
        getPendingTurnCount(): number;
      };
    };

    const pending = store.transact(() => {
      store.$.count(1);
    });

    expect(store.$.count()).toBe(1);
    expect(store.__transactions.getConfirmedTurnCount()).toBe(0);
    expect(store.__transactions.getPendingTurnCount()).toBe(1);

    pending.confirm();

    expect(store.__transactions.getConfirmedTurnCount()).toBe(1);
    expect(store.__transactions.getPendingTurnCount()).toBe(0);
  });

  it('publishes a transaction callback as one coherent location state', () => {
    const store = signalTree(
      { left: 0, right: 0 },
      { enhancers: [transactions()] }
    );
    const seen: Array<readonly [number, number]> = [];
    const unsubscribe = store.$.left.subscribe(() => {
      seen.push([store.$.left(), store.$.right()]);
    });

    store.transact(() => {
      store.$.left(1);
      store.$.right(1);
    });

    expect(seen).toEqual([[1, 1]]);
    unsubscribe();
  });

  it('rolls back a pending optimistic transaction without reverting later confirmed work', async () => {
    const { resetPathNotifier } = await import('../../lib/path-notifier');
    resetPathNotifier();

    const store = signalTree(
      { inside: '', outside: '' },
      { enhancers: [transactions()] }
    );

    const pending = store.transact(() => {
      store.$.inside('grouped');
    });

    store.$.outside('later');

    await Promise.resolve();
    await Promise.resolve();

    pending.rollback();

    expect(store.$()).toEqual({ inside: '', outside: 'later' });
  });

  // WITHDRAWN WITH STATUS-DEL — "rolls back pending status source-signal writes
  // without status-specific logic". The frozen property is that rollback works
  // without feature-specific logic, and it retains five independent specimens
  // here, including the `stored()` case immediately below which existed on its
  // own merits. Marker PARTICIPATION in the causal path is UNPROVEN, so the
  // specimen is withdrawn rather than migrated.

  it('aborts a thrown transaction callback by undoing only transaction writes', async () => {
    const { getPathNotifier, resetPathNotifier } = await import(
      '../../lib/path-notifier'
    );
    resetPathNotifier();
    getPathNotifier().setBatchingEnabled(false);

    const store = signalTree(
      { left: '', right: '', outside: 'stable' },
      { enhancers: [transactions()] }
    );
    expect(getOwnedPositionIds(store.$)?.length).toBeGreaterThan(0);
    expect(getTreeRealizationPort(store.$)?.validateEffects).toBeTypeOf(
      'function'
    );

    expect(() =>
      store.transact(() => {
        store.$.left('L');
        store.$.right('R');
        throw new Error('boom');
      })
    ).toThrow('boom');

    await Promise.resolve();
    expect(store.$()).toEqual({ left: '', right: '', outside: 'stable' });
  });

  it('aborts a mixed structural thrown rollback through the realization port, restores baseline state, and does not reuse the fresh subject id', async () => {
    const { getPathNotifier, resetPathNotifier } = await import(
      '../../lib/path-notifier'
    );
    resetPathNotifier();
    getPathNotifier().setBatchingEnabled(false);

    const store = signalTree(
      {
        count: 0,
        rows: entityMap<{ id: string; name: string }, string>({
          selectId: (row) => row.id,
        }),
      },
      { enhancers: [transactions({ history: { retain: 1000 } })] }
    ) as unknown as {
      $: {
        (): {
          count: number;
          rows: { all: Array<{ id: string; name: string }> };
        };
        count: () => number;
        rows: {
          addOne(row: { id: string; name: string }): void;
          removeOne(id: string): void;
          changeId(from: string, to: string): void;
          ids(): string[];
          byIdOrFail(id: string): {
            name: (() => string | undefined) & { __subjectIds?: number[] };
          };
        };
      };
      transact: (fn: () => void) => { confirm(): void; rollback(): void };
      __transactions: {
        getConfirmedTurnCount(): number;
        getPendingTurnCount(): number;
      };
    };

    store.$.rows.addOne({ id: 'b', name: 'Base' });
    await Promise.resolve();
    await Promise.resolve();

    const baselineConfirmed = store.__transactions.getConfirmedTurnCount();
    const baselinePending = store.__transactions.getPendingTurnCount();

    const originalSubject = store.$.rows.byIdOrFail('b').name
      .__subjectIds?.[0] as number | undefined;
    let abortedFreshSubject: number | undefined;

    expect(() =>
      store.transact(() => {
        store.$.count(1);
        store.$.rows.removeOne('b');
        store.$.rows.addOne({ id: 'a', name: 'Alpha' });
        abortedFreshSubject =
          store.$.rows.byIdOrFail('a').name.__subjectIds?.[0];
        store.$.rows.changeId('a', 'c');
        store.$.rows.byIdOrFail('c').name('Charlie');
        throw new Error('boom');
      })
    ).toThrow('boom');

    expect(originalSubject).toBe(1);
    expect(abortedFreshSubject).toBe(2);
    expect(store.$.count()).toBe(0);
    expect(store.$.rows.ids()).toEqual(['b']);
    expect(store.$()).toEqual({
      count: 0,
      rows: { all: [{ id: 'b', name: 'Base' }] },
    });
    expect(store.$.rows.byIdOrFail('b').name.__subjectIds?.[0]).toBe(
      originalSubject
    );
    expect(store.__transactions.getConfirmedTurnCount()).toBe(
      baselineConfirmed
    );
    expect(store.__transactions.getPendingTurnCount()).toBe(baselinePending);

    store.$.rows.addOne({ id: 'z', name: 'Zed' });
    await Promise.resolve();
    expect(store.$.rows.byIdOrFail('z').name.__subjectIds?.[0]).toBeGreaterThan(
      abortedFreshSubject as number
    );
  });

  it('throws rollback error with preserved callback failure when realization-port validation refuses and does not fallback to the scoped resolver', async () => {
    const { getPathNotifier, resetPathNotifier } = await import(
      '../../lib/path-notifier'
    );
    resetPathNotifier();
    getPathNotifier().setBatchingEnabled(false);

    const store = signalTree(
      {
        count: 0,
        rows: entityMap<{ id: string; name: string }, string>({
          selectId: (row) => row.id,
        }),
      },
      { enhancers: [transactions({ history: { retain: 1000 } })] }
    ) as {
      $: {
        count: () => number;
        rows: {
          addOne(row: { id: string; name: string }): void;
          removeOne(id: string): void;
          changeId(from: string, to: string): void;
          ids(): string[];
        };
      };
      transact: (fn: () => void) => { confirm(): void; rollback(): void };
      __transactions: {
        getConfirmedTurnCount(): number;
        getPendingTurnCount(): number;
      };
    };

    store.$.rows.addOne({ id: 'b', name: 'Base' });
    await Promise.resolve();
    await Promise.resolve();

    const baselineConfirmed = store.__transactions.getConfirmedTurnCount();
    const baselinePending = store.__transactions.getPendingTurnCount();
    const realizationPort = getTreeRealizationPort(store.$);
    if (!realizationPort?.validateEffects) {
      throw new Error('Expected transaction tree realization port');
    }

    const validateEffects = vi
      .spyOn(realizationPort, 'validateEffects')
      .mockImplementation(() => ({ kind: 'structural-drift' }));
    const applyAtomically = vi.spyOn(realizationPort, 'applyAtomically');

    try {
      store.transact(() => {
        store.$.count(1);
        store.$.rows.removeOne('b');
        store.$.rows.addOne({ id: 'a', name: 'Alpha' });
        store.$.rows.changeId('a', 'c');
        throw new Error('boom');
      });
      throw new Error('Expected thrown rollback to fail closed');
    } catch (error) {
      expect(error).toBeInstanceOf(SignalTreeRollbackError);
      const rollbackError = error as SignalTreeRollbackError;
      expect(rollbackError.cause).toMatchObject({
        kind: 'effect-validation-failed',
        pendingTurnId: 1,
        errorMessage: 'Transaction rollback refused: structural-drift',
        callbackError: expect.objectContaining({ message: 'boom' }),
        cause: { kind: 'structural-drift' },
      });
      expect(validateEffects).toHaveBeenCalledOnce();
      expect(applyAtomically).not.toHaveBeenCalled();
      expect(store.$.count()).toBe(1);
      expect(store.$.rows.ids()).toEqual(['c']);
      expect(store.__transactions.getConfirmedTurnCount()).toBe(
        baselineConfirmed
      );
      // Refused compensation preserves the same pending settlement authority.
      expect(store.__transactions.getPendingTurnCount()).toBe(
        baselinePending + 1
      );
    }

    validateEffects.mockRestore();
    applyAtomically.mockRestore();
  });

  it('aborts a mixed structural explicit pending rollback through the realization port, restores baseline state, and closes the pending lifecycle', async () => {
    const { getPathNotifier, resetPathNotifier } = await import(
      '../../lib/path-notifier'
    );
    resetPathNotifier();
    getPathNotifier().setBatchingEnabled(false);

    const store = signalTree(
      {
        count: 0,
        rows: entityMap<{ id: string; name: string }, string>({
          selectId: (row) => row.id,
        }),
      },
      { enhancers: [transactions({ history: { retain: 1000 } })] }
    ) as {
      (): { count: number; rows: { all: Array<{ id: string; name: string }> } };
      $: {
        count: () => number;
        rows: {
          addOne(row: { id: string; name: string }): void;
          removeOne(id: string): void;
          changeId(from: string, to: string): void;
          ids(): string[];
          byIdOrFail(id: string): {
            name: (() => string | undefined) & { __subjectIds?: number[] };
          };
        };
      };
      transact: (fn: () => void) => { confirm(): void; rollback(): void };
      __transactions: {
        getConfirmedTurnCount(): number;
        getPendingTurnCount(): number;
      };
    };

    store.$.rows.addOne({ id: 'b', name: 'Base' });
    await Promise.resolve();
    await Promise.resolve();

    const baselineConfirmed = store.__transactions.getConfirmedTurnCount();
    const baselinePending = store.__transactions.getPendingTurnCount();
    const originalSubject = store.$.rows.byIdOrFail('b').name
      .__subjectIds?.[0] as number | undefined;

    const pending = store.transact(() => {
      store.$.count(1);
      store.$.rows.removeOne('b');
      store.$.rows.addOne({ id: 'a', name: 'Alpha' });
      store.$.rows.changeId('a', 'c');
      store.$.rows.byIdOrFail('c').name('Charlie');
    });

    const pendingFreshSubject =
      store.$.rows.byIdOrFail('c').name.__subjectIds?.[0];

    expect(originalSubject).toBe(1);
    expect(pendingFreshSubject).toBe(2);
    expect(store.$.count()).toBe(1);
    expect(store.$.rows.ids()).toEqual(['c']);
    expect(store.__transactions.getConfirmedTurnCount()).toBe(
      baselineConfirmed
    );
    expect(store.__transactions.getPendingTurnCount()).toBe(
      baselinePending + 1
    );

    pending.rollback();

    expect(store.$.count()).toBe(0);
    expect(store.$.rows.ids()).toEqual(['b']);
    expect(store.$()).toEqual({
      count: 0,
      rows: { all: [{ id: 'b', name: 'Base' }] },
    });
    expect(store.$.rows.byIdOrFail('b').name.__subjectIds?.[0]).toBe(
      originalSubject
    );
    expect(store.__transactions.getConfirmedTurnCount()).toBe(
      baselineConfirmed
    );
    expect(store.__transactions.getPendingTurnCount()).toBe(baselinePending);

    expect(() => pending.rollback()).not.toThrow();
    expect(() => pending.confirm()).toThrow(
      'Cannot confirm a rolled back transaction'
    );

    store.$.rows.addOne({ id: 'z', name: 'Zed' });
    await Promise.resolve();
    expect(store.$.rows.byIdOrFail('z').name.__subjectIds?.[0]).toBeGreaterThan(
      pendingFreshSubject as number
    );
  });

  it('keeps the primary transaction error when capture release cleanup also fails', async () => {
    const { getPathNotifier, resetPathNotifier } = await import(
      '../../lib/path-notifier'
    );
    const { MUTATION_CAPTURE_RUNTIME } = await import(
      '../../lib/internals/mutation-capture-runtime'
    );
    const { getOrCreateInternalTransactionRuntime } = await import(
      './transactions'
    );
    resetPathNotifier();
    getPathNotifier().setBatchingEnabled(false);

    const store = signalTree({ left: '', outside: 'stable' });
    const cleanupFailure = new Error('cleanup failed');
    const report = vi
      .spyOn(console, 'error')
      .mockImplementation(() => undefined);
    (store as unknown as Record<symbol, unknown>)[MUTATION_CAPTURE_RUNTIME] = {
      isCaptureActive: () => false,
      activateCapture: () => () => {
        throw cleanupFailure;
      },
    };

    const runtime = getOrCreateInternalTransactionRuntime(store);

    expect(() =>
      runtime.transaction(() => {
        store.$.left('L');
        throw new Error('boom');
      })
    ).toThrow('boom');

    expect(report).toHaveBeenCalledWith(
      'SignalTree: transactions() cleanup failed during transaction capture release after failure.',
      cleanupFailure
    );

    report.mockRestore();
  });

  it('surfaces capture release cleanup failure when the transaction body succeeds', async () => {
    const { resetPathNotifier } = await import('../../lib/path-notifier');
    const { MUTATION_CAPTURE_RUNTIME } = await import(
      '../../lib/internals/mutation-capture-runtime'
    );
    const { getOrCreateInternalTransactionRuntime } = await import(
      './transactions'
    );
    resetPathNotifier();

    const store = signalTree({ count: 0 });
    const cleanupFailure = new Error('cleanup failed');
    (store as unknown as Record<symbol, unknown>)[MUTATION_CAPTURE_RUNTIME] = {
      isCaptureActive: () => false,
      activateCapture: () => () => {
        throw cleanupFailure;
      },
    };

    const runtime = getOrCreateInternalTransactionRuntime(store);

    expect(() =>
      runtime.transaction(() => {
        store.$.count(1);
      })
    ).toThrow('cleanup failed');
  });

  it('preserves a later same-subject field write when rolling back a pending rekey', async () => {
    const { resetPathNotifier } = await import('../../lib/path-notifier');
    resetPathNotifier();

    const store = signalTree(
      {
        rows: entityMap<{ id: number; name: string }, number>({
          selectId: (row) => row.id,
        }),
      },
      { enhancers: [transactions()] }
    );

    store.$.rows.addOne({ id: 7, name: 'target' });
    await Promise.resolve();
    await Promise.resolve();

    const pending = store.transact(() => {
      store.$.rows.changeId(7, 42);
    });

    store.$.rows.byIdOrFail(42).name('later');
    await Promise.resolve();
    await Promise.resolve();

    pending.rollback();

    expect(store.$.rows.ids()).toEqual([7]);
    expect(store.$.rows.byIdOrFail(7).name()).toBe('later');
  });

  it('rejects rollback of a pending add when later same-subject field work depends on that existence', async () => {
    const { resetPathNotifier } = await import('../../lib/path-notifier');
    resetPathNotifier();

    const store = signalTree(
      {
        rows: entityMap<{ id: number; name: string }, number>({
          selectId: (row) => row.id,
        }),
      },
      { enhancers: [transactions()] }
    );

    const pending = store.transact(() => {
      store.$.rows.addOne({ id: 17, name: 'pending' });
    });

    store.$.rows.byIdOrFail(17).name('later');
    await Promise.resolve();
    await Promise.resolve();

    expectRollbackError(() => pending.rollback(), {
      kind: 'later-confirmed-dependency',
      pendingEffect: { kind: 'add' },
      conflictingEffect: { kind: 'set' },
    });
    expect(store.$.rows.ids()).toEqual([17]);
    expect(store.$.rows.byIdOrFail(17).name()).toBe('later');
  });

  it('supports an optimistic workflow where rollback reverts optimistic state but preserves later unrelated activity', async () => {
    const { resetPathNotifier } = await import('../../lib/path-notifier');
    resetPathNotifier();

    const store = signalTree(
      {
        order: { status: 'open' as 'open' | 'assigned' },
        driver: { orderId: null as number | null },
        telemetry: entityMap<{ id: number; lat: number }, number>({
          selectId: (row) => row.id,
        }),
      },
      { enhancers: [transactions()] }
    );

    const pending = store.transact(() => {
      store.$.order.status('assigned');
      store.$.driver.orderId(17);
    });

    store.$.telemetry.addOne({ id: 9, lat: 42 });
    await Promise.resolve();
    await Promise.resolve();

    pending.rollback();

    expect(store.$()).toEqual({
      order: { status: 'open' },
      driver: { orderId: null },
      telemetry: { all: [{ id: 9, lat: 42 }] },
    });
  });

  it('supports application refetch fallback when rollback is conservatively rejected', async () => {
    const { resetPathNotifier } = await import('../../lib/path-notifier');
    resetPathNotifier();

    const store = signalTree(
      {
        rows: entityMap<{ id: number; name: string }, number>({
          selectId: (row) => row.id,
        }),
      },
      { enhancers: [transactions()] }
    );

    const pending = store.transact(() => {
      store.$.rows.addOne({ id: 17, name: 'optimistic' });
    });

    store.$.rows.byIdOrFail(17).name('dependent-later');
    await Promise.resolve();
    await Promise.resolve();

    try {
      pending.rollback();
      throw new Error('Expected rollback to fail');
    } catch (error) {
      expect(error).toBeInstanceOf(SignalTreeRollbackError);
      store.$.rows.removeOne(17);
      await Promise.resolve();
      await Promise.resolve();
    }

    expect(store.$.rows.ids()).toEqual([]);
  });
});
