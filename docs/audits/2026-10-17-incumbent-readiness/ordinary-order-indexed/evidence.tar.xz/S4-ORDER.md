# S4 ordinary order carrier audit

Static inspection October24 of mutable native source; no replay or frozen identity qualification by this audit. Source lines are observations only.

CollectionOrderDelta (target-transition.ts252–259) stores lengths, frontiers and participants' endpoint ranks, not backbone identities. deriveCollectionOrderDelta500–548 computes a common subsequence and deliberately omits it. applyCollectionOrderDelta550 onward recovers that backbone by filtering its supplied current array, after validating frontier/length/participant ranks. Therefore delta+frontier alone does not encode a complete target. Frontier is opaque identity, not storage from which to decode omitted lifetimes.

Current target derivation432–489 applies delta to collection.order obtained from physical source. transactions.ts2887 derives delta from captured beforeSubjects/afterSubjects. Entity source publishOrderChange before/after presently originate physical snapshots; merely adding optional target.admittedOrder (prepare-entity-target.ts138) does not populate a valid ordinary target. Setting admittedOrder=target.order would assert P=O, precisely the unproved boundary.

## What is derivable

If a delta is explicitly certified as an ordinary endpoint delta, applying it to the source owner's **matching ordinary endpoint** can recover its target using that owner's backbone. This is bounded fact carrying, not a new authority. But existing physical delta cannot generically be treated as ordinary: inspection may reorder/remove members so ordinary backbone/membership/length differs. Even equal lengths do not prove correspondence; frontier is currently physical. Reusing physical frontier for unrelated ordinary ordering would make validation meaningless.

A complete requested target can legitimately enumerate owner ordinary order, apply selected ordinary structural inverse in execution order, then its explicitly admitted ordinary order transition. The current source owner supplies current O topology; it cannot manufacture historical omitted O endpoint after capture if the delta was physical. Additional carrier must contain either prepared ordinary target order for that admitted operation/inverse or an ordinary delta plus certified endpoint identity/backbone provenance. Capture this when both O endpoints exist; downstream cannot infer it from current P rows.

## Minimal native discriminator to prewrite/run frozen

Start O ABC. Inspection explicitly reorders CBA (same lifetimes, Link created before inspection). Own explicit full reorder ACB, then rollback. Assert ordinary projection returns ABC (source ordinary before own order), while physical display follows existing inverse footprint/placement policy separately. Current full-target path must show which ordinary before/after order it captured; physical delta alone starts CBA and can restore CBA incorrectly. Include inspect and later ordinary field write to expose persistent O contamination. This audit has not executed that sequence and labels it a proposed discriminator, not a reproduced defect. If own full reorder semantics expressly adopts a different ordinary order footprint, verify that against existing owner-approved authored-order rules before choosing an expected physical result.

Also keep unchanged compound OABC/P-CBX own membership-only setAllCAX regression: no explicit own order delta there, so source ordinary restoration should use owner facts rather than physical target reconstruction. This separately proves no blanket physicaltarget→ordinaryorder default is valid.

## Bounded mechanism / stop boundary

Carry separate prepared physical target order and admitted ordinary target order through the existing private target carrier, populated from source-owned ordinary state plus authorized inverse facts before validation. For own explicit order capture, preserve separate O endpoint evidence at source preparation; retain existing P order delta/frontier for P installation/compatibility. Do not reinterpret physical captures silently or introduce a second settlement authority. A full requested order may processN; point realization must avoid enumeration. If preserving distinct O endpoint proof requires redesigning transaction/history order-delta semantics across authorities rather than private source fact carriage, report that concrete scope expansion before implementation.
