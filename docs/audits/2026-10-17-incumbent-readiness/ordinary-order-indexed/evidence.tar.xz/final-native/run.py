from pathlib import Path
import subprocess,json,hashlib,os,difflib,shutil
b=Path('/private/tmp/ordinary-order-indexed');c=b/'native';d=b/'final-native';control=Path('/private/tmp/inverse-disposition-native/candidate')
m={str(p.relative_to(c)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((c/'packages').rglob('*.ts'))}
(d/'SOURCE.json').write_text(json.dumps(m,indent=2)+'\n');changed=[]
with (d/'CUMULATIVE.patch').open('w') as diff:
 for rel,h in m.items():
  p=c/rel;old=control/rel
  if old.exists() and hashlib.sha256(old.read_bytes()).hexdigest()==h:continue
  changed.append(rel);out=d/'source'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
  diff.writelines(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],p.read_text().splitlines(True),fromfile=str(old),tofile=str(p)))
(d/'CHANGED.json').write_text(json.dumps(changed,indent=2)+'\n')
cmd=json.loads(Path('/private/tmp/inverse-disposition-native/order-policy/qualified-command.json').read_text());extra=['src/lib/prepend-publication-boundary.spec.ts','src/enhancers/transactions/native-compound-ordinary-order-regression.spec.ts','src/lib/indexed-source-owner-payload.spec.ts','src/lib/indexed-source-owner-cross-baseline.spec.ts','src/lib/indexed-source-owner-prepend.spec.ts','src/lib/indexed-source-owner-s4.spec.ts','src/lib/indexed-source-owner-subset.spec.ts','src/lib/ordinary-order-indexed-work.spec.ts','src/lib/ordinary-order-source-boundaries.spec.ts','src/lib/entity-egress-footprint.spec.ts','src/lib/entity-egress-footprint-delivery.spec.ts','src/lib/entity-inspection-egress.spec.ts','src/lib/inspection-egress-conformance.spec.ts','src/lib/indexed-source-owner-prefix.spec.ts','src/lib/ordinary-order-owner-preparation.spec.ts']
for f in extra:
 arg='--testFile='+f
 if arg not in cmd:cmd.insert(-1,arg)
(d/'COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n')
env=dict(os.environ,COREPACK_ENABLE_NETWORK='0',NX_DAEMON='false',NX_ISOLATE_PLUGINS='false')
with (d/'FIRST.log').open('w') as out:r=subprocess.run(cmd,cwd=c,env=env,stdout=out,stderr=subprocess.STDOUT)
assert all(hashlib.sha256((c/f).read_bytes()).hexdigest()==h for f,h in m.items()),'source changed during run'
print('exit',r.returncode,'source',hashlib.sha256((d/'SOURCE.json').read_bytes()).hexdigest(),flush=True)
