# Native experiment: scope and evidence corrections

October 24, 2026. These notes supplement the preserved plan; they do not rewrite its first version or the original tests.

## Physical order

NATIVE-PLAN.md initially described physical CAB as a requirement. That was an inference from an observed earlier realization/model input. The unchanged ordinary-only compound regression deliberately prescribes ordinary ABC, restored lifetime identities, rejected-lifetime absence and the subsequent ordinary field write; it does not prescribe exact physical order. The independent criteria retain their initial version and correct this distinction. Exact diagnostic source currently produces physical ABC and outbound CAB. Neither exact physical order is accepted merely because a model or implementation emits it; existing footprint and successor contracts still govern.

## Execution identities

The original native control was copied from the complete 770-file package manifest d1ff7c33a380d578390879a79e142950d0655920710a818af7d49fe2a017521b. NATIVE-FIRST-RED.log records four failures and nine passes before changes. The four assertions remain unchanged.

NATIVE-IMPLEMENTATION-FIRST.log records one failure and twelve passes. The implementation was edited again before a complete first-run source snapshot was saved. That log remains a historical observation, not an exact-source qualification. Do not assign the later diagnostic manifest to it.

The diagnostic-source directory freezes the six changed/new files for the later diagnostic execution. Independent replay verified those hashes and the unchanged compound failure. execution-third records a fresh pre-run manifest and changed source copies for the version with blanket ordinary selection: thirteen passes in the two original files. That result alone does not qualify its selection mechanism; independent cross-baseline controls demonstrate why source responsibility cannot replace relationship-relative operation semantics indiscriminately.

## Source and consumer separation

The diagnostic source prepares ordinary ABC before publication; Link ignores the carried ordinary structural facts. Independent boundary review permits testing consumption of existing prepared facts within this bounded native experiment, provided physical latent topology, connection baseline and eligibility remain distinct. This is not authorization to reconstruct source truth in Link, replace relationship state with a source snapshot, change public semantics or resume later slices.

The independent payload falsifier is separate: placement-only retention stores a stale payload, so ordinary B=44 followed by removal/rejection restores B=2. The predecessor restores44. The approved design already assigns payload authority to EntityValueStore; retaining a second payload cache in placement metadata is an implementation violation, not evidence that the indexed placement representation itself is impossible. Preserve this first failure through any correction.

## Unfinished qualification

No full-target, retirement, native work/retention, combined focused, type, lint, full-suite or artifact acceptance is inherited from the finite model. Later slices remain gated. Production, slice1 and the closed B investigation are unchanged.
