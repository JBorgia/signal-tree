import { withSelectedEntityDisposition } from '../selected-entity-disposition';
import { prepareOrdinaryRealization, ordinaryRealization, realizationPlacement } from './ordinary-realization';
import { withEntityOrdinaryChanges, type EntityRealizationEdit } from '../entity-value-transition';
import type { CommittedEntityMutation } from '../mutation-capture-runtime';
import {
  canRealizePlainBranchMember,
  preparePlainBranchMembers,
} from '../plain-branch-membership';
import type {
  ISignalTree,
  PositionId,
  StructuralEffect,
  WriteMetadata,
} from '../../types';
import { getPathNotifier } from '../../path-notifier';
import { getActiveWriteContext, withWriteContext } from '../../write-context';
import { deepClone } from '../utilities/deep-clone';
import { getOwnedOwnerPath, getOwnedPositionIds } from '../owned-mutation';
import { getPhysicalCommitClock } from '../physical-commit-clock';
import {
  getPositionRegistry,
  type PositionRegistry,
} from '../position-registry';
import { getTreeScalarSlotRuntime } from '../tree-scalar-slot-port';
import { isTraversableNode } from '../../utils';
import { visitTree } from '../visit-tree';
import { markOwnerInvalidatedFrom } from '../owner-invalidation-port';
import { getLocationRuntime } from '../location-runtime';

import type { ReversalEffect, ReversalRefusal } from './causal-types';
import { applyInInvalidationGroup } from './post-application-failure';
import { holdEntityMembershipDelivery } from '../entity-membership-source';
import { normalizeScopedValuePath } from './scoped-value-addressing';

type StructuralDriftRefusal = Extract<
  ReversalRefusal,
  { readonly kind: 'structural-drift' }
>;

const TREE_REALIZATION_DESCRIPTORS = Symbol.for(
  'SignalTree:TreeRealizationDescriptors'
);
const TREE_REALIZATION_PORT = Symbol.for('SignalTree:TreeRealizationPort');

type CollectionNode = {
  __prepareOrdinaryRealization?(effects: readonly ReversalEffect[], physicalAfter?: ReadonlyMap<number, unknown>, physicalEffects?: readonly ReversalEffect[]): {install(): void; changes: readonly CommittedEntityMutation[]};
  __preparePointValues?(
    values: readonly {
      subjectId: number;
      key: string | number;
      value: unknown;
      edits: readonly EntityRealizationEdit[];
    }[]
  ): {
    install(): void;
    invalidate(): void;
    publish(): void;
  };
  byIdOrFail(id: string | number): unknown;
  changeId(from: string | number, to: string | number): void;
  removeOne(id: string | number): void;
  __planFreshAdd?(
    key: string | number,
    entity: unknown,
    subjectId: number
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  };
  __planRemove?(
    key: string | number,
    subjectId: number
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  };
  __planRestore?(
    key: string | number,
    entity: unknown,
    subjectId: number,
    beforeSubject?: number,
    afterSubject?: number,
    /**
     * Keys this same frame will vacate before the restore commits. Without it
     * the occupancy check is evaluated against pre-frame state and rejects a
     * key the frame itself is about to free. See RESTORE-P0 P0-D.
     */
    vacatingKeys?: ReadonlySet<string | number>
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  };
  __planRekey?(
    from: string | number,
    to: string | number
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  };
  __planPreparedRekey?(
    from: string | number,
    to: string | number,
    subjectId: number,
    entity: unknown,
    placement?: { beforeSubject?: number; afterSubject?: number }
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  };
  __findKeyBySubjectId?(subjectId: number): string | number | undefined;
  __inspectSubjectResources?(
    subjectId: number
  ): { state: 'active' | 'tombstoned' } | undefined;
  __restoreOne?(
    key: string | number,
    entity: unknown,
    subjectId: number,
    beforeSubject?: number,
    afterSubject?: number
  ): void;
};

type WritableLeaf = {
  set(value: unknown): void;
};

type WritableEntityNode = {
  (value: unknown): void;
};

type PreparedSubjectRealization = {
  collectionPath: string;
  /** The collection node this subject belongs to; the scope of its key. */
  scope: object;
  subjectId: number;
  reachable: boolean;
  currentKey: string | number | undefined;
  value: unknown;
};

type PreparedOccupancyState = number | 'vacant';

/**
 * Subject lifetimes are allocated per collection, so two collections routinely
 * hold the same lifetime ID, and two collections can share a path label (a
 * literal `'a.b'` key beside a nested `a.b`). Prepared subjects and key
 * occupancy are therefore scoped by the collection NODE each effect resolves
 * to, by owner position where the effect states one. A bare lifetime once let
 * one collection's restored row absorb another collection's field reversal.
 */
class PreparedRealizationContext {
  constructor(
    private readonly scopeOf: (effect: ReversalEffect) => object | undefined
  ) {}

  private readonly subjects = new Map<
    object,
    Map<number, PreparedSubjectRealization>
  >();
  private readonly occupancy = new Map<
    object,
    Map<string | number, PreparedOccupancyState>
  >();

  private setOccupancy(
    scope: object,
    key: string | number,
    state: PreparedOccupancyState
  ): void {
    let entries = this.occupancy.get(scope);
    if (!entries) {
      entries = new Map<string | number, PreparedOccupancyState>();
      this.occupancy.set(scope, entries);
    }
    entries.set(key, state);
  }

  private subjectsIn(scope: object): Map<number, PreparedSubjectRealization> {
    let subjects = this.subjects.get(scope);
    if (!subjects) {
      subjects = new Map();
      this.subjects.set(scope, subjects);
    }
    return subjects;
  }

  rememberRestoredSubject(
    effect: ReversalEffect,
    subjectId: number,
    collectionPath: string,
    key: string | number,
    value: unknown
  ): void {
    const scope = this.scopeOf(effect);
    if (!scope) return;
    this.subjectsIn(scope).set(subjectId, {
      collectionPath,
      scope,
      subjectId,
      reachable: true,
      currentKey: key,
      value,
    });
    this.setOccupancy(scope, key, subjectId);
  }

  rememberRekeyedSubject(
    effect: ReversalEffect,
    subjectId: number,
    key: string | number
  ): void {
    const existing = this.resolveSubject(effect, subjectId);
    if (!existing) {
      return;
    }

    this.setOccupancy(
      existing.scope,
      existing.currentKey as string | number,
      'vacant'
    );
    this.setOccupancy(existing.scope, key, subjectId);

    this.subjectsIn(existing.scope).set(subjectId, {
      ...existing,
      reachable: true,
      currentKey: key,
    });
  }

  rememberRemovedSubject(
    effect: ReversalEffect,
    subjectId: number,
    collectionPath: string,
    key: string | number,
    value: unknown
  ): void {
    const scope = this.scopeOf(effect);
    if (!scope) return;
    const existing = this.subjectsIn(scope).get(subjectId);
    const currentValue = existing?.value ?? value;

    this.setOccupancy(scope, existing?.currentKey ?? key, 'vacant');

    this.subjectsIn(scope).set(subjectId, {
      collectionPath,
      scope,
      subjectId,
      reachable: false,
      currentKey: undefined,
      value: currentValue,
    });
  }

  resolveSubject(
    effect: ReversalEffect,
    subjectId: number
  ): PreparedSubjectRealization | undefined {
    const scope = this.scopeOf(effect);
    return scope === undefined
      ? undefined
      : this.subjects.get(scope)?.get(subjectId);
  }

  resolveOccupancy(
    scope: object,
    key: string | number
  ): PreparedOccupancyState | undefined {
    return this.occupancy.get(scope)?.get(key);
  }
}

type StructuralOwnerIndex = ReadonlyMap<PositionId, string> & {
  readonly nodes: ReadonlyMap<PositionId, CollectionNode>;
};

type SubjectRealizationDescriptor = {
  path: string;
  ownerPath: string;
  collectionPath?: string;
  fieldPathFromRow?: string;
};

type InlineSubjectAddressEffect = ReversalEffect & {
  subjectId: number;
  path: string;
  ownerPath: string;
};

export interface TreeRealizationDescriptor {
  readonly path?: string;
  readonly ownerPath?: string;
  readonly collectionPath?: string;
  readonly fieldPathFromRow?: string;
  readonly structuralEffects?: ReadonlyMap<string, StructuralEffect>;
  readonly structuralEffectBySubject?: ReadonlyMap<string, StructuralEffect>;
  readonly subjectDescriptors?: ReadonlyMap<
    string,
    SubjectRealizationDescriptor
  >;
}

export interface RememberTreeRealizationDescriptorOptions {
  readonly descriptors: Map<PositionId, TreeRealizationDescriptor>;
  /**
   * ADDRESS-REPAIR-1 — canonical collection authority.
   *
   * Optional because SUBJECT-ADDRESS-CARDINALITY-0 measured that descriptor
   * capture is FALLBACK machinery: every effect needing a field coordinate
   * carries its own inline address, and the inline term wins. Capture still
   * derives correctly when the registry is supplied, and synthetic callers
   * without one keep the legacy interpretation.
   */
  readonly registry?: PositionRegistry;
  readonly path: string;
  readonly ownerPath?: string;
  readonly positionIds?: readonly number[];
  readonly subjectIds?: readonly number[];
  readonly meta?: WriteMetadata;
}

export interface CreateTreeRealizationAdapterOptions {
  readonly tree: ISignalTree<object>;
  readonly descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>;
}

export interface TreeRealizationPort {
  prepareOrdinaryEffects?(effects: readonly ReversalEffect[]): readonly ReversalEffect[];
  validateEffects(
    effects: readonly ReversalEffect[]
  ): StructuralDriftRefusal | undefined;
  applyAtomically(effects: readonly ReversalEffect[]): void;
}

function isRealizationAttachmentHost(
  node: unknown
): node is Record<PropertyKey, unknown> {
  return isTraversableNode(node) || typeof node === 'function';
}

export function rememberTreeRealizationDescriptor(
  options: RememberTreeRealizationDescriptorOptions
): void {
  const owner = options.positionIds?.[0] as PositionId | undefined;
  if (owner === undefined) {
    return;
  }

  const existing = options.descriptors.get(owner);
  const structuralEffects =
    existing?.structuralEffects instanceof Map
      ? (existing.structuralEffects as Map<string, StructuralEffect>)
      : new Map(existing?.structuralEffects ?? []);
  const structuralEffectBySubject =
    existing?.structuralEffectBySubject instanceof Map
      ? (existing.structuralEffectBySubject as Map<string, StructuralEffect>)
      : new Map(existing?.structuralEffectBySubject ?? []);
  const subjectDescriptors =
    existing?.subjectDescriptors instanceof Map
      ? (existing.subjectDescriptors as Map<
          string,
          SubjectRealizationDescriptor
        >)
      : new Map(existing?.subjectDescriptors ?? []);
  if (options.meta?.structuralEffect) {
    structuralEffects.set(
      toStructuralEffectKey(options.meta.structuralEffect),
      options.meta.structuralEffect
    );
    if (
      options.meta.structuralEffect.kind === 'add' ||
      options.meta.structuralEffect.kind === 'remove'
    ) {
      structuralEffectBySubject.set(
        String(options.meta.structuralEffect.subject),
        options.meta.structuralEffect
      );
    }
  }

  const subjectId = options.subjectIds?.[0];
  const ownerPath = options.ownerPath ?? options.path;
  // ADDRESS-REPAIR-1 — the registry answers, the string does not.
  const { collectionPath, fieldPathFromRow } = deriveRealizationAddress(
    options.path,
    ownerPath,
    subjectId,
    options.meta?.structuralEffect,
    options.registry?.collectionPathFor(owner)
  );
  if (typeof subjectId === 'number') {
    const subjectKey = String(subjectId);
    const existingSubjectDescriptor = subjectDescriptors.get(subjectKey);
    if (
      !existingSubjectDescriptor ||
      existingSubjectDescriptor.path !== options.path ||
      existingSubjectDescriptor.ownerPath !== ownerPath ||
      existingSubjectDescriptor.collectionPath !== collectionPath ||
      existingSubjectDescriptor.fieldPathFromRow !== fieldPathFromRow
    ) {
      subjectDescriptors.set(subjectKey, {
        path: options.path,
        ownerPath,
        collectionPath,
        fieldPathFromRow,
      });
    }
  }

  const nextPath = existing?.path ?? options.path;
  const nextOwnerPath = existing?.ownerPath ?? ownerPath;
  const nextCollectionPath = existing?.collectionPath ?? collectionPath;
  const nextFieldPathFromRow = existing?.fieldPathFromRow ?? fieldPathFromRow;

  if (
    existing?.path === nextPath &&
    existing?.ownerPath === nextOwnerPath &&
    existing?.collectionPath === nextCollectionPath &&
    existing?.fieldPathFromRow === nextFieldPathFromRow &&
    existing?.structuralEffects === structuralEffects &&
    existing?.structuralEffectBySubject === structuralEffectBySubject &&
    existing?.subjectDescriptors === subjectDescriptors
  ) {
    return;
  }

  options.descriptors.set(owner, {
    path: nextPath,
    ownerPath: nextOwnerPath,
    collectionPath: nextCollectionPath,
    fieldPathFromRow: nextFieldPathFromRow,
    structuralEffects,
    structuralEffectBySubject,
    subjectDescriptors,
  });
}

/**
 * The port applies effects on behalf of two different callers — `restoration()`
 * restoring, and `transactions()` compensating a rollback — so it no longer
 * asserts an origin of its own. Each site takes `source` from the ambient write
 * context and falls back to `'system'`.
 *
 * This is what makes a restoration distinguishable from external truth at the
 * observation seam without changing its CLASSIFICATION: it stays
 * `participation: 'realized'`, because from the perspective of authorship and
 * history admission it is realization-like, and that is what stops an undo
 * recursively admitting itself.
 */
export function createTreeRealizationAdapter(
  options: CreateTreeRealizationAdapterOptions
): TreeRealizationPort {
  const scalarSlotRuntime =
    getTreeScalarSlotRuntime(options.tree) ??
    getTreeScalarSlotRuntime(options.tree.$);
  const physicalCommitClock =
    getPhysicalCommitClock(options.tree) ??
    getPhysicalCommitClock(options.tree.$);
  const structuralOwnerPaths = indexStructuralOwnerPaths(options.tree.$);

  return {
    prepareOrdinaryEffects(effects) {
      const byOwner = new Map(effects.map((effect) => [effect.owner, effect]));
      return prepareOrdinaryRealization(effects, (owner, subject) => {
        const effect = byOwner.get(owner);
        return effect ? resolveCollectionNode(options.tree, options.descriptors.get(owner), structuralOwnerPaths, effect)?.__findKeyBySubjectId?.(subject) : undefined;
      }).physical;
    },
    validateEffects(effects) {
      const preparedContext = buildPreparedRealizationContext(
        options.tree,
        options.descriptors,
        structuralOwnerPaths,
        scalarSlotRuntime,
        effects
      );
      if (!preparedContext) {
        return { kind: 'structural-drift' };
      }

      // RESTORE-P0 P0-C is deliberately NOT decided here.
      //
      // The first attempt compared each scalar location against the value the
      // turn left there and refused on any difference. It broke seven existing
      // selective-undo tests, because a closure undo legitimately reverses a
      // dependent turn first — so while reversing turn N the location still
      // holds turn N+1's value, and "current != recorded" is the NORMAL case,
      // not a conflict.
      //
      // The real predicate is provenance, not value: refuse when the current
      // value is EXTERNAL truth, allow when it came from an authored turn the
      // restoration is itself reversing. Only the history authority knows which
      // writes were realizations, so the check lives there.
      return undefined;
    },
    applyAtomically(effects) {
      const memberTargets = new Map<
        number,
        { present: boolean; value: unknown; turn?: number }
      >();
      const authoredValueEffects: ReversalEffect[] = [];
      for (const effect of effects) {
        if (effect.plainBranchMembership) {
          // Last-write order, as `deriveDeclarativeTransitionTarget` keeps it:
          // a jump concatenates every turn it crosses into one application.
          memberTargets.delete(effect.owner);
          memberTargets.set(effect.owner, {
            present: effect.plainBranchMembership.after,
            value: effect.after,
            ...(effect.turn === undefined ? {} : { turn: effect.turn }),
          });
        } else {
          authoredValueEffects.push(effect);
        }
      }
      const members = memberTargets.size
        ? preparePlainBranchMembers(options.tree.$, memberTargets)
        : undefined;
      // A scalar value an earlier turn left is superseded where a later
      // turn's member write staged its location (`withoutSupersededScalars`).
      const staged = members?.staged;
      const valueEffects = staged?.size
        ? authoredValueEffects.filter(
            (effect) =>
              effect.turn === undefined ||
              effect.structural !== undefined ||
              typeof effect.subjectId === 'number' ||
              (staged.get(effect.owner) ?? effect.turn) <= effect.turn
          )
        : authoredValueEffects;
      const apply = () => {
        // Prepare the remaining frame before any member is installed. All member
        // values and presence are installed before any effect is published.
        const heterogeneousFrame = valueEffects.length
          ? planHeterogeneousFrame(
              options.tree,
              options.descriptors,
              structuralOwnerPaths,
              scalarSlotRuntime,
              physicalCommitClock,
              valueEffects,
              ordinaryRealization(effects)?.ordinary
            )
          : undefined;
        let scalarFrame =
          !heterogeneousFrame && valueEffects.length
            ? planScalarFrame(
                options.tree,
                options.descriptors,
                structuralOwnerPaths,
                scalarSlotRuntime,
                valueEffects
              )
            : undefined;
        // ⚠️ SLOT SCALARS NEVER TAKE THE AUTHORED WRITE. A mixed reversal whose
        // collection cannot be planned yet (it lies under a member this
        // reversal re-adds) applies effect by effect. An authored scalar write
        // under a member the reversal hides re-adds that member's path
        // (`reactivatePathOnWrite`): a jump back over a path re-add, a
        // `setAll` and an omission came back with the member present and one
        // child (v16 8g, generated jump-vs-undo histories). Membership is the
        // membership targets' to decide; the slot frame writes values only.
        let perEffect: readonly ReversalEffect[] =
          heterogeneousFrame || scalarFrame ? [] : valueEffects;
        if (perEffect.length) {
          const slotScalars = valueEffects.filter(
            (effect) =>
              effect.structural === undefined &&
              effect.subjectId === undefined &&
              effect.subjectFieldSegments === undefined &&
              !hasInlineScopedAddress(effect) &&
              !hasInlineSubjectAddress(effect) &&
              scalarSlotRuntime?.resolveScalarSlot(effect.owner) !== undefined
          );
          scalarFrame = slotScalars.length
            ? planScalarFrame(
                options.tree,
                options.descriptors,
                structuralOwnerPaths,
                scalarSlotRuntime,
                slotScalars
              )
            : undefined;
          if (scalarFrame) {
            const framed = new Set(slotScalars);
            perEffect = valueEffects.filter((effect) => !framed.has(effect));
          }
        }
        members?.install();
        // A membership-only frame has no value frame to advance the shared
        // physical clock. Publish its installed presence under a new revision.
        if (members && valueEffects.length === 0)
          physicalCommitClock?.advance();
        if (heterogeneousFrame) {
          heterogeneousFrame.commit();
        } else {
          scalarFrame?.commit();
          for (const effect of perEffect) {
            applyEffect(
              options.tree,
              options.descriptors,
              structuralOwnerPaths,
              scalarSlotRuntime,
              effect
            );
          }
        }
        members?.publish();
      };

      // Membership listeners run once the whole reversal is installed and
      // published, in commit order, whatever throws on the way out.
      const releaseMembership = holdEntityMembershipDelivery(options.tree.$);
      try {
        applyInInvalidationGroup(options.tree.$, apply);
      } finally {
        releaseMembership();
      }
    },
  };
}

export function defineTreeRealizationDescriptors(
  node: object,
  descriptors: Map<PositionId, TreeRealizationDescriptor>
): void {
  Object.defineProperty(node, TREE_REALIZATION_DESCRIPTORS, {
    value: descriptors,
    enumerable: false,
    configurable: true,
  });
}

export function getTreeRealizationDescriptors(
  node: unknown
): Map<PositionId, TreeRealizationDescriptor> | undefined {
  if (!isRealizationAttachmentHost(node)) {
    return undefined;
  }

  return (
    node as Record<
      symbol,
      Map<PositionId, TreeRealizationDescriptor> | undefined
    >
  )[TREE_REALIZATION_DESCRIPTORS];
}

export function defineTreeRealizationPort(
  node: object,
  port: TreeRealizationPort
): void {
  Object.defineProperty(node, TREE_REALIZATION_PORT, {
    value: port,
    enumerable: false,
    configurable: true,
  });
}

export function getTreeRealizationPort(
  node: unknown
): TreeRealizationPort | undefined {
  if (!isRealizationAttachmentHost(node)) {
    return undefined;
  }

  return (node as Record<symbol, TreeRealizationPort | undefined>)[
    TREE_REALIZATION_PORT
  ];
}

/**
 * Point-only realization for scalar slots and existing entity lifetimes.
 * The caller retains admission and the encompassing invalidation group.
 * Undefined means the effects require the existing structural/member planner.
 */
export function preparePointRealization(
  tree: ISignalTree<object>,
  effects: readonly ReversalEffect[]
): { install(): void; publish(): void } | undefined {
  if (
    !effects.length ||
    !effects.some((effect) => typeof effect.subjectId === 'number')
  )
    return undefined;
  const descriptors = getTreeRealizationDescriptors(tree.$);
  const slots =
    getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
  const clock = getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree);
  if (!descriptors || !slots || !clock) return undefined;
  const baseRevision = clock.revision();
  const owners = effects.some(
    (effect) => effect.structural || effect.plainBranchMembership
  )
    ? indexStructuralOwnerPaths(tree.$)
    : indexPointOwnerPaths(tree.$, effects);
  const memberTargets = new Map<
    number,
    { present: boolean; value: unknown; turn?: number }
  >();
  for (const effect of effects)
    if (effect.plainBranchMembership) {
      memberTargets.delete(effect.owner);
      memberTargets.set(effect.owner, {
        present: effect.plainBranchMembership.after,
        value: effect.after,
        ...(effect.turn === undefined ? {} : { turn: effect.turn }),
      });
    }
  if (effects.some((effect) => effect.structural)) {
    const scalarEffects = effects.filter(
      (effect) =>
        !effect.plainBranchMembership &&
        !effect.structural &&
        typeof effect.subjectId !== 'number'
    );
    const members = memberTargets.size
      ? preparePlainBranchMembers(tree.$, memberTargets, scalarEffects)
      : undefined;
    const entityEffects = effects.filter(
      (effect) =>
        !effect.plainBranchMembership &&
        (!members || effect.structural || typeof effect.subjectId === 'number')
    );
    const heterogeneous = planHeterogeneousFrame(
      tree,
      descriptors,
      owners,
      slots,
      clock,
      entityEffects,
      ordinaryRealization(effects)?.ordinary
    );
    if (!heterogeneous) return undefined;
    if (clock.revision() !== baseRevision)
      throw new Error('Point realization preparation reentered installation');
    let installed = false;
    return {
      install(): void {
        if (installed || clock.revision() !== baseRevision)
          throw new Error('Point realization base revision is stale');
        members?.install();
        // Existing structural commits resolve anchors in their established order.
        // The surrounding invalidation group defers native delivery until all install.
        heterogeneous.install();
        installed = true;
      },
      publish(): void {
        if (!installed)
          throw new Error('Point realization published before installation');
        let failed = false;
        let firstError: unknown;
        const run = (fn: () => void): void => {
          try {
            fn();
          } catch (error) {
            if (!failed) {
              failed = true;
              firstError = error;
            }
          }
        };
        run(() => heterogeneous.invalidate());
        if (members) run(() => members.invalidate());
        if (members) run(() => members.publish());
        run(() => heterogeneous.publish());
        if (failed) throw firstError;
      },
    };
  }
  // The transaction producer supplies whole-row or top-level effects. Deeper
  // synthetic inputs retain the existing general adapter, without selecting an
  // ordinary missing-parent policy here. Decline before target preparation.
  const pointPaths = new Map<ReversalEffect, readonly string[]>();
  for (const effect of effects) {
    if (effect.plainBranchMembership || typeof effect.subjectId !== 'number')
      continue;
    const path = resolveSubjectFieldPath(
      descriptors.get(effect.owner),
      effect,
      getPositionRegistry(tree.$)
    );
    if (path === undefined || path.length > 1) return undefined;
    pointPaths.set(effect, path);
  }
  const rows = new Map<
    CollectionNode,
    Map<
      number,
      {
        subjectId: number;
        key: string | number;
        value: unknown;
        edits: EntityRealizationEdit[];
      }
    >
  >();
  const scalarEffects: ReversalEffect[] = [];
  const frame = slots.beginFrame();
  for (const effect of effects) {
    if (effect.plainBranchMembership) continue;
    if (typeof effect.subjectId !== 'number') {
      if (
        effect.subjectFieldSegments !== undefined ||
        hasInlineScopedAddress(effect) ||
        hasInlineSubjectAddress(effect)
      )
        return undefined;
      const slot = slots.resolveScalarSlot(effect.owner);
      if (slot === undefined) return undefined;
      frame.set(slot, effect.after);
      scalarEffects.push(effect);
      continue;
    }
    const descriptor = descriptors.get(effect.owner);
    const collection = resolveCollectionNode(tree, descriptor, owners, effect);
    if (!collection?.__preparePointValues) return undefined;
    const key = collection.__findKeyBySubjectId?.(effect.subjectId);
    if (key === undefined) return undefined;
    let bySubject = rows.get(collection);
    if (!bySubject) rows.set(collection, (bySubject = new Map()));
    let row = bySubject.get(effect.subjectId);
    if (!row) {
      row = {
        subjectId: effect.subjectId,
        key,
        value: deepClone(snapshotCollectionEntityValue(collection, key)),
        edits: [],
      };
      bySubject.set(effect.subjectId, row);
    }
    const path = pointPaths.get(effect);
    if (path === undefined) return undefined;
    // Read user-provided effect payload once. The physical target and ordered
    // ordinary edit must not alias each other or mutate the caller's payload.
    const after = deepClone(effect.after);
    const present = effect.fieldPresence?.after !== false;
    if (path.length === 0) row.edits.push({ kind: 'row', value: after });
    else
      row.edits.push({ kind: 'field', field: path[0]!, present, value: after });
    if (path.length === 0) row.value = deepClone(after);
    else if (!present) row.value = withoutFieldAtSegments(row.value, path);
    else assignPreparedSubjectValue(row.value, path, deepClone(after));
  }
  const members = memberTargets.size
    ? preparePlainBranchMembers(tree.$, memberTargets, scalarEffects)
    : undefined;
  const collections = [...rows].map(([collection, subjects]) => {
    const prepare = collection.__preparePointValues;
    if (!prepare)
      throw new Error('Point realization preparation is unavailable');
    return prepare.call(collection, [...subjects.values()]);
  });
  if (!frame.prepareCommit) return undefined;
  const installScalars = members
    ? () => undefined
    : frame.prepareCommit({ advanceRevision: false, publish: false });
  if (clock.revision() !== baseRevision)
    throw new Error('Point realization preparation reentered installation');
  let result: ReturnType<typeof frame.commit> | undefined;
  let installed = false;
  return {
    install(): void {
      if (installed || clock.revision() !== baseRevision)
        throw new Error('Point realization base revision is stale');
      if (members) members.install();
      else result = installScalars();
      for (const collection of collections) collection.install();
      clock.advance();
      installed = true;
    },
    publish(): void {
      const installedScalars = result;
      if (!installed || (!members && !installedScalars))
        throw new Error('Point realization published before installation');
      // Complete all owned invalidation staging before any path or replay callback.
      let failed = false;
      let firstError: unknown;
      const run = (fn: () => void) => {
        try {
          fn();
        } catch (error) {
          if (!failed) {
            failed = true;
            firstError = error;
          }
        }
      };
      for (const collection of collections) run(() => collection.invalidate());
      if (members) run(() => members.invalidate());
      else if (installedScalars)
        run(() => slots.publishPrepared(installedScalars));
      if (members) run(() => members.publish());
      for (const collection of collections) run(() => collection.publish());
      for (const effect of members ? [] : scalarEffects)
        run(() => {
          const descriptor = descriptors.get(effect.owner);
          const path = resolveNotifyPath(tree, descriptor, owners, effect);
          if (path)
            getPathNotifier().notify(
              path,
              effect.after,
              effect.before,
              descriptor?.ownerPath ?? path,
              undefined,
              [effect.owner],
              {
                ...(getActiveWriteContext() ?? {}),
                intent: 'system',
                participation: 'realized',
              }
            );
        });
      run(() => markOwnerInvalidatedFrom(tree as object));
      if (failed) throw firstError;
    },
  };
}

function planHeterogeneousFrame(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  structuralOwnerPaths: StructuralOwnerIndex,
  scalarSlotRuntime: ReturnType<typeof getTreeScalarSlotRuntime>,
  physicalCommitClock: ReturnType<typeof getPhysicalCommitClock>,
  effects: readonly ReversalEffect[],
  ordinaryEffects?: readonly ReversalEffect[]
):
  | { commit(): void; install(): void; invalidate(): void; publish(): void }
  | undefined {
  if (
    effects.length === 0 ||
    !effects.some(
      (effect) =>
        effect.structural === 'rekey' ||
        effect.structural === 'add' ||
        effect.structural === 'remove'
    ) ||
    effects.some(
      (effect) =>
        effect.structural &&
        effect.structural !== 'rekey' &&
        effect.structural !== 'add' &&
        effect.structural !== 'remove'
    )
  ) {
    return undefined;
  }

  const scalarEffects = effects.filter((effect) => !effect.structural);
  const preparedContext = buildPreparedRealizationContext(
    tree,
    descriptors,
    structuralOwnerPaths,
    scalarSlotRuntime,
    effects
  );
  if (!preparedContext) {
    return undefined;
  }

  const removeKeysByEffect = new Map<
    ReversalEffect & { structural: 'remove'; subjectId: number },
    string | number
  >();
  const planningPreparedContext = new PreparedRealizationContext(
    preparedSubjectScope(tree, descriptors, structuralOwnerPaths)
  );
  for (const effect of effects) {
    const removeEffect =
      effect.structural === 'remove' && typeof effect.subjectId === 'number'
        ? (effect as ReversalEffect & {
            structural: 'remove';
            subjectId: number;
          })
        : undefined;

    if (removeEffect) {
      const descriptor = descriptors.get(effect.owner);
      const collectionNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        removeEffect
      );
      if (!collectionNode) {
        return undefined;
      }

      const effectiveRemoveKey = resolveEffectiveRemoveKey(
        collectionNode,
        planningPreparedContext,
        removeEffect
      );
      if (effectiveRemoveKey === undefined) {
        return undefined;
      }

      removeKeysByEffect.set(removeEffect, effectiveRemoveKey);
    }

    updatePreparedRealizationContext(
      tree,
      descriptors,
      structuralOwnerPaths,
      planningPreparedContext,
      effect
    );
  }

  // RESTORE-P0 P0-D — what this frame is about to free, per collection.
  //
  // `removeKeysByEffect` is fully resolved above, BEFORE any restore is
  // planned, so the planner already knows every key its own frame will vacate.
  // It just never told the collection, and `planRestore` therefore validated
  // occupancy against pre-frame state.
  //
  // Scoped by owner (position id) rather than global: two collections may
  // legitimately hold the same key, and freeing 'a' in one must not license
  // overwriting 'a' in another.
  const vacatingKeysByOwner = new Map<number, Set<string | number>>();
  for (const [removeEffect, removedKey] of removeKeysByEffect) {
    let keys = vacatingKeysByOwner.get(removeEffect.owner);
    if (!keys) {
      keys = new Set<string | number>();
      vacatingKeysByOwner.set(removeEffect.owner, keys);
    }
    keys.add(removedKey);
  }

  const preparedSubjectScalarEffects = scalarEffects.filter((effect) =>
    isPreparedSubjectScalarEffect(effect, preparedContext)
  );
  const framedScalarEffects = scalarEffects.filter(
    (effect) => !isPreparedSubjectScalarEffect(effect, preparedContext)
  );
  const rekeyEffects = effects.filter(
    (effect): effect is ReversalEffect & { structural: 'rekey' } =>
      effect.structural === 'rekey'
  );
  const restoreEffects = effects.filter(
    (effect): effect is ReversalEffect & { structural: 'add'; subjectId: number } =>
      effect.structural === 'add' && typeof effect.subjectId === 'number'
  );
  // Sequential simulation retains execution dependencies. Only installation
  // placement is ordered against the complete proposed topology.
  const placementEffects = orderPhysicalPlacements(tree, descriptors, structuralOwnerPaths, effects).filter((effect) => effect.structural === 'add' || realizationPlacement(effect) !== undefined);
  const baseRevision = scalarSlotRuntime?.revision();
  const scalarFrameRuntime =
    framedScalarEffects.length > 0 ? scalarSlotRuntime : undefined;

  const scalarFrame =
    framedScalarEffects.length > 0
      ? scalarFrameRuntime?.beginFrame()
      : undefined;
  if (framedScalarEffects.length > 0 && (!scalarFrameRuntime || !scalarFrame)) {
    return undefined;
  }
  const resolvedScalarFrameRuntime = scalarFrameRuntime;
  const plannedRestores: Array<{
    effect: ReversalEffect & { structural: 'add'; subjectId: number };
    plan: {
      commit(options?: { advancePhysicalRevision?: boolean }): void;
      publish(metaOverride?: WriteMetadata): void;
    };
  }> = [];
  const plannedFreshAdds: Array<{
    effect: ReversalEffect & { structural: 'add'; subjectId: number };
    plan: {
      commit(options?: { advancePhysicalRevision?: boolean }): void;
      publish(metaOverride?: WriteMetadata): void;
    };
  }> = [];
  const plannedRekeys: Array<{
    effect: ReversalEffect & { structural: 'rekey' };
    plan: {
      commit(options?: { advancePhysicalRevision?: boolean }): void;
      publish(metaOverride?: WriteMetadata): void;
    };
  }> = [];
  const plannedRemoves: Array<{
    effect: ReversalEffect & { structural: 'remove'; subjectId: number };
    plan: {
      commit(options?: { advancePhysicalRevision?: boolean }): void;
      publish(metaOverride?: WriteMetadata): void;
    };
  }> = [];

  type PhysicalPlan = { commit(options?: { advancePhysicalRevision?: boolean }): void; publish(metaOverride?: WriteMetadata): void };
  const placementPlans = new Map<ReversalEffect, PhysicalPlan>();
  for (const effect of restoreEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    const structuralEffect = getStructuralAddEffect(descriptor, effect);
    const collectionPath = resolveCollectionPath(
      descriptor,
      structuralOwnerPaths,
      effect
    );
    const subjectInventory = collectionNode?.__inspectSubjectResources?.(
      effect.subjectId
    );
    const isFreshSubject = subjectInventory === undefined;
    if (
      !collectionNode ||
      !structuralEffect ||
      !collectionPath ||
      (isFreshSubject
        ? typeof collectionNode.__planFreshAdd !== 'function'
        : typeof collectionNode.__planRestore !== 'function')
    ) {
      scalarFrame?.discard();
      return undefined;
    }

    const preparedSubject = preparedContext.resolveSubject(
      effect,
      effect.subjectId
    );
    if (!preparedSubject) {
      scalarFrame?.discard();
      return undefined;
    }

    if (isFreshSubject) {
      const planFreshAdd = collectionNode.__planFreshAdd;
      if (typeof planFreshAdd !== 'function') {
        scalarFrame?.discard();
        return undefined;
      }

      plannedFreshAdds.push({
        effect,
        plan: planFreshAdd(
          effect.after as string | number,
          preparedSubject.value,
          effect.subjectId
        ),
      });
      continue;
    }

    const planRestore = collectionNode.__planRestore;
    if (typeof planRestore !== 'function') {
      scalarFrame?.discard();
      return undefined;
    }

    plannedRestores.push({
      effect,
      plan: planRestore(
        effect.after as string | number,
        preparedSubject.value,
        effect.subjectId,
        structuralEffect.beforeSubject,
        structuralEffect.afterSubject,
        vacatingKeysByOwner.get(effect.owner)
      ),
    });
  }

  for (const effect of framedScalarEffects) {
    if (!resolvedScalarFrameRuntime) {
      scalarFrame?.discard();
      return undefined;
    }

    const slotIndex = resolvedScalarFrameRuntime.resolveScalarSlot(
      effect.owner
    );
    if (slotIndex === undefined) {
      scalarFrame?.discard();
      return undefined;
    }
    scalarFrame?.set(slotIndex, effect.after);
  }

  for (const effect of rekeyEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    if (
      !collectionNode ||
      (typeof collectionNode.__planRekey !== 'function' &&
        typeof collectionNode.__planPreparedRekey !== 'function')
    ) {
      scalarFrame?.discard();
      return undefined;
    }

    const preparedSubject =
      typeof effect.subjectId === 'number'
        ? preparedContext.resolveSubject(effect, effect.subjectId)
        : undefined;
    const plan =
      preparedSubject &&
      typeof collectionNode.__planPreparedRekey === 'function'
        ? collectionNode.__planPreparedRekey(
            effect.before as string | number,
            effect.after as string | number,
            effect.subjectId as number,
            preparedSubject.value,
            realizationPlacement(effect)?.structuralContext as { beforeSubject?: number; afterSubject?: number } | undefined
          )
        : typeof collectionNode.__planRekey === 'function'
        ? collectionNode.__planRekey(
            effect.before as string | number,
            effect.after as string | number
          )
        : undefined;
    if (!plan) {
      scalarFrame?.discard();
      return undefined;
    }

    plannedRekeys.push({
      effect,
      plan,
    });

    if (typeof effect.subjectId === 'number') {
      preparedContext.rememberRekeyedSubject(
        effect,
        effect.subjectId,
        effect.after as string | number
      );
    }
  }

  const removeEffects = effects.filter(
    (
      effect
    ): effect is ReversalEffect & { structural: 'remove'; subjectId: number } =>
      effect.structural === 'remove' && typeof effect.subjectId === 'number'
  );

  for (const effect of removeEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    if (!collectionNode || typeof collectionNode.__planRemove !== 'function') {
      scalarFrame?.discard();
      return undefined;
    }

    const effectiveRemoveKey = removeKeysByEffect.get(effect);
    if (effectiveRemoveKey === undefined) {
      scalarFrame?.discard();
      return undefined;
    }

    plannedRemoves.push({
      effect,
      plan: collectionNode.__planRemove(effectiveRemoveKey, effect.subjectId),
    });
  }

  for (const { effect, plan } of [...plannedFreshAdds, ...plannedRestores]) placementPlans.set(effect, plan);
  for (const { effect, plan } of plannedRekeys) if (realizationPlacement(effect)) placementPlans.set(effect, plan);

  const ordinaryPlans = new Map<PositionId, {install(): void; changes: readonly CommittedEntityMutation[]}>();
  if (ordinaryEffects) {
    const groups = new Map<PositionId, ReversalEffect[]>();
    for (const effect of ordinaryEffects) {
      if (typeof effect.subjectId !== 'number') continue;
      let group = groups.get(effect.owner);
      if (!group) groups.set(effect.owner, group = []);
      group.push(effect);
    }
    for (const [owner, group] of groups) {
      const node = resolveCollectionNode(tree, descriptors.get(owner), structuralOwnerPaths, group[0]);
      if (!node?.__prepareOrdinaryRealization) throw new Error('Ordinary realization binding is unavailable');
      // Source-owned preparation receives the exact physical execution order;
      // ordinary authority remains the separately selected group.
      const physicalGroup=[...removeEffects,...placementEffects,...plannedRekeys.filter(({effect})=>!realizationPlacement(effect)).map(({effect})=>effect)].filter(effect=>effect.owner===owner);
      ordinaryPlans.set(owner, node.__prepareOrdinaryRealization(group,undefined,physicalGroup));
    }
  }
  const publicationMeta = (effect: ReversalEffect): WriteMetadata => {
    const meta: WriteMetadata = { ...(getActiveWriteContext() ?? {}), intent: 'system', participation: 'realized' };
    const plan = ordinaryPlans.get(effect.owner);
    return plan ? withSelectedEntityDisposition(meta, plan.changes.filter((change) => change.subject === effect.subjectId)) : meta;
  };

  let scalarCommitResult:
    | ReturnType<NonNullable<typeof scalarFrame>['commit']>
    | undefined;
  const install = (): void => {
    if (
      scalarFrame &&
      physicalCommitClock &&
      physicalCommitClock.revision() !== baseRevision
    ) {
      throw new Error('Heterogeneous realization base revision is stale.');
    }

    scalarCommitResult = scalarFrame?.commit({
      advanceRevision: false,
      publish: false,
    });

    for (const { plan } of plannedRemoves) {
      plan.commit({ advancePhysicalRevision: false });
    }

    // Revival and transfer are the same placement dependency unit. An active
    // anchor which this unit moves is not an already-final surviving anchor.
    for (const effect of placementEffects) placementPlans.get(effect)?.commit({ advancePhysicalRevision: false });
    for (const { effect, plan } of plannedRekeys) {
      if (!realizationPlacement(effect)) plan.commit({ advancePhysicalRevision: false });
    }

    for (const plan of ordinaryPlans.values()) plan.install();
    physicalCommitClock?.advance();
  };
  const invalidate = (): void => {
    if (scalarCommitResult && scalarSlotRuntime) {
      scalarSlotRuntime.publishPrepared(scalarCommitResult);
    }
  };
  const publish = (): void => {
    let failed = false;
    let firstError: unknown;
    const run = (fn: () => void): void => {
      try {
        fn();
      } catch (error) {
        if (!failed) {
          failed = true;
          firstError = error;
        }
      }
    };

    for (const { plan, effect } of plannedRemoves) {
      run(() =>
        plan.publish(publicationMeta(effect))
      );
    }

    for (const { plan, effect } of plannedRestores) {
      run(() =>
        plan.publish(publicationMeta(effect))
      );
    }

    for (const { plan, effect } of plannedFreshAdds) {
      run(() =>
        plan.publish(publicationMeta(effect))
      );
    }

    for (const { plan, effect } of plannedRekeys) {
      run(() =>
        plan.publish(publicationMeta(effect))
      );
    }

    for (const effect of [
      ...preparedSubjectScalarEffects,
      ...framedScalarEffects,
    ]) {
      const descriptor = descriptors.get(effect.owner);
      const notifyPath = resolveNotifyPath(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!notifyPath) {
        continue;
      }

      run(() =>
        getPathNotifier().notify(
          notifyPath,
          effect.after,
          effect.before,
          descriptor?.ownerPath ?? notifyPath,
          typeof effect.subjectId === 'number' ? [effect.subjectId] : undefined,
          [effect.owner],
          {
            ...(getActiveWriteContext() ?? {}),
            intent: 'system',
            participation: 'realized',
          }
        )
      );
    }

    run(() => markOwnerInvalidatedFrom(tree as object));
    if (failed) throw firstError;
  };
  return {
    install,
    invalidate,
    publish,
    commit(): void {
      const commitAndPublish = () => {
        install();
        invalidate();
        publish();
      };
      const locations = getLocationRuntime(tree.$);
      if (locations) locations.runInvalidationGroup(commitAndPublish);
      else if (scalarSlotRuntime)
        scalarSlotRuntime.runInvalidationGroup(commitAndPublish);
      else commitAndPublish();
    },
  };
}

function planScalarFrame(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  structuralOwnerPaths: StructuralOwnerIndex,
  scalarSlotRuntime: ReturnType<typeof getTreeScalarSlotRuntime>,
  effects: readonly ReversalEffect[]
): { commit(): void } | undefined {
  void tree;
  void descriptors;
  void structuralOwnerPaths;
  if (
    effects.length === 0 ||
    effects.some(
      (effect) =>
        effect.structural ||
        effect.subjectFieldSegments !== undefined ||
        hasInlineScopedAddress(effect) ||
        hasInlineSubjectAddress(effect)
    )
  ) {
    return undefined;
  }

  if (!scalarSlotRuntime) {
    return undefined;
  }

  const frame = scalarSlotRuntime.beginFrame();
  for (const effect of effects) {
    const slotIndex = scalarSlotRuntime.resolveScalarSlot(effect.owner);
    if (slotIndex === undefined) {
      return undefined;
    }

    frame.set(slotIndex, effect.after);
  }

  return {
    commit(): void {
      frame.commit();

      for (const effect of effects) {
        const descriptor = descriptors.get(effect.owner);
        const notifyPath = resolveNotifyPath(
          tree,
          descriptor,
          structuralOwnerPaths,
          effect
        );
        if (!notifyPath) {
          continue;
        }

        getPathNotifier().notify(
          notifyPath,
          effect.after,
          effect.before,
          descriptor?.ownerPath ?? notifyPath,
          typeof effect.subjectId === 'number' ? [effect.subjectId] : undefined,
          [effect.owner],
          {
            ...(getActiveWriteContext() ?? {}),
            intent: 'system',
            participation: 'realized',
          }
        );
      }
    },
  };
}

function canApplyEffect(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  structuralOwnerPaths: StructuralOwnerIndex,
  scalarSlotRuntime: ReturnType<typeof getTreeScalarSlotRuntime>,
  effect: ReversalEffect,
  preparedContext?: PreparedRealizationContext
): boolean {
  if (effect.plainBranchMembership)
    return canRealizePlainBranchMember(tree.$, effect.owner);
  const descriptor = descriptors.get(effect.owner);
  if (
    !descriptor &&
    !effect.structural &&
    effect.subjectFieldSegments === undefined &&
    !scalarSlotRuntime?.resolveScalarLeaf(effect.owner) &&
    !hasInlineSubjectAddress(effect) &&
    !hasInlineScopedAddress(effect)
  ) {
    return false;
  }

  if (!effect.structural) {
    if (
      canResolvePreparedSubjectTarget(
        descriptor,
        effect,
        preparedContext,
        getPositionRegistry(tree.$)
      )
    ) {
      return true;
    }

    const target = resolveLiveScalarNode(
      tree,
      descriptor,
      scalarSlotRuntime,
      effect,
      structuralOwnerPaths
    );
    return isWritableLeaf(target) || isWritableEntityNode(target);
  }

  const ownerNode = resolveCollectionNode(
    tree,
    descriptor,
    structuralOwnerPaths,
    effect
  );
  if (!ownerNode) {
    return false;
  }

  const currentSubjectKey =
    typeof effect.subjectId === 'number'
      ? resolvePreparedOrLiveSubjectKey(
          ownerNode,
          preparedContext,
          effect,
          effect.subjectId
        )
      : undefined;
  const destinationOccupied =
    effect.structural === 'rekey' || effect.structural === 'add'
      ? isCollectionKeyOccupied(
          ownerNode,
          effect.after as string | number,
          preparedContext
        )
      : false;

  switch (effect.structural) {
    case 'remove': {
      const removeEffect =
        typeof effect.subjectId === 'number'
          ? (effect as ReversalEffect & {
              structural: 'remove';
              subjectId: number;
            })
          : undefined;
      return (
        (removeEffect
          ? resolveEffectiveRemoveKey(
              ownerNode,
              preparedContext,
              removeEffect
            ) !== undefined
          : hasCollectionKey(ownerNode, effect.before as string | number)) &&
        (typeof effect.subjectId !== 'number' ||
          currentSubjectKey !== undefined)
      );
    }
    case 'rekey':
      return (
        (typeof effect.subjectId === 'number'
          ? currentSubjectKey === effect.before
          : hasCollectionKey(ownerNode, effect.before as string | number)) &&
        (typeof effect.subjectId !== 'number' ||
          currentSubjectKey === effect.before) &&
        (!destinationOccupied || (realizationPlacement(effect) !== undefined && currentSubjectKey === effect.after))
      );
    case 'add': {
      if (
        typeof effect.subjectId !== 'number' ||
        typeof ownerNode.__restoreOne !== 'function' ||
        destinationOccupied ||
        currentSubjectKey !== undefined
      ) {
        return false;
      }

      return getStructuralAddEffect(descriptor, effect) !== undefined;
    }
  }
}

function applyEffect(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  structuralOwnerPaths: StructuralOwnerIndex,
  scalarSlotRuntime: ReturnType<typeof getTreeScalarSlotRuntime>,
  effect: ReversalEffect
): void {
  const descriptor = descriptors.get(effect.owner);
  if (
    !descriptor &&
    !effect.structural &&
    effect.subjectFieldSegments === undefined &&
    !scalarSlotRuntime?.resolveScalarLeaf(effect.owner) &&
    !hasInlineSubjectAddress(effect) &&
    !hasInlineScopedAddress(effect)
  ) {
    throw new Error(
      `Missing live descriptor for owner ${String(effect.owner)}`
    );
  }

  withWriteContext(
    {
      ...(getActiveWriteContext() ?? {}),
      intent: 'system',
      participation: 'realized',
    },
    () => {
      if (
        !effect.structural &&
        effect.fieldPresence?.after === false &&
        typeof effect.subjectId === 'number' &&
        effect.subjectFieldSegments?.length
      ) {
        // The field was absent at the target endpoint: remove the key from the
        // row rather than writing undefined into it.
        const row = resolveCurrentSubjectTarget(
          tree,
          descriptor,
          effect.subjectId,
          { ...effect, subjectFieldSegments: [] },
          structuralOwnerPaths
        );
        if (isWritableEntityNode(row)) {
          const read = row as unknown as () => unknown;
          row(withoutFieldAtSegments(read(), effect.subjectFieldSegments));
          return;
        }
      }
      if (!effect.structural) {
        const target = resolveLiveScalarNode(
          tree,
          descriptor,
          scalarSlotRuntime,
          effect,
          structuralOwnerPaths
        );
        if (isWritableLeaf(target)) {
          target.set(effect.after);
          return;
        }

        if (isWritableEntityNode(target)) {
          target(effect.after);
          return;
        }

        if (!isWritableLeaf(target)) {
          throw new Error(
            `Missing live leaf for owner ${String(effect.owner)}`
          );
        }
        return;
      }

      const ownerNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!ownerNode) {
        throw new Error(`Missing structural owner for ${String(effect.owner)}`);
      }

      switch (effect.structural) {
        case 'rekey':
          ownerNode.changeId(
            effect.before as string | number,
            effect.after as string | number
          );
          return;
        case 'remove': {
          const removeEffect =
            typeof effect.subjectId === 'number'
              ? (effect as ReversalEffect & {
                  structural: 'remove';
                  subjectId: number;
                })
              : undefined;
          const effectiveRemoveKey = removeEffect
            ? resolveEffectiveRemoveKey(ownerNode, undefined, removeEffect)
            : (effect.before as string | number);
          if (effectiveRemoveKey === undefined) {
            throw new Error(
              `Missing live structural subject for owner ${String(
                effect.owner
              )}`
            );
          }

          ownerNode.removeOne(effectiveRemoveKey);
          return;
        }
        case 'add': {
          const structuralEffect = getStructuralAddEffect(descriptor, effect);
          if (!structuralEffect) {
            throw new Error(
              `Missing structural restore metadata for owner ${String(
                effect.owner
              )}`
            );
          }

          ownerNode.__restoreOne?.(
            effect.after as string | number,
            structuralEffect.value,
            effect.subjectId as number,
            structuralEffect.beforeSubject,
            structuralEffect.afterSubject
          );
          return;
        }
      }
    }
  );
}

function resolveLiveScalarNode(
  tree: ISignalTree<object>,
  descriptor: TreeRealizationDescriptor | undefined,
  scalarSlotRuntime: ReturnType<typeof getTreeScalarSlotRuntime>,
  effect: ReversalEffect,
  structuralOwnerPaths: StructuralOwnerIndex
): unknown {
  if (typeof effect.subjectId === 'number') {
    return resolveCurrentSubjectTarget(
      tree,
      descriptor,
      effect.subjectId,
      effect,
      structuralOwnerPaths
    );
  }

  if (hasInlineScopedAddress(effect)) {
    return resolveCurrentScopedTarget(tree, descriptor, effect);
  }

  const directLeaf = scalarSlotRuntime?.resolveScalarLeaf(effect.owner);
  if (directLeaf) {
    return directLeaf;
  }

  if (!descriptor?.path) {
    return undefined;
  }

  const pathNode = resolveNodeAtPath(
    tree.$ as Record<string, unknown>,
    descriptor.path
  );
  return isWritableLeaf(pathNode) || isWritableEntityNode(pathNode)
    ? pathNode
    : undefined;
}

function canResolvePreparedSubjectTarget(
  descriptor: TreeRealizationDescriptor | undefined,
  effect: ReversalEffect,
  preparedContext: PreparedRealizationContext | undefined,
  registry: PositionRegistry | undefined
): boolean {
  if (typeof effect.subjectId !== 'number') {
    return false;
  }

  const preparedSubject = preparedContext?.resolveSubject(
    effect,
    effect.subjectId
  );
  if (!preparedSubject) {
    return false;
  }

  if (!preparedSubject.reachable) {
    return false;
  }

  const fieldPathFromRow = resolveSubjectFieldPath(
    descriptor,
    effect,
    registry
  );
  if (!fieldPathFromRow) {
    return false;
  }

  const value = preparedSubject.value as Record<string, unknown>;
  return effect.fieldPresence?.after === true && fieldPathFromRow.length > 0
    ? isTraversableNode(
        resolveNodeAtSegments(value, fieldPathFromRow.slice(0, -1))
      )
    : resolveNodeAtSegments(value, fieldPathFromRow) !== undefined;
}

function resolveCollectionNode(
  tree: ISignalTree<object>,
  descriptor: TreeRealizationDescriptor | undefined,
  structuralOwnerPaths: StructuralOwnerIndex,
  effect: ReversalEffect
): CollectionNode | undefined {
  const owned = structuralOwnerPaths.nodes.get(effect.owner);
  if (owned) return owned;
  if (effect.subjectFieldSegments !== undefined) return undefined;
  const collectionPath = resolveCollectionPath(
    descriptor,
    structuralOwnerPaths,
    effect
  );
  if (collectionPath === undefined) {
    return undefined;
  }

  const node = resolveNodeAtPath(
    tree.$ as Record<string, unknown>,
    collectionPath
  );
  return isCollectionNode(node) ? node : undefined;
}

function resolveCollectionPath(
  descriptor: TreeRealizationDescriptor | undefined,
  structuralOwnerPaths: StructuralOwnerIndex,
  effect: ReversalEffect
): string | undefined {
  return (
    descriptor?.collectionPath ??
    (effect.structural ? descriptor?.ownerPath : undefined) ??
    structuralOwnerPaths.get(effect.owner)
  );
}

function isCollectionKeyOccupied(
  ownerNode: CollectionNode,
  key: string | number,
  preparedContext: PreparedRealizationContext | undefined
): boolean {
  const preparedOccupancy = preparedContext?.resolveOccupancy(ownerNode, key);
  if (preparedOccupancy === 'vacant') {
    return false;
  }
  if (preparedOccupancy !== undefined) {
    return true;
  }

  return hasCollectionKey(ownerNode, key);
}

function resolvePreparedOrLiveSubjectKey(
  ownerNode: CollectionNode,
  preparedContext: PreparedRealizationContext | undefined,
  effect: ReversalEffect,
  subjectId: number
): string | number | undefined {
  const preparedSubject = preparedContext?.resolveSubject(effect, subjectId);
  if (preparedSubject) {
    return preparedSubject.currentKey;
  }

  return ownerNode.__findKeyBySubjectId?.(subjectId);
}

function resolveEffectiveRemoveKey(
  ownerNode: CollectionNode,
  preparedContext: PreparedRealizationContext | undefined,
  effect: ReversalEffect & { structural: 'remove'; subjectId: number }
): string | number | undefined {
  return resolvePreparedOrLiveSubjectKey(
    ownerNode,
    preparedContext,
    effect,
    effect.subjectId
  );
}

function snapshotCollectionEntityValue(
  collectionNode: CollectionNode,
  key: string | number
): unknown {
  const rowNode = collectionNode.byIdOrFail(key);
  return typeof rowNode === 'function' ? rowNode() : rowNode;
}

function updatePreparedRealizationContext(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  structuralOwnerPaths: StructuralOwnerIndex,
  preparedContext: PreparedRealizationContext,
  effect: ReversalEffect
): void {
  if (typeof effect.subjectId === 'number' && !effect.structural) {
    const descriptor = descriptors.get(effect.owner);
    const preparedSubject = preparedContext.resolveSubject(
      effect,
      effect.subjectId
    );
    const fieldPathFromRow = resolveSubjectFieldPath(
      descriptor,
      effect,
      getPositionRegistry(tree.$)
    );
    if (preparedSubject && fieldPathFromRow?.length === 0) {
      preparedSubject.value = effect.after;
    } else if (
      preparedSubject &&
      fieldPathFromRow &&
      effect.fieldPresence?.after === false
    ) {
      preparedSubject.value = withoutFieldAtSegments(
        preparedSubject.value,
        fieldPathFromRow
      );
    } else if (preparedSubject && fieldPathFromRow) {
      assignPreparedSubjectValue(
        preparedSubject.value,
        fieldPathFromRow,
        effect.after
      );
    }
    return;
  }

  if (typeof effect.subjectId !== 'number' || !effect.structural) {
    return;
  }

  const descriptor = descriptors.get(effect.owner);
  switch (effect.structural) {
    case 'add': {
      const collectionPath = resolveCollectionPath(
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionPath) {
        return;
      }
      const structuralEffect = getStructuralAddEffect(descriptor, effect);
      if (!structuralEffect) {
        return;
      }
      const preparedValue = deepClone(structuralEffect.value);
      preparedContext.rememberRestoredSubject(
        effect,
        effect.subjectId,
        collectionPath,
        effect.after as string | number,
        preparedValue
      );

      return;
    }
    case 'rekey': {
      if (realizationPlacement(effect) && !preparedContext.resolveSubject(effect, effect.subjectId)) {
        const collectionNode = resolveCollectionNode(tree, descriptor, structuralOwnerPaths, effect);
        const path = resolveCollectionPath(descriptor, structuralOwnerPaths, effect);
        if (collectionNode && path) preparedContext.rememberRestoredSubject(
          effect, effect.subjectId, path, effect.before as string | number,
          deepClone(snapshotCollectionEntityValue(collectionNode, effect.before as string | number))
        );
      }
      preparedContext.rememberRekeyedSubject(effect, effect.subjectId, effect.after as string | number);
      return;
    }
    case 'remove': {
      const collectionPath = resolveCollectionPath(
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionPath) {
        return;
      }

      const collectionNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionNode) {
        return;
      }

      const removeEffect = effect as ReversalEffect & {
        structural: 'remove';
        subjectId: number;
      };
      const effectiveRemoveKey = resolveEffectiveRemoveKey(
        collectionNode,
        preparedContext,
        removeEffect
      );
      if (effectiveRemoveKey === undefined) {
        return;
      }

      const liveValue = snapshotCollectionEntityValue(
        collectionNode,
        effectiveRemoveKey
      );
      if (liveValue === undefined) {
        return;
      }

      preparedContext.rememberRemovedSubject(
        effect,
        effect.subjectId,
        collectionPath,
        effectiveRemoveKey,
        liveValue
      );
      return;
    }
  }
}

function preparedSubjectScope(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  structuralOwnerPaths: StructuralOwnerIndex
): (effect: ReversalEffect) => object | undefined {
  return (effect) =>
    resolveCollectionNode(
      tree,
      descriptors.get(effect.owner),
      structuralOwnerPaths,
      effect
    );
}

function buildPreparedRealizationContext(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  structuralOwnerPaths: StructuralOwnerIndex,
  scalarSlotRuntime: ReturnType<typeof getTreeScalarSlotRuntime>,
  effects: readonly ReversalEffect[]
): PreparedRealizationContext | undefined {
  const preparedContext = new PreparedRealizationContext(
    preparedSubjectScope(tree, descriptors, structuralOwnerPaths)
  );
  for (const effect of effects) {
    if (
      !canApplyEffect(
        tree,
        descriptors,
        structuralOwnerPaths,
        scalarSlotRuntime,
        effect,
        preparedContext
      )
    ) {
      return undefined;
    }

    updatePreparedRealizationContext(
      tree,
      descriptors,
      structuralOwnerPaths,
      preparedContext,
      effect
    );
  }

  return preparedContext;
}

function resolveSubjectFieldPath(
  descriptor: TreeRealizationDescriptor | undefined,
  effect: ReversalEffect,
  registry: PositionRegistry | undefined
): readonly string[] | undefined {
  if (typeof effect.subjectId !== 'number') return undefined;
  if (effect.subjectFieldSegments !== undefined) {
    return effect.subjectFieldSegments;
  }
  const legacy =
    deriveFieldPathFromEffect(effect, registry) ??
    descriptor?.subjectDescriptors?.get(String(effect.subjectId))
      ?.fieldPathFromRow ??
    descriptor?.fieldPathFromRow;
  return legacy === undefined
    ? undefined
    : legacy === ''
    ? []
    : legacy.split('.');
}

function assignPreparedSubjectValue(
  subjectValue: unknown,
  fieldPathFromRow: readonly string[],
  nextValue: unknown
): void {
  if (fieldPathFromRow.length === 0) {
    return;
  }

  if (!isTraversableNode(subjectValue)) {
    return;
  }

  const segments = fieldPathFromRow;
  let cursor: unknown = subjectValue;
  for (const segment of segments.slice(0, -1)) {
    if (!isTraversableNode(cursor)) {
      return;
    }
    cursor = (cursor as Record<string, unknown>)[segment];
  }

  const leafKey = segments.at(-1);
  if (leafKey === undefined || !isTraversableNode(cursor)) {
    return;
  }

  (cursor as Record<string, unknown>)[leafKey] = nextValue;
}

function isPreparedSubjectScalarEffect(
  effect: ReversalEffect,
  preparedContext: PreparedRealizationContext
): boolean {
  return (
    typeof effect.subjectId === 'number' &&
    !effect.structural &&
    preparedContext.resolveSubject(effect, effect.subjectId) !== undefined
  );
}

/** Resolve visible point owners without visiting unrelated branches. Unsupported
 * addresses retain the incumbent traversal and its omission semantics. */
function indexPointOwnerPaths(
  root: unknown,
  effects: readonly ReversalEffect[]
): StructuralOwnerIndex {
  const registry = getPositionRegistry(root);
  const owners = Object.assign(new Map<PositionId, string>(), {
    nodes: new Map<PositionId, CollectionNode>(),
  });
  for (const effect of effects) {
    if (typeof effect.subjectId !== 'number' || owners.nodes.has(effect.owner))
      continue;
    const address = registry?.addressFor(effect.owner);
    if (!address || address.length > 32) return indexStructuralOwnerPaths(root);
    let node: unknown = root;
    for (const key of address) {
      if (
        !isTraversableNode(node) ||
        key === 'set' ||
        key === 'update' ||
        key.startsWith('_')
      ) {
        return indexStructuralOwnerPaths(root);
      }
      const property = Object.getOwnPropertyDescriptor(node, key);
      if (!property?.enumerable || !('value' in property))
        return indexStructuralOwnerPaths(root);
      node = property.value;
    }
    if (
      !isCollectionNode(node) ||
      getOwnedPositionIds(node)?.[0] !== effect.owner
    ) {
      return indexStructuralOwnerPaths(root);
    }
    const path = getOwnedOwnerPath(node);
    if (path === undefined) return indexStructuralOwnerPaths(root);
    owners.set(effect.owner, path);
    owners.nodes.set(effect.owner, node);
  }
  return owners;
}

function indexStructuralOwnerPaths(root: unknown): StructuralOwnerIndex {
  const ownerPaths = Object.assign(new Map<PositionId, string>(), {
    nodes: new Map<PositionId, CollectionNode>(),
  });

  visitTree(
    root,
    (node) => {
      if (!isCollectionNode(node)) {
        return undefined;
      }

      const positionId = getOwnedPositionIds(node)?.[0] as
        | PositionId
        | undefined;
      const ownerPath = getOwnedOwnerPath(node);
      if (positionId === undefined || ownerPath === undefined) {
        return undefined;
      }

      // Preserve the exact collection alongside its diagnostic address. This
      // index owns no entity values or retired row references.
      ownerPaths.set(positionId, ownerPath);
      ownerPaths.nodes.set(positionId, node);
      return undefined;
    },
    {
      skipKey: (key) =>
        key === 'set' || key === 'update' || key.startsWith('_'),
    }
  );

  return ownerPaths;
}

function resolveCurrentSubjectTarget(
  tree: ISignalTree<object>,
  descriptor: TreeRealizationDescriptor | undefined,
  subjectId: number,
  effect: ReversalEffect,
  structuralOwnerPaths: StructuralOwnerIndex
): unknown {
  if (effect.subjectFieldSegments !== undefined) {
    const collection = structuralOwnerPaths.nodes.get(effect.owner);
    const key = collection?.__findKeyBySubjectId?.(subjectId);
    if (!collection || key === undefined) return undefined;
    const row = collection.byIdOrFail(key);
    return resolveStructuredSubjectTarget(row, effect.subjectFieldSegments);
  }
  const registry = getPositionRegistry(tree.$);
  const inlineCollectionPath = deriveCollectionPathFromEffect(effect, registry);
  const inlineFieldPathFromRow = deriveFieldPathFromEffect(effect, registry);
  const subjectDescriptor = descriptor?.subjectDescriptors?.get(
    String(subjectId)
  );
  const collectionPath =
    inlineCollectionPath ??
    subjectDescriptor?.collectionPath ??
    descriptor?.collectionPath ??
    (effect.structural ? descriptor?.ownerPath : undefined);
  if (!collectionPath && collectionPath !== '') {
    return undefined;
  }
  const collectionNode = resolveNodeAtPath(
    tree.$ as Record<string, unknown>,
    collectionPath
  );
  if (!isCollectionNode(collectionNode)) {
    return undefined;
  }

  const currentKey = collectionNode.__findKeyBySubjectId?.(subjectId);
  if (currentKey === undefined) {
    return undefined;
  }

  const rowNode = collectionNode.byIdOrFail(currentKey);
  const fieldPathFromRow =
    inlineFieldPathFromRow ??
    subjectDescriptor?.fieldPathFromRow ??
    descriptor?.fieldPathFromRow;

  if (fieldPathFromRow === '') {
    return rowNode;
  }

  if (!fieldPathFromRow) {
    return undefined;
  }

  return resolveNodeAtPath(
    rowNode as Record<string, unknown>,
    fieldPathFromRow
  );
}

function resolveNotifyPath(
  tree: ISignalTree<object>,
  descriptor: TreeRealizationDescriptor | undefined,
  structuralOwnerPaths: StructuralOwnerIndex,
  effect: ReversalEffect
): string | undefined {
  if (hasInlineScopedAddress(effect)) {
    return effect.path;
  }

  if (typeof effect.subjectId !== 'number') {
    // A settlement can forget a scalar descriptor that restoration history
    // still needs; the effect's own path is the same location.
    return descriptor?.path ?? effect.path;
  }

  if (effect.subjectFieldSegments !== undefined) {
    const collection = structuralOwnerPaths.nodes.get(effect.owner);
    const key = collection?.__findKeyBySubjectId?.(effect.subjectId);
    const path = structuralOwnerPaths.get(effect.owner);
    if (key === undefined || path === undefined) return undefined;
    return [path, String(key), ...effect.subjectFieldSegments].join('.');
  }
  const registry = getPositionRegistry(tree.$);
  const inlineCollectionPath = deriveCollectionPathFromEffect(effect, registry);
  const inlineFieldPathFromRow = deriveFieldPathFromEffect(effect, registry);
  const collectionPath =
    inlineCollectionPath ??
    descriptor?.subjectDescriptors?.get(String(effect.subjectId))
      ?.collectionPath ??
    descriptor?.collectionPath ??
    structuralOwnerPaths.get(effect.owner);
  if (collectionPath === undefined) {
    return descriptor?.path;
  }

  const collectionNode = resolveNodeAtPath(
    tree.$ as Record<string, unknown>,
    collectionPath
  );
  if (!isCollectionNode(collectionNode)) {
    return descriptor?.path;
  }

  const currentKey = collectionNode.__findKeyBySubjectId?.(effect.subjectId);
  if (currentKey === undefined) {
    return descriptor?.path;
  }

  const fieldPathFromRow =
    inlineFieldPathFromRow ??
    descriptor?.subjectDescriptors?.get(String(effect.subjectId))
      ?.fieldPathFromRow ??
    descriptor?.fieldPathFromRow;
  const rowPath = `${collectionPath}.${String(currentKey)}`;

  if (fieldPathFromRow === '') {
    return rowPath;
  }

  return fieldPathFromRow ? `${rowPath}.${fieldPathFromRow}` : descriptor?.path;
}

function hasInlineSubjectAddress(
  effect: ReversalEffect
): effect is InlineSubjectAddressEffect {
  return (
    typeof effect.subjectId === 'number' &&
    typeof effect.path === 'string' &&
    typeof effect.ownerPath === 'string'
  );
}

function hasInlineScopedAddress(
  effect: ReversalEffect
): effect is ReversalEffect & { path: string; ownerPath: string } {
  return (
    typeof effect.path === 'string' &&
    typeof effect.ownerPath === 'string' &&
    effect.path !== effect.ownerPath
  );
}

/**
 * ⚠️ THE INLINE PATH IS THE ONE THAT MATTERED.
 *
 * SUBJECT-ADDRESS-CARDINALITY-0 measured that these two win over every
 * descriptor fallback — `descField=""` sat unused while `inlineField` supplied
 * the answer on every resolution. So the nested rollback defect lived HERE, not
 * in descriptor capture or its merge policy, and the registry has to be
 * reachable from this call site or the repair does nothing.
 */
function deriveCollectionPathFromEffect(
  effect: ReversalEffect,
  registry: PositionRegistry | undefined
): string | undefined {
  if (!hasInlineSubjectAddress(effect)) {
    return undefined;
  }

  return deriveRealizationAddress(
    effect.path,
    effect.ownerPath,
    effect.subjectId as number,
    undefined,
    registry?.collectionPathFor(effect.owner)
  ).collectionPath;
}

/** Literal property keys supplied by capture; diagnostic paths are not identities. */
export function deriveFieldSegmentsFromEffect(
  effect: ReversalEffect,
  registry: PositionRegistry | undefined
): readonly string[] | undefined {
  if (effect.subjectFieldSegments !== undefined) {
    return effect.subjectFieldSegments;
  }
  const legacy = deriveFieldPathFromEffect(effect, registry);
  return legacy === undefined
    ? undefined
    : legacy === ''
    ? []
    : legacy.split('.');
}

export function deriveFieldPathFromEffect(
  effect: ReversalEffect,
  registry: PositionRegistry | undefined
): string | undefined {
  if (!hasInlineSubjectAddress(effect)) {
    return undefined;
  }

  return deriveRealizationAddress(
    effect.path,
    effect.ownerPath,
    effect.subjectId as number,
    undefined,
    registry?.collectionPathFor(effect.owner)
  ).fieldPathFromRow;
}

function resolveCurrentScopedTarget(
  tree: ISignalTree<object>,
  descriptor: TreeRealizationDescriptor | undefined,
  effect: ReversalEffect & { path: string; ownerPath: string }
): unknown {
  const scopePath = effect.ownerPath ?? descriptor?.ownerPath;
  if (!scopePath) {
    return undefined;
  }

  const scopeNode = resolveNodeAtPath(
    tree.$ as Record<string, unknown>,
    scopePath
  );
  if (scopeNode === undefined) {
    return undefined;
  }

  const relativePath = effect.path.startsWith(`${scopePath}.`)
    ? effect.path.slice(scopePath.length + 1)
    : '';
  const normalizedRelativePath = normalizeScopedValuePath(relativePath);

  if (normalizedRelativePath === '') {
    return scopeNode;
  }

  const scopedFieldTree =
    scopeNode && typeof scopeNode === 'function' && '$' in (scopeNode as object)
      ? (scopeNode as { $?: unknown }).$
      : undefined;

  if (isTraversableNode(scopedFieldTree)) {
    const scopedTarget = resolveNodeAtPath(
      scopedFieldTree as Record<string, unknown>,
      normalizedRelativePath
    );
    if (isWritableLeaf(scopedTarget) || isWritableEntityNode(scopedTarget)) {
      return scopedTarget;
    }
  }

  if (!isTraversableNode(scopeNode)) {
    return undefined;
  }

  return resolveNodeAtPath(
    scopeNode as Record<string, unknown>,
    normalizedRelativePath
  );
}

/** A copy of `value` without the field at `segments`; other keys untouched. */
function withoutFieldAtSegments(
  value: unknown,
  segments: readonly string[]
): unknown {
  if (segments.length === 0 || !isTraversableNode(value)) return value;
  const [head, ...tail] = segments;
  const record = value as Record<string, unknown>;
  if (!Object.prototype.hasOwnProperty.call(record, head)) return value;
  if (tail.length === 0) {
    const { [head]: _removed, ...rest } = record;
    return rest;
  }
  return { ...record, [head]: withoutFieldAtSegments(record[head], tail) };
}

function resolveNodeAtSegments(
  root: unknown,
  segments: readonly string[]
): unknown {
  let cursor = root;
  for (const segment of segments) {
    if (cursor === null || cursor === undefined) return undefined;
    cursor = (cursor as Record<string, unknown>)[segment];
  }
  return cursor;
}

function resolveStructuredSubjectTarget(
  row: unknown,
  segments: readonly string[]
): unknown {
  if (segments.length === 0) return row;
  const direct = resolveNodeAtSegments(row, segments);
  if (isWritableLeaf(direct) || isWritableEntityNode(direct)) return direct;
  if (!isWritableEntityNode(row)) return undefined;
  const read = row as unknown as () => unknown;
  const parent = resolveNodeAtSegments(read(), segments.slice(0, -1));
  if (!isTraversableNode(parent)) return undefined;
  // Entity fields can be opaque object leaves. Realize a nested value through
  // the owned row's replacement operation rather than inventing a native leaf.
  return (value: unknown) =>
    row(replaceValueAtSegments(read(), segments, value));
}

function replaceValueAtSegments(
  value: unknown,
  segments: readonly string[],
  next: unknown
): unknown {
  if (segments.length === 0) return next;
  const [key, ...rest] = segments;
  const record = isTraversableNode(value)
    ? (value as Record<string, unknown>)
    : {};
  return { ...record, [key]: replaceValueAtSegments(record[key], rest, next) };
}

function resolveNodeAtPath(
  root: Record<string, unknown>,
  path: string
): unknown {
  if (path === '') {
    return root;
  }

  let cursor: unknown = root;
  for (const segment of path.split('.')) {
    if (cursor === null || cursor === undefined) {
      return undefined;
    }
    cursor = (cursor as Record<string, unknown>)[segment];
  }

  return cursor;
}

const rowScope = (owner: unknown, subject: unknown): string =>
  `${String(owner)}\u0000${String(subject)}`;

/** The same placement order is used by validation and installation planning. */
function orderPhysicalPlacements(
  tree: ISignalTree<object>,
  descriptors: ReadonlyMap<PositionId, TreeRealizationDescriptor>,
  ownerPaths: StructuralOwnerIndex,
  effects: readonly ReversalEffect[]
): readonly ReversalEffect[] {
  const placements = effects.filter((effect): effect is ReversalEffect & {subjectId: number} =>
    typeof effect.subjectId === 'number' && (effect.structural === 'add' || realizationPlacement(effect) !== undefined));
  if (placements.length < 2) return effects;
  const removed = new Set(effects.filter((effect) => effect.structural === 'remove').map((effect) => rowScope(effect.owner, effect.subjectId)));
  const nodes = new Map<PositionId, CollectionNode | undefined>();
  const ordered = orderRestoresForPlacement(placements,
    (effect) => getStructuralAddEffect(descriptors.get(effect.owner), realizationPlacement(effect) ?? effect),
    (effect, subject) => {
      if (removed.has(rowScope(effect.owner, subject))) return false;
      if (!nodes.has(effect.owner)) nodes.set(effect.owner, resolveCollectionNode(tree, descriptors.get(effect.owner), ownerPaths, effect));
      return nodes.get(effect.owner)?.__findKeyBySubjectId?.(subject) !== undefined;
    });
  const placementSet = new Set<ReversalEffect>(placements);
  let next = 0;
  return effects.map((effect) => placementSet.has(effect) ? ordered[next++] : effect);
}

/**
 * Orders a frame's restores so each one, when it commits, finds its recorded
 * neighbours live. Restores commit in sequence and each resolves its anchors
 * against the rows live at that moment, so the order decides the placement.
 * Capture order cannot be used: the notifier delivers a row's removal in the
 * slot of that row's EARLIER write, so `updateOne('a'); clear()` reversed
 * restored [a, c, z].
 *
 * Next is, in order of preference: a restore whose restored anchors are all
 * placed and that has a live anchor (or no live-able anchor at all); one with
 * at least one live anchor while another is still waiting; else the head of a
 * chain with nothing live (one whose predecessor is not waiting). An anchor
 * that is a surviving row, or a restore already placed, is live. The tiers
 * matter both ways: `updateOne c; removeOne a; removeOne c` anchors a to c (c
 * was there when a went), so c goes first; `removeMany([z, a])` beside a
 * surviving c anchors z and a to each other, so a goes first, against c.
 */
function orderRestoresForPlacement<
  T extends ReversalEffect & { subjectId: number }
>(
  restores: readonly T[],
  anchorsOf: (
    effect: T
  ) => { beforeSubject?: number; afterSubject?: number } | undefined,
  isLive: (effect: T, subject: number) => boolean
): T[] {
  if (restores.length < 2) return [...restores];
  const pending = new Map<string, T>();
  for (const effect of restores) {
    pending.set(rowScope(effect.owner, effect.subjectId), effect);
  }
  const waiting = new Map<T, number>();
  const hasLiveAnchor = new Set<T>();
  const dependents = new Map<string, T[]>();
  const full: T[] = [];
  const partial: T[] = [];
  for (const effect of restores) {
    const anchors = anchorsOf(effect);
    let count = 0;
    for (const subject of [anchors?.beforeSubject, anchors?.afterSubject]) {
      if (subject === undefined) continue;
      const key = rowScope(effect.owner, subject);
      if (pending.has(key)) {
        count += 1;
        const list = dependents.get(key);
        if (list) list.push(effect);
        else dependents.set(key, [effect]);
      } else if (isLive(effect, subject)) {
        hasLiveAnchor.add(effect);
      }
    }
    waiting.set(effect, count);
    if (count === 0) full.push(effect);
    else if (hasLiveAnchor.has(effect)) partial.push(effect);
  }
  const placed = new Set<T>();
  const ordered: T[] = [];
  let fullHead = 0;
  let partialHead = 0;
  const isWaitingOn = (effect: T, subject: number | undefined): boolean => {
    if (subject === undefined) return false;
    const anchor = pending.get(rowScope(effect.owner, subject));
    return anchor !== undefined && !placed.has(anchor);
  };
  while (ordered.length < restores.length) {
    while (fullHead < full.length && placed.has(full[fullHead])) fullHead += 1;
    while (partialHead < partial.length && placed.has(partial[partialHead])) {
      partialHead += 1;
    }
    const next =
      fullHead < full.length
        ? full[fullHead++]
        : partialHead < partial.length
        ? partial[partialHead++]
        : restores.find(
            (effect) =>
              !placed.has(effect) &&
              !isWaitingOn(effect, anchorsOf(effect)?.beforeSubject)
          ) ?? (restores.find((effect) => !placed.has(effect)) as T);
    placed.add(next);
    ordered.push(next);
    for (const dependent of dependents.get(
      rowScope(next.owner, next.subjectId)
    ) ?? []) {
      if (placed.has(dependent)) continue;
      const left = (waiting.get(dependent) ?? 1) - 1;
      waiting.set(dependent, left);
      hasLiveAnchor.add(dependent);
      if (left === 0) full.push(dependent);
      else partial.push(dependent);
    }
  }
  return ordered;
}

function getStructuralAddEffect(
  descriptor: TreeRealizationDescriptor | undefined,
  effect: ReversalEffect
): Extract<StructuralEffect, { kind: 'add' | 'remove' }> | undefined {
  if (effect.structural !== 'add' || typeof effect.subjectId !== 'number') {
    return undefined;
  }

  if (isStructuralEffect(effect.structuralContext)) {
    return effect.structuralContext.kind === 'remove' ||
      effect.structuralContext.kind === 'add'
      ? effect.structuralContext
      : undefined;
  }

  const removeEffect = descriptor?.structuralEffects?.get(
    `remove:${String(effect.subjectId)}:${String(effect.after)}`
  );
  if (removeEffect?.kind === 'remove') {
    return removeEffect;
  }

  const subjectEffect = descriptor?.structuralEffectBySubject?.get(
    String(effect.subjectId)
  );
  if (subjectEffect?.kind === 'remove' || subjectEffect?.kind === 'add') {
    return subjectEffect;
  }

  const addEffect = descriptor?.structuralEffects?.get(
    `add:${String(effect.subjectId)}:${String(effect.after)}`
  );
  return addEffect?.kind === 'add' ? addEffect : undefined;
}

/**
 * ADDRESS-REPAIR-1 — the explicit subject address.
 *
 * ```text
 * undefined            this effect establishes NO subject address
 * { kind: 'whole' }    it targets the entire current subject
 * { kind: 'field' }    it targets a coordinate within the current subject
 * ```
 *
 * ⚠️ Absence is a SEPARATE VALUE, not a falsy string. The previous encoding was
 * `undefined | '' | string`, and DESCRIPTOR-ROLE-0 measured two consumers
 * disagreeing about `''` — one read it as "no path", the other as "the whole
 * subject". Those are different answers to the same question, and the collision
 * is what let an owner-only ping claim a whole-subject address.
 *
 * ⚠️ `whole` exists at THIS layer only. REAL-WHOLE-EFFECT-0 captured every
 * `ReversalEffect` reaching realization and found none that needs it — every
 * whole-entity operation decomposes into per-field effects. So `whole` is
 * produced by row-level NOTIFICATION capture and must not be carried into
 * `ReversalEffect` itself.
 */
type SubjectAddress =
  | { readonly kind: 'whole' }
  | { readonly kind: 'field'; readonly path: string };

const WHOLE_SUBJECT: SubjectAddress = { kind: 'whole' };

/**
 * The single canonical derivation, replacing `deriveCollectionPath` and
 * `deriveFieldPathFromRow` as independent guesses.
 *
 * `canonicalCollectionPath` comes from `PositionRegistry.collectionPathFor()` —
 * the owner position's REGISTERED address — so the collection is never inferred
 * from a string. Given it, the subject coordinate is pure segment arithmetic:
 *
 * ```text
 * path === collection            owner-only notification   -> NO address
 * collection + 1 segment         the row itself            -> whole
 * collection + 2+ segments       a field within the row    -> field(rest)
 * ```
 *
 * ⚠️ The first line is the fix for the owner ping. The old code returned `''`
 * on `path === ownerPath` BEFORE it ever examined `subjectId`, so a value-less
 * collection notification carrying no subject still manufactured the strongest
 * address in the model. Here that case simply has no address to give.
 *
 * ⚠️ The entity-key segment is CONSUMED as event addressing and never becomes a
 * durable coordinate. That is the nested defect that produced `FIELD="seed"` —
 * the key returned as a field name — and it is now impossible rather than
 * avoided, because the key's position in the path is known rather than guessed.
 */
function deriveSubjectAddress(
  path: string,
  subjectId: number | undefined,
  structuralEffect: StructuralEffect | undefined,
  canonicalCollectionPath: string
): SubjectAddress | undefined {
  // Structural effects address existence and membership, never scalar state.
  // `structuralContext` carries add / remove / rekey.
  if (structuralEffect) {
    return undefined;
  }

  if (path === canonicalCollectionPath) {
    return undefined;
  }

  const prefix = `${canonicalCollectionPath}.`;
  if (!path.startsWith(prefix)) {
    return undefined;
  }

  const relative = path.slice(prefix.length);
  const firstDot = relative.indexOf('.');

  // `collection.<key>` — the row itself.
  if (firstDot === -1) {
    return typeof subjectId === 'number' ? WHOLE_SUBJECT : undefined;
  }

  // `collection.<key>.<rest>` — a coordinate inside the row.
  const fieldPath = relative.slice(firstDot + 1);
  return fieldPath === '' ? undefined : { kind: 'field', path: fieldPath };
}

/**
 * The storage encoding, isolated to one place.
 *
 * `TreeRealizationDescriptor` and the inline resolution chain still speak
 * `string | undefined` with `''` meaning whole. That wire format is unchanged by
 * ADDRESS-REPAIR-1 — only the DERIVATION is corrected — so the ambiguity is now
 * confined to storage rather than being the semantics.
 *
 * ⚠️ It is a real remaining wart. `''` is still falsy at
 * `canResolvePreparedSubjectTarget` and whole-subject at
 * `assignPreparedSubjectValue`. Migrating the stored shape is deliberately NOT
 * part of a correctness fix; it is safe now only because the derivation above no
 * longer produces `''` for anything that means "no address".
 */
function encodeSubjectAddress(
  address: SubjectAddress | undefined
): string | undefined {
  if (!address) return undefined;
  return address.kind === 'whole' ? '' : address.path;
}

/**
 * ⚠️ LEGACY FALLBACK — used only when the owner position has NO registered
 * canonical collection.
 *
 * That happens for synthetic descriptors built directly by the adapter tests,
 * whose `ownerPath` names a ROW (`data.users.u1`) rather than a collection.
 * REALIZATION-TARGET-ROLE-1 measured that both shapes are legitimate for the
 * same owner position and that no string test separates them — which is exactly
 * why the registry answers instead. Those cases never materialized an entityMap,
 * so they have nothing registered and keep their existing interpretation by
 * construction rather than by a special case.
 */
function deriveCollectionPathLegacy(
  path: string,
  ownerPath: string,
  subjectId: number | undefined,
  structuralEffect: StructuralEffect | undefined
): string | undefined {
  if (structuralEffect) return ownerPath;
  if (path === ownerPath) {
    return ownerPath.includes('.') ? parentPath(ownerPath) : undefined;
  }
  if (!path.startsWith(`${ownerPath}.`)) return undefined;
  if (!ownerPath.includes('.')) return ownerPath;
  if (typeof subjectId !== 'number') return undefined;
  return parentPath(ownerPath);
}

function deriveFieldPathFromRowLegacy(
  path: string,
  ownerPath: string,
  subjectId: number | undefined,
  structuralEffect: StructuralEffect | undefined
): string | undefined {
  if (structuralEffect) {
    return undefined;
  }

  if (path === ownerPath) {
    return '';
  }

  if (typeof subjectId !== 'number' || !path.startsWith(`${ownerPath}.`)) {
    return undefined;
  }

  const relativePath = path.slice(ownerPath.length + 1);
  if (!ownerPath.includes('.')) {
    const firstDot = relativePath.indexOf('.');
    return firstDot === -1 ? '' : relativePath.slice(firstDot + 1);
  }

  return relativePath;
}

/**
 * The one entry point. Registry first; legacy only when the owner is not a
 * registered collection.
 */
function deriveRealizationAddress(
  path: string,
  ownerPath: string,
  subjectId: number | undefined,
  structuralEffect: StructuralEffect | undefined,
  canonicalCollectionPath: string | undefined
): {
  collectionPath: string | undefined;
  fieldPathFromRow: string | undefined;
} {
  if (canonicalCollectionPath !== undefined) {
    return {
      collectionPath: canonicalCollectionPath,
      fieldPathFromRow: encodeSubjectAddress(
        deriveSubjectAddress(
          path,
          subjectId,
          structuralEffect,
          canonicalCollectionPath
        )
      ),
    };
  }

  return {
    collectionPath: deriveCollectionPathLegacy(
      path,
      ownerPath,
      subjectId,
      structuralEffect
    ),
    fieldPathFromRow: deriveFieldPathFromRowLegacy(
      path,
      ownerPath,
      subjectId,
      structuralEffect
    ),
  };
}

function parentPath(path: string): string {
  const lastDot = path.lastIndexOf('.');
  return lastDot === -1 ? '' : path.slice(0, lastDot);
}

/**
 * Drop every realization record belonging to subjects that can no longer be
 * restored.
 *
 * ## Why these are subject-lifetime state, not history state
 *
 * `structuralEffects`, `structuralEffectBySubject` and
 * `subjectDescriptors` are read on exactly one path — reversal planning — and
 * every read is keyed by subject id:
 *
 *   structuralEffects     `${kind}:${subject}:${key}`, read by
 *                                `resolveStructuralEffect`
 *   structuralEffectBySubject   `String(subject)`, same reader
 *   subjectDescriptors           `String(subject)`, read for `collectionPath`
 *                                and `fieldPathFromRow`
 *
 * So an entry is needed for exactly as long as its subject is restorable, which
 * is exactly as long as something claims it. Nothing pruned them: they were
 * bounded by neither `maxHistorySize` nor reclamation, and grew four entries per
 * retired subject — 256,600 at 64,000 retirements — which was the whole
 * remaining slope after the entity layer plateaued. See
 * docs/architecture/retired-subject-churn.md, "STEP 8 PHASE 6D".
 *
 * ## Why a scan rather than a subject index
 *
 * The effect keys are prefixed by subject, so a `subject -> keys` index would
 * make this O(1) per subject. It would also be a second structure that can
 * drift out of step with the first, for a pass over a map that pruning itself
 * keeps bounded at a few entries per live row plus one window. The scan is the
 * cheaper thing to be sure about.
 *
 * The CALLER must have established that these subjects are unclaimed. This
 * function does not re-check — it is the destructive half of a decision made
 * against the claim registry.
 */
export function forgetSubjectsInTreeRealizationDescriptors(
  descriptors: Map<PositionId, TreeRealizationDescriptor>,
  subjectIds: readonly number[]
): void {
  if (subjectIds.length === 0 || descriptors.size === 0) {
    return;
  }
  const forgotten = new Set(subjectIds.map((id) => String(id)));

  for (const descriptor of descriptors.values()) {
    const bySubject = descriptor.structuralEffectBySubject;
    if (bySubject instanceof Map) {
      for (const key of forgotten) {
        bySubject.delete(key);
      }
    }

    const subjectDescriptors = descriptor.subjectDescriptors;
    if (subjectDescriptors instanceof Map) {
      for (const key of forgotten) {
        subjectDescriptors.delete(key);
      }
    }

    const effects = descriptor.structuralEffects;
    if (effects instanceof Map) {
      for (const key of [...effects.keys()]) {
        // `${kind}:${subject}:...` — the subject is always the second segment.
        const firstColon = key.indexOf(':');
        if (firstColon === -1) {
          continue;
        }
        const secondColon = key.indexOf(':', firstColon + 1);
        const subject = key.slice(
          firstColon + 1,
          secondColon === -1 ? undefined : secondColon
        );
        if (forgotten.has(subject)) {
          effects.delete(key);
        }
      }
    }
  }
}

function toStructuralEffectKey(effect: StructuralEffect): string {
  switch (effect.kind) {
    case 'add':
    case 'remove':
      return `${effect.kind}:${String(effect.subject)}:${String(effect.key)}`;
    case 'rekey':
      return `rekey:${String(effect.subject)}:${String(
        effect.beforeKey
      )}:${String(effect.afterKey)}`;
  }
}

function isWritableLeaf(value: unknown): value is WritableLeaf {
  return Boolean(
    value &&
      typeof value === 'function' &&
      'set' in (value as object) &&
      typeof (value as { set?: unknown }).set === 'function'
  );
}

function isWritableEntityNode(value: unknown): value is WritableEntityNode {
  return Boolean(
    value && typeof value === 'function' && !('set' in (value as object))
  );
}

function isStructuralEffect(value: unknown): value is StructuralEffect {
  return Boolean(
    value &&
      typeof value === 'object' &&
      'kind' in (value as object) &&
      ((value as StructuralEffect).kind === 'add' ||
        (value as StructuralEffect).kind === 'remove' ||
        (value as StructuralEffect).kind === 'rekey')
  );
}

function isCollectionNode(value: unknown): value is CollectionNode {
  return Boolean(
    value &&
      'byIdOrFail' in (value as object) &&
      'changeId' in (value as object) &&
      'removeOne' in (value as object)
  );
}

function hasCollectionKey(node: CollectionNode, key: string | number): boolean {
  try {
    node.byIdOrFail(key);
    return true;
  } catch {
    return false;
  }
}
