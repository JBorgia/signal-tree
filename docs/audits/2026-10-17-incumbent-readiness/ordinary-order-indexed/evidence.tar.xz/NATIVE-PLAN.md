# Conditional bounded native experiment plan

Read-only planning October24. Native work conditional on indexed-model independent review; no runtime modifications here. Use source manifest d1ff7c33a380d578390879a79e142950d0655920710a818af7d49fe2a017521b as control. Preserve source, original four failures and physicalCAB behavior. Production/slice1/later-slice gates unchanged.

## Exact internal change boundary

1. Extend lib/physical/entity-ordinary-topology.ts into the single source-owned ordinary occupancy/placement owner. Preserve stable lifetime identities; do not duplicate payload ownership from EntityValueStore. Introduce explicit ordinary head/tail and certified physical-base adjacency fallback with indexed exceptional edges. A missing override means agreement only when maintenance proves it. Admission prepares immutable patches; no live map mutation during preparation.
2. lib/entity-signal.ts prepareOrdinaryTopology/read and prepareOrdinaryRealization must read O neighbors from that owner, never getNeighborSubjects under key-equality fallback. Field/rekey stays placement-neutral except approved explicit necessary existence. Source owner stages ordinary splice/insert/full-order intent separately from P patch.
3. physical/entity-mutation-frame.ts must receive complete planned P adjacency footprint and prepared owner installation; create/tombstone/restore/transfer+placement operate through that shared plan. Preserve old reciprocal neighbors/head/tail before changing physical base. Direct createSubject1532 path must either prove existing-key identity-only use or join prepared installation if it can install.
4. addManyInOrder/addOneWithStructuralEffect must prepare final append/prepend placement before frame responsibility is installed. Remove delayed moveToFront as a second unaccounted installation; preserve established callback timing and no new notifications. Existing frame-to-source capture metadata carries final ordinary placement; do not patch history or physical metadata afterward.
5. setAll must prepare complete P target and ordinary authored intent before frame installation/reorder. Inspection full reorder preserves all ordinary answers whose base links change; own no-order-capture membership changes must not adopt inspected survivor ordering. Explicit full reorder may enumerate supplied members. Preserve final physicalCAB in compound witness while O restoresABC.
6. physical/prepare-entity-target.ts target installation and entity-signal private realization adapters must install prepared owner disposition in same callback-free unit. Source authority still selects inverse; owner never changes conflict classification. Frontier restoration is proof metadata, not a second order authority.
7. Retirement forget/retire and tree disposal must release obligation-free owner exceptions and indexes while protecting ordinary-present physically-absent lifetimes and recovery claims. Do not infer eligibility from pending count alone. No consumer-global Link or history callback becomes an owner dependency.

## S1–S6 containment

S1 direct point value installs remain physically placement-neutral; preparePointValues verifies existing subject/key and needs no adjacency edit. commitExistingSubjectValue can need ordinary existence insertion and must use owner for that intent.
S2 frame/direct prepend/direct setAll are the main migration. S3/S5 point inverse/revival use owner facts and existing placement policy. S4 full target needs only owner integration at existing prepared installation seam, not a redesign of target semantics. S6 owner metadata retirement follows existing obligation checks. W9 hidden re-add wrappers must route retained clear/new rows through these same seams; no new parent membership policy.

A bounded experiment can be internally complete if these existing installation seams accept owner patches without changing consumer protocols. It cannot claim all slice3 hidden/restoration behavior qualified; those remain later audit. If the footprint cannot be produced without a new public adapter API, new authored-order semantics, rewritten authority selection, or independently writable canonical mirror, stop and present that exact expansion. Do not accommodate it through exceptions in Link/history or blanket capture guards.

## Focused execution gates after conditional implementation

Use Node24.15.0/pnpm10.17.0, Nx only; fresh isolated candidate with recorded pre/post package manifests. Initial reds must execute unchanged against control before edits:

    COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false corepack pnpm exec nx test kernel --testFile=src/lib/prepend-publication-boundary.spec.ts --testFile=src/enhancers/transactions/native-compound-ordinary-order-regression.spec.ts --skip-nx-cache

These are three prepend failures plus one ordinary-only compound leak. Keep original new physicalABC assertion as separate premise evidence, not substitute for ordinary-only test. Preserve all first failing logs and exact source identities.

Then run exact archived argument vectors from combined-qualified-command.json (239-source controls) and order-policy/qualified-command.json (251-era qualified controls) via their manifest-checking runner, retargeted only to isolated candidate. Inspect vectors first and avoid double-counting overlapping tests; run the union once if an auditable vector records deduplication. Include new indexed-owner controls (model/adapter parity, construction empty/populated, per-operation footprint/work counts, ordinary/inspection convergence, same-key replacement, held lifetimes, order-only inspection and final prepend nestedflush).

Specific fault gates: failed owner preparation installs no maps or P state; reentry invalidates whole stale plan; installed observer throw retains useful abort/recovery; occupied destination or order-policy refusal changes neither domain nor authority. Retained receipts must not become owner roots after terminal drain. Test point operations at increasing sizes with fixed mutation count; count P footprint visits, owner probes/edits and retained exceptions, not just collection active-key scans.

Run configured typecheck/spec-types and changed runtime lint after combined focused pass, then independently review frozen source/diff. No full kernel/framework, fresh artifacts or cost campaign until this bounded successor and slice2 gate are adjudicated. No activation/API/budget changes.
