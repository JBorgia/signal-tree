import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions,link} from '/private/tmp/ordinary-order-indexed/native/packages/kernel/src/index';
import {withWriteContext} from '/private/tmp/ordinary-order-indexed/native/packages/kernel/src/lib/write-context';
import {getMutationCaptureRuntime} from '/private/tmp/ordinary-order-indexed/native/packages/kernel/src/lib/internals/mutation-capture-runtime';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});const r=t.$.rows,sent:unknown[]=[];
let connection:ReturnType<typeof link>|undefined;
const off=getMutationCaptureRuntime(t)!.subscribeCollectionOrder!(c=>console.log('ORDER',JSON.stringify(c)));
try{r.setAll([{id:'a',n:1},{id:'b',n:2},{id:'c',n:3}]);await tick();connection=link(r,{set:v=>{sent.push(structuredClone(v));}});const order=(ids:string)=>r.setAll([...ids].map(id=>r.byIdOrFail(id)()));withWriteContext({participation:'inspection'},()=>order('cba'));await tick();await connection.settled();assert.equal(sent.length,0);
const p=t.transact(()=>order('acb'));await tick();console.log('PENDING',JSON.stringify({P:r.all(),inspect:p.inspect(),sent}));p.rollback();await tick();await connection.settled();console.log('REJECTED',JSON.stringify({P:r.all(),inspect:p.inspect(),sent}));r.updateOne('b',{n:4});await tick();await connection.settled();console.log('LATER',JSON.stringify({P:r.all(),sent}));assert.deepEqual(sent.at(-1),[{id:'a',n:1},{id:'b',n:4},{id:'c',n:3}]);assert.deepEqual(sent.at(-2),[{id:'a',n:1},{id:'b',n:2},{id:'c',n:3}]);}finally{off();connection?.dispose();t.destroy();}
