const fs=require('fs'),esbuild=require('/private/tmp/ordinary-order-indexed/native/node_modules/esbuild');const root='/private/tmp/ordinary-order-indexed/execution-sixth/trace/';
esbuild.buildSync({entryPoints:[root+'probe.ts'],bundle:true,platform:'node',format:'esm',outfile:root+'instrumented.mjs',plugins:[]});
