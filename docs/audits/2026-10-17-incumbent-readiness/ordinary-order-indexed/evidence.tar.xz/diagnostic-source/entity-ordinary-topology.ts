import { EntityPlacementStage, type EntityPlacement } from './entity-placement-stage';
import type { StructuralEffect } from '../mutation-types';

export type OrdinaryEntityPresence<K extends string | number, E> =
  | { readonly present: false }
  | { readonly present: true; readonly key: K; readonly value: E;
      readonly beforeSubject?: number; readonly afterSubject?: number };

/** Only membership/key divergence is retained, never an ordinary collection copy. */
export class EntityOrdinaryTopology<K extends string | number, E> {
  private headOverride: {value:number|undefined}|undefined;
  private tailOverride: {value:number|undefined}|undefined;
  private readonly divergent = new Map<number, OrdinaryEntityPresence<K,E>>();
  private readonly displaced = new Map<K,number>();
  preparePlacement(physical:EntityPlacementStage<K>):EntityPlacementStage<K>{
    return new EntityPlacementStage(subject=>this.divergent.get(subject)??physical.base(subject),this.headOverride?this.headOverride.value:physical.head,this.tailOverride?this.tailOverride.value:physical.tail);
  }
  prepareInstall(ordinary:EntityPlacementStage<K>, physical:EntityPlacementStage<K>, value:(subject:number)=>E):()=>void {
    const updates=new Map<number,OrdinaryEntityPresence<K,E>|undefined>();
    const ids=new Set([...ordinary.patch.keys(),...physical.patch.keys()]);
    for(const subject of ids){const o=ordinary.read(subject),p=physical.read(subject);
      const same=o.present===p.present&&(!o.present||p.present&&o.key===p.key&&o.beforeSubject===p.beforeSubject&&o.afterSubject===p.afterSubject);
      updates.set(subject,same?undefined:o.present?{...o,value:value(subject)}:{present:false});
    }
    const head=ordinary.head===physical.head?undefined:{value:ordinary.head};
    const tail=ordinary.tail===physical.tail?undefined:{value:ordinary.tail};
    return ()=>{for(const [subject,row] of updates)this.install(subject,row);this.headOverride=head;this.tailOverride=tail;};
  }
  read(subject: number): OrdinaryEntityPresence<K,E> | undefined { return this.divergent.get(subject); }
  atKey(key: K): number | undefined { return this.displaced.get(key); }
  install(subject: number, next: OrdinaryEntityPresence<K,E> | undefined): void {
    const previous=this.divergent.get(subject);
    if(previous?.present && this.displaced.get(previous.key)===subject) this.displaced.delete(previous.key);
    if(next===undefined) this.divergent.delete(subject);
    else {
      this.divergent.set(subject,next);
      if(next.present) this.displaced.set(next.key,subject);
    }
  }
  retains(subject: number): boolean { return this.divergent.get(subject)?.present===true; }
  clear(): void { this.divergent.clear(); this.displaced.clear(); this.headOverride=undefined;this.tailOverride=undefined; }
}

export function ordinaryPresenceRecord<K extends string | number,E>(
 kind:'add'|'remove',subject:number,state:Extract<OrdinaryEntityPresence<K,E>,{present:true}>
): StructuralEffect {
 return {kind,subject,key:state.key,value:state.value,beforeSubject:state.beforeSubject,afterSubject:state.afterSubject};
}
