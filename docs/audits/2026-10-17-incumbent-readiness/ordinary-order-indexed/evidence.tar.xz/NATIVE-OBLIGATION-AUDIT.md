# Native ordinary-order obligation audit

Read-only frozen baseline /private/tmp/inverse-disposition-native/candidate, October24. No concurrent worker source edits/read dependence; no new lease engine proposed.

## Existing retention roots

- lib/internals/subject-restoration-claims.ts owner→subjects and subject→owners maps (roughly96–174), attached by private symbol to tree/$, are real strong identity roots. retain is atomic replacement/idempotent per owner; release returns newly unowned subjects; releaseAll clears maps. These are backing-retention claims, deliberately not authority or proof of reclamation eligibility.
- transactions.ts1390–1424 injects claims for transaction:<turnId> into TransactionAuthority. Confirm/discard release at989/1007. Release deliberately does **not** run reclamation sink: restoration may claim same subjects only on subsequent capture drain. Immediate cleanup there is the known never-claimed-retirement hazard.
- transactions authority retains pending effects/baselines, later dependency ledger and queued evidence. getPendingRollbackPlan refusal precedes retirement; pending claims remain. history-retain configuration and releaseConfirmedBeyondObligation govern optional confirmed history, not pending correctness facts.
- restoration.ts2344–2416 retains restoration:<entry.id> claims from entry.restorationSubjectIds. Eviction/window truncation/reset use releaseRetainedRestorationEntries; sink rechecks other owners and causal eligibility. Released descriptors are forgotten only at this boundary. Stable IDs avoid shifted-window aliasing; retain replacement is the existing update boundary for recaptured entry subject sets.
- entity-signal.ts ordinaryTopology is collection closure-owned and strongly holds divergent presence records including values. retains(subject) protects ordinary-present/physical-absent lifetime from no-restorer reclamation at2865. That is **current ordinary truth**, not optional history. Its lifetime cannot be ended just because transaction claims reach zero.
- physical retained values/states and weak held-reference carriers are separate roots; clearing ordinary placement metadata must not retarget old references or prematurely forget an ordinary-present lifetime.

## Source owner versus recovery facts

Current ordinary adjacency/head/tail describe current truth even with no transactions/history/Link. A live ordinary edge or ordinary presence is sufficient reason to retain its identity record. Historical anchors belong to retained inverse operations and existing claims; they cannot become current visible authority because retained. Conversely releasing last historical claim does not remove current ordinary facts.

The indexed owner should not claim every collection member under each pending/history entry merely to preserve its current order. Current state belongs to source storage; inverse facts/anchors remain in existing responsibility records. An identity-only adjacency override must not retain whole payload graphs solely because order differs. Existing EntityValueStore owns ordinary payload.

## Last-owner and drain boundary

No existing source callback promises 'last historical claim released' before capture drain. Transaction release intentionally avoids sink. A new cleanup requiring instantaneous per-edge notification at confirmation would be an added lifecycle mechanism and must not be smuggled into this experiment. Prefer existing current-state normalization at prepared ordinary/physical convergence; reclaimed subject paths already use claim/eligibility coordinator. If indexed design requires a new cross-system edge-claim registry to stay correct, that is a concrete architecture expansion to report.

Refusal must retain all inverse facts and conflict metadata. Confirmation may release pending claim while restoration entry still owns it. History eviction must not destroy pending claims. Repeated retain updates must release old set membership idempotently, not additive refcounts. Successful rollback/recovery cleanup waits for established publication/capture sequencing, not merely zero pending owners.

## Actual tree destruction

signal-tree.ts1990–2024 retains cleanupFns and rootAccessor on tree. destroy marks destroyed, terminates invalidation, invokes every registered cleanup despite throws, empties cleanupFns, releases contained-report budget. It does not erase tree.$ or forcibly clear each StructuralStore. A user-retained destroyed tree/handle can therefore keep source closures reachable; process collectibility requires dropping such roots and cannot be inferred from logical destroy alone.

transactions.ts4899 onward registers cleanup of subscriptions/pending maps/authority metadata; restoration.ts5353–5400 unsubscribes capture/order/notifications, resets retained history and clears pending-related maps. Restoration releases only its own claims, never other enhancers' releaseAll. Link has independent dispose closure and held-send cleanup. Collection owner registration must use the existing tree cleanup/materialization lifetime, with no consumer required to exist. If source currently lacks an owner cleanup hook, attach to existing authorized internal lifecycle seam and verify ordering; do not reinterpret public api.clear as destruction.

## Missing evidence / bounds

No new indexed-claim boundary is demonstrated as necessary for correctness if owner retains only current ordinary divergence and delegates historical backing to existing claims. Exact native owner representation may reveal a need; that is not assumed solved here. Required tests: current divergence with zero pending; pending claim survives history eviction; confirm before capture drain; refused retry keeps claims; same-key replacement and held retired reference; reset releases only restoration-owned records; destroy with pending/in-flight work; repeated cycles post-drain logical counts and separately dropped-root GC probes. Do not report retained user references as accidental tree leak without reachability evidence.
