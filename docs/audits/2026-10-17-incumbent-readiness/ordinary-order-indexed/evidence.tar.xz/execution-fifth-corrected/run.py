from pathlib import Path
import subprocess,json,hashlib,os
c=Path('/private/tmp/ordinary-order-indexed/native');d=Path('/private/tmp/ordinary-order-indexed/execution-fifth-corrected')
m={str(p.relative_to(c)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((c/'packages').rglob('*.ts'))}
(d/'SOURCE.json').write_text(json.dumps(m,indent=2)+'\n')
env=dict(os.environ,COREPACK_ENABLE_NETWORK='0',NX_DAEMON='false',NX_ISOLATE_PLUGINS='false')
commands=[('PREPEND-CORRECTED-FIRST',['corepack','pnpm','exec','nx','test','kernel','--testFile=src/lib/indexed-source-owner-prepend.spec.ts','--skip-nx-cache']),('COMBINED-FIRST',json.loads(Path('/private/tmp/inverse-disposition-native/order-policy/qualified-command.json').read_text()))]
for name,cmd in commands:
 (d/(name+'-COMMAND.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (d/(name+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=c,env=env,stdout=out,stderr=subprocess.STDOUT)
 assert all(hashlib.sha256((c/f).read_bytes()).hexdigest()==h for f,h in m.items()),'source changed during run'
 print(name,r.returncode,flush=True)
 if r.returncode:break
