import { describe, expect, it } from 'vitest';
import { signalTree } from './signal-tree';
import { transactions } from '../enhancers/transactions/transactions';
import { entityMap } from './markers/entity-map';
import { link } from './link';
import { external } from './external';
import { getLinkStateSlot } from './internals/link-state-source';
import { getPositionRegistry } from './internals/position-registry';
import { getHeldConsequenceCountForTesting } from './internals/commit-consequence';
const drain = async () => {
  for (let i = 0; i < 40; i++) await Promise.resolve();
};
const fixture = () =>
  signalTree(
    {
      x: 0,
      y: 0,
      nested: { n: 0 },
      rows: entityMap<{ id: string; x: number; y: number }, string>(),
    },
    { enhancers: [transactions()] }
  );
describe('Link independent progress through shared consequence authority', () => {
  it.each(['ordinary', 'confirm', 'refused'] as const)(
    'sends independent y while x remains %s',
    async (mode) => {
      const t = fixture();
      const xs: number[] = [];
      const ys: number[] = [];
      const lx = link(t.$.x, {
        set: (v) => {
          xs.push(v);
        },
      });
      const ly = link(t.$.y, {
        set: (v) => {
          ys.push(v);
        },
      });
      try {
        t.$.y(5);
        await drain();
        expect(ys).toEqual([5]);
        t.$.rows.addOne({ id: 'collision', x: 0, y: 0 });
        const p = t.transact(() => {
          t.$.x(1);
          if (mode === 'refused') t.$.rows.removeOne('collision');
        });
        if (mode === 'refused') {
          external(() => t.$.rows.addOne({ id: 'collision', x: 0, y: 0 }));
          expect(() => p.rollback()).toThrow();
        }
        if (mode === 'confirm') t.transact(() => t.$.y(11)).confirm();
        else t.$.y(11);
        await drain();
        expect(ys).toEqual([5, 11]);
        expect(xs).toEqual([]);
        expect(t.$.x()).toBe(1);
        if (mode !== 'refused') {
          p.rollback();
          await drain();
          expect(xs).toEqual([0]);
        } else expect(() => p.rollback()).toThrow();
      } finally {
        lx.dispose();
        ly.dispose();
        t.destroy();
      }
    }
  );
  it('holds a whole branch while allowing a disjoint sibling', async () => {
    const t = fixture();
    const whole: unknown[] = [];
    const ys: number[] = [];
    const a = link(t.$, {
        set: (v) => {
          whole.push(v);
        },
      }),
      b = link(t.$.y, {
        set: (v) => {
          ys.push(v);
        },
      });
    try {
      const p = t.transact(() => t.$.x(1));
      t.$.y(2);
      await drain();
      expect(whole).toEqual([]);
      expect(ys).toEqual([2]);
      p.rollback();
      await drain();
      expect(whole).toEqual([expect.objectContaining({ x: 0, y: 2 })]);
    } finally {
      a.dispose();
      b.dispose();
      t.destroy();
    }
  });
  it('separates fields of one lifetime and distinct lifetimes', async () => {
    const t = fixture();
    t.$.rows.addMany([
      { id: 'a', x: 0, y: 0 },
      { id: 'b', x: 0, y: 0 },
    ]);
    const a = t.$.rows.byIdOrFail('a'),
      b = t.$.rows.byIdOrFail('b');
    const xs: number[] = [],
      ys: number[] = [],
      bs: number[] = [];
    const links = [
      link(a.x, {
        set: (v) => {
          xs.push(v);
        },
      }),
      link(a.y, {
        set: (v) => {
          ys.push(v);
        },
      }),
      link(b.x, {
        set: (v) => {
          bs.push(v);
        },
      }),
    ];
    try {
      const p = t.transact(() => a.x(1));
      a.y(2);
      b.x(3);
      await drain();
      expect(xs).toEqual([]);
      expect(ys).toEqual([2]);
      expect(bs).toEqual([3]);
      p.rollback();
      await drain();
      expect(xs).toEqual([0]);
    } finally {
      links.forEach((l) => l.dispose());
      t.destroy();
    }
  });
  it('retains order-only authority for the collection without holding unrelated fields', async () => {
    const t = fixture();
    const rows = [
      { id: 'a', x: 0, y: 0 },
      { id: 'b', x: 0, y: 0 },
    ];
    t.$.rows.addMany(rows);
    const orders: string[][] = [],
      ys: number[] = [];
    const a = link(t.$.rows, {
        set: (v) => {
          orders.push(v.map((r) => r.id));
        },
      }),
      b = link(t.$.rows.byIdOrFail('a').y, {
        set: (v) => {
          ys.push(v);
        },
      });
    try {
      const p = t.transact(() => t.$.rows.setAll([...rows].reverse()));
      t.$.rows.byIdOrFail('a').y(2);
      await drain();
      expect(orders).toEqual([]);
      expect(ys).toEqual([2]);
      p.confirm();
      await drain();
      expect(orders.at(-1)).toEqual(['b', 'a']);
    } finally {
      a.dispose();
      b.dispose();
      t.destroy();
    }
  });
  it('rechecks admission after sending observation opens an intersecting transaction', async () => {
    const t = fixture();
    const sent: number[] = [];
    const l = link(t.$.y, {
      set: (v) => {
        sent.push(v);
      },
    });
    let pending: ReturnType<typeof t.transact> | undefined;
    const slot = getLinkStateSlot(getPositionRegistry(t.$)!);
    slot.observer = (record) => {
      if (record.activity()[3] && !pending)
        pending = t.transact(() => t.$.y(9));
    };
    try {
      t.$.y(2);
      await drain();
      expect(pending).toBeDefined();
      expect(sent).toEqual([]);
      slot.observer = undefined;
      pending!.rollback();
      await drain();
      expect(sent).toEqual([2]);
    } finally {
      slot.observer = undefined;
      l.dispose();
      t.destroy();
    }
  });
  it('drops held closures on disposal and destruction', async () => {
    const t = fixture();
    const sent: number[] = [];
    const l = link(t.$.x, {
      set: (v) => {
        sent.push(v);
      },
    });
    const p = t.transact(() => t.$.x(1));
    await drain();
    expect(getHeldConsequenceCountForTesting(t)).toBeGreaterThan(0);
    l.dispose();
    expect(getHeldConsequenceCountForTesting(t)).toBe(0);
    p.rollback();
    await drain();
    expect(sent).toEqual([]);
    t.destroy();
  });
});
