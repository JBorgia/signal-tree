# L1 bounded admission experiment — not accepted

Baseline d832058c in incumbent readiness worktree. B remains closed. No commits, API exports, releases or ceiling changes.

## Mechanism and changed files

- commit-consequence.ts: opt-in dependency-scoped admission, using per-scope authority proof; default storage gate unchanged. Held requests rechecked after each settlement, disposal withdrawal remains. Reentrant replacement of held entries checked.
- transactions.ts: open scope proof reads reserved/materialized effects, lifetime/field identity, structured addresses, open order capture and staged order deltas. No separate mutation ownership ledger. File formatting also normalized some previous code; no other semantic edits.
- link.ts: requests dependency-scoped admission at scheduling and per-send boundary; sending observer may open a new pending scope, so rechecks after observer and rereads eligible projection. Publishes waiting state again if denied.
- link-independent-progress.spec.ts: 16 new controls, no changes to pre-existing assertions or tests.

## Results and first failures

- Public replay ordinary / confirmed / refused / reentrant y advances while pending x remains held; disposed control stays silent. l1-public-candidate.log; original replay/script already archived in prior investigation.
- Initial 27 unchanged controls passed (l1-initial-tests.log).
- New initial 7/8 pass: endpoint received old y=2 after sending observer opened pending y=9. l1-controls-first.log and l1-first-{link.ts,transactions.ts,commit-consequence.ts} preserve source. Added second authority check at endpoint.
- Second new result 7/8: observer fixture repeatedly opened transactions before assigning pending variable. Original l1-second-fixture.spec.ts and l1-controls-second.log preserved. One-shot guard fixed setup, assertions unchanged; 35/35 then pass (l1-controls-third.log).
- Expanded fixture first run14/16: getMutationCaptureRuntime incorrectly addressed tree.$ (actual tree); nested public transact unsupported. l1-extra-first.spec.ts and l1-extra-first.log preserved. Corrected capture target and used older pending plus active newer callback, no new nested API promise.
- Initial spec types found unsupported root Link containing entity map and optional object represented as a leaf. Corrected test to ordinary scalar root and explicit JS omission through Reflect.apply; no runtime/type weakening. Original failures l1-spec-types.log. Later l1-spec-types-final.log has no Link errors, but concurrent restoration WIP errors, so whole gate NOT passed.
- Expanded43/43 pass (16 new +27 existing), l1-expanded.log.
- Additional existing Link72/72 pass (includes16 new), l1-existing-expanded.log; do not sum overlapping runs.
- ESLint four changed files passes, l1-lint.log.
- Public reader variant adds held=true/sending=false assertion after denied observer reentry. Included in complete Link run.
- Complete Link run:318 ordinary passes /18 failures /336 tests,31 files, no skips/expected failures. l1-all-link-first.log. This result rejects sufficiency of the candidate.

## Decisive defect: reactive dependency is not owned-write overlap

Eight unchanged link-reactive-settlement tests fail. Pending s0=7 propagates through notifier subscribers s0→s1→s2. The s2 Link sends7 before confirmation/rejection. After rollback it sends0. These are genuine speculative-publication regressions, not old global-gate fixture expectations.

Read-only bundled diagnostic l1-reactive-trace.mjs/json/log records exact inputs and:

- Reserved/materialized authority effects and pending inspection name only s0, replace0→7.
- s0 notification carries transactionId1; subscriber active write context is absent.
- s1 notification and its subscriber active context have no transactionId.
- Therefore the query falsely proves s2 disjoint although its value depends on pending s0.

executeTransaction's withWriteContext ends before notification draining. PathNotifier calls handlers without declared observation scopes. Declared scopes explicitly are not read dependencies. location-runtime's dependency graph governs projection freshness; it does not record arbitrary subscriber value flow into authored writes. Extending callback capture or using pending position counts cannot reconstruct missing provenance after the fact.

Options: retain the safe tree gate (leaves independent progress unresolved); separately specify and test consequence dependency propagation through notifications/derived writes (new representation obligation); or explicit application dependency declarations (new API and not authorized). Do not attribute ordinary callback writes to a transaction merely to make admission pass, or silently classify these leaks as supported independent work. Recommendation: reject this candidate as complete, preserve its narrower positive evidence, and report the precise missing proof boundary before further architecture.

## Frozen composition accounting

Unchanged frozen N cases:6 held /4 violated /2 unsupported. All10 original progress assertions now held. Four rows reach a later `rejected x never sent` assertion expecting[], but receive restored baseline[0], never rejected1. Preserve four violated verdicts; do not rewrite frozen oracle.

Direct identical baseline/candidate replay l1-n04-compare.mjs/json/log verifies:
- Both send x=[0] after rejection, current state x0/y2/z0.
- Baseline withholds y until x rejects; candidate sends y2 after y confirmation while x pending.
- Existing public Link contract permits restored-value publication (link-0-three-directions.spec.ts:331 onward). This is a distinct stronger no-emission oracle premise, not the eight reactive leaks.

Other ten all-Link failures appear tied to historical global-gate expectations; they are unmodified and not conclusively migrated/classified because the real reactive defect blocks acceptance first.

## Commands

Node24.15.0 / pinned pnpm10.17.0, NX_DAEMON=false. PATH prepends /private/tmp/st-b-qualification-20261016/bin and /Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin.

```
pnpm nx test kernel --testFile=src/lib/link-independent-progress.spec.ts --testFile=src/lib/link-order-rollback.spec.ts --testFile=src/lib/internals/commit-consequence.spec.ts --testFile=src/lib/egress-1-observation-vs-consequence.spec.ts --skip-nx-cache
pnpm nx test kernel --testFile=src/lib/link-0-three-directions.spec.ts --testFile=src/lib/link-1-relationship.spec.ts --testFile=src/lib/link-2-public-contract.spec.ts --testFile=src/lib/link-structured-address-audit.spec.ts --testFile=src/lib/link-independent-progress.spec.ts --skip-nx-cache
pnpm nx test kernel --testFile=src/lib/link --skip-nx-cache
node /private/tmp/l1-frozen-replay/replay.mjs
node /private/tmp/l1-n04-compare.mjs
node /private/tmp/l1-reactive-trace.mjs
node tools/check-spec-types.mjs
pnpm exec eslint packages/kernel/src/lib/link.ts packages/kernel/src/lib/internals/commit-consequence.ts packages/kernel/src/enhancers/transactions/transactions.ts packages/kernel/src/lib/link-independent-progress.spec.ts
```

No broader qualification/build/benchmark by this worker. Hashes l1-source-hashes.sha256; final snapshots and runtime.patch in l1-evidence. Baseline/candidate diagnostic JSON includes all source input hashes. Frozen replay retains original frozen-oracle hash checks.

Automatic approval review rejected a proposed formatting-cleanup reconstruction of transactions.ts from HEAD, citing risk of unrelated change loss. It did not run. No workaround attempted; formatter hunks remain. This rejection is separate from executed test failures and did not block diagnosis.
