# R1/R2 bounded restoration candidate

Base: d832058c. No commit performed by worker. B remains closed. Link is separately rejected; these results do not qualify release.

Mechanism: pre-install payload-free structural placement evidence is delivered with the installed frontier interval. Restoration appends operation evidence; explicit order endpoints extend through contiguous same-bucket intervals only. Enclosing setAll/prepend membership is not replayed twice. Frame inverse placement uses indexed pending/waiter dependencies, not reversed caller order. Final arrays materialize once; point captures do not traverse collection state.

Preservation: original-reversal.spec.ts is exact unchanged tracking carrier. baseline.log passes its 24 ordinary tracking/current checks plus six expected failures. first-candidate.log records six obsolete refusal assertions and six unexpected it.fails successes. Active desired assertions are unchanged, promoted ordinary; current-behavior tests removed under their explicit delete-when-fixed instruction.

Independent review falsifier: ordinary removeMany([A,C,B]) then setAll([E,D]) from [A,B,C,D,E]. Initial helper tried inverse B before its restorable neighbors. Composition threw in swallowed onFlush, so no useful history was recorded. See review-multi-removal-first.log and pre-review-multi-removal-helper.ts. General indexed frame dependency resolution corrected it. No convenient neighbor fallback or ST1034 weakening.

Final: focused-reviewed-final.log records 124 ordinary passes, zero skips/expected failures, across eight files. Includes six original assertions across three enhancer configurations; repeated undo/redo across earlier designated order; enclosing fresh prepend; independent drift; realized membership interleave; held references; all six three-row removal permutations; disconnected removed runs; original compound and zero-net controls; unchanged missing-anchor/frontier/two-setAll controls. Unit work controls read each record once at sizes16,128,1024; these are operation counts, not CPU benchmarks.

Controlled preparation test: historical endpoint preparation fails after authored endpoint preparation. Both capture channels retain facts; a later genuinely notifying unrelated write allows useful undo of both turns. First fixture used uninstrumented unrelated leaf and therefore emitted no notifier event; exact first spec/log preserved, corrected to restoration-enabled source. Initial fixture also used nonexistent rows.entity and incorrect write-context import; logs retained as test harness errors, not runtime failures.

Source identities: reviewed-candidate-hashes.sha256 and frozen-source/ contain exact seven files. Earlier candidate-hashes.sha256 is preserved with its earlier provenance. Type/lint and independent final review belong to root qualification; no full-release acceptance claimed. No public recovery API added. Artificial failure of one-shot transaction staging retains capture but does not demonstrate a new public recovery lifecycle.


## Full-kernel failure-group correction

Root full run: /private/tmp/incumbent-restoration-kernel-full.log:72 failures,5763 ordinary passes,5 expected failures,12 skips. Exact baseline comparison /private/tmp/incumbent-d832-five-groups.log found60 pre-existing group failures:56 membership reversal publication,4 detached historical reconstruction. New candidate added12 observer lifecycle assertions.

The12 introduced failures were a permanent committed-entity observer enabling a channel contractually active only while pending obligations exist. Structural-boundary evidence now has its own private listener set and query; ordinary field capture remains gated by pending committed observers. Existing assertions are unchanged.

Four baseline history failures (three prepend and one mixed member/entity) occur after useful undo/redo, while getRestorationHistory reconstructs detached states. Existing collection-order subscriber captured origin:restoration as a new historical gap, unlike the ordinary notifier's explicit replay exclusion. Order and structural-boundary capture now both exclude that origin. No blanket isRestoring guard suppresses callback-authored writes, and no frontier check was weakened.

history-origin-final.log:160 ordinary passes,zero failures/skips/expected failures across five files:pending-active-entity,pending-footprint-v16-controls,pending-membership-admission,prepend-many-order-reversal,and order-composition-readiness. qualification-candidate-hashes.sha256 and qualification-source/ freeze these revised seven sources. Earlier frozen-source and reviewed hashes remain unchanged evidence. Parent independently owns membership publication investigation and final type/review/full gates.

Reviewer actual-work controls: channel-controls-first.log 24/24 ordinary passes. New tests prove field update emits neither boundary listener nor committed publication with no pending owner; structural add emits once; destroy releases boundary channel; explicitly application-authored order during undo delivery survives and can itself be undone. Runtime unchanged from qualification-candidate hashes; final seven-file identities in qualification-final-hashes.sha256.
