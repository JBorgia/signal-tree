from pathlib import Path
p=Path('/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/restoration/order-boundary-evidence.ts');s=p.read_text();a=s.index('  for (const interval of intervals) {',s.index('function extend'));b=s.index('  const result: number[] = [];',a)
s=s[:a]+'''  for (const interval of intervals) {
    // A frame records pre-install neighbors, not an ordering of inverse work.
    // Remove departing subjects first, then resolve the insertion dependency
    // graph. Caller order (e.g. removeMany A,C,B) is not placement authority.
    const pending = new Map<number, Exclude<StructuralPlacementEvidence, { kind: 'rekey' }>>();
    for (const record of interval.records) {
      if (record.kind === 'rekey') continue;
      const remove = inverse ? record.kind === 'add' : record.kind === 'remove';
      if (!remove) {
        if (nodes.has(record.subject) || pending.has(record.subject))
          throw new Error('Captured order boundary repeats a subject');
        pending.set(record.subject, record);
        continue;
      }
      const node = nodes.get(record.subject);
      if (!node) throw new Error('Captured order boundary has no subject');
      if (node.before === undefined) head = node.after;
      else nodes.get(node.before)!.after = node.after;
      if (node.after !== undefined) nodes.get(node.after)!.before = node.before;
      nodes.delete(record.subject);
    }
    const waiting = new Map<number, number[]>();
    const ready: number[] = [];
    for (const record of pending.values()) {
      let available = false;
      for (const anchor of [record.afterSubject, record.beforeSubject]) {
        if (anchor === undefined) continue;
        if (nodes.has(anchor)) available = true;
        else {
          let dependents = waiting.get(anchor);
          if (!dependents) waiting.set(anchor, dependents = []);
          dependents.push(record.subject);
        }
      }
      if (available) ready.push(record.subject);
    }
    if (!nodes.size && pending.size) {
      // The frame can restore an entire chain into an empty collection. A
      // seed is safe only when every named neighbor is in this same frame.
      const seed = [...pending.values()].find(record =>
        [record.beforeSubject, record.afterSubject].every(anchor =>
          anchor === undefined || pending.has(anchor)));
      if (seed) ready.push(seed.subject);
    }
    for (let index = 0; index < ready.length; index++) {
      const record = pending.get(ready[index]);
      if (!record) continue;
      const successor = record.afterSubject;
      const predecessor = record.beforeSubject;
      const after = successor !== undefined && nodes.has(successor)
        ? successor
        : predecessor !== undefined && nodes.has(predecessor)
        ? nodes.get(predecessor)!.after
        : undefined;
      if (nodes.size &&
          !(successor !== undefined && nodes.has(successor)) &&
          !(predecessor !== undefined && nodes.has(predecessor))) continue;
      const before = after === undefined
        ? (predecessor !== undefined && nodes.has(predecessor) ? predecessor : undefined)
        : nodes.get(after)!.before;
      nodes.set(record.subject, { before, after });
      if (before === undefined) head = record.subject;
      else nodes.get(before)!.after = record.subject;
      if (after !== undefined) nodes.get(after)!.before = record.subject;
      pending.delete(record.subject);
      for (const dependent of waiting.get(record.subject) ?? []) ready.push(dependent);
      waiting.delete(record.subject);
    }
    if (pending.size) throw new Error('Captured order boundary has no placement anchor');
  }
''' +s[b:];p.write_text(s)
