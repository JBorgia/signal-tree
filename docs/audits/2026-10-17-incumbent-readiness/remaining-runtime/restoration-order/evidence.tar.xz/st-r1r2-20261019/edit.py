from pathlib import Path
r=Path('/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree')
p=r/'packages/kernel/src/lib/entity-signal.ts'
s=p.read_text().replace('frame.commit(committedEntityObserver(),responsibility,structuralFrontier)', 'frame.commit(committedEntityObserver(structuralFrontier, changes),responsibility,structuralFrontier)')
s=s.replace('function committedEntityObserver():', '''function committedEntityObserver(
    structuralFrontier?: import('./internals/mutation-capture-runtime').StructuralFrontierInterval,
    preparedChanges?: readonly CommittedEntityMutation[]
  ):''')
s=s.replace('''        changes,
        meta,
      });
  }

  function rememberSubjectIds''','''        changes,
        structuralFrontier,
        structuralRecords: structuralFrontier
          ? preparedChanges?.flatMap((change) => change.structuralRecord ? [change.structuralRecord] : [])
          : undefined,
        meta,
      });
  }

  function rememberSubjectIds''')
p.write_text(s)
p=r/'packages/kernel/src/lib/internals/mutation-capture-runtime.ts';s=p.read_text().replace('export type CommittedEntityCapture = {','export type CommittedEntityCapture = {\n  readonly structuralRecords?: readonly StructuralEffect[];');p.write_text(s)
p=r/'packages/kernel/src/enhancers/restoration/restoration.ts';s=p.read_text();s="import { completeOrderCapture, type OrderBoundaryEvidence } from './order-boundary-evidence';\n"+s
s=s.replace('  collectionOrders: Map<number, PendingCollectionOrder>;','  collectionOrders: Map<number, PendingCollectionOrder>;\n  orderBoundaries: Map<number, OrderBoundaryEvidence[]>;')
s=s.replace('      collectionOrders: new Map(),','      collectionOrders: new Map(),\n      orderBoundaries: new Map(),')
s=s.replace('      bucket.collectionOrders.clear();','      bucket.collectionOrders.clear();\n      bucket.orderBoundaries.clear();',1)
s=s.replace('''        (order) => ({
          ...order,
          beforeSubjects: [...order.beforeSubjects],
          afterSubjects: [...order.afterSubjects],
        })''','''        (order) => completeOrderCapture(order, bucket.orderBoundaries.get(order.owner) ?? [])''')
s=s.replace('''      bucket.collectionOrders.clear();
      const descriptorInputs''','''      bucket.collectionOrders.clear();
      bucket.orderBoundaries.clear();
      const descriptorInputs''')
s=s.replace('''    let unsubscribeCollectionOrders: (() => void) | null = null;''','''    let unsubscribeCollectionOrders: (() => void) | null = null;
    let unsubscribeOrderBoundaries: (() => void) | undefined;''')
s=s.replace('''    try {
      unsubscribeCollectionOrders =''','''    try {
      unsubscribeOrderBoundaries = getMutationCaptureRuntime(tree)?.subscribeCommittedEntity?.((capture) => {
        if (!capture.structuralFrontier || !capture.structuralRecords ||
            isCompensationWrite(capture.meta) || isInspectionWrite(capture.meta)) return;
        const evidence: OrderBoundaryEvidence = {
          ...capture.structuralFrontier,
          records: capture.structuralRecords.map(({ value: _value, ...record }) => record),
        };
        const retain = (bucket: CaptureBucket): void => {
          let records = bucket.orderBoundaries.get(capture.owner);
          if (!records) bucket.orderBoundaries.set(capture.owner, records = []);
          records.push(evidence);
        };
        const transactionId = resolveTransactionId(capture.meta);
        if (getWriteParticipation(capture.meta) === 'realized' || transactionId === undefined) {
          const historical = getHistoricalCapture();
          if (historical) retain(historical);
        }
        if (getWriteParticipation(capture.meta) === 'realized') return;
        retain(transactionId === undefined ? pendingCapture : getTransactionBucket(transactionId));
      });
      unsubscribeCollectionOrders =''')
s=s.replace('''          unsubscribeCollectionOrders?.();''','''          unsubscribeCollectionOrders?.();
          unsubscribeOrderBoundaries?.();''')
p.write_text(s)
