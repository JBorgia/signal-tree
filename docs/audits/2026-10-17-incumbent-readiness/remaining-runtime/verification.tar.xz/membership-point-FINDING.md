# Baseline partial membership delivery

Baseline d832058c. Read-only source trace + exact-baseline bundled diagnostic; no production edits. Source input hashes and raw results in membership-point-trace.json, generating script membership-point-trace.mjs, output membership-point-trace.log.

Ordinary reproduction: seed left[a],right[b]; transact add left.x and right.y; subscribe entityMembershipReader before transaction; rollback.

First callback is delivered during point.install, sees both native and inventory left[a],right[b,y]. Second callback still during point.install sees inventory left[a],right[b], but native cached right.ids remains[b,y] until publish. Final state is correct. Thus this is premature observer delivery, not a stale final state or restoration semantics dispute.

Root's unchanged baseline five-group run /private/tmp/incumbent-d832-five-groups.log reports60 failures/294 passes; membership-reversal-delivery failures say `rollback: partial reversal visible to a listener`. These predate today's R1/R2 edits.

Causal route:
- transactions.ts applyRollbackCompensation computes compensatedFrontiers.
- frontiers.size >0 selects preparePointRealization even for ordinary multi-collection structural effects.
- installPreparedCompensation (around2683) invokes point.install, installs compensated frontier, marks completion committed, invokes point.publish.
- preparePointRealization structural arm (tree-realization-adapter.ts around653–703) installs heterogeneous physical frames first; entity membership source publishes committed facts synchronously.
- No membership-delivery hold spans this helper. Outer pending.rollback wraps native invalidation group, which governs reactive publication, not membership tooling delivery.
- Existing rollbackPendingTarget holds membership listeners around complete installation/publication (transactions.ts2868). Existing createTreeRealizationAdapter.applyAtomically does the same (tree-realization-adapter.ts589). The added point route bypasses those wrappers.

Smallest correction to test: use existing holdEntityMembershipDelivery around the complete installPreparedCompensation installation/frontier restoration/publication, release in finally. This is restoring the established publication boundary. Recheck first-error behavior and reentrant membership delivery, plus unchanged membership-reversal-delivery matrix. No ST1034/history reset, semantic alteration, new authority or API required.
