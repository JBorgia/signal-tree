# Point-compensation membership publication repair

Source inherited e9653a41, identical transaction source to d832058c before this change. Only transactions.ts changed by this worker. No Link dependency work, API or semantics changes.

Cause and exact baseline reproduction: membership-point-FINDING.md and membership-point-trace.{mjs,json,log}. Point compensation installed physical membership with synchronous tooling delivery before all collections and projections were coherent. Existing complete-target and general realization routes already held membership delivery; point route omitted that established hold.

Correction: installPreparedCompensation obtains holdEntityMembershipDelivery after frontier validation, spans point.install, frontier installation, completion marking and point.publish, and releases in finally. Membership observer exceptions are already contained by reader delivery. Original physical/publication errors retain their established propagation and pending disposition. No history reset or changed refusal rule.

Verification (Node24.15.0/pnpm10.17.0/NX_DAEMON=false):

```
pnpm nx test kernel --testFile=src/enhancers/restoration/membership-reversal-delivery.spec.ts --testFile=src/enhancers/restoration/compound-compensation-retry-readiness.spec.ts --testFile=src/lib/transaction-safety.spec.ts --skip-nx-cache
```

218 ordinary passes in2 files: membership matrix216 + retry2. Third testFile was a nonexistent path and did not execute; corrected below. Log membership-point-repair-first.log.

```
pnpm nx test kernel --testFile=src/enhancers/transactions/transaction-safety.spec.ts --testFile=src/enhancers/transactions/recovery-handle-0.spec.ts --testFile=src/enhancers/restoration/compound-compensation-controls.spec.ts --testFile=src/enhancers/restoration/zero-net-compensation.spec.ts --skip-nx-cache
pnpm exec eslint packages/kernel/src/enhancers/transactions/transactions.ts
```

46 ordinary passes in4files, no skipped/expected failures. Existing controls include occupied-destination refusal/retry, preparation reentry, mixed observer throw, callback recovery, zero-net intervals and compensated history retry. Membership matrix itself includes throws and cross-collection reentrant remove/rekey/update, so no redundant new test needed. Logs membership-point-repair-controls.log and membership-point-repair-lint.log; lint passes.

Final transaction source SHA256:
487b4e2a693395b37572991484a66a3cd36f5748098e5d4ab21b2673c85bd536

No whole-source type/build/release qualification claimed by this worker. Root coordinates combined-source review and broader verification. No commits by worker; final independent review still required.

## Exact point-route error witness

`node /private/tmp/membership-point-error-witness.mjs` uses esbuild onLoad instrumentation only, no production edits, with exact original source hashes in adjacent JSON. Replays the mixed scalar+entity test body from transaction-safety.spec.ts plus explicit identity/release assertions and an observed membership reader.

Trace: point.enter → point.install.before → point.install.after → point.publish.before → membership.release.before → membership.release.after. There is no point.publish.after because the original notifier Error throws. Two notifier invocations throw the same Error; the escaping thrown value is that exact object. Complete x=0/rows=[] is delivered to membership listener during finally release; listener itself throws a different contained error without masking the notifier error. Pending count0, commit scope closed, repeated rollback no-op, confirmation rejected, inspection preserved. A later ordinary add delivers another membership event, demonstrating hold release rather than stuck queue. No coherence claim is added for ordinary installation callbacks.

Original harness typo `contents.index` failed before execution; fixed to indexOf with first log preserved as membership-point-error-witness-harness-first.log. This is harness failure, not source failure.

Pinned test hashes:
- transaction-safety.spec.ts37e5d73415832047863481084d1d0b8be7d8bdf16305973a18172de1b5070771
- membership-reversal-delivery.spec.ts1f96503a2afb00c06066997e2d1d8c21f96614c6cb06202c055695ef478ad27a
