# Bounded ordered realization successor

The adapter retains its physical target and carries the ordered reversal edits that created it. A typed edit is whole-row replacement or a present/deleted top-level field. Store preparation starts from existing ordinary-before, applies those edits in authored order, then prepares dual ordinary/physical result. No target diff and no inspection sibling copying. Installation stays allocation/callback-free; existing physical revision checks bracket preparation and install. Publish carries the prepared result through existing notify metadata.

Whole-row replacement followed by field edit and repeated field edits retain sequence. Deletion is represented separately from present undefined. Preparation clones edit values before installation. Existing scope/participation classification remains unchanged; this path is realized compensation, not a new authored write.

Nested paths are not qualified in this successor pending the missing-parent contract investigation. No implicit full-row fallback, parent creation, deletion or adoption is selected. Structural, membership and later slices remain untouched.

## Reachability and scope disposition

The reachability audit finds sole production S3 caller is transactions, whose effects have empty or one-segment paths. Point adapter preflight declines deeper synthetic paths through existing optional capability return before target preparation. This is neither a selected missing-parent semantic nor nested support. Existing general fallback is unchanged and unqualified for missing-parent dual truth; restoration uses other adapters. No ancestor policy is implemented.

## Prepared payload isolation correction

First independent review exposed repeated reading of effect.after and whole-row target aliasing. Preserved red logs precede correction. Each entity effect now reads and clones after once; physical target mutations consume another isolated clone, leaving the ordered ordinary edit and caller input unchanged. Six focused files34/34 and source typecheck pass; this is bounded evidence, not later-slice or release qualification.
