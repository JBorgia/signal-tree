// Illustrative API declarations only; no implementation or package exports.
import type {PendingTransaction,SignalTreeRollbackRecovery} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src';
type OwnerReference = PendingTransaction | SignalTreeRollbackRecovery['transaction'];
export type PublicationResponsibility =
 | { readonly kind: 'independent' }
 | { readonly kind: 'dependent'; readonly owners: readonly OwnerReference[] }
 | { readonly kind: 'unknown' };
export type PublicationState =
 | { readonly state: 'no-write' | 'superseded' | 'disposed' | 'released' }
 | { readonly state: 'eligible' }
 | { readonly state: 'held'; readonly reason: 'pending-dependency' }
 | { readonly state: 'conservative'; readonly reason: 'unknown' | 'rejected-dependency' | 'unavailable-owner' | 'invalid-declaration' };
export interface PublicationReceipt { read(): PublicationState; }
export interface ProposedLink {
 retrieve(): Promise<void>; settled(): Promise<void>; dispose(): void;
 declare<R>(responsibility: PublicationResponsibility, work: () => R & (R extends PromiseLike<unknown> ? never : unknown)): PublicationReceipt;
}
