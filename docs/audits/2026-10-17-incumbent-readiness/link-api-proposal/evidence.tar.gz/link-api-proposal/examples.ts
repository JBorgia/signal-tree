import type {PendingTransaction,SignalTreeRollbackError} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src';
import type {ProposedLink} from './proposal-types';
declare const connection:ProposedLink;
declare const pending:PendingTransaction;
declare const recovery:NonNullable<SignalTreeRollbackError['recovery']>;
declare const readX:()=>number;
declare const writeY:(v:number)=>void;
const literal=connection.declare({kind:'independent'},()=>writeY(7));
const copied=connection.declare({kind:'dependent',owners:[pending]},()=>writeY(readX()));
const saved=readX();
connection.declare({kind:'dependent',owners:[pending]},()=>writeY(saved));
connection.declare({kind:'dependent',owners:[recovery.transaction]},()=>writeY(saved));
connection.declare({kind:'unknown'},()=>writeY(saved));
// @ts-expect-error owners are required, not implicitly empty
connection.declare({kind:'dependent'},()=>writeY(saved));
// @ts-expect-error ordinary async callback rejected by proposed signature
connection.declare({kind:'independent'},async()=>writeY(7));
// @ts-expect-error promise result rejected
connection.declare({kind:'independent'},()=>Promise.resolve());
// Unknown result cannot be statically certified; mandatory runtime validation.
declare const erased:()=>unknown;
connection.declare({kind:'independent'},erased);
// Four facade leaf-write forms; callback wrapper does not change native reads.
declare const angular:{set(v:number):void};
declare const solid:{set(v:number):void};
declare const vue:{value:number};
declare const react:(v:number)=>void;
connection.declare({kind:'independent'},()=>angular.set(7));
connection.declare({kind:'independent'},()=>solid.set(7));
connection.declare({kind:'independent'},()=>{vue.value=7;});
connection.declare({kind:'independent'},()=>react(7));
void literal.read();void copied.read();
