// Illustrative API declarations only; no implementation or package exports.
import type {PendingTransaction,SignalTreeRollbackError} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src';
type OwnerReference = PendingTransaction | NonNullable<SignalTreeRollbackError['recovery']>['transaction'];
export type PublicationResponsibility =
 | { readonly kind: 'independent' }
 | { readonly kind: 'dependent'; readonly owners: readonly OwnerReference[] }
 | { readonly kind: 'unknown' };
export type PublicationState =
 | { readonly state: 'validating' | 'no-write' | 'superseded' | 'disposed' }
 | { readonly state: 'eligible' | 'started'; readonly basis: 'declared' | 'surviving' }
 | { readonly state: 'held'; readonly reason: 'pending-dependency' }
 | { readonly state: 'conservative'; readonly reason: 'unknown' | 'rejected-dependency' | 'unavailable-owner' | 'invalid-declaration' };
export interface PublicationReceipt { read(): PublicationState; }
export interface ProposedLink {
 retrieve(): Promise<void>; settled(): Promise<void>; dispose(): void;
 declare<R>(responsibility: PublicationResponsibility, work: () => R & (R extends PromiseLike<unknown> ? never : unknown)): PublicationReceipt;
}

export declare class SignalTreePublicationError extends Error {
 readonly code: 'SIGNALTREE_PUBLICATION_DECLARATION_INVALID';
 readonly stage: 'before-callback' | 'after-callback';
 readonly reason: 'malformed' | 'unavailable-owner' | 'contradiction' | 'async-callback' | 'validation-threw' | 'disposed' | 'unsupported-source';
 readonly cause?: unknown;
}
