import {signalTree, transactions, link} from './packages/kernel/src/index';
import {getPathNotifier} from './packages/kernel/src/lib/path-notifier';
import {getPositionRegistry} from './packages/kernel/src/lib/internals/position-registry';
import {getLinkStateSlot} from './packages/kernel/src/lib/internals/link-state-source';
import * as research from 'research-private';
const tick=async()=>{for(let i=0;i<60;i++)await Promise.resolve();};
export async function run(){
 const results:unknown[]=[];
 for(const bridge of [false,true]) for(const scenario of ['ingress','direct','copy','previous','captured','no-op','inflight','destroy','reentry','rejected-copy']){
 research.mode(bridge);
 const t=signalTree({x:0,y:0,z:0},{enhancers:[transactions()]});
 const sent:unknown[]=[];let incoming!:(v:number)=>void;const offs:(()=>void)[]=[];
 let release! :()=>void;
 const outgoing=link(t.$.y,{set:v=>{sent.push(v);if(scenario==='inflight'&&sent.length===1)return new Promise<void>(r=>release=r);}});
 const inbound=link(t.$.y,{subscribe:next=>{incoming=next;return ()=>{};}});
 const p=t.transact(()=>t.$.x(7));
 let assertion='pass', error:string|undefined;
 const check=(ok:boolean,message:string)=>{if(!ok){assertion='FAIL';error=message;}};
 try{
  if(scenario==='ingress'){incoming(42);await tick();const first=[...sent];incoming(7);await tick();results.push({bridge,scenario,phase:'pending',sent:[...sent],first,x:t.$.x()});check(JSON.stringify(sent)===JSON.stringify(bridge?[42,7]:[]),'expected authoritative 42 and 7 before settlement only in bridge');}
  if(scenario==='direct'||scenario==='copy'){await tick();t.$.y(scenario==='direct'?42:t.$.x());await tick();check(sent.length===0,'unknown write escaped');}
  if(scenario==='previous'||scenario==='captured'){
   t.$.y(7);await tick();const captured=t.$.x();
   offs.push(getPathNotifier().subscribe('y',(v,prev)=>{if(v===42)t.$.y(scenario==='previous'?prev as number:captured);}));
   incoming(42);await tick();check(sent.length===0,'arbitrary callback output inherited clean ingress');
  }
  if(scenario==='no-op'){t.$.y(7);await tick();incoming(7);await tick();check(sent.length===0,'no-op manufactured revision');}
  if(scenario==='inflight'){incoming(42);await tick();incoming(7);await tick();if(bridge){check(JSON.stringify(sent)==='[42]','second request overlapped');release();await tick();check(JSON.stringify(sent)==='[42,7]','old completion erased replacement');}}
  if(scenario==='destroy'){incoming(42);outgoing.dispose();await tick();check(sent.length===0,'disposed queued work sent');}
  if(scenario==='reentry'){
   let reentered=false;const slot=getLinkStateSlot(getPositionRegistry(t.$.y)!);
   slot.observer=(r)=>{if(r.endpoint.set&&r.activity()[3]&&!reentered){reentered=true;t.$.y(t.$.x());}};
   incoming(42);await tick();slot.observer=undefined;
   check(sent.length===0,'stale admitted revision sent after sending observer replaced y with pending copy');
  }
  if(scenario==='rejected-copy'){t.$.y(t.$.x());await tick();p.rollback();await tick();check(sent.length===0,'surviving copied unknown escaped after rejection');}
  results.push({bridge,scenario,phase:'before-confirm',sent:[...sent],state:t.$(),assertion,error});
  if(scenario!=='rejected-copy')p.confirm();await tick();
  if(!bridge&&scenario==='inflight'&&release){release();await tick();}
  results.push({bridge,scenario,phase:'after-confirm',sent:[...sent],state:t.$()});
 }catch(e){results.push({bridge,scenario,harnessError:String(e)});}
 finally {for(const off of offs)off();outgoing.dispose();inbound.dispose();t.destroy();await tick();}
 }
 results.push({researchHeldCallbacksAfterDisposal:research.heldCount(),revisionReceipts:research.receipts});
 return results;
}
