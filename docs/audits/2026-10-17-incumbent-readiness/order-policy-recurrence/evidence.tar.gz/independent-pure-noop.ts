import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '../candidate/packages/kernel/src/index';
import {withWriteContext} from '../candidate/packages/kernel/src/lib/write-context';
import {observeWrites} from '../candidate/packages/kernel/src/internals';
import {peekInternalTransactionRuntime} from '../candidate/packages/kernel/src/enhancers/transactions/transactions';
const realized=(f:()=>void)=>withWriteContext({intent:'system',participation:'realized'},f);
const tick=async()=>{for(let i=0;i<40;i++)await Promise.resolve();};
for(const mode of ['netnoop'] as const){
 const t=signalTree({x:0,rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});let off=()=>{};
 try{const r=t.$.rows;r.setAll(['a','b','c'].map((id,n)=>({id,n})));await tick();const order=(s:string)=>r.setAll([...s].map(id=>r.byIdOrFail(id)()));let p:any;const failure=new Error('independent callback failure');let caught:any;
 const work=()=>{order('cba');if(mode!=='safe'){realized(()=>order('bca'));if(mode==='aba')realized(()=>order('cba'));}order(mode==='netnoop'?'abc':'acb');if(mode==='failed')throw failure;};
 try{p=t.transact(work);}catch(e){caught=e;p=(e as any).recovery?.transaction;}
 assert.ok(p,'must retain transaction/recovery');const expected=mode==='netnoop'?'abc':'acb';assert.equal(r.ids().join(''),expected);const frames:any[]=[];off=observeWrites(f=>frames.push(f));
 if(mode==='safe'){p.rollback();assert.equal(r.ids().join(''),'abc');assert.equal(t.$.x(),0);}else{assert.throws(()=>p.rollback(),/order/i);assert.equal(r.ids().join(''),expected);assert.equal(t.$.x(),0);assert.doesNotThrow(()=>p.inspect());assert.equal(frames.filter(f=>f.origin==='transaction-rollback').length,0);assert.throws(()=>p.rollback(),/order/i);assert.equal(r.ids().join(''),expected);assert.equal(peekInternalTransactionRuntime(t)?.getPendingTurnCount(),1);if(mode==='failed'){assert.ok(caught?.recovery);assert.equal(caught.recovery.callbackError,failure);}p.confirm();assert.equal(peekInternalTransactionRuntime(t)?.getPendingTurnCount(),0);assert.throws(()=>p.rollback());}
 console.log('PASS',mode);
 }finally{off();t.destroy();}
}
