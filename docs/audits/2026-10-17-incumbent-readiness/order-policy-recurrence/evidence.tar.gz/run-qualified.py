from pathlib import Path
import subprocess,json,hashlib,os
r=Path('/private/tmp/inverse-disposition-native');c=r/'candidate';d=r/'order-policy'
cmd=json.loads((d/'pre-policy-command.json').read_text())
cmd.insert(-1,'--testFile=src/enhancers/transactions/native-order-interference.spec.ts')
m={str(p.relative_to(c)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((c/'packages').rglob('*.ts'))}
p=d/'qualified-source-manifest.json';p.write_text(json.dumps(m,indent=2)+'\n');print('source',hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
(d/'qualified-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
env=dict(os.environ,COREPACK_ENABLE_NETWORK='0',NX_DAEMON='false',NX_ISOLATE_PLUGINS='false')
with (d/'qualified.log').open('w') as out:result=subprocess.run(cmd,cwd=c,env=env,stdout=out,stderr=subprocess.STDOUT)
assert all(hashlib.sha256((c/f).read_bytes()).hexdigest()==h for f,h in m.items()),'source changed during run'
print('exit',result.returncode,flush=True)
raise SystemExit(result.returncode)
