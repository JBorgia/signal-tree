import {signalTree,entityMap} from '../candidate/packages/kernel/src/index';
import {restoration} from '../candidate/packages/kernel/src/enhancers/restoration/restoration';
import {undoable} from '../candidate/packages/kernel/src/lib/undoable';
import {getPathNotifier} from '../candidate/packages/kernel/src/lib/path-notifier';
const flush=async()=>{getPathNotifier().flushSync();for(let i=0;i<12;i++)await Promise.resolve();};
const t=signalTree({branch:{rows:entityMap<{id:string;n:number},string>()}},{enhancers:[restoration()]});
try{t.$.branch.rows.addOne({id:'a',n:1});await flush();const off=t.$.branch.rows.tap({onAdd:(_r,id)=>{if(id==='x')getPathNotifier().flushSync();}});undoable(()=>t.$.branch.rows.prependMany([{id:'x',n:2}]));await flush();off();console.log('AFTER',JSON.stringify(t.$.branch.rows.ids()));console.log('HISTORY',JSON.stringify(t.getRestorationHistory()));t.undo();await flush();console.log('UNDO',JSON.stringify(t.$.branch.rows.ids()));t.redo();await flush();console.log('REDO',JSON.stringify(t.$.branch.rows.ids()));}finally{t.destroy();}
