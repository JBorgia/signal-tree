# Slice2 named gate coverage, read-only mapping

Runtime remains transactions.ts SHA8ccc2ed77f5cb018fdaf596730223bb78f967bf948f58327304e9c9642e45ea9. This report maps source assertions; it does not attach unexecuted tests to the combined251 result. New gap probes ran only the specifically named files. Root independently owns exact qualification/source manifests and the three history-redo failures.

## Selection C → X → C

`lib/entity-selection-lifetime.spec.ts` covers retained selection on removal/clear, selected-lifetime revival publication, selection across rekey, and newer outside selection surviving restoration. None performs C→X→C from a structural callback.

New `enhancers/transactions/native-structural-composition-gates.spec.ts`, first test, covers this exact gap. During rollback's onRemove(b), it observes complete installed ids[a,x], authors selection c→x→c, and asserts final activeId c, missing activeEntity, old-a lifetime identity, and zero pending authority. PASS in structural-gaps-first.log at the frozen runtime. No runtime correction was needed.

## Nested settlement from structural delivery

`enhancers/transactions/reentrant-order-v16-controls.spec.ts` tests an observeWrites listener confirming a transaction from a row FIELD notification; `reentrant-order-bookkeeping.spec.ts` tests older settlement during open field capture and reverse-order retry. `lib/entity-semantic-structure-slice.spec.ts` tests nested append/remove/rekey writes from completed prepend callbacks. Neither directly establishes nested settlement during structural tap delivery.

New `native-structural-composition-gates.spec.ts`, second test, closes that specific discriminator: onRemove(b) during structural rollback sees the entire [a,x] target already installed, settles an unrelated older scalar pending turn, observes scalar8→0 without disturbing ids, and asserts both handles become terminal/idempotently rolled back and pending count0. PASS in structural-gaps-first.log.

## Compound inspection, inspect and ordinary Link

Existing `lib/entity-semantic-structure-slice.spec.ts`, upsert/setAll cases, already combines useful inspect contribution, inspected field99, compound structural rejection, restored held lifetime identity and Link's final ordinary payload. It does not inspect membership AND ordering together.

Existing `lib/entity-semantic-topology.spec.ts` C1/C2 combines inspected existence/vacancy with adopted/removed lifetime rollback and ordinary Link. C3 covers ordinary-neutral removal of inspected existence. Existing `lib/entity-inspection-egress.spec.ts` H1/H2 asserts inspected REMOVE/ADD cannot hitchhike on unrelated authored updates; C2/C3/C6 asserts minimal dependency traversal, and R1 covers inspected rekey followed by authored update. Those are valuable compatibility controls, but not the combined order-plus-membership inverse.

New combined gap case is RED. Original test is preserved unchanged as structural-gaps.first-red.spec.ts; its physicalABC expectation is under premise review and must not be used alone to classify a runtime defect. Standalone compound-consumer-trace.ts/mjs/log records the same operations without prescribing physical order. The only explicit order admission is inspection's reorder. Authored setAll preserves surviving C/X relative order and emits no full-order capture. After rejection, held old-A/B are restored and fresh-A/X are gone; physical order is CAB. Ordinary Link also publishes CAB, and a subsequent ordinary B update keeps CAB.

The separately authorized permanent `native-compound-ordinary-order-regression.spec.ts` avoids prescribing physical order. It positively observes ordinary endpointABC; asserts inspection leaves that endpoint untouched; asserts each authored lifetime contribution is inspectable; asserts rollback identities/presence; then requires ordinary endpointABC. It fails only at that last endpoint assertion (line83): actualCAB. Source/log/snapshot are compound-ordinary-first-red.*. One focused run, no repair, no historical-equivalence claim: older production does not necessarily implement the same adopted-lifetime contract. This remains an unresolved consumer gate, not a pass.

## Removal/rekey/placement invalidity and refusal

- `lib/entity-bulk-mutations.spec.ts`: "removeMany THROWS for an id that is not present" plus "...and that failure is ATOMIC — nothing is removed" explicitly validates ids before deletion and proves unchanged membership. This is ordinary producer invalidity, not adopted-lifetime reversal qualification.
- `lib/entity-semantic-structure-interceptors.spec.ts`: supported interceptor prepare failure/reentry for upsert/setAll preserves outer membership, inspected values and a useful later inverse. "occupied rekey destination preserves identities and usable transaction rollback" asserts the public rekey throws without changing either lifetime, followed by useful pending rollback. The getter-fault sibling suite is separately adjudicated; do not count it as a passing alternative.
- `enhancers/transactions/native-foreign-disposition-matrix.spec.ts`: occupied original key after own removal refuses atomically and keeps fresh foreign lifetime; removing that actual conflict lets the same pending turn revive its original lifetime and reverse scalar x. This covers removal inverse invalidity plus useful retry under existing policy.
- `enhancers/transactions/rekey-occupancy-0.spec.ts`: named dependency refusal, unchanged state, retained settlement authority and clearing occupant→same-turn success; also realized occupancy ABA/net vacancy, pending occupancy and newer field carry. These are explicit occupancy refusal controls, not merely forward rekey tests.
- `lib/physical/prepare-structural-target.spec.ts`: "refuses malformed targets without changing live state or authority" covers duplicate keys, unknown subjects and invalid placement at detached target preparation. `causal-runtime/target-transition.spec.ts` adds key-collision/private-all-owner preparation and non-overwriting order-backbone guards.
- `lib/occupancy-successor-realization.spec.ts`: physical99/ordinary7 relocation, placement independent of physical key transfer, and private preparation failure/reentry preserve physical state and usable retry authority. Sparse revival/active transfer asserts shared placement dependencies without synthetic lifecycle callbacks. These directly exercise inverse realization limits.

## Post-install callback throw and recovery

`lib/prepend-publication-boundary.spec.ts` "a postcommit tap throw retains final order and does not poison a later call" asserts installed membership and a useful later ordinary call. `lib/entity-semantic-structure-slice.spec.ts` "callback throw leaves complete membership/order and transaction abort remains useful" separately proves installed ordinary prepend survives its callback error and transaction-abort compensation reverses the structural insertion. Neither claims a recovery handle when compensation succeeds.

`enhancers/transactions/reentrant-order-v16-controls.spec.ts` "a later dependent row write refuses the automatic compensation and keeps a usable recovery handle" asserts observer-installed newer field2, original callbackError, pending count1, recovery.confirm→count0, and retained value2. This is the established post-install dependent-write refusal/recovery behavior. New `native-order-interference.spec.ts` extends failed-callback usable recovery to the authorized interleaved-order refusal, preserving mixed scalar/order state.

## Scope limits

No broad suites were run for this mapping. Exact source qualification of reused tests belongs to root's command/manifests; source inspection alone is not a run. No runtime file was edited during gap testing. The three parent-observed history redo failures remain separate pending control adjudication; they are not repaired or relabeled here. Compound ordinary order remains red and must be resolved or explicitly deferred by the governing slice boundary before closure.
