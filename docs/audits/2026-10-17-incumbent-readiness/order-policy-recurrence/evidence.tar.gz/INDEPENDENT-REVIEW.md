# Independent review: owner-approved interleaved-order refusal

No blocker demonstrated in the bounded order-policy implementation at transactions.ts SHA256 8ccc2ed77f5cb018fdaf596730223bb78f967bf948f58327304e9c9642e45ea9. Before/after hashes match (independent-before.sha256, independent-after.sha256). Candidate is a reconstructed source directory, not a Git HEAD. New spec identity supplied by freeze: 4640c854e38873fea4000da415c6743018aac06e466e052f2149e07a0efb5d0a. This review does not confer release sign-off or broader native semantics acceptance.

## Contract and prior failure

Owner-approved policy: initial ABC; own CBA; independent realized BCA; own ACB; rejection refuses with clear ordering conflict before any rollback publication, leaving ACB and pending inspectable authority. Confirmation/recovery stays usable; unresolved retry cannot silently succeed. No blanket refusal for unrelated fields or established safe inverses. Read docs/review-contract.md, supplied policy, CONTRACT-CONTROLS.md, original root-review/foreign-order scripts and old first-failure log. Old code accepted rollback to ABC; the prior script's then-permitted success-to-BCA branch is historical evidence, not the approved new acceptance assertion.

## Independent executed falsifiers

Fresh esbuild bundles; Node24.15.0; no runtime/test edits. Local independent scripts and their hashes precede execution.

- independent-probe: exact owner ABC/CBA/BCA/ACB; repeated unresolved refusal matches /order/i; order ACB and mixed scalar1 remain; inspect usable; no observeWrites transaction-rollback frames; pending count1; confirm succeeds, count0, subsequent rollback rejects as confirmed.
- Foreign ABA variant BCA then CBA still refuses; net-own-endpoint ABC variant also refuses. Equal endpoints do not discard actual interference.
- Pure order-only netABC version omits the scalar entirely. It still retains pending count1, refuses/retries while preservingABC, confirms to count0. Thus scalar ownership does not mask an empty net order journal.
- No-foreign safe CBA/ACB reverses toABC and scalar0 successfully.
- Callback-throw variant retains the original callbackError in recovery, leaves ACB/scalar1, and supplies a recovery.transaction that remains inspectable/retryable and confirmable. Automatic compensation does not erase state or lose authority.
- independent-lifetime repeats all modes and then opens a fresh safe order transaction on the same tree after confirmation. Its rollback succeeds to the prior committed order and pending count0, demonstrating no lingering order conflict contaminating the next transaction. Every fixture destroys its tree.

All checks pass. Logs: independent-probe.log, independent-pure-noop.log, independent-lifetime.log. Scripts: corresponding .ts files; source and script hashes in independent-*-before.sha256. These include native public order mutations under the established internal realized-context harness; they do not claim an uninstrumented public ingress API.

## Source evidence and interpretation

The collection-order listener records value-free per-transaction/per-owner admissions. Actual independent installed order events mark earlier open own order responsibility; the next own order records a persistent conflict. Distinct authored transaction IDs are treated as independent of one another, not merely absent IDs. Producer setAll emits collection order only when surviving order actually changes, so a suppressed no-op is not fabricated interference.

The conflict is passed to TransactionAuthority.getPendingRollbackPlan. It returns the existing effect-validation-failed cause with a clear 'Collection ordering conflict' explanation before realization/physical compensation. No public cause variant or new API is introduced. Existing structural/scalar planners still handle non-conflicting transactions. Order evidence is retired at confirmation, successful rejection, abandoned capture and quiet cleanup/destroy; no collection-size state snapshot or second ordering authority was added.

Inspection and compensation/restoration origin exclusions agree with existing causal participation/source capture contracts. write-participation.ts explicitly states a realized compensation restores existing authority and is not external truth. This review found no supported restoration replay that establishes new independent authored ordering responsibility; it does not redefine replay as external authority. Direct nested transactions are explicitly unsupported by runtime.transaction. New distinct transaction admissions are handled by the listener, but arbitrary observer-reentrant transaction combinations were source-reviewed rather than exhaustively executed.

## Limits / not run

Root's combined supported/typing gates were ongoing separately. This reviewer did not run broad kernel/release/build/demo/performance gates. No standalone Link delivery probe, exact path-notification subscription probe, heap/WeakMap retention measurement, arbitrary nested observer-reentry matrix or successful retry after conflict resolution was executed here. No in-place repair API/event was invented: repeated unresolved retries refuse, and confirmation is the demonstrated terminal resolution. Root/worker suites must remain separately attributed. Prior field/rekey compiler and exact-admission reviews remain in review-capture; they are not silently upgraded to this source identity without the parent's combined gate.

## Final acceptance qualification

The owner-approved order-refusal repair remains a bounded pass on runtime8ccc2ed77f5cb018fdaf596730223bb78f967bf948f58327304e9c9642e45ea9. This is not whole-candidate acceptance. The separately reproduced compound ordinary-source leak publishes CAB to Link after rejection and preserves CAB on a later ordinary write; see COMPOUND-ORDINARY-LINK-TRACE.md and independent red executable evidence. The combined candidate remains unaccepted for that concrete unresolved failure.

Root reports the observer spec correction8f8aff94 uses valid frame.path instrumentation with a useful positive emission control, replacing invalid frame.meta access. This test-only correction does not change the runtime source qualified by this review, and no new runtime replay was performed for it. Root's combined251 pass is separately attributed to source manifest14712f30...; final all-test manifestd1ff7c33a380d578390879a79e142950d0655920710a818af7d49fe2a017521b additionally includes the separate known-gap and ordinary red regression tests. These root results do not supersede this review's exact executable identities or erase the independently reproduced ordinary leak.
