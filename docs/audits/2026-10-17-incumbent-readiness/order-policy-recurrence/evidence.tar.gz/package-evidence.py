from pathlib import Path
import subprocess,tarfile,io,hashlib,json,shutil
r=Path('/private/tmp/inverse-disposition-native');c=r/'candidate';d=r/'order-policy';a=d/'archive';a.mkdir(exist_ok=True)
repo='/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree';base='f80645c8e73e3a958b43b4214ffb6b6333ea332d'
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',base,'packages'],cwd=repo))) as t:
 old={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile() and m.name.endswith('.ts')}
changed=[]
for p in sorted((c/'packages').rglob('*.ts')):
 rel=str(p.relative_to(c)); data=p.read_bytes()
 if old.pop(rel,None)!=data:
  q=a/'candidate-overlay'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);changed.append(rel)
(a/'changed-files.json').write_text(json.dumps({'base':base,'changed':changed,'deleted':sorted(old)},indent=2)+'\n')
for p in d.iterdir():
 if p.is_file() and p.name not in ['evidence.tar.gz','ARCHIVE.sha256']:shutil.copy2(p,a/p.name)
with tarfile.open(d/'evidence.tar.gz','w:gz') as t:
 for p in sorted(a.iterdir()):t.add(p,arcname=p.name)
p=d/'evidence.tar.gz';h=hashlib.sha256(p.read_bytes()).hexdigest();(d/'ARCHIVE.sha256').write_text(h+'  evidence.tar.gz\n');print(len(changed),len(old),p.stat().st_size,h)
