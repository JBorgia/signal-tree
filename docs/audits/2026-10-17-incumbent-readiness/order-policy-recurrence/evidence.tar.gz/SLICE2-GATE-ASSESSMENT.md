# Slice2 gate assessment

Read-only, October24. Inputs: f80645c8 plan ordered-slices table; 80e6095e prerequisite record; db5b130 evidence README and exact21-file command,239-pass source manifest25812d0428e6cb085b67f4e467b76d061d94bdb59c6c93dcd668cce5ae924e92. No new test execution here. The order-policy revision is later source and cannot inherit those runs as exact-source qualification.

## What the recorded evidence establishes

- C1–C3 and ordinary rekey-vacancy controls are included unchanged in the239. Existing lifetime versus fresh lifetime identity and P99/O7 subsequent transaction controls are included.
- W4 append/prepend, W5 rekey, W7 mixed upsert and W8 mixed setAll have explicit structural/value inverse tests in entity-semantic-structure-slice.spec.ts, including untouched inspected sibling authority. W6 inverse handling is exercised by structural-inverses and update-then-remove-rollback, not a claim of complete restoration migration.
- Completed prepend callback order with nested append/remove/rekey and callback throws is recorded; ordinary inspection chronology, foreign field/rekey/remove/replacement and occupied destination retry are represented.
- Supported interceptor preparation throws/reentry are exercised for mixed upsert/setAll and occupied rekey destination. Private realization failure/reentry, two transfers and restore/field/restore execution dependency controls pass in identified source.
- Point active-key traversal controls at16/1024 pass. Anchor-distance traversal is an existing measured limitation, not evidence that every placement operation is constant-work.
- Types/spec-types and runtime lint were executed at prior identity. They qualify those sources only.

## Remaining focused gates before slice2 closure

1. Freeze the order-policy successor and rerun the exact21-file focused command plus new order-policy tests, with launch/completion manifest verification. This is warranted by a runtime change, not duplicate acknowledgment. Preserve policy first-red and original preapproval assertion separately.
2. Order-policy controls: exact approved refusal leaves ACB, authority and observers unchanged; confirm and failed-abort recovery usable; ABA and before/between/after discrimination; unrelated fields/collections and no-interference successful inverse; repeated unresolved retry cannot drain conflict. Current policy run results are pending, not failures asserted by this assessment.
3. Add or locate exact-source focused **selection C→X→C** callback control. The21-file list and structural-slice callback cases establish placement but do not establish this selection identity rule. Use existing shared-publication selection regression unchanged if available; do not rewrite its expected value.
4. Add or locate explicit **nested settlement from structural delivery** control on this successor. Nested callback writes and nested transact refusal are covered; neither proves settlement reentry. Assert coherent installed snapshots, final authority and retry/error semantics under existing contract.
5. Verify consumer pair for compound structure: inspect and ordinary Link payload must agree with captured authored transition, including inspected add/remove/order plus rollback. Existing minimal egress controls may be reused as focused compatibility tests, but the239 command does not contain entity-inspection-egress or declared-Link structural qualification. A source-only mapping is insufficient where ordinary publication is the central migration claim. Full declared-Link lifecycle/four-framework qualification stays slice4.
6. Supported fault coverage must retain the structural operation's full footprint: upsert/setAll prep controls exist; confirm explicit removal/rekey/placement invalidity and post-install observer-throw recovery are actually asserted, not inferred from passing ordinary forward work. Reuse existing controls if exact assertions cover these; no need a Cartesian explosion of equivalent routes.
7. Independent final review of frozen combined source must address common admission/realization mapping, pure-order policy evidence and cleanup of newly introduced conflict records. Prior reviews remain valid within their exact scopes but cannot approve the new policy implementation automatically.

The unchanged getter-fault suite remains3 red assertions with archived test-premise adjudication; do not label them new corruption or count them as passes. Decide its ledger status explicitly from that adjudication. No broad kernel/framework run is needed merely to close this focused gate.

## Later scope and semantics

Full restoration/hidden-member/retirement audit is slice3. Final GC/collectibility, all four frameworks/Link composition and artifact costs remain slice4/5 obligations; their absence does not itself prove slice2 runtime failure. Protect live obligations now and do not claim final reclamation from map counts.

Nested missing-parent remains conditional: only a concrete supported producer makes it an owner decision. Approved P99/O7 relocation and atomic interleaved-order refusal need no reopening. Successful order retry after an alleged conflict-resolution event needs a governing lifecycle rule if claimed; useful confirmation plus unchanged unresolved retry meets current bounded policy.

Assessment: prior evidence supports substantial slice2 mechanisms, but does not close the gate. Close only after current order-policy source survives the focused recurrence suite and the missing selection/settlement/publication controls are resolved by actual named evidence. A new failure is to be classified by first causal divergence; counts alone do not authorize later slices.
