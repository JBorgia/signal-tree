# Independent compound ordinary-order leak trace

Concrete failure reproduced against transactions8ccc2ed77f5cb018fdaf596730223bb78f967bf948f58327304e9c9642e45ea9. No runtime edits.

Fresh uninstrumented compound-independent-assert.mjs repeats the supplied native/established inspection-context operations, waits Link settlement and then asserts the subsequent ordinary write's published row order ABC. It fails with CAB. This establishes an ordinary egress divergence separately from whether physical CAB alone might be permissible.

Sequence: ordinaryABC (B value4, publishedABC); inspection removes A, adds X, ordersCBX (Link remainsABC); own setAll CAX; reject; Link publishesCAB; later ordinary B5 still publishesCAB. Held original A and B lifetime identities recover, but their ordinary collection order does not. Original raw worker trace remains unchanged; independent source/assert scripts and logs are compound-independent-{trace,assert}.*, hashes compound-independent-before.sha256 and compound-assert-before.sha256.

## First causal divergence

Source-only esbuild onLoad instrumentation prints exact prepareEntityResponsibility capture and ordinary lowering inputs, without editing source files.

The first authored setAll's source-prepared removal of B already carries structuralRecord `{kind:remove,subject:2,key:b,beforeSubject:3,afterSubject:4}`: B is anchored after C and before inspection-only X. Original ordinaryABC requires B between oldA andC. The oldA removal record separately retains its prior ordinary afterSubject:B, showing that ordinary exceptions protect some rows but not the complete order.

prepareOrdinaryTopology's read function in entity-signal.ts:713+ first selects staged/ordinaryTopology exceptions; for B no exception exists, so it falls back to the current physical activeKey and getNeighborSubjects. Inspection reordered physicalCBX without preserving an ordinary neighbor exception for B. Its later own removal converts that physical placement into ordinary structuralRecord through record(remove). This happens before authority disposition or inverse compilation.

Inverse lowering subsequently receives the same B restoration anchors C/X. It does not receive a valid ABC ordinary fact and lose it. The Link consumer then observes the admitted realization/publication produced from those already-contaminated ordinary source facts. Therefore this is not demonstrated as a Link-only missing consumer, or an isolated physical display realization issue.

## Boundary interpretation

Current source has no complete retained ordinary order for this inspection reorder; unexceptional row placement falls back to physical order. The existing per-row ordinary state can store placement fields, but the inspection full-order operation does not populate the necessary ordinary-order evidence for unaffected lifetimes. A claim that the representation already expresses and preserves the required order must account for this missing state; a downstream consumer-only fix cannot recover originalABC from the supplied contaminated B record.

This trace proves the ordinary/physical authority boundary fails in the compound source capture path already exercised by the candidate's admission/inverse design. It does not independently decide the user's recurrence-stop rule or authorize another representation extension. Contract audit must adjudicate whether the existing shared ordinary-fact claim makes this a stop; historical dating or physical-order ambiguity does not remove the demonstrated ordinary Link publication leak. No repair or policy change performed.
