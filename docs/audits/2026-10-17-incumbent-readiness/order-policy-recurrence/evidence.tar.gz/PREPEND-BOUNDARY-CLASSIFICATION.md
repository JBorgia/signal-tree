# Independent causal classification: prepend redo gate failure

Concrete current regression against production is demonstrated. It predates the successor/segmentation/order-policy repairs: root's reconstructed slice2 overlay6bd control has the same 3 failures /9 passes, while exact production87 passes12/12. Those gate runs are root evidence, not this reviewer's own executions.

## Independent raw source trace

Executed source-traced esbuild bundle with history-only restoration, no transactions enhancer: initial row a; designated prepend x; onAdd flush; undo; redo. Runtime source files were not edited. Trace plugin prints the existing createStructuralEffectMeta arguments; script, builder, hashes and raw log are prepend-boundary-trace.{ts,mjs,log}, build-prepend-boundary-trace.cjs and prepend-boundary-before.sha256.

Raw trace before history capture:

- Physical publication effect for x: add subject2, afterSubject1. Correct physical placement is x before a.
- Same metadata's ordinaryChanges record for x: add subject2, beforeSubject1. That says x after a.
- Immediate state is [x,a]. HISTORY.__effects stores beforeSubject1, while its state snapshot is [x,a].
- Undo produces [a]. Redo produces [a,x].

The first observable causal divergence is source ordinary responsibility versus final physical placement, before capture/history/redo. History then faithfully retains the wrong ordinary anchor; the trace does not demonstrate a redo-sort origin for the error.

## Source boundary

entity-signal.ts:845-878 constructs fresh-add ordinary evidence using pre-frame tail as beforeSubject. addMany commits that evidence at2120, then prepend performs final moveToFront at2143. Publication at2190-2196 correctly uses final getNeighborSubjects for physical structuralEffect, but attaches committed.ordinaryChanges built before that placement. restoration.captureEffects at4187+ selects ordinaryEntityEntries first; ordinaryEntityEntries replaces structuralEffect with the ordinary record's structuralRecord. This is where the correct final physical publication anchor loses authority to the stale ordinary source fact. A fresh prepend does not require a surviving-row order delta to carry the missing placement: its ordinary add responsibility itself needs the correct placement.

## Boundary disposition

This is a source-placement handoff left incompatible when ordinary responsibility became authoritative in slice2. It is not evidence that the later exact-record pairing or selected inverse ordering representation cannot express the required fact, and it does not by itself establish recurrence of their specific prior inverse-order or notification-correlation defects. Whether this violates an already-claimed general shared-fact guarantee is a separate contract-audit determination. It also is not merely unrelated production debt: the experimental candidate fails existing history-only behavior that production preserves.

A minimal correction belongs at the shared compound source admission/placement boundary and must be staged before publication/reentrant flush, with the same immutable final ordinary placement facts shared by capture and notifications. This statement identifies the missing property; it does not authorize a patch or prescribe a broad restoration architecture. Changing redo sorting/history policy, relaxing the existing assertions, or treating the state snapshot as alternative authority is not justified by this evidence.

Acceptance therefore remains bounded: no new order-policy runtime failure is demonstrated, but the candidate's existing consumer gate regression remains unresolved pending the parent's scope/admission decision. If this proven shared-source incompatibility is admitted as missing minimal inverse preservation, it is an unmigrated source consumer boundary; if it is deferred, acceptance must explicitly exclude the failing history consumer path. No new semantics are needed to state [x,a] redo preservation.


## Exact identity and assignment qualification

Trace source identities: entity-signal.ts 0209436bdfac69ff02ead1affa6db2fcb82e5af0d3d07e72a962ba583de8c42b; restoration.ts 368d408f70a82577ed3ae882577c627a1576c9ae971e929d09100a15b3846ed5; script a562fe7c82be989744318c0626b332a5be8ebe7a4ba23f56200a055e929af291. Additional helper/transactions/builder hashes in prepend-boundary-additional.sha256.

The exact last-correct-to-first-wrong consumer assignment is ordinary-entity-entries.ts:27: `meta: { ...clean, structuralEffect: change.structuralRecord }`. `clean.structuralEffect` still contains final afterSubject:a; this assignment overwrites it with the ordinary record's beforeSubject:a. The wrong ordinary record originated at entity-signal fresh-add beforeSubject:tail (875), then prepareOrdinaryTopology copies that placement into next (774-775) and record(add) (777). Thus the projection assignment reveals an already-inconsistent source pair; it does not create the stale anchor itself.

A writer-neutral invariant can preserve both channels: the compound source's admitted ordinary add placement must describe its final authored placement before any source observer or notification can flush. This does not require a prepend-specific exception in history or relaxing ordinary-authority selection. This report does not establish whether an implementation can satisfy that invariant within currently approved effort/scope, and does not decide the contract's recurrence-stop classification. Historical dating alone does not excuse violation of a general already-claimed shared-fact guarantee.
