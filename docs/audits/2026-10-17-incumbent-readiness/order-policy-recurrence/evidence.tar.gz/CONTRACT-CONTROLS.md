# Approved interleaved-order refusal: discriminators

Read-only implementation review, 2026-10-24. Governing owner approval: ABC → own CBA → independent realized BCA → own ACB; rejection must refuse atomically, retain ACB and pending authority, emit no rollback publication, explain ordering conflict, permit confirmation/recovery. No runtime/test edits or executions here.

## Mandatory positive refusal witness

Assert exact ABC/CBA/BCA/ACB sequence. Retain row references and field values. Clear notification/event logs immediately before rollback. Assert clear ordering conflict through established error surface; ACB, rows, ordinary truth and authority unchanged; no value/order/Link rollback delivery. inspect remains usable; repeated unresolved retry refuses identically without advancing frontiers or dropping evidence. Confirm then succeeds and repeated confirm remains terminal-idempotent. A separate callback-throw/failed-abort variant must expose usable recovery.transaction and preserve callbackError under existing rollback-error semantics.

## Prevent blanket refusal

- No foreign write: own CBA → own ACB rejects successfully to ABC.
- Foreign field-only write between own reorders: do not invent order interference; preserve the foreign field according to existing field disposition while normal order inverse executes or existing independently specified dependency refuses.
- Foreign order on another collection: collection-local evidence must not block this collection.
- Foreign order before first own order: it is the actual own inverse baseline; do not classify it as between-own interference.
- Foreign order after last own order: must obey already-existing newer-order/frontier conflict contract; do not infer this policy’s between-own marker is a full solution for it.
- Ordinary field-only transaction with unrelated foreign order: keep existing safe inverse behavior.
- Existing rekey/placement, two-transfer, interleaved-field restore and P99/O7 controls remain unchanged. An incidental order snapshot is not explicit order authorship.

## Identity, admission and atomicity

- Distinct frontier/revision with equal final order (ABA) must not erase real interference merely by value comparison. A true suppressed no-op should not create fictitious foreign order responsibility.
- Foreign order may be delivered synchronously during reentry; classify from installation/admission identity, not observer flush time.
- Multiple own/foreign order segments must retain the first conflict and all still-live obligations; delayed older capture must not overwrite newer identity.
- Preparation throw before foreign installation must create no conflict marker. A foreign installed mutation followed by observer throw must retain its actual responsibility.
- Mixed scalar/entity unit: refusal before *any* inverse install; no scalar restoration followed by order error.
- Reentrant refusal listeners may author newer writes; attempted refusal must not restore an earlier snapshot over them. Receipt/error inspection cannot mutate terminal authority.

## Retry and retirement

Repeated retry without an actual conflict-resolution event cannot become success because flush, inspection, history eviction or serialization discarded metadata. Confirming the affected pending transaction is a supported terminal resolution; subsequent rollback must obey terminal lifecycle, not retry its old plan. Tree destruction must detach subscriptions and retire order evidence only when no live authority remains; retained handles/receipts must not retain tree graphs accidentally.

Current candidate subscribeCollectionOrder (transactions.ts 2734–2755) ignores captures without this transaction’s metadata and compresses own order endpoints to first-before/latest-after. Therefore an interference mechanism must observe foreign installations independently and correlate by collection plus active operation chronology. Do not turn foreign captures into own pendingOrderDeltas. Current confirm cleanup (4529) and destroy cleanup (4890) must retire any added evidence too. Atomic rollback planning reads pendingOrderDeltas around4588: refusal belongs before realization installation, preserving current lifecycle.

## Exact boundary still requiring care

Owner approval does not define an in-place repair API or a concrete event that makes the already-interleaved historical conflict disappear while this same pending transaction remains open. Do not invent 'set order equal BCA/ACB' as resolution: equality does not prove retirement of responsibility. For this finite implementation, unresolved retry may continue refusing; confirmation is useful. If claiming successful rollback retry after an external operation, first establish the existing supersession/frontier rule that actually retires this conflict. This is a conditional semantic question only if that success is required; it need not block implementing the approved refusal plus confirmation path.
