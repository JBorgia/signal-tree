# Approved between-own order interference refusal

Runtime frozen: transactions.ts 8ccc2ed77f5cb018fdaf596730223bb78f967bf948f58327304e9c9642e45ea9. Only transactions.ts changed for the policy; new regression file is native-order-interference.spec.ts. Root owns the original239 archive/manifest and qualified combined runs; none were overwritten by this worker.

## Why the change is needed

Collection-order capture previously retained only first-own-before/latest-own-after. ABC→ownCBA→independentBCA→ownACB therefore appeared to be an uninterrupted own ABC→ACB contribution. Its inverse could successfully overwrite the hidden independent order. Owner approved atomic refusal for this interleaving, with unchanged physicalACB, pending authority and useful confirmation/recovery. Endpoint equality/ABA cannot retire this independent admission.

The source collection-order callback runs synchronously after order installation and before entity notifier publication. It is not notifier delivery-time inference. A preparation failure never publishes this capture. The policy records a value-free monotonic admission number for each observed order operation, collection-local own/independent sequence state, and the first between-own conflict. Independent means any other writer, including recognized other transaction identity; direct nested transact remains unsupported and no malformed metadata stream is used to prove a bug. Foreign fields emit no order capture. Foreign-before-first-own produces no between-own marker.

The existing TransactionAuthority planner receives the immutable conflict fact alongside ordinary queued evidence. It refuses before any compensation installation via the existing effect-validation-failed surface, with a clear collection ordering conflict message. No public cause kind or public API was added. Capture endpoints remain available for inspection, confirmation and ordinary safe inverses. The marker remains until this pending transaction settles; no external equality-based or invented in-place retry resolution was introduced. Evidence is deleted on terminal settlement/abandonment and tree cleanup.

## Participation boundary

Inspection is excluded because it has no authored/independent truth authority. Restoration and transaction-rollback origins are excluded consistently with existing source/inspection/evidence consumers: lib/write-participation.ts:isCompensationWrite documents rollback as realized compensation restoring SignalTree's previously captured authority, explicitly not external truth; restoration.ts stamps its replay origin and participation. This is a provenance boundary, not a claim that arbitrary supported reentrant replay compositions are already proven. A concrete supported replay-origin operation that introduces independently protected ordinary order would require separate evidence/adjudication; no such trigger was asserted by this implementation.

## Evidence and corrected instrumentation

policy-first-red.log: prewritten12-test file initially contained8 controls; four between-own/ABA/no-op expectations failed, four safe controls passed, before runtime editing. The original preapproval policy hypothesis and production-first.log remain separately preserved.

The expanded policy file now has12 tests: exact ACΒ/refusal, own endpoints canceling toABC, foreign orderABA, pure order-only no-op pending authority, repeated refusal, no rollback events, idempotent confirmation, failed-callback recovery, failed preparation, useful safe own/field/other-collection/foreign-before-own/scalar-only inverses. focused-final.log originally recorded5files46passes on frozen runtime.

The initial no-publication observer incorrectly read frame.meta and its callback returned a number. Root's configured spec gate exposed this. That original test is preserved as native-order-interference.invalid-observer.spec.ts; its no-publication assertion is not evidence. The corrected file records every actual ObservedWriteFrame.path, proves both streams nonempty before clearing, then asserts no frames or notifier values after the refused attempt. The callback now returns void. policy-valid-observer.log records12passes; valid-observer-spec.sha256 gives the corrected identity8f8aff94d88ab39a15ab55b432c6df70268f12e51a29fb108c9cece5ac6ee15d. Runtime remained unchanged.

source-types-final.log is clean kernel source typing. new-gap-spec-types.log is clean targeted configured spec typing for the corrected order spec plus the two additional gap files, not a claim that the full existing spec ratchet is clean. Root owns that broader gate.

Subsequent gate coverage findings are in SLICE2-GATE-COVERAGE.md. SelectionABA and nested structural settlement probes pass; compound ordinary order publication remains red in native-compound-ordinary-order-regression.spec.ts. That first-red source/log and the earlier overstrong physical-order hypothesis were preserved separately. No dependent runtime repair or expectation weakening occurred.
