# Approved interleaved full-order policy

2026-10-24. Owner replied "you are authorized" to the request to record atomic
refusal with usable settlement authority. This resolves the decision pending at
db5b130ebe9c02d7e31973f23d45cb6b6e82972c; no other compatibility change is implied.

Initial ABC; own explicit full-order CBA; independent realized full-order BCA;
own explicit full-order ACB. Rejection must refuse before installing any inverse:
current ACB, scalar/row state, inspection and pending authority survive; no rollback
state publication. Existing error/recovery surface must explain ordering conflict.
Unresolved retries keep refusing; confirmation remains usable. Retry success
requires genuine conflict resolution, not equality, flush or metadata eviction.

This is not blanket refusal for foreign field writes, incidental topology or a
foreign order in another collection. Existing established safe inverses remain.
Original production ABC result and the unapproved BCA-or-refusal hypothesis remain
preserved with their original source/logs. They are not rewritten as a prior pass.
No API, activation, budget increase or release is authorized. Later slices remain
gated on successor inverse qualification and review. B remains closed.
