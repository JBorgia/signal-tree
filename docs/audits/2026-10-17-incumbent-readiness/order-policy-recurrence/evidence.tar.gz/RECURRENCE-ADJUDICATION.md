# Recurrence and scope adjudication

Read-only independent interpretation, October24. Inputs: source-traced COMPOUND-ORDINARY-LINK-TRACE.md, PREPEND-BOUNDARY-CLASSIFICATION.md; preserved raw sources/logs; f80645c8 plan and80e6095e prerequisites. No runtime edits or reruns here. Supplied execution claims remain attributed to their authors.

## Verdict

The compound ordinary-order finding triggers the recurrence stop. The prepend mismatch independently blocks slice2 closure; its history consumer being scheduled for a slice3 audit does not permit slice2's already-migrated source to supply inconsistent ordinary placement. Neither finding authorizes another repair automatically.

Frozen plan slice2 boundary is “W4–W8 structural branches; complete operation combines current structure/order facts with value result, retaining existing policies”; useful success is “Mixed add/remove/rekey/reorder, selection and callback snapshots coherent.” Its consumer matrix makes responsibility use ordinary authored facts and prohibits reconstructing adoption from display. Prerequisite80e says explicit ordinary presence, lifetime, key and ordering facts must accompany installation, and specifically: “whole physical rows cannot grant authority.” Its recurrence rule says stop when an “already-covered shared correction loses the same facts again or requires caller-specific exceptions.”

Current successor claims ordinary/physical separation across source admission, capture, selected inverse compilation and publication. Compound setAll and prepend are W8/W4 already in that claimed structural migration. This is not merely a new inverse producer in an unmigrated slice3 writer.

## Compound evidence

OrdinaryABC; inspection removeA/addX/orderCBX; own setAllCAX; rejection publishes ordinaryCAB, later ordinaryB update stillCAB. Held original lifetimes recover. Independent ordinary-only assertion reproduces without any physical-order expectation.

First loss precedes inverse execution: source ordinary removeB record contains physical C/X neighbors because unchanged ordinary B falls back to getNeighborSubjects after inspection reorder. The original ordinary order fact is unavailable to downstream lowering. Thus neither a Link caller patch nor another inverse sort corrects the causal boundary. This repeats the central prohibited substitution of physical display for ordinary authority, now for placement instead of field payload/key occupancy. A per-row exception representation that leaves unexceptional rows dependent on inspected physical neighbors has not demonstrated completeness for compound full-order inspection.

This is sufficient recurrence evidence even though original6bd source already contains the weakness. Historical origin distinguishes incremental cause, not whether the newly claimed shared structural mechanism has covered it. Allowing unlimited newly-found instances in covered W4–W8 would nullify the stated recurrence boundary.

## Prepend evidence

Fresh prepend x produces correct physical add afterSubject:a and contradictory ordinary add beforeSubject:a in the same metadata. History chooses the ordinary record, so undo/redo returnsax rather thanxa. Production control passes; experimental6bd/current share the regression. Physical and ordinary topology coincide for this ordinary fresh prepend, so no semantic ambiguity explains the mismatch.

Restoration consumer audit remains slice3, but the producer already violates the slice2 complete-operation placement fact before that consumer runs. At minimum this fails slice2's required minimal useful inverse/compatibility gate. It alone need not disprove segmented capture or private sequential validation; it exposes a separate source-finalization obligation. Combined with compound recurrence it cannot justify continuing with an isolated prepend adjustment under existing authorization.

## Original physicalABC premise

The initial new test demanding physicalABC after the compound rejection is overstrong without further authority. Inspection's surviving C-before-B display placement may remain outside explicitly reversed facts. Therefore physicalCAB alone is not established corruption. Preserve the original red test as a premise question; do not erase it or count its physical assertion as a proven defect.

OrdinaryABC is a separate requirement: inspection-only reorder must not enter ordinary publication. The own setAll preserved surviving C/X relative order and emitted no explicit own full-order capture; its removals/admissions cannot implicitly adopt inspected C-before-B. The approved “restore ordinary topology within authored footprint; unrelated inspection untouched” requires ordinary B restoration from ordinary placement facts while permitting distinct physical display. The independently reproduced ordinaryCAB publication establishes the defect without selecting physicalABC or reopening successor policy.

## Consequence

Pause dependent runtime work. Preserve8ccc source, original assertions and both causal traces. A successor needs a finite explanation of how ordinary placement survives inspection reorder, how complete compound placement is finalized before responsibility installation, and how the same facts reach capture/inspection/publication/history. If representing untouched ordinary placement requires a broader topology mechanism, present that expansion explicitly. No new public semantic decision is needed to establish these two ordinary-source defects. Do not resume later slices, weaken history/Link assertions or promote snapshots to a second authority.
