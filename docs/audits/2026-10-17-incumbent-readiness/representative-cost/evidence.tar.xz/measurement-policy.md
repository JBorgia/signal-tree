# Measurement contract

Use the generator for the question being asked, on identified built/installed
artifacts. Report source claim, artifact hashes, environment, workload and raw
results. A build receipt and a source-commit sidecar are different evidence.

- Give competing arms the same observable task and meaningful success checks.
  Validate intermediate results when timing intermediate operations. Endpoint
  agreement does not certify every timed write.
- Name what is timed: primitive execution, framework stabilization, rendering,
  transfer or application startup. Those costs are not interchangeable.
- Compare repeated independent samples and distributions. Use same-arm controls
  to assess noise; do not choose favorable retries or call an A/A band a confidence
  interval. Record first failures and diagnose changes.
- Isolate arms to avoid shared runtime history. A browser context is not proof of
  a fresh renderer process. Describe the isolation actually established.
- Distinguish whole heap, filtered snapshot self-size, retained/dominator memory,
  per-size slopes and positive-only attribution. Do not add incompatible metrics.
- Destroy bounded-lifetime stores. Finite cleanup/GC samples do not prove no leaks
  or bounded growth for every long-lived workload.
- State host contention and throttle settings. Busy runs are development evidence;
  a CDP throttle factor is not a calibrated device class.
- Consumer bundle fixtures must verify behavior and use the intended production
  defines. State which peers are external. A facade fixture differs from a neutral
  kernel budget fixture; simple handwritten undo is not semantic equivalence to
  the full restoration contract.
- Do not raise a ceiling merely because it fails. Attribute cost, test safe
  reductions, and justify any budget change independently.

Executable authorities: `tools/check-bundle-budget.mjs`, the current gate registry
and each benchmark's own protocol. Historical findings remain in the
[design-thesis record](../architecture/design-thesis-and-benchmarking-rules.md);
its old API names, numbers and proposed remedies are not current instructions.


## Acceptance policy

Measurement validity and product acceptance are separate decisions. Bundle
ceilings detect regressions and protect ordinary consumers; they do not by
themselves establish which implementation is best. A larger artifact can be
accepted when its required behavior and representative production costs justify
it. Lower populated-state heap does not erase download/startup cost, and a
smaller empty fixture does not establish better application performance.

### Define the comparison before measuring

Record the supported behavior, exact baseline, candidate, application profiles,
workload sizes, operation frequencies, observation boundaries and acceptance
criteria before the decision run. Use identified application traces or fixtures
where available. Otherwise label synthetic scenarios and frequency assumptions;
do not present them as measured adoption or usage. Include:

- Ordinary store use without optional transaction/restoration features.
- Populated entities at several justified sizes, including point writes and churn.
- Transaction-heavy use: successful settlement, refusal, recovery and overlapping
  contributions, with capture/maintenance drain explicitly accounted for.
- Many bounded-lifetime trees: construction, population, teardown and cleanup.
- Framework stabilization/rendering when the claim concerns application latency.

A smaller bounded study may omit profiles, but must identify the omissions and
cannot support a general production-superiority claim. Do not compare successful
settlement with refusal as equal work. Report capability gains separately.
Required correctness cannot be traded away for speed or size.

### Keep costs separate

Report absolute values, relative changes, sample distributions and uncertainty
for each relevant profile. Do not combine incompatible units into one score.

| Dimension | Required distinction |
| --- | --- |
| Artifact | Compressed transfer bytes, emitted code, external peers and optional-module inclusion; parse/startup claims require their own measurements |
| Fixed runtime | Per-process and per-tree overhead; empty-tree cost is a control, not the whole decision |
| Populated state | Tree count, row/leaf count and payload shape; measure scaling rather than assume linearity |
| Responsibility | Pending-owner count, overlap, recovery dependencies and terminal cleanup |
| History | Explicit retention configuration, separated from correctness obligations |
| CPU/latency | Ordinary operations, settlement, churn and construction; distinguish synchronous work, drained work and rendering |
| Cleanup | Pre/post-drain and destruction checkpoints, retained references and GC method; counters are not heap bytes |

Use absolute differences to explain impact: microseconds per operation, bytes
per artifact and heap deltas at stated sizes. Any application-level extrapolation
must disclose operation frequencies and assumptions; benchmark percentages are
not automatically application slowdown percentages. Benefits for transaction
users do not automatically compensate consumers who never enable that feature.

### Decision rules

1. Apply the measurement rules above before interpreting a difference. If noise
   or incomplete observations prevent a conclusion, record it as unresolved.
2. Predeclare meaningful workload-specific latency, memory, growth and artifact
   constraints. There is no universal percentage threshold or default overall
   winner. If no defensible constraint is available, report characterization
   rather than inventing a performance pass/fail verdict.
3. Inspect unintended optional dependencies, duplicated work and obsolete paths;
   test plausible safe reductions. Do not contort required semantics to save
   bytes, or require endless optimization before a deliberate tradeoff decision.
4. Keep results by profile. Application-specific weighting requires disclosed
   evidence or assumptions and sensitivity to alternative mixes. Neither equal
   weights nor maintainer estimates establish a universal product ranking.
5. A failed executable budget remains failed until an explicitly approved policy
   change is implemented and the resulting artifact passes. It blocks sign-off
   under the current budget; it does not alone reject the architecture. Smaller
   heap or faster rollback does not waive an unrelated artifact failure.
6. Owner approval of a tradeoff must name the added cost, required benefit,
   affected consumers, unresolved limits and proposed ceiling/headroom where
   applicable. Approval of a bundle ceiling is not approval of CPU, heap or
   correctness regressions. Existing explicit approval remains valid in scope.

If observed results motivate different acceptance criteria, preserve the original
verdict and record the policy revision explicitly. A new empirically selected
threshold requires independent validation; do not select it and claim validation
from the same samples. Do not rerun to obtain favorable outcomes.

### Decision record

Use the existing task/research record, not a new permanent reporting system.
Include source/artifact identities, commands and environment; supported behavior
and omissions; chosen profiles and their provenance; predeclared criteria; raw
results and distributions; cost attribution and reduction attempts; beneficiaries
and disadvantaged profiles; independent review for consequential architecture;
and the owner disposition with any remaining blockers. Reference existing sealed
measurements when applicable instead of rerunning unchanged work.

This policy adds no numeric ceilings and grants no release, API or compatibility
authority. The executable budget remains the sole source of bundle limits.
