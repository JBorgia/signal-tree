# Independent measurement review

Reviewer: cost_review, independent agent. No runtime or evidence files edited.

Before campaign: verified all110 incumbent and248 candidate artifact hashes;
found shaped empty fixture, inaccurate older-first refusal label, missing separate
capability probe and conflated pending/enhancer heap. Corrections recorded before
campaign at a67b5720. No preferred performance verdict supplied.

After campaign: independently verified324distinctprocesses. Required uncertainty
classification to include each decision arm's own range in addition to A/A and
between-arm overlap; summary corrected, three direction classifications became
unresolved. Original samples unchanged. Identified negative whole-process pending
increment as non-attributable and declined any cleanup/leak inference from
postdestroy residuals. Separate diagnostics demonstrated benchmark-frame retention.

Heap-v2: no remaining harness blocker. Verified84distinctprocesses and weakAlive=0
in every sample; synchronous helper scopes remove demonstrated retention. Direct
pending-state assertions now included. Ordinary live candidate deltas independently
recomputed as5560/4920/5144bytes across10trees at100/1000/10000rows. Pending10k net
heap increments remain negative(-47072/-43320), so isolated owner storage remains
unresolved. WeakRefs establish sampled tree collectability, not absence of retained
children/metadata. Compare arms within v2; do not splice absolutev1/v2 checkpoints.
No additional sampling warranted. No general speed/cleanup/superiority claim.

Parent verification: recomputed summary, checked zero assertion failures, verified
all358artifacthashes before and after measurement, verified zero weakAlive in84v2
records and reproduced reported medians. Reviewer findings are incorporated rather
than treated as product acceptance.
