import assert from 'node:assert/strict';import {quiesce} from './heap-quiescence.mjs';
globalThis.ngDevMode=false;
const [arm,mode]=process.argv.slice(2);
const dir='/private/tmp/st-new-key-cost-20261018/'+(arm==='candidate'?'shared':'incumbent')+'/dist/packages/kernel/dist/index.js';
const {signalTree,entityMap}=await import(dir);
const baseline=await quiesce();let held=[],refs=[];
function make(){const created=[],weak=[];for(let j=0;j<10;j++){const t=signalTree({fields:Object.fromEntries(Array.from({length:16},(_,i)=>['f'+i,0])),rows:entityMap()});t.$.rows.setAll(Array.from({length:10000},(_,i)=>({id:String(i),name:'row'+i,value:0})));assert.equal(t.$.rows.count(),10000);created.push(t);weak.push(new WeakRef(t));}return {created,weak};}
if(mode==='helper'){const r=make();held=r.created;refs=r.weak;}else{for(let j=0;j<10;j++){const t=signalTree({fields:Object.fromEntries(Array.from({length:16},(_,i)=>['f'+i,0])),rows:entityMap()});t.$.rows.setAll(Array.from({length:10000},(_,i)=>({id:String(i),name:'row'+i,value:0})));held.push(t);refs.push(new WeakRef(t));}}
const live=await quiesce();
function destroy(){for(const t of held)t.destroy();}
if(mode==='helper')destroy();else for(const t of held)t.destroy();
held=[];const destroyed=await quiesce();
console.log(JSON.stringify({arm,mode,baseline,live,destroyed,alive:refs.map(r=>r.deref()!==undefined)}));
