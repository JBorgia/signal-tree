# Frozen-model measurement result

Command: `node /private/tmp/ordinary-order-next/measure/run.mjs > /private/tmp/ordinary-order-next/measure/FIRST-RUN.log 2>&1`. First execution exit 0; 42 measurement rows. Source identity is PRE-RUN.sha256. No model edits or reruns.

At N=16/256/1024, fixed local field divergence retains one sparse exception versus N snapshot records. Cleanup visits respectively 1 versus N, releasing zero because ordinary and physical fields still differ.

After reverse-order physical divergence and actual physical convergence, both representations still retain N ordinary records immediately after install. Cleanup visits N and releases N. Sparse install does not prune the already existing exceptions on this path. The preregistration allowed possible install-time release; the measured result is zero release at install and N release at cleanup.

After full divergence, a local field write and its inverse leave unrelated reversed physical order in place. Cleanup visits N and releases zero for both representations. This is a concrete N scan with no storage retirement. Current semantic divergence remains necessary after the recovery lease drains.

Repeated local divergence/convergence cycles1/8/32 end with equal O/P, zero ordinary storage and zero recovery leases. Accumulated phase counters are retained rather than collapsed into a constant-cost claim. Staggered leases demonstrate the second removed member remains recoverable after the first lease drains; restoring it and draining the second releases all internal obligation facts. The first removed lifetime stays absent. Old lifetime descriptors remain externally held and are counted separately.

Prepare, install, cleanup, verification, inverse-descriptor and retention counters have distinct phase namespaces. The unchanged model's cleanup keys have a redundant `cleanup.cleanup.*` prefix. Reporting/assertion/JSON work and caller descriptor creation are excluded; descriptor sizes are stated. The retained report is taken after each row's counter snapshot, so that last report's own retention scan is not included in the stored counters (earlier explicit retention reports are). These are selected instrumented operations and internal record counts, not complete allocations, CPU, heap, garbage collection, public lifetime authorization or a native implementation result.
