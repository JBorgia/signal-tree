import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {Model,add,remove,field,inverseIntents} from '../model.mjs';
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(new URL('../model.mjs',import.meta.url))).digest('hex'),'bdb00609a27f104d3de837c644050741d403e1bf6c5ff138ad8463414af6edff');
const rows=[],phase=(m,p,fn)=>m.counts.during(p,fn),storage=m=>m.ordinary.retained().ordinaryRecords;
function install(m,o=[],p=o){const plan=phase(m,'prepare',()=>m.prepare(o,p));return phase(m,'install',()=>plan.install());}
function cleanup(m,name){const before=storage(m),old=m.counts.read();phase(m,'settlement',()=>m.drain(name));const now=m.counts.read();return {before,after:storage(m),released:before-storage(m),visited:(now['cleanup.cleanup.exceptionEntriesScanned']??0)+(now['cleanup.cleanup.snapshotEntriesScanned']??0)-(old['cleanup.cleanup.exceptionEntriesScanned']??0)-(old['cleanup.cleanup.snapshotEntriesScanned']??0)};}
function init(kind,n){const m=new Model(kind),lives=Array.from({length:n},(_,i)=>m.life('k'+i,i));install(m,lives.map(x=>add(x)));m.counts.reset();return {m,lives};}
function check(m,o,p=o){m.verify();assert.deepEqual(m.state().map(x=>x.id),o.map(x=>x.id));assert.deepEqual(m.state('physical').map(x=>x.id),p.map(x=>x.id));}
for(const kind of ['snapshot','sparse'])for(const n of [16,256,1024]){
 for(const cycles of [1,8,32]){const {m,lives}=init(kind,n),[a,b,c]=lives,perCycle=[];for(let i=0;i<cycles;i++){
  const old=m.counts.read();install(m,[],[remove(a),add(a,{next:c.id})]);check(m,lives,[b,a,...lives.slice(2)]);const divergentRecords=storage(m);
  install(m,[],[remove(a),add(a,{next:b.id})]);check(m,lives);const beforeDrain=storage(m),drain=cleanup(m,'none');assert.equal(storage(m),0);assert.equal(m.leases.size,0);
  const now=m.counts.read();perCycle.push({divergentRecords,beforeDrain,drain,preservationEntries:(now['prepare.ordinary.preservationEntriesScanned']??0)-(old['prepare.ordinary.preservationEntriesScanned']??0)});
 }const retained=m.retained();rows.push({workload:'local-order',kind,n,cycles,perCycle,retained,counts:m.counts.read(),externalDescriptors:n,externalFactRoots:0,currentDivergence:false});}
 {const {m,lives}=init(kind,n),oldB=lives[1],d=lives[3],freshB=m.life(oldB.key,777);let first=install(m,[remove(oldB)]),second=install(m,[remove(d)]);m.retain('first',[first]);m.retain('second',[second]);install(m,[add(freshB)]);first=undefined;const firstDrain=cleanup(m,'first'),afterFirst=m.retained();assert.equal(afterFirst.leases,1);assert(afterFirst.internalRetainedFacts>0);
  for(const intent of [field(oldB,999),{kind:'rekey',id:oldB.id,key:'wrong'}]){const rev=m.revision;assert.throws(()=>install(m,[intent]),/missing lifetime/);assert.equal(m.revision,rev);}
  const inverse=phase(m,'inverseDescriptor',()=>inverseIntents([second],m.counts));install(m,inverse);second=undefined;const expected=[...lives.filter(x=>x.id!==oldB.id),freshB];check(m,expected);assert.equal(m.state().at(-1).n,777);assert(m.state().some(x=>x.id===d.id));assert(!m.state().some(x=>x.id===oldB.id));const secondDrain=cleanup(m,'second'),retained=m.retained();assert.equal(retained.leases,0);assert.equal(retained.internalRetainedFacts,0);assert.equal(storage(m),0);
  rows.push({workload:'same-key-staggered-leases',kind,n,firstDrain,afterFirst,secondDrain,retained,counts:m.counts.read(),externalDescriptors:n+1,externalHeldOldDescriptors:2,externalFactRoots:0,externalInverseDescriptorFacts:inverse.length,secondRecoveryUseful:true,currentDivergence:false});
 }
}
fs.writeFileSync(new URL('./RESULTS.json',import.meta.url),JSON.stringify({rows,scope:'finite unchanged model; selected instrumented work not CPU/heap/GC; trusted add inputs; caller descriptors/output allocations excluded'},null,2));console.log(JSON.stringify({rows:rows.length,order:rows.filter(x=>x.workload==='local-order').map(x=>({kind:x.kind,n:x.n,cycles:x.cycles,firstCycle:x.perCycle[0],lastCycle:x.perCycle.at(-1)}))}));
