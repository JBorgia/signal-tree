# Review scope and frozen premises

Task: extend lifecycle/work characterization of the two frozen ordinary-order models and specify a source-owner/path design. Native repair remains paused. Models are evidence, not a public API or new settlement authority.

Owner's current premises (October 24 conversation):
> Inspection must not overwrite ordinary placement; ordinary writes, rollback and redo must update or consume it under their existing authority.
> capture must retain enough ordinary placement information before inversion, and every inverse consumer must use it consistently.
> The recurrence stop and later-slice gates remain in force.

Prior approved semantics remain: physical 99 / ordinary 7 for the relocated live lifetime; successor-first lifetime-sensitive placement; complete prepend installation before callbacks; atomic refusal for an intervening independently authored full order. No new interpretation of payload, absence, authority, retries or declaration eligibility.

Independent questions:
1. Do workloads distinguish processing genuinely changed/converging facts from unrelated scanning? Are capture/install/drain costs and current divergence, live obligations, external roots reported separately? Is same observable work performed for both arms? Any counter omitted or misleading retention interpretation?
2. Does the proposed single source owner cover actual physical mutators and all six paths/eleven families, without a second authority, downstream consumer repair, or blanket whole-collection work? Identify concrete omissions, especially failed/reentrant preparation, direct order, hidden collections, restore/frontier and retirement.
3. Do the mechanism and source mapping explain each of the four preserved failures? Source inspection/model success must not be called native qualification. Can an unchanged-path exclusion be justified from bodies/callers?

Review raw source and results, independently exercise a discriminating case, and report limitations. No desired selection or author's final verdict is supplied. Do not edit native files or central repository documentation.
