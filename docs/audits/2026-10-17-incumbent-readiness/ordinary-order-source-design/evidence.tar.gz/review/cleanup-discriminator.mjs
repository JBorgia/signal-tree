import assert from 'node:assert/strict';
import {Model,add,field,reorder} from './model.mjs';
for(const kind of ['snapshot','sparse']){
 const m=new Model(kind),lives=Array.from({length:16},(_,i)=>m.life('k'+i,i));m.commit(lives.map(l=>add(l)));
 m.inspection([field(lives[0],999)]);const afterDivergence=m.ordinary.retained();m.counts.reset();m.drain('no-such-lease');const unrelatedCounts=m.counts.read();assert.equal(m.ordinary.read(lives[0].id).n,0);assert.equal(m.physical.read(lives[0].id).n,999);assert.equal(m.ordinary.retained().ordinaryRecords,afterDivergence.ordinaryRecords);
 m.counts.reset();m.inspection([field(lives[0],0)]);const beforeDrain=m.ordinary.retained();const installCounts=m.counts.read();m.counts.reset();m.drain('no-such-lease');assert.equal(m.ordinary.retained().ordinaryRecords,0);console.log(JSON.stringify({kind,divergent:afterDivergence,unrelatedCounts,beforeDrain,installCounts,convergenceDrain:m.counts.read(),qualified:'stored records released, not heap or source facts collected'}));
}
