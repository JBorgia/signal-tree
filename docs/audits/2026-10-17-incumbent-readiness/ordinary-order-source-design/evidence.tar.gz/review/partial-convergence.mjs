import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {Model, add, remove, reorder} from './model.mjs';
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(new URL('./model.mjs',import.meta.url))).digest('hex'),'bdb00609a27f104d3de837c644050741d403e1bf6c5ff138ad8463414af6edff');
const rows=[];
for(const kind of ['snapshot','sparse'])for(const n of [16,256,1024]){
 const m=new Model(kind),lives=Array.from({length:n},(_,i)=>m.life(`k${i}`,i));
 m.commit(lives.map(l=>add(l)));
 const mixed=lives.slice();for(let i=0;i<n;i+=4)[mixed[i+1],mixed[i+2]]=[mixed[i+2],mixed[i+1]];
 m.inspection([reorder(mixed)]);assert.equal(m.ordinary.retained().ordinaryRecords,n);
 m.counts.reset();
 const plan=m.counts.during('prepare',()=>m.prepare([],[remove(lives[1]),add(lives[1],{next:lives[2].id})]));
 m.counts.during('install',()=>plan.install());
 const operation=m.counts.read(),before=m.ordinary.retained();m.counts.reset();
 m.drain('unrelated-terminal');
 const cleanup=m.counts.read(),after=m.ordinary.retained();
 m.verify();assert.deepEqual(m.state().map(x=>x.id),lives.map(x=>x.id));
 const expected=mixed.slice();expected.splice(0,4,...lives.slice(0,4));
 assert.deepEqual(m.state('physical').map(x=>x.id),expected.map(x=>x.id));
 const visited=(cleanup['cleanup.cleanup.exceptionEntriesScanned']??0)+(cleanup['cleanup.cleanup.snapshotEntriesScanned']??0);
 assert.equal(visited,n);assert.equal(after.ordinaryRecords,kind==='sparse'?n-4:n);
 rows.push({kind,n,convergedAdjacencyRecords:4,before,after,visited,released:before.ordinaryRecords-after.ordinaryRecords,operation,cleanup});
}
fs.writeFileSync(new URL('./INDEPENDENT-PARTIAL.json',import.meta.url),JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.map(({kind,n,convergedAdjacencyRecords,visited,released})=>({kind,n,convergedAdjacencyRecords,visited,released}))));
