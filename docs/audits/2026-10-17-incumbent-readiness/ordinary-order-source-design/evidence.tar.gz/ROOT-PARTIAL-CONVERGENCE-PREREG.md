# Preregistered partial convergence boundary

Use unchanged model SHA bdb00609a27f104d3de837c644050741d403e1bf6c5ff138ad8463414af6edff.
N16/256/1024, groups of four. Physical-only full order swaps middle two of
EVERY group; ordinary retains original. All N records have changed links.
Then physically move original member1 before member2 using trusted internal
remove/add. That restores exactly first four records' adjacency while remaining
N-4 continue to diverge. Ordinary stays exact original throughout.

Prediction from source: both models hold N records before drain; cleanup visits
N; sparse releases exactly4 and retainsN-4; snapshot retains wholeN because
its fork cannot be partially released. Separate initial full-divergence setup
from local convergence preparation/install and drain. No CPU/heap or native
claim. This answers the specific 'retire four local changes' concern, not a
rerun/optimization of prior data. Any failed expectation stays preserved.
