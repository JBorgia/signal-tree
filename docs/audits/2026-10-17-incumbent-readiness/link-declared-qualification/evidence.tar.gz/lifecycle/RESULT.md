# Independent frozen lifecycle qualification

No candidate repairs or production edits. Inputs are patchfa397f9 plus frame86006a66 and helper87231fb2. Local patch019b1146 differs only by making the frame-file path point to this evidence directory. Loader output directory likewise changed; transformations/semantics unchanged. PLAN.md precedes execution.

## Results

Explicit disposal of queued work prevents endpoint start and returns disposed receipt. Disposing an in-flight connection releases settled waiters before endpoint acknowledgment; already-started request completes when acknowledged. Actual foreign dependency confirmation releases the dependent payload. Those controls pass.

**Receipt terminality failure:** after an independent declared payload starts I/O, receipt.read() reports started. Reading that SAME receipt inside a later unrelated no-write declaration reports validating, then returns to started after the scope closes. Started was specified terminal. Source cause: status() checks global stack.length before frame.started. This is observable status regression, not a demonstrated speculative send. Original failing check remains unchanged.

**Obligation-free responsibility retention:** eight cycles each create source/target trees, open one source transaction, declare a target write dependent on that authentic owner, confirm it, drain microtasks, await connection.settled(), dispose connection, destroy both trees and drop returned declaration receipts. No owner remains pending, endpoint request remains in flight, connection listener remains installed or user receipt remains held. Exact helper counts grow:

| Record | Before cycles | After8 |
|---|---:|---:|
| Registered sources |4|20|
| Outcome-tree maps |3|11|
| Latest location facts |6|22|
| Exact payload receipts |8|24|
| Completed receipts |6|22|
| Listeners |0|0|

Each cycle adds two sources/two latest facts/two receipts/two completions. These retired records serve no live publication/recovery obligation in this workload. No inference is made from mere existence of a Map: executable controls fully settle/dispose/destroy each cycle, and source inspection shows no records/sources/completed deletion path (dispose helper is empty). The separate exported diagnostic log also retains history, but the counts above refer to correctness stores, not that log. This proves retained-record growth; it is not a heap-byte measurement or proof that every captured tree object itself stays alive.

## Destruction distinction preserved

Three independent destruction controls pass existing expectations: queued predestroy1 may deliver1; started request remains pending until acknowledgment and then settled resolves; held dependent waiter stays unresolved after tree.destroy but resolves after explicit connection.dispose. The third is the previously documented tree-destroy/connection-dispose gap, not a newly failed test. No extra disposal guarantee is invented.

## Replay and identity

Node24.15.0:

    node loader.mjs
    ENTRY=destroy.ts node loader.mjs

The loader overwrites its generic output names. Frozen first-bundle.mjs/first.log/first-receipts.json preserve the first lifecycle/retention run; current bundle.mjs/destroy.log are destruction controls. Sources and source hashes are in receipts JSON. The first log has one composite receipt failure and one retention failure; transport subobservations inside the composite result are individually successful.

First witness ba0f748f9bc1ab10872f798e495d065a70e16dfaa2188b909aa095f79a757cb8; first bundle41778374d5cb1beec22fef2e62a79f3b2bbaa58e006f3fc7e0f7ae26c2fac791; first log7e1bb805ef9d924e9e767fe5afa84312147cc4242ebeeac84ce965939dc6a093. Destroy bundle50abbbaa408fa182a57f694f5db260f8520d8fe5a9e72001de68ca383323e917; destroy log1c60d1fa40fba264dec67aacf87915011ad3262a63db65fa5641bfb717095d55.

Disposition: lifecycle qualification fails receipt terminality and post-drain metadata reclamation. Useful conditional progress and tested disposal behavior remain valid. No repairs attempted; do not accept production lifecycle qualification from these results.

## Independent composition replay and severity

Executed root's frozen /private/tmp/link-qualification-composition/bundle.mjs under Node24.15.0; raw output saved composition-independent-replay.json here. Confirms two failed assertions with one causal defect: a known declaration contradiction plus frozen callback throw preserves the callback object's exact identity, but emits zero onTreeError operation link:declare events; consequently the reporting listener's write8 never executes and display stays7. Both endpoint arrays remain empty. The implementation catch returns the primary error without the required secondary reporter call.

This is observable error-contract incompleteness, not demonstrated publication leakage or lost transaction recovery. The reporter-reentry path is unexercised because the reporter is absent; its safety cannot be counted as passed merely because no callback ran. Similarly, the started->validating->started receipt failure is a diagnostic/admission-state contract regression, not evidence that a started request was physically reversed or that speculative data leaked. Reclamation growth is a separate lifecycle/cost blocker. These failures must not be collapsed into a single safety-corruption count, nor dismissed because the tested sends stayed held.

Held-receipt GC is explicitly unqualified: the churn test drops returned receipts. It establishes obligation-free map growth only. A terminal receipt's closure may retain connection/frame context, but retention of whole trees by held receipts was not measured here.
