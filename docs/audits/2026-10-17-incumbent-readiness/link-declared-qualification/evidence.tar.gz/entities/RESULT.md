# Frozen entity/restoration qualification: rejected

No repairs. Inputs patchfa397f9 + frame86006a66 + existing private helper. Local patch differs only source path for frame fragment. Current checkout lineage changes are documentation-only; production unchanged. Private scalar API not expanded to aggregate declarations.

## Concrete supported-carrier failure
`link(rows.byIdOrFail('a').n)` is an existing scalar Link source. Native baseline ordinary n9 sends number9; native inspection n99 sends nothing. Candidate accepts it; `declare(independent,()=>field(9))` returns started while endpoint receives **undefined**, even though physical read9. Exact typed payload witness confirms typeof undefined; JSON null in original arrays is serialization, not actual null. Dependent declaration holds then rejection also sends undefined. No unsupported-source recognition or refusal occurred. This is wrong scalar publication, not merely missing aggregate declaration support.

Source cause: native Link projects entity events using collection owner, subject lifetime and field footprint, and ignores value-less pings. Private responsibility helper keys only tree+first position and stamps every event, including collection pings. refresh assigns receipt.payload directly, bypassing native entity projection. Row events, field observations and ping share collection position. Inspection alone can refresh an earlier undefined receipt and send undefined.

## Equal adoption boundary incomplete for entity fields
Inspection field99 then transact same field99 records0, rollback leaves99 rather than owner-approved ordinary baseline7. Standalone scalar patch does not cover entity value storage. This is an unimplemented production path under the approved general adoption rule, separately from erroneous entity Link refresh. Original test retained.

## Aggregate native controls
Aggregate declarations unapproved. Controls use existing Link with private policy admission disabled (research.mode(false)); refresh instrumentation still active, so this does not erase experimental side effects. Baseline16/16; candidate15/16. Add/remove/rekey/order rollback, same-key replacement/held lifetime and removal restoration pass. Inspection-only update triggers an unnecessary publication of original eligible rows `[a7,b8]`; baseline sends nothing. No inspected99 escaped in that aggregate control. Subsequent authored b9 excludes inspected a99 as required.

Actual restoration enhancer undo of removal restores ids[a,b], held row7 and outbound[a7,b8]; redo returns[b] with old held reference detached. Baseline, native-only adoption patch, and full candidate (eligibility disabled, refresh retained) all reproduce these results. No general restoration qualification inferred.

## Independent review evidence
Replayed lifecycle first-bundle unchanged: started receipt becomes validating inside unrelated declaration, then started again; terminality failure confirmed. Post-drain registered source/receipt growth reproduced. Saved lifecycle-independent.log. This is independent replay, not source edit.

## Replay/limits
Node24.15.0 standalone first-bundle.mjs (original field checks), payload-bundle.mjs (typed payload), baseline-fields-bundle.mjs, aggregate-first-bundle.mjs, aggregate-baseline-bundle.mjs and restoration-first-bundle.mjs export run(). Loader rebuild overwrites generic artifacts; frozen first filenames remain. No Nx/full suites/cost measurements. Direct source-loader only; no production changes.

## Native-only isolation
NATIVE_ONLY=1 applies only patch.mjs, omitting private Link, notifier and transaction transformations. Same aggregate16 assertions: baseline16/16, native-only16/16, full candidate with eligibility disabled15/16. Thus extra inspection-only baseline publication belongs to private refresh integration, not adoption substrate. Every arm standalone bundle preserved; mode(false) alone is never described as native-only. No repairs.
