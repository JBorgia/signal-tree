import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const results:unknown[]=[];
for(const scenario of ['equal-acquisition','foreign-failed-horizon','input-getter-throw']){
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const f=signalTree({x:0},{enhancers:[transactions()]});const sent:number[]=[];const other:number[]=[];let upstream=99;
 const c:any=link(t.$.y,{set:v=>{sent.push(v);},get:()=>upstream});const d:any=link(t.$.y,{set:v=>{other.push(v);}});const checks:unknown[]=[];
 const eq=(name:string,actual:unknown,expected:unknown)=>checks.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
 try{
 if(scenario==='equal-acquisition'){
  withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();eq('inspection not sent',sent.slice(),[]);
  await c.retrieve();await tick();eq('acquired equal displayed state',t.$.y(),99);
  const p=t.transact(()=>t.$.x(7));c.declare({kind:'independent'},()=>t.$.y(0));await tick();eq('return to baseline must send after acquisition',sent.slice(),[0]);p.rollback();
 }else if(scenario==='foreign-failed-horizon'){
  const p=f.transact(()=>f.$.x(7));let error='';try{c.declare({kind:'dependent',owners:[p]},()=>{d.declare({kind:'dependent',owners:[p]},()=>t.$.y(7));return Promise.resolve();});}catch(e){error=(e as {reason:string}).reason;}
  await tick();eq('outer async rejected',error,'async-callback');eq('foreign failed outer holds c',sent.slice(),[]);eq('foreign failed outer holds d',other.slice(),[]);p.confirm();await tick();eq('useful fallback c',sent.slice(),[7]);eq('useful fallback d',other.slice(),[7]);
 }else{
  const p=t.transact(()=>t.$.x(7));let called=false;let error='';try{c.declare({get kind(){d.declare({kind:'independent'},()=>t.$.y(9));throw new Error('input getter');}},()=>{called=true;});}catch(e){error=(e as {reason:string}).reason;}
  await tick();eq('callback absent',called,false);eq('getter validation error',error,'validation-threw');eq('inner getter write remains',t.$.y(),9);eq('inner held by failed horizon',other.slice(),[]);p.confirm();await tick();eq('inner conservative fallback useful',other.slice(),[9]);
 }
 results.push({scenario,checks,sent:sent.slice(),other:other.slice()});
 }catch(e){results.push({scenario,error:String(e),checks,sent:sent.slice(),other:other.slice()});}
 finally{c.dispose();d.dispose();t.destroy();f.destroy();await tick();}
}
return results;}
