# Bounded native boundary correction

Research only; production remains unchanged. Source checkout376129b5 lineage. Original25 ordinary assertions and misuse demonstration unchanged; misuse excluded from safety pass count. Original13 root controls unchanged; nested original failure unchanged. Copies from frozen native final-private/loader and witness.ts (there was no final-witness.ts file).

## Mechanisms
- Permission frames retain all enclosing validation frame references after return. Eligibility consults their current invalid/unknown outcomes and declared blockers. A popped child cannot outrun enclosing returned-then getter validation.
- Native conservative fallback retains known pending declared obligations even after invalidation; where no channel declaration exists, captured pending facts remain restrictive. This matters for a getter authoring a newer revision after inner scope returns while foreign owner remains pending.
- Inspection participation never invalidates or completes ordinary responsibility receipts. Ordinary receipt completion still operates independently of value notification suppression. Refresh consumes exact completed ordinary receipt payload, not physical inspected display; original current revision identity preflight remains.
- Clean incoming authority uses existing explicit acquire boundary and exact-ticket guard. Native candidate376 had omitted that bypass, which unchanged delivery campaign exposed. No new public policy.

## Preserved first results
- First corrected original25 and root13 plus original nested failure pass.
- New31:30 pass, foreign-invalid fails. Return then getter wrote10 after inner returned; no inner permission on new revision, local native fallback sent despite foreign owner pending. first-extra* preserved; first-private and first-loader freeze those sources. Adding captured blockers to undeclared conservative fallback closes unchanged failure;31 pass.
- First unchanged delivery campaign:18/34 completed assertions pass,16 mismatches, several branches stop on unavailable release. Incoming acquisition42 held because prior native candidate never consumed clean authority. Exact-ticket clean bypass restores32/34. first-delivery bundle/traces and pre-delivery-private preserve evidence.
- Final original25 ordinary + root13 + nested original + new31 pass. Original saved-misuse asserts false declaration publishes speculative7; not a safety pass.
- Final delivery32/34: old permanent-unknown assertions expect []/unsettled after confirmation, actual[42]/settled. Preserve unchanged oracle; approved terminal-owner surviving semantics explain differences, not generic delivery qualification failure.
- Strict private helper typecheck passes. No integrated public API/spec-type/package suites.

## Scope / limits
Scalar private source-loader only, default native scheduling. Retained source/receipt maps and all-source scans remain unqualified. Equal setter against inspection-displayed99 produces no native write and receipt no-write, not retroactive acquisition; actual incoming acquire remains supported. Shared single-instrumented-runtime foreign controls do not prove arbitrary package/realm propagation. Declaration completeness remains application responsibility. No framework/entity ordering/restoration qualification. No production acceptance, activation, budget change, or B reopening.

## Replay
Node24.15.0. Standalone final-{witness,independent-controls,nested-original,extra}-bundle.mjs and targeted-bundle.mjs export run(). Example:
node --input-type=module -e 'const {run}=await import("/private/tmp/link-native-boundaries/final-extra-bundle.mjs");console.log(JSON.stringify(await run(),null,2))'
Rebuild research against recorded checkout: ENTRY=extra.ts node /private/tmp/link-native-boundaries/loader.mjs (overwrites generic bundle/traces; frozen final copies remain).
Typecheck from checkout: ./node_modules/.bin/tsc --strict --target ES2022 --module ESNext --skipLibCheck --noEmit /private/tmp/link-native-boundaries/private.ts
