import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];for(const scenario of ['input-getter','return-getter','ordinary-equal','acquire-equal']){
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];let stored=0;
 const c:any=link(t.$.y,{set:v=>sent.push(v),get:()=>stored});const d:any=link(t.$.y,{set:()=>{}});let inner:any;let error:any;
 try{const p=t.transact(()=>t.$.x(7));
 if(scenario==='input-getter'){try{c.declare({get kind(){inner=d.declare({kind:'independent'},()=>t.$.y(9));throw Error('getter');}},()=>{});}catch(e){error=String(e);}await tick();rows.push({scenario,sent:[...sent],inner:inner.read(),error,pass:sent.length===0&&inner.read().state==='conservative'});}
 if(scenario==='return-getter'){try{c.declare({kind:'independent'},()=>{inner=d.declare({kind:'independent'},()=>t.$.y(9));return {get then(){throw Error('getter');}};});}catch(e){error=String(e);}await tick();rows.push({scenario,sent:[...sent],inner:inner.read(),error,pass:sent.length===0&&inner.read().state==='conservative'});}
 if(scenario==='ordinary-equal'){withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();const r=c.declare({kind:'independent'},()=>t.$.y(99));await tick();rows.push({scenario,sent:[...sent],receipt:r.read(),expected:[99],pass:JSON.stringify(sent)==='[99]'});}
 if(scenario==='acquire-equal'){withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();stored=99;await c.retrieve();await tick();p.rollback();await tick();t.$.y(0);await tick();rows.push({scenario,sent:[...sent],expected:[0],pass:JSON.stringify(sent)==='[0]'});}
 }finally{c.dispose();d.dispose();t.destroy();await tick();}}
 return rows;}
