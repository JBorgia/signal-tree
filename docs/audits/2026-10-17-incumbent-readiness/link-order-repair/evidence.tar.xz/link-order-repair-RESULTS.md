# Bounded Link prepared-order publication repair

Parent-authorized runtime edits in incumbent readiness worktree, no commit. Base HEAD16f85b6d. Unrelated AGENTS.md/measurement-contract edits untouched. Ownership: prepare-entity-target publication, entity-signal host callback, target-transition publication phase, new link-order-rollback.spec.ts. Restoration worker owns other edits and combined validation.

## Change

Entity target preparation captures before order/frontier and target after order/frontier. Installed target publishes its order through existing collection-order channel. Host preserves ambient participation metadata and uses established survivingOrderChanged predicate to avoid unchanged/membership-only extra order captures.

All targets install before a separate optional internal publishOrder phase; all order facts publish before any target's ordinary publication/callbacks. Existing publication phase still attempts all targets and rethrows first error. No new public API or extra queue flush. Link algorithm unchanged. Optional phase permits scalar/member target bindings to keep existing contract.

## Preserved first results

- link-order-repair-first.log: unchanged runtime, original5 controls ->4fail/1pass (confirmation positive).
- link-order-repair-candidate.log: first per-target fix, new in-flight test setup first sends initiala,b due synchronous confirmation;5pass/1setupfailure. Fixed setup stages, drains, then confirms to ensure intendedb,a first request. Preserved original spec copy link-order-repair-first-candidate.spec.ts.
- link-order-repair-two-targets.log: stronger actual cross-target callback fixture ->6pass/1fail. Physical newerb,a survives but late prepared order capture publishesa,b. Preserved before-phase source/spec. This rejects per-target late publication.
- link-order-repair-phases.log: complete-unit order phase ->7pass.
- link-order-repair-expanded.log:9pass/1test-premise failure. Undo explicitly stamps realized participation, so wrapping undo in inspection context is not inspection. Original spec preserved link-order-repair-inspection-premise.spec.ts. Replaced setup with actual prepared-target installation under inspection context, same no-durable-order expectation.

## Current focused verification

- link-order-focused-final.log:6files57tests pass (new10 + unchanged inflight-settlement-audit, same-turn-settlement, authority-carrier, overlapping-rollback, order-audit-regression).
- link-order-mixed.log: new spec12/12 pass, adding queued/drained mixed removed-row restoration plus survivor reordering.
- link-order-lint.log: empty successful ESLint on new spec, prepare-entity-target, target-transition.
- New spec formatted using repository Prettier2.8.8.
- git diff --check passes.
- Exact4 relevant source hashes at each run in link-order-focused-inputs.sha256 and link-order-mixed-inputs.sha256.

Current12 controls: queued/drained rollback, confirmation, earlier acknowledged request delay, literal outdated confirmedb,a already in-flight then restorationa,b requiring secondpayload, endpoint-authored reorder, cross-target tap-authored reorder, throwing delivery, no unchanged-order capture, prepared inspection excludes durable order, queued/drained mixed removed rows+survivor order.

No full typecheck/framework/broad suites/build/budget run. No production acceptance; independent review and combined checks remain parent-owned. No claims of general native framework timing from these kernel tests.

## Replay

Workdir /Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree
PATH=/private/tmp/st-b-qualification-20261016/bin:/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin:$PATH
NX_DAEMON=false pnpm nx test kernel --testFile=src/lib/link-order-rollback.spec.ts --skip-nx-cache
NX_DAEMON=false pnpm nx test kernel --testFile=src/lib/link-order-rollback.spec.ts --testFile=src/lib/link-inflight-settlement-audit.spec.ts --testFile=src/lib/link-same-turn-settlement.spec.ts --testFile=src/lib/link-authority-carrier.spec.ts --testFile=src/lib/link-overlapping-rollback.spec.ts --testFile=src/lib/link-order-audit-regression.spec.ts --skip-nx-cache
pnpm exec eslint packages/kernel/src/lib/link-order-rollback.spec.ts packages/kernel/src/lib/physical/prepare-entity-target.ts packages/kernel/src/lib/internals/causal-runtime/target-transition.ts
