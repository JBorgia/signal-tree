import { describe, expect, it } from 'vitest';
import { signalTree } from './signal-tree';
import { entityMap } from './markers/entity-map';
import { link } from './link';
import { restoration } from '../enhancers/restoration/restoration';
import { undoable } from './undoable';
import { transactions } from '../enhancers/transactions/transactions';

const drain = async () => { for (let i = 0; i < 16; i++) await Promise.resolve(); };
const initial = [{ id: 'a', n: 0 }, { id: 'b', n: 0 }];
function fixture() {
  const tree = signalTree({ rows: entityMap<{id: string; n: number}, string>() }, { enhancers: [transactions()] });
  tree.$.rows.addMany(initial);
  return tree;
}

describe('Link order publication after transaction rollback', () => {
  it.each([false, true])('publishes restored order with forward delivery already drained=%s', async (delivered) => {
    const tree = fixture();
    const sent: string[][] = [];
    const connection = link(tree.$.rows, { set: value => { sent.push(value.map(row => row.id)); } });
    try {
      const pending = tree.transact(() => tree.$.rows.setAll([...initial].reverse(), { reorder: true }));
      if (delivered) await drain();
      expect(sent).toEqual([]);
      pending.rollback();
      expect(tree.$.rows.ids()).toEqual(['a', 'b']);
      expect(tree.$.rows.all().map(row => row.id)).toEqual(['a', 'b']);
      await connection.settled();
      expect(sent.length).toBeGreaterThan(0);
      expect(sent.every(order => order.join() === 'a,b')).toBe(true);
    } finally { connection.dispose(); tree.destroy(); }
  });

  it('confirms and publishes a useful order change', async () => {
    const tree = fixture();
    const sent: string[][] = [];
    const connection = link(tree.$.rows, { set: value => { sent.push(value.map(row => row.id)); } });
    try {
      const pending = tree.transact(() => tree.$.rows.setAll([...initial].reverse(), { reorder: true }));
      await drain(); expect(sent).toEqual([]);
      pending.confirm(); await connection.settled();
      expect(sent).toEqual([['b', 'a']]);
    } finally { connection.dispose(); tree.destroy(); }
  });

  it('does not send rejected order after an earlier endpoint request completes', async () => {
    const tree = fixture();
    const sent: string[][] = [];
    let finish!: () => void;
    const connection = link(tree.$.rows, { set: value => {
      sent.push(value.map(row => row.id));
      if (sent.length === 1) return new Promise<void>(resolve => { finish = resolve; });
    } });
    try {
      tree.$.rows.byIdOrFail('a').n(1); await drain();
      expect(sent).toEqual([['a', 'b']]);
      const pending = tree.transact(() => tree.$.rows.setAll([{id:'b', n:0}, {id:'a', n:1}], {reorder:true}));
      await drain(); pending.rollback(); finish(); await connection.settled();
      expect(sent.every(order => order.join() === 'a,b')).toBe(true);
    } finally { finish?.(); connection.dispose(); tree.destroy(); }
  });

  it('preserves a newer order authored by the endpoint during restored delivery', async () => {
    const tree = fixture();
    const sent: string[][] = [];
    const connection = link(tree.$.rows, { set: value => {
      sent.push(value.map(row => row.id));
      if (sent.length === 1) tree.$.rows.setAll([...initial].reverse(), {reorder:true});
    } });
    try {
      const pending = tree.transact(() => tree.$.rows.setAll([...initial].reverse(), {reorder:true}));
      await drain(); pending.rollback(); await connection.settled();
      expect(sent).toEqual([['a','b'], ['b','a']]);
      expect(tree.$.rows.ids()).toEqual(['b','a']);
    } finally { connection.dispose(); tree.destroy(); }
  });
  it('sends restored order after an outdated confirmed payload already entered I/O', async () => {
    const tree = signalTree({rows: entityMap<{id:string;n:number},string>()}, {enhancers:[transactions(), restoration()]});
    tree.$.rows.addMany(initial);
    const sent: string[][] = [];
    let finish!: () => void;
    const connection = link(tree.$.rows, {set: value => {
      sent.push(value.map(row => row.id));
      if(sent.length===1)return new Promise<void>(resolve=>{finish=resolve;});
    }});
    try {
      undoable(() => {
        const pending=tree.transact(()=>tree.$.rows.setAll([...initial].reverse(),{reorder:true}));
        pending.confirm();
      });
      await drain(); expect(sent).toEqual([['b','a']]);
      tree.undo(); expect(tree.$.rows.ids()).toEqual(['a','b']);
      finish(); await connection.settled();
      expect(sent).toEqual([['b','a'],['a','b']]);
    } finally {finish?.(); connection.dispose(); tree.destroy();}
  });

});
