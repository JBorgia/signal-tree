import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {entityMap} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/markers/entity-map';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
import {getMutationCaptureRuntime} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/mutation-capture-runtime';
const seed=[{id:'a',n:0},{id:'b',n:0}];const t=signalTree({first:entityMap<{id:string;n:number},string>(),rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});t.$.first.addMany(seed);t.$.rows.addMany(seed);let armed=false;
t.$.first.tap({onUpdate(){if(armed)console.log('tap',t.$.rows.ids(),t.$.rows.all().map(x=>x.id));}});
const rt=getMutationCaptureRuntime(t.$.rows)!;const release=rt.activateCapture();const off=rt.subscribeCollectionOrder!(c=>{if(armed)console.log('capture',c.afterSubjects,t.$.rows.ids(),t.$.rows.all().map(x=>x.id))});
const p=t.transact(()=>{t.$.first.setAll([{id:'b',n:1},{id:'a',n:0}],{reorder:true});t.$.rows.setAll([...seed].reverse(),{reorder:true});});
for(let i=0;i<16;i++)await Promise.resolve();console.log('prime',t.$.rows.ids(),t.$.rows.all().map(x=>x.id));armed=true;p.rollback();console.log('final',t.$.rows.ids(),t.$.rows.all().map(x=>x.id));off();release();t.destroy();
