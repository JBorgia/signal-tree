import {signalTree,entityMap,transactions} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
async function run(){
 const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});const r=t.$.rows;
 r.setAll([{id:'a',n:7},{id:'b',n:8}]);for(let i=0;i<50;i++)await Promise.resolve();
 const oldA=r.byIdOrFail('a'),oldB=r.byIdOrFail('b');
 const snap=()=>({ids:r.ids(),rows:r.all(),oldA:oldA(),oldB:oldB(),aIsOldA:r.byId('a')===oldA,dIsOldA:r.byId('d')===oldA,bIsOldB:r.byId('b')===oldB});
 const before=snap();withWriteContext({participation:'inspection'},()=>r.changeId('a','c'));const inspected=snap();
 const steps=[];const p=t.transact(()=>{r.changeId('b','a');steps.push(snap());r.changeId('c','d');steps.push(snap());});
 let view,error,rollbackError;try{view=p.inspect()}catch(e){error=String(e)};const beforeReject=snap();try{p.rollback()}catch(e){rollbackError=String(e)};
 console.log(JSON.stringify({before,inspected,steps,beforeReject,view,error,afterReject:snap(),rollbackError}));t.destroy();
}
await run();
