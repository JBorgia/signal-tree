const fs=require('node:fs'),crypto=require('node:crypto');
const root='/private/tmp/semantic-transition-slice2/candidate';
const out='/private/tmp/occupancy-successor-normalization';
const esbuild=require(root+'/node_modules/esbuild');
const txPath=root+'/packages/kernel/src/enhancers/transactions/transactions.ts';
const rbPath=root+'/packages/kernel/src/lib/internals/causal-runtime/pending-rollback.ts';
const tx=fs.readFileSync(txPath,'utf8'),rb=fs.readFileSync(rbPath,'utf8');
function between(a,b){const start=tx.indexOf(a),end=tx.indexOf(b,start);if(start<0||end<0)throw Error('missing extraction markers');return tx.slice(start,end);}
const extraction=between('  const rememberBaselineValue =','  const buildTurnEffectFromStructural =')+between('  const toCausalEffect =','  const toRollbackEffect =');
const source=extraction+`\nexport function fold(effects){const bucket={baselineValues:new Map(),entityFootprints:new Map()};const map=new Map();for(const e of effects)enqueueEffect(bucket,map,structuredClone(e));return [...map.values()].map(toCausalEffect);}\n`;
fs.writeFileSync(out+'/extracted-fold.ts',source);
fs.writeFileSync(out+'/source-identities.json',JSON.stringify([txPath,rbPath].map(path=>({path,sha256:crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex')})),null,2)+'\n');
Promise.all([
 esbuild.build({stdin:{contents:source,loader:'ts',resolveDir:root},bundle:true,platform:'node',format:'esm',outfile:out+'/fold.mjs'}),
 esbuild.build({stdin:{contents:rb+'\nexport {createPendingRollbackEffects};',loader:'ts',resolveDir:require('node:path').dirname(rbPath)},bundle:true,platform:'node',format:'esm',outfile:out+'/rollback.mjs'})
]).catch(e=>{console.error(e);process.exitCode=1});
