// Experimental occupancy endpoint composer only. Not a runtime installation engine.
import {fold as incumbentFold} from './original/fold.mjs';
export function fold(operations){
 const endpoints=new Map();
 for(const e of operations){
  if(!['add','remove','rekey'].includes(e.kind))throw Error('Occupancy model accepts structural records only');
  const address=JSON.stringify([e.ownerPath,e.position,e.subject]);
  const before=e.kind==='add'?undefined:e.kind==='remove'?e.key:e.beforeKey;
  const after=e.kind==='remove'?undefined:e.kind==='add'?e.key:e.afterKey;
  let row=endpoints.get(address);
  if(!row){row={first:e,before,after,beforeValue:e.kind==='remove'?e.value:undefined,last:e};endpoints.set(address,row);}
  else {if(!Object.is(row.after,before))throw Error('Discontinuous occupancy evidence');row.after=after;row.last=e;}
  if(e.kind==='remove' && row.beforeValue===undefined)row.beforeValue=e.value;
 }
 const net=[];
 for(const r of endpoints.values()){
  if(Object.is(r.before,r.after))continue;
  const base={ownerPath:r.first.ownerPath,path:r.first.path,position:r.first.position,subject:r.first.subject};
  if(r.before===undefined)net.push({...base,...r.last,kind:'add',key:r.after});
  else if(r.after===undefined)net.push({...base,...r.last,kind:'remove',key:r.before,value:r.beforeValue});
  else net.push({...base,kind:'rekey',beforeKey:r.before,afterKey:r.after});
 }
 return incumbentFold(net);
}
