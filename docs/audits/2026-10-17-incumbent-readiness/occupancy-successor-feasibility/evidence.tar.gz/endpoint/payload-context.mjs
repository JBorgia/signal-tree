import assert from 'node:assert/strict';import {fold} from './fold.mjs';
const base={position:10,ownerPath:'rows',path:'rows',subject:1};
const result=fold([{...base,kind:'add',key:'a',value:{n:7},beforeSubject:2},{...base,kind:'rekey',beforeKey:'a',afterKey:'b'}]);
console.log(JSON.stringify(result));assert.deepEqual(result[0].structuralContext.value,{n:7});assert.equal(result[0].structuralContext.beforeSubject,2);
