import assert from 'node:assert/strict';
import {fold} from './fold.mjs';
import {createPendingRollbackEffects} from './rollback.mjs';
const base={position:10,ownerPath:'rows',path:'rows',subject:1};
const remove=key=>({...base,kind:'remove',key,value:{n:7}});
const add=key=>({...base,kind:'add',key,value:{n:7}});
const rekey=(beforeKey,afterKey)=>({...base,kind:'rekey',beforeKey,afterKey});
const field={owner:10,ownerPath:'rows',path:'rows.a.n',subjectId:1,subjectFieldSegments:['n'],before:7,after:99};
const inv=effects=>createPendingRollbackEffects({id:1,effects},{getCurrentValue(){throw Error('unexpected')},getValueWithoutPendingTurn(){throw Error('unexpected')}});
const sig=e=>[e.subjectId,e.structural??'field',e.before??null,e.after??null];
const tests=[
 ['same-key cancellation does not discard a separately explicit field',()=>assert.deepEqual(inv([...fold([remove('a'),add('a')]),field]).map(sig),[[1,'field',99,7]])],
 ['net relocation and separately explicit field both invert',()=>assert.deepEqual(inv([...fold([remove('a'),add('c')]),field]).map(sig),[[1,'rekey','c','a'],[1,'field',99,7]])],
 ['separate capture checkpoints do not cancel each other',()=>{assert.deepEqual(inv(fold([rekey('a','b')])).map(sig),[[1,'rekey','b','a']]);assert.deepEqual(inv(fold([rekey('b','a')])).map(sig),[[1,'rekey','a','b']]);}],
 ['committed checkpoint output is not mutated by later folding',()=>{const committed=fold([rekey('a','b')]);const saved=JSON.stringify(committed);fold([rekey('b','c')]);assert.equal(JSON.stringify(committed),saved);}],
 ['nested separately-owned capture records remain separate',()=>{const outerBefore=[rekey('a','b')],nested=[rekey('b','c')];const a=fold(outerBefore),b=fold(nested);assert.deepEqual(a.map(sig),[[1,'rekey','a','b']]);assert.deepEqual(b.map(sig),[[1,'rekey','b','c']]);}],
 ['unexplained interruption is refused rather than composed',()=>assert.throws(()=>fold([rekey('a','b'),rekey('c','d')]),/Discontinuous occupancy evidence/)]
];
let fails=0;for(const [name,run] of tests){try{run();console.log(JSON.stringify({name,verdict:'PASS'}));}catch(e){fails++;console.log(JSON.stringify({name,verdict:'FAIL',error:e.message}));}}
console.log(JSON.stringify({passed:tests.length-fails,failed:fails,scope:'endpoint model and actual inverse-construction only; no native reentry/commit integration or order-channel qualification'}));process.exitCode=fails?1:0;
