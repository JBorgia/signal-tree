// <stdin>
var rememberBaselineValue = (bucket, effect) => {
  if (!bucket.baselineValues.has(effect.position)) {
    switch (effect.kind) {
      case "set":
        bucket.baselineValues.set(effect.position, effect.before);
        break;
      case "add":
        bucket.baselineValues.set(effect.position, void 0);
        break;
      case "remove":
        bucket.baselineValues.set(effect.position, effect.key);
        break;
      case "rekey":
        bucket.baselineValues.set(effect.position, effect.beforeKey);
        break;
    }
  }
};
var effectKey = (effect) => {
  switch (effect.kind) {
    case "set":
      return JSON.stringify([
        effect.kind,
        effect.position,
        effect.subject,
        effect.subjectFieldSegments ?? effect.path
      ]);
    // RESTORE-P0 P0-B: keyed by SUBJECT, deliberately without `kind`, so the
    // transaction's effects on one subject collide and can be composed into
    // the NET effect. With `kind` in the key, `rekey('a','a2')` and
    // `removeOne('a2')` occupied separate slots and rollback applied both
    // inverses, returning the row under the name it had been renamed TO.
    // Mirrors the same repair in restoration.ts.
    case "remove":
    case "add":
    case "rekey":
      return `structural\0${effect.ownerPath}\0${effect.position}\0${effect.subject}`;
  }
};
var enqueueEffect = (bucket, effectMap, effect) => {
  const key = effectKey(effect);
  const existing = effectMap.get(key);
  if (existing) {
    if (existing.kind === "set" && effect.kind === "set") {
      if (!composePlainBranchMemberEffect(existing, effect)) {
        existing.after = effect.after;
        const beforePresent = existing.fieldPresence?.before ?? true;
        const afterPresent = effect.fieldPresence?.after ?? true;
        if (beforePresent && afterPresent) delete existing.fieldPresence;
        else
          existing.fieldPresence = {
            before: beforePresent,
            after: afterPresent
          };
      }
      existing.mutationIntent = combineScalarMutationIntent(
        existing.mutationIntent,
        effect.mutationIntent
      );
      if (effectMap === bucket.entityFootprints && plainBranchMemberEffectIsNoop(existing) && (existing.fieldPresence?.before ?? true) === (existing.fieldPresence?.after ?? true)) {
        effectMap.delete(key);
      }
      return;
    }
    if (existing.kind !== "set" && effect.kind !== "set") {
      if (existing.kind === "add" && effect.kind === "remove") {
        effectMap.delete(key);
        return;
      }
      if (existing.kind === "rekey" && effect.kind === "remove") {
        const composed = { ...effect, key: existing.beforeKey };
        rememberBaselineValue(bucket, composed);
        effectMap.set(key, composed);
        return;
      }
      if (existing.kind === "add" && effect.kind === "rekey") {
        existing.key = effect.afterKey;
        return;
      }
      if (existing.kind === "rekey" && effect.kind === "rekey") {
        if (existing.beforeKey === effect.afterKey) {
          effectMap.delete(key);
          return;
        }
        existing.afterKey = effect.afterKey;
        return;
      }
    }
    return;
  }
  if (effectMap !== bucket.entityFootprints) {
    rememberBaselineValue(bucket, effect);
  }
  effectMap.set(key, effect);
};
var toCausalEffect = (effect) => {
  switch (effect.kind) {
    case "set":
      return {
        owner: effect.position,
        before: effect.before,
        after: effect.after,
        subjectId: effect.subject,
        subjectFieldSegments: effect.subjectFieldSegments,
        plainBranchMembership: effect.plainBranchMembership,
        fieldPresence: effect.fieldPresence,
        path: effect.path,
        ownerPath: effect.ownerPath
      };
    case "add":
      return {
        owner: effect.position,
        before: void 0,
        after: effect.key,
        subjectId: effect.subject,
        path: effect.path,
        ownerPath: effect.ownerPath,
        structural: "add",
        structuralContext: {
          kind: "add",
          subject: effect.subject,
          key: effect.key,
          value: effect.value,
          beforeSubject: effect.beforeSubject,
          afterSubject: effect.afterSubject
        }
      };
    case "remove":
      return {
        owner: effect.position,
        before: effect.key,
        after: void 0,
        subjectId: effect.subject,
        path: effect.path,
        ownerPath: effect.ownerPath,
        structural: "remove",
        structuralContext: {
          kind: "remove",
          subject: effect.subject,
          key: effect.key,
          value: effect.value,
          beforeSubject: effect.beforeSubject,
          afterSubject: effect.afterSubject
        }
      };
    case "rekey":
      return {
        owner: effect.position,
        before: effect.beforeKey,
        after: effect.afterKey,
        subjectId: effect.subject,
        path: effect.path,
        ownerPath: effect.ownerPath,
        structural: "rekey",
        structuralContext: {
          kind: "rekey",
          subject: effect.subject,
          beforeKey: effect.beforeKey,
          afterKey: effect.afterKey
        }
      };
  }
};
function fold(effects) {
  const bucket = { baselineValues: /* @__PURE__ */ new Map(), entityFootprints: /* @__PURE__ */ new Map() };
  const map = /* @__PURE__ */ new Map();
  for (const e of effects) enqueueEffect(bucket, map, structuredClone(e));
  return [...map.values()].map(toCausalEffect);
}
export {
  fold
};
