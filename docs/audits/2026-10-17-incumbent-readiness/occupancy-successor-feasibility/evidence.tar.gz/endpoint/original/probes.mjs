import {fold} from './fold.mjs';
import {createPendingRollbackEffects} from './rollback.mjs';
import assert from 'node:assert/strict';
const add=(subject,key,n)=>({kind:'add',subject,key,value:{n},position:10,ownerPath:'rows',path:'rows'});
const remove=(subject,key,n)=>({...add(subject,key,n),kind:'remove'});
const rekey=(subject,beforeKey,afterKey)=>({kind:'rekey',subject,beforeKey,afterKey,position:10,ownerPath:'rows',path:'rows'});
const sig=e=>[e.subjectId,e.structural,e.before??null,e.after??null];
const context={getCurrentValue(){throw Error('Unexpected scalar read')},getValueWithoutPendingTurn(){throw Error('Unexpected scalar resolution')}};
const cases=[
 {name:'displaced destination: remove oldA then rekey B to a',ops:[remove(1,'a',7),rekey(2,'b','a')],expected:[[1,'add',null,'a'],[2,'rekey','a','b']]},
 {name:'freshA while oldA physically at b: O fold retains both inverses',ops:[remove(1,'a',7),add(3,'a',99)],expected:[[1,'add',null,'a'],[3,'remove','a',null]]},
 {name:'staged repeated key: fresh1 displaced by fresh2',ops:[remove(1,'a',7),add(3,'a',99),remove(3,'a',99),add(4,'a',100)],expected:[[1,'add',null,'a'],[4,'remove','a',null]]},
 {name:'rekey then remove original lifetime',ops:[rekey(1,'a','b'),remove(1,'b',7)],expected:[[1,'add',null,'a']]},
 {name:'repeated rekeys collapse original to last key',ops:[rekey(1,'a','b'),rekey(1,'b','c')],expected:[[1,'rekey','c','a']]},
 {name:'round-trip rekey cancels net contribution',ops:[rekey(1,'a','b'),rekey(1,'b','a')],expected:[]},
 {name:'same lifetime remove and rebind another key',ops:[remove(1,'a',7),add(1,'c',7)],expectedForward:[[1,'rekey','a','c']],expected:[[1,'rekey','c','a']]},
 {name:'same lifetime remove and rebind original key',ops:[remove(1,'a',7),add(1,'a',7)],expectedForward:[],expected:[]}
];
let failures=0;
for(const c of cases){const normalized=fold(c.ops);const inverses=createPendingRollbackEffects({id:1,effects:normalized},context);let error;try{if(c.expectedForward)assert.deepEqual(normalized.map(sig),c.expectedForward);assert.deepEqual(inverses.map(sig),c.expected);}catch(e){error=e.message;failures++;}console.log(JSON.stringify({name:c.name,normalized:normalized.map(sig),inverses:inverses.map(sig),expected:c.expected,verdict:error?'FAIL':'PASS',error}));}
console.log(JSON.stringify({passed:cases.length-failures,failed:failures,scope:'extracted incumbent structural fold and private rollback creation; not native installation/public API qualification'}));
process.exitCode=failures?1:0;
