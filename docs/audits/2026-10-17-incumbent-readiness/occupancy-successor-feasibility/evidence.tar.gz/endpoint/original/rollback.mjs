// <stdin>
function rollbackPendingTurnAt(options) {
  const turn = options.store.getPendingTurn(options.turnId);
  if (!turn) {
    return { ok: false, refusal: { kind: "turn-evicted" } };
  }
  if (!turn.participants.every(
    (participant) => options.topology.contains(options.authority, participant)
  )) {
    return { ok: false, refusal: { kind: "outside-boundary" } };
  }
  if (hasLaterStructuralDependency(turn, options.store)) {
    return { ok: false, refusal: { kind: "dependency-conflict" } };
  }
  const effects = createPendingRollbackEffects(
    turn,
    options.realizationContext
  );
  const validationRefusal = options.port.validateEffects?.(effects);
  if (validationRefusal) {
    return { ok: false, refusal: validationRefusal };
  }
  const transition = options.store.prepareDiscardPendingTurn(turn.id);
  if (!transition.ok) {
    return mapDiscardFailure(transition);
  }
  options.port.applyAtomically(effects);
  const discardedTurn = options.store.commitPreparedDiscardPending(
    transition.transition
  );
  const maintenanceObserver = options.onMaintenanceMayBeUseful ?? options.onPendingTurnDiscarded;
  const maintenanceErrorObserver = options.reportMaintenanceObserverError ?? options.reportDiscardObserverError;
  if (discardedTurn && maintenanceObserver) {
    try {
      maintenanceObserver(discardedTurn);
    } catch (error) {
      if (maintenanceErrorObserver) {
        maintenanceErrorObserver(error, discardedTurn);
      } else {
        queueMicrotask(() => {
          throw normalizeError(error);
        });
      }
    }
  }
  return { ok: true, turnId: turn.id };
}
function createPendingRollbackEffects(turn, realizationContext) {
  const dominantStructuralEffects = /* @__PURE__ */ new Map();
  for (const effect of turn.effects) {
    if (effect.subjectId !== void 0 && (effect.structural === "add" || effect.structural === "remove")) {
      const candidates = dominantStructuralEffects.get(effect.subjectId);
      if (candidates) candidates.push(effect);
      else dominantStructuralEffects.set(effect.subjectId, [effect]);
    }
  }
  const firstEffectIndexByOwner = /* @__PURE__ */ new Map();
  turn.effects.forEach((effect, index) => {
    const effectKey = rollbackAddressKey(effect);
    if (!firstEffectIndexByOwner.has(effectKey)) {
      firstEffectIndexByOwner.set(effectKey, index);
    }
  });
  return placeFieldReversalsWhileRowsExist(
    turn.effects.filter((effect, index) => {
      if (effect.subjectId !== void 0) {
        const dominantStructuralEffect = dominantStructuralEffects.get(effect.subjectId)?.find((candidate) => sameSubjectScope(candidate, effect));
        if (dominantStructuralEffect && (dominantStructuralEffect === effect || dominantStructuralEffect.structural === "add" || dominantStructuralEffect.owner !== effect.owner)) {
          return dominantStructuralEffect === effect;
        }
      }
      const effectKey = rollbackAddressKey(effect);
      return firstEffectIndexByOwner.get(effectKey) === index;
    }).map(
      (effect) => createPendingRollbackEffect(effect, turn.id, realizationContext)
    ).filter(
      (effect) => effect.plainBranchMembership !== void 0 && effect.plainBranchMembership.before !== effect.plainBranchMembership.after || effect.before !== effect.after || effect.fieldPresence !== void 0 && effect.fieldPresence.before !== effect.fieldPresence.after
    )
  );
}
function placeFieldReversalsWhileRowsExist(effects) {
  if (effects.length === 0) return effects;
  const segments = [];
  let segment;
  let previous;
  for (const effect of effects) {
    if (!segment || !Object.is(previous, effect.turn)) {
      segments.push(segment = []);
      previous = effect.turn;
    }
    segment.push(effect);
  }
  let changed = false;
  const result = [];
  for (const unit of segments) {
    const rows = /* @__PURE__ */ new Map();
    const row = (e) => (e.structural === "add" || e.structural === "remove") && e.subjectId !== void 0;
    const scope = (e) => rows.get(e.owner)?.get(e.subjectId);
    for (const e of unit)
      if (row(e)) {
        let owners = rows.get(e.owner);
        if (!owners) rows.set(e.owner, owners = /* @__PURE__ */ new Map());
        const existing = owners.get(e.subjectId);
        if (existing && existing.kind !== e.structural) existing.mixed = true;
        if (!existing)
          owners.set(e.subjectId, {
            kind: e.structural,
            fields: [],
            mixed: false
          });
      }
    for (const e of unit)
      if (e.structural === void 0 && e.subjectId !== void 0) {
        const entry = scope(e);
        if (entry && !entry.mixed) entry.fields.push(e);
      }
    const ordered = [];
    for (const e of unit) {
      const candidate = scope(e);
      const entry = candidate?.mixed ? void 0 : candidate;
      if (e.structural === void 0 && e.subjectId !== void 0 && entry)
        continue;
      if (row(e) && e.structural === "remove" && entry) {
        for (const field of entry.fields) ordered.push(field);
        entry.fields = [];
      }
      ordered.push(e);
      if (row(e) && e.structural === "add" && entry) {
        for (const field of entry.fields) ordered.push(field);
        entry.fields = [];
      }
    }
    changed ||= ordered.some((effect, index) => effect !== unit[index]);
    for (const effect of ordered) result.push(effect);
  }
  return changed ? result : effects;
}
function rollbackAddressKey(effect) {
  if (effect.plainBranchMembership !== void 0) {
    return `${String(effect.owner)}\0membership`;
  }
  if (effect.structural === "rekey" && effect.subjectId !== void 0) {
    return JSON.stringify([effect.owner, effect.subjectId, "rekey"]);
  }
  if (effect.subjectFieldSegments !== void 0) {
    return JSON.stringify([
      effect.owner,
      effect.subjectId,
      effect.subjectFieldSegments
    ]);
  }
  return hasInlineScopedLeafAddress(effect) ? `${String(effect.owner)}\0${effect.path}` : String(effect.owner);
}
function createPendingRollbackEffect(effect, turnId, realizationContext) {
  const structural = deriveCompensationStructuralEffect(effect.structural);
  if (effect.structural !== void 0) {
    return {
      owner: effect.owner,
      before: deriveStructuralRollbackBefore(effect),
      after: deriveStructuralRollbackAfter(effect),
      subjectId: effect.subjectId,
      subjectFieldSegments: effect.subjectFieldSegments,
      plainBranchMembership: effect.plainBranchMembership ? {
        before: effect.plainBranchMembership.after,
        after: effect.plainBranchMembership.before
      } : void 0,
      fieldPresence: effect.fieldPresence ? {
        before: effect.fieldPresence.after,
        after: effect.fieldPresence.before
      } : void 0,
      structural,
      structuralContext: effect.structuralContext
    };
  }
  if (effect.plainBranchMembership !== void 0 || hasInlineScopedLeafAddress(effect)) {
    return {
      owner: effect.owner,
      before: effect.after,
      after: effect.before,
      subjectId: effect.subjectId,
      subjectFieldSegments: effect.subjectFieldSegments,
      plainBranchMembership: effect.plainBranchMembership ? {
        before: effect.plainBranchMembership.after,
        after: effect.plainBranchMembership.before
      } : void 0,
      fieldPresence: effect.fieldPresence ? {
        before: effect.fieldPresence.after,
        after: effect.fieldPresence.before
      } : void 0,
      path: effect.path,
      ownerPath: effect.ownerPath,
      structural,
      structuralContext: effect.structuralContext
    };
  }
  return {
    owner: effect.owner,
    before: realizationContext.getCurrentValue(effect.owner),
    after: realizationContext.getValueWithoutPendingTurn(turnId, effect.owner),
    subjectId: effect.subjectId,
    subjectFieldSegments: effect.subjectFieldSegments,
    fieldPresence: effect.fieldPresence ? {
      before: effect.fieldPresence.after,
      after: effect.fieldPresence.before
    } : void 0,
    structural,
    structuralContext: effect.structuralContext
  };
}
function hasInlineScopedLeafAddress(effect) {
  if (effect.subjectFieldSegments !== void 0) return true;
  return effect.structural === void 0 && effect.path !== effect.ownerPath;
}
function deriveStructuralRollbackBefore(effect) {
  switch (effect.structural) {
    case "add":
    case "rekey":
      return effect.after;
    case "remove":
      return effect.after;
    default:
      return effect.before;
  }
}
function deriveStructuralRollbackAfter(effect) {
  switch (effect.structural) {
    case "add":
      return effect.before;
    case "remove":
    case "rekey":
      return effect.before;
    default:
      return effect.after;
  }
}
function hasLaterStructuralDependency(pendingTurn, store) {
  const laterTurns = [...store.getTurns(), ...store.getPendingTurns()].filter(
    (turn) => turn.id > pendingTurn.id
  );
  return pendingTurn.effects.some((pendingEffect) => {
    if (!pendingEffect.structural || !pendingEffect.subjectId) {
      return false;
    }
    if (pendingEffect.structural === "add") {
      return laterTurns.some(
        (turn) => turn.effects.some((effect) => sameSubjectScope(effect, pendingEffect))
      );
    }
    const restoredStructuralResource = getRestoredStructuralResource(pendingEffect);
    if (restoredStructuralResource !== void 0 && laterTurns.some(
      (turn) => turn.effects.some(
        (effect) => getAcquiredStructuralResource(effect) === restoredStructuralResource && sameStructuralScope(effect, pendingEffect)
      )
    )) {
      return true;
    }
    return laterTurns.some(
      (turn) => turn.effects.some(
        (effect) => effect.structural !== void 0 && sameSubjectScope(effect, pendingEffect)
      )
    );
  });
}
function sameSubjectScope(left, right) {
  if (left.subjectId !== right.subjectId) {
    return false;
  }
  const leftOwnerPath = left.ownerPath;
  const rightOwnerPath = right.ownerPath;
  return typeof leftOwnerPath === "string" && typeof rightOwnerPath === "string" ? leftOwnerPath === rightOwnerPath : true;
}
function sameStructuralScope(left, right) {
  const leftOwnerPath = left.ownerPath;
  const rightOwnerPath = right.ownerPath;
  return typeof leftOwnerPath === "string" && typeof rightOwnerPath === "string" ? leftOwnerPath === rightOwnerPath : left.owner === right.owner;
}
function getRestoredStructuralResource(effect) {
  switch (effect.structural) {
    case "remove":
    case "rekey":
      return effect.before;
    default:
      return void 0;
  }
}
function getAcquiredStructuralResource(effect) {
  switch (effect.structural) {
    case "add":
    case "rekey":
      return effect.after;
    default:
      return void 0;
  }
}
function deriveCompensationStructuralEffect(structural) {
  switch (structural) {
    case "add":
      return "remove";
    case "remove":
      return "add";
    case "rekey":
      return "rekey";
    default:
      return void 0;
  }
}
function mapDiscardFailure(result) {
  if (result.reason === "turn-evicted") {
    return { ok: false, refusal: { kind: "turn-evicted" } };
  }
  return { ok: false, refusal: { kind: "turn-evicted" } };
}
function normalizeError(error) {
  if (error instanceof Error) {
    return error;
  }
  return new Error(String(error));
}
export {
  createPendingRollbackEffects,
  placeFieldReversalsWhileRowsExist,
  rollbackPendingTurnAt
};
