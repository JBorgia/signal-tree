import {Model} from './model.mjs';
const m=new Model();m.seed('a','A',7);m.seed('b','B',8);m.seed('c','C',9);m.field('t','a',17);m.remove('t','a');m.remove('t','b');m.order('foreign',['c']);
m.reject('t',false,undefined,{initial:[{id:'c',n:9}],stream:[{kind:'restore',id:'a',n:17,successor:'b'},{kind:'field',id:'a',n:7},{kind:'restore',id:'b',n:8,successor:'c'}]});
console.log('order after committed order plus older restoration',m.facts.get('order'));
