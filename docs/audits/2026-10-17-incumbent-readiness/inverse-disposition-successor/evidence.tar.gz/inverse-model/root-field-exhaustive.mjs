import assert from 'node:assert/strict';
import {Model} from './model.mjs';
let cases=0;
for(let n=1;n<=7;n++)for(let mask=1;mask<(1<<n);mask++){
 const m=new Model();m.seed('a','A',7);let expected=7;
 for(let i=0;i<n;i++){const own=!!(mask&(1<<i)),value=[7,99,7][i%3];m.field(own?'t':'foreign','a',value);if(!own)expected=value;}
 m.reject('t');assert.equal(m.facts.get('field:a'),expected,`n${n}mask${mask}`);
 assert.equal(m.turns.get('t'),'rejected');assert.equal(m.publications.length,1);cases++;
}
console.log('PASS',cases,'exhaustive field ownership sequences, including equal-value ABA');
