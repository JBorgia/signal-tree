Prewritten expectations (2026-10-23), before model execution.

1. Own rekey + foreign field: reverse key; preserve field (rekey-supersession-0 case1).
2. Own rekey + foreign removal: remain absent; reverse other own facts (case2).
3. Own rekey + foreign replacement: replacement remains untouched (case3).
4. Own rekey + occupied inverse key: atomic refusal, authority retained; clearing occupant permits retry (rekey-occupancy-0).
5. Own field + foreign field supersession: preserve newer field; other inverses proceed.
6. Own creation + foreign field dependency: atomic refusal, not blanket refusal of all foreign work.
7. Own rekey + foreign rekey: newer key survives (supersession hypothesis; needs contract audit).
8. Own full order + newer committed full order: newer order survives; no historical resurrection.
9. Own full order hidden by pending order: refuse oldest; rejecting newest reveals oldest.
10. Capture-gap: separated own segments construct/inspect/confirm without pretending foreign facts are authored.
11. Restore A, field A, restore B: sequential validation retains field dependency; final placement A,B,C.
12. Preparation failure publishes nothing; successful install publishes one complete snapshot.

Only 1–4 are directly sourced to inspected incumbent files. 5–12 are discriminators based on parent mandate; 7 awaits independent contract audit. Model cannot establish physical/ordinary adoption correctness.
