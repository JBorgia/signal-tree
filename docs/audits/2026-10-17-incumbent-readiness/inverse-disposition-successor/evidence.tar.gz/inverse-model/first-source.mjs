import assert from 'node:assert/strict';
// Finite fact model: existence, key, field, order are separately authored.
// Observations are dependencies only where the operation requires lifetime existence.
export class Model {
 constructor(){this.facts=new Map();this.events=[];this.turns=new Map();this.publications=[];this.seq=0;}
 seed(id,key,n){this.write('base',`exists:${id}`,true);this.write('base',`key:${id}`,key);this.write('base',`field:${id}`,n);}
 write(owner,fact,value,requires=[]){const e={id:++this.seq,owner,fact,before:this.facts.get(fact),value,requires:[...requires]};this.events.push(e);this.facts.set(fact,value);if(owner!=='base'&&owner!=='foreign'){if(!this.turns.has(owner))this.turns.set(owner,'pending');}return e;}
 field(o,id,n){assert(this.facts.get(`exists:${id}`));return this.write(o,`field:${id}`,n,[`exists:${id}`]);}
 rekey(o,id,key){assert(this.facts.get(`exists:${id}`));return this.write(o,`key:${id}`,key,[`exists:${id}`]);}
 remove(o,id){this.write(o,`exists:${id}`,false);}
 add(o,id,key,n){this.seedOwned(o,id,key,n);}
 seedOwned(o,id,key,n){this.write(o,`exists:${id}`,true);this.write(o,`key:${id}`,key,[`exists:${id}`]);this.field(o,id,n);}
 order(o,ids){this.write(o,'order',[...ids],ids.map(id=>`exists:${id}`));}
 inspect(o){return this.events.filter(e=>e.owner===o).map(e=>({authored:e.fact,id:e.id,requires:e.requires}));}
 confirm(o){assert.equal(this.turns.get(o),'pending');this.turns.set(o,'confirmed');}
 reject(o,fail=false){assert.equal(this.turns.get(o),'pending');const draft=new Map(this.facts);const own=this.events.filter(e=>e.owner===o);
  for(const e of own.toReversed()){
   const later=this.events.filter(x=>x.id>e.id&&x.owner!==o&&this.turns.get(x.owner)!=='rejected');
   if(later.some(x=>x.fact===e.fact))continue; // same authored fact supersedes
   const id=e.fact.split(':')[1];
   if(id&&draft.get(`exists:${id}`)===false&&e.fact!==`exists:${id}`)continue;
   if(e.fact.startsWith('exists:')&&e.before!==true&&later.some(x=>x.requires.includes(e.fact)))throw Error('dependency');
   if(e.fact==='order'&&later.some(x=>x.fact==='order'&&this.turns.get(x.owner)==='pending'))throw Error('dependency');
   if(e.fact.startsWith('key:')&&draft.get(`exists:${id}`))for(const [k,v] of draft)if(k.startsWith('key:')&&k!==e.fact&&v===e.before&&draft.get(`exists:${k.slice(4)}`))throw Error('occupancy');
   if(e.before===undefined)draft.delete(e.fact);else draft.set(e.fact,e.before);
  }
  if(fail)throw Error('prepare');this.facts=draft;this.turns.set(o,'rejected');this.publications.push([...draft]);
 }
}
let checks=0;function test(name,fn){fn();checks++;console.log(`PASS ${name}`)}
const base=()=>{const m=new Model();m.seed('a','A',7);return m;};
test('foreign field survives rekey inverse',()=>{let m=base();m.rekey('t','a','B');m.field('foreign','a',99);m.reject('t');assert.equal(m.facts.get('key:a'),'A');assert.equal(m.facts.get('field:a'),99)});
test('foreign removal/replacement not resurrected',()=>{for(const replacement of [false,true]){let m=base();m.rekey('t','a','B');m.remove('foreign','a');if(replacement)m.add('foreign','new','B',88);m.reject('t');assert.equal(m.facts.get('exists:a'),false);if(replacement)assert.equal(m.facts.get('field:new'),88)}});
test('occupied inverse atomic refusal and useful retry',()=>{let m=base();m.rekey('t','a','B');m.add('foreign','new','A',88);let before=[...m.facts];assert.throws(()=>m.reject('t'),/occupancy/);assert.deepEqual([...m.facts],before);assert.equal(m.turns.get('t'),'pending');m.remove('foreign','new');m.reject('t');assert.equal(m.facts.get('key:a'),'A')});
test('foreign field supersedes only field',()=>{let m=base();m.field('t','a',8);m.field('foreign','a',9);m.reject('t');assert.equal(m.facts.get('field:a'),9)});
test('creation dependency refuses atomically',()=>{let m=base();m.add('t','b','B',8);m.field('foreign','b',9);let before=[...m.facts];assert.throws(()=>m.reject('t'),/dependency/);assert.deepEqual([...m.facts],before)});
test('foreign rekey supersession hypothesis',()=>{let m=base();m.rekey('t','a','B');m.rekey('foreign','a','C');m.reject('t');assert.equal(m.facts.get('key:a'),'C')});
test('committed order supersedes older order',()=>{let m=base();m.order('t',['a']);m.order('u',[]);m.confirm('u');m.reject('t');assert.deepEqual(m.facts.get('order'),[])});
test('private preparation failure no publication',()=>{let m=base();m.field('t','a',8);let before=[...m.facts];assert.throws(()=>m.reject('t',true),/prepare/);assert.deepEqual([...m.facts],before);assert.equal(m.publications.length,0);m.reject('t');assert.equal(m.publications.length,1)});
test('capture gap construct inspect confirm',()=>{let m=base();m.rekey('t','a','C');m.field('foreign','a',123);m.field('t','a',99);m.rekey('t','a','D');assert.equal(m.inspect('t').length,3);assert(!m.inspect('t').some(x=>x.id===5));m.confirm('t');assert.equal(m.turns.get('t'),'confirmed')});
console.log(`${checks} bounded model cases pass`);
