import assert from 'node:assert/strict';
// Finite fact model: existence, key, field, order are separately authored.
// Observations are dependencies only where the operation requires lifetime existence.
export class Model {
 constructor(){this.facts=new Map();this.events=[];this.turns=new Map();this.publications=[];this.seq=0;}
 seed(id,key,n){this.write('base',`exists:${id}`,true);this.write('base',`key:${id}`,key);this.write('base',`field:${id}`,n);}
 write(owner,fact,value,requires=[]){const e={id:++this.seq,owner,fact,before:this.facts.get(fact),value,requires:[...requires]};this.events.push(e);this.facts.set(fact,value);if(owner!=='base'&&owner!=='foreign'){if(!this.turns.has(owner))this.turns.set(owner,'pending');}return e;}
 field(o,id,n){assert(this.facts.get(`exists:${id}`));return this.write(o,`field:${id}`,n,[`exists:${id}`]);}
 assertVacant(key,id){for(const [fact,value] of this.facts)if(fact.startsWith('key:')&&fact!=='key:'+id&&value===key&&this.facts.get('exists:'+fact.slice(4)))throw Error('occupied admission');}
 rekey(o,id,key){this.assertVacant(key,id);assert(this.facts.get(`exists:${id}`));return this.write(o,`key:${id}`,key,[`exists:${id}`]);}
 remove(o,id){this.write(o,`exists:${id}`,false);}
 add(o,id,key,n){this.seedOwned(o,id,key,n);}
 seedOwned(o,id,key,n){this.assertVacant(key,id);assert(!this.facts.get('exists:'+id));this.write(o,`exists:${id}`,true);this.write(o,`key:${id}`,key,[`exists:${id}`]);this.field(o,id,n);}
 order(o,ids){this.write(o,'order',[...ids],ids.map(id=>`exists:${id}`));}
 compact(){if([...this.turns.values()].includes('pending'))return false;this.events=[];this.turns.clear();for(const [fact,value] of [...this.facts])if(fact.startsWith('exists:')&&value===false){const id=fact.slice(7);this.facts.delete(fact);this.facts.delete('key:'+id);this.facts.delete('field:'+id);}return true;}
 visibleOrder(){return (this.facts.get('order')??[]).filter(id=>this.facts.get('exists:'+id));}
 reference(id){return ()=>this.facts.get('exists:'+id)?{id,key:this.facts.get('key:'+id),n:this.facts.get('field:'+id)}:undefined;}
 inspect(o){return this.events.filter(e=>e.owner===o).map(e=>({authored:e.fact,id:e.id,requires:e.requires}));}
 confirm(o){assert.equal(this.turns.get(o),'pending');this.turns.set(o,'confirmed');}
 reject(o,fail=false,prepareHook,realization){const revision=this.seq;assert.equal(this.turns.get(o),'pending');const draft=new Map(this.facts);const own=this.events.filter(e=>e.owner===o);
  for(const e of own.toReversed()){
   const later=this.events.filter(x=>x.id>e.id&&x.owner!==o&&this.turns.get(x.owner)!=='rejected').filter(x=>this.turns.get(x.owner)==='pending'||!this.events.some(y=>y.id>x.id&&y.fact===x.fact&&this.turns.get(y.owner)!=='pending'&&this.turns.get(y.owner)!=='rejected'));
   if(later.some(x=>x.fact===e.fact&&this.turns.get(x.owner)==='pending'))throw Error('dependency');
   if(e.fact.startsWith('key:')&&later.some(x=>x.fact===e.fact)&&draft.get('exists:'+e.fact.slice(4)))throw Error('dependency');
   if(later.some(x=>x.fact===e.fact))continue; // terminal authored field fact supersedes
   const id=e.fact.split(':')[1];
   if(id&&draft.get(`exists:${id}`)===false&&e.fact!==`exists:${id}`)continue;
   if(e.fact.startsWith('exists:')&&e.before!==true&&later.some(x=>x.requires.includes(e.fact)))throw Error('dependency');
   if(e.fact==='order'&&later.some(x=>x.fact==='order'&&this.turns.get(x.owner)==='pending'))throw Error('dependency');
   if(e.fact.startsWith('key:')&&draft.get(`exists:${id}`))for(const [k,v] of draft)if(k.startsWith('key:')&&k!==e.fact&&v===e.before&&draft.get(`exists:${k.slice(4)}`))throw Error('occupancy');
   if(e.before===undefined)draft.delete(e.fact);else draft.set(e.fact,e.before);
  }
  const occupied=new Map();for(const [fact,value] of draft)if(fact.startsWith('exists:')&&value){const id=fact.slice(7),key=draft.get('key:'+id);assert(key!==undefined,'missing key');if(occupied.has(key))throw Error('occupancy');occupied.set(key,id);}
  if(realization){const topology=prepareTopology(realization.initial,realization.stream);for(const row of topology){assert.equal(draft.get('exists:'+row.id),true,'realization existence mismatch');assert.equal(draft.get('field:'+row.id),row.n,'realization field mismatch');}const active=[...draft].filter(([fact,value])=>fact.startsWith('exists:')&&value).map(([fact])=>fact.slice(7));assert.deepEqual([...topology.map(row=>row.id)].sort(),active.sort(),'incomplete realization');const foreignOrder=this.events.findLast(e=>e.fact==='order'&&e.owner!==o&&this.turns.get(e.owner)!=='rejected');if(foreignOrder){const selected=draft.get('order').filter(id=>draft.get('exists:'+id));assert.deepEqual([...selected].sort(),active.sort(),'surviving order membership dependency');draft.set('order',selected);}else draft.set('order',topology.map(row=>row.id));}
  prepareHook?.();if(this.seq!==revision)throw Error('reentry');if(fail)throw Error('prepare');this.facts=draft;this.turns.set(o,'rejected');this.publications.push([...draft]);
 }
}
let checks=0;function test(name,fn){fn();checks++;console.log(`PASS ${name}`)}
const base=()=>{const m=new Model();m.seed('a','A',7);return m;};
test('foreign field survives rekey inverse',()=>{let m=base();m.rekey('t','a','B');m.field('foreign','a',99);m.reject('t');assert.equal(m.facts.get('key:a'),'A');assert.equal(m.facts.get('field:a'),99)});
test('foreign removal/replacement not resurrected',()=>{for(const replacement of [false,true]){let m=base();m.rekey('t','a','B');m.remove('foreign','a');if(replacement)m.add('foreign','new','B',88);m.reject('t');assert.equal(m.facts.get('exists:a'),false);if(replacement)assert.equal(m.facts.get('field:new'),88)}});
test('occupied inverse atomic refusal and useful retry',()=>{let m=base();m.rekey('t','a','B');m.add('foreign','new','A',88);let before=[...m.facts];assert.throws(()=>m.reject('t'),/occupancy/);assert.deepEqual([...m.facts],before);assert.equal(m.turns.get('t'),'pending');m.remove('foreign','new');m.reject('t');assert.equal(m.facts.get('key:a'),'A')});
test('foreign field supersedes only field',()=>{let m=base();m.field('t','a',8);m.field('foreign','a',9);m.reject('t');assert.equal(m.facts.get('field:a'),9)});
test('creation dependency refuses atomically',()=>{let m=base();m.add('t','b','B',8);m.field('foreign','b',9);let before=[...m.facts];assert.throws(()=>m.reject('t'),/dependency/);assert.deepEqual([...m.facts],before)});
test('foreign rekey dependency refuses',()=>{let m=base();m.rekey('t','a','B');m.rekey('foreign','a','C');assert.throws(()=>m.reject('t'),/dependency/);assert.equal(m.facts.get('key:a'),'C');assert.equal(m.turns.get('t'),'pending')});
test('committed order supersedes older order',()=>{let m=base();m.order('t',['a']);m.order('u',[]);m.confirm('u');m.reject('t');assert.deepEqual(m.facts.get('order'),[])});
test('private preparation failure no publication',()=>{let m=base();m.field('t','a',8);let before=[...m.facts];assert.throws(()=>m.reject('t',true),/prepare/);assert.deepEqual([...m.facts],before);assert.equal(m.publications.length,0);m.reject('t');assert.equal(m.publications.length,1)});
test('capture gap construct inspect confirm',()=>{let m=base();m.rekey('t','a','C');m.field('foreign','a',123);m.field('t','a',99);m.rekey('t','a','D');assert.equal(m.inspect('t').length,3);assert(!m.inspect('t').some(x=>x.id===5));m.confirm('t');assert.equal(m.turns.get('t'),'confirmed')});
console.log(`${checks} bounded model cases pass`);
test('pending hiding reversible and oldest refuses',()=>{let m=base();m.order('t',['a']);m.order('u',[]);const before=[...m.facts];assert.throws(()=>m.reject('t'),/dependency/);assert.deepEqual([...m.facts],before);m.reject('u');assert.deepEqual(m.facts.get('order'),['a'])});
// Additional adversarial controls: do not count a historical dependency as live
// merely because its event remains available for recovery.
test('creation foreign field then foreign removal releases dependency',()=>{let m=base();m.add('t','b','B',8);m.field('foreign','b',9);m.remove('foreign','b');m.reject('t');assert.equal(m.facts.get('exists:b'),false)});
test('pending field cannot supersede authority',()=>{let m=base();m.field('t','a',8);m.field('u','a',9);assert.throws(()=>m.reject('t'),/dependency/);assert.equal(m.turns.get('t'),'pending');m.reject('u');m.reject('t');assert.equal(m.facts.get('field:a'),7)});
test('exact occupancy gap admission and confirmation',()=>{let m=base();m.seed('b','b',8);
 // Physical inspection moves a to c, ordinary occupancy is still a.
 const physical=new Map([['a','c'],['b','b']]);
 m.remove('t','a');m.rekey('t','b','A');physical.set('b','A');
 // Independent necessary-existence author explicitly installs ordinary a at c.
 m.write('foreign','exists:a',true);m.write('foreign','key:a','c',['exists:a']);m.field('foreign','a',123);
 m.field('t','a',99);m.rekey('t','a','d');m.rekey('t','a','e');physical.set('a','e');
 assert.equal(m.facts.get('field:a'),99);assert.equal(m.facts.get('key:a'),'e');assert.equal(m.inspect('t').length,5);
 assert.equal(m.inspect('t').filter(x=>x.authored==='exists:a').length,1);m.confirm('t');assert.equal(m.turns.get('t'),'confirmed');
});
// Concrete representation falsifier. The stream stores field before=8 while
// reversing the lifetime removal first revives it. Both must compose privately.
test('remove followed by inverse restoration retains key and payload',()=>{let m=base();m.field('t','a',8);m.remove('t','a');m.reject('t');assert.equal(m.facts.get('exists:a'),true);assert.equal(m.facts.get('field:a'),7);assert.equal(m.facts.get('key:a'),'A')});
test('prepare reentry preserves newer write and useful retry',()=>{let m=base();m.field('t','a',8);assert.throws(()=>m.reject('t',false,()=>m.field('foreign','a',9)),/reentry/);assert.equal(m.facts.get('field:a'),9);assert.equal(m.turns.get('t'),'pending');assert.equal(m.publications.length,0);m.reject('t');assert.equal(m.facts.get('field:a'),9)});
test('postdrain reclamation preserves held retired identity',()=>{let m=base();let held=m.reference('a');m.rekey('t','a','B');m.remove('foreign','a');m.add('foreign','replacement','B',88);assert.equal(m.compact(),false);m.reject('t');assert.equal(m.compact(),true);assert.equal(m.events.length,0);assert.equal(m.turns.size,0);assert.equal(held(),undefined);assert.equal(m.reference('replacement')().n,88)});
export function prepareTopology(initial,stream){const rows=new Map(initial.map(r=>[r.id,{...r}])),placements=[];for(const op of stream){if(op.kind==='restore'){assert(!rows.has(op.id));rows.set(op.id,{id:op.id,n:op.n});placements.push(op);}else if(op.kind==='transfer'){assert(rows.has(op.id));placements.push(op);}else if(op.kind==='field'){assert(rows.has(op.id),'missing lifetime');rows.get(op.id).n=op.n;}else throw Error('unknown');}
 const before=new Map();for(const p of placements){assert(rows.has(p.successor),'missing successor');assert(!before.has(p.successor),'ambiguous');before.set(p.successor,p.id);}
 const moved=new Set(placements.map(p=>p.id)),out=[],seen=new Set();function emit(id){assert(!seen.has(id),'cycle');seen.add(id);if(before.has(id))emit(before.get(id));out.push(rows.get(id));}for(const row of initial)if(!moved.has(row.id))emit(row.id);assert.equal(out.length,rows.size);return out;}
test('sequential inverse stream separate from final placement',()=>{let initial=[{id:'c',n:9}];let stream=[{kind:'restore',id:'a',n:8,successor:'b'},{kind:'field',id:'a',n:7},{kind:'restore',id:'b',n:8,successor:'c'}];assert.deepEqual(prepareTopology(initial,stream),[{id:'a',n:7},{id:'b',n:8},{id:'c',n:9}]);assert.deepEqual(initial,[{id:'c',n:9}]);assert.throws(()=>prepareTopology(initial,[stream[1],stream[0],stream[2]]),/missing lifetime/)});
test('two active transfers use complete topology',()=>{assert.deepEqual(prepareTopology([{id:'c',n:9},{id:'a',n:7},{id:'b',n:8}],[{kind:'transfer',id:'a',successor:'b'},{kind:'transfer',id:'b',successor:'c'}]).map(x=>x.id),['a','b','c'])});
console.log('ALL',checks,'finite controls pass; bounded successor chains only');
test('displaced capture gap rejects without undoing foreign admission',()=>{let m=base();m.seed('b','b',8);m.remove('t','a');m.rekey('t','b','A');m.write('foreign','exists:a',true);m.write('foreign','key:a','c',['exists:a']);m.field('foreign','a',123);m.field('t','a',99);m.rekey('t','a','d');m.rekey('t','a','e');m.reject('t');assert.equal(m.facts.get('exists:a'),true);assert.equal(m.facts.get('key:a'),'c');assert.equal(m.facts.get('field:a'),123);assert.equal(m.facts.get('key:b'),'b')});
test('combined rejection prepares restoration field and placement atomically',()=>{let m=base();m.seed('b','B',8);m.seed('c','C',9);m.field('t','a',17);m.remove('t','a');m.remove('t','b');m.reject('t',false,undefined,{initial:[{id:'c',n:9}],stream:[{kind:'restore',id:'a',n:17,successor:'b'},{kind:'field',id:'a',n:7},{kind:'restore',id:'b',n:8,successor:'c'}]});assert.deepEqual(m.facts.get('order'),['a','b','c']);assert.equal(m.facts.get('field:a'),7);assert.equal(m.publications.length,1)});
test('foreign pending order existence dependency releases on rejection',()=>{let m=base();m.add('t','b','B',8);m.order('u',['a','b']);assert.throws(()=>m.reject('t'),/dependency/);assert.equal(m.turns.get('u'),'pending');m.reject('u');m.reject('t');assert.equal(m.facts.get('exists:b'),undefined)});
test('confirmed order lifetime obligation survives confirmation',()=>{let m=base();m.add('t','b','B',8);m.order('u',['a','b']);m.confirm('u');assert.throws(()=>m.reject('t'),/dependency/);assert.equal(m.turns.get('t'),'pending')});
test('obsolete order dependency releases after committed replacement',()=>{let m=base();m.add('t','b','B',8);m.order('u',['a','b']);m.confirm('u');m.order('foreign',['a']);m.reject('t');assert.equal(m.facts.get('exists:b'),undefined)});
test('removal revival cannot duplicate foreign key occupancy',()=>{let m=base();m.remove('t','a');m.add('foreign','new','A',88);let before=[...m.facts];assert.throws(()=>m.reject('t'),/occupancy/);assert.deepEqual([...m.facts],before);assert.equal(m.turns.get('t'),'pending');m.remove('foreign','new');m.reject('t');assert.equal(m.facts.get('exists:a'),true)});
test('surviving committed order wins over historical placement plan',()=>{let m=base();m.seed('b','B',8);m.seed('c','C',9);m.order('t',['a','b','c']);m.order('foreign',['c','b','a']);m.reject('t',false,undefined,{initial:[{id:'c',n:9},{id:'a',n:7},{id:'b',n:8}],stream:[{kind:'transfer',id:'a',successor:'b'},{kind:'transfer',id:'b',successor:'c'}]});assert.deepEqual(m.facts.get('order'),['c','b','a']);assert.equal(m.turns.get('t'),'rejected')});
test('committed removal projects authored order without retired lifetime',()=>{let m=base();m.add('t','b','B',8);m.order('foreign',['a','b']);m.remove('foreign','b');m.reject('t',false,undefined,{initial:[{id:'a',n:7}],stream:[]});assert.deepEqual(m.visibleOrder(),['a']);assert.equal(m.turns.get('t'),'rejected')});
test('pending removal hides order with recovery identity retained',()=>{let m=base();m.add('t','b','B',8);m.order('foreign',['a','b']);m.remove('u','b');assert.deepEqual(m.visibleOrder(),['a']);assert.throws(()=>m.reject('t'),/dependency/);m.reject('u');assert.deepEqual(m.visibleOrder(),['a','b']);assert.throws(()=>m.reject('t'),/dependency/)});
test('confirmed removal releases creator dependency',()=>{let m=base();m.add('t','b','B',8);m.order('foreign',['a','b']);m.remove('u','b');m.confirm('u');m.reject('t');assert.deepEqual(m.visibleOrder(),['a'])});
test('same key replacement never retargets old ordering lifetime',()=>{let m=base();m.add('t','b','B',8);m.order('foreign',['a','b']);m.remove('foreign','b');m.add('foreign','new','B',88);m.reject('t');assert.deepEqual(m.visibleOrder(),['a']);assert.equal(m.reference('new')().n,88);assert.equal(m.reference('b')(),undefined)});
