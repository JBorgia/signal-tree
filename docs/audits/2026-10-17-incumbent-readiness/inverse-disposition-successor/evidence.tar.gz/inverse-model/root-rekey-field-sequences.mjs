import assert from 'node:assert/strict';
import {Model} from './model.mjs';
let checks=0;
for(let n=1;n<=7;n++)for(let mask=1;mask<(1<<n);mask++){
 const m=new Model();m.seed('a','A',7);let field=7;
 for(let i=0;i<n;i++)if(mask&(1<<i))m.rekey('t','a',i%2?'B':'C');else {field=100+i;m.field('foreign','a',field);}
 m.reject('t');assert.equal(m.facts.get('key:a'),'A');assert.equal(m.facts.get('field:a'),field);checks++;
}
console.log('PASS',checks,'bounded rekey/foreign-field interleavings');
