# Bounded inverse model

Executable `model.mjs`, Node24.15.0, nineteen named controls pass in `extended-final.log`. The intermediate count line precedes final control and is not the final total. First nine-case source/log and pending-order first red preserved. Initial same-fact classifier incorrectly treated pending ordering as committed; lifecycle-first classification corrected that model defect. Foreign-rekey initial expectation was explicitly a hypothesis; contract audit requires dependency refusal, now encoded. These are model corrections, not runtime evidence.

Per-event immutable IDs describe authored existence, key, field, or explicit order facts; required lifetime facts remain distinct. Own segments stay chronological across foreign admissions. Rejection reverses own events against current surviving foreign facts privately, refuses pending overlap/structural dependencies/occupied inverse destinations, retains authority, and publishes once after successful validation. Reentry invalidates preparation by revision and useful retry preserves its foreign write. Confirmed field replacement supersedes, newer field survives rekey inverse, removal/replacement detaches old lifetime. Vacancy is validated at admission. Postdrain compaction releases events/terminalturns/retired facts; held identity accessor stays detached.

Exact occupancy-gap control displaces ordinary A to absent, foreign admission binds same lifetime at c with123, own writes99 and c→d→e. Construct/inspect/confirm passes. Separate rejection preserves foreign c/123 and restores other lifetime's original key. This is a model prediction, not incumbent public behavior proof.

Sequential inverse validation and final placement are separately executable. RestoreA→fieldA→restoreB validates in semantic order then resolves A,B,C. Two active transfers also resolve A,B,C. The helper supports unambiguous successor chains only and rejects missing anchors; approved full successor/predecessor policy is not reimplemented. It is not yet invoked from the generic fact rejection engine. Therefore this is bounded mechanism evidence, not a complete native realization plan or qualification.

Explicit full-order committed supersession test remains a hypothesis pending order-specific source adjudication; it must not authorize a semantic change. Broad adoption/physical99-ordinary7 transitions and restoration callbacks are outside this small model.

Replay: `node /private/tmp/occupancy-adjudication/inverse-model/model.mjs`.

## Combined revision

`combined-final.log` has 23 named passing controls. `reject` now calls `prepareTopology` on the supplied inverse stream before installation, validates every realized row's existence/field against independently computed inverse disposition, and installs final order in the same draft. Combined restoreA/fieldA/restoreB asserts one publication. Supplied inverse stream remains an explicit model input; native lowering is not proved.

`combined-first-source.mjs` and `combined-first.log` preserve obsolete confirmed-order dependency refusal. Generic surviving-event classification now distinguishes a terminal fact superseded by a later terminal fact from retained recovery history. Pending fact responsibility remains reversible and conservatively blocks overlapping rejection. New controls cover pending order release by rejection, confirmed order retained existence obligation, committed replacement releasing obsolete requirement, and unchanged authority following refusal. This supersedes the earlier report's separate-helper limitation; successor/predecessor completeness limitation remains.

## Prepared authority revision

25 named controls pass in `qualified-model.log`; source SHA256 e4a689cce12753ccdf7c4b156fd7c9d964bd9844958bdf67f737c23eaee14286. `frozen23-source.mjs` preserved. `occupancy-final-first.log` records missing occupied-key refusal when existence reversal revives a lifetime; generic complete-draft occupancy uniqueness now validates that boundary. Stale placement cannot override surviving explicit order: final selection uses surviving order with exact active-membership agreement, otherwise uses prepared placement result. Added unchanged scenario newer c,b,a order versus historical a,b,c placement; rejection succeeds preserving c,b,a.

This remains a finite model, with array/map whole-model passes allowed for falsification; it establishes no native sparsity or cost claim. Full predecessor/successor fallback/lifetime policy remains the native resolver's obligation. Source review must verify whether order-survivor choice is the governing incumbent policy before using it for implementation.

## Order/membership lifecycle revision

Frozen25 retained. Reviewer adjudication `../INVERSE-ORDER-REMOVAL-ADJUDICATION.md` establishes native removal affects ordered membership as well as existence. Model now distinguishes authored order facts from visible active-lifetime projection. 29 cases pass `order-removal-final.log`, SHA256 8c63b564b3c42a85cbae28f8d99e86bdc49c8c133ae9171d15884301e6e0f54f. Creator rejection succeeds after independent committed removal; pending removal hides membership but retained fact IDs restore visibility on its rejection; confirmation releases the removal's dependency; same business key replacement does not retarget old ordering references. These are derived model-composition cases, not observed native passes.

Known model boundary: add admission does not yet author independent placement when an explicit order already exists. Therefore `visibleOrder` currently lists only specified active IDs; it is not a complete model of append/prepend or arbitrary structural membership publication. This must be reviewed before claiming complete ordering model coverage.

## Partial constraint composition

Frozen29 retained. 31 named controls pass `partial-constraint-final.log`; source SHA256 14ab9e0f085a63c5d0de7285b8c4e1f24f7cfc49fb66763cc71d03e4fb9b4540. A surviving explicit order mentioning a subset of active identities is validated as a subsequence constraint on complete privately prepared topology. Unmentioned replacement placement comes from supplied topology, never guessed by appending missing IDs. All-named surviving order still selects CBA over stale ABC hints. Conflict between partial constraint and supplied topology causes atomic model refusal; whether an actual producer must derive a different valid topology remains a realization obligation, not a newly approved public refusal policy.

Root's unchanged `root-occupancy-falsifier.mjs`, `root-order-removal-realization.mjs`, and `root-replacement-realization.mjs` rerun against this source without assertion errors; logs `*-rerun.log`. Postdrain compaction prunes inactive order IDs only once no pending authority remains. Pending removal still retains order recovery identity and rejection restores its visibility.
