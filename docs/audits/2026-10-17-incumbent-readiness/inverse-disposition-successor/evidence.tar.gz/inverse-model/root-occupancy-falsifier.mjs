import assert from 'node:assert/strict';
import {Model} from './model.mjs';
const m=new Model();m.seed('a','A',7);m.remove('t','a');m.add('foreign','new','A',99);
const before=[...m.facts];assert.throws(()=>m.reject('t'),/occupancy/);assert.deepEqual([...m.facts],before);assert.equal(m.turns.get('t'),'pending');
