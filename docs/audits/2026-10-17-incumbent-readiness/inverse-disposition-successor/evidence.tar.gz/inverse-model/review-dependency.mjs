import {Model} from './model.mjs';
const m=new Model();m.seed('a','A',7);m.add('t','b','B',8);m.order('foreign',['a','b']);m.order('foreign',['a']);
try{m.reject('t');console.log('obsolete order dependency released',m.facts.get('exists:b'));}catch(e){console.log('REVIEW FAILURE obsolete order dependency retained:',e.message);process.exitCode=1;}
