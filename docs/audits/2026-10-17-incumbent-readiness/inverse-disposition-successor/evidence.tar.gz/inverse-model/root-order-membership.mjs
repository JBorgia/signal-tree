import assert from 'node:assert/strict';
import {Model} from './model.mjs';
const m=new Model();m.seed('a','A',7);m.add('t','b','B',8);m.order('foreign',['a','b']);m.remove('foreign','b');m.reject('t');
assert.equal(m.facts.get('exists:b'),false);
assert.deepEqual(m.facts.get('order'),['a'],'visible order must not retain a removed lifetime');
