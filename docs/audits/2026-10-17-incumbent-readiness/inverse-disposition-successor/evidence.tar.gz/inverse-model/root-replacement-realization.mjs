import assert from 'node:assert/strict';
import {Model} from './model.mjs';
const m=new Model();m.seed('a','A',7);m.add('t','b','B',8);m.order('foreign',['a','b']);m.remove('foreign','b');m.add('foreign','new','B',88);
m.reject('t',false,undefined,{initial:[{id:'a',n:7},{id:'new',n:88}],stream:[]});
assert.equal(m.turns.get('t'),'rejected');assert.equal(m.facts.get('exists:new'),true);
