import {Model} from './model.mjs';
const m=new Model();m.seed('a','A',7);m.seed('b','B',8);m.seed('c','C',9);m.order('t',['a','b','c']);m.order('foreign',['c','b','a']);
m.reject('t',false,undefined,{initial:[{id:'c',n:9},{id:'b',n:8},{id:'a',n:7}],stream:[{kind:'transfer',id:'a',successor:'b'},{kind:'transfer',id:'b',successor:'c'}]});
console.log('expected c,b,a; actual',m.facts.get('order'));
