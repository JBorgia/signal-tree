import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '../candidate/packages/kernel/src/index';
import {preparePointRealization} from '../candidate/packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter';
import {getOwnedPositionIds,getOwnedSubjectIds} from '../candidate/packages/kernel/src/lib/internals/owned-mutation';
import {withWriteContext} from '../candidate/packages/kernel/src/lib/write-context';
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
try{const r=t.$.rows;r.addOne({id:'a',n:7});for(let i=0;i<40;i++)await Promise.resolve();const a=r.byIdOrFail('a');
const owner=getOwnedPositionIds(r)![0],subjectId=getOwnedSubjectIds(a.n)![0];
const p=t.transact(()=>{withWriteContext({intent:'system',participation:'realized'},()=>r.updateOne('a',{n:99}));a.n(8);const plan=preparePointRealization(t,[{owner,subjectId,subjectFieldSegments:['n'],before:8,after:123}]);assert.ok(plan);plan.install();plan.publish();});
console.log('before',a.n(),JSON.stringify(p.inspect()));let refused=false;try{p.rollback();}catch{refused=true;}console.log('after',a.n(),{refused});assert.equal(a.n(),123);if(refused){assert.doesNotThrow(()=>p.inspect());p.confirm();}
}finally{t.destroy();}
