import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/index';
import {withWriteContext} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/write-context';
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
try{const r=t.$.rows;const values=new Map(['a','b','c'].map((id,i)=>[id,{id,n:i}]));const order=(ids:string[])=>r.setAll(ids.map(id=>values.get(id)!));order(['a','b','c']);for(let i=0;i<40;i++)await Promise.resolve();
const p=t.transact(()=>{order(['c','b','a']);withWriteContext({intent:'system',participation:'realized'},()=>order(['b','c','a']));order(['a','c','b']);});
let refused=false;try{p.rollback();}catch{refused=true;}console.log(JSON.stringify({refused,ids:r.ids()}));
if(refused){assert.deepEqual(r.ids(),['a','c','b']);assert.doesNotThrow(()=>p.inspect());p.confirm();}else assert.deepEqual(r.ids(),['b','c','a']);
}finally{t.destroy();}
