# Existing anchor-distance work

One private StructuralStore placement request, both anchors live at first/last
positions. No public producer or transaction timing claim. Instrumented only the
probe's linked-node next getters; runtime source unmodified. Node24.15 esbuild.

16 members:15 next reads;128:127;1024:1023. Source nodePrecedes walks from left
to right; approved successor policy currently uses it when both anchors survive.
Production87f6831f also contains this walk (git show verified). Thus this is an
existing substrate cost, not newly caused by the three-line topology correction.
It prevents claiming arbitrary distant-anchor placement constant-time. One-field
settlement's separate zero-enumeration contract is not falsified by this probe.
No performance optimization or acceptance relaxation is proposed here.

Replay from candidate: node ../root-review/anchor-distance.mjs. Source/build/raw
outputs preserved adjacent. Counts cover link traversal only, not CPU or heap.
