import assert from 'node:assert/strict';
import {StructuralStore} from '../candidate/packages/kernel/src/lib/physical/structural-store';
for(const size of [16,128,1024]){
 const store=new StructuralStore<string>();for(let i=1;i<=size;i++)store.createSubject(i,String(i));
 const nodes=(store as unknown as {activeNodesBySubject:Map<number,{next:unknown}>}).activeNodesBySubject;
 let nextReads=0;
 for(const node of nodes.values()){let next=node.next;Object.defineProperty(node,'next',{configurable:true,get(){nextReads++;return next;},set(value){next=value;}});}
 const result=store.resolveSubjectRestorePlacement(1,size);
 assert.equal(result.afterSubject,size);
 console.log(JSON.stringify({size,requestedPlacements:1,nextReads}));
}
