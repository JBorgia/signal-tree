import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '../candidate/packages/kernel/src/index';
import {withWriteContext} from '../candidate/packages/kernel/src/lib/write-context';
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
try{const r=t.$.rows;r.setAll([{id:'a',n:7}]);for(let i=0;i<40;i++)await Promise.resolve();const a=r.byIdOrFail('a');
 const p=t.transact(()=>{r.changeId('a','b');withWriteContext({intent:'system',participation:'realized'},()=>a.n(123));r.changeId('b','c');});
 assert.equal(a.n(),123);console.log('before',JSON.stringify({ids:r.ids(),inspection:p.inspect()}));
 p.rollback();assert.deepEqual(r.ids(),['a']);assert.equal(a.n(),123);console.log('PASS same-lifetime own rekeys around independent field preserve foreign field');
}finally{t.destroy();}
