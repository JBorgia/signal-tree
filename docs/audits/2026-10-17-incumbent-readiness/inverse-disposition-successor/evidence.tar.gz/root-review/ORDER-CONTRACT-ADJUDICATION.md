# Interleaved full-order contract adjudication

Read-only source/decision audit, 2026-10-23. No runtime rerun or edit by this reviewer.

## Sequence and evidence

ABC → own full-order CBA → independent realized full-order BCA → own full-order ACB; reject the single transaction. Supplied candidate and comparator logs report successful ABC. Root falsifier permits BCA or atomic refusal retaining ACB. That falsifier's expected outcome is not yet established by the frozen contract.

The latest own operation is explicit complete order authorship, not a rekey's incidental observed order. semantic-transition-plan/README.md W5 explicitly excludes implicit order adoption; W8 expressly authors exact input order. Therefore the earlier rekey/incidental-topology findings do not decide this sequence.

transactions.ts captureCollectionOrderIntoBucket lines2438–2443 deliberately retains first beforeSubjects and latest afterSubjects. Lines2512–2521 derive one pending order delta. This explains ABC but does not itself legitimize it. No per-segment foreign ordering authority is represented there.

Existing queued-inspection-review.spec.ts 24–42 validates realized writes before/after own writes inside callback, but only inspection current/superseded status for scalar cases, not structural order inverse. proposal-rejection-0.spec.ts and rekey-supersession-0.spec.ts distinguish later replacement from existence dependencies; neither establishes whether an intermediate foreign full-order remains authoritative after another own full-order explicitly replaces it.

The approved newest-open-first scope (reconciliation/README.md lines18 onward) permits atomic retryable refusal for overlapping pending work. It does not prescribe the intermediate committed full-order's fate inside one callback. The approved successor-placement policy concerns where inverse restoration places lifetimes; no members are missing or restored here. It does not answer full-order supersession.

## Disposition

This is a concrete compatibility question, not yet a proven runtime defect. The prewritten BCA-or-refusal assertion must remain preserved as a proposed falsifier, but it cannot qualify an implementation until the owner chooses the inverse rule. Current production ABC is compatibility evidence; it is not sufficient specification.

Concrete choices:

1. **Segment responsibility:** rejection removes both own explicit-order contributions; independent BCA survives. If the implementation cannot validate that disposition, refuse atomically with authority. Requires preserving intermediate foreign order identity through the later own replacement.
2. **Single transaction order unit:** the later own full reorder explicitly replaces the intermediate foreign order and rejection restores the transaction's original ABC. Matches observed incumbent control, but must be documented as replacing that intermediate order's visible authority.
3. **Conservative interference refusal:** mixed independent full-order authorship within an active capture always refuses rejection atomically, retaining ACB and usable confirmation/recovery. Construction, inspection and confirmation still work. This is a narrower inverse capability than either successful policy.

Recommendation: preserve compatibility unless the owner explicitly selects segment responsibility. Ask the exact sequence, not a general 'preserve newer truth' question: the foreign BCA is newer than the first own operation but older than the last explicit own replacement. Neither relative-age slogan resolves its authority.

Do not repair this by splitting order deltas silently or by treating all observed topology as dependencies. Continue unaffected field/lifetime inverse work while this order-only decision is pending.
