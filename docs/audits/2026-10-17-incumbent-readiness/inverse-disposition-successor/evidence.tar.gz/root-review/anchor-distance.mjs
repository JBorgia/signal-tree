// ../root-review/anchor-distance.ts
import assert from "node:assert/strict";

// packages/kernel/src/lib/internals/production-substrate-stats.ts
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// packages/kernel/src/lib/physical/structural-store.ts
var StructuralStore = class {
  keysCache;
  subjectIds = /* @__PURE__ */ new Map();
  subjectStates = /* @__PURE__ */ new Map();
  subjectRevisions = /* @__PURE__ */ new Map();
  activeNodesByKey = /* @__PURE__ */ new Map();
  activeNodesBySubject = /* @__PURE__ */ new Map();
  nextSubjectId = 1;
  collectionIncarnation = 0;
  activeHead;
  activeTail;
  activeCount = 0;
  orderFrontier = {};
  activeOrderFrontier() {
    return this.orderFrontier;
  }
  /** Only a complete, lineage-validated compensation may restore this token. */
  installCompensatedOrderFrontier(frontier) {
    this.orderFrontier = frontier;
  }
  planFreshSubjectIds(count) {
    return Array.from(
      { length: count },
      (_, index) => this.nextSubjectId + index
    );
  }
  allocateFreshSubjectId() {
    const subjectId = this.nextSubjectId;
    this.nextSubjectId += 1;
    return subjectId;
  }
  subjectIdForKey(key) {
    return this.subjectIds.get(key);
  }
  acquireSubjectHandleForKey(key) {
    const subjectId = this.subjectIds.get(key);
    return subjectId === void 0 ? void 0 : {
      subjectId,
      acquiredRevision: this.subjectRevision(subjectId),
      collectionIncarnation: this.collectionIncarnation
    };
  }
  resolveSubjectHandle(handle) {
    if (handle.collectionIncarnation !== this.collectionIncarnation) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    const state = this.subjectStates.get(handle.subjectId);
    if (state === void 0) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    if (state.active) {
      if (state.key === void 0) {
        throw new Error(
          `Active subject ${String(
            handle.subjectId
          )} is missing its active key.`
        );
      }
      return {
        state: "active",
        subjectId: handle.subjectId,
        key: state.key,
        revision: this.subjectRevision(handle.subjectId)
      };
    }
    return {
      state: "tombstoned",
      subjectId: handle.subjectId,
      restoreAllowed: state.restoreAllowed,
      revision: this.subjectRevision(handle.subjectId)
    };
  }
  stateForSubject(subjectId) {
    return this.subjectStates.get(subjectId);
  }
  hasSubject(subjectId) {
    return this.subjectStates.has(subjectId);
  }
  subjectRevision(subjectId) {
    return this.subjectRevisions.get(subjectId) ?? 0;
  }
  bumpSubjectRevision(subjectId) {
    this.subjectRevisions.set(subjectId, this.subjectRevision(subjectId) + 1);
  }
  activeKeyForSubject(subjectId) {
    const state = this.stateForSubject(subjectId);
    return state?.active ? state.key : void 0;
  }
  hasActiveKey(key) {
    return this.subjectIds.has(key);
  }
  activeKeyCount() {
    return this.activeCount;
  }
  /**
   * Active keys in order, shared until the next list or key mutation. Every
   * mutator of the active list (or of a node's key) clears it; a field write
   * changes neither, so reading `ids()` after one no longer re-walks the list.
   * Callers must not mutate the result.
   */
  activeKeysSnapshot() {
    if (this.keysCache) return this.keysCache;
    const keys = [];
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
    }
    this.keysCache = keys;
    return keys;
  }
  /** Fills both arrays from one walk of the active order. */
  snapshotActiveOrder(keys, subjectIds) {
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
      subjectIds.push(node.subjectId);
    }
  }
  firstActiveKey() {
    return this.activeHead?.key;
  }
  lastActiveKey() {
    return this.activeTail?.key;
  }
  prepareTarget(subjects, order, orderFrontier, prepare) {
    return prepare(
      this.subjectStates,
      this.subjectRevisions,
      subjects,
      order,
      orderFrontier
    );
  }
  installPreparedTarget(target) {
    this.keysCache = void 0;
    this.subjectIds = target.subjectIds;
    this.subjectStates = target.subjectStates;
    this.subjectRevisions = target.subjectRevisions;
    this.activeNodesByKey = target.activeNodesByKey;
    this.activeNodesBySubject = target.activeNodesBySubject;
    this.activeHead = target.activeHead;
    this.activeTail = target.activeTail;
    this.activeCount = target.activeCount;
    this.orderFrontier = target.orderFrontier;
  }
  moveKeysToFront(keys) {
    this.keysCache = void 0;
    const nodes = [
      ...new Set(
        keys.map((key) => this.activeNodesByKey.get(key)).filter((node) => node !== void 0)
      )
    ];
    for (const node of nodes) {
      this.detachNode(node);
    }
    for (let index = nodes.length - 1; index >= 0; index -= 1) {
      this.prependDetachedNode(nodes[index]);
    }
    if (nodes.length > 0) this.orderFrontier = {};
  }
  reorderActiveKeys(keys) {
    let current = this.activeHead;
    let unchanged = true;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) continue;
      if (node !== current) {
        unchanged = false;
        break;
      }
      current = current.next;
    }
    if (unchanged && current === void 0) return;
    this.keysCache = void 0;
    this.activeHead = void 0;
    this.activeTail = void 0;
    for (const node of this.activeNodesByKey.values()) {
      node.prev = void 0;
      node.next = void 0;
    }
    let nextCount = 0;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) {
        continue;
      }
      this.appendDetachedNode(node);
      nextCount += 1;
    }
    this.activeCount = nextCount;
    this.orderFrontier = {};
  }
  neighborSubjectsForKey(key) {
    const node = this.activeNodesByKey.get(key);
    if (node === void 0) {
      return {};
    }
    return {
      beforeSubject: node.prev?.subjectId,
      afterSubject: node.next?.subjectId
    };
  }
  tombstonedSubjectsSnapshot() {
    return [...this.subjectStates.entries()].filter(([, subjectState]) => !subjectState.active).map(([subjectId]) => subjectId).sort((left, right) => left - right);
  }
  createSubject(subjectId, key) {
    recordProductionSubstrateStat("structuralSubjectsCreated");
    this.nextSubjectId = Math.max(this.nextSubjectId, subjectId + 1);
    this.activateSubject(subjectId, key);
    this.subjectRevisions.set(subjectId, 0);
    this.createAndAppendActiveNode(subjectId, key);
    this.orderFrontier = {};
  }
  transferSubject(subjectId, from, to, restoreAllowed = true) {
    recordProductionSubstrateStat("structuralSubjectTransfers");
    const node = this.activeNodesByKey.get(from);
    this.subjectIds.delete(from);
    this.activateSubject(subjectId, to, restoreAllowed);
    if (node === void 0) {
      this.createAndAppendActiveNode(subjectId, to);
      return;
    }
    this.activeNodesByKey.delete(from);
    node.key = to;
    this.keysCache = void 0;
    this.activeNodesByKey.set(to, node);
    this.activeNodesBySubject.set(subjectId, node);
  }
  tombstoneSubject(subjectId, key, restoreAllowed) {
    recordProductionSubstrateStat("structuralSubjectTombstones");
    this.subjectIds.delete(key);
    const node = this.activeNodesByKey.get(key);
    if (node !== void 0) {
      this.unregisterActiveNode(node);
      this.detachNode(node);
      this.activeCount -= 1;
    }
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed
    });
    this.orderFrontier = {};
  }
  restoreSubject(subjectId, key, beforeSubject, afterSubject, restoreAllowed = true) {
    const placement = this.resolveSubjectRestorePlacement(
      beforeSubject,
      afterSubject
    );
    this.restoreSubjectAtResolvedPlacement(
      subjectId,
      key,
      placement,
      restoreAllowed
    );
  }
  resolveSubjectRestorePlacement(beforeSubject, afterSubject) {
    const beforeNode = beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(beforeSubject);
    const afterNode = afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(afterSubject);
    if (beforeNode !== void 0 && afterNode !== void 0) {
      if (this.nodePrecedes(beforeNode, afterNode)) {
        return {
          beforeSubject: beforeNode.subjectId,
          afterSubject: afterNode.subjectId,
          beforeKey: beforeNode.key,
          afterKey: afterNode.key
        };
      }
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (afterNode !== void 0) {
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (beforeNode !== void 0) {
      return {
        beforeSubject: beforeNode.subjectId,
        afterSubject: beforeNode.next?.subjectId,
        beforeKey: beforeNode.key,
        afterKey: beforeNode.next?.key
      };
    }
    return {
      beforeSubject: this.activeTail?.subjectId,
      beforeKey: this.activeTail?.key
    };
  }
  restoreSubjectAtResolvedPlacement(subjectId, key, placement, restoreAllowed = true) {
    this.activateSubject(subjectId, key, restoreAllowed);
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.activeCount += 1;
    this.orderFrontier = {};
    const beforeNode = placement.beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    const afterNode = placement.afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    if (afterNode !== void 0) {
      this.insertDetachedNodeBefore(node, afterNode);
      return;
    }
    if (beforeNode !== void 0) {
      this.insertDetachedNodeAfter(node, beforeNode);
      return;
    }
    this.appendDetachedNode(node);
  }
  /** Relocate an active lifetime without retiring it or emitting lifecycle effects. */
  placeActiveSubject(subjectId, beforeSubject, afterSubject) {
    const node = this.activeNodesBySubject.get(subjectId);
    if (!node) throw new Error("Placement lifetime is not active");
    if (beforeSubject === subjectId || afterSubject === subjectId)
      throw new Error("Placement cannot name its own lifetime");
    const placement = this.resolveSubjectRestorePlacement(beforeSubject, afterSubject);
    const after = placement.afterSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    const before = placement.beforeSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    this.detachNode(node);
    if (after) this.insertDetachedNodeBefore(node, after);
    else if (before) this.insertDetachedNodeAfter(node, before);
    else this.appendDetachedNode(node);
    this.keysCache = void 0;
    this.orderFrontier = {};
  }
  retireSubject(subjectId) {
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed: false
    });
  }
  /**
   * Drop a retired subject's lifetime ledger entirely — state AND revision.
   *
   * ⚠️ TRIAL. This is the null hypothesis for "is the ~117 B/retired lifetime
   * record earned?" (docs/architecture/retired-subject-churn.md, open question
   * 2). `retireSubject` above keeps a `{active:false, restoreAllowed:false}`
   * record forever, which is what makes zero-owner churn linear in every subject
   * that ever existed. This deletes it.
   *
   * SAFE ONLY FOR A TERMINAL, ZERO-OWNER RETIREMENT, and the reason is subject
   * id allocation: `nextSubjectId` only ever increases, and `tombstoneSubject`
   * has already removed the key -> subject mapping. A later add of the same
   * business key therefore gets a FRESH subject id and cannot collide with the
   * forgotten one. Deleting the record cannot resurrect or alias a subject.
   *
   * WHAT IT GIVES UP: `resolveSubjectHandle` reports `missing` rather than
   * `tombstoned` for the forgotten subject, and `planRestore`'s
   * "has retired backing and cannot be restored" guard loses its input. Both are
   * acceptable only because a tree with no restoration authority has no path to
   * a restore at all — the guard becomes unreachable rather than unenforced. If
   * a restorer can exist, DO NOT call this.
   */
  forgetSubject(subjectId) {
    this.subjectStates.delete(subjectId);
    this.subjectRevisions.delete(subjectId);
    this.activeNodesBySubject.delete(subjectId);
  }
  clear() {
    this.keysCache = void 0;
    this.subjectIds.clear();
    this.subjectStates.clear();
    this.subjectRevisions.clear();
    this.activeNodesByKey.clear();
    this.activeNodesBySubject.clear();
    this.activeHead = void 0;
    this.activeTail = void 0;
    this.activeCount = 0;
    this.nextSubjectId = 1;
    this.collectionIncarnation += 1;
    this.orderFrontier = {};
  }
  createAndAppendActiveNode(subjectId, key) {
    this.keysCache = void 0;
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.appendDetachedNode(node);
    this.activeCount += 1;
  }
  unregisterActiveNode(node) {
    this.keysCache = void 0;
    this.activeNodesByKey.delete(node.key);
    this.activeNodesBySubject.delete(node.subjectId);
  }
  prependDetachedNode(node) {
    this.keysCache = void 0;
    node.prev = void 0;
    node.next = this.activeHead;
    if (this.activeHead !== void 0) {
      this.activeHead.prev = node;
    } else {
      this.activeTail = node;
    }
    this.activeHead = node;
  }
  appendDetachedNode(node) {
    this.keysCache = void 0;
    node.next = void 0;
    node.prev = this.activeTail;
    if (this.activeTail !== void 0) {
      this.activeTail.next = node;
    } else {
      this.activeHead = node;
    }
    this.activeTail = node;
  }
  insertDetachedNodeAfter(node, anchor) {
    this.keysCache = void 0;
    node.prev = anchor;
    node.next = anchor.next;
    if (anchor.next !== void 0) {
      anchor.next.prev = node;
    } else {
      this.activeTail = node;
    }
    anchor.next = node;
  }
  insertDetachedNodeBefore(node, anchor) {
    this.keysCache = void 0;
    node.next = anchor;
    node.prev = anchor.prev;
    if (anchor.prev !== void 0) {
      anchor.prev.next = node;
    } else {
      this.activeHead = node;
    }
    anchor.prev = node;
  }
  detachNode(node) {
    this.keysCache = void 0;
    if (node.prev !== void 0) {
      node.prev.next = node.next;
    } else {
      this.activeHead = node.next;
    }
    if (node.next !== void 0) {
      node.next.prev = node.prev;
    } else {
      this.activeTail = node.prev;
    }
    node.prev = void 0;
    node.next = void 0;
  }
  nodePrecedes(left, right) {
    let node = left;
    while (node !== void 0) {
      if (node === right) {
        return true;
      }
      node = node.next;
    }
    return false;
  }
  activateSubject(subjectId, key, restoreAllowed = true) {
    this.subjectIds.set(key, subjectId);
    this.subjectStates.set(subjectId, {
      active: true,
      key,
      restoreAllowed
    });
  }
};

// ../root-review/anchor-distance.ts
for (const size of [16, 128, 1024]) {
  const store = new StructuralStore();
  for (let i = 1; i <= size; i++) store.createSubject(i, String(i));
  const nodes = store.activeNodesBySubject;
  let nextReads = 0;
  for (const node of nodes.values()) {
    let next = node.next;
    Object.defineProperty(node, "next", { configurable: true, get() {
      nextReads++;
      return next;
    }, set(value) {
      next = value;
    } });
  }
  const result = store.resolveSubjectRestorePlacement(1, size);
  assert.equal(result.afterSubject, size);
  console.log(JSON.stringify({ size, requestedPlacements: 1, nextReads }));
}
