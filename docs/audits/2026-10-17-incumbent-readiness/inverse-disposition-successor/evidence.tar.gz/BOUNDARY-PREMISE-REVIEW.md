# Independent boundary premise review

Read-only review, October 23, 2026. Read NEXT-BOUNDARY.md, preserved capture-gap and physical independent reviews, and their reported source boundaries. No runtime execution or production edits in this review. This report evaluates the proposed mechanism, not acceptance.

## Capture: segments are necessary but insufficient alone

The selected writes are a subsequence of installation history. A continuity check on that subsequence is invalid. Preserve each operation's immutable authorship identity, before/after occupancy, lifetime, installation revision and participation. Coalesce only adjacent owned operations when no intervening installation affecting that fact occurred. The separator is evidence of interference, not an owned transition.

A foreign segment must not be copied into the transaction's inverse. Its facts instead remain independently authoritative, and existing dependency rules determine whether rejection can proceed. Confirmation retires this transaction's authority without undoing foreign work. Inspection must enumerate the transaction's authored facts across segments and use actual installation chronology when assessing foreign effects. Flattening those segments back to one endpoint before any of these consumers recreates the failure.

A minimal representation can use an ordered owned-operation journal plus fact-local installation revisions and existing foreign dependency records. A permanent canonical state mirror is unnecessary. However, a revision-only separator cannot establish whether foreign work supersedes an older owned fact, depends on it, or is irrelevant. The design must name the existing record supplying that disposition before implementation. If it does not exist, segmented capture requires additional dependency accounting, not merely a different list container.

The preserved example requires construction, inspection and confirmation. It does not establish that rejecting the transaction must succeed in the presence of the foreign realized admission. Atomic refusal with usable authority remains legitimate where existing rules require it.

## Placement: proposed topology must be a preparation product

Resolve placement against the complete proposed final membership/key topology privately. Do not permute the effect stream to make an anchor physically available early. Keep original field/lifetime chronology for validation and payload computation. Derive final placement instructions separately, validate their anchors against proposed lifetimes, then install the coherent prepared unit before publication/callback delivery according to existing contracts.

This needs two distinct projections during preparation: a sequential value/existence simulation for effect preconditions, and a proposed final topology for successor/predecessor resolution. A single final-topology lookup cannot validate a field operation that precedes its target's creation; conversely, sequential physical availability cannot decide a successor restored later in the same unit. Physical and ordinary payloads remain separate throughout.

The prepared topology is an installation plan, not independently writable current truth. Its lifetime ends after commit/refusal. Preparation must use affected lifetime/key indexes; resolving genuinely external anchors must not enumerate untouched members or walk unbounded linked-node distances merely to decide precedence. Existing nodePrecedes distance work is an unresolved measurement question.

## Required falsifiers before native acceptance

1. Foreign admission before, between and after owned segments; exact original capture gap; foreign same-value ABA; same key with different lifetimes; foreign unrelated field changes must not split or acquire occupancy unnecessarily.
2. Confirm with foreign dependency preserved; reject either preserves surviving foreign facts or refuses atomically with accessible retry. Retry after dependency retirement must not resurrect obsolete owned endpoints.
3. A pending foreign writer rejects between owned segments. Terminal committed supersession must not be reversible merely because earlier recovery facts remain retained.
4. Original two-transfer order and restore-A/field-A/restore-B both succeed. Add field-before-create invalid input control to prove final topology is not being used to excuse invalid chronology.
5. Mixed active transfer/revival, removed successor restored by same settlement, replaced successor lifetime, missing both anchors and occupied destination follow frozen placement rules or refuse unchanged.
6. P99/O7, explicit field inverse to7, unrelated inspected fields preserved; subsequent transaction inspection/adoption/rollback agrees.
7. Preparation throw and synchronous reentry after topology resolution invalidate the whole plan before installation; no published partial state. Post-install observer errors retain coherent authority.
8. Fixed affected operations with growing untouched collections: count index lookups, visited nodes and temporary/retained records. Drain cleanup with retained handles and receipts must not retain journals or source graphs without an obligation.

## Verdict

Segmented capture plus proposed topology is a coherent bounded hypothesis only with the explicit consumer rules above. Segments alone and final topology alone are not sufficient. No new public semantic decision is demonstrated by these failures. Recommend a small executable model retaining operation chronology, foreign disposition references and a separate topology plan, with the exact original falsifiers. Do not clear recurrence or resume later slices from this design review alone.

## Executable sketch follow-up

Read segments-model.mjs after writing the review. Its four assertions preserve the selected endpoints but do not yet model the central foreign obligation. In particular, `owned('tx')` yields a→absent and c→e; blindly applying their inverses would relocate e→c and then revive a, potentially duplicating one lifetime or overwriting independently admitted c. The needed decision is whether foreign admission blocks the first inverse, supersedes it, or survives a coordinated inverse; the sketch has no disposition rule. This is a concrete missing model transition, not evidence that capture segments cannot work.

Likewise schedule([A requires B, fieldA requires A, B]) tests one valid ordering but may select a different semantic field chronology than the original stream. Anchor availability is not inherently an execution prerequisite. A unit can privately know B's final identity/position while A's payload/existence operations remain in source order. A cycle in graph edges conflating anchor availability with execution therefore does not establish atomic refusal is required. Before a native implementation, add an explicit two-phase model and preserve the field-before-create invalid control. No new public semantics are needed to represent these distinctions; the missing work is internal disposition and preparation semantics.
