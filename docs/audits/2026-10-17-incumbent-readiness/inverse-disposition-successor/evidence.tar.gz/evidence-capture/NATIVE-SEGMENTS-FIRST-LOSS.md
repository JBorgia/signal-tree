# Read-only first-loss trace: segmented rekeys

No implementation edits. Frozen SHA remains transactions 3b9e61099ad250fd0596997434611b1c991b21ae7cd66faff5bcf0f28b46cc5b.

Root executable evidence: root-review/foreign-rekey-segments-first.log returns successfully from rollback but final key is b, expected a. Root's frozen rejected-source comparator root-review/foreign-rekey-control.log passes a/123. This report adds source tracing only, not a separate instrumented runtime trace.

1. Source preparation assigns own a→b its first segment, foreign field=123 a separate admission, then own b→c a new own segment. CaptureKey therefore retains both rekeys. Public inspection deliberately projects the latest semantic contribution; its single rows.b entry does not establish missing settlement capture.
2. TransactionAuthority buildPendingRollbackPlan walks pending effects backward (transactions.ts:696–697), retaining [b→c, a→b]. The intervening foreign field is not rekey authorship and the existing rekey rule carries it along, so it does not reject.
3. Handle.rollback reverses that compensation array at transactions.ts:4542. rollbackPendingEffectsThroughRealizationPort receives [a→b, b→c], the forward authored chronology expected by the old single-endpoint path.
4. The shared consumer maps both with toRollbackEffect at transactions.ts:3409, obtaining [b→a, c→b]. Target selection sees a key handoff at b: target-transition.ts:284–301 sees the first inverse vacating b and the second inverse occupying b. Therefore this regression takes the declarative target branch, not rollbackPendingTurnAt.
5. The declarative branch again maps the same forward array to inverses at transactions.ts:3426 and calls rollbackPendingTarget without reversing. This is the first concrete loss of the intended inverse execution chronology: the semantic inverse list is [b→a,c→b], whereas reversing both own transitions requires [c→b,b→a]. The earlier array reversal is the precursor; the consumer's forward inverse mapping makes it wrong.
6. rollbackPendingTarget takes those admitted inverses at transactions.ts:3047 and passes them to prepareOrdinaryRealization at :3090. ordinary-realization.ts uses its sparse current-key join as designed: physical c joins the first b→a into c→a, then joins the second c→b against the staged a into a→b. The proposed complete target therefore legitimately finishes at b. This target agrees with the wrong supplied chronology; validation cannot discover the discarded original inverse ordering by checking target occupancy alone.
7. Installation commits this wrong target and the outer authority retires the transaction as successfully rejected. Foreign n=123 survives, masking the missing own a→b inverse.

A second consumer still assumes endpoint-normalized capture: pending-rollback.ts:141–165 retains only the first effect for rollbackAddressKey; :266 keys all same-lifetime rekeys by [owner,subject,'rekey']. This branch does not explain this exact target-routed regression, but independently prevents a claim that all journal/authority/realization consumers support segments. No caller-specific repair or alternate settlement engine is proposed here.

The mapping is incomplete at an existing general composition boundary. Passing the capture regression and conservative dependency controls was insufficient to establish a vetted native inverse-capture successor.
