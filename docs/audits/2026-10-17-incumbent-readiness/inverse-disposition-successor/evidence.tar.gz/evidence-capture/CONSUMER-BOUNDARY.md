# Native capture consumer boundary

Read-only source assessment, not a runtime result. No source changes made.

The existing producer calls prepareEntityResponsibility for every entity ordinary transition before installation (entity-signal.ts:935,1591); therefore there is a common paired admission seam. The transactions consumer immediately drops foreign admissions when resolveTransactionId is absent (transactions.ts:2152). Existing realized foreign dependency evidence is instead created in the notifier interceptor at 3489–3519, after physical installation. It also appends the effects globally to every open callbackExternalEffects array.

Owned capture is reduced by effectKey into one endpoint per lifetime/field; ordered operation records are later reduced through the same enqueueEffect path (2313). Inspection chronology and validateOperationDisposition also index by that same key. Capture segmentation must migrate all these consumers coherently.

The further authority consumer cannot be left unchanged. buildPendingRollbackPlan receives one global laterEffects list (382); classifyLaterOverlap compares each captured scalar to that entire list (414). Its reverse loop visits every own effect with the same unfiltered external list (653 onwards). Thus foreign field=123 followed by own field=99 would classify that earlier foreign field as superseding the later own segment. Structural handling likewise uses the global later list, not each segment admission boundary. Simply preserving multiple records or suppressing continuity validation is insufficient.

Minimal coherent internal extension needs immutable admission identities shared by paired foreign records and owned segments, with per-segment later-fact filtering in TransactionAuthority. Foreign records must retain existing lifetime/existence dependency semantics; segmenting cannot confer ownership of foreign facts. Confirmation/materialization must preserve which facts are actually latest. Journal, bucket materialization, inspection, validation and authority must consume the same segment IDs. This remains a proposed mechanism, not a proven implementation.

This exceeds the capture-only assignment unless authority classification ownership is explicitly coordinated. rollbackPendingTarget/realization files remain untouched. No blanket refusal or guard deletion was attempted.

## Concrete representation mapping

A segment identity must differ from the semantic fact key. The former indexes capture endpoint groups and journal validation; the latter compares overlap and inspection footprints. Using one string for both recreates either endpoint collapse or missed interference. Proposed private `CapturedFact` is `{effect, admissionRevision, segmentId}`. The immutable revision is minted only by preparation; the terminal record installs it alongside source mutation. The identity must survive cloning, normalization, drain and pending-turn storage. Foreign facts use the same clock and carry no owned-turn identity. Every ordinary mutation of the same lifetime ends its previous own segment, including same-value presence adoption; a notification is not the admission clock.

Normalization is permitted within one contiguous own segment. A later segment may have a new before-image established by foreign facts; it cannot rewrite an older segment's original before-image. Rebind companion fields use that segment's removal/addition images only. Chronology footprints remain value-free and can refer to admission revision without retaining payloads. Inspection must compare each segment against foreign semantic overlaps after that admission, while final statuses aggregate conservatively where public inspection does not expose segments.

Authority rejection evaluates foreign facts newer than each own segment. The existing dependency contract may still refuse structural overlap. Foreign facts earlier than a later own write must not suppress that later own write merely because they occurred after the transaction opened. Conversely, later own writes cannot remove the foreign lifetime dependency needed to preserve an earlier segment's inverse. This requires keeping segment execution order and dependency evidence distinct; a single flat `laterEffects` argument is insufficient.

Terminal cleanup must release admission/segment metadata when the transaction drains and the authority has retired all associated rollback/dependency obligations. A global lifetime-version map retained forever would introduce a tombstone leak, so active-obligation ownership/index cleanup is part of the representation, not optional housekeeping.

## Status

Root explicitly expanded transactions.ts ownership to include TransactionAuthority/planner temporal filtering. That removes the ownership gate described above; it does not establish implementation sufficiency. No native source edits, test passes, or rejection claims are established by this source report.
