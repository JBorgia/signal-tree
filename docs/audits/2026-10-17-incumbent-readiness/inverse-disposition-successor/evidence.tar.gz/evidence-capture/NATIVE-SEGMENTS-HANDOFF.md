# Native authored admission segment handoff

Implementation frozen in `candidate/packages/kernel/src/enhancers/transactions/transactions.ts` and new `native-admission-segments.spec.ts`. `occupancy-composition.ts` is unchanged: its continuity assertion remains. Exact identities are in `segments-frozen.sha256`; immutable source copies are `transactions.frozen.ts` and `native-admission-segments.frozen.spec.ts`.

## Mapping

Source preparation mints immutable private admission revision and authored segment identity. An owned segment continues only while the same transaction remains the last admitted writer of that entity lifetime. Foreign admission breaks the segment, and its changes, inspection footprints, dependency evidence, and callback evidence install through the same terminal record plan. Failed preparation installs none of those maps. The admission clock is monotonic and failed preparation may consume a revision; it retains no per-revision object by itself.

Semantic effect keys remain overlap addresses. Segment keys independently index own occupancy endpoints, own fields, journal folds, retained disposition validation, and own inspection chronology. Normalization copies admission identity onto generated occupancy and companion field facts. TransactionAuthority remains the sole rollback planner and applies source evidence only when newer than the particular owned segment. Its existing callback derive refusal remains intact. Public inspection projects the latest own segment per semantic contribution.

All admission maps exist only while pending/callback obligations exist. The authority clears its prepared source dependency map at final pending retirement; capture/inspection cleanup clears lifetime segment and latest-source-admission maps. No full tree copies or whole state scans were introduced. Repeated cycle test retains terminal handles while proving these map counts return to zero; this is not a GC or payload-retention proof.

## Final focused evidence

`segments-focused-final.log`: Nx kernel test with four explicit test files (occupancy-inspection-chronology, native-admission-segments, occupancy-composition, queued-inspection-review), maxWorkers=2, skip-nx-cache: 4 files/24 tests pass. This includes the original 3 chronology tests, new conservative-refusal behavior, failed foreign preparation, and 12 terminal cycles proving active map counts 1/1/1 and drained counts 0/0/0.

`segments-typecheck-final.log`: kernel source typing command `COREPACK_ENABLE_NETWORK=0 corepack pnpm exec tsc --noEmit -p packages/kernel/tsconfig.typecheck.json` completes with zero diagnostics.

The earlier `segments-transactions.log` directory check passed 51 files/738 tests on intermediate source before the last dependency/inspection amendments; it is not final-source acceptance.

## Preserved failures and limits

`segments-first.log`, `segments-debug*.log`, `segments-second.log` preserve intermediate failures, including the original discontinuous occupancy error and transient missing chronology errors. Baseline original transactions source is `transactions.pre-segments.ts`.

`segments-kernel-first.log` is an INTERRUPTED exploratory full kernel run (own exec session stopped with Ctrl-C, exit130). It emitted 23 failing file summaries containing 152 failed cases and 1 skipped case; no full-suite totals were produced, and unexecuted tests are unknown. Source changed while this run was active, so it is source-variant evidence with no exact immutable launch snapshot. It establishes neither final-source regression counts nor unrelated baseline failures. No broad rerun was performed after root gated further broad verification.

`segments-spec-types-final.log` comes from an incorrectly broad direct spec-tsconfig attempt and contains 283 diagnostics. It is not comparable to the previously tracked targeted eleven fixture errors and does not discharge them. No diagnostic mentions transactions.ts or the new test file. No clean spec-type gate is claimed.

No native acceptance, model acceptance, sparse-work benchmark, cross-framework validation, activation, release, or budget acceptance is established. Independent review remains required. No commits or public API/settlement semantics changes were intended.
