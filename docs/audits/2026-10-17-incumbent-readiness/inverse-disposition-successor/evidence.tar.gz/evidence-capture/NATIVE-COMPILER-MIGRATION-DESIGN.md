# Selected-compensation compiler completion

The authority-selected compensation is the compiler input. Capture segments and foreign admissions remain unchanged for journal, inspection, disposition and dependency decisions. After authority disposition, continuous own occupancy transitions for one lifetime can compile to the same bounded endpoint operation used before capture segmentation. This is a private lowering step, not retrospective ownership of foreign field facts. Foreign occupancy discontinuities must remain separate segments; they cannot be bridged by changing a baseline.

Compiler normalization will preserve chronology across discontinuities and preserve independently selected scalar facts. Continuous same-lifetime occupancy composes through the existing occupancy composer, including endpoint cancellation. Companion field values remain their separately adjudicated captured effects. All physical inverse effects must execute in reverse authored chronology; the existing revive-before-field dependency ordering still applies afterward. The sparse pending compiler cannot silently discard repeated same-address segments. Whole-unit private validation precedes installation.

Tests will include original own rekey/foreign field/own rekey, ABA rekeys around foreign fields, independent scalar/address carry, and revive-before-field controls. Point-work evidence with 16 and 1024 unrelated rows must show no new collection target scans due solely to capture segmentation. No public API, new authority or caller-specific branch is intended.

Concrete internal seam: `rollbackPendingTurnAt` accepts already authority-selected inverse compensation in execution order. It bypasses the legacy context-projection dedup only for this supplied selection; the same whole-unit validation and private installation remain. Transactions compiles continuous occupancy endpoints first and supplies the same reverse-chronological inverse sequence to sparse and complete-target routes. Legacy raw-turn projection behavior remains for other callers whose context intentionally computes one net owner compensation.

Source-backed notifier and queued projections now defer to the paired source admission for each recorded entity lifetime. The earlier latest-source semantic lookup could not correctly identify delayed notifications after a later own admission replaced that owner pointer; it generated unclocked duplicates. Their removal preserves source ordering, including foreign field before own removal. Unprepared/pre-open and root scalar evidence retain the existing notifier path. The callback source effects still receive the existing derive refusal at materialization.

## Frozen implementation and evidence

`compiler-frozen.sha256` identifies transactions.ts, pending-rollback.ts and the new native-segment-compilation.spec.ts. Exact snapshots are transactions.compiler-frozen.ts, pending-rollback.compiler-frozen.ts and native-segment-compilation.frozen.spec.ts. Original transactions.frozen.ts and original root red logs/traces remain unchanged.

`compiler-focused-final.log`: pinned Corepack Nx kernel run, twelve explicit files, maxWorkers=2, skip-nx-cache: 12 files / 195 tests pass. Files: native-segment-compilation, native-admission-segments, occupancy-inspection-chronology, queued-inspection-review, update-then-remove-rollback, rekey-occupancy-0, rekey-supersession-0, pending-rollback, pending-rollback-composition, target-transition, occupancy-successor-composition, occupancy-successor-point-work.

`compiler-typecheck-final.log`: `COREPACK_ENABLE_NETWORK=0 corepack pnpm exec tsc --noEmit -p packages/kernel/tsconfig.typecheck.json`, exit0, no diagnostics. This is source typing only; prior spec diagnostics remain unresolved/unqualified.

`compiler-foreign-rekey-final.log`: original root-review/foreign-rekey-segments.ts rebuilt unchanged using esbuild --bundle --platform=node --format=esm, then node execution: PASS, expected original key a and foreign123. Separate output artifact preserves original failing mjs/log.

The new test's continuous and ABA workloads use one touched lifetime plus respectively16 and1024 unrelated members. The production structuralActiveKeyEntriesVisited counter is asserted zero during capture and again after resetting it immediately before rejection. These are scoped work-count controls, not runtime timing or a general complexity proof. They establish that extra capture segments do not force complete collection target enumeration in these workloads.

`compiler-newtests-first.log` and `compiler-newtests-second.log` preserve the initially failing revive-before-field control; `compiler-revive-debug.log` captures its exact unclocked foreign field conflict. `compiler-newtests-third.log` records its correction with unchanged assertion. Root's originally observed b-versus-a failure and immutable trace remain root-review/foreign-rekey-segments-first.log and NATIVE-SEGMENTS-FIRST-LOSS.md.

No full suite was rerun. No acceptance, release, budget, cross-framework or general sparse-work claims are made. Independent rereview and root's preregistered foreign-disposition matrix remain outstanding.

## Exact notification pairing correction

Independent review demonstrated that a previously captured lifetime is not evidence that a sibling point-realization notification passed source preparation. The lifetime-has shortcut was removed. The correction keys an internal WeakMap by each actual ordinary change object and installs its immutable identity only through the terminal record plan. Source `ordinaryPlan.changes`, `byStep` and `byPhysicalSubject` retain the same group objects (entity-signal.ts:789–793); metadata copies preserve those references. Evidence consumers filter those exact admitted objects before ordinaryEntityEntries strips metadata. Unprepared sibling point notifications remain on the existing conservative raw evidence path.

TerminalRecordPlan's map property now requires only its existing `set` operation, allowing an internal WeakMap sink. This changes no installer runtime logic. The intrinsic-mutation module and TerminalRecordPlan are not exported through kernel's index/internals/adapter barrels or package export map. No readonly ordinary fact or notification metadata is mutated, and no weak entry is installed during preparation itself. A failed preparation therefore cannot publish pairing evidence.

The original independent unpaired-point first-red artifacts and the previous compiler source snapshot remain unchanged. Rebuilding unpaired-point-adjudicated.ts against the corrected source yields123, atomic refusal, retained inspect/retry/confirm authority (`exact-pair-unpaired-replay.log`). Additional tests assert actual object-reference handoff and the unprepared point sibling. Mixed coalescing completeness remains under independent investigation; this intermediate correction is not final acceptance.
