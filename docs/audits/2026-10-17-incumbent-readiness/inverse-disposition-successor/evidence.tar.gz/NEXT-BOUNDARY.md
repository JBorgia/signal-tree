# Successor design boundary

Source: rejected successor f1042531 archive, read-only adjudication October23.
No new runtime experiment or acceptance claim.

## Capture

The owner-selected sequence is not a contiguous history. Compressing A@a→absent,
foreign absent→A@c, own A@c→A@e into A@a→A@e either erases the foreign admission
or incorrectly acquires it. Keeping only the final endpoint is therefore
insufficient. A possible representation is multiple owned segments separated by
foreign-admission revisions. Earlier responsibility must survive the separator;
foreign admission must retain its own identity and disposition. This adds an
explicit interference lifecycle and needs a new bounded design authorization.
It must not be implemented as resetting the endpoint on mismatch.

Required discriminator: original capture-gap sequence constructs, inspects and
confirms. Rejection must preserve independent facts or refuse atomically with
usable authority according to existing dependency rules; successful rejection
is not stipulated. Test foreign admissions before/between/after own segments,
same-value ABA, key reuse with different lifetimes, and cleanup after drain.
A write revision alone detects interference but does not specify its ownership.

## Realization

The current resolver permutes only structural slots. For [restore A, field A,
restore B], it produces [restore B, field A, restore A], violating the field's
existence precondition. A complete operation dependency graph is one option:
restore A must precede field A; placement may require B's availability. But
availability for placement need not mean callback-visible physical installation.
A proposed-topology resolver could resolve positions privately, then install a
complete prepared unit using the established callback/publication contract.
Neither option is proved sufficient. Do not combine them by an ad hoc sort.

Required discriminator: unchanged two-transfer and interleaved-field probes both
succeed, alongside removed anchors, same-lifetime transfer, fresh revival, P99/O7,
reentry and preparation failure. No synthetic lifetime callbacks, speculative
whole-collection scan, or unrelated-field adoption is permitted.

## Decision boundary

These are additional internal representations, not already-authorized slices of
the rejected implementation. Preserve slice1 and production. Before native work,
require a concrete finite model of owned segments and proposed topology, with
explicit supersession, inverse, validation, publication and reclamation rules.
Independent premise review must establish that this addresses both exact
falsifiers without asserting broader rollback capability. If that cannot be
specified without new public semantics, the owner must decide that exact issue.
No new public semantic question is established by the present trace.
