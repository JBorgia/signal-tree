# Inverse model independent review

October 23, 2026. Read actual incumbent rekey-supersession-0 and update-then-remove-rollback tests, INVERSE-CONTRACT-AUDIT.md and current inverse-model/model.mjs. This is a review of a still-in-progress model; no runtime edits or native acceptance.

Current concrete blockers:

1. Same-fact `continue` classifies every later writer as supersession before checking pending authority. The pending-order guard is consequently unreachable when a later order exists. This affects fields and keys too, not just order. Pending overlap must not be silently treated as committed replacement.
2. Capture-gap control does not reproduce the preserved sequence. It rekeys an existing A and writes its field; it never displaces ordinary A to absent, then independently admits that lifetime at c, then authors a later rekey. Thus it cannot exercise segmented occupancy or inverse disposition across that boundary.
3. Events and terminal turns are never retired. Cleanup and bounded retention are wholly unmodeled; successful settlement cannot establish reclamation.
4. Existence dependencies are bare fact names. If an earlier foreign dependency is superseded by later independent replacement/removal, `later.some(requires...)` still sees its obsolete historical requirement. Dependency authority must follow surviving obligation identity, rather than all historical events. Need dependency released/superseded controls, including create→foreign field→foreign removal.
5. Key facts are independently stored per lifetime and write admission does not validate occupancy. A realistic gap requires key occupancy, including displacement and same-key distinct lifetime, to be modeled explicitly; accepting inconsistent initial facts would make inverse success meaningless.
6. Sequential field/existence preparation and final placement are absent. The model currently has only an opaque `order` fact, so it cannot qualify restore-A/field-A/restore-B or successor lifetime policy.

The audit supports field replacement, structural dependencies and atomic refusal/retry distinctions. It does not yet justify the foreign-rekey supersession hypothesis or arbitrary full-order expectation; retain those as explicit hypotheses pending source adjudication.

Important interpretation: the semantic inverse stream is not necessarily forward capture order. update-then-remove-rollback explicitly requires revival before field reversal. Preserve supplied inverse chronology while resolving final placement privately; do not preserve forward source order mechanically.

Recommendation: complete the model with operation/lifetime/key occupancy, revision-identified surviving dependencies, terminal classification before supersession, independent admission and cleanup; then test exact preserved sequences. No public semantic expansion or permanent canonical mirror is established as necessary. Current model is not a gate for native implementation.
