# Order/removal composition adjudication

Read-only October23. Reviewed root-order-removal-realization.mjs and existing proposal-rejection-0.spec.ts cases11/12. Model SHA e4a689 remains unchanged. No native execution performed here.

The combined-model failure identifies an incomplete removal representation. remove() authors only exists=false; order remains an array containing the removed lifetime. reject() then demands that surviving order membership exactly match active topology. Those two model rules cannot both hold after a valid removal.

Native public collection order cannot contain an absent lifetime. A native removal affects ordered membership as well as existence. The model must represent that coordinated projection, while retaining enough historical placement/dependency information for reversible pending removal. No new public semantics are required to express that distinction.

Cases11/12 require useful rejection when a later removal has already erased the creator's lifetime. They do not include an intervening explicit full-order operation, so the exact extended sequence's successful native rejection remains an unexecuted composition claim. Label the model expectation as derived from existing removal projection and supersession requirements; do not claim the exact native control passed.

A viable bounded specification distinguishes authored order constraints from visible order projection. Removal suppresses the removed lifetime's visible membership; committed removal supersedes its live existence requirement. A pending removal may hide that requirement but must preserve it for restoration on rejection. Blindly deleting the lifetime from every historical order record loses reversible authority, while demanding historical arrays equal current membership causes the observed false refusal.

Required controls: committed remove after committed order releases dependency; pending remove hides but retains recovery facts; reject pending remove restores order/dependency; confirm pending remove releases them; same-key replacement never retargets the old lifetime's order fact. In every case visible order and active membership agree. Whether this is implemented by explicit membership transitions or deriving order over selected active lifetimes is an internal model choice, provided recovery authority remains distinct.

Disposition: a concrete model composition gap, not evidence that native capture-clock mapping fails or that public policy must change. Model acceptance should wait for these controls; native unaffected investigation may continue, with combined acceptance gated.
