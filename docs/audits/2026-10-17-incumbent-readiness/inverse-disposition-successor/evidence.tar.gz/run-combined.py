from pathlib import Path
import subprocess,json,hashlib,os
r=Path('/private/tmp/inverse-disposition-native');c=r/'candidate'
files=['src/enhancers/transactions/'+n+'.spec.ts' for n in ['occupancy-inspection-chronology','native-admission-segments','occupancy-composition','queued-inspection-review','rekey-occupancy-0','rekey-supersession-0','native-foreign-disposition-matrix','native-segment-compilation','native-source-notification-pairing','update-then-remove-rollback']]
files+=['src/lib/'+n+'.spec.ts' for n in ['occupancy-successor-realization','occupancy-successor-composition','occupancy-successor-point-work','entity-semantic-rekey-vacancy-recurrence','entity-semantic-structure-slice','entity-semantic-structural-inverses','entity-semantic-structure-interceptors']]
files+=['src/lib/internals/causal-runtime/'+n+'.spec.ts' for n in ['pending-rollback','pending-rollback-composition','structural-pending-rollback-composition','target-transition']]
m={str(p.relative_to(c)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((c/'packages').rglob('*.ts'))}
p=r/'qualified-source-manifest.json';p.write_text(json.dumps(m,indent=2)+'\n');print('source',hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
cmd=['corepack','pnpm','exec','nx','test','kernel',*['--testFile='+f for f in files],'--skip-nx-cache']
(r/'combined-qualified-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
env=dict(os.environ,COREPACK_ENABLE_NETWORK='0',NX_DAEMON='false',NX_ISOLATE_PLUGINS='false')
with (r/'combined-qualified.log').open('w') as out:result=subprocess.run(cmd,cwd=c,env=env,stdout=out,stderr=subprocess.STDOUT)
assert all(hashlib.sha256((c/f).read_bytes()).hexdigest()==h for f,h in m.items()),'source changed during run'
print('exit',result.returncode,flush=True)
raise SystemExit(result.returncode)
