# Extended inverse-model independent follow-up

October 23, 2026. Reviewed 18-control model and subsequent displaced-gap control while worker continued composition work. No model source edited. Independent executable review-dependency.mjs imports model.mjs and reproduces an additional failure; full output in inverse-model/review-dependency.log.

Sequence: seed A; t creates B; committed foreign order explicitly includes A,B; newer committed foreign order includes only A; reject t. The model refuses `dependency` because it scans every historical event's requires array. The superseded ordering no longer supplies visible authority, so retaining it solely for recovery must not preserve an existence obligation on B. This is exactly the obsolete-dependency lifecycle discriminator requested by the task. It is a model defect; no corresponding native claim is made.

The converse remains essential: confirming an order including B must NOT discard the required existence obligation. Rejection of B's creator must refuse atomically while that committed order remains authoritative. Rejection or supersession of a dependent pending order must release/update its obligations consistently, while failed settlement preserves them.

Progress since first review: pending same-fact overlap checked before supersession; exact displaced-admission control added; no blanket foreign refusal (field and removal controls succeed); postdrain cleanup modeled; sequential topology helper preserves restore-A/field-A/restore-B. However topology is still separate from reject at this review identity; composition cannot be inferred from helper success.

Owner contract basis for committed full-order supersession exists in the conversation's stale-order instructions: newer committed order must not be overwritten by rejection of older work; recovery-only facts cannot determine visible order; pure order confirmation releases obsolete dependencies. The audit's absence of a direct incumbent test does not remove that owner requirement. Retain the requirement, and label lack of native matching evidence separately.

Cleanup claim is currently all-pending-drained only: compact returns false whenever any pending turn exists and clears events/turns afterward. It does not demonstrate prompt per-obligation retirement while unrelated work remains pending. That narrower claim can be explicit; do not describe general bounded retained metadata from this control.

No acceptance until dependency supersession and integrated reject/topology controls pass under a frozen model identity.

## Combined revision review

Worker froze model SHA256 5a1b71b84e14d3f2555624416311183b312b698b2bddaa04a45a9fb95b8abb64. Historical order-dependency defect is corrected by terminal-survivor filtering and named controls. Combined reject now calls topology preparation, but its output is not checked against selected ordering authority.

Independent review-order-override.mjs/log: t authors [a,b,c]; later committed foreign authors [c,b,a]; reject t with historical placement stream A before B, B before C. Disposition skips t's superseded order, then realization overwrites surviving order to [a,b,c]. The model accepts conflicting preparation instead of deriving or validating the surviving placement footprint. This is a concrete internal model interface falsifier, not a native producer claim. Filter/derive prepared realization from selected disposition or reject inconsistent plans before installation; it must never override newer committed authority. Field/existence checks alone do not establish shared semantic transition consistency.

A separate review-composition removal probe is ambiguous about insertion into a later order of only surviving C and is NOT claimed as a contract failure.
