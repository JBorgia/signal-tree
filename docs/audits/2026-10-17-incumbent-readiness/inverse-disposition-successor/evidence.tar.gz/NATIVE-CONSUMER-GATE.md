# Native consumer gate (source inspection)

Restored rejected source matches all763 package TypeScript hashes. Isolated at
/private/tmp/inverse-disposition-native/candidate. Pinned Corepack Nx replay
reproduces2pass/1fail. Initial system-pnpm attempt did not execute tests; Corepack
avoids its automatic dependency-install path. Available Nx/Vitest/TypeScript/
esbuild versions match candidate declarations. Historical docs tsconfig absolute
extends warnings remain separately visible in the run log.

The journal already retains ordered owned operations, but foldOperationDisposition
(2313) folds every record back through enqueueEffect, reproducing the selected-
endpoint assumption. Merely adding segments at admission leaves this consumer
incorrect. validateOperationDisposition(2335) indexes retained effects by
single effectKey and would collapse repeated segment identities. Inspection
(1998) similarly resolves chronology by effectKey. Drain(1697) materializes
bucket.effects. compensatedFrontiers(2715) coalesces structural intervals and
rejects discontinuous frontier optimization; this safety fallback must remain.

Native successor must map admission, journal validation, materialization,
inspection, later-effect classification and inverse realization together. It
cannot change only composeOccupancy's continuity assertion. Current journal is
not a second settlement engine: TransactionAuthority still determines rejection.
A finite model must identify surviving foreign dependency authority before these
consumers can be adapted. No runtime patch selected or made.
