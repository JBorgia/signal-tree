# Exact prepared ordinary-record handoff: source premise review

Read-only source assessment, not executable validation of the proposed change.

The proposed exact-record proof is supported by the existing producer handoff:

- entity-signal.prepareOrdinaryTopology records each operation into a group, then appends those same objects into selected, byStep and byPhysicalSubject (lines790-793). No per-record copy separates the responsibility capture from these notification projections.
- Frame source preparation receives ordinaryPlan.changes (selected); frame valueResultsByStep/valueResults use the indexed group arrays in EntityValueTransition. Single-row preparation receives selected and returns selected as ordinaryChanges. Structural metadata helper stores the per-subject arrays by reference.
- withEntityValueTransition copies only metadata wrapper; withEntityOrdinaryChanges stores the array by reference. mergeEntityValueTransition concatenates ordinary-change arrays by spread, retaining their member object identities. PathNotifier materializeDeliveryMeta copies structuralEffect only, retaining symbol metadata values; mergeMeta delegates ordinary row merging to mergeEntityValueTransition.
- ordinaryEntityEntries is currently a destructive boundary for record identity: it creates projected tuples and removes the original ordinary-change/transition metadata. Consequently checking record identity only after that projection cannot prove exact operation pairing. Filter per ordinary record before expansion or carry an explicit private record reference.

Important falsifier requirements for implementation:

- Mixed paired and unpaired row records in one coalesced projection must retain every unpaired row. Whole-entry some/every shortcuts need to be justified; individual record filtering is the direct proof.
- Same semantic address ABA and reentrant outer/inner delivery must use original record identity, not owner/subject/address/value matching.
- The established private preparePointRealization harness must retain fallback behavior (current adjudicated first-red in this directory). That producer publishes realized writes without source paired capture.
- Empty ordinaryChanges is affirmative no-fact evidence; do not turn it into legacy tuple fallback.
- If a future path clones a row record, exact identity fails closed, but duplicate unclocked evidence could still regress chronology. Source cloning/metadata-loss variants are not proven by this premise review and require bounded controls.

TerminalRecordPlan and installTerminalRecord are internal substrate declarations. No root index.ts or adapter.ts exports found. Replacing its concrete Map requirement with a minimal private set protocol supporting WeakMap need not change the public SDK. Verify type variance and all installTerminalRecord consumers with the usual typecheck.

No implementation source edits, no new API, and no executable pass claimed by this document.
