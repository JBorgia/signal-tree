# Final bounded independent review

No blocker demonstrated on the exact final source reviewed below. Prior REPORT.md failures remain valid against their older source identities; this document supersedes their disposition only for this final source.

## Source identity

transactions.ts a5ae192f67963019b6bcb871dff38de81f812b071a51993ce9f83593f05b9ddd; intrinsic-mutation.ts bad91893...; pending-rollback.ts cbeb4422... . Full SHA256 identities, falsifier hashes and unchanged before/after replay comparisons are recorded in final-review-before.sha256 and final-review-after.sha256. This is a reconstructed candidate directory, not a Git HEAD; shared checkout HEAD does not identify it.

## Original falsifiers replayed

Node24.15.0, fresh local esbuild bundles using unchanged original/adjudicated scripts. No runtime source mutation.

- Original foreign-rekey-segments: row initially a(n7); pending callback own a->b, established realized-context field123 through the original lifetime handle, own b->c. Before rollback ids[c], n123. Rollback now returns ids[a], n123. Assertions pass. foreign-rekey-exact-final.log. The previous wrong-final-b failure is no longer demonstrated.
- Original adjudicated unpaired point harness: row n7; pending own n8; established private preparePointRealization installs and publishes123. Inspection now superseded; rollback refuses atomically with123 preserved; inspect and retry remain available, retry still refuses without changing123, and confirm succeeds. unpaired-point-adjudicated-exact-final-repeat.log. Prior lifetime-map suppression regression is no longer demonstrated.

These triggers combine native public mutations with explicitly identified internal realized-context/point-adapter harnesses. They are not claims of uninstrumented public ingress.

## Source interpretation

- TransactionAuthority still decides overlap/dependency disposition before rollbackPendingEffectsThroughRealizationPort compiles selected facts. The compiler does not decide ownership or remove foreign dependencies.
- compileSelectedCompensation (transactions2931+) folds only selected continuous own occupancy endpoints; scalar facts remain. The inversion sequence is constructed once in reverse execution order (3344+), then supplied consistently to declarative target realization and internal pending rollback selectedCompensation. The legacy raw-turn caller path remains when that optional input is absent. Boundary, dependency, effect validation and prepared-discard checks remain before installation. This addresses the demonstrated ordered-segment handoff loss without using the legacy same-address dedup for selected inverses.
- Exact pairedEntityAdmissions WeakMap entries are installed in the same TerminalRecordPlan as source admissions/segments/footprints and foreign/owned responsibility. Preparation alone does not certify a notification. Each actual ordinary record is checked before expansion; mixed arrays retain unpaired members. Empty changes remains affirmative no-fact evidence. Latest-owner and lifetime-membership proof shortcuts are removed.
- Producer selected/byStep/byPhysicalSubject arrays share record objects; metadata wrappers and compatible coalescing retain those identities. See EXACT-RECORD-PREMISE.md for supporting source paths.
- TerminalRecordPlan now requires only private set(key,value), permitting WeakMap installation with the same internal installer. No root index or adapter SDK export of this helper, selectedCompensation option or compiler was found. No public API change demonstrated.
- Quiet cleanup clears source segment/admission maps and replaces the WeakMap; authority clears source dependencies when pending obligations drain. Earlier independently executed terminal-count test (older freeze) measured repeated confirmation/destroy counts, while final cleanup claims here are source inspection. No new final WeakMap count measurement is claimed.

## Coalescing challenges and limits

Four attempted known/unknown coalescing sequences passed the allowed-refusal preservation contract; see EXACT-PAIR-RECHECK.md and raw scripts/logs. Original after-callback and unrelated-pending sentinel variants flush the older paired entry at transaction boundaries. Stronger same-callback variants, including exactly matching system/realized attribution, leave paired99 and unpaired123 as separate queued entries around own8 due to causal boundary handling. No summary-completeness hole was demonstrated. This is bounded attempted falsification, not exhaustive proof against future metadata cloning or arbitrary reentrant adapters.

No broad suite, release verification, packaging/build/demo gate or performance claim was run by this reviewer. Parent/worker focused suites and source typing results remain separate evidence. Root's final combined gate was ongoing when this report was frozen. No further native semantics or public feature acceptance is inferred from this review.

## Final lint-only source qualification

Reviewed exact diff from transactions-before-lint.ts (a5ae192f67963019b6bcb871dff38de81f812b071a51993ce9f83593f05b9ddd) to transactions.ts 5520b8473587769165183e580a85f76c525f47bd110817e295375d2def5f7c63. Only runtime delta is one local `const identity = identityOf(effect)` in enqueueEffect and three guarded uses of that local replacing repeated identity lookups/non-null assertions. Private identities are frozen objects attached to internal effect records; occupancy composition does not mutate their identity. No behavior-changing delta demonstrated by this source review. Original falsifier run claims above remain tied to a5ae192; they were not rerun for this local narrowing change. Root's focused/type gates remain separate run evidence. No additional blocker found from this diff.

Full collection order policy remains an owner interpretation question. This review does not convert an underdetermined order contract into a candidate failure or select a new policy.
