import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '../candidate/packages/kernel/src/index';
import {preparePointRealization} from '../candidate/packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter';
import {getOwnedPositionIds,getOwnedSubjectIds} from '../candidate/packages/kernel/src/lib/internals/owned-mutation';
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
try {const r=t.$.rows;r.addOne({id:'a',n:7});for(let i=0;i<40;i++)await Promise.resolve();const a=r.byIdOrFail('a');const p=t.transact(()=>a.n(8));const owner=getOwnedPositionIds(r)![0],subjectId=getOwnedSubjectIds(a.n)![0];const plan=preparePointRealization(t,[{owner,subjectId,subjectFieldSegments:['n'],before:8,after:123}]);assert.ok(plan);plan.install();plan.publish();console.log('before',a.n(),JSON.stringify(p.inspect()));p.rollback();console.log('after',a.n());assert.equal(a.n(),123);}finally{t.destroy();}
