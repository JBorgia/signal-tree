# Native capture segment review

No blocker demonstrated within the reviewed capture/chronology boundary. This is a focused experimental-candidate review, not release verification or public-semantics approval.

## Artifact and contract

Read docs/review-contract.md, contributor-contracts.md, transaction semantics contract and the supplied frozen capture boundary. Compared transactions.ts and occupancy-composition.ts against /private/tmp/occupancy-adjudication/overlay. Candidate is a reconstructed source directory without .git; its base is supplied as f806, not independently established here. Shared checkout HEAD is 628d302dadb082a48c58528651c9088234d0a777 and is not the candidate source identity.

Final hashes before and after execution are identical in source-final-before.sha256 and source-final-after.sha256. transactions.ts SHA256 3b9e61099ad250fd0596997434611b1c991b21ae7cd66faff5bcf0f28b46cc5b. occupancy-composition.ts unchanged from comparator. Initial pre-counter source run is separately identified by source-before.sha256.

## Source evidence

- transactions.ts:133-158 gives each prepared entity effect an admission revision and contiguous authored segment identity; enumerable private symbol metadata survives effect spread cloning. This is internal effect metadata, not a public trigger/API.
- captureKey separates segment storage from semantic effectKey. enqueueEffect retains distinct own segments while normalizing within a segment; foldOperationDisposition and validateOperationDisposition use this segmented capture path.
- prepareEntityResponsibility installs sourceAdmissions, sourceSegments, inspection footprints, foreign sourceDependencies/callback evidence or owned operation journal through its returned TerminalRecordPlan. Failed preparation can consume clock counters but does not install the prepared map writes. No source-level authority loss or physical-write fallback was demonstrated.
- isLaterAdmission filters per-own-effect chronology in overlap and structural dependency classification, preserving earlier foreign dependency evidence without pretending it follows a later own segment. Inspection projects latest semantic own facts while planner retains all segments.
- occupancy continuity assertion and planner failure paths remain. No second state engine or silent alternate settlement was introduced by this delta.
- releaseInspectionIfQuiet clears segment/admission maps; authority releaseLedgerIfQuiet clears sourceDependencies. Final new test measures these three counts before and after terminal confirmation and destroy across 12 cycles while keeping terminal handles alive.

## Executed falsifiers

Node v24.15.0; pinned pnpm via corepack; COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false.

1. Initial frozen native-admission-segments test: 1 file / 2 tests passed. Log native-segments.log.
2. Final frozen native-admission-segments plus original occupancy-inspection-chronology tests: 2 files / 6 tests passed. Command:

    corepack pnpm exec nx test kernel --testFile=src/enhancers/transactions/native-admission-segments.spec.ts --testFile=src/enhancers/transactions/occupancy-inspection-chronology.spec.ts --skip-nx-cache

Log final-focused-corrected.log. This checks the original before-adoption realized field bridge into own removal/rekey without modifying its assertions, earlier foreign field dependency with latest-own inspection, failed preparation, and the new terminal retention cycle.

First final harness attempt incorrectly used comma-separated --testFile and found no tests. Preserved final-focused.log; it is not a runtime failure or acceptance evidence. Corrected run above used repeated flags.

## Not run / limits

No broad kernel suite, release gates, build, bundle, demo, package or spec-types run by this reviewer. No new executable counterexample was found, so no new speculative repro was added. This focused pass does not exhaust mixed scalar/entity segment histories, arbitrary reentrant adapters or every dependency retry permutation. It does not claim rollback success where an existing dependency refusal is permitted. Parent/implementer runs are separate claims, not silently promoted into this review's run evidence.

## Additional notification-correlation limit

Source inspection raised an unproven risk: identifyNotification looks up only the latest sourceAdmissions array for an owner and then matches semantic effectKey, rather than carrying an exact operation token in notification metadata. updateOne and replaceOne enqueue path notification before public emitTap (entity-signal.ts:3216/3231 and 3290/3317), so those taps cannot overtake enqueue observation. Committed-capture subscriber or realization reentry between source installation and notification can potentially replace the latest array. No executable user-visible corruption or changed refusal was demonstrated in this review; this is not reported as a blocker. Exact operation correlation under arbitrary reentrant realization remains not-run.

# Superseding finding: repeated own rekey segments compensate in forward order

Concrete blocker demonstrated after the preceding focused no-blocker result. `transactions.ts:3426` passes `effects.map(toRollbackEffect)` into rollbackPendingTarget in authored segment order. Native case: initial a(n=7); own a->b; realized independent field n=123 through held lifetime handle; own b->c; rollback returns successfully but ids are [b], rather than [a]. Foreign n=123 remains. This violates complete compensation of own occupancy while preserving independent field truth. Trigger mutations are native public changeId/leaf calls; realized participation is supplied by the explicitly established private write-context harness, not claimed as an uninstrumented public ingress API.

Executed evidence:

- rekey-source-before.sha256 records exact source and trace-builder hashes before execution.
- rekey-fresh.log: independent fresh uninstrumented esbuild bundle fails expected [a], actual [b].
- rekey-trace.log: read-only esbuild onLoad instrumentation prints ordinary inverses [b->a,c->b], physical lowered sequence [c->a,a->b]. The pending rollback compiler marker never runs. Thus pending-rollback.ts same-lifetime rekey dedup is not the first loss for this case.
- rekey-control-replay.log: supplied frozen-rejected control (transactions.pre-segments.ts + first-adapter.ts, other source unchanged) passes the same case. This is a paired control, not attribution to transactions alone.

The private segment representation retains both authored rekeys; the target-settlement path has not migrated from endpoint-only assumptions to ordered segment inversion. First demonstrated loss is inverse ordering on entry to the complete-target realization route. prepareOrdinaryRealization then lowers that supplied order consistently, producing b. This supports classifying the failure as an unmigrated settlement consumer, rather than proving that the representation cannot express correct disposition. No fix performed. A valid correction must reverse/compose the authorized sequence after disposition, preserve foreign field truth, and separately check the ordinary pending compiler's dedup assumptions.

# Coverage blocker in renewed compiler freeze 03b31ff3

`transactions.ts:1846-1848` treats prior lifetime membership in sourceSegments as proof that a particular raw projection was paired. That proof is false for the existing private point-realization harness. `entity-signal.ts:503-576` prepares/installs point values without prepareEntityResponsibility, then publishes a realized notification. This is an established internal adapter exercise (entity-realization-handoff.spec.ts), not claimed as a public ingress API.

Executed falsifier: initial row a.n=7; pending own n=8 establishes tracked lifetime; preparePointRealization for n=123, install and publish; pending rollback. Final frozen source 03b31ff3 inspects current, accepts rollback and erases the realized123 to7. Frozen comparator (pre-segments transactions + first-adapter) inspects superseded and refuses later-confirmed-dependency, retaining123 and inspect/retry/confirm authority. Adjudicated test permits either preservation after successful rollback or atomic refusal retaining123 and retry authority. Final candidate fails; comparator passes.

Raw artifacts: unpaired-point-before.sha256, unpaired-point-adjudicated-before.sha256; unpaired-point.ts and first logs preserve the initial stricter success expectation (control refused, not passed); unpaired-point-adjudicated.ts and corresponding current/control logs establish the permitted-refusal comparison. No source mutation performed. This finding does not demonstrate an uninstrumented public restoration or Link failure. Matching guards already exclude intentional restoration/transaction-rollback/inspection contexts before suppression, and isRestoring is const false. Those contexts alone do not establish this blocker; the established unpaired point producer does.
