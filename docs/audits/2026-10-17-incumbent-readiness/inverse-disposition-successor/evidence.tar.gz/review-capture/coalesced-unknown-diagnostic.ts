import assert from 'node:assert/strict';
import {getPathNotifier} from '../candidate/packages/kernel/src/lib/path-notifier';
import {getEntityOrdinaryChanges} from '../candidate/packages/kernel/src/lib/internals/entity-value-transition';
import {signalTree,entityMap,transactions} from '../candidate/packages/kernel/src/index';
import {withWriteContext} from '../candidate/packages/kernel/src/lib/write-context';
import {preparePointRealization} from '../candidate/packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter';
import {getOwnedPositionIds,getOwnedSubjectIds} from '../candidate/packages/kernel/src/lib/internals/owned-mutation';
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
try {const r=t.$.rows;r.addOne({id:'a',n:7});for(let i=0;i<40;i++)await Promise.resolve();const a=r.byIdOrFail('a');const p=t.transact(()=>{withWriteContext({intent:'system',participation:'realized'},()=>a.n(99));a.n(8);});const owner=getOwnedPositionIds(r)![0],subjectId=getOwnedSubjectIds(a.n)![0];const plan=preparePointRealization(t,[{owner,subjectId,subjectFieldSegments:['n'],before:8,after:123}]);assert.ok(plan);plan.install();plan.publish();console.log('QUEUED',JSON.stringify(getPathNotifier().readPending().map(e=>({path:e.path,before:e.oldValue,after:e.newValue,meta:e.meta,ordinary:getEntityOrdinaryChanges(e.meta)}))));console.log('before',a.n(),JSON.stringify(p.inspect()));let refusal:unknown;try{p.rollback();}catch(e){refusal=e;}console.log('after',a.n(),'refused',!!refusal);assert.equal(a.n(),123);if(refusal){assert.doesNotThrow(()=>p.inspect());assert.throws(()=>p.rollback());assert.equal(a.n(),123);p.confirm();}console.log('PASS realization retained or atomic refusal');}finally{t.destroy();}
