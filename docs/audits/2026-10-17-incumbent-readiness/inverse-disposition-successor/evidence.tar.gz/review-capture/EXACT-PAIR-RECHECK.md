# Exact pair recheck, transactions a5ae192f67963019b6bcb871dff38de81f812b071a51993ce9f83593f05b9ddd

No blocker demonstrated in this bounded recheck. Exact-record WeakMap filtering resolves the earlier lifetime-map unpaired point counterexample: independent fresh unpaired-point-adjudicated-exact-final bundle inspects superseded, refuses atomically, preserves123, remains inspectable/retryable and permits confirmation.

Executed coalescing challenges, all with allowed success-or-refusal preservation assertion:

1. Callback foreign realized99 then own8; outside callback unpaired point123. Pass, refusal preserves123. Transaction flush leaves only the unpaired entry queued.
2. Unrelated x sentinel pending; foreign realized99 outside; new own8 pending; unpaired point123 outside. Pass, refusal preserves123. Transaction flush again leaves only the unpaired entry queued.
3. Same callback foreign99, own8, then point123 with inherited callback attribution. Pass; diagnostic entries remain separate.
4. Same callback foreign99, own8, then point123 explicitly within matching system/realized context (no transaction ID on either foreign operation). Pass; inside-queued diagnostic still shows separate foreign99 and point123 entries around own8. Intervening causal mode boundary prevents the hypothesized known/unknown coalescence.

Scripts/logs: unpaired-point-adjudicated-exact-final.*, coalesced-unknown-exact-final.*, coalesced-sentinel-exact-final.*, coalesced-inside.*, coalesced-inside-attributed.*. exact-final-replay-before.sha256 and individual *-before.sha256 record source identities before bundling. No runtime source edits. Older first-red logs remain unchanged.

Limits: these are private point-adapter/realized-context harnesses already established by existing tests, not claims of uninstrumented public ingress. No exhaustive summary-completeness proof, release gate, broad suite or performance claim. Source premise review separately identifies record sharing and destructive ordinary-entry projection. No counterexample to the final exact-record implementation was found in these attempted coalescing cases.
