# Incumbent inverse-disposition contract audit

Read-only source audit, 2026-10-23. Readiness checkout f1042531; no tests executed by this audit. Paths below relative to packages/kernel/src. Do not import B expectations into this model.

## Concrete rules to encode

| Authored pending fact | Later independent fact | Existing disposition and evidence |
| --- | --- | --- |
| field value | replacement of same location | Keep newer field and reverse other transaction effects; proposal-rejection-0.spec.ts header and cases 2–7; transactions.ts classifyLaterOverlap lines 420–466. Identity/revision matters, not equal value. |
| field value | overlapping nonreplacement/ancestor mutation | Atomic refusal when classified dependency, not silent surgical omission; same classifier. |
| added lifetime | later field edit on that lifetime | Atomic whole-turn later-confirmed-dependency; proposal-rejection-0 case9 lines290–316. |
| added lifetime | later removal | Skip inverse removal, reverse remaining facts; cases11/12 lines350–397. |
| added lifetime | removal then new lifetime at same key | Preserve replacement lifetime, skip erased original; case13 lines407–435. |
| removed lifetime | fresh lifetime occupies original key | Atomic effect-validation-failed; no overwrite; case15 lines463–490. Header explicitly identifies this as expected refusal (older inline TODO wording is stale). |
| rekey | later field edit of same lifetime | Reverse key, carry newer field along; rekey-supersession-0 case1 lines51–83. Field does not author key occupancy. |
| rekey | later removal of lifetime | Skip inverse rename, reverse remaining facts; rekey-supersession-0 case2 and proposal-rejection case16. |
| rekey | different lifetime occupies inverse destination | Refuse before installation; transactions.ts 592–624 tracks NET occupancy, allowing retry when add is subsequently removed or rekeyed away. |
| any turn | one superseded fact plus one surviving structural dependency | Entire rejection refuses, no partial reversal; proposal-rejection case14 lines438–460. |
| overlapping later pending fact | not terminal committed authority | Refuse rather than treating it as supersession; transactions.ts getPendingRollbackPlan 960–1001. |

Refusal retains authority: proposal-facade-0.spec.ts 461–510 proves confirm after refused rollback and live inspection after further changes. Successful retry after conflict removal must inspect net current occupancy, not stale historical add existence (transactions.ts rekey occupancy comment 592 onward).

## Intervening realized writer inside callback

This is an established internal producer contract, not a newly invented invariant violation: queued-inspection-review.spec.ts 24–42 explicitly invokes withWriteContext({intent:system,participation:realized}) before/after authored writes inside transact callback. Before means own value current; after means own value superseded. Lines44–96 additionally preserve external scalar/entity-field ABA identity. Source-only audit does NOT establish a public application trigger for the occupancy-gap reproduction.

Thus discontinuity alone cannot reject capture admission. Segments must retain who authored each transition. The existing tests do not fully prescribe rejection of every interleaved structural sequence: use the above dependency/refusal rules, preserve foreign facts, or atomically refuse. Baseline construct/inspect/confirm success does not imply successful rejection.

## Ordering limit

transactions.ts captures collection order separately (2438–2443), derives pending order deltas (2512–2521), and passes those separately into rollback realization (4095–4116). Do not model incidental rekey snapshots as authored full reorder. This audit found no direct incumbent test establishing arbitrary later committed full-order supersession within this limited read; that outcome must be verified against order-delta realization source/policy controls before imposing a model expectation. Existing owner-approved successor placement policy and approved physical99/ordinary7 decision remain governing inputs.

Execution dependencies and placement constraints are distinct. update-then-remove-rollback.spec.ts header explicitly requires revival before field reversal, including declarative order targets. Rearranging only structural slots cannot invalidate that execution precondition.

## Model acceptance implications

Use immutable lifetime identity plus per-operation authored field/key/existence/order facts. Foreign writes keep separate chronology; do not merge foreign admission into transaction ownership. Equal-value ABA may supersede by identity; no-turn authored ABA is deliberately different (queued-inspection-review.spec.ts 139 onward). Rejection prepares all disposition and placement privately, and any unresolved dependency refuses whole unit without retiring authority. These are acceptance requirements inferred directly from cited controls, not an authorization of a new representation.
