import {signalTree,transactions} from './packages/solid/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<50;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];for(const mode of ['set','update']){
 const t=signalTree({y:7},{enhancers:[transactions()]});try{
 withWriteContext({participation:'inspection'},()=>t.$.y.set(99));await tick();let input:unknown;
 const p=t.transact(()=>mode==='set'?t.$.y.set(99):t.$.y.update(v=>{input=v;return v;}));
 await tick();const before={display:t.$.y(),changes:p.inspect().changes,input};p.rollback();await tick();rows.push({mode,before,after:t.$.y(),expected:7,pass:t.$.y()===7});
 }finally{t.destroy();await tick();}}return rows;}
