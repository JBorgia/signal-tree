import '@angular/compiler';
import * as angular from './packages/angular/src/index';
import * as solid from './packages/solid/src/index';
import * as vue from './packages/vue/src/index';
import * as react from './packages/react/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];
for(const [name,facade] of Object.entries({angular,solid,vue,react}))for(const linked of [false,true])for(const mode of ['set','update']){
 const f:any=facade;const t:any=f.signalTree({y:7},{enhancers:[f.transactions()]});const leaf:any=t.$.y;
 const read=()=>name==='vue'?leaf.value:leaf();
 const set=(v:number)=>name==='vue'?leaf.value=v:name==='react'?leaf(v):leaf.set(v);
 const update=(fn:(v:number)=>number)=>name==='vue'?leaf.value=fn(leaf.value):name==='react'?leaf(fn):leaf.update(fn);
 const sent:number[]=[];const c=linked?f.link(leaf,{get:()=>7,set:(v:number)=>sent.push(v)}):undefined;
 try{if(c)await c.retrieve();await tick();withWriteContext({participation:'inspection'},()=>set(99));await tick();let input:unknown;
 const p=t.transact(()=>mode==='set'?set(99):update(v=>{input=v;return v;}));await tick();
 const before={display:read(),changes:p.inspect().changes,input};p.rollback();await tick();
 rows.push({name,linked,mode,before,after:read(),sent:[...sent],pass:read()===7&&before.changes.length===1&&(mode==='set'||input===99)&&!sent.includes(99)});
 }catch(e){rows.push({name,linked,mode,error:String(e),pass:false});}finally{c?.dispose();t.destroy();await tick();}}
return rows;}
