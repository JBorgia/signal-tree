import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];for(const scenario of ['ordinary','rollback','confirm','different-rollback','true-noop','exit','repeated-inspect','incoming','callback-throw']){
const t=signalTree({y:scenario==='true-noop'?99:7},{enhancers:[transactions()]});const sent:number[]=[];const c:any=link(t.$.y,{get:()=>99,set:(v:number)=>{sent.push(v);}});const changes:number[]=[];const off=t.$.y.subscribe(()=>changes.push(t.$.y()));const checks:any[]=[];const eq=(name:string,a:unknown,e:unknown)=>checks.push({name,actual:structuredClone(a),expected:e,pass:JSON.stringify(a)===JSON.stringify(e)});let receipt:any;
try{
if(scenario!=='true-noop'){withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();}changes.length=0;
if(scenario==='ordinary'){receipt=c.declare({kind:'independent'},()=>t.$.y(99));await tick();eq('adopt sends',sent,[99]);eq('no value notify',changes,[]);eq('receipt meaningful',receipt.read().state,'started');}
if(['rollback','confirm','different-rollback','repeated-inspect'].includes(scenario)){
if(scenario==='repeated-inspect'){withWriteContext({participation:'inspection'},()=>t.$.y(88));withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();}
const p=t.transact(()=>t.$.y(scenario==='different-rollback'?100:99));eq('pending recorded',p.inspect().changes.length,1);await tick();eq('pending held',sent,[]);if(scenario==='confirm')p.confirm();else p.rollback();await tick();eq('physical settled',t.$.y(),scenario==='confirm'?99:7);eq('publication settled',sent,scenario==='confirm'?[99]:[7]);}
if(scenario==='true-noop'){const p=t.transact(()=>t.$.y(99));eq('no record',p.inspect().changes,[]);p.rollback();await tick();eq('no send',sent,[]);eq('no notification',changes,[]);}
if(scenario==='exit'){await tick();eq('display persists',t.$.y(),99);eq('no adoption',sent,[]);}
if(scenario==='incoming'){await c.retrieve();await tick();const no=t.transact(()=>t.$.y(99));eq('acquired99 true noop',no.inspect().changes,[]);no.confirm();const p=t.transact(()=>t.$.y(100));p.rollback();await tick();eq('rollback acquired99',t.$.y(),99);}
if(scenario==='callback-throw'){const err={why:'same'};let same=false;try{t.transact(()=>{t.$.y(99);throw err;});}catch(e){same=e===err;}await tick();eq('throw identity',same,true);eq('abort physical',t.$.y(),7);eq('abort publication',sent,[7]);}
}catch(e){checks.push({name:'unexpected',error:String(e),pass:false});}finally{off();c.dispose();t.destroy();await tick();}rows.push({scenario,checks});}return rows;}
