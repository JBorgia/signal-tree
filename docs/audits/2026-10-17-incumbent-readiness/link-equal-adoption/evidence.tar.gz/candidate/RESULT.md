# Private scalar equal-adoption native experiment

Owner authorizes meaningful ordinary adoption of inspection-displayed value and rollback restoration to ordinary7, not display99. Source-loader only; production untouched.

Mechanism: sparse per-slot baseline Map populated only while inspection diverges. `readRecordSlot` provides ordinary-before for terminal preparation and capture, display still serves public reads/updaters. commitRecorded distinguishes semantic responsibility change from physical change; records install before publication. Equal adoption advances responsibility but suppresses ordinary value publication. Point and frame installation prepare shadow transitions and discharge them on noninspection realization, including equality. Frame output changedSlots remains physical.

First neutral9 scenarios passed. Source review found derive transformation incomplete; first-patch preserved. Independent native first compile duplicate changed preserved by reviewer. Native derive now takes current display for callback, ordinary-before for capture. Added neutral derive rollback passes.

Frozen final worker controls: witness10 scenarios/32 assertions pass; frame-controls4 pass (branch/root inspection ingress and equal point/frame realization); overlap3 pass (older/newer independent authority preserved by atomic refusal; newest-open-first rollback99->7->0 succeeds). Slot fault characterizations: equality/preparation failure leaves physical99/ordinary-before7; equality reentry preserves newer77 and rejects stale outer installation. `faults.ts` attempted equality through unsupported signalTree config.equal, which did not exercise comparison: two diagnostic rows are NOT equality-fault passes. Its subscriber reentry2 assertions pass. slot-faults is actual configurable-slot comparator test replacing that unqualified instrumentation. The slot scenario named derive is plain successful commit characterization, not derive coverage; actual derive covered by witness.

Typecheck first adds TS2345 native result union; fixed with explicit discriminator objects, no casts. Final transformed source full kernel tsconfig.lib diagnostics byte-identical to baseline11 preexisting TS4111 research semantics files. Parent targeted gate may exclude these; this run is differential, not clean.

Limits: no production acceptance, no cost/performance claim. Frame implementation intentionally allocates preparation maps; optimization unqualified. Broad framework/entity/removal/reclamation matrices not run. Slot shadow held only by runtime, but no retained-heap destruction proof or arbitrary omission lifecycle coverage. Full native framework controls are independent reviewer evidence, not inherited here. Public source/API unchanged.

Replay final-witness-bundle.mjs etc export async run(); Node24.15.0. Loader rebuild requires recorded checkout and patch.mjs/frame-fragment absolute paths. First files preserve original outputs. No broad suite.

## Shared root/branch admission correction

Frozen507c source failed unchanged native P5: inbound root acquisition set Link eligible99, but recursive branch reference-equality shortcut skipped slot admission, retaining ordinary baseline7. Later ordinary7 suppressed responsibility and never reached Link. First source preserved p5-failed-patch.mjs; parent retains Nx first log. No Link-specific repair.

Internal writable binding now supplies optional needsAuthorityAdmission, delegated to the scalar substrate's existing inspection-baseline presence and current noninspection participation. Recursive branch skip asks this query. Genuine ordinary no-op still skips ingress (write interception count0), value reporting stays[]. No new global map or public export; existing weak binding lifecycle holds the closure.

New root/branch ordinary+realized and no-op controls12 pass with private scalar declaration eligibility disabled for root-native tests. First root controls with scalar-only declaration engine enabled produced three no-send failures; preserved root-admission-first source/bundle/log. That engine has no root location ticket and is not root-Link qualified. Native-path result does NOT extend declaration API scope to aggregates. Parent Nx unchanged P5 is the production-shaped regression.
