import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];for(const scenario of ['subscriber-reentry','throw-equality','reenter-equality']){
let fault=false,reentered=false;let t:any;const eq=(a:unknown,b:unknown)=>{if(fault){fault=false;if(scenario==='throw-equality')throw Error('equality');if(scenario==='reenter-equality'){reentered=true;t.$.y(77);}}return Object.is(a,b);};
t=signalTree({y:7},{enhancers:[transactions()],equal:eq});const sent:number[]=[];const c=link(t.$.y,{set:v=>{sent.push(v as number);}});const checks:any[]=[];const check=(name:string,a:unknown,e:unknown)=>checks.push({name,actual:a,expected:e,pass:JSON.stringify(a)===JSON.stringify(e)});let off=()=>{};
try{withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();
if(scenario==='subscriber-reentry'){off=t.$.y.subscribe(()=>{if(t.$.y()===7)t.$.y(88);});const p=t.transact(()=>t.$.y(99));p.rollback();await tick();check('reentrant newer write',t.$.y(),88);check('published newer',sent.at(-1),88);}
else {fault=true;let error:string|undefined;try{t.transact(()=>t.$.y(99));}catch(e){error=String(e);}await tick();rows.push({scenario,error,reentered,physical:t.$.y(),sent:[...sent]});continue;}
}catch(e){checks.push({name:'unexpected',error:String(e),pass:false});}finally{off();c.dispose();t.destroy();await tick();}rows.push({scenario,checks});}return rows;}
