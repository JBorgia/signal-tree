import {readFileSync} from 'node:fs';
export function patch(s,path){
if(path.endsWith('/tree-scalar-slot-runtime.ts')){
s="import {getActiveWriteContext} from '../write-context';\n"+s;
s=s.replace('  createSlot<T>(', '  readRecordSlot<T>(slotIndex: SlotIndex): T;\n  createSlot<T>(');
s=s.replace('prepare?: () => TerminalRecordPlan | undefined): boolean;', 'prepare?: () => TerminalRecordPlan | undefined): {changed:boolean;physicalChanged:boolean};');
s=s.replace('  const values: unknown[] = [];','  const values: unknown[] = [];\n  const inspectionBaseline = new Map<number,unknown>();');
s=s.replace('    commitRecorded<T>(slotIndex: SlotIndex, value: T, prepare?: () => TerminalRecordPlan | undefined): boolean {','    readRecordSlot<T>(slotIndex: SlotIndex):T { return (getActiveWriteContext()?.participation!==\'inspection\' && inspectionBaseline.has(slotIndex) ? inspectionBaseline.get(slotIndex) : values[slotIndex]) as T; },\n    commitRecorded<T>(slotIndex: SlotIndex, value: T, prepare?: () => TerminalRecordPlan | undefined): {changed:boolean;physicalChanged:boolean} {');
s=s.replace('      if(equal)return false;\n      const plan=prepare?.();',`      const inspection=getActiveWriteContext()?.participation==='inspection';
      const shadowed=inspectionBaseline.has(slotIndex);
      const ordinaryBefore=shadowed?inspectionBaseline.get(slotIndex):values[slotIndex];
      const authorityEqual=shadowed?equalities[slotIndex](ordinaryBefore,value):equal;
      if(getCommittedRevision()!==base)throw new Error('Scalar authority equality reentered installation');
      const semanticChanged=inspection?!equal:!authorityEqual;
      if(equal&&!semanticChanged){if(!inspection)inspectionBaseline.delete(slotIndex);return {changed:false,physicalChanged:false};}
      const plan=semanticChanged?prepare?.():undefined;`);
s=s.replace('      values[slotIndex]=value;',`      if(inspection){if(authorityEqual)inspectionBaseline.delete(slotIndex);else if(!shadowed)inspectionBaseline.set(slotIndex,ordinaryBefore);}else inspectionBaseline.delete(slotIndex);
      values[slotIndex]=value;`);
s=s.replace('      return true;\n    },\n    commitSlot<T>', '      return {changed:semanticChanged,physicalChanged:!equal};\n    },\n    commitSlot<T>');
// Direct/frame realization installation retires any touched inspection shadow.
s=s.replace(/^(\s*)values\[slotIndex\] = nextValue;/gm, '$1inspectionBaseline.delete(slotIndex);\n$1values[slotIndex] = nextValue;');

const begin=s.indexOf('  const prepareSlots =');const end=s.indexOf('  const commitSlot =',begin);s=s.slice(0,begin)+readFileSync('/private/tmp/link-equal-adoption/frame-fragment.txt','utf8')+s.slice(end);
}
if(path.endsWith('/tree-scalar-leaf-runtime.ts')){
s=s.replace('    return kernel.readSlot<T>(slotIndex);','    return stored ? kernel.readRecordSlot<T>(slotIndex) : kernel.readSlot<T>(slotIndex);');
s=s.replace('    const result = {changed:changedValue};','    const result = {changed:changedValue.physicalChanged};');
s=s.replace('    return changed;\n  });','    return {changed:changedValue.changed || reAdded,physicalChanged:changed};\n  });');
}
if(path.endsWith('/location-runtime.ts')){
s=s.replaceAll("prepare?: () => TerminalRecordPlan | undefined) => boolean", "prepare?: () => TerminalRecordPlan | undefined) => boolean | {changed:boolean;physicalChanged:boolean}");
s=s.replace("const changed = write(next, 'replace',", "const result = write(next, 'replace',");
s=s.replace("const changed = write(next, 'derive',", "const result = write(next, 'derive',");
s=s.replace("after:next,changed:true}));", "after:next,changed:true}));\n        const changed=typeof result==='boolean'?result:result.changed;\n        const physicalChanged=typeof result==='boolean'?result:result.physicalChanged;");
s=s.replace("const result = write(next, 'derive',()=>mutationSource2.prepareTerminal?.({intent:'derive',before,after:next,changed:true}));", "const result = write(next, 'derive',()=>mutationSource2.prepareTerminal?.({intent:'derive',before,after:next,changed:true}));\n        const changed=typeof result==='boolean'?result:result.changed;\n        const physicalChanged=typeof result==='boolean'?result:result.physicalChanged;");
s=s.replaceAll('if (changed) publish([binding]);','if (physicalChanged) publish([binding]);');
}
if(path.endsWith('/native-tree-scalar-leaf-runtime.ts')){
s=s.replace('dormant ? kernel.readSlot<T>(slotIndex) : realized.peek()', 'kernel.readRecordSlot<T>(slotIndex)');
s=s.replace('      const before = dormant ? kernel.readSlot<T>(slotIndex) : realized.peek();', '      const current = dormant ? kernel.readSlot<T>(slotIndex) : realized.peek();\n      const before = kernel.readRecordSlot<T>(slotIndex);');
s=s.replace('const next = update(dormant ? undefined as T : before);','const next = update(dormant ? undefined as T : current);');
s=s.replaceAll('const changed = kernel.commitRecorded(', 'const resultCommit = kernel.commitRecorded(');
s=s.replaceAll('after:value,changed:true}));', 'after:value,changed:true}));\n      const changed=resultCommit.changed;');
s=s.replaceAll('after:next,changed:true}));', 'after:next,changed:true}));\n      const changed=resultCommit.changed;');
s=s.replace('publishChanged(changed, {value});','publishChanged(resultCommit.physicalChanged, {value});');
s=s.replace('      publishResult(result);','      publishResult(resultCommit.physicalChanged ? {revision:kernel.revision(),changed:true,slot:slotIndex} : {revision:kernel.revision(),changed:false});');
}
return s;
}
