import '@angular/compiler';
import * as angular from './packages/angular/src/index';
import * as solid from './packages/solid/src/index';
import * as vue from './packages/vue/src/index';
import * as react from './packages/react/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
import {needsLocationAuthorityAdmission} from './packages/kernel/src/lib/internals/location-runtime';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];for(const [name,facade] of Object.entries({angular,solid,vue,react}))for(const scope of ['root','branch'])for(const operation of ['adopt','acquire','ordinary-noop']){
 const f:any=facade;const t:any=f.signalTree({box:{y:7}},{enhancers:[f.transactions()]});const leaf=t.$.box.y;const leafRead=()=>name==='vue'?leaf.value:leaf();const leafWrite=(v:number)=>name==='vue'?leaf.value=v:name==='react'?leaf(v):leaf.set(v);let payload:any=scope==='root'?{box:{y:99}}:{y:99};const target:any=scope==='root'?t.$:t.$.box;const set=(v:number)=>scope==='root'?t.$({box:{y:v}}):t.$.box({y:v});const sent:any[]=[];const c:any=f.link(target,{get:()=>payload,set:(v:any)=>sent.push(v)});
 try{if(operation==='ordinary-noop'){const p=t.transact(()=>set(7));rows.push({name,scope,operation,query:needsLocationAuthorityAdmission(t.$.box.y),changes:p.inspect().changes,pass:p.inspect().changes.length===0});p.rollback();continue;}
 withWriteContext({participation:'inspection'},()=>leafWrite(99));await tick();const queryBefore=needsLocationAuthorityAdmission(t.$.box.y);
 if(operation==='adopt'){const p=t.transact(()=>set(99));await tick();const queryAfter=needsLocationAuthorityAdmission(t.$.box.y);const changes=p.inspect().changes;p.rollback();await tick();rows.push({name,scope,operation,queryBefore,queryAfter,changes,after:leafRead(),pass:queryBefore&&!queryAfter&&changes.length===1&&leafRead()===7});}
 else{await c.retrieve();await tick();const queryAfter=needsLocationAuthorityAdmission(t.$.box.y);leafWrite(7);await tick();const last=sent.at(-1);rows.push({name,scope,operation,queryBefore,queryAfter,sent,pass:queryBefore&&!queryAfter&&(scope==='root'?last?.box.y:last?.y)===7});}
 }finally{c.dispose();t.destroy();await tick();}}return rows;}
