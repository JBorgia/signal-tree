import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
import {needsLocationAuthorityAdmission} from './packages/kernel/src/lib/internals/location-runtime';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];for(const scope of ['root','branch'])for(const operation of ['adopt','acquire','ordinary-noop']){
 const t=signalTree({box:{y:7}},{enhancers:[transactions()]});let payload:any=scope==='root'?{box:{y:99}}:{y:99};const target:any=scope==='root'?t.$:t.$.box;const set=(v:number)=>scope==='root'?t.$({box:{y:v}}):t.$.box({y:v});const sent:any[]=[];const c:any=link(target,{get:()=>payload,set:(v:any)=>sent.push(v)});
 try{if(operation==='ordinary-noop'){const p=t.transact(()=>set(7));rows.push({scope,operation,query:needsLocationAuthorityAdmission(t.$.box.y),changes:p.inspect().changes,pass:p.inspect().changes.length===0});p.rollback();continue;}
 withWriteContext({participation:'inspection'},()=>t.$.box.y(99));await tick();const queryBefore=needsLocationAuthorityAdmission(t.$.box.y);
 if(operation==='adopt'){const p=t.transact(()=>set(99));await tick();const queryAfter=needsLocationAuthorityAdmission(t.$.box.y);const changes=p.inspect().changes;p.rollback();await tick();rows.push({scope,operation,queryBefore,queryAfter,changes,after:t.$.box.y(),pass:queryBefore&&!queryAfter&&changes.length===1&&t.$.box.y()===7});}
 else{await c.retrieve();await tick();const queryAfter=needsLocationAuthorityAdmission(t.$.box.y);t.$.box.y(7);await tick();const last=sent.at(-1);rows.push({scope,operation,queryBefore,queryAfter,sent,pass:queryBefore&&!queryAfter&&(scope==='root'?last?.box.y:last?.y)===7});}
 }finally{c.dispose();t.destroy();await tick();}}return rows;}
