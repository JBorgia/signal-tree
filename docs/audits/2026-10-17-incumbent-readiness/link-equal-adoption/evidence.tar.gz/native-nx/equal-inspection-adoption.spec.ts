import {describe,it,expect} from 'vitest';
import {signalTree,transactions,link} from '../index';
import {withWriteContext} from './write-context';
const tick=async()=>{for(let i=0;i<40;i++)await Promise.resolve();};
describe('authorized equal inspection adoption',()=>{
 for(const mode of ['rollback','confirm','ordinary','noop','exit','repeat'] as const)it(mode,async()=>{
 const tree=signalTree({y:mode==='noop'?99:7},{enhancers:[transactions()]});const sent:number[]=[];const c=link(tree.$.y,{set:value=>{sent.push(value);}});let count=0;const off=tree.$.y.subscribe(()=>count++);
 try{
 if(mode!=='noop'){withWriteContext({participation:'inspection'},()=>tree.$.y(99));if(mode==='repeat'){withWriteContext({participation:'inspection'},()=>tree.$.y(88));withWriteContext({participation:'inspection'},()=>tree.$.y(99));}await tick();expect(sent).toEqual([]);}
 const before=count;
 if(mode==='exit'){expect(tree.$.y()).toBe(99);expect(sent).toEqual([]);return;}
 if(mode==='ordinary'||mode==='noop'){tree.$.y(99);await tick();expect(count).toBe(before);expect(sent).toEqual(mode==='ordinary'?[99]:[]);return;}
 const p=tree.transact(()=>tree.$.y(99));await tick();expect(p.inspect().changes).toHaveLength(1);expect(count).toBe(before);expect(sent).toEqual([]);
 if(mode==='confirm')p.confirm();else p.rollback();await tick();expect(tree.$.y()).toBe(mode==='confirm'?99:7);expect(sent.at(-1)??7).toBe(mode==='confirm'?99:7);
 }finally{off();c.dispose();tree.destroy();}
 });
});
describe('equal branch authority admission',()=>{
 it('captures supplied equal displayed values through root replacement',async()=>{
 const t=signalTree({y:7},{enhancers:[transactions()]});try{
 withWriteContext({participation:'inspection'},()=>t.$({y:99}));const p=t.transact(()=>t.$({y:99}));await tick();expect(p.inspect().changes).toHaveLength(1);p.rollback();await tick();expect(t.$.y()).toBe(7);
 }finally{t.destroy();}
 });
 it('keeps an ordinary equal root replacement empty',async()=>{
 const t=signalTree({y:99},{enhancers:[transactions()]});try{const p=t.transact(()=>t.$({y:99}));await tick();expect(p.inspect().changes).toHaveLength(0);p.rollback();expect(t.$.y()).toBe(99);}finally{t.destroy();}
 });
});
