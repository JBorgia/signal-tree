import type { PositionId } from '../types';
import { markTreeCell } from './cell-identity';
import { registerIntrinsicMutationSource } from './intrinsic-mutation';
import {
  registerWritableLocationBinding,
  type WritableLocationBinding,
} from './location-runtime';
import type {
  ObservationAdapter,
  ObservationToken,
} from './observation-adapter';
import type { PhysicalCommitClock } from './physical-commit-clock';
import {
  PRODUCTION_SUBSTRATE_STATS_ENABLED,
  recordProductionSubstrateStat,
} from './production-substrate-stats';
import type { Location } from './cell-runtime';
import type {
  MemberAbsence,
  ScalarSlotMutationFrame,
  SlotIndex,
  TreeScalarLeafRuntime,
} from './tree-scalar-slot-port';
import {
  createTreeScalarSlotRuntime,
  type ScalarSlotCommitResult,
  type ScalarSlotMutationFrame as ScalarSlotKernelMutationFrame,
  type TreeScalarSlotRuntime,
} from './tree-scalar-slot-runtime';

class NativeScalarSlotPublication {
  private readonly tokens: Array<ObservationToken | undefined> = [];

  constructor(private readonly observation: ObservationAdapter) {}

  bind(slotIndex: SlotIndex, token: ObservationToken): void {
    this.tokens[slotIndex] = token;
  }

  publish(result: ScalarSlotCommitResult): void {
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat('publications', result.changedSlots.length);
    }
    let failed = false;
    let first: unknown;
    try {
      this.observation.runInvalidationGroup(() => {
        for (const slotIndex of result.changedSlots) {
          try { this.token(slotIndex).invalidate(); }
          catch (error) { if (!failed) { failed = true; first = error; } }
        }
      });
    } catch (error) { if (!failed) { failed = true; first = error; } }
    if (failed) throw first;
  }

  publishSlot(result: {
    readonly changed: boolean;
    readonly slot?: SlotIndex;
  }): void {
    if (!result.changed || result.slot === undefined) return;
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat('publications');
    }
    this.token(result.slot).invalidate();
  }

  private token(slotIndex: SlotIndex): ObservationToken {
    return (this.tokens[slotIndex] ??= this.observation.createToken());
  }
}

class NativeScalarSlotMutationFrame implements ScalarSlotMutationFrame {
  constructor(
    private readonly frame: ScalarSlotKernelMutationFrame,
    private readonly publication: NativeScalarSlotPublication
  ) {}

  set(slotIndex: SlotIndex, value: unknown): void {
    this.frame.set(slotIndex, value);
  }

  update(slotIndex: SlotIndex, updater: (value: unknown) => unknown): void {
    this.frame.update(slotIndex, updater);
  }

  discard(): void {
    this.frame.discard();
  }

  prepareCommit(options?: { advanceRevision?: boolean; publish?: boolean }): () => ScalarSlotCommitResult {
    const install = this.frame.prepareCommit({advanceRevision:options?.advanceRevision});
    return () => {
      const result = install();
      if (options?.publish !== false) this.publication.publish(result);
      return result;
    };
  }

  commit(options?: {
    advanceRevision?: boolean;
    publish?: boolean;
  }): ScalarSlotCommitResult {
    const result = this.frame.commit({
      advanceRevision: options?.advanceRevision,
    });
    if (options?.publish !== false) {
      this.publication.publish(result);
    }
    return result;
  }
}

function createNativeScalarLeaf<T>(
  kernel: TreeScalarSlotRuntime,
  publication: NativeScalarSlotPublication,
  observation: ObservationAdapter,
  slotIndex: SlotIndex,
  liveness: { absence?: MemberAbsence }
): Location<T> {
  const holder: { leaf?: Location<T> } = {};
  const realized = observation.createWritableCell?.(() => {
    // Absent when this leaf or a member above it is omitted (v16 8d). One
    // empty slot until this tree's first omission (v16 8e).
    if (liveness.absence?.isAbsent(holder.leaf)) return undefined as T;
    return kernel.readSlot<T>(slotIndex);
  });
  if (!realized) throw new Error('Expected a native writable cell realization');

  const native = realized.cell;
  publication.bind(slotIndex, realized.token);
  const leaf = markTreeCell(native as unknown as Location<T>);
  holder.leaf = leaf;
  const mutationSource = registerIntrinsicMutationSource<T>(leaf as object);

  // `reAdd` re-adds and announces an absent leaf's path, and says whether it
  // did (`reactivatePathOnWrite`). No per-leaf closure: the slot is read
  // inline (v16 8e).
  const publishResult = (
    result: ReturnType<TreeScalarSlotRuntime['commitSlot']>
  ): void => {
    const reAdded = liveness.absence?.reAdd(leaf) === true;
    publication.publishSlot(
      reAdded && !result.changed
        ? { ...result, changed: true, slot: slotIndex }
        : result
    );
  };

  /**
   * `NATIVE-STORAGE-0`. When the adapter can accept a committed value, publish
   * it directly instead of invalidating a token that immediately calls back
   * into `kernel.readSlot` for the value this call already has.
   *
   * `committed` is passed only by paths that know it. A dormant member reads as
   * `undefined` through the cell's own closure, so reactivation without a known
   * value still goes the invalidate route.
   */
  const commitNative = realized.commit;
  const publishChanged = (changed: boolean, committed?: { value: T }): void => {
    const reAdded = liveness.absence?.reAdd(leaf) === true;
    if (!changed && !reAdded) return;
    if (committed !== undefined && commitNative !== undefined) {
      commitNative(committed.value);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat('publications');
      }
      return;
    }
    publication.publishSlot({ changed: true, slot: slotIndex });
  };

  const binding: WritableLocationBinding<T> = {
    location: leaf,
    notify: () => publication.publishSlot({ changed: true, slot: slotIndex }),
    replace: (value) => {
      const observer = mutationSource.observer, capture = mutationSource.capture;
      const observing = observer || capture;
      const dormant = observing ? liveness.absence?.isAbsent(leaf) === true : false;
      const before = observing ? (kernel.readRecordSlot<T>(slotIndex)) : undefined;
      const resultCommit = kernel.commitRecorded(slotIndex, value, () => mutationSource.prepareTerminal?.({intent:'replace',before:before as T,after:value,changed:true}));
      const changed=resultCommit.changed;
      const mutation = observing ? {intent:'replace' as const,before:before as T,after:changed || dormant ? value : before as T,changed:changed || dormant} : undefined;
      if (mutation) capture?.(mutation);
      publishChanged(resultCommit.physicalChanged, {value});
      if (mutation) observer?.(mutation);
    },
    derive: (update) => {
      const observer = mutationSource.observer, capture = mutationSource.capture;
      const dormant = liveness.absence?.isAbsent(leaf) === true;
      const current = dormant ? kernel.readSlot<T>(slotIndex) : realized.peek();
      const before = kernel.readRecordSlot<T>(slotIndex);
      const next = update(dormant ? undefined as T : current);
      const resultCommit = kernel.commitRecorded(slotIndex,next,()=>mutationSource.prepareTerminal?.({intent:'derive',before,after:next,changed:true}));
      const changed=resultCommit.changed;
      const result = changed ? {revision:kernel.revision(),changed:true as const,slot:slotIndex} : {revision:kernel.revision(),changed:false as const};
      const mutation = {intent:'derive' as const,before,after:result.changed || dormant ? next : before,changed:result.changed || dormant};
      capture?.(mutation);
      publishResult(resultCommit.physicalChanged ? {revision:kernel.revision(),changed:true,slot:slotIndex} : {revision:kernel.revision(),changed:false});
      observer?.(mutation);
    },
  };
  registerWritableLocationBinding(binding);
  native.set = binding.replace;
  native.update = binding.derive;
  return leaf;
}

export function createNativeTreeScalarLeafRuntime(
  physicalCommitClock: PhysicalCommitClock | undefined,
  observation: ObservationAdapter
): TreeScalarLeafRuntime {
  const kernel = createTreeScalarSlotRuntime(physicalCommitClock);
  const publication = new NativeScalarSlotPublication(observation);
  const leafByPositionId = new Map<PositionId, Location<unknown>>();
  const liveness: { absence?: MemberAbsence } = {};

  return {
    enableAbsence(absence: MemberAbsence): void {
      liveness.absence = absence;
    },
    disableAbsence(): void {
      liveness.absence = undefined;
    },
    createLeaf<T>(
      initialValue: T,
      equal: (current: T, next: T) => boolean,
      positionId?: PositionId
    ): Location<T> {
      const slotIndex = kernel.createSlot(initialValue, equal, positionId);
      const leaf = createNativeScalarLeaf<T>(
        kernel,
        publication,
        observation,
        slotIndex,
        liveness
      );
      if (positionId !== undefined) {
        leafByPositionId.set(positionId, leaf as Location<unknown>);
      }
      return leaf;
    },
    beginFrame(): ScalarSlotMutationFrame {
      return new NativeScalarSlotMutationFrame(
        kernel.beginFrame(),
        publication
      );
    },
    runInvalidationGroup(run: () => void): void {
      observation.runInvalidationGroup(run);
    },
    publishPrepared(result: ScalarSlotCommitResult): void {
      publication.publish(result);
    },
    resolveScalarSlot(positionId: PositionId): SlotIndex | undefined {
      return kernel.resolveScalarSlot(positionId);
    },
    resolveScalarLeaf(positionId: PositionId): Location<unknown> | undefined {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat('positionResolutions');
      }
      return leafByPositionId.get(positionId);
    },
    revision(): number {
      return kernel.revision();
    },
    slotCount(): number {
      return kernel.slotCount();
    },
  };
}
