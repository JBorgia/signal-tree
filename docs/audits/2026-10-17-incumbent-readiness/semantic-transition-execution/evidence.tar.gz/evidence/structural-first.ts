import {signalTree,entityMap,transactions,link} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/index';
import {withWriteContext} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve()};
const ins=(f:()=>void)=>withWriteContext({participation:'inspection'},f);
const results=[];
for(const mode of ['created-update','vacancy-add','created-remove']){
 const tree=signalTree({rows:entityMap<{id:string;name:string},string>({selectId:r=>r.id})},{enhancers:[transactions()]});
 const rows=tree.$.rows;rows.addOne({id:'a',name:'ordinary-A'});await tick();
 const oldA=rows.byIdOrFail('a');let held:any;const sends:unknown[]=[];
 const c=link(rows,{set:v=>{sends.push(structuredClone(v))}});
 const trace:any={mode};const snap=()=>({rows:rows.all(),held:held?.(),oldA:oldA(),pending:tree.transactions.pendingCount()});
 try{
  if(mode==='vacancy-add')ins(()=>rows.removeOne('a'));else{ins(()=>rows.addOne({id:'b',name:'inspection-B'}));held=rows.byIdOrFail('b');}
  trace.before=snap();
  const p=tree.transact(()=>{if(mode==='created-update')held.name('authored-B');else if(mode==='created-remove')rows.removeOne('b');else{rows.addOne({id:'a',name:'new-A'});held=rows.byIdOrFail('a');}});
  trace.installed=snap();try{trace.inspection=p.inspect()}catch(e){trace.inspectError=String(e)}
  try{p.rollback();trace.rollback='success'}catch(e){trace.rollback=String(e)}
  await tick();trace.after=snap();trace.sends=sends;
  try{p.rollback();trace.retry='success'}catch(e){trace.retry=String(e)}
 }catch(e){trace.error=String(e)}finally{c.dispose();tree.destroy()}
 results.push(trace);
}
console.log(JSON.stringify(results,null,2));
