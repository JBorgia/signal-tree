import { describe, expect, it } from 'vitest';
import { signalTree, entityMap, transactions, link } from '../index';
import { withWriteContext } from './write-context';

type Row = { id: string; n: number; m?: number };
const tick = async () => { for (let i = 0; i < 100; i++) await Promise.resolve(); };
const setup = () => {
  const tree = signalTree({ z: 0, rows: entityMap<Row, string>({ selectId: row => row.id }) }, { enhancers: [transactions()] });
  tree.$.rows.setAll([{ id: 'a', n: 7 }, { id: 'b', n: 8 }]);
  return tree;
};
const inspect = (work: () => void) => withWriteContext({ participation: 'inspection' }, work);

describe('shared entity semantic transition — prewritten acceptance', () => {
  it('A1: setAll preserves two lifetime adoption chronology and ordinary rollback', async () => {
    const tree = setup(); const rows = tree.$.rows; await tick();
    const sent: (readonly Row[])[] = [];
    const connection = link(rows, { set: value => { sent.push(structuredClone(value)); } });
    try {
      inspect(() => { rows.updateOne('a', { n: 99 }); rows.updateOne('b', { n: 88 }); });
      const pending = tree.transact(() => rows.setAll([{ id: 'a', n: 99, m: 1 }, { id: 'b', n: 88, m: 2 }]));
      // Exact A1 expected facts; archive preserves original run harness verbatim.
      expect(pending.inspect().changes.filter(change => change.path.endsWith('.n')).length).toBe(2);
      pending.rollback(); await tick();
      expect(rows.all()).toEqual([{ id: 'a', n: 7 }, { id: 'b', n: 8 }]);
      expect(sent.some(value => value.some(row => row.n === 99 || row.n === 88))).toBe(false);
      expect(() => pending.rollback()).not.toThrow();
    } finally { connection.dispose(); tree.destroy(); }
  });

  for (const writer of ['field', 'update', 'replacement', 'setAll'] as const) {
    it(`${writer}: equal displayed value is authored adoption; genuine ordinary equal is not`, () => {
      const tree = setup(); const rows = tree.$.rows; const a = rows.byIdOrFail('a');
      try {
        inspect(() => rows.updateOne('a', { n: 99 }));
        const pending = tree.transact(() => {
          if (writer === 'field') a.n(99);
          if (writer === 'update') rows.updateOne('a', { n: 99 });
          if (writer === 'replacement') a({ id: 'a', n: 99 });
          if (writer === 'setAll') rows.setAll([{ id: 'a', n: 99 }, { id: 'b', n: 8 }]);
        });
        expect(pending.inspect().changes.some(change => change.path.endsWith('.n'))).toBe(true);
        pending.rollback(); expect(a.n()).toBe(7);
        const noop = tree.transact(() => a.n(7));
        expect(noop.inspect().changes).toEqual([]); noop.rollback(); expect(a.n()).toBe(7);
      } finally { tree.destroy(); }
    });
  }

  it('partial adoption leaves inspected sibling outside ordinary responsibility', () => {
    const tree = setup(); const rows = tree.$.rows;
    try {
      inspect(() => rows.updateOne('a', { n: 99, m: 88 }));
      const pending = tree.transact(() => rows.updateOne('a', { n: 99 }));
      expect(pending.inspect().changes.some(change => change.path.endsWith('.m'))).toBe(false);
      pending.rollback();
      expect(rows.byIdOrFail('a').n()).toBe(7);
      expect(rows.byIdOrFail('a')().m).toBe(88);
    } finally { tree.destroy(); }
  });

  it('A1 mixed-throw: outer preparation failure preserves prior baselines for useful rollback', () => {
    const tree = setup(); const rows = tree.$.rows;
    try {
      inspect(() => { rows.updateOne('a', { n: 99 }); rows.updateOne('b', { n: 88 }); });
      const failure = new Error('getter');
      expect(() => tree.transact(() => {
        tree.$.z(1);
        rows.setAll([{ id: 'a', n: 99 }, { id: 'b', get n(): number { throw failure; } }]);
      })).toThrow(failure);
      expect(tree.$.z()).toBe(0);
      expect(rows.all()).toEqual([{ id: 'a', n: 99 }, { id: 'b', n: 88 }]);
      const pending = tree.transact(() => { rows.byIdOrFail('a').n(99); rows.byIdOrFail('b').n(88); });
      pending.rollback();
      expect(rows.all()).toEqual([{ id: 'a', n: 7 }, { id: 'b', n: 8 }]);
    } finally { tree.destroy(); }
  });
});
