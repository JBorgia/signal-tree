# Scoped prerequisite corrections

Only experimental-publication/private.ts, projection.ts, lifecycle.ts, link.ts and internals/native-tree-scalar-leaf-runtime.ts were edited by this worker. Other workers own notifier/entity/transaction paths. Original source is preserved in evidence/slice1-first-source.tar.gz and original diagnostic log slice1-types-first.log.

The materialized native scalar source incorrectly treated commitRecorded's semantic/physical result object as a boolean. Restored the previously reviewed native behavior: record-before reads ordinary authority; updater input reads current displayed value; mutation/capture uses semantic changed; native publication uses physicalChanged; the internal authority-admission query allows inspected-equal adoption through dispatch. This is the existing approved scalar rule, not a new transition policy. Prior four-facade evidence in /private/tmp/link-equal-adoption-review.md and its frozen patch were inspected before correction.

Experimental metadata now extends WriteMetadata with optional named unique-symbol properties. No generic string index or payload-authority cast was added. A first attempt using a symbol index was incompatible with WriteMetadata; prerequisite-types.log preserves that diagnostic. The named-symbol correction is in the final source.

Link constructs a locally typed Link & {declare(...)} object then returns it under the unchanged exported Link return type. This does not export declaration API typing. Publication error construction uses ordinary Error plus a nonenumerable writable configurable cause property with the exact original cause value; it no longer requires ES2022 ErrorOptions in a lower-library compile target.

Verification:
- `node .../typescript/bin/tsc --noEmit -p packages/kernel/tsconfig.lib.json`: final prerequisite-types-second.log has no diagnostics in edited files;11 errors remain in semantics-authority.ts/semantics-composition.ts, outside this assignment. This is not a clean package typecheck.
- `node /private/tmp/semantic-transition-execution/prerequisite-facades.mjs`: unchanged16 native scalar controls pass against current isolated candidate, four facades x Link/no-Link x set/update. All capture the adoption and rollback7; updates receive displayed99; no99 endpoint leak. This is not a computed/effect scheduling or broader framework suite claim.
- Final owned source identities: evidence/prerequisite-sha256.txt. Root runs affected Nx acceptance separately.
