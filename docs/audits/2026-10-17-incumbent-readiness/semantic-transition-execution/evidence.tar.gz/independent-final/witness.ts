import {signalTree,entityMap,transactions,restoration} from '/private/tmp/semantic-transition-execution/candidate/packages/kernel/src/index';
import {withWriteContext} from '/private/tmp/semantic-transition-execution/candidate/packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve()};
const results=[];
for(const mixed of [false,true]){
 const tree=signalTree({x:0,rows:entityMap<{id:string;n:number;m:number},string>({selectId:r=>r.id})},{enhancers:[transactions(),restoration()]}); const rows=tree.$.rows;
 try{
 rows.addOne({id:'a',n:7,m:0}); await tick();
 withWriteContext({participation:'inspection'},()=>rows.updateOne('a',{n:99})); await tick();
 const p=tree.transact(()=>{if(mixed)tree.$.x(1);rows.updateOne('a',{m:4})});
 p.rollback(); const afterFirst=rows.byIdOrFail('a')();
 const q=tree.transact(()=>rows.updateOne('a',{n:99})); const changes=q.inspect().changes; q.rollback();
 results.push({mixed,afterFirst,changes,final:rows.byIdOrFail('a')(),x:tree.$.x(),pass:changes.some(c=>c.path.endsWith('.n'))&&rows.byIdOrFail('a').n()===7});
 }finally{tree.destroy()}
}
console.log(JSON.stringify(results,null,2));
