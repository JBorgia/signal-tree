# Inspection-created / removed lifetime compensation: contract inventory

Read-only investigation for authorized migration f80645c8. No runtime patch or replay executed; candidate outcomes below are discriminators, not selected expected assertions. Citations use current worktree `/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/`.

## Finding

Existing rules determine minimal **egress** adoption and exclusion of inspection from transaction authorship/dependency. I did not find a governing decision that uniquely specifies **physical rollback and lifetime disposition after a transaction authors into an inspection-created lifetime, or fills an inspection-created vacancy**. Treat that subset as the plan's conditional semantic stop. Existing-lifetime ordinary-value migration can continue independently.

This is not evidence that all structural behavior is undecided: authored creation/removal, held lifetime isolation, inspection not blocking rollback, and ordinary Link topology exclusion are already governed. The missing intersection is adoption ownership and inverse realization when ordinary and physical membership differ before the new contribution.

## Positive rules with exact evidence

- `packages/kernel/src/lib/entity-inspection-egress.spec.ts:17–29`: traverse local topology without promoting incidental neighbors; authored UPDATE of inspection-created subject adopts necessary existence; authored REMOVE does not (still absent represents ordinary truth).
- Same file133: A1 ordinary update promotes inspected-created B to Link;142/159/173 exercise minimality and successor traversal;188 A2 ordinary add into inspected vacancy adopts new lifetime, not old lifetime;216 inspected-created removal is value-neutral;238 rekeyed lifetime remains same identity. These methods are ordinary calls. The fixture has transactions enhancer at49–53, but there is **no transact/rollback scenario in this file**. Enhancer presence is not transaction-compensation coverage.
- Same file85–125: inspection removals/additions do not hitchhike on unrelated authored updates; local IDs can intentionally disagree with outgoing ordinary topology. Therefore “make physical membership equal Link membership immediately” is not a general contract.
- `packages/kernel/src/lib/write-participation.ts:17–29`: inspection is excluded from causal admission; viewing B cannot prevent business rollback to A. This excludes inspection as authority but does not specify the minimum structural inverse of a later authored field operation.
- `packages/kernel/src/enhancers/devtools/devtools-jump-0-1.spec.ts:44–81`: inspection scalar42 inside a transaction survives rollback of unrelated authored row creation. Inspection is not automatically erased globally at settlement.
- Same file84–105: authored pending row creation followed by inspection update still rolls back to absence. The inspected row has no independent preservation right.
- Same file107 onward: later authored write after inspection still creates dependency; inspection is not a causal eraser. Keep this as a safety constraint for overlap, not a specification of adoption into an originally inspection-created row.
- `docs/architecture/v15-production-surface-audit.md:3012–3075,3180–3222`: DEVTOOLS-JUMP-0 selects inspection distinct from realization; .1 explicitly excludes inspection contribution and dependency, while unrelated scrub may persist. This history supports the tests above, not a new structural adoption inverse.
- `docs/audits/2026-10-17-incumbent-readiness/link-equal-write-boundary/README.md:36` and `link-equal-adoption/REVIEW.md:9–11`: owner selected scalar displayed99/ordinary7 adoption with rollback physical+publication7. Existing-entity field extension addresses ordinary existing rows; this decision does not explicitly choose absent lifetime creation/removal semantics.
- `docs/audits/2026-10-17-incumbent-readiness/semantic-transition-plan/README.md:146–150,192 onward`: the authorized plan explicitly keeps inspection-created/removed-lifetime transaction compensation conditional on governing evidence; minimal egress alone is not that rule.

History checked: `git log -- packages/kernel/src/lib/entity-inspection-egress.spec.ts` identifies introduction in `dbf958adb7462858cef65c3408889f115ee2a622` (v15 mostly completel); no later change in that file supplies the missing transaction assertions. This is a scoped search, not proof no decision exists anywhere.

## Small discriminating cases to specify before asserting

### C1: field transaction adopts inspection-created lifetime

```ts
// ordinary rows=[A], native rows=[A]
inspection(() => rows.addOne(B)); // native=[A,B], ordinary=[A]
const heldB = rows.byIdOrFail(B.id);
const p = tree.transact(() => heldB.name('authored-B'));
p.inspect();
p.rollback();
```

Two materially different possibilities need owner interpretation: rollback removes B physically because the operation's necessary ordinary existence is rejected, or rollback returns B to inspection-only presence (with appropriate inspected payload) while removing its ordinary eligibility. Existing egress tests distinguish neither. Required shared safety assertions already known: no B may remain ordinarily adopted by rejected work; no dangling capture; held B must never retarget a different lifetime; repeated rollback terminal behavior coherent. The physical `ids()/heldB()` answer and what baseline payload/field scope to restore need the rule.

### C2: transaction fills inspected vacancy with a new lifetime

```ts
const oldA = rows.byIdOrFail('a'); // ordinary+native old A
inspection(() => rows.removeOne('a')); // ordinary old A; native absent
let newA;
const p = tree.transact(() => {
  rows.addOne({id:'a', name:'new'});
  newA = rows.byIdOrFail('a');
});
p.rollback();
```

Does compensation restore the old ordinary lifetime physically, or remove newA but retain the prior inspected vacancy physically while restoring old A only to ordinary eligibility? Egress A2 requires the added row be a new lifetime; it does not answer this inverse. Old/new held references must be checked independently, plus IDs, payloads, ordinary endpoint, inspection, retry and any lawful destination-conflict refusal. Do not manufacture an old lifetime or permit retargeting to satisfy a payload-only assertion.

### C3: authored removal of an inspection-created row

Inspection creates B; transaction removes B; rollback. Egress removal is ordinary-value-neutral, but physical removal occurred. Is rollback a terminal no-op leaving B absent, or does the contribution retain enough physical-only obligation to restore B inspection-only? This exposes whether a physically effective but ordinary-neutral action is still rollback-owned. Existing value-neutral send assertion alone is insufficient.

For each case use no-Link native control and one/two-Link controls, confirm and reject separately, unrelated inspection siblings, same-key independent replacement, and failure/retry. Prewrite *characterization* outputs first; do not select expected physical result by whatever current implementation produces. No broader runtime redesign is implied by these tests.

## Decision form if execution reaches this boundary

A single coherent decision should specify whether rejection restores the participating ordinary topology physically for the authored footprint, or restores the pre-operation physical topology while undoing ordinary adoption separately. Clarify C3 physical-only contribution and C2 old-lifetime restoration rather than deciding only C1 by value analogy. Either direction must preserve minimal egress, lifetime isolation, useful retry/refusal and no global inspection reset. This report supplies options, not a preferred semantic answer.
