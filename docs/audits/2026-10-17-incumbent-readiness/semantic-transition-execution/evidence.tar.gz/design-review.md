# Independent slice1 notification/consumer design review

Read-only against actual kernel consumers. No code edits/tests and no new semantic decision. Proposed `design.md` ordinary-at-enqueue / physical-at-delivery split is **incomplete as written**, not a demonstrated impossibility of the single-protocol approach.

## Blocking consumer inventory

Paths below relative to `packages/kernel/src/` in the readiness worktree.

1. `enhancers/transactions/transactions.ts:3160–3215` is indeed an enqueue chronology consumer. It runs captureEffects from entry.newValue/oldValue and strips payloads afterward. Ordinary evidence here repairs the cited equal-display chronology problem, with origin/participation filters retained.
2. **Delivery still captures authority:** same file3224 installs collection notifier subscription. At3288–3320 realized next/prev builds later-dependency effects;3330–3355 captures pending/ordinary authored effects. Keeping physical tuples here can recapture a different contribution from the prepared terminal/chronology evidence. A prepared terminal is not proof these delivery consumers became irrelevant.
3. **Restoration delivery also interprets truth:** `enhancers/restoration/restoration.ts:4752` installs subscription;4804 captures historical effects from next/prev. Realized truth handling at4877 onward restores superseded row truth for compensation or records external truth. These are not physical observer-only callbacks.
4. **Queued read-side safety bypasses enqueue and delivery:** transactions3563 `readQueuedLaterEffects` reads PendingEntry old/new and subjectFieldKeys before flush. restoration3752 `readQueuedExternalAuthority` does the same to decide undo authority without executing observers. If queued fields retain only P, O-at-enqueue does not protect these paths.
5. **Another enqueue consumer exists:** restoration4553 records pending footprints from enqueue next/prev; migrate/test it with transaction chronology, not only the latter.
6. **Link consumes delivery, not observeEnqueue:** `lib/link.ts:610–633` entity field/row projection;650–680 nested/collection egress. `lib/internals/entity-egress-projection.ts:39–59` uses full row for null footprint or selectively copies declared fields; unknown footprint cannot authorize whole-row adoption. Physical next plus exact authored keys can suffice for a partial explicit write, because those authored values agree, but that is a proved invariant to establish. Derive/whole replacement/realization/equal adoption require separate coverage. Link must not reconstruct ordinary eligibility from physical equality-derived empty fields, or from untouched inspected siblings.

## Required design refinement within one protocol

Keep the prepared evidence attached to the existing pending entry and delivered operation, not only substituted into the enqueue snapshot. Explicitly select O in all existing capture/dependency/history consumers above; preserve P for native physical observer semantics/taps. A typed optional internal argument or existing-operation payload extension can do this without a second notification entrypoint. The design must name how absence of evidence falls back for unmigrated writers, rather than silently treating every delivery as O or P.

`lib/path-notifier.ts:774` coalesces entries and footprints; old O must remain first semantic-before and O-after must remain latest participating result under the established causal-boundary rules at750–772. Physical and ordinary equality cannot share one discard decision. Atflush498–507 net-equal entries skip delivery: authority-only adoption still needs existing authority consumers and Link responsibility handling while retaining ordinary user value-notification suppression. The candidate's private equal-responsibility route is a prerequisite to audit, not evidence that native transaction/restoration subscribers automatically see correct O.

`readPending()`566 copies pending entries: include immutable evidence and correct semantic footprint there. Keep physical projections separate, and release operation evidence on drain as already designed. Do not return a live mutable transition object whose fields change after chronology/queued checks.

## Minimal discriminators before implementation acceptance

- Same displayed adoption with pending transaction: p.inspect, rollback, and same-turn queued later-effect checks agree; run both before and after notifier flush.
- Ordinary7/m1 -> inspection99/m88 -> partial n99: capture/inspect/Link adopt n only; untouched m remains nonparticipating; rollback n7 does not promote m88.
- Equivalent update(v=>v), replaceOne, updateMany, upsert existing and setAll replacement: explicit unknown/null/partial footprint handling cannot silently erase ordinary changes merely because physical values match.
- Restoration historical capture and queued external-authority checks before flush agree with postflush checks; later realized acquisition equal to display discharges baseline and protects actual new truth.
- ABA physical net-equality with changed responsibility: native value listeners retain suppression, authoritative checks and Link receive current evidence without forced user emissions.

Structural inspection-created/removed compensation remains the separately documented unresolved case; none of this review selects its answer.

## Disposition

The single notification protocol can carry multiple named views in principle. The proposed routing rule alone cannot preserve all current consumers because delivery and pending-queue readers are load-bearing authority paths. Refine the consumer selection and merge/discard contract before runtime implementation; do not repair this by changing all prev arguments to ordinary values or by adding a parallel event bus.
