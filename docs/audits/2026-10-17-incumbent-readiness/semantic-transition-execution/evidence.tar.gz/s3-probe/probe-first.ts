import {signalTree,entityMap,transactions,restoration} from '../candidate/packages/kernel/src/index';
import {withWriteContext} from '../candidate/packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve()};
const results=[];
for(const mode of ['rollback','undo']){
 const tree=signalTree({rows:entityMap<{id:string;n:number;m:number},string>({selectId:r=>r.id})},{enhancers:[transactions(),restoration()]});const rows=tree.$.rows;
 rows.addOne({id:'a',n:7,m:0});await tick();
 withWriteContext({participation:'inspection'},()=>rows.updateOne('a',{n:99}));await tick();
 const start=(globalThis as any).__s3.length;
 try{
 if(mode==='rollback'){const p=tree.transact(()=>rows.updateOne('a',{m:4}));p.rollback()}
 else {tree.undoable(()=>rows.updateOne('a',{m:4}));tree.undo()}
 const after=rows.byIdOrFail('a')();const routes=(globalThis as any).__s3.slice(start);
 const q=tree.transact(()=>rows.updateOne('a',{n:99}));const inspection=q.inspect();q.rollback();
 results.push({mode,after,routes,inspection,final:rows.byIdOrFail('a')()});
 }catch(e){results.push({mode,error:String(e),routes:(globalThis as any).__s3.slice(start)})}finally{tree.destroy()}
}
console.log(JSON.stringify(results,null,2));
