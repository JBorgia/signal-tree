# S3 footprint counterexample

Candidate untouched. The private loader adds only prepare/install trace capture. No policy changes or new runtime fix.

Ordinary row `{id:a,n:7,m:0}`; inspect `n=99`; mixed transaction writes scalar `x=1` and row `m=4`; rollback. Adapter enters `preparePointValues` once, installs once. Its physical row target copies inspected `n=99`, changes only `m` to zero. However the full-row transition declares ordinary-after n99 and removes divergence. A later transaction writing n99 has empty inspection changes; rollback leaves99 instead of ordinary7.

Control without the scalar selects another rollback route (zero S3 visits) and preserves later adoption responsibility: rollback restores7. The first undo probe had invalid `tree.undoable` harness; retained in first.json and probe-first.ts, not counted. Corrected undo probe has no S3 visits and is not an S3 qualification.

## First divergence

`tree-realization-adapter.ts` constructs whole target from physical snapshot and applies effect paths; it sends only subject/key/value, no field footprint. `preparePointValues` calls prepareValueTransition with no fields, which means full authored replacement. This incorrectly promotes untouched inspected sibling. Publish additionally passes plain realized metadata, with no prepared transition evidence. Thus one shared-result consumer migration has an exercised coverage hole.

No runtime fix attempted. S3 was explicitly changed in slice1, so report under already-covered-path recurrence condition rather than silently patching caller.

## Replay

Use Node24.15.0:
```sh
node /private/tmp/semantic-transition-execution/s3-probe/build.mjs
node /private/tmp/semantic-transition-execution/s3-probe/bundle.mjs > /private/tmp/semantic-transition-execution/s3-probe/mixed.json
node /private/tmp/semantic-transition-execution/s3-probe/assert.mjs
```
Last command fails expected7 actual99. identities.json records candidate inputs.
