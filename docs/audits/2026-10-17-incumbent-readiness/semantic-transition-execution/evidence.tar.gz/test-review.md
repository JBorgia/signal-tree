# Independent prewritten-test review

Read-only review against f80645c8 and archived `evidence/original-a1/witness.ts`. No runtime result inferred and no tests edited.

## Verdict

The seven test cases stay within approved existing-lifetime value adoption. No test selects compensation for an inspection-created or inspection-removed entity lifetime. Partial adoption of `n` must not author sibling `m`; retaining physically inspected `m=88` after rollback is consistent with the explicitly scoped authored footprint. The ordinary-equal no-op control is correctly separate from displayed-equal/authority-different adoption.

Two evidence qualifications:

1. The new A1 fixture is not a verbatim replay: archived mixed-frame and mixed-throw inspect through held `a.n(99)`/`b.n(88)` handles; new tests inspect through `updateOne`. The expected2 chronology facts, restored7/8 rows and leakage check match, but both the archived exact replay and this sibling-route regression should run. Do not describe only the new fixture as unchanged A1.
2. `sent.some(speculative)` being false establishes no leakage but permits no publication at all. Keep this unchanged assertion and supplement with a useful final ordinary endpoint value after `connection.settled()`. Likewise capture count2 plus rollback state already prevents a vacuous transaction success, but does not establish final outbound convergence.

The mixed-throw test strengthens the original failure flag with an Error expectation. If exact thrown identity is claimed, use explicit caught-object identity; `toThrow(error)` alone should not be reported as identity proof. This is a measurement limitation, not a reason to change the contract.

## Minimal additional controls under existing rules

- Preparation reentry: an incoming row getter makes one ordinary field write to an existing lifetime. The outer prepared write must not overwrite that newer write; if the existing revision guard refuses the outer operation, assert its untouched footprint and the nested write's actual ownership. Run outside `transact` first so automatic abort does not confuse independent nested state with a callback-owned write. Reuse the existing reentry refusal contract; do not prescribe a new error class.
- Failed settlement then useful retry: p adopts inspected `a.n=99` over ordinary7, q later writes `a.n=100`. Older rollback must use the existing overlap refusal behavior atomically with both authorities retained; reject q then retry p and require7 plus truthful inspection. Do not require arbitrary-order surgical success.
- Synchronous publication reentry after rollback: an existing observer authors a later value during restored-value delivery. Assert that later value survives, with ordinary value notification suppression preserved for authority-only equal adoption. No promise of fresh application-owned native computed values inside grouped writes.
- Repeated existing-lifetime writes within one callback: adopt99 then write100; inspection must retain ordinary before7 and latest after100, rollback7. This directly tests staged folding rather than only one transition per lifetime.

These are bounded discriminators of the approved common transition mechanism. They do not require choosing structural inspection compensation semantics. The separate structural characterization must remain non-acceptance evidence until a governing rule or owner decision exists.
