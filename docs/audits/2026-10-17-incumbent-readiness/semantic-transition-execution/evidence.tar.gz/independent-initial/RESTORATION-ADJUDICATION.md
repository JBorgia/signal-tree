# Restoration first-failure adjudication

Read-only; no runtime edits. Reviewed raw `slice1-restoration-first.log` and test at `entity-semantic-transition.spec.ts:118–134`.

The two initial failures are not established runtime regressions or a shared-migration recurrence. The harness performs an ordinary undesignated update and expects undo authority. Existing contract requires explicit designation:

- `packages/kernel/src/lib/entity-update-one-equivalence.spec.ts:137–144` wraps the row update in `undoable`, waits for turn settlement, then undo restores prior value.
- `packages/kernel/README.md:212–215`: undoable designates the synchronous authored turn; history is recorded when that turn settles; undo should occur in a later action, not immediately in the same synchronous function.
- `packages/kernel/src/enhancers/restoration/restoration.ts:3978`: `isTurnEligible = designated`;4456 onward declines an undesignated pending turn. This precedes selection of any realization target, so these failures do not identify S4 or another target installer.

Therefore preserve original two failures as test-contract mismatches. Add a designated, settled test with unchanged substantive expectation (ordinary7 -> inspection99 -> undoable ordinary99 -> settle -> undo7 -> redo99). That tests the intended existing-lifetime capture/history consumer. Treat immediate same-turn undo separately as characterization unless a specific stronger existing contract is found. A corrected designated-and-settled failure would require fresh causal tracing; do not pre-classify it as recurrence merely from these initial results.

Corrected-run disposition pending parent's execution; no unrun passing claim.

## Verified corrected disposition

Inspected corrected source and `evidence/slice1-restoration-designated.log`:12/12 Nx tests pass, including designation via undoable, awaited settlement and unchanged undo7/redo99 assertions. Parent preserved the original13-test source as `evidence/restoration-undesignated-tests.ts` and first failure log. Same-turn false variant remains unclaimed under the documented later-action contract. No runtime edit was needed for this correction. These initial failures do not activate the recurrence stop; the newly valid settled restoration case supports continued bounded qualification.
