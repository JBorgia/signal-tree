import {createRequire} from 'node:module';
const {build}=createRequire('/private/tmp/semantic-transition-execution/candidate/package.json')('esbuild');
await build({entryPoints:['/private/tmp/semantic-transition-review/witness.ts'],outfile:'/private/tmp/semantic-transition-review/bundle.mjs',bundle:true,platform:'node',format:'esm',target:'node24'});
