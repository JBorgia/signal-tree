# Independent slice1 consumer review

Read-only review of candidate `/private/tmp/semantic-transition-execution/candidate`. Exact reviewed six-file hashes are in `SHA256SUMS` beside this report; saved executable probe bundle is immutable evidence of what executed. Other agents may subsequently change prerequisite helpers. No production/candidate files edited, no broad suites.

## Findings

No new reproduced correctness blocker in the reviewed existing-lifetime slice. The specific omitted-consumer issue from design-review.md is addressed in source:

- Entity transition evidence is carried in metadata through the existing notify operation, queue and handler protocol.
- Transaction enqueue chronology, delivery capture and realized dependency consumers select ordinary before/after.
- Restoration enqueue pending footprints, delivery historical/external truth consumers select ordinary before/after.
- Both transaction queued-later-effects and restoration queued-external-authority select ordinary entries from readPending.
- Native handler tuple remains physical. Semantic changed-field keys are derived from ordinary pairs; explicit authored field footprint remains distinct.
- Same-subject coalescing keeps first ordinary/physical before and latest after; causal-mode boundaries remain. Ordinary changed fields prevent authority-changing equal physical tuples from being discarded as no-ops.

This is source verification, not proof of every merge/reentry interleaving. Mixed structural writer migration and whole-target realization are later slices; no acceptance claim made for them.

## Independent probe

Created `witness.ts`, `build.mjs`, `bundle.mjs`, `first.log` in this directory. Node24.15.0, direct esbuild source bundle, not Nx/package qualification.

Prewritten discriminator: ordinary `{id:a,n:7}` -> inspection `{n:99,m:88}` -> transaction authors n99 -> rollback; then a separate transaction explicitly authors m88 -> rollback. The second transaction must still see m as adoption (not a genuine ordinary no-op), and its rollback must remove m's ordinary absence while preserving n7.

Result passes:
- First inspection lists n only.
- First rollback physical row remains `{id:a,n:7,m:88}`.
- Second inspection lists m.
- Second rollback physical row becomes `{id:a,n:7}`.

This tests retention of untouched inspected sibling responsibility across an earlier partial rollback, extending the initial11 controls. It disproves the suspected simple failure that every partial rollback unconditionally discards all sibling divergence on this exercised path. It does not establish every realization entry point.

Replay:

```sh
/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node /private/tmp/semantic-transition-review/bundle.mjs
```

## Outstanding coverage, not invented failures

`preparePointValues` installs a prepared full-row transition and publishes physical tuples without attaching that transition; its input rows are constructed by the realization adapter. Verify this route's footprint/baseline discharge directly when qualifying minimal S3: the passing public probe does not prove it exercised that exact route. `installPreparedTargetValues` also has separate baseline disposition, appropriately remaining an S4/later-slice concern. Do not count them complete by analogy to public rollback.

Raw initial11 output was inspected, not independently rerun. Known prerequisite type diagnostics remain separately reported by parent. No final framework, performance, heap, artifact or production acceptance follows from this review.
