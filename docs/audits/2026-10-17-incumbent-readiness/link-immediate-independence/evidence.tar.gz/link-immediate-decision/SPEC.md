# Fixed immediate-independence decision

Source d7c6da825e76a1e8ff82a9fa589f753ea76d4801; unchanged private responsibility
helper and transformations from preceding experiment. No eligibility modification.

Before execution: same tree x=0,y=0; Link y; pending transaction writes x=7.
Four separate fresh-process scenarios:
1. Direct independent y(7): expect [7] while x transaction remains pending.
2. Direct read/copy y(x()): expect [] while source pending.
3. x subscriber writes literal y(7): independent payload, expect [7] while pending.
4. Same subscriber reads/copies y(x()): expect [] while source pending.
After confirmation all scenarios expect [7], proving delivery performs useful work.
A callback's invocation may depend on x even when literal payload doesn't: scenario3
is diagnostic only if trigger dependency makes its independence underdetermined.
Scenario1 is the decisive unconditional progress requirement.

Capture current write context, exact receipt facts, pending status and endpoint values.
Normalize only identity counters if comparing across processes; preserve raw output.
If independent/dependent writes share supplied eligibility evidence, stop without
optimizing scans/retention or adding another policy. This tests this observation
mechanism, not the impossibility of richer read/dependency tracking.
