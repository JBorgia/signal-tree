import {signalTree,transactions,link} from './packages/kernel/src/index';
import {getPathNotifier} from './packages/kernel/src/lib/path-notifier';
import {getActiveWriteContext} from './packages/kernel/src/lib/write-context';
import {transactionLifecycleReader} from './packages/kernel/src/lib/internals/transaction-lifecycle-view';
import * as research from 'research-private';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){
 const scenario=process.env.SCENARIO??'direct';
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});
 const sent:number[]=[];const contexts:unknown[]=[];
 const out=link(t.$.y,{set:v=>{sent.push(v);}});
 let off=()=>{};
 if(scenario.startsWith('callback'))off=getPathNotifier().subscribe('x',v=>{
   if(v!==7)return;
   contexts.push({active:getActiveWriteContext()??null});
   t.$.y(scenario==='callback-copy'?t.$.x():7);
 });
 const p=t.transact(()=>t.$.x(7));
 if(!scenario.startsWith('callback')){contexts.push({active:getActiveWriteContext()??null});t.$.y(scenario==='copy'?t.$.x():7);}
 await tick();
 const pending={pendingCount:transactionLifecycleReader(t)!.read().pending.length,sent:[...sent],receipts:[...research.receipts]};
 const expected=scenario==='direct'||scenario==='callback-literal'?[7]:[];
 p.confirm();await tick();
 const result={scenario,contexts,pending,checks:[
 {name:'transaction remains pending',actual:pending.pendingCount,expected:1,pass:pending.pendingCount===1},
 {name:'immediate behavior',actual:pending.sent,expected,pass:JSON.stringify(pending.sent)===JSON.stringify(expected)},
 {name:'after confirmation useful delivery',actual:[...sent],expected:[7],pass:JSON.stringify(sent)==='[7]'}]};
 off();out.dispose();t.destroy();await tick();return result;
}
