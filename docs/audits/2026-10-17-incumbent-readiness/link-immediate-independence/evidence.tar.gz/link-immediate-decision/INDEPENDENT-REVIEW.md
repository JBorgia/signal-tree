# Independent immediate-independence review

Scope: private scalar/default-batched observation mechanism at repository `d7c6da825e76a1e8ff82a9fa589f753ea76d4801`; production behavior unchanged. Reviewed `private.ts`, loader transformations, PathNotifier enqueue/delivery, contributor contracts and scoped architecture protocol. No production edits or optimization experiment.

## Premises and question

The preserved report states: “A genuinely independent write authored during existing pending owners still waits.” It also states: “Cross-tree conservatism snapshots pending owners across registered trees, namespaced by tree and transaction identity.” Source: `docs/audits/2026-10-17-incumbent-readiness/link-responsibility-observation/README.md` at the revision above.

Owner request requires an ordinary independent write to progress while an already-open owner remains pending, with a dependent reactive copy held. Approved surviving-write semantics applies after the rejected owner has settled; it does not certify independence from owners that remain pending.

## Source findings

`annotate()` observes write metadata, destination owner/position, authored participation, and payload. It snapshots every registered tree's pending transactions. It does not intercept scalar reads, record consumed source revisions, or connect a callback's read set to its outgoing write. `unknown` differentiates participation/origin/valid explicit transaction attribution; it is not a dependency-read predicate. `allowed()` requires every captured owner to confirm unless the fact came from the separately identified authoritative incoming acquisition.

For an ordinary authored destination write while transaction P remains pending, a literal 7 and a copied speculative 7 can have identical eligibility inputs: ordinary participation, absent transaction attribution/origin, payload 7, and blocker P. Revision identity differs, but is only recency, not proof of source independence. Exact payload equality likewise cannot provide causality.

Responsibility completion and Link refresh preserve the payload/ticket pairing. Those mechanisms improve ticket delivery and ABA handling; they add no source-dependency information. A more efficient pending-owner index or cleanup cannot create that missing information.

PathNotifier delivers subscribers with the originating notification metadata as callback arguments, but invokes them under `withoutWriteObservationScopes`. That gives the subscriber access to the triggering event; the experimental helper does not consume a callback-to-write relation. Even blanket tagging of subscriber callbacks would need separate supported scope: callbacks can write literals, read other sources, or execute later. No such mechanism is selected here.

## Execution

Awaiting the root's paired replay before recording executed verdicts. Source inspection alone predicts both direct and copied ordinary writes remain held while P remains pending. This prediction is limited to the unchanged experimental mechanism and is not an impossibility proof for automatic dependency tracking in a different supported execution model.

## Executed result and disposition

Independently executed the fixed `bundle.mjs` with Node 24.15.0 in separate fresh processes under `SCENARIO=direct` and `SCENARIO=callback-copy`. Results are byte-identical to root's saved `direct.json` and `callback-copy.json`. My copies are `/private/tmp/link-immediate-review-direct.json` and `/private/tmp/link-immediate-review-copy.json`.

Both scenarios retain one pending owner and send nothing. Both then send exactly `[7]` after confirmation. The direct ordinary `y(7)` case fails the prewritten immediate-progress expectation; the reactive `y(x())` case satisfies safety. The two destination receipts expose exactly the same fact: revision 2, owner 1, position 3, clean false, unknown false, blocker `{owner:1,id:1}`, no transaction attribution or origin. Active write context is null in both. The four root outputs also show identical facts for direct copy and callback literal; I inspected those outputs but independently executed only the decisive direct/callback-copy pair.

The callback-literal expectation is not an independently established contract failure: its invocation depends on speculative x even if the payload is a constant. Root appropriately marked it diagnostic before execution. Neither this ambiguity nor the earlier corrected harness status/reader errors affects the decisive direct-write failure.

**Disposition:** this unchanged observation mechanism cannot satisfy the required immediate independence. It refreshes ownership evidence reliably but obtains only a conservative possible-owner set, not evidence that the destination consumed no speculative source. Releasing the direct receipt from its current facts would release the indistinguishable copy as well. Stop optimizing or expanding this mechanism on this evidence. Preserve its bounded ABA and delivery benefits; production hold remains intact.

This is not an impossibility result for a different mechanism with observable read/dependency boundaries. The exact missing information is a trustworthy association between a newly authored destination revision and the source revisions/owner dependencies it consumed, or equivalent trustworthy evidence that it consumed none. Callback entry alone cannot establish that across all writes. No API or architecture selection follows from this finding.

## Historical 32/34 expectations

Keep both original assertions unchanged in the evidence. Their fixture expects permanent holding of an ordinary y=42 revision after all captured owners confirm. Under the experimental eligibility rule and owner-approved surviving-write distinction, that old expectation is not a safety requirement: no possible captured owner remains pending or rejected, and no continuing speculative source is demonstrated. The reconciled proposed acceptance is send 42 and resolve the waiter after confirmation, while retaining holds for still-pending, rejected, abandoned or unknown evidence. This is a documented oracle reconciliation for the bounded experiment, not evidence that production already promises automatic immediate independence or authorization to erase historical results.

Cross-tree scope remains one fully instrumented runtime. No indexing, retention, framework, public API, production mutation or broad qualification claim is made here.
