import {readFileSync} from 'node:fs';import assert from 'node:assert/strict';
const load=n=>JSON.parse(readFileSync(new URL(n,import.meta.url)));let checks=0;
for(const [file,research] of [['baseline-traces.json',false],['traces.json',true]]){
 const rows=load(file);const at=(s,p)=>rows.find(r=>r.scenario===s&&r.phase===p);
 for(const s of ['direct-confirm','reactive-confirm']){assert.deepEqual(at(s,'confirmed').sends,research?[]:[7]);checks++;}
 assert.deepEqual(at('two-confirm','p-confirmed-q-pending').sends,[]);checks++;
 assert.deepEqual(at('two-confirm','q-terminal').sends,research?[]:[9]);checks++;
 assert.deepEqual(at('two-reject','q-terminal').sends,research?[]:[9]);checks++;
 const a=at('after-reject-literal','written-no-pending'),b=at('after-reject-captured','written-no-pending');
 assert.equal(a.pending,false);assert.equal(b.pending,false);checks+=2;
 assert.deepEqual(a.events,b.events);checks++;
 assert.deepEqual(a.sends,b.sends);checks++;
 assert.deepEqual(at('authoritative','pending').sends,research?[42]:[]);checks++;
}
console.log(JSON.stringify({checks,meaning:'observational comparisons, not eligibility acceptance'}));
