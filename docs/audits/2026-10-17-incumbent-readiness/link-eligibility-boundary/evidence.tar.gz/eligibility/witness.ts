import {signalTree,transactions,link} from './packages/kernel/src/index';
import {getPathNotifier} from './packages/kernel/src/lib/path-notifier';
import {hasOpenCommitScope} from './packages/kernel/src/lib/internals/commit-consequence';
import * as research from 'research-private';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
export async function run(){
 research.mode(true);const rows:unknown[]=[];
 for(const scenario of ['direct-confirm','reactive-confirm','two-confirm','two-reject','overwrite-literal','overwrite-captured','after-reject-literal','after-reject-captured','authoritative']){
  const t=signalTree({x:0,y:0,z:0},{enhancers:[transactions()]});const sends:number[]=[];const events:unknown[]=[];
  const out=link(t.$.y,{set:v=>{sends.push(v);}});let incoming!:(v:number)=>void;
  const input=link(t.$.y,{subscribe:f=>{incoming=f;return ()=>{};}});
  const off=getPathNotifier().subscribe('y',(v,prev,_p,_o,_origin,_sub,_pos,meta)=>{
   const primitives=Object.fromEntries(Object.entries(meta??{}).filter(([k,v])=>k!=='ownerId'&&(v===null||['string','number','boolean','undefined'].includes(typeof v))));
   events.push({value:v,previous:prev,pending:hasOpenCommitScope(t.$),metadata:primitives,metadataKeys:Object.keys(meta??{}).sort()});
  });
  let reactive=()=>{};if(scenario==='reactive-confirm')reactive=getPathNotifier().subscribe('x',v=>{if(v===7)t.$.y(v as number);});
  const trace=(phase:string)=>rows.push({scenario,phase,state:t.$(),pending:hasOpenCommitScope(t.$),sends:[...sends],events:[...events]});
  try{
   const p=t.transact(()=>t.$.x(7));await tick();const captured=t.$.x();
   if(scenario.startsWith('two-')){
    const q=t.transact(()=>t.$.z(9));t.$.y(t.$.z());await tick();trace('both-pending');p.confirm();await tick();trace('p-confirmed-q-pending');
    if(scenario==='two-confirm')q.confirm();else q.rollback();await tick();trace('q-terminal');
   }else if(scenario.startsWith('after-reject')){
    p.rollback();await tick();trace('rejected-before-write');t.$.y(scenario.endsWith('literal')?7:captured);await tick();trace('written-no-pending');
   }else {
    if(scenario==='authoritative')incoming(42);
    else if(scenario!=='reactive-confirm')t.$.y(scenario==='direct-confirm'?7:3);
    await tick();trace('pending');
    if(scenario.startsWith('overwrite')){t.$.y(scenario.endsWith('literal')?7:captured);await tick();trace('overwrite-pending');}
    p.confirm();await tick();trace('confirmed');
   }
  }finally{reactive();off();out.dispose();input.dispose();t.destroy();await tick();}
 }
 return rows;
}
