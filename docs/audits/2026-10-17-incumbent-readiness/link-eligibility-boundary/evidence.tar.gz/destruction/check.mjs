import {readFileSync} from 'node:fs';import assert from 'node:assert/strict';
let checks=0;for(const name of ['baseline-traces.json','traces.json']){
 const rows=JSON.parse(readFileSync(new URL(name,import.meta.url)));assert.equal(rows.length,6);checks++;
 for(const row of rows){const after=row.stages.find(x=>x.phase==='after-destruction');const final=row.stages.at(-1);
  assert.deepEqual(after.sent,row.phase==='inflight'||row.action==='tree'&&row.phase==='queued'?[42]:[]);checks++;
  assert.equal(after.settled,row.action==='connection'||row.phase==='queued');checks++;
  assert.equal(final.settled,true);checks++;
  if(row.phase==='inflight'){assert.equal(row.stages.find(x=>x.phase==='after-endpoint-completion').settled,true);checks++;}
 }
}console.log(JSON.stringify({checks,meaning:'observed lifetime distinction, not destruction acceptance'},null,2));
