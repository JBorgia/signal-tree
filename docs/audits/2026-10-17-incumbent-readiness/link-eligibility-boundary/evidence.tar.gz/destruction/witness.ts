import {signalTree, transactions, link} from './packages/kernel/src/index';
import * as research from 'research-private';
const tick=async()=>{for(let n=0;n<100;n++)await Promise.resolve();};
export async function run(){
 research.mode(true);const results:unknown[]=[];
 for(const action of ['tree','connection'])for(const phase of ['queued','held','inflight']){
  const t=signalTree({x:0,y:0},{enhancers:[transactions()]});
  const sent:number[]=[];let release=()=>{};let incoming!:(v:number)=>void;let unsubscribed=0;
  const c=link(t.$.y,{set:v=>{sent.push(v);if(phase==='inflight')return new Promise<void>(r=>release=r);}});
  const inbound=link(t.$.y,{subscribe:cb=>{incoming=cb;return ()=>{unsubscribed++};}});
  const pending=phase==='held'?t.transact(()=>t.$.x(7)):undefined;
  if(phase==='held')t.$.y(42);else incoming(42);
  if(phase!=='queued')await tick();
  let settled=false;void c.settled().then(()=>{settled=true});
  const stages:unknown[]=[];stages.push({phase:'before',sent:[...sent],settled,unsubscribed});
  if(action==='tree')t.destroy();else c.dispose();await tick();
  stages.push({phase:'after-destruction',sent:[...sent],settled,unsubscribed,destroyed:t.destroyed()});
  if(phase==='inflight'){release();await tick();stages.push({phase:'after-endpoint-completion',sent:[...sent],settled});}
  c.dispose();await tick();stages.push({phase:'after-explicit-disposal',sent:[...sent],settled});
  inbound.dispose();t.destroy();results.push({action,phase,stages});
 }
 return results;
}
