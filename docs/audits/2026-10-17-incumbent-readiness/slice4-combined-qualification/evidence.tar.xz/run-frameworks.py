import pathlib,subprocess,os,json,time,hashlib
root=pathlib.Path('/private/tmp/slice4-qualification/candidate');out=root.parent/'frameworks';env=os.environ.copy();env.update(PATH='/private/tmp/derive-placement-successor/toolchain:'+env['PATH'],COREPACK_ENABLE_NETWORK='0',NX_DAEMON='false',NX_ISOLATE_PLUGINS='false')
patterns={
'angular':['transaction-realization','restoration-reactivity','e-active-selection','designated-collection-omission','plain-member-absence-observation','link-native-address','audit-observation-lifecycle','declared-publication-composition'],
'vue':['transaction-realization','settlement-publication','entity-projection-publication','prepared-selection-publication','entity-selection-lifetime','designated-collection-omission','plain-member-absence-observation','link-native-address','audit-observation-lifecycle','declared-publication-composition'],
'solid':['transaction-realization','native-publication-error-boundary','designated-collection-omission','plain-member-absence-observation','link-native-address','audit-observation','declared-publication-composition'],
'react':['transaction-realization','pending-turn-realization','designated-collection-omission','plain-member-absence-observation','link-native-address','ownership.spec','use-signal-tree.spec','declared-publication-composition']}
a={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'packages').rglob('*')) if p.suffix in ('.ts','.tsx') and p.is_file()};(out/'SOURCE.json').write_text(json.dumps(a,indent=2)+'\n')
for fw,paths in patterns.items():
 cmd=['corepack','pnpm','exec','nx','test',fw,*paths,'--skip-nx-cache'];(out/f'{fw}.COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n');start=time.time()
 with (out/f'{fw}.FIRST.log').open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/f'{fw}.EXIT.json').write_text(json.dumps({'exit':r.returncode,'seconds':time.time()-start})+'\n');print(fw,r.returncode,flush=True)
