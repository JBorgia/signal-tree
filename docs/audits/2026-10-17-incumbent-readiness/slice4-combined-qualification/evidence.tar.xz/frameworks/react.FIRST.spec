import { expect, it } from 'vitest';
import { entityMap, link, signalTree, transactions } from '../index';
import { withWriteContext } from '../../../kernel/src/lib/write-context';

// Private experiment capability check; this does not add a facade/API export.
type DeclaredConnection = ReturnType<typeof link> & {
  declare(input: unknown, work: () => unknown): { read(): { state: string } };
};
function declared(connection: ReturnType<typeof link>): DeclaredConnection {
  if (typeof Reflect.get(connection, 'declare') !== 'function')
    throw new Error('Experimental declaration path is unavailable');
  return connection as DeclaredConnection;
}
const drain = async () => {
  for (let i = 0; i < 120; i++) await Promise.resolve();
};

it('declared scalar independence progresses while two owners remain open; dependency waits', async () => {
  const tree = signalTree({ x: 0, y: 0, z: 0, other: 0 }, { enhancers: [transactions()] });
  const sent: unknown[] = [], dependent: unknown[] = [];
  const c = declared(link(tree.$.y, { set: value => { sent.push(value); } }));
  const d = declared(link(tree.$.z, { set: value => { dependent.push(value); } }));
  try {
    const p = tree.transact(() => { tree.$.x(7); });
    const q = tree.transact(() => { tree.$.other(3); });
    const receipt = c.declare({ kind: 'independent' }, () => { tree.$.y(8); });
    const held = d.declare({ kind: 'dependent', owners: [p] }, () => { tree.$.z(tree.$.x()); });
    await drain();
    expect(sent).toEqual([8]);
    expect(dependent).toEqual([]);
    expect(receipt.read().state).toBe('started');
    expect(held.read().state).toBe('held');
    p.confirm();
    await drain();
    expect(dependent).toEqual([7]);
    expect(held.read().state).toBe('started');
    expect(tree.$.other()).toBe(3);
    q.rollback();
    expect(tree.$.other()).toBe(0);
  } finally { c.dispose(); d.dispose(); tree.destroy(); }
});

it('declared entity inspection adoption publishes ordinary authority through the facade', async () => {
  const tree = signalTree({ x: 0, rows: entityMap<{id: string; n: number}, string>() }, { enhancers: [transactions()] });
  tree.$.rows.addOne({ id: 'a', n: 7 });
  await drain();
  const a = tree.$.rows.byIdOrFail('a');
  const sent: unknown[] = [];
  const c = declared(link(a.n, { set: value => { sent.push(value); } }));
  try {
    const p = tree.transact(() => { tree.$.x(7); });
    withWriteContext({ participation: 'inspection' }, () => { a.n(99); });
    await drain();
    expect(a.n()).toBe(99);
    expect(sent).toEqual([]);
    const receipt = c.declare({ kind: 'independent' }, () => { a.n(99); });
    await drain();
    expect(sent).toEqual([99]);
    expect(receipt.read().state).toBe('started');
    p.rollback();
    await drain();
    expect(a.n()).toBe(99);
    expect(sent).toEqual([99]);
  } finally { c.dispose(); tree.destroy(); }
});
