# Exact historical34 mapping

No rerun/rewrite. Extracted readiness docs/audits/2026-10-17-incumbent-readiness/link-owner-window/evidence.tar.gz to declarations/historical34. implementation/SHA256SUMS verifies successfully (VERIFY.log). Counted stored targeted-traces.json:34 assertions,32true,2false.

Exact identities:
- implementation/targeted.ts SHA2560e58d5db18c29e4390a0350a24c6355a18886cdead1e1c606e41df3064a2e1bf
- targeted-bundle.mjs a90ceb2e05e5b0a2e36e369945b4c8bc86e37a7277b14f9393a1cc251c8c033b
- targeted-traces.json763cf84620d5b1491acbcdee7f71ab007046619dff2e5c1b9d50be2738caafb8
- targeted.log75a32f7caca5da595c5a01ae00d43a7296633ebce2543a8f33dd08e4f2f2e0b3

Both reds originate targeted.ts43, scenario unknown-confirm: ordinaryy42 while owner pending; wait starts; p.confirm; drain. `unknown never cleansed` expects sends[] but storedactual[42]. `actual held after confirm` expects settledfalse but storedactualtrue. Same scenario produces two assertions; do not describe two independent runtime defects. All original source/expected/raw outputs unchanged.

Governing explicit approved reconciliation: readiness link-immediate-independence/README.md71–90 records owner instruction “Permanent holding after all relevant owners confirm should not remain a required behavior merely because an older test encoded it”. Correct experimental postcondition is sends[42], waiter completes after all captured relevant owners confirm. This does not infer independence while another unresolved owner remains; surviving ordinary write after rejection is separate rule. link-owner-window/REVIEW.md23 independently characterizes same2 as oracle differences, and link-native-boundaries/README.md18 preserves exact names/actuals.

Current executed declaration witness lifecycle/scalar.ts confirm scenario separately checks pendingheld[] then confirmationpublishes[99]. Its source/hash/bundle/results live replayed/lifecycle-scalar.inputs.json/.json. This is narrower differentpayload/currentadoption confirmation coverage, **not** a rerun of original34 or proof that all historical observation scenarios execute identically. Current141contractpasses cannot replace historical34 accounting. Exact original mapping above closes that archival identification; no34/34claim or editedassertion is made.

Closer current equivalents are original executed combined/focused-final/independent/witness.ts18 (`other eventually delivers` after confirming owner while a second connection had remained conservative) and20 (`no write cannot authorize prior value`, then ownerconfirm→`ordinary eventual delivery`[7]). Their inputs hashes/results are replayed/combined-focused-final-independent-witness.inputs.json/.json. They assert eventual value progression, not exact historical settled waiter outcome. Exact waiter confirmation is covered by original stored historical actual; no new equality claim added here.
