# Unchanged declaration and receipt replay

October25. Owned output directory only; candidate untouched. Runner copied from /private/tmp/link-fallback-successor/replay-controls.mjs with output directory and current candidate root remapped. Uses esbuild normal loader and only research-private→current private module resolution. No archived patch scripts, old projection loaders or bundle rewrites. Each emitted .inputs.json records witness SHA, bundle SHA and actual loaded-file hashes; IMPORT-AUDIT.json verifies loaded paths stay current candidate. entries.txt contains original ten plus six named A1–A3 extensions; five further named extensions recorded16–20-FIRST.log. All raw first results preserved.

Exact invocation per witness: `node /private/tmp/slice4-qualification/declarations/replay.mjs ENTRY`. Logs00–09 reproduce142 true boolean checks:141 contract checks plus one saved-input omission misuse. That demonstration's name explicitly says NOT safety pass; exclude it. No contract failures in original ten.

Named expansion: adoption/witness, adoption-root, final entities/aggregate/restoration/composition/root/projection/nested all execute with passing boolean checks. A1 adoption-review exits on removed private `EntityValueStore.authorityCount`; do not count aborted scenarios as passes or rewrite it. A2 extra-first records4passes/1red: reentrant write77 expected to survive failed transact but actual7. Original new oracle is preserved; same-callback owned write rollback may explain it, requiring explicit existing oracle-mismatch adjudication before classifying regression. No runtime repair or assertion change authorized here. Structural characterization scenarios without pass flags remain observations, not checks.

Historical32/34 remains preserved in preceding archive; selected combined/RESULT.md explicitly references approved postconfirmation reconciliation and does not revise its expectations. Current ten contract vector passes but must not be claimed to have rerun historical34 unchanged. Exact originating34 runner/result reconciliation is a remaining archival mapping item if full historical-verdict accounting is required.

## Fixed receipt collection

Inspected original receipt-graph-gc and dropped sources before rebuild:4cycles,16 event-loop-separated forcedGC, useful sends8x4, live tree positive control, retained receipts separate from dropped. gc-build.mjs resolves research-private to current source and records witness/input hashes. Explicit invocation (fresh process each, once):

 node --expose-gc --input-type=module -e "const{run}=await import('/private/tmp/slice4-qualification/declarations/gc/receipt-graph-gc.mjs');console.log(JSON.stringify(await run(),null,2));"
 node --expose-gc --input-type=module -e "const{run}=await import('/private/tmp/slice4-qualification/declarations/gc/receipt-graph-dropped-gc.mjs');console.log(JSON.stringify(await run(),null,2));"

RETAINED-FIRST and DROPPED-FIRST each20/20 collected, pass=true. Both useful sends and liveControl retained. No favorable repeat. This qualifies the sampled receipt graph under current source, not complete entityGC or process-memory acceptance. First18/20 marker-root evidence remains untouched elsewhere.

## Expanded red reconciliation

Exact pre-existing adjudication found in controls-original/adoption/RESULT.md27: `extra-vetted.ts` preserves actions while records same-owner transact reentry compensates to7; ordinary reentry preserves77 without mandatory throw. Original extra-first red unchanged. Ran this existing vetted witness unchanged, current source6/6 pass (21-VETTED-FIRST.log, input/witness/bundle hashes in replayed/adoption-extra-vetted.inputs.json). Thus expanded extra-first77→7 is an already-adjudicated oracle mismatch, not a new runtime blocker. Do not replace/delete original red or add its count to safety totals.

A1 original adoption-review privateauthorityCount observation remains unsupported, not passed. Current78 vector's src/lib/entity-semantic-transition.spec.ts explicitly names A1 setAll two-lifetime adoption chronology/ordinaryrollback, exercised held-field and updateOne scenarios, useful ordinary Link assertion. Its executed result is a separate public native regression, not unchanged original witness execution. Private store authority-count retirement cannot be inferred from that A1 equivalence; use separately qualified retention controls and currentGC witnesses within their scope. Each reused witness identity is its corresponding inputs.json; no aggregate can stand in for those hashes.

## Exact execution root

These rebuilt witnesses load /private/tmp/restoration-install-successor/candidate (slice3 frozen source), not the later slice4 directory. Root verified 2181 recorded input hashes. Slice4 differs only in four new facade test files; all runtime modules are byte-identical. This permits runtime evidence reuse, not a claim that the original paths were the slice4 path. Retained/dropped GC were not repeated to obtain favorable samples.
