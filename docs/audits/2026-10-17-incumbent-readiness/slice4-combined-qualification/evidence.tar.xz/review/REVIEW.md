# Independent bounded slice4 composition review

No concrete blocker demonstrated in the scoped combined qualification. The finite slice4 matrix is supported by the reviewed native/facade/declaration/lifecycle evidence, with historical mismatches and unsupported observations explicitly separated. This does not authorize activation, SDK additions, full release verification or publication.

## Exact change boundary

Independent package TS/TSX comparison against accepted slice3 finds exactly four new facade spec files; runtime bodies and public exports/types remain byte-identical. Final bodies are stamped FINAL-FACADE-HASHES.json. Each test explicitly checks private declaration capability before a test-only type assertion; this does not promise a public facade declaration API. Native facade write grammar is respected. Inspection setup uses the already existing transaction-realization-contract test support; realizeAs directly reexports withWriteContext. First cross-project import lint errors remain preserved; final supported test-boundary import exceptions and new test type/lint results pass without widening public API.

## Concrete matrix evidence

Existing33 framework files274passes include two new cases per Angular/React/Vue/Solid facade. The scalar case proves independent8 progress while two owners remain pending, dependent7 holds then starts on its actual owner's confirmation, and unrelated owner remains usefully rollbackable. Entity case proves inspected99 does not publish, declared ordinary adoption99 does publish while unrelated owner remains pending, and that owner's rejection cannot undo it. These are meaningful useful-send/receipt assertions rather than runtime-presence-only tests. Final exact four-body reruns are2passes each, spec-types pass, lint0errors/0warnings; original first8passes are not double-counted.

Native14requested/13executed166passes cover in-flight/latest recheck, overlap, structured/root/nested collection projection, order rollback, snapshots/adapters, delivery errors and native epoch publication. link-lifetime is intentionally excluded from default project selection; the explicit retention-gc registry runs it under its required GC environment and passes. Do not claim default runner executed14files. Prior78 native vector1060passes plus preserved replacement+identity contract mismatch remains exact same runtime evidence for P/O/entity order and source responsibility, not new passes here.

Current declaration witnesses exercise multiowner, revision ABA, nested/reentrant validation, rejection/inspection, async misuse, endpoint/callback errors, terminal receipts and metadata drain. No automatic independence from arbitrary unresolved owners is inferred.141 contract boolean checks exclude the explicitly labelled saved-input misuse demonstration. A1 private removed authorityCount abort is unsupported, not passed; separate current native A1 public capture/rollback/Link assertions supply scoped public equivalence. extra-first owned reentry77→7 remains original oracle mismatch; existing extra-vetted actions execute6passes. No original assertion was rewritten.

Historical34 identification now explicit HISTORICAL-34.md: exact source/bundle/result hashes and original32true/2false retained. Both false checks are the same unknown-confirm scenario: send[]/settledfalse expectation against actual[42]/true. The documented owner reconciliation rejects permanent holding after all relevant owners confirm. Current eventual value/waiter controls and own final composition probe are current evidence; no claim historical34 was rerun unchanged or became34green. This closes archival verdict identification without relabelling two assertions as two runtime failures.

Receipt graph forced-GC retained/dropped cases each20/20 use useful sends, live positive control and no favorable repeats. This is sampled receipt graph qualification, not universal entity/object collectibility, canceled in-flight I/O or production memory acceptance. Existing destroy semantics and explicit disposal remain distinct.

## Independent omission challenge

Preregistered review/EXPECTED.md and BEFORE.sha256, full current-source inputs in combined-INPUTS.json. One combined public/native experiment: two pending owners, two entity fields, independentn2 starts in-flight, inspectionn99 never publishes, dependentm3 releases on qconfirm while p remains open, dependentn7 waits pconfirm and prior endpoint acknowledgement, all relevant receipts reach started, and disposal preventsn8. FIRST.log passes exact sends n[2,7]/m[3]. Root verifies/replays input identity separately. This challenges composition omitted by the two simple facade cases without inventing new state/order policy. It is not a proof of every cross-product.

## Evidence location correction and limits

Declaration/gc runners actually load /private/tmp/restoration-install-successor/candidate, not slice4 directory. Recorded input hashes identify that accepted stage3 runtime; package comparison proves identical runtime in slice4. Thus evidence applies by exact body equivalence, not a claim files were loaded from a different path. Result documentation now qualifies this explicitly. No rerun was needed merely to rename an equivalent runtime directory.

Full registry/kernel/framework/browser suites, installed artifacts/declarations/demo/package builds and budgets, mutation proofs, matched CPU/heap costs and final release source freeze remain slice5. Existing-prefix snapshot overhead and local-index fallback limits remain. No current supported failure is excused by later scope; none was demonstrated by this review. No runtime/controller or prior assertion edits by reviewer.
