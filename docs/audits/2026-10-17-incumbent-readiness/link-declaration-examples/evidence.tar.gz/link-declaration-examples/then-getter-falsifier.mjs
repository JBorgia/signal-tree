import {Model} from './model.mjs';
const m=new Model();const p=m.owner();
let error;
try { m.declare([p],()=>({get then(){m.declare([],()=>m.write(9));m.pump();return undefined;}})); }
catch(e){error=String(e);}
const result={name:'then getter reentry cannot erase outer pending dependency',expected:[],actual:m.sent,error,pending:m.owners.get(p),events:m.events};
console.log(JSON.stringify(result,null,2));if(m.sent.length)process.exitCode=1;
