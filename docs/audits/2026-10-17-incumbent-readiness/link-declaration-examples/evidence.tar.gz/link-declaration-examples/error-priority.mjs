import assert from 'node:assert/strict';
import {Model,DeclarationError} from './model.mjs';
const results=[];
for(const error of [17,Object.freeze(new Error('frozen callback'))]){
 const m=new Model(),p=m.owner();let caught;
 try{m.declare([],()=>{m.write(7);m.observe(p);throw error;});}catch(e){caught=e;}
 assert.equal(caught,error);assert.equal(m.pump(),false);assert.equal(m.projection.value,7);
 results.push({case:typeof error==='number'?'primitive':'frozen',sameIdentity:caught===error,sent:m.sent,events:m.events});
}
{
 const m=new Model();m.owner();
 assert.throws(()=>m.declare([],()=>{m.write(7);return {get then(){throw new Error('getter');}};}),DeclarationError);
 assert.equal(m.pump(),false);results.push({case:'throwing-then-getter',sent:m.sent,events:m.events});
}
console.log(JSON.stringify(results,null,2));
