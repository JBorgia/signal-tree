// Executable scalar contract model; no SignalTree integration or public API.
export class DeclarationError extends Error {}
export class Model {
  owners = new Map(); frame = null; version = 0; projection = { value: 0, version: 0 };
  receipt = null; sent = []; events = []; disposed = false; inspection = null;
  owner(source = 'local') { const o = Object.freeze({ id: this.owners.size + 1, source }); this.owners.set(o, 'pending'); return o; }
  settle(o, outcome) {
    if (this.owners.get(o) !== 'pending') throw new Error('nonpending settlement');
    this.owners.set(o, outcome); this.events.push(['outcome', o.id, outcome]);
  }
  observe(o) {
    if (!this.frame) return;
    if (!this.owners.has(o)) { this.frame.invalid = true; return; }
    if (this.owners.get(o) === 'pending') this.frame.known.add(o);
  }
  write(value) {
    this.projection = Object.freeze({ value, version: ++this.version });
    this.receipt = { ...this.projection, deps: new Set(), valid: false, reason: 'ordinary' };
    if (this.frame) this.frame.writes.add(this.version);
    this.events.push(['installed', this.version, value]);
  }
  // Harness input: native compensation has already installed a coherent projection.
  restore(value) { this.write(value); this.events.push(['restoration', this.version]); }
  declare(list, work) {
    if (!Array.isArray(list) || list.some(o => !this.owners.has(o) || ['rejected','abandoned'].includes(this.owners.get(o)))) throw new DeclarationError('invalid declaration before callback');
    const parent = this.frame;
    const f = { declared: new Set(list), known: new Set(parent ? [...parent.known, ...parent.declared] : []), writes: new Set(), invalid: false };
    this.frame = f;
    let result, original, failed = false;
    try { result = work(); }
    catch (e) { original = e; failed = true; }
    // Return-shape inspection can invoke a user getter; it is part of validation.
    try { if (result != null && typeof result.then === 'function') { f.invalid = true; Promise.resolve(result).catch(() => {}); } }
    catch { f.invalid = true; }
    finally { this.frame = parent; }
    if ([...f.known].some(o => !f.declared.has(o))) f.invalid = true;
    const deps = new Set([...f.declared, ...f.known]);
    if (parent) {
      for (const o of deps) parent.known.add(o);
      for (const v of f.writes) parent.writes.add(v);
      parent.invalid ||= f.invalid;
    } else if (this.receipt && f.writes.has(this.receipt.version)) {
      this.receipt = { ...this.receipt, deps, valid: !f.invalid, reason: f.invalid ? 'conservative' : 'declared' };
    }
    this.events.push(['validation', !f.invalid, [...deps].map(o => o.id)]);
    if (failed) throw original;
    if (f.invalid) throw new DeclarationError('early publication refused; writes retained');
    return result;
  }
  prepare() {
    if (this.disposed || this.frame || !this.receipt) return null;
    const r = this.receipt;
    if (r.valid && [...r.deps].every(o => this.owners.get(o) === 'confirmed')) return Object.freeze({ value:r.value, version:r.version, basis:'declared', receipt:r });
    // This conservative whole-model gate is an input assumption, not sparse production code.
    if ([...this.owners.values()].some(s => s === 'pending' || s === 'abandoned')) return null;
    // NEW evaluation of the noninspection projection; never replay r.value here.
    return Object.freeze({ ...this.projection, basis:'current-surviving', receipt:r });
  }
  deliver(ticket) {
    if (!ticket || this.disposed || this.frame || ticket.version !== this.projection.version || ticket.receipt !== this.receipt) return false;
    const now = this.prepare();
    if (!now || now.basis !== ticket.basis) return false;
    this.sent.push(ticket.value); this.events.push(['send',ticket.value,ticket.basis,ticket.version]);
    this.receipt = null; return true;
  }
  pump() { return this.deliver(this.prepare()); }
  dispose() { this.disposed = true; this.receipt = null; }
}
