# Final independent bounded derive review

No remaining concrete blocker demonstrated in this correction. Reviewed derive/FINAL/SOURCE.json SHA256 46f0f570f7d4cac6988b36f7d5dfce73db1d962622d85f4e46ab34e1c7f6fb1c, copied owned source and exact candidate fallback. First-draft and STAGED rejections remain preserved in review-derive.md/review-derive-staged.md with their raw probes. This disposition covers derive footprint preparation, not later slices or whole integration.

## Source interpretation

replaceOne retains displayed updater input and interceptor-transformed returned row. It passes private derive designation before ordinary preparation. EntityValueStore evaluates only own enumerable string accessors into stable data inside the existing frame revision window; data-only outputs retain their exact reference. The physical own-property/Object.is comparison uses stable after evidence and keeps nested references, preventing false whole nested-field authorship from deep cloning. Same prepared physicalAfter flows to value installation, capture, native notification and tap. Partial O fields merge onto ordinary-before; explicit replacement still uses null/whole intent and adopts same-display inspection. No new authority, public export or generic no-op event was introduced.

Descriptor staging preserves all unmaterialized own descriptors and prototype. Relevant getters run with original receiver, including nonconfigurable getters whose final data descriptor is built before clone construction. Symbols/nonenumerables remain physical data; this does not invent their ordinary authorship. The erased PropertyDescriptorMap annotation since COMPATIBLE does not alter runtime behavior.

New reflection remains fallible before installation, under existing revision validation. Getter tree reentry invalidates the outer staged plan instead of overwriting independent writes; throwing getter leaves outer state uninstalled. Existing updater/interceptor callback semantics are retained, not extended to prohibit all deliberate nested writes. No universal arbitrary Proxy/reflection/clone contract is claimed.

## Independent executable falsifiers

FINAL-BEFORE.sha256 stamps frozen manifest plus unchanged reviewer probes; each bundle records all loaded source hashes before execution. No candidate source edits.

- Unchanged property.ts on FINAL restores the prederive control exactly: identity-updater same row reference, nested reference, prototype/inherited8, nonenumerable7, symbol9 all retained (PROPERTY-FINAL.log versus PROPERTY-CONTROL.log). This closes the STAGED physical data-loss finding.
- Unchanged changing-getter probe evaluates once, installs coherent physical y0 with empty responsibility, and rejection retains y0/readcount1 (GETTER-FINAL.log). Earlier getter-first draft had installed y2 with no responsibility and repeated reads. This closes the independently reproduced preparation-coherence finding.
- Additional property-accessor probe uses a nonconfigurable enumerable getter, original receiver, inherited/prototype data, symbol and nonenumerable data together. ACCESSOR-FINAL.log proves one read/original receiver and other data preserved. This separately exercises the descriptor-copy branch, not merely the data-only identity fast case.

Read the14 new spec assertions: y-only capture/rollback plus useful later ordinary publication; identity derive no capture/no publication; add/delete/presentundefined; explicit same-display replacement capture and rollback; updater/getter throw; getter independent reentry; single-value ordinary publication; physical references/descriptors/null prototype/special names. These assert useful behavior. Their worker-reported14 pass and parent larger gate are separate evidence, not reviewer-owned Nx executions.

## Acceptance limits and inherited mismatch

The original combined explicit replacement then identity-updater no-send expectation remains incompatible with approved whole replacement adoption. Its continued red is not a corrected identity-only derive failure and must be reported transparently; do not silently remove/change that assertion. Identity-only controls now exercise the actual genuine-no-op premise separately. Parent owns final exact-source compatibility/type/spec gates and reconciliation of other inherited assertions.

No broad suite, later structural/full-target/restoration/hidden semantics, cost campaign, disposal/GC, framework/package or release qualification follows. No production/controller/test assertions were changed by reviewer.
