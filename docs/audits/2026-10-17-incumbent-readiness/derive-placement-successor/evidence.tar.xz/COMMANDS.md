# Replay / execution record

Node24.15.0; outer Corepack pnpm10.17.0. Final gates also put toolchain/pnpm first on PATH so the Nx wrapper's nested `pnpm exec vitest` resolves pinned10.17.0 rather than host11. Earlier FIRST/RESULT logs retain their host-inner invocation warnings; all use installed Vitest4.1.9. No dependency installation or config change.

Original snapshot reduction red and first corrected65 used:

```
COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false corepack pnpm exec nx test kernel --testFile=src/lib/placement-snapshot-reuse.spec.ts --skip-nx-cache
```

Corrected vector added ordinary-order-owner-preparation, native-compound-ordinary-order-regression, prepend-many-order-reversal (exact relative paths in log command).

Final combined45-file vector: `python3 run-focused.py`, command arguments in combined/COMMAND.json. Wrapper froze all source before and verified after execution. A new output folder is required to replay the runner; or run saved command arguments directly against reconstructed candidate. 477pass9fail, no skips/expected-failure classifications applied by runner.

After fixing only new-test library/lint compatibility, final fourteen derive assertions ran through pinned Nx:

```
PATH=/private/tmp/derive-placement-successor/toolchain:$PATH COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false corepack pnpm exec nx test kernel --testFile=src/lib/derive-footprint.spec.ts --skip-nx-cache
```

Final quality checks from candidate with the same PATH: `corepack pnpm run typecheck`; `node tools/check-spec-types.mjs`; `corepack pnpm exec eslint packages/kernel/src/lib/entity-signal.ts packages/kernel/src/lib/physical/entity-mutation-frame.ts packages/kernel/src/lib/physical/entity-placement-stage.ts packages/kernel/src/lib/physical/entity-value-store.ts packages/kernel/src/lib/derive-footprint.spec.ts packages/kernel/src/lib/placement-snapshot-reuse.spec.ts`.

Final exact runtime traversal: `node measurement-final/build.cjs` then `node --enable-source-maps measurement-final/candidate.mjs`. Build inputs have file hashes; prior control runtime unchanged, measured once in measurement/CONTROL-FIRST.jsonl. Root independently replayed `node link-boundary/receipt-probe.mjs` into ROOT-REPLAY.log. Standalone bundles embed tested runtime; scripts preserve source/build roots for reconstruction. Root trace probes are diagnostics, not counted as assertion-suite passes.

Reconstruction: restore unchanged indexed source from a55050e4 evidence (manifestd13c33b1...), then apply final/overlay preserving paths. Complete final783-file manifest verifies inputs. Original scripts' absolute paths may need relocation; do not silently resolve imports to a different candidate. node_modules is the existing main checkout installation; neither candidate nor archive vendors it.
