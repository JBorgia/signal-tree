# Independent private snapshot reuse review

October25 read-only. Reviewed exact three-file diff against /private/tmp/ordinary-order-indexed/native. Source hashes review-placement.sha256; no candidate edits or independent test executions. Supplied placement/RESULT.log65 passes inspected as attributed run evidence, not this reviewer's execution.

No concrete correctness blocker found in these three changes. This verdict covers prepared snapshot reuse only, not simultaneous derive changes or final integration.

## Physical prefix endpoint

EntityMutationFrame.preparePlacement adds local prefixOrder, assigned only when finalFront actually moves existing members. Same frozen snapshot also remains this.ordinaryOrder as before. Endpoint after reuses it **only when finalOrder is absent**; if a full finalOrder exists, stage.order executes and endpoint snapshots current stage instead. Thus coexistence does not reuse a stale pre-finalOrder physical endpoint. If no prefix movement occurred, prefixOrder stays undefined and old snapshot behavior remains. Changes do not alter the preexisting semantics of ordinaryOrder when both flags exist; they preserve that state, rather than claiming those semantics newly proved.

Between prefix snapshot and guarded reuse there is no user callback/getter, live installation, or captured external reference mutation. Inputs are plain lifetime IDs resolved from internal stages. Snapshot is frozen, no stage reference stored in endpoint. The branch gate is sufficient for the only intervening explicit stage mutation in this method.

## Ordinary endpoint

EntityPlacementStage.orderDomain still validates unique/present members, snapshots current private order, builds same mapped result and calls order. It now freezes/returns that result. Source consumes it immediately as ordinaryEndpoints.after without further placement mutation. order writes precisely the supplied links/head/tail, so returned sequence and prepared stage agree on successful return. Failure during order leaves only private preparation mutated, as before; no live source state installed. Extra Object.freeze runs on newly constructed private plain array, with no user-controlled accessor/invocation. Return value contains only lifetime IDs.

The frozen array is retained by the same operation endpoint that previously retained a fresh snapshot array. No global cache, owner mirror, extra persistent reference or lease is introduced. old before/after distinction remains. Physical prefixOrder is not passed as ordinary endpoint by this optimization: ordinary source derives its own orderDomain output, preserving P/O separation.

## Reentry and faults

Neither reuse adds an executable callback or extends a result across installation/publication. Existing revision checks around preparation still reject reentrant stale source units; no check is removed. Return alias is immutable. A test monkeypatch of internal stage.order that changes supplied semantics could invalidate equality, but that is not an existing supported production callback boundary and does not justify adding defensive full traversal.

Focused final gate should retain direct combination finalFront+finalOrder, ordinary partial-domain preserving hidden member slots, owner post-plan throw/reentry, callback nested prepend/append, and original four ordinary/history regressions. If65-case vector lacks explicit finalFront+finalOrder combination, source inspection supports gate but execution evidence remains missing for that private combination. Do not report counts as premise proof. No broader suite or CPU claim implied.
