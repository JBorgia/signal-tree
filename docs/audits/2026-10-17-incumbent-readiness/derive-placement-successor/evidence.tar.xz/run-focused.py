from pathlib import Path
import json,os,subprocess,hashlib,difflib,shutil,sys
b=Path('/private/tmp/derive-placement-successor');c=b/'candidate';d=b/'combined';d.mkdir(exist_ok=False)
m={str(p.relative_to(c)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((c/'packages').rglob('*.ts'))}
(d/'SOURCE.json').write_text(json.dumps(m,indent=2)+'\n')
base=Path('/private/tmp/ordinary-order-indexed/native');changed=[]
for f,h in m.items():
 old=base/f;new=c/f
 if old.exists() and hashlib.sha256(old.read_bytes()).hexdigest()==h:continue
 changed.append(f);dest=d/'source'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(new,dest)
 with (d/'CHANGE.patch').open('a') as out:out.writelines(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],new.read_text().splitlines(True),fromfile=str(old),tofile=str(new)))
(d/'CHANGED.json').write_text(json.dumps(changed,indent=2))
oldtests=[f for f in changed if (base/f).exists() and f.endswith('.spec.ts')]
assert not oldtests,oldtests
cmd=json.loads(Path('/private/tmp/ordinary-order-indexed/final-native/COMMAND.json').read_text())
for f in ['src/lib/placement-snapshot-reuse.spec.ts','src/lib/derive-footprint.spec.ts','src/lib/entity-semantic-transition.spec.ts','src/lib/entity-semantic-point-recurrence.spec.ts','src/lib/entity-semantic-composition-slice.spec.ts','src/lib/entity-update-one-equivalence.spec.ts','src/lib/entity-own-property-audit.spec.ts','src/lib/prepend-many-order-reversal.spec.ts']:
 arg='--testFile='+f
 if arg not in cmd:cmd.insert(-1,arg)
(d/'COMMAND.json').write_text(json.dumps(cmd,indent=2))
env=dict(os.environ,PATH=str(b/'toolchain')+':'+os.environ['PATH'],COREPACK_ENABLE_NETWORK='0',NX_DAEMON='false',NX_ISOLATE_PLUGINS='false')
with (d/'FIRST.log').open('w') as out:r=subprocess.run(cmd,cwd=c,env=env,stdout=out,stderr=subprocess.STDOUT)
after={f:hashlib.sha256((c/f).read_bytes()).hexdigest() for f in m};assert after==m,'Source changed during test'
(d/'RESULT.json').write_text(json.dumps({'exit':r.returncode,'sourceManifestSha256':hashlib.sha256((d/'SOURCE.json').read_bytes()).hexdigest(),'unchangedOriginalAssertions':True,'sourceStable':True},indent=2))
print((d/'RESULT.json').read_text())
