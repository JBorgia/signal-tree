import {signalTree,entityMap,transactions,link} from '@case/index';
import {withWriteContext} from '@case/lib/write-context';
import {getPathNotifier} from '@case/lib/path-notifier';
const tick=async()=>{getPathNotifier().flushSync();for(let i=0;i<40;i++)await Promise.resolve();};
const t=signalTree({rows:entityMap<{id:string;x:number;y:number},string>()},{enhancers:[transactions()]});let c:ReturnType<typeof link>|undefined;
try{t.$.rows.addOne({id:'r',x:0,y:0});await tick();const row=t.$.rows.byIdOrFail('r');const sent:unknown[]=[];c=link(t.$.rows,{set:v=>{sent.push(structuredClone(v));}});withWriteContext({participation:'inspection'},()=>row.x(99));await tick();let reads=0;const p=t.transact(()=>row(v=>({...v,get y(){return ++reads===1?0:2;}})));console.log(JSON.stringify({reads,P:row(),inspect:p.inspect(),sent}));p.rollback();await tick();console.log(JSON.stringify({afterReject:row(),reads,sent}));}finally{c?.dispose();t.destroy();}
