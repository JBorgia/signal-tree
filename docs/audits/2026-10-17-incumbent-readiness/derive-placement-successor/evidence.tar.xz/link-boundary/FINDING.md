# Minimal field omission delivery boundary

Independent bounded native probe, October25. No candidate edits. BEFORE.json records package TS/harness hashes before first execution; RECEIPT-BEFORE.sha256 records receipt variant. node probe.mjs and node receipt-probe.mjs run finite100-microtask drains then dispose; disposal awaited successfully. No indefinite settled wait. Source bundles, raw metadata/results retained. Probe uses ordinary field named value, not collision names, so boundary is broader than own-property collision handling.

No transactions enhancer: replaceOne omits value; held field reads undefined (undefined omitted by JSON object serialization); row notification arrives with ordinary row{id:a}; no endpoint call after bounded drain; settled remains false; dispose releases wait. Research receipt: owner1 revision1 cleanfalse unknowntrue.

Transactions enhancer, otherwise same operations: physical field undefined; endpoint set(undefined) runs, settled true before dispose. JSON sent array shows null because JSON.stringify converts undefined array entries; SEND log prints undefined. Receipts unknownfalse. No pending proposals in either arm.

## First causal discriminator

Native notification and physical own-property resolution succeed. The unresolved boundary is experimental publication eligibility/authority initialization on a supported entity-field source **without transactions registration**, rather than undefined transport universally: same undefined payload sends with transactions. private.ts annotate30–33 marks ordinary write unknown when lifecycle.ownerToken(owner) absent. Receipt confirms unknowntrue only no-enhancer arm. private.ts allowed45 requires valid latest fact plus clean/early/grant; admit47–54 schedules conservative fallback, but missing eligibility initialization does not become publishable in observed finite drain. Settled waits outstanding send/held chain and dispose releases it. No evidence of dropped notification, endpoint rejection or queue's inability to represent undefined.

This narrows but does not prove complete fallback scheduling root cause: further instrumentation would be needed to attribute exact ungranted send wait versus lifecycle missing owner registration. Do not claim permanent hold from finite probe alone; unchanged5s test timeouts independently demonstrate sustained failure. Existing frozen-predecessor whole-file8 timeouts establish inherited integration boundary, not newly introduced derive/placement regression. No no-enhancer public contract narrowing authorized.

The original own-property eight tests and current two inherited footprint assertions remain preserved. This finding authorizes no Link repair. Required disposition must acknowledge no-enhancer ordinary field publication fails while physical read succeeds, and qualify registered/enhanced success separately.
