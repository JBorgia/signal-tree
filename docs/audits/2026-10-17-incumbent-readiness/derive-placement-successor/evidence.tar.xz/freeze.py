from pathlib import Path
import json,hashlib,shutil,difflib,tarfile
b=Path('/private/tmp/derive-placement-successor');c=b/'candidate';base=Path('/private/tmp/ordinary-order-indexed/native');d=b/'final'
m={str(p.relative_to(c)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((c/'packages').rglob('*.ts'))}
(d/'SOURCE.json').write_text(json.dumps(m,indent=2)+'\n')
old=json.loads(Path('/private/tmp/ordinary-order-indexed/final-corrected/SOURCE.json').read_text());assert all(hashlib.sha256((base/f).read_bytes()).hexdigest()==h for f,h in old.items())
combined=json.loads((b/'combined/SOURCE.json').read_text());assert [f for f,h in m.items() if combined.get(f)!=h]==['packages/kernel/src/lib/derive-footprint.spec.ts']
patch=[];changed=[]
for f,h in m.items():
 prev=base/f;cur=c/f
 if prev.exists() and hashlib.sha256(prev.read_bytes()).hexdigest()==h:continue
 assert not (prev.exists() and f.endswith('.spec.ts')),f
 changed.append(f);dest=d/'overlay'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(cur,dest)
 patch.extend(difflib.unified_diff(prev.read_text().splitlines(True) if prev.exists() else [],cur.read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
(d/'CHANGE.patch').write_text(''.join(patch));(d/'CHANGED.json').write_text(json.dumps(changed,indent=2))
(d/'IDENTITY.json').write_text(json.dumps({'sourceManifestSHA256':hashlib.sha256((d/'SOURCE.json').read_bytes()).hexdigest(),'baselineManifest':'d13c33b1a515c65e4ca008df5caab0ac4976ed4db0cc166b922998fd2b7f6cb6','combinedManifest':'c995f26fe0e933c0ed85fa3120586bda5bfb191c94c3d29b63a99ffbf4484628','production':'87f6831fa60cafe87508f0ace84b7638698ca3b0','controllerBase':'c0f55f0dbd5354b37f737a4562dfc4a52b8069cc','sourceFiles':len(m),'baselineUnchanged':True,'existingAssertionsUnchanged':True,'deltaAfterCombined':'new derive test only: ES library-compatible own-property check and getter mock-context assertion; runtime unchanged'},indent=2))
print((d/'IDENTITY.json').read_text())
