import { describe, expect, it } from 'vitest';
import { entityMap, link, signalTree, transactions } from '../index';
import { getPathNotifier } from './path-notifier';
import { withWriteContext } from './write-context';

type Row = { id: string; x: number; y: number; extra?: number | undefined };
const flush = async () => {
  getPathNotifier().flushSync();
  for (let i = 0; i < 20; i++) await Promise.resolve();
};
const setup = async (extra = false) => {
  const tree = signalTree({ rows: entityMap<Row, string>() }, { enhancers: [transactions()] });
  tree.$.rows.addOne({ id: 'r', x: 0, y: 0, ...(extra ? { extra: 3 } : {}) });
  await flush();
  const row = tree.$.rows.byIdOrFail('r');
  const sent: unknown[] = [];
  const connection = link(tree.$.rows, { set: value => { sent.push(structuredClone(value)); } });
  withWriteContext({ participation: 'inspection' }, () => row.x(99));
  await flush();
  return { tree, row, sent, connection };
};

describe('derived row authored physical footprint', () => {
  it('captures only derived y and rolls back without owning inspected x', async () => {
    const { tree, row, sent, connection } = await setup();
    try {
      const pending = tree.transact(() => row(current => ({ ...current, y: 2 })));
      expect(pending.inspect().changes.some(change => change.path.endsWith('.x'))).toBe(false);
      pending.rollback();
      expect(row()).toEqual({ id: 'r', x: 99, y: 0 });
      row(current => ({ ...current, y: 2 }));
      await flush(); await connection.settled();
      expect(sent.at(-1)).toEqual([{ id: 'r', x: 0, y: 2 }]);
    } finally { connection.dispose(); tree.destroy(); }
  });
  it.each(['same-reference', 'same-fields'] as const)('identity derive %s does not adopt inspection', async kind => {
    const { tree, row, sent, connection } = await setup();
    try {
      const pending = tree.transact(() => row(current => kind === 'same-reference' ? current : { ...current }));
      expect(pending.inspect().changes).toEqual([]);
      pending.confirm(); await flush(); await connection.settled();
      expect(sent).toEqual([]);
      expect(row.x()).toBe(99);
    } finally { connection.dispose(); tree.destroy(); }
  });
  it.each(['add', 'delete', 'undefined'] as const)('preserves physical field presence for %s', async kind => {
    const { tree, row, sent, connection } = await setup(kind === 'delete');
    try {
      row(current => {
        const next = { ...current };
        if (kind === 'delete') delete next.extra;
        else next.extra = kind === 'undefined' ? undefined : 4;
        return next;
      });
      await flush(); await connection.settled();
      expect(sent.at(-1)).toEqual([{ id: 'r', x: 0, y: 0, ...(kind === 'delete' ? {} : { extra: kind === 'undefined' ? undefined : 4 }) }]);
      expect(Object.hasOwn((sent.at(-1) as Row[])[0], 'extra')).toBe(kind !== 'delete');
    } finally { connection.dispose(); tree.destroy(); }
  });
  it('explicit same-display replacement adopts and its rollback restores ordinary x', async () => {
    const { tree, row, connection } = await setup();
    try {
      const pending = tree.transact(() => row(row()));
      expect(pending.inspect().changes.some(change => change.path.endsWith('.x'))).toBe(true);
      pending.rollback(); expect(row.x()).toBe(0);
    } finally { connection.dispose(); tree.destroy(); }
  });
  it('throwing updater installs nothing and later derived change remains useful', async () => {
    const { tree, row, sent, connection } = await setup();
    try {
      expect(() => row(() => { throw new Error('derive failure'); })).toThrow('derive failure');
      expect(row()).toEqual({ id: 'r', x: 99, y: 0 });
      row(current => ({ ...current, y: 2 }));
      await flush(); await connection.settled();
      expect(sent.at(-1)).toEqual([{ id: 'r', x: 0, y: 2 }]);
    } finally { connection.dispose(); tree.destroy(); }
  });
  it('getter failure during physical comparison installs no outer value', async () => {
    const { tree, row, connection } = await setup();
    try {
      expect(() => row(current => ({ ...current, get y(): number { throw new Error('getter failure'); } }))).toThrow('getter failure');
      expect(row()).toEqual({ id: 'r', x: 99, y: 0 });
    } finally { connection.dispose(); tree.destroy(); }
  });
  it('getter reentry cannot silently overwrite independently installed truth', async () => {
    const { tree, row, connection } = await setup();
    try {
      let entered = false;
      expect(() => row(current => ({ ...current, get y(): number {
        if (!entered) { entered = true; row.y(7); }
        return 2;
      } }))).toThrow(/reenter/i);
      expect(entered).toBe(true);
      expect(row.y()).toBe(7);
    } finally { connection.dispose(); tree.destroy(); }
  });

});
