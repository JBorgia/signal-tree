// Private research only. Does not infer arbitrary application provenance.
export const stamp = Symbol('research revision');
type Fact = { readonly revision: number; readonly clean: boolean };
type Meta = Record<PropertyKey, unknown>;
let serial = 0;
let ingress: { owner: number; position: number; consumed: boolean } | undefined;
const latest = new Map<string, Fact>();
const held = new Map<object, () => void>();
export const receipts: unknown[] = [];
export let enabled = true;
export function mode(value: boolean): void { enabled = value; }
export function acquire(owner: number, position: number, work: () => void): void {
 const old = ingress; ingress = { owner, position, consumed: false };
 try { work(); } finally { ingress = old; }
}
export function annotate(meta: Meta | undefined, owner: number | undefined, positions: number[] | undefined): Meta {
 const clean = !!ingress && !ingress.consumed && owner === ingress.owner && positions?.[0] === ingress.position;
 if (clean && ingress) ingress.consumed = true;
 const fact: Fact = Object.freeze({ revision: ++serial, clean });
 if(owner !== undefined && positions?.[0] !== undefined) latest.set(`${owner}:${positions[0]}`,fact);
 receipts.push({owner,position:positions?.[0],...fact});
 return {...meta, [stamp]: fact};
}
export function evidence(meta: unknown): Fact | undefined { return (meta as Meta | undefined)?.[stamp] as Fact | undefined; }
export function allowed(fact: Fact | undefined, owner: number, position: number): boolean {
 return !enabled || !!fact?.clean && latest.get(`${owner}:${position}`) === fact;
}
export function admit(original: (request: Request) => void, fact: Fact | undefined, owner: number, position: number, request: Request): boolean {
 if (!enabled) { original(request); return true; }
 if(allowed(fact,owner,position)) { request.run(); return true; }
 return false;
}

type Request = {claimant: unknown; key: object; run: () => void};
export function dispose(a: object,b: object): void { held.delete(a); held.delete(b); }
export function heldCount(): number { return held.size; }
