import {signalTree,transactions,link} from './packages/kernel/src/index';
import {getPositionRegistry} from './packages/kernel/src/lib/internals/position-registry';
import {getLinkStateSlot} from './packages/kernel/src/lib/internals/link-state-source';
import * as research from 'research-private';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
export async function run(){
 research.mode(true);const results:unknown[]=[];
 for(const scenario of ['observer-unknown','observer-eligible','held-inflight','eligible-inflight','repeat-coalesce','dispose-held','dispose-started','settlement-equality','observer-throw','endpoint-reject','unknown-confirm']){
  const t=signalTree({x:0,y:0},{enhancers:[transactions()]});
  const trace:unknown[]=[];const sent:number[]=[];let active=0,maxActive=0,release:undefined|(()=>void),incoming!:(v:number)=>void;
  const out=link(t.$.y,{set:v=>{sent.push(v);active++;maxActive=Math.max(maxActive,active);trace.push({event:'start',value:v});
   if(scenario==='endpoint-reject'&&sent.length===1){active--;trace.push({event:'reject',value:v});return Promise.reject(Error('targeted endpoint failure'));}
   if(['held-inflight','eligible-inflight','dispose-started'].includes(scenario)&&sent.length===1)return new Promise<void>(r=>{release=()=>{active--;trace.push({event:'complete',value:v});r();};});
   active--;trace.push({event:'complete',value:v});
  }});
  const input=link(t.$.y,{subscribe:next=>{incoming=next;return ()=>{};}});
  const p=t.transact(()=>t.$.x(7));const checks:unknown[]=[];
  const eq=(actual:unknown,expected:unknown,name:string)=>checks.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
  let settled=false;let settledPromise:Promise<void>|undefined;
  const wait=()=>{settledPromise=out.settled().then(()=>{settled=true;trace.push({event:'settled'});});};
  const slot=getLinkStateSlot(getPositionRegistry(t.$.y)!);
  try{
   if(scenario.startsWith('observer-')){let fired=false;slot.observer=r=>{if(r.endpoint.set&&r.activity()[3]&&!fired){fired=true;trace.push({event:'observer',scenario});if(scenario==='observer-throw')throw Error('targeted observer failure');if(scenario==='observer-eligible')incoming(9);else t.$.y(7);}};
    incoming(42);await tick();slot.observer=undefined;
    eq([...sent],scenario==='observer-eligible'?[9]:[],'post-observer no stale42');
    const record=[...slot.links.values()].find(r=>!!r.endpoint.set);eq(record?.activity()[3],false,'sending restored');
    if(scenario!=='observer-eligible'){incoming(9);await tick();eq([...sent],[9],'later eligible progresses');}
   }
   if(scenario==='held-inflight'||scenario==='eligible-inflight'){
    incoming(42);await tick();eq([...sent],[42],'first started');
    if(scenario==='held-inflight'){t.$.y(7);await tick();release!();await tick();wait();await tick();eq(settled,false,'actual settled held');incoming(9);}
    else {incoming(9);await tick();eq([...sent],[42],'replacement serialized');release!();}
    await tick();eq([...sent],[42,9],'correction');eq(maxActive,1,'one inflight');if(settledPromise)eq(settled,true,'held settlement released');
   }
   if(scenario==='repeat-coalesce'){
    t.$.y(7);await tick();wait();await tick();eq(settled,false,'initial held');incoming(8);t.$.y(6);incoming(9);incoming(10);await tick();eq([...sent],[10],'latest coherent candidate');eq(settled,true,'latest releases actual held');
   }
   if(scenario==='dispose-held'){t.$.y(7);await tick();wait();await tick();eq(settled,false,'held before disposal');out.dispose();await tick();incoming(9);await tick();eq(settled,true,'dispose releases actual wait');eq(sent,[],'no new send');}
   if(scenario==='dispose-started'){incoming(42);await tick();wait();out.dispose();await tick();eq(settled,true,'dispose releases local wait');incoming(9);release!();await tick();eq([...sent],[42],'started bytes only');}
   if(scenario==='settlement-equality'){incoming(42);await tick();t.$.y(7);await tick();wait();await tick();eq(settled,false,'unknown held');incoming(42);await tick();eq([...sent],[42],'equal knownY needs no duplicate');eq(settled,true,'equal knownY releases held');}
   if(scenario==='endpoint-reject'){incoming(42);await tick();incoming(9);await tick();eq([...sent],[42,9],'subsequent eligible retries');eq(maxActive,1,'serialized retry');}
   if(scenario==='unknown-confirm'){t.$.y(42);await tick();wait();p.confirm();await tick();eq([...sent],[],'unknown never cleansed');eq(settled,false,'actual held after confirm');trace.push({classification:'UNMET eligibility absent, not wake-only'});}
   results.push({scenario,sent:[...sent],maxActive,checks,trace:[...trace]});
  }catch(error){results.push({scenario,harnessError:String(error),sent:[...sent],checks,trace:[...trace]});}
  finally{slot.observer=undefined;out.dispose();input.dispose();if(release)release();t.destroy();await tick();}
 }
 return results;
}
