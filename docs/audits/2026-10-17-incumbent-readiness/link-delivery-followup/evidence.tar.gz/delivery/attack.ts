import {signalTree,transactions,link} from './packages/kernel/src/index';
import {getPathNotifier} from './packages/kernel/src/lib/path-notifier';
import * as research from 'research-private';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
export async function run(){
 research.mode(true);const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];const events:unknown[]=[];
 const off=getPathNotifier().subscribe('y',(_v,_prev,_p,_o,_origin,_sub,_pos,meta)=>{const fact=research.evidence(meta);if(fact){let threw=false;try{(fact as {clean:boolean}).clean=true;}catch{threw=true;}events.push({threw,clean:fact.clean,frozen:Object.isFrozen(fact)});}});
 const out=link(t.$.y,{set:v=>{sent.push(v);}});const p=t.transact(()=>t.$.x(7));
 t.$.y(t.$.x());await tick();const result={sent:[...sent],events,immutableTicketSafety:sent.length===0&&events.length===1&&(events[0] as {threw:boolean}).threw};
 out.dispose();off();t.destroy();return result;
}
