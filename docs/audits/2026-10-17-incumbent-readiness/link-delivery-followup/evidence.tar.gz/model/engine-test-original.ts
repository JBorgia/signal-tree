import {Engine,facts,union} from './engine.ts';
const rows:unknown[]=[];
function equal(actual:unknown,expected:unknown,label:string){if(JSON.stringify(actual)!==JSON.stringify(expected))throw Error(label+': '+JSON.stringify({actual,expected}));rows.push({label,actual});}
function throws(fn:()=>void,label:string){let thrown=false;try{fn();}catch{thrown=true;}equal(thrown,true,label);}
for(const arm of ['A','B','C'] as const){
 const e=new Engine(arm);e.owner('p');e.owner('q');
 e.propose({a:7,b:42},facts(['p','q']));if(arm==='C')e.request();equal(e.send(),[],arm+' two owners pending');
 e.outcome('p','confirmed');equal(e.send(),[],arm+' one confirmed still holds');
 // Refusal is no transition, so responsibility remains identical.
 equal(e.status(),'held',arm+' refusal holds');e.outcome('q','confirmed');equal(e.send(),[{a:7,b:42}],arm+' coherent full record');
 e.propose(42,facts([],true));if(arm==='C')e.request();equal(e.send(),[],arm+' unknown holds');
 if(arm!=='A'){
  const prior=e.current;
  throws(()=>e.propose(9,facts(['p'],true),{owners:[],complete:true}),arm+' missing known owner');equal(e.current?.id,prior?.id,arm+' rejection preserves current');
  throws(()=>e.propose(9,facts([],true),{owners:['foreign'],complete:true}),arm+' foreign owner');
  e.propose(42,facts([],true),{owners:[],complete:false});if(arm==='C')e.request();equal(e.send(),[],arm+' partial cannot clear unknown');
  e.propose(42,facts([],true),{owners:[],complete:true});if(arm==='C'){equal(e.send(),[],arm+' update alone does not request');e.request();}equal(e.send(),[42],arm+' complete empty application assertion');
  // Deliberately false complete assertion: hidden rejected contribution is invisible.
  e.outcome('p','rejected');e.propose(7,facts([],true),{owners:[],complete:true});if(arm==='C')e.request();equal(e.send(),[7],arm+' NEGATIVE hidden rejected owner omission leaks');
  e.propose(7,facts(['p'],true),{owners:['p'],complete:true});if(arm==='C')e.request();equal(e.send(),[],arm+' known rejected owner cannot cleanse');
 }
 const obj={a:1,b:{c:2}};e.propose(obj,facts());obj.b.c=3;if(arm==='C')e.request();equal(e.send(),[{a:1,b:{c:2}}],arm+' immutable whole revision');
 equal(e.send(()=>{e.propose(99,facts([],true));if(arm==='C')e.request();}),[],arm+' final reentry revalidation');
 e.destroy();equal(e.send(),[],arm+' destruction invalidates authority');
}
const nested=union(facts(['p']),facts(['q'],true));equal([...nested.owners],['p','q'],'nested parent child and previous union');equal(nested.unknown,true,'unobserved closure remains unknown');
// Conservative returned evidence retains p even if outer constant does not use it.
equal(union(facts(),facts(['p'])).owners.has('p'),true,'UNMET independent outer constant false dependency');
console.log(JSON.stringify(rows,null,2));
