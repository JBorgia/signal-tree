import {Engine} from './engine.ts';
const e=new Engine('A');e.destroy();
try{Object.assign(e,{alive:true});}catch{}
let rejected=false;try{e.owner('late');}catch{rejected=true;}
console.log(JSON.stringify({alive:e.alive,lateOwnerRejected:rejected}));
if(e.alive||!rejected)throw Error('destroyed authority resurrected');
