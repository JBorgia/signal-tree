# Evidence enforcement slice

Research-only A/B/C algebra. No Link/API/runtime change. Each admitted revision owns a private snapshot of observed/declaration owners and unknown state. Exposed facts are immutable read views, not authoritative mutable collections. A foreign/forged revision cannot become eligible. Owner identities register once: pending may become confirmed, rejected or destroyed; repeated same terminal settlement is idempotent, any terminal reversal or reset throws without changing state. Destruction prevents all later proposals, registrations and transitions.

Observed/declaration capture is still a trusted instrumentation/application boundary. This slice enforces preservation of supplied evidence, not discovery of omitted hidden dependencies. False complete declarations remain demonstrable misuse. Retention and cleanup remain finite model observations, not heap qualification. Payload support is plain structured records/scalars as before.

Before fixing, run the new unchanged adversarial test against the prior engine and save all results. Preserve the prior 42-assertion test verbatim. That fixture confirms p then rejects p: the new terminality contract must reject that transition. Separately preserve equivalent omission controls using a different rejected owner; do not label the unchanged fixture a passing rerun.
