// Finite evidence algebra only; NO claim that Link gathers these facts.
export type Outcome='pending'|'confirmed'|'rejected'|'destroyed';
export type Facts={readonly owners:ReadonlySet<string>; readonly unknown:boolean};
export type Revision={readonly id:number;readonly payload:unknown;readonly facts:Facts};
export class Engine {
 readonly outcomes=new Map<string,Outcome>(); private serial=0;
 current:Revision|undefined; requested:Revision|undefined; alive=true;
 readonly policy:'A'|'B'|'C';
 constructor(policy:'A'|'B'|'C'){this.policy=policy;}
 owner(id:string):void{this.outcomes.set(id,'pending');}
 outcome(id:string,state:Outcome):void{if(!this.outcomes.has(id))throw Error('foreign');this.outcomes.set(id,state);}
 propose(payload:unknown, observed:Facts, declaration?:{owners:readonly string[];complete:boolean}):Revision{
  if(!this.alive)throw Error('destroyed');
  const owners=new Set(observed.owners);let unknown=observed.unknown;
  for(const id of owners)if(!this.outcomes.has(id))throw Error('foreign observed owner');
  if(declaration){
   if(this.policy==='A')throw Error('A has no declaration');
   for(const id of declaration.owners)if(!this.outcomes.has(id))throw Error('foreign declaration');
   if(declaration.complete){for(const id of owners)if(!declaration.owners.includes(id))throw Error('contradiction');unknown=false;}
   for(const id of declaration.owners)owners.add(id);
  }
  const revision=Object.freeze({id:++this.serial,payload:freeze(structuredClone(payload)),facts:{owners,unknown}});
  this.current=revision;if(this.policy!=='C')this.requested=revision;return revision;
 }
 request():void{this.requested=this.current;}
 status(rev=this.requested):'held'|'cancelled'|'eligible'{
  if(!this.alive||!rev)return 'cancelled';
  for(const id of rev.facts.owners){const s=this.outcomes.get(id);if(s==='rejected'||s==='destroyed'||s===undefined)return 'cancelled';}
  if(rev.facts.unknown||[...rev.facts.owners].some(id=>this.outcomes.get(id)==='pending'))return 'held';
  return 'eligible';
 }
 send(observer:()=>void=()=>{}):unknown[]{const rev=this.requested;if(this.status(rev)!=='eligible')return [];observer();if(rev!==this.requested||this.status(rev)!=='eligible')return [];return [rev!.payload];}
 destroy():void{this.alive=false;this.current=undefined;this.requested=undefined;}
}
function freeze(value:unknown):unknown{if(value&&typeof value==='object'){for(const v of Object.values(value))freeze(v);Object.freeze(value);}return value;}
export const facts=(owners:string[]=[],unknown=false):Facts=>({owners:new Set(owners),unknown});
export function union(...inputs:Facts[]):Facts{return facts([...new Set(inputs.flatMap(f=>[...f.owners]))],inputs.some(f=>f.unknown));}
