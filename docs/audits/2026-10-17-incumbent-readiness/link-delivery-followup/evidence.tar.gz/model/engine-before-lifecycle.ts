// Finite evidence algebra only; NO claim that Link gathers these facts.
export type Outcome='pending'|'confirmed'|'rejected'|'destroyed';
export type Facts={readonly owners:ReadonlySet<string>; readonly unknown:boolean};
export type Revision={readonly id:number;readonly payload:unknown;readonly facts:Facts};
export class Engine {
 readonly #outcomes=new Map<string,Outcome>(); private serial=0;
 readonly #evidence=new WeakMap<Revision,Facts>();
 current:Revision|undefined; requested:Revision|undefined; alive=true;
 readonly policy:'A'|'B'|'C';
 constructor(policy:'A'|'B'|'C'){this.policy=policy;}
 owner(id:string):void{if(!this.alive)throw Error('destroyed');if(this.#outcomes.has(id))throw Error('duplicate owner');this.#outcomes.set(id,'pending');}
 outcome(id:string,state:Outcome):void{if(!this.alive)throw Error('destroyed');if(!['pending','confirmed','rejected','destroyed'].includes(state))throw Error('invalid outcome');const prior=this.#outcomes.get(id);if(!prior)throw Error('foreign');if(prior!==state&&prior!=='pending')throw Error('terminal outcome');this.#outcomes.set(id,state);}
 propose(payload:unknown, observed:Facts, declaration?:{owners:readonly string[];complete:boolean}):Revision{
  if(!this.alive)throw Error('destroyed');
  const owners=new Set(observed.owners);let unknown=observed.unknown;
  for(const id of owners)if(!this.#outcomes.has(id))throw Error('foreign observed owner');
  if(declaration){
   if(this.policy==='A')throw Error('A has no declaration');
   for(const id of declaration.owners)if(!this.#outcomes.has(id))throw Error('foreign declaration');
   if(declaration.complete){for(const id of owners)if(!declaration.owners.includes(id))throw Error('contradiction');unknown=false;}
   for(const id of declaration.owners)owners.add(id);
  }
  const revision=Object.freeze({id:++this.serial,payload:freeze(structuredClone(payload)),facts:facts([...owners],unknown)});
  this.#evidence.set(revision,revision.facts);this.current=revision;if(this.policy!=='C')this.requested=revision;return revision;
 }
 request():void{this.requested=this.current;}
 status(rev=this.requested):'held'|'cancelled'|'eligible'{
  if(!this.alive||!rev||!this.#evidence.has(rev))return 'cancelled';
  for(const id of rev.facts.owners){const s=this.#outcomes.get(id);if(s==='rejected'||s==='destroyed'||s===undefined)return 'cancelled';}
  if(rev.facts.unknown||[...rev.facts.owners].some(id=>this.#outcomes.get(id)==='pending'))return 'held';
  return 'eligible';
 }
 send(observer:()=>void=()=>{}):unknown[]{const rev=this.requested;if(this.status(rev)!=='eligible')return [];observer();if(rev!==this.requested||this.status(rev)!=='eligible')return [];return [rev!.payload];}
 destroy():void{this.alive=false;this.current=undefined;this.requested=undefined;}
}
function freeze(value:unknown):unknown{if(value&&typeof value==='object'){for(const v of Object.values(value))freeze(v);Object.freeze(value);}return value;}
// A frozen read facade closes over an unexposed copied Set. Object.freeze(Set) alone
// would not disable add/delete/clear. No returned iterator exposes the backing Set.
export const facts=(owners:string[]=[],unknown=false):Facts=>{
 const values=new Set(owners);
 const view:ReadonlySet<string>=Object.freeze({
  get size(){return values.size;},
  has:(value:string)=>values.has(value),
  entries:()=>values.entries(), keys:()=>values.keys(), values:()=>values.values(),
  [Symbol.iterator]:()=>values[Symbol.iterator](),
  forEach:(callback:(value:string,value2:string,set:ReadonlySet<string>)=>void,thisArg?:unknown)=>{
   values.forEach(value=>callback.call(thisArg,value,value,view));
  }
 });
 return Object.freeze({owners:view,unknown});
};
export function union(...inputs:Facts[]):Facts{return facts([...new Set(inputs.flatMap(f=>[...f.owners]))],inputs.some(f=>f.unknown));}
