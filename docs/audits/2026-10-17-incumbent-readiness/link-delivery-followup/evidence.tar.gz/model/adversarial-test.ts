import {Engine,facts} from './engine.ts';
const results:{name:string;pass:boolean;detail?:unknown}[]=[];
function check(name:string,run:()=>boolean){try{results.push({name,pass:run()});}catch(error){results.push({name,pass:false,detail:String(error)});}}
function refused(run:()=>void){try{run();return false;}catch{return true;}}
check('rejected owner cannot confirm',()=>{const e=new Engine('A');e.owner('p');e.propose(7,facts(['p']));e.outcome('p','rejected');return refused(()=>e.outcome('p','confirmed'))&&e.send().length===0;});
check('terminal owner cannot reset',()=>{const e=new Engine('A');e.owner('p');e.propose(7,facts(['p']));e.outcome('p','rejected');return refused(()=>e.owner('p'))&&e.send().length===0;});
check('returned owners cannot be cleared',()=>{const e=new Engine('A');e.owner('p');const r=e.propose(7,facts(['p']));try{(r.facts.owners as Set<string>).clear();}catch{}return e.send().length===0;});
check('returned unknown cannot be cleared',()=>{const e=new Engine('A');const r=e.propose(7,facts([],true));try{Object.assign(r.facts,{unknown:false});}catch{}return e.send().length===0;});
check('source mutation does not affect admitted evidence',()=>{const e=new Engine('A');e.owner('p');const f=facts(['p']);e.propose(7,f);try{(f.owners as Set<string>).clear();}catch{}return e.send().length===0;});
check('forged revision cannot become eligible',()=>{const e=new Engine('A');e.owner('p');const r=e.propose(7,facts(['p']));return e.status({...r,facts:facts()})!=='eligible';});
check('same terminal outcome repeat stays usable',()=>{const e=new Engine('A');e.owner('p');e.propose(7,facts(['p']));e.outcome('p','confirmed');e.outcome('p','confirmed');return JSON.stringify(e.send())==='[7]';});
check('confirm cannot later reject',()=>{const e=new Engine('A');e.owner('p');e.propose(7,facts(['p']));e.outcome('p','confirmed');return refused(()=>e.outcome('p','rejected'))&&JSON.stringify(e.send())==='[7]';});
check('two pending owners require both confirmations',()=>{const e=new Engine('A');e.owner('p');e.owner('q');e.propose(7,facts(['p','q']));e.outcome('p','confirmed');if(e.send().length)return false;e.outcome('q','confirmed');return JSON.stringify(e.send())==='[7]';});
check('destroyed engine cannot register owners',()=>{const e=new Engine('A');e.destroy();return refused(()=>e.owner('p'));});
check('unknown outcome cannot authorize',()=>{const e=new Engine('A');e.owner('p');e.propose(7,facts(['p']));return refused(()=>e.outcome('p','bogus' as never))&&e.send().length===0;});
check('duplicate pending registration refused',()=>{const e=new Engine('A');e.owner('p');e.propose(7,facts(['p']));return refused(()=>e.owner('p'))&&e.send().length===0;});
check('observer throw preserves pending evidence',()=>{const e=new Engine('A');e.owner('p');e.propose(42,facts());const threw=refused(()=>e.send(()=>{e.propose(7,facts(['p']));throw Error('observer');}));return threw&&e.send().length===0;});
console.log(JSON.stringify(results,null,2));if(results.some(x=>!x.pass))process.exitCode=1;
