# Projection identity bounded correction

Private module only; no repository writes. Based on frozen link-equal-adoption helper/loader. Native Link remains the payload interpreter, retaining subject lifetime, field footprint, participation, removal/rekey and inspection handling. Raw notification payload never becomes eligible via helper refresh. Bound source identity includes tree, owned position, entity subject and field. Unsupported root/branch/collection/whole-row declarations fail before callback; ordinary aggregate connections bypass private eligibility and preserve native behavior.

Responsibility attaches only to matching source at enqueue. Projection delivered by native Link binds resulting payload to that source's completed responsibility fact. Net-equal notification skips invoke the same native handler through private responsibility listener; ordinary value subscribers remain suppressed. No physical read used to reconstruct projected payload.

First failures preserved:
- first.log loader literal quoting error (no test executed), corrected wiring.
- first-root-controls-* source identity coalescing failure: n9 then m8 means raw merged meta stamp m; n projection held because original helper selected event stamp. Corrected source-qualified completion queues resolve facts per binding through batch completion event revision; native captured row still determines field payload. No value-equality inference.

Latest checks:
- Original entity payload witness: actual number9, not undefined.
- Original aggregate16/16; original scalar adoption32/32. Ordinary restoration one original assertion passes.
- Root projection-specific8/8 (field isolation, other-source-only); two failures in root terminal/report cases remain in old lifecycle helper, intentionally not repaired here.
- Added projection-controls17/17: aggregate source guards, supported field, native subscriber reentry before Link, pending/ordinary same-field coalescing, sibling inspection, stale lifetime.
- Original entity witness8/11: remaining3 adoption failures belong separate native entity adoption, not this projection implementation. Composition must qualify them later.
- Strict projection.ts tsc passes; not public type/framework qualification.

Retention adjustment: perbinding WeakMap<event,fact> replaces initial event→all-channel snapshot. Disposing removes binding, queue, latest/projected facts and equal listener. No crosssource strong channel map hangs from retained event. Active binding scans remain unqualified cost; helper's existing unrelated lifecycle history is not claimed reclaimed here.

Integration: copy projection.ts; loader.diff shows native hooks. helper.diff shows minimal corresponding identity hooks but lifecycle agent replaces ownership/frame mechanics. Required calls: stampSource before annotate with subject IDs/native knownFootprint; matchingChannels for admission; admitted before lifecycle attach; completeSource at notification batch frontier; native Link project returns exact source fact; isLatest at final send; releaseSource on dispose. Do not restore raw receipt payload refresh.

Replay: Node24.15.0, ENTRY=projection-controls.ts node loader.mjs (directory constants private); original aggregate/scalar/root-controls entries preserved. Named bundle/traces outputs survive each run. No broad suites or production acceptance.
