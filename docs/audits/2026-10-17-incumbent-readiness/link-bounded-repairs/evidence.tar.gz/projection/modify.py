p='/private/tmp/link-repair-projection/private.ts';s=open(p).read();s="import * as projection from './projection';\nexport {bindSource,stampSource,subscribeProjection,deliverEqual} from './projection';\n"+s
s=s.replace('if(key)latest.delete(key);','')
s=s.replace('attach(fact,owner,positions,meta);if(key)latest.set(key,fact);records.set(fact,Object.freeze({fact,payload}));', 'for(const channel of projection.matchingChannels(owner,positions,meta))projection.admitted(channel,fact);attach(fact,owner,positions,meta);')
s=s.replace('latest.get(`${owner}:${position}`)===fact', 'projection.isLatest(channel,fact)').replace('latest.get(`${owner}:${position}`)!==frame.last', '!projection.isLatest(channel,frame.last)')
s=s.replace("if(f.owner!==owner||f.position!==positions?.[0])continue;", "if(!projection.matchingChannels(owner,positions,meta).includes(f.channel))continue;")
s=s.replace('export function dispose(_a:object,_b:object):void{}', 'export function dispose(a:object,_b:object):void{projection.releaseSource(a);}')
s=s.replace("if(isDisposed())throw new SignalTreePublicationError(stage,'disposed');", "if(isDisposed())throw new SignalTreePublicationError(stage,'disposed');\n  if(!projection.supported(channel))throw new SignalTreePublicationError(stage,'unsupported-source');")
s=s.replace(' if(!enabled){original(r);return true;}', ' if(!enabled||!projection.supported(channel)){original(r);return true;}')
s=s.replace('return !enabled||!stack.length', 'return !enabled||!projection.supported(channel)||!stack.length')
s += "\nexport function project(channel:object,meta:unknown,payload:unknown):void{projection.project(channel,evidence(meta),payload);}\nexport function refreshSource(channel:object):Receipt|undefined{return projection.refreshSource(channel) as Receipt|undefined;}\n"
open(p,'w').write(s)
p='/private/tmp/link-repair-projection/loader.mjs';s=open(p).read().replace("const out='/private/tmp/link-equal-adoption';","const out='/private/tmp/link-repair-projection';")
s=s.replace(" s=sub(s,'  let eligible: T = read();'", " s=sub(s,'  let eligible: T = read();'")
s=s.replace("const receipt = research.refresh(registry.id, getOwnedPositionIds(x)?.[0] ?? -1);", "const receipt = research.refreshSource(consequenceKey);")
s=s.replace("'      researchFact = relative.length === 0 ? research.evidence(meta) : undefined;\\n      eligible = applyAtRelativePath(eligible, relative, v);'", "'      researchFact = relative.length === 0 ? research.evidence(meta) : undefined;\\n      eligible = applyAtRelativePath(eligible, relative, v);\\n      research.project(consequenceKey, meta, eligible);'")
needle=" s=sub(s,'  const sendEligible = (): Promise<boolean> =>'"
i=s.index(needle)
s=s[:i]+''' s=sub(s,'  const offSub = notifier.subscribe(\\n    \'**\',', '  research.bindSource(consequenceKey, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, {supported: !collection && !isNodeAccessor(x) && !getRootTree(x) && isWritableLocation(x) && (!entityLocation || entityLocation.fieldKey !== undefined), subject: entityLocation?.subjectId, field: entityLocation?.fieldKey});\\n  const offSub = research.subscribeProjection(notifier, consequenceKey,',1,'bound-projection');
 s=sub(s,'        dirty = true;\\n        observeLink();\\n        return;\\n      }\\n      const position = _pos?.[0];','        researchFact = research.evidence(meta);\\n        research.project(consequenceKey, meta, eligible);\\n        dirty = true;\\n        observeLink();\\n        return;\\n      }\\n      const position = _pos?.[0];',1,'entity-native-projection');
'''+s[i:]
# Delete old annotation insertion; insert after native footprint computed.
a=s.index(" s=sub(s,'    const declaredScopes =");b=s.index('\n',a)
s=s[:a]+''' s=sub(s,'    if (!this.batchingEnabled) {',"    meta = researchAnnotate(researchStampSource(meta, subjectIds, knownFootprint, value, prev), ownerId ?? meta?.ownerId, positionIds, getWriteParticipation(meta) === 'authored', value);\\n    if (!this.batchingEnabled) {",1,'qualified-annotation');
 s=sub(s,'          continue;\\n        }\\n\\n        // Run subscribers synchronously', '          researchDeliverEqual(entry);\\n          continue;\\n        }\\n\\n        // Run subscribers synchronously',1,'equal-projection');'''+s[b:]
s=s.replace("annotate as researchAnnotate, complete as researchComplete", "annotate as researchAnnotate, complete as researchComplete, stampSource as researchStampSource, deliverEqual as researchDeliverEqual")
open(p,'w').write(s)
