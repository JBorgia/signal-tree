import {signalTree,transactions,link} from './packages/kernel/src/index';
import {diagnostics} from 'research-private';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){
 const held:any[]=[];const refs:WeakRef<object>[]=[];
 async function retired(){const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const c:any=link(t.$.y,{set:()=>{}});const p=t.transact(()=>t.$.x(7));refs.push(new WeakRef(t),new WeakRef(c),new WeakRef(p));held.push(c.declare({kind:'dependent',owners:[p]},()=>t.$.y(7)));p.confirm();await tick();await c.settled();c.dispose();t.destroy();}
 await retired();await tick();
 const live=signalTree({y:0},{enhancers:[transactions()]});const liveRef=new WeakRef(live);const c=link(live.$.y,{set:()=>{}});
 for(let i=0;i<16;i++){await new Promise(r=>setTimeout(r,0));globalThis.gc();}
 const collected=refs.map(r=>r.deref()===undefined);const before=diagnostics();const result={collected,livePositive:liveRef.deref()===live,receipt:held[0].read(),countsWhileLive:before,pass:collected.every(Boolean)&&liveRef.deref()===live&&held[0].read().state==='started'};c.dispose();live.destroy();await tick();return {...result,postdrain:diagnostics()};
}
