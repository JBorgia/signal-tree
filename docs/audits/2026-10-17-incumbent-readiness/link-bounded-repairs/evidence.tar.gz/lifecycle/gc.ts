import * as l from './lifecycle';
const tick=async()=>{await new Promise(resolve=>setTimeout(resolve,0));};
export async function run(){
 const held:ReturnType<typeof l.runDeclaration>[]=[];const weak:WeakRef<object>[]=[];
 function retired(){const tree={payload:new Uint8Array(100000)},channel={tree};weak.push(new WeakRef(tree),new WeakRef(channel));l.registerOwnerSource(1,tree);l.registerConnection(channel,{supported:true,report:()=>{void tree;},wake:()=>{void tree;}});const revision={tree};held.push(l.runDeclaration(channel,{kind:'independent'},()=>l.attachRevision(channel,revision,[])));l.started(channel,revision);l.disposeConnection(channel);l.unregisterOwnerSource(1);}
 retired();
 const liveTree={payload:new Uint8Array(100000)},liveChannel={tree:liveTree};const live=new WeakRef(liveTree);l.registerConnection(liveChannel,{supported:true,report:()=>{void liveTree;},wake:()=>{void liveTree;}});
 for(let i=0;i<12;i++){await tick();(globalThis as typeof globalThis & {gc():void}).gc();}
 const result={terminal:held[0].read(),retiredCollected:weak.every(r=>r.deref()===undefined),livePositive:live.deref()===liveTree,diagnostics:l.diagnostics()};l.disposeConnection(liveChannel);return result;
}
