Draft lifecycle interface (pending coordination; no production edits)
- OwnerCell { owner,id,status:'pending'|'confirmed'|'rolled-back'|'abandoned' }, authentic handles WeakMap -> cell, registry only pending sources/cells. Capturing dependency retains cell directly; outcome does not require permanent global history.
- registerOwnerSource(owner,token), ownerTransition(owner,fact), abandonOwnerSource(owner), enroll(handle,owner,id), pendingOwners(), ownerCell(owner,id).
- registerConnection(channel,{isDisposed,report,changed?}), disposeConnection(channel). report calls native reportTreeError under open horizon.
- runDeclaration(channel,input,work) -> receipt; validates before invoking work; frame horizon across nested operations.
- attachRevision(channel,revision,{known:OwnerCell[],unknown?}) during active scopes; revision identity stays opaque projection module object.
- decision(channel,revision) provides declared early permission/pending restriction/fallback; started(channel,revision), supersede(channel,revision), releaseRevision(channel,revision).
- receipt owns detached status cell; completed validation compacts inherited frames into immutable dependency evidence; terminal started/superseded/disposed no longer references connection, payload or frames. Receipt.read closes over only status cell.
