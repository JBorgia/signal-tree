# Operation lifecycle repair: bounded private experiment

Production and original candidate sources unchanged. Frozen inputs and outputs are identified by SHA256SUMS. This is implementation evidence, not independent acceptance or a production qualification.

## Changes

Receipt views detach from callback/frame/connection graphs. Shared synchronous validation horizons retain their actual enclosing obligations until completion. One revision updates all matching receipt views, including nested same-connection declarations. Started receipts are irreversible and release operation proofs. Callback primary errors remain exact; a distinct declaration contradiction reports through native onTreeError while validation remains open, and reporter failure cannot replace the primary.

Authentic handles weakly reference compact terminal dependency cells. Pending source cells retire after native terminal events and synchronous enrollment. Source destruction unregisters storage; it does not manufacture settlement or resolve held dependency waiters. Connection disposal releases source projection, wake closure and operation metadata. Diagnostic logging is bounded to64 detached primitive records.

Projection/loader copied from projection worker and integrated here. Native error reporter, channel-scoped wake registration, and source unregister cleanup are wired. No additional public API introduced.

## First failures and limits

- nested-first.log: outer receipt remained eligible while inner receipt became started for the same revision. Fixed with shared operation views; same test now both started.
- native-first-real.log originally reported postdrain pass using old `records/completed` fields absent in new diagnostics. That oracle was vacuous for those fields and is **not an unchanged retention pass**. Preserve original file; retention-counts.ts explicitly compares every meaningful current strong-registry diagnostic to its baseline. Added projection latest/completed/projected/queued counts. WeakMap completion entries cannot be enumerated; their keys are weak and actual collectibility is tested separately.
- An initial copied loader retained its projection output path and replayed that worker's witness before correction. No source was edited there; existing generated witness outputs were overwritten. Native-first.log belongs to that accidental replay, not this integration.
- Source-level native adoption chronology defect independently discovered elsewhere still prevents accepting the combined candidate. These tests do not resolve that defect.

## Results

- Module six controls pass; separate same-channel nested receipt test passes.
- Unchanged native lifecycle first three scenarios pass: dispose queued, in-flight terminal receipt/waiter, foreign dependency confirmation.
- Eight post-capture-drain churn cycles return all concrete strong registry/projection counts to zero (retention-counts-final.log).
- Native destruction three controls pass, including the preserved known held-waiter distinction requiring explicit connection disposal (destroy-final.log).
- Unchanged composition26 assertions pass, including native secondary contradiction reporting and reporting listener reentry (composition-final.log).
- Root controls pass, including terminal receipt read during getter and reporter throw; expected native ST2025 listener warning retained (root-controls.log).
- Native held terminal receipt GC: tree, connection and transaction WeakRefs all collected while receipt remains usable/started. Separate live-tree positive control remains alive; its live source/connection/projection counters are1, then all zero after disposal/destruction (native-gc-final.log). GC is sampled evidence under Node's exposed GC, not universal timing guarantee.
- Strict TypeScript private helper and imported lifecycle/projection modules pass (helper-types-final.log). This does not qualify esbuild-transformed native source types.

## Replay

From any directory with Node24.15.0:

```sh
ENTRY=witness.ts node /private/tmp/link-repair-lifecycle/loader.mjs
ENTRY=retention-counts.ts node /private/tmp/link-repair-lifecycle/loader.mjs
ENTRY=destroy.ts node /private/tmp/link-repair-lifecycle/loader.mjs
ENTRY=composition.ts node /private/tmp/link-repair-lifecycle/loader.mjs
ENTRY=root-controls.ts node /private/tmp/link-repair-lifecycle/loader.mjs
ENTRY=native-gc.ts node --expose-gc /private/tmp/link-repair-lifecycle/loader.mjs
node /Users/jonathanborgia/code/signaltree/node_modules/typescript/bin/tsc --noEmit --strict --target ES2022 --module ESNext --moduleResolution bundler --skipLibCheck /private/tmp/link-repair-lifecycle/private.ts
```

The loader's bundle/traces/receipts outputs are overwritten per invocation; named saved logs above preserve each result. No broad suite run.
