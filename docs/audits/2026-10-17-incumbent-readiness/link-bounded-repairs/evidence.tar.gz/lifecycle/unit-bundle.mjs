// ../../../../private/tmp/link-repair-lifecycle/lifecycle.ts
var sources = /* @__PURE__ */ new Map();
var authentic = /* @__PURE__ */ new WeakMap();
var pending = /* @__PURE__ */ new Set();
var wakeQueued = false;
function registerOwnerSource(owner, token) {
  if (!sources.has(owner)) sources.set(owner, { token, cells: /* @__PURE__ */ new Map() });
}
function ownerCell(owner, id) {
  return sources.get(owner)?.cells.get(id);
}
function wake() {
  if (wakeQueued) return;
  wakeQueued = true;
  queueMicrotask(() => {
    wakeQueued = false;
    refreshAll();
    for (const c of [...connections.values()]) c.wake();
  });
}
function ownerTransition(owner, event) {
  const source = sources.get(owner);
  if (!source) return;
  let cell = source.cells.get(event.transactionId);
  if (!cell) {
    if (event.kind !== "opened" && event.kind !== "staged") return;
    cell = { owner, id: event.transactionId, outcome: "pending" };
    source.cells.set(cell.id, cell);
  }
  if (event.kind === "opened" || event.kind === "staged") {
    if (cell.outcome === "pending") pending.add(cell);
    return;
  }
  if (!["confirmed", "rolled-back", "abandoned"].includes(event.kind)) return;
  const outcome = event.kind;
  if (cell.outcome !== "pending" && cell.outcome !== outcome) throw Error("Terminal publication dependency outcome reversed");
  cell.outcome = outcome;
  pending.delete(cell);
  const retired = cell;
  queueMicrotask(() => {
    if (source.cells.get(retired.id) === retired && retired.outcome !== "pending") source.cells.delete(retired.id);
  });
  wake();
}
function abandonOwnerSource(owner) {
  const source = sources.get(owner);
  if (!source) return;
  for (const cell of source.cells.values()) pending.delete(cell);
  source.cells.clear();
  sources.delete(owner);
  wake();
}
function enroll(handle, owner, id) {
  if (owner !== void 0) {
    const cell = ownerCell(owner, id);
    if (cell) authentic.set(handle, cell);
  }
  return handle;
}
var connections = /* @__PURE__ */ new Map();
var stack = [];
var reporting = false;
var SignalTreePublicationError = class extends Error {
  constructor(stage, reason, options) {
    super(`Declaration invalid: ${reason}; writes may remain`, options);
    this.stage = stage;
    this.reason = reason;
  }
  code = "SIGNALTREE_PUBLICATION_DECLARATION_INVALID";
};
function registerConnection(channel, options) {
  if (connections.has(channel)) throw Error("Publication connection already registered");
  connections.set(channel, { ...options, ops: /* @__PURE__ */ new Map(), disposed: false });
}
function state(view, value) {
  if (["started", "superseded", "disposed", "no-write"].includes(view.value.state)) return;
  view.value = Object.freeze(value);
}
function effective(frame) {
  const all = [...frame.parents, frame];
  return { owners: [...new Set(all.flatMap((f) => f.owners))], unknown: all.some((f) => f.unknown), invalid: all.some((f) => f.invalid) };
}
function setOperationState(op, value) {
  for (const view of op.views) state(view, value);
}
function refresh(op) {
  if (op.started) return;
  if (op.frames.size) {
    for (const view of op.views) state(view, { state: "validating" });
    return;
  }
  const p = op.proof;
  if (!p) return;
  if (p.invalid || p.unknown) {
    setOperationState(op, { state: "conservative", reason: p.invalid ? "invalid-declaration" : "unknown" });
    return;
  }
  if (p.owners.some((x) => x.outcome === "rolled-back" || x.outcome === "abandoned")) {
    setOperationState(op, { state: "conservative", reason: "rejected-dependency" });
    return;
  }
  setOperationState(op, p.owners.some((x) => x.outcome === "pending") ? { state: "held", reason: "pending-dependency" } : { state: "eligible", basis: "declared" });
}
function refreshAll() {
  for (const c of connections.values()) for (const op of c.ops.values()) refresh(op);
}
function attachRevision(channel, revision, known, unknown = false) {
  const c = connections.get(channel);
  if (!c || c.disposed) return;
  const matches = stack.filter((f) => f.channel === channel);
  if (matches.length === 0) return;
  const inherited = stack.flatMap((f) => f.owners);
  if (known.some((owner) => !inherited.includes(owner))) for (const f of stack) f.invalid = true;
  let op = c.ops.get(revision);
  if (!op) {
    op = { revision, frames: /* @__PURE__ */ new Set(), views: /* @__PURE__ */ new Set(), started: false, surviving: false };
    c.ops.set(revision, op);
  }
  for (const f of matches) {
    if (f.last && f.last !== revision) {
      const old = c.ops.get(f.last);
      if (old) {
        old.views.delete(f.view);
        if (!old.views.size) c.ops.delete(f.last);
      }
    }
    f.last = revision;
    f.unknown ||= unknown || stack.some((x) => x.unknown);
    for (const owner of [...inherited, ...known]) if (!f.owners.includes(owner)) f.owners.push(owner);
    op.frames.add(f);
    op.views.add(f.view);
    f.ops.add(op);
  }
}
function started(channel, revision, basis = "declared") {
  const op = connections.get(channel)?.ops.get(revision);
  if (!op) return;
  op.started = true;
  op.surviving = basis === "surviving";
  setOperationState(op, { state: "started", basis });
  op.proof = void 0;
  op.frames.clear();
  op.views.clear();
  connections.get(channel)?.ops.delete(revision);
}
function disposeConnection(channel) {
  const c = connections.get(channel);
  if (!c) return;
  c.disposed = true;
  for (const op of c.ops.values()) if (!op.started) setOperationState(op, { state: "disposed" });
  c.ops.clear();
  connections.delete(channel);
}
function finish(h) {
  const operations = /* @__PURE__ */ new Set();
  for (const f of h.frames) {
    if (!f.last) state(f.view, { state: f.connection.disposed ? "disposed" : "no-write" });
    for (const op of f.ops) operations.add(op);
  }
  for (const op of operations) {
    const proofs = [...op.frames].map(effective);
    op.proof = { owners: [...new Set(proofs.flatMap((p) => p.owners))], unknown: proofs.some((p) => p.unknown), invalid: proofs.some((p) => p.invalid) };
    op.frames.clear();
    refresh(op);
  }
  for (const f of h.frames) f.ops.clear();
  h.frames.clear();
}
function runDeclaration(channel, input, work) {
  const c = connections.get(channel);
  if (!c || c.disposed) throw new SignalTreePublicationError("before-callback", "disposed");
  if (!c.supported) throw new SignalTreePublicationError("before-callback", "unsupported-source");
  const view = { value: Object.freeze({ state: "validating" }) };
  const receipt = makeReceipt(view);
  const h = stack.at(-1)?.horizon ?? { frames: /* @__PURE__ */ new Set(), open: 0 };
  const frame = { channel, connection: c, parents: [...stack], horizon: h, owners: [], unknown: true, invalid: false, view, ops: /* @__PURE__ */ new Set() };
  h.frames.add(frame);
  h.open++;
  stack.push(frame);
  let stage = "before-callback";
  let thrown = false;
  let primary;
  try {
    if (!input || typeof input !== "object" || typeof work !== "function") throw new SignalTreePublicationError(stage, "malformed");
    const d = input;
    const kind = d.kind;
    if (kind !== "independent" && kind !== "dependent" && kind !== "unknown") throw new SignalTreePublicationError(stage, "malformed");
    const owners = [];
    if (kind === "dependent") {
      const list = d.owners;
      if (!Array.isArray(list)) throw new SignalTreePublicationError(stage, "malformed");
      for (const handle of list) {
        const cell = handle && typeof handle === "object" ? authentic.get(handle) : void 0;
        if (!cell || cell.outcome === "rolled-back" || cell.outcome === "abandoned") throw new SignalTreePublicationError(stage, "unavailable-owner");
        owners.push(cell);
      }
    }
    frame.owners = [.../* @__PURE__ */ new Set([...frame.owners, ...owners])];
    frame.unknown = kind === "unknown" || frame.ops.size > 0;
    stage = "after-callback";
    let result;
    try {
      result = work();
    } catch (error) {
      thrown = true;
      primary = error;
    }
    if (result !== null && (typeof result === "object" || typeof result === "function")) {
      if (typeof result.then === "function") throw new SignalTreePublicationError(stage, "async-callback");
    }
    if (frame.invalid) throw new SignalTreePublicationError(stage, "contradiction");
    if (thrown) throw primary;
    return receipt;
  } catch (error) {
    for (const f of stack) f.invalid = true;
    if (thrown) {
      if (error !== primary && !reporting) {
        reporting = true;
        try {
          c.report(error);
        } catch {
        } finally {
          reporting = false;
        }
      }
      throw primary;
    }
    if (error instanceof SignalTreePublicationError) throw error;
    throw new SignalTreePublicationError(stage, "validation-threw", { cause: error });
  } finally {
    stack.pop();
    h.open--;
    if (h.open === 0) finish(h);
    wake();
  }
}
function makeReceipt(view) {
  return Object.freeze({ read: () => view.value });
}
function diagnostics() {
  let cells = 0, operations = 0;
  for (const s of sources.values()) cells += s.cells.size;
  for (const c of connections.values()) operations += c.ops.size;
  return { sources: sources.size, pendingOwners: pending.size, ownerCells: cells, connections: connections.size, operations, activeFrames: stack.length };
}

// ../../../../private/tmp/link-repair-lifecycle/unit.ts
var tick = async () => {
  for (let i = 0; i < 20; i++) await Promise.resolve();
};
async function run() {
  const rows = [];
  const check = (name, a2, e) => rows.push({ name, actual: a2, expected: e, pass: JSON.stringify(a2) === JSON.stringify(e) });
  const a = {}, b = {};
  const reports = [];
  registerConnection(a, { supported: true, report: (e) => reports.push(e), wake: () => {
  } });
  registerConnection(b, { supported: true, report: (e) => reports.push(e), wake: () => {
  } });
  const rev = {};
  const r = runDeclaration(a, { kind: "independent" }, () => attachRevision(a, rev, []));
  started(a, rev);
  let inside;
  runDeclaration(b, { kind: "independent" }, () => {
    inside = r.read().state;
  });
  check("started monotonic", inside, "started");
  let child;
  try {
    runDeclaration(a, { kind: "independent" }, () => {
      child = runDeclaration(b, { kind: "independent" }, () => attachRevision(b, {}, []));
      return Promise.resolve();
    });
  } catch {
  }
  check("nested failure conservative", child.read().state, "conservative");
  registerOwnerSource(1, {});
  ownerTransition(1, { kind: "opened", transactionId: 1 });
  const owner = ownerCell(1, 1);
  const handle = enroll({}, 1, 1);
  const frozen = Object.freeze({ x: 1 });
  let thrown;
  try {
    runDeclaration(a, { kind: "independent" }, () => {
      attachRevision(a, {}, [owner]);
      throw frozen;
    });
  } catch (e) {
    thrown = e;
  }
  check("primary", thrown === frozen, true);
  check("secondary", reports.length, 1);
  ownerTransition(1, { kind: "confirmed", transactionId: 1 });
  await tick();
  const terminal = runDeclaration(b, { kind: "dependent", owners: [handle] }, () => attachRevision(b, {}, []));
  check("retained authentic terminal handle", terminal.read().state, "eligible");
  disposeConnection(a);
  disposeConnection(b);
  abandonOwnerSource(1);
  await tick();
  check("cleanup", diagnostics(), { sources: 0, pendingOwners: 0, ownerCells: 0, connections: 0, operations: 0, activeFrames: 0 });
  return rows;
}
export {
  run
};
