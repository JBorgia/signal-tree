import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const base='/private/tmp/link-repair-combined';
const cases=JSON.parse(readFileSync(base+'/cases.json','utf8'));
const template=readFileSync(base+'/combined-loader.mjs','utf8');
const run=process.argv[2]; if(!run||!/^[a-z0-9-]+$/.test(run))throw Error('provide unique run name');
const dir=base+'/'+run;mkdirSync(dir);const summary=[];
for(const [name,src]of Object.entries(cases)){
 const out=dir+'/'+name;mkdirSync(out);
 const s=template.replace(/const out='[^']+';/,`const out='${out}';`);
 writeFileSync(out+'/loader.mjs',s);copyFileSync(src,out+'/witness.ts');
 const r=spawnSync(process.execPath,[out+'/loader.mjs'],{encoding:'utf8',env:{...process.env,ENTRY:'witness.ts'},timeout:120000,maxBuffer:20e6});
 writeFileSync(out+'/run.log',(r.stdout??'')+(r.stderr??''));
 let results;try{results=JSON.parse(readFileSync(out+'/traces.json','utf8'));}catch{}
 const assertions=[];function walk(v){if(!v||typeof v!=='object')return;if(typeof v.pass==='boolean')assertions.push(v);for(const x of Object.values(v))if(x&&typeof x==='object')walk(x);}walk(results);
 const misuse=assertions.filter(a=>String(a.name??'').includes('MISUSE'));
 const ordinary=assertions.filter(a=>!misuse.includes(a));
 const row={name,source:src,sourceSha256:createHash('sha256').update(readFileSync(src)).digest('hex'),exit:r.status,error:r.error?.message,passes:ordinary.filter(a=>a.pass).length,failures:ordinary.filter(a=>!a.pass),misuse:misuse.length,resultsAvailable:!!results};
 summary.push(row);writeFileSync(dir+'/summary.json',JSON.stringify(summary,null,2));console.log(name,row.exit,row.passes,row.failures.length,row.misuse);
}
