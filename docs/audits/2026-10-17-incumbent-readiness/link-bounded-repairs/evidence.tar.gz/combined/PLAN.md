# Combined focused qualification preregistration

Source9b8dd393, production87f6831f; three disposable components only. Freeze exact
inputs before each test run, preserve first failing logs and bundle/source hashes.
No original test edited. No broad suites/costs until focused gate survives review.

Run unchanged: qualification entity witness-original, aggregate, restoration,
lifecycle witness/destroy, composition/source-guard; prior scalar witness, slot
faults, frame controls, overlap, root admission; native-boundary witness (hidden
omission counted separately as misuse), extra, nested-original, independent controls.
Record each ordinary assertion, unexpected throw, expected misuse separately.
Historical32/34 remains old evidence; no silently revised expectations.

Add root independent discriminators: same collection distinct row/field cannot
share declaration authority; one connection declaration that authors only another
source must not bless it; terminal receipt remains terminal during later invalid
getter scope; primary primitive/frozen errors survive throwing diagnostic listener.
Useful publication and follow-up settled progress required, never output suppression
alone. Original field adoption expected7 after rollback remains unchanged.

Lifecycle component additionally measures internal counters across repeated drain
cycles and WeakRef collection with retained terminal receipts. GC probes use fresh
processes --expose-gc, event-loop turns between collection attempts; bounded retries
fixed before execution. A nondeterministic no-collection result is unresolved, not
proof of leak; positive reachability and deliberately live obligations are controls.

Component source tests are not integration acceptance. Combined focused checks and
independent source review must pass before affected Nx/types; subsequent gates do
not inherit another source revision's results.

GC diagnostic boundary after first fixed16-turn entity graph probe: first tree and
its current payload not collected, other18 targets collected. All current helper
strong counts zero. No leak inferred solely from failure to collect. One control
will omit keeping returned receipts, using the same4 cycles and16 collection turns;
this tests whether retaining receipts is necessary for the observed retention.
No additional repetitions for favorable outcomes. Preserve both results.
