import {entityPatch} from '/private/tmp/link-repair-combined/entity-patch.mjs';
import {patch} from '/private/tmp/link-equal-adoption/patch.mjs';
import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,dirname} from 'node:path';
const root='/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree';
const out='/private/tmp/link-repair-combined/focused-first/source-guard';
const {build}=createRequire(resolve(root,'package.json'))('esbuild');
const hashes={}; const counts={}; const baseline=process.env.BASELINE==='1'; const prefix=(process.env.TARGETED==='1'?'targeted-':'')+(baseline?'baseline-':'');
const hash=s=>createHash('sha256').update(s).digest('hex');
function sub(s,from,to,n,name){const count=s.split(from).length-1;counts[name]=count;if(count!==n)throw Error(`${name}: ${count} != ${n}`);return s.split(from).join(to);}
const result=await build({stdin:{contents:readFileSync(resolve(out,process.env.ENTRY || (process.env.TARGETED==='1'?'targeted.ts':'witness.ts')),'utf8'),loader:'ts',resolveDir:root},bundle:true,write:false,platform:'node',format:'esm',target:'node24',plugins:[{name:'private-link-research',setup(b){
 b.onResolve({filter:/^research-private$/},()=>({path:'/private/tmp/link-repair-combined/private.ts'}));
 b.onLoad({filter:/\/packages\/kernel\/src\/.*\.ts$/},({path})=>{
 const original=readFileSync(path,'utf8');let s=baseline?original:entityPatch(patch(original,path),path);
 if(!baseline && path.endsWith('/link.ts')){
 s=`import * as research from 'research-private';\n`+s;
 s=sub(s,'  let eligible: T = read();','  let eligible: T = read();\n  let researchFact: ReturnType<typeof research.evidence>; ',1,'eligible');
 s=sub(s,'    external(() => write(value));','    research.acquire(registry.id, getOwnedPositionIds(x)?.[0] ?? -1, () => external(() => write(value)));',1,'acquire');
 s=sub(s,'      eligible = applyAtRelativePath(eligible, relative, v);','      researchFact = relative.length === 0 ? research.evidence(meta) : undefined;\n      eligible = applyAtRelativePath(eligible, relative, v);\n      researchFact = research.project(consequenceKey, meta, eligible);',1,'scalar-revision');
 s=sub(s,'scheduleDurableConsequence({','research.admit(scheduleDurableConsequence, researchFact, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, consequenceKey, {',2,'admission');
 s=sub(s,"  const offSub = notifier.subscribe(\n    '**',", '  research.bindSource(consequenceKey, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, {supported: !collection && !isNodeAccessor(x) && !getRootTree(x) && isWritableLocation(x) && (!entityLocation || entityLocation.fieldKey !== undefined), subject: entityLocation?.subjectId, field: entityLocation?.fieldKey}, error => reportTreeError({error, operation: \'link:declare\', treeId: registry.id, path: ownerPath || undefined}));\n  const offSub = research.subscribeProjection(notifier, consequenceKey,',1,'bound-projection');
 s=sub(s,'        dirty = true;\n        observeLink();\n        return;\n      }\n      const position = _pos?.[0];','        researchFact = research.evidence(meta);\n        researchFact = research.project(consequenceKey, meta, eligible);\n        dirty = true;\n        observeLink();\n        return;\n      }\n      const position = _pos?.[0];',1,'entity-native-projection');
 s=sub(s,'  const sendEligible = (): Promise<boolean> =>',`  const researchHold = (): void => {
    if (held.size > 0 || disposed) return;
    let resolve!: () => void;
    const promise = new Promise<void>((r) => (resolve = r));
    held.add({promise, resolve});
  };
  const sendEligible = (): Promise<boolean> =>`,1,'actual-held-visibility');
 s=sub(s,'          const now = entityProjection','          const researchTicket = researchFact;\n          const now = entityProjection',1,'capture-ticket');
 s=sub(s,'          research.admit(scheduleDurableConsequence, researchFact, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, consequenceKey, {','          const researchAdmitted = research.admit(scheduleDurableConsequence, researchTicket, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, consequenceKey, {',1,'send-result');
 s=sub(s,'          // Held behind an open scope: the send waits for permission.',`          if (!researchAdmitted) { researchHold(); cancel(); }
          // Held behind an open scope: the send waits for permission.`,1,'denied-send-drain');
 s=sub(s,'              observeLink();\n              if (disposed) {',`              try { observeLink(); }
              catch (error) { sending = false; throw error; }
              if (!disposed && !research.allowed(researchTicket, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, consequenceKey)) {
                sending = false;
                researchHold();
                cancel();
                return;
              }
              if (disposed) {`,1,'post-observer-revalidate');
 s=sub(s,'  const offFlush = notifier.onFlush?.(flushOutbound);', `  const researchRefresh = (): void => {
    const receipt = research.refreshSource(consequenceKey);
    if (!receipt || receipt.fact === researchFact) return;
    researchFact = receipt.fact; eligible = receipt.payload as T; dirty = true;
  };
  const offFlush = notifier.onFlush?.(() => { researchRefresh(); flushOutbound(); });
  const offResearchEligibility = research.onEligibility(registry.id, () => {
    if (!disposed) researchRefresh();
    if (disposed || held.size === 0 || research.pendingDecision(researchFact, consequenceKey)) return;
    dirty = true; flushOutbound();
  }, consequenceKey);`,1,'eligibility-wake');
 s=sub(s,'                Promise.resolve(endpoint.set?.(now)).then(', '                research.started(researchTicket, consequenceKey);\n                Promise.resolve(endpoint.set?.(now)).then(',1,'started-receipt');
 s=sub(s,'  return {\n    async retrieve() {', `  return {\n    declare: (declaration: unknown, work: () => unknown) => research.declare(consequenceKey, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, declaration, work, () => disposed),\n    async retrieve() {`,1,'declaration-surface');
 s=sub(s,'    disposed = true;','    disposed = true;\n    offResearchEligibility(); research.dispose(consequenceKey, sendConsequenceKey);',1,'dispose');
 }
 if(!baseline && path.endsWith('/path-notifier.ts')){
 s=`import {annotate as researchAnnotate, complete as researchComplete, stampSource as researchStampSource, deliverEqual as researchDeliverEqual} from 'research-private';\n`+s;
 s=sub(s,'    const meta =\n      ownerId === undefined','    let meta =\n      ownerId === undefined',1,'notifier-meta');
 s=sub(s,'    if (!this.batchingEnabled) {',"    meta = researchAnnotate(researchStampSource(meta, subjectIds, knownFootprint, value, prev), ownerId ?? meta?.ownerId, positionIds, getWriteParticipation(meta) === 'authored', value);\n    if (!this.batchingEnabled) {",1,'qualified-annotation');
 s=sub(s,'          continue;\n        }\n\n        // Run subscribers synchronously', '          researchDeliverEqual(entry);\n          continue;\n        }\n\n        // Run subscribers synchronously',1,'equal-projection');
 s=sub(s,'    this.pendingFlush = false;\n\n    for (const slot of toNotify)', '    this.pendingFlush = false;\n    for (const slot of toNotify) for (const entry of (Array.isArray(slot) ? slot : [slot])) researchComplete(entry.meta, entry.ownerId ?? entry.meta?.ownerId, entry.positionIds);\n\n    for (const slot of toNotify)',1,'responsibility-completed-frontier');
 }
 if(!baseline && path.endsWith('/transactions.ts')){
 s=`import * as research from 'research-private';\n`+s;
 s=sub(s,'  const publishLifecycle = (fact: TransactionLifecycleFact): void => {',`  if (lifecycleRegistry) research.register(lifecycleRegistry.id, {read: () => ({pending: [...lifecycleViews.values()]})}, transactionOwnerToken);
  const publishLifecycle = (fact: TransactionLifecycleFact): void => {
    research.transition(lifecycleRegistry?.id, fact);`,1,'lifecycle-record');
 s=sub(s,'      destroyed = true;', '      destroyed = true;\n      research.unregister(lifecycleRegistry?.id);',1,'source-unregister');
 s=sub(s,'decorateHandle(handle, pendingTurnId)', 'research.enroll(decorateHandle(handle, pendingTurnId), lifecycleRegistry?.id, transactionId)',2,'authentic-owner-enrollment');
 s=sub(s,'    retireLifecycleView(transactionId);\n    lifecycleSequence++;',`    research.transition(lifecycleRegistry?.id, {kind: 'abandoned', transactionId});
    retireLifecycleView(transactionId);
    lifecycleSequence++;`,1,'lifecycle-abandoned');
 }
 if(path.endsWith('/link.ts')||path.endsWith('/path-notifier.ts')||path.endsWith('/tree-scalar-slot-runtime.ts')||path.endsWith('/location-runtime.ts')||path.endsWith('/tree-scalar-leaf-runtime.ts')||path.endsWith('/native-tree-scalar-leaf-runtime.ts')) { writeFileSync(resolve(out,prefix+path.split('/').at(-1)+'.original'),original);writeFileSync(resolve(out,prefix+path.split('/').at(-1)+'.loaded'),s); }
 hashes[path.slice(root.length+1)]={original:hash(original),loaded:hash(s)};return {contents:s,loader:'ts',resolveDir:dirname(path)};
 });
}}]});
writeFileSync(resolve(out,prefix+'receipts.json'),JSON.stringify({counts,hashes},null,2));
writeFileSync(resolve(out,prefix+'bundle.mjs'),result.outputFiles[0].text);
const {run}=await import(resolve(out,prefix+'bundle.mjs'));
const results=await run();
const name=(process.env.ENTRY||'witness.ts').replace('.ts','');writeFileSync(resolve(out,name+'-bundle.mjs'),result.outputFiles[0].text);writeFileSync(resolve(out,name+'-traces.json'),JSON.stringify(results,null,2));
writeFileSync(resolve(out,prefix+'traces.json'),JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
