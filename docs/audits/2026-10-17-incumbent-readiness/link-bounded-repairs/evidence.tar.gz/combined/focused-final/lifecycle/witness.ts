import {signalTree,transactions,link} from './packages/kernel/src/index';
import {diagnostics} from 'research-private';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];
{
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];const c:any=link(t.$.y,{set:v=>sent.push(v)});const p=t.transact(()=>t.$.x(7));const r=c.declare({kind:'independent'},()=>t.$.y(1));c.dispose();await tick();await c.settled();rows.push({scenario:'dispose-queued',sent:[...sent],receipt:r.read(),pass:sent.length===0&&r.read().state==='disposed'});p.rollback();t.destroy();await tick();
}
{
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});let ack!:()=>void;const sent:number[]=[];const c:any=link(t.$.y,{set:v=>{sent.push(v);return new Promise<void>(r=>ack=r);}});const p=t.transact(()=>t.$.x(7));const r=c.declare({kind:'independent'},()=>t.$.y(1));await tick();const before=r.read();let during:any;c.declare({kind:'independent'},()=>{during=r.read();});const after=r.read();c.dispose();let settled=false;void c.settled().then(()=>settled=true);await tick();rows.push({scenario:'dispose-inflight-and-receipt',sent:[...sent],before,during,after,settledBeforeAck:settled,pass:sent.length===1&&before.state==='started'&&during.state==='started'&&after.state==='started'&&settled});ack();await tick();p.rollback();t.destroy();await tick();
}
{
 const a=signalTree({x:0},{enhancers:[transactions()]});const b=signalTree({y:0},{enhancers:[transactions()]});const p=a.transact(()=>a.$.x(7));const sent:number[]=[];const c:any=link(b.$.y,{set:v=>sent.push(v)});c.declare({kind:'dependent',owners:[p]},()=>b.$.y(7));await tick();const held=[...sent];p.confirm();await tick();await c.settled();rows.push({scenario:'foreign-confirm',held,sent:[...sent],pass:held.length===0&&JSON.stringify(sent)==='[7]'});c.dispose();a.destroy();b.destroy();await tick();
}
const baseline=diagnostics();const checkpoints:any[]=[];
for(let i=0;i<8;i++){
 const a=signalTree({x:0},{enhancers:[transactions()]});const b=signalTree({y:0},{enhancers:[transactions()]});const p=a.transact(()=>a.$.x(7));const c:any=link(b.$.y,{set:()=>{}});c.declare({kind:'dependent',owners:[p]},()=>b.$.y(7));p.confirm();await tick();await c.settled();c.dispose();a.destroy();b.destroy();await tick();checkpoints.push(diagnostics());
}
await tick();const final=diagnostics();rows.push({scenario:'postdrain-retention',baseline,checkpoints,final,liveConnections:0,pendingOwners:0,inflight:0,heldReceipts:0,pass:final.sources===baseline.sources&&final.records===baseline.records&&final.completed===baseline.completed});return rows;}
