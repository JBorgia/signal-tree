import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const results:any[]=[];
for(const scenario of ['return-getter','input-getter','foreign-invalid','nested-success','inspection-aba','serialized','acquire-equal','same-value-authored']){
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const f=signalTree({x:0},{enhancers:[transactions()]}); const sent:number[]=[],other:number[]=[];let ack:(()=>void)|undefined;let remote=99;
 const c:any=link(t.$.y,{get:()=>remote,set:(v:number)=>{sent.push(v);if(scenario==='serialized'&&sent.length===1)return new Promise<void>(r=>ack=r);}});const d:any=link(t.$.y,{set:(v:number)=>{other.push(v);}});
 const checks:any[]=[];const eq=(name:string,actual:unknown,expected:unknown)=>checks.push({name,actual:structuredClone(actual),expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});let p:any;let receipt:any;
 try{
 if(['return-getter','input-getter','foreign-invalid','nested-success'].includes(scenario)){
  p=(scenario==='foreign-invalid'?f:t).transact(()=> (scenario==='foreign-invalid'?f:t).$.x(7));let reason:unknown;
  try{
   const declaration=scenario==='input-getter'?{get kind(){receipt=d.declare({kind:'independent'},()=>t.$.y(9));throw Error('input getter');}}:{kind:scenario==='foreign-invalid'?'dependent':'independent',owners:[p]};
   c.declare(declaration,()=>{receipt=d.declare({kind:'independent'},()=>t.$.y(9));if(scenario!=='nested-success')return {get then(){t.$.y(10);throw Error('return getter');}};});
  }catch(e){reason=(e as any).reason;}
  await tick();eq('writes survive',t.$.y(),scenario==='input-getter'||scenario==='nested-success'?9:10);eq('inner boundary',other,scenario==='nested-success'?[9]:[]);eq('outer boundary',sent,scenario==='nested-success'?[9]:[]);eq('validation diagnosis',reason,scenario==='nested-success'?undefined:'validation-threw');p.confirm();await tick();eq('conservative eventually publishes',sent.at(-1),t.$.y());
 }else if(scenario==='inspection-aba'){
  p=t.transact(()=>t.$.x(7));c.declare({kind:'dependent',owners:[p]},()=>t.$.y(7));await tick();withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();eq('inspection held',sent,[]);p.rollback();await tick();eq('reject preserves ordinary',sent,[7]);withWriteContext({participation:'inspection'},()=>t.$.y(0));await tick();eq('inspection exit not ordinary',sent,[7]);t.$.y(8);await tick();eq('new ordinary progresses',sent,[7,8]);
 }else if(scenario==='serialized'){
  p=t.transact(()=>t.$.x(7));c.declare({kind:'independent'},()=>t.$.y(7));await tick();eq('started first',sent,[7]);withWriteContext({participation:'inspection'},()=>t.$.y(99));c.declare({kind:'independent'},()=>t.$.y(8));await tick();eq('corrective waits',sent,[7]);ack!();await tick();eq('corrective ordinary',sent,[7,8]);p.rollback();
 }else if(scenario==='acquire-equal'){
  withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();await c.retrieve();await tick();sent.length=0;t.$.y(0);await tick();eq('equal acquisition preserves return write',sent,[0]);
 }else{
  p=t.transact(()=>t.$.x(7));withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();receipt=c.declare({kind:'independent'},()=>t.$.y(99));await tick();eq('equal no write does not promote inspection',sent,[]);eq('no write receipt',receipt.read().state,'no-write');p.rollback();await tick();eq('inspection never eligible',sent,[]);
 }
 }catch(e){checks.push({name:'unexpected',pass:false,error:String(e)});}finally{c.dispose();d.dispose();t.destroy();f.destroy();await tick();}results.push({scenario,checks,sent,other});
}return results;}
