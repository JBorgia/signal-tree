import {signalTree,transactions,link} from './packages/kernel/src/index';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const rows:any[]=[];
{
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];const c:any=link(t.$.y,{set:v=>sent.push(v)});t.$.y(1);t.destroy();await tick();rows.push({scenario:'tree-destroy-queued',sent:[...sent],pass:sent.length===0||JSON.stringify(sent)==='[1]',contract:'zero or one predestroy value allowed'});c.dispose();await tick();
}
{
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});let ack!:()=>void;const sent:number[]=[];const c:any=link(t.$.y,{set:v=>{sent.push(v);return new Promise<void>(r=>ack=r);}});c.declare({kind:'independent'},()=>t.$.y(1));await tick();let settled=false;void c.settled().then(()=>settled=true);t.destroy();await tick();const before=settled;ack();await tick();rows.push({scenario:'tree-destroy-inflight',sent:[...sent],beforeAck:before,afterAck:settled,pass:!before&&settled});c.dispose();
}
{
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];const c:any=link(t.$.y,{set:v=>sent.push(v)});const p=t.transact(()=>t.$.x(7));c.declare({kind:'dependent',owners:[p]},()=>t.$.y(1));await tick();let settled=false;void c.settled().then(()=>settled=true);t.destroy();await tick();const afterDestroy=settled;c.dispose();await tick();rows.push({scenario:'tree-destroy-held',sent:[...sent],afterDestroy,afterDispose:settled,pass:settled,contract:'known held-waiter gap; explicit disposal must release'});
}
return rows;}
