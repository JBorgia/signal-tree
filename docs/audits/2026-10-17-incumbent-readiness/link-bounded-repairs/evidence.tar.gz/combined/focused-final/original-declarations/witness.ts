import {signalTree,transactions,link} from './packages/kernel/src/index';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const rows:unknown[]=[];
 for(const scenario of ['independent','dependent-confirm','dependent-reject','unknown','fake','no-write','noop-owner','two-connections','nested-unknown','then-getter','async','attribution','ABA','disposed','callback-throw','saved-misuse']){
 const t=signalTree({x:0,y:0,z:0},{enhancers:[transactions()]});const sent:number[]=[];const other:number[]=[];const c:any=link(t.$.y,{set:v=>{sent.push(v);}});const d:any=link(t.$.y,{set:v=>{other.push(v);}});const checks:unknown[]=[];const eq=(a:unknown,e:unknown,n:string)=>checks.push({name:n,actual:JSON.parse(JSON.stringify(a)),expected:JSON.parse(JSON.stringify(e)),pass:JSON.stringify(a)===JSON.stringify(e)});let receipt:any;
 try{const noop=t.transact(()=>{});noop.confirm();const p=t.transact(()=>t.$.x(7));
 if(scenario==='independent'||scenario==='two-connections'||scenario==='saved-misuse'){receipt=c.declare({kind:'independent'},()=>t.$.y(scenario==='saved-misuse'?t.$.x():7));await tick();eq(sent,[7],scenario==='saved-misuse'?'MISUSE hidden omission leaks, not safety pass':'independent progresses');if(scenario==='two-connections')eq(other,[],'other connection not blessed');}
 if(scenario==='dependent-confirm'||scenario==='dependent-reject'){receipt=c.declare({kind:'dependent',owners:[p]},()=>t.$.y(t.$.x()));await tick();eq(sent,[],'pending held');if(scenario==='dependent-confirm')p.confirm();else p.rollback();await tick();eq(sent,[7],scenario==='dependent-confirm'?'confirm releases':'fresh surviving truth after reject');}
 if(scenario==='unknown'){receipt=c.declare({kind:'unknown'},()=>t.$.y(7));await tick();eq(sent,[],'unknown held');}
 if(scenario==='fake'){let called=false;try{c.declare({kind:'dependent',owners:[{}]},()=>{called=true;});}catch(e){eq((e as any).reason,'unavailable-owner','fake owner rejected');}eq(called,false,'callback not run');}
 if(scenario==='no-write'){t.$.y(7);await tick();receipt=c.declare({kind:'independent'},()=>{});await tick();eq(sent,[],'no write cannot bless old');eq(receipt.read().state,'no-write','no-write receipt');}
 if(scenario==='noop-owner'){receipt=c.declare({kind:'dependent',owners:[noop]},()=>t.$.y(7));await tick();eq(sent,[7],'terminal no-op authentic identity');}
 if(scenario==='nested-unknown'){c.declare({kind:'unknown'},()=>{receipt=c.declare({kind:'independent'},()=>t.$.y(7));eq(receipt.read().state,'validating','inner validating');});await tick();eq(sent,[],'outer unknown preserved');}
 if(scenario==='then-getter'){receipt=c.declare({kind:'independent'},()=>{t.$.y(7);return {get then(){t.$.y(8);return undefined;}};});await tick();eq(sent,[8],'getter reentry included');}
 if(scenario==='async'){try{c.declare({kind:'independent'},async()=>{t.$.y(7);await Promise.resolve();t.$.y(8);});}catch(e){eq((e as any).reason,'async-callback','async denied');}await tick();eq(sent,[],'async installed writes held');}
 if(scenario==='attribution'){try{c.declare({kind:'independent'},()=>t.transact(()=>t.$.y(7)));}catch(e){eq((e as any).reason,'contradiction','known owner contradiction');}await tick();eq(sent,[],'contradiction held');}
 if(scenario==='ABA'){t.$.y(42);await tick();receipt=c.declare({kind:'independent'},()=>{t.$.y(99);t.$.y(42);});await tick();eq(sent,[42],'ABA fresh permission');}
 if(scenario==='disposed'){c.dispose();let called=false;try{c.declare({kind:'independent'},()=>called=true);}catch(e){eq((e as any).reason,'disposed','disposed rejection');}eq(called,false,'disposed callback not run');}
 if(scenario==='callback-throw'){const value=Object.freeze({message:'same'});try{c.declare({kind:'independent'},()=>{t.$.y(7);throw value;});}catch(e){eq(e===value,true,'callback identity');}await tick();eq(sent,[],'throw holds installed write');}
 rows.push({scenario,checks,sent,other,receipt:receipt?.read()});
 }catch(e){rows.push({scenario,checks,error:String(e)});}finally{c.dispose();d.dispose();t.destroy();await tick();}}
 return rows;}
