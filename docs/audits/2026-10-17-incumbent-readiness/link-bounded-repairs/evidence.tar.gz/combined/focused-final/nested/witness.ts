import {signalTree,transactions,link} from './packages/kernel/src/index';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];const other:number[]=[];
 const c:any=link(t.$.y,{set:v=>{sent.push(v);}}); const d:any=link(t.$.y,{set:v=>{other.push(v);}});
 const p=t.transact(()=>t.$.x(7)); let inner:any;let error:unknown;
 try{ c.declare({kind:'independent'},()=>{inner=d.declare({kind:'independent'},()=>t.$.y(9));return Promise.resolve();}); }catch(e){error=(e as any).reason;}
 await tick();const result={error,sent:[...sent],other:[...other],inner:inner.read(),expectedOther:[],pass:other.length===0};c.dispose();d.dispose();t.destroy();await tick();return result;
}
