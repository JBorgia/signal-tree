import {signalTree,transactions,link} from './packages/kernel/src/index';
import {transactionLifecycleReader} from './packages/kernel/src/lib/internals/transaction-lifecycle-view';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const results:unknown[]=[];
for(const scenario of ['noop-identity','two-connections','no-write','inspection-rejection']){
const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];const other:number[]=[];
const c=link(t.$.y,{set:v=>{sent.push(v);}}) as ReturnType<typeof link> & {declare(r:unknown,work:()=>unknown):{read():unknown}};
const d=link(t.$.y,{set:v=>{other.push(v);}});const checks:unknown[]=[];
const eq=(name:string,actual:unknown,expected:unknown)=>checks.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
try{
if(scenario==='noop-identity'){
 const p=t.transact(()=>{}),q=t.transact(()=>t.$.x(7));
 eq('two live native owners',transactionLifecycleReader(t)!.snapshot().pending.length,2);
 c.declare({kind:'dependent',owners:[p]},()=>t.$.y(1));await tick();eq('pending noop holds',sent.slice(),[]);
 p.confirm();await tick();eq('noop confirmation permits while ordinary pending',sent.slice(),[1]);eq('ordinary owner survives',transactionLifecycleReader(t)!.snapshot().pending.length,1);q.rollback();
}else if(scenario==='two-connections'){
 const p=t.transact(()=>t.$.x(7));c.declare({kind:'independent'},()=>t.$.y(7));await tick();eq('declared connection progresses',sent.slice(),[7]);eq('other connection remains conservative',other.slice(),[]);p.confirm();await tick();eq('other eventually delivers',other.slice(),[7]);
}else if(scenario==='no-write'){
 const p=t.transact(()=>t.$.x(7));t.$.y(7);await tick();const receipt=c.declare({kind:'independent'},()=>{});await tick();eq('no write cannot authorize prior value',sent.slice(),[]);eq('receipt no-write',(receipt.read() as {state:string}).state,'no-write');p.confirm();await tick();eq('ordinary eventual delivery',sent.slice(),[7]);
}else{
 const p=t.transact(()=>t.$.x(7));c.declare({kind:'dependent',owners:[p]},()=>t.$.y(7));await tick();withWriteContext({participation:'inspection'},()=>t.$.y(99));await tick();eq('inspection visible',t.$.y(),99);eq('no pending publish',sent.slice(),[]);p.rollback();await tick();eq('eligible truth not inspected display',sent.slice(),[7]);
}
results.push({scenario,checks,sent:[...sent],other:[...other]});
}catch(error){results.push({scenario,error:String(error),checks,sent:[...sent],other:[...other]});}
finally{c.dispose();d.dispose();t.destroy();await tick();}
}
return results;}
