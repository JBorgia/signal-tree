import {signalTree,transactions,entityMap,link,onTreeError} from './packages/kernel/src/index';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const results:any[]=[];
for(const scenario of ['field-isolation','other-source-only','terminal-validation','reporter-throws']){
 const t=signalTree({x:0,y:0,rows:entityMap<{id:string;n:number;m:number},string>({selectId:r=>r.id})},{enhancers:[transactions()]});
 t.$.rows.addMany([{id:'a',n:1,m:2},{id:'b',n:3,m:4}]);await tick();
 const a=t.$.rows.byIdOrFail('a'),b=t.$.rows.byIdOrFail('b');const sent:any[]=[],other:any[]=[],third:any[]=[];const checks:any[]=[];
 const eq=(name:string,actual:unknown,expected:unknown)=>checks.push({name,actual:structuredClone(actual),expected:structuredClone(expected),pass:JSON.stringify(actual)===JSON.stringify(expected)});
 const c:any=link(a.n,{set:v=>{sent.push(v);}}),d:any=link(a.m,{set:v=>{other.push(v);}}),e:any=link(b.n,{set:v=>{third.push(v);}});
 let p:any,off=()=>{};
 try{
 p=t.transact(()=>t.$.x(7));
 if(scenario==='field-isolation'){c.declare({kind:'independent'},()=>{a.n(9);a.m(8);b.n(6);});await tick();eq('only exact field progresses',sent,[9]);eq('same lifetime other field held',other,[]);eq('other lifetime held',third,[]);p.confirm();await tick();eq('same lifetime eventually useful',other,[8]);eq('other lifetime eventually useful',third,[6]);}
 if(scenario==='other-source-only'){const r=c.declare({kind:'independent'},()=>b.n(6));await tick();eq('receipt owns no write',r.read().state,'no-write');eq('unrelated source held',third,[]);p.confirm();await tick();eq('unrelated source progresses after confirm',third,[6]);}
 if(scenario==='terminal-validation'){const r=c.declare({kind:'independent'},()=>a.n(9));await tick();let seen:unknown;try{d.declare({get kind(){seen=r.read().state;throw 'bad getter';}},()=>a.m(8));}catch{}eq('terminal inside failing validation',seen,'started');eq('terminal after failure',r.read().state,'started');eq('useful original send',sent,[9]);}
 if(scenario==='reporter-throws'){let events=0;off=onTreeError(ev=>{if(ev.operation==='link:declare'){events++;throw 'secondary listener';}});let primary:unknown;try{c.declare({kind:'independent'},()=>{t.transact(()=>a.n(9));throw 17;});}catch(err){primary=err;}await tick();eq('primitive identity',primary,17);eq('secondary diagnostic once',events,1);eq('failed scope held',sent,[]);}
 }catch(err){checks.push({name:'unexpected',error:String(err),pass:false});}finally{off();try{p?.confirm();}catch{}c.dispose();d.dispose();e.dispose();t.destroy();await tick();}results.push({scenario,checks});
}return results;}
