import {signalTree,transactions,entityMap,link} from './packages/kernel/src/index';
import {diagnostics} from 'research-private';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const refs:WeakRef<object>[]=[];const receipts:any[]=[];const sends:number[]=[];
 async function cycle(){const t=signalTree({x:0,rows:entityMap<{id:string;payload:{data:number[]}},string>({selectId:r=>r.id})},{enhancers:[transactions()]});t.$.rows.addOne({id:'a',payload:{data:[1,2,3]}});await tick();const r=t.$.rows.byIdOrFail('a');const c:any=link(r.payload,{set:v=>{sends.push(v.data[0]);}});const p=t.transact(()=>t.$.x(7));refs.push(new WeakRef(t),new WeakRef(c),new WeakRef(p),new WeakRef(r.payload()));c.declare({kind:'independent'},()=>r.payload({data:[8,9,10]}));refs.push(new WeakRef(r.payload()));await tick();await c.settled();p.confirm();c.dispose();t.destroy();await tick();}
 for(let i=0;i<4;i++)await cycle();
 const live=signalTree({x:1});const liveRef=new WeakRef(live);
 for(let i=0;i<16;i++){await new Promise(r=>setTimeout(r,0));globalThis.gc();}
 const collected=refs.map(r=>!r.deref());const result={collected,sends,receipts:receipts.map(r=>r.read()),liveControl:liveRef.deref()===live,counts:diagnostics(),pass:collected.every(Boolean)&&sends.join(',')==='8,8,8,8'&&receipts.every(r=>r.read().state==='started')&&liveRef.deref()===live};live.destroy();return result;
}
