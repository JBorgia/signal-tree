# Independent setAll chronology recurrence — frozen, no repair

Independent reviewer `/root/declared_native` reproduced at entity patchba21c351:
ordinary rows a7,b8; inspection a99,b88; transact setAll with those same displayed rows. Pending inspect throws missing mutation chronology. Reviewer owns raw first bundle/log under `/private/tmp/link-repair-adoption-review`; root independently controls disposition. This note is source trace, not another execution.

Source path:
- entity-signal.ts3663 stages `prev=valueStore.backingForSubject(subjectId)`: inspected physical row.
- setAll3720 stages replace-value instructions and calls shared commitAndProjectEntityMutationFrame.
- entityPatch supplies ordinary-before to prepared entity responsibility and committed capture; this can record7->99 despite equal physical display.
- EntityMutationCommitResult exposes subject IDs, not the prepared semantic before/after publication records.
- setAll3780 publishes independently staged `prev` and incoming entity. Both are inspected99; notification equality sees no meaningful change, so transaction chronology omits work already held in responsibility.

Earlier correction changed updateOne and replaceOne notification before-values locally. It did not establish a shared semantic publication result for every frame caller. This is the same mechanism recurring on another supported mutation route after purported shared repair. No setAll special case added.

Representation requirement exposed: storage/capture ordinary-before and caller notification before must come from the same prepared operation outcome, with physical value notification suppression represented separately. Existing prepared ordinary information is available internally but is discarded at the commit-to-publication seam. Merely substituting another caller's prev is not general coverage.
