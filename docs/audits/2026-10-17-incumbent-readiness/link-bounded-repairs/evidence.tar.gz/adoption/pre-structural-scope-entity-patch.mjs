export function entityPatch(s,path){
if(path.endsWith('/physical/entity-value-store.ts')){
s=`import {getActiveWriteContext} from '../write-context';\nimport {deepEqual} from '../internals/utilities/deep-equal';\nexport type EntityAuthorityPlan<E>={before:E|undefined;after:E;baseline:E|undefined;retain:boolean};\n`+s;
s=s.replace('  private retainedEntities = new Map<number, E>();',`  private retainedEntities = new Map<number, E>();
  private inspectionBaselines = new Map<number,E>();
  ordinaryForSubject(subject:number):E|undefined{return this.inspectionBaselines.get(subject)??this.retainedEntities.get(subject);}
  prepareAuthority(subject:number,next:E,fields?:readonly string[]):EntityAuthorityPlan<E>{
    const physical=this.retainedEntities.get(subject);
    const before=this.ordinaryForSubject(subject);
    const inspection=getActiveWriteContext()?.participation==='inspection';
    let after:E;
    if(inspection)after=(before??next);
    else if(fields&&before){const result={...before};for(const key of fields){if(Object.prototype.hasOwnProperty.call(next,key))Object.defineProperty(result,key,{value:next[key],writable:true,enumerable:true,configurable:true});else delete result[key];}after=result;}
    else after=next;
    const retain=before!==undefined&&!deepEqual(after,next);
    return {before,after,baseline:retain?after:undefined,retain};
  }
  installAuthority(subject:number,plan:EntityAuthorityPlan<E>):void{if(plan.retain)this.inspectionBaselines.set(subject,plan.baseline!);else this.inspectionBaselines.delete(subject);}
  authorityCount():number{return this.inspectionBaselines.size;}`);
s=s.replace('retainSubjectValue(subjectId: number, entity: E): void {','retainSubjectValue(subjectId: number, entity: E, authority=this.prepareAuthority(subjectId,entity)): void {\n    this.installAuthority(subjectId,authority);');
s=s.replace('    return this.retainedEntities.delete(subjectId);','    this.inspectionBaselines.delete(subjectId);\n    return this.retainedEntities.delete(subjectId);');
s=s.replace('    this.retainedEntities.clear();','    this.inspectionBaselines.clear();\n    this.retainedEntities.clear();');
// Prepared target carries its already-prepared shadow outcomes into installation.
s=s.replace('  prepareTargetValues(', '  private targetAuthority=new WeakMap<Map<number,E>,Map<number,EntityAuthorityPlan<E>>>();\n  prepareTargetValues(');
s=s.replace('    const target = new Map(this.retainedEntities);','    const target = new Map(this.retainedEntities);\n    const authority=new Map<number,EntityAuthorityPlan<E>>();');
s=s.replace('      target.set(subject.subjectId, subject.value);','      target.set(subject.subjectId, subject.value);\n      authority.set(subject.subjectId,this.prepareAuthority(subject.subjectId,subject.value));');
s=s.replace('    return target;','    this.targetAuthority.set(target,authority);\n    return target;');
s=s.replace('    this.retainedEntities = target;','    for(const [subject,plan]of this.targetAuthority.get(target)??[])this.installAuthority(subject,plan);\n    this.targetAuthority.delete(target);\n    this.retainedEntities = target;');
}
if(path.endsWith('/physical/entity-mutation-frame.ts')){
s=s.replace('    structuralFrontier?: { after: unknown }', "    structuralFrontier?: { after: unknown }, preparedAuthority?: ReadonlyMap<number,ReturnType<EntityValueStore<E>['prepareAuthority']>>");
s=s.replace('    const preparedMutations = this.prepareCommitInstructions();',`    const preparedMutations = this.prepareCommitInstructions();
    const authority=new Map<number,ReturnType<EntityValueStore<E>['prepareAuthority']>>(preparedAuthority);
    if(!preparedAuthority)for(const mutation of preparedMutations){const next='nextValue'in mutation?mutation.nextValue:'resolvedValue'in mutation?mutation.resolvedValue:undefined;if(next!==undefined)authority.set(mutation.subjectId,this.valueStore.prepareAuthority(mutation.subjectId,next));}`);
s=s.replaceAll('mutation.nextValue\n        );','mutation.nextValue, authority.get(mutation.subjectId)\n        );');
s=s.replace('mutation.resolvedValue\n          );','mutation.resolvedValue, authority.get(mutation.subjectId)\n          );');
}
if(path.endsWith('/lib/entity-signal.ts')){
s=s.replace('function commitExistingSubjectValue(subjectId: number, nextValue: E): void {','function commitExistingSubjectValue(subjectId: number, nextValue: E, fields?:readonly string[]): void {\n    const revision=physicalCommitClock?.revision();\n    const authority=valueStore.prepareAuthority(subjectId,nextValue,fields);');
s=s.replace('    const revision = physicalCommitClock?.revision();','');
s=s.replace('      ? valueStore.backingForSubject(subjectId)\n      : undefined;', '      ? authority.before\n      : undefined;');
s=s.replace('before: valueStore.backingForSubject(subjectId), after: nextValue, structural: false', 'before: authority.before, after: authority.after, structural: false');
s=s.replace('    valueStore.retainSubjectValue(subjectId, nextValue);','    valueStore.retainSubjectValue(subjectId, nextValue, authority);');
s=s.replace('{ subject: subjectId, before, after: nextValue, structural: false }','{ subject: subjectId, before, after: authority.after, structural: false }');
s=s.replace('      const prev = entity;', '      const prev = valueStore.ordinaryForSubject(structuralStore.subjectIdForKey(id)!) ?? entity;');
s=s.replace('      const prev = presentEntity(id);', '      const prev = valueStore.ordinaryForSubject(structuralStore.subjectIdForKey(id)!) ?? presentEntity(id);');
s=s.replace('commitExistingSubjectValue(subjectIdForWrite, finalUpdated);','commitExistingSubjectValue(subjectIdForWrite, finalUpdated, Object.keys(transformedChanges));');
// Frame responsibility needs ordinary values; observer reports the same prepared semantic changes.
s=s.replace("    const changes: Array<import('./internals/mutation-capture-runtime').CommittedEntityMutation> = [];", "    const changes: Array<import('./internals/mutation-capture-runtime').CommittedEntityMutation> = [];\n    const authorityPlans=new Map<number,ReturnType<typeof valueStore.prepareAuthority>>();\n    for(const mutation of frame.mutations){const next='nextValue'in mutation?mutation.nextValue:'realizedValue'in mutation?mutation.realizedValue:undefined;if(next!==undefined)authorityPlans.set(mutation.subjectId,valueStore.prepareAuthority(mutation.subjectId,next));}");
s=s.replace("const before = valueStore.backingForSubject(m.subjectId);", "const before = valueStore.ordinaryForSubject(m.subjectId);");
s=s.replace('frame.commit(committedEntityObserver(structuralFrontier, changes),responsibility,structuralFrontier)', 'frame.commit((()=>{const observer=committedEntityObserver(structuralFrontier,changes);return observer?()=>observer(changes):undefined;})(),responsibility,structuralFrontier,authorityPlans)');
// Point restoration prepares authority before installation.
s=s.replace('return { subjectId, key: key as K, before, after,','return { subjectId, key: key as K, before, after, authority:valueStore.prepareAuthority(subjectId,after),');
s=s.replace('valueStore.retainSubjectValue(row.subjectId, row.after);','valueStore.retainSubjectValue(row.subjectId, row.after, row.authority);');
}
return s;
}
