// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/write-context.ts
var activeContext;
function withWriteContext(meta, fn) {
  const previous = activeContext;
  activeContext = meta;
  try {
    return fn();
  } finally {
    activeContext = previous;
  }
}
function getActiveWriteContext() {
  return activeContext;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/utilities/deep-equal.ts
function deepEqual(a, b) {
  return equalsInner(a, b, 0, void 0);
}
var CYCLE_GUARD_DEPTH = 64;
function equalsInner(a, b, depth, seen) {
  if (a === b) return true;
  if (a == null || b == null) return a === b;
  const typeA = typeof a;
  const typeB = typeof b;
  if (typeA !== typeB) return false;
  if (typeA !== "object") return a !== a && b !== b;
  if (depth >= CYCLE_GUARD_DEPTH) {
    seen ??= /* @__PURE__ */ new WeakMap();
    if (seen.get(a) === b) return true;
    seen.set(a, b);
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    const bArr = b;
    for (let i = 0; i < a.length; i++) {
      const x = a[i];
      const y = bArr[i];
      if (x === y) continue;
      if (!equalsInner(x, y, depth + 1, seen)) return false;
    }
    return true;
  }
  if (Array.isArray(b)) return false;
  if (a instanceof Date && b instanceof Date) {
    try {
      const ta = a.getTime();
      const tb = b.getTime();
      return ta === tb || ta !== ta && tb !== tb;
    } catch {
      return false;
    }
  }
  if (a instanceof RegExp && b instanceof RegExp) {
    return a.source === b.source && a.flags === b.flags;
  }
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    for (const [key, value] of a) {
      if (!b.has(key) || !equalsInner(value, b.get(key), depth + 1, seen))
        return false;
    }
    return true;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    for (const value of a) {
      if (!b.has(value)) return false;
    }
    return true;
  }
  if (a instanceof Error && b instanceof Error) {
    if (a.name !== b.name || a.message !== b.message) return false;
  } else if (a instanceof Number && b instanceof Number || a instanceof String && b instanceof String || a instanceof Boolean && b instanceof Boolean) {
    const va = a.valueOf();
    const vb = b.valueOf();
    if (!(va === vb || va !== va && vb !== vb)) return false;
  }
  try {
    if (a.constructor !== b.constructor) {
      return false;
    }
  } catch {
    return false;
  }
  const objA = a;
  const objB = b;
  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  const hasOwn = Object.prototype.hasOwnProperty;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!hasOwn.call(objB, key)) return false;
    const x = objA[key];
    const y = objB[key];
    if (x === y) continue;
    if (!equalsInner(x, y, depth + 1, seen)) return false;
  }
  return true;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/production-substrate-stats.ts
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/physical/entity-value-store.ts
var EntityValueStore = class {
  retainedEntities = /* @__PURE__ */ new Map();
  inspectionBaselines = /* @__PURE__ */ new Map();
  ordinaryForSubject(subject) {
    return this.inspectionBaselines.get(subject) ?? this.retainedEntities.get(subject);
  }
  prepareAuthority(subject, next, fields) {
    const physical = this.retainedEntities.get(subject);
    const before = this.ordinaryForSubject(subject);
    const inspection = getActiveWriteContext()?.participation === "inspection";
    let after;
    if (inspection) after = before ?? next;
    else if (fields && before) {
      const result = { ...before };
      for (const key of fields) {
        if (Object.prototype.hasOwnProperty.call(next, key)) Object.defineProperty(result, key, { value: next[key], writable: true, enumerable: true, configurable: true });
        else delete result[key];
      }
      after = result;
    } else after = next;
    const retain = before !== void 0 && !deepEqual(after, next);
    return { before, after, baseline: retain ? after : void 0, retain };
  }
  installAuthority(subject, plan) {
    if (plan.retain) this.inspectionBaselines.set(subject, plan.baseline);
    else this.inspectionBaselines.delete(subject);
  }
  authorityCount() {
    return this.inspectionBaselines.size;
  }
  backingForSubject(subjectId) {
    return this.retainedEntities.get(subjectId);
  }
  retainSubjectValue(subjectId, entity, authority = this.prepareAuthority(subjectId, entity)) {
    this.installAuthority(subjectId, authority);
    recordProductionSubstrateStat("valueStoreWrites");
    this.retainedEntities.set(subjectId, entity);
  }
  targetAuthority = /* @__PURE__ */ new WeakMap();
  prepareTargetValues(subjects) {
    const target = new Map(this.retainedEntities);
    const authority = /* @__PURE__ */ new Map();
    for (const subject of subjects) {
      target.set(subject.subjectId, subject.value);
      authority.set(subject.subjectId, this.prepareAuthority(subject.subjectId, subject.value));
    }
    this.targetAuthority.set(target, authority);
    return target;
  }
  installPreparedTargetValues(target) {
    for (const [subject, plan] of this.targetAuthority.get(target) ?? []) this.installAuthority(subject, plan);
    this.targetAuthority.delete(target);
    this.retainedEntities = target;
  }
  hasRetainedValueBacking(subjectId) {
    return this.retainedEntities.has(subjectId);
  }
  retireSubjectValue(subjectId) {
    this.inspectionBaselines.delete(subjectId);
    return this.retainedEntities.delete(subjectId);
  }
  clear() {
    this.inspectionBaselines.clear();
    this.retainedEntities.clear();
  }
};

// <stdin>
async function run() {
  const s = new EntityValueStore();
  s.retainSubjectValue(1, { n: 7, m: 0 });
  withWriteContext({ participation: "inspection" }, () => s.retainSubjectValue(1, { n: 99, m: 0 }));
  const first = s.authorityCount();
  const p = s.prepareAuthority(1, { n: 99, m: 4 }, ["m"]);
  s.retainSubjectValue(1, { n: 99, m: 4 }, p);
  const untouched = s.ordinaryForSubject(1);
  const a = s.prepareAuthority(1, { n: 99, m: 4 }, ["n"]);
  s.retainSubjectValue(1, { n: 99, m: 4 }, a);
  const adopted = s.authorityCount();
  withWriteContext({ participation: "inspection" }, () => s.retainSubjectValue(1, { n: 88, m: 4 }));
  s.retireSubjectValue(1);
  const retired = s.authorityCount();
  s.retainSubjectValue(2, { n: 7, m: 0 });
  withWriteContext({ participation: "inspection" }, () => s.retainSubjectValue(2, { n: 99, m: 0 }));
  s.clear();
  return { first, untouched, adopted, retired, cleared: s.authorityCount(), pass: first === 1 && untouched?.n === 7 && untouched?.m === 4 && adopted === 0 && retired === 0 && s.authorityCount() === 0 };
}
export {
  run
};
