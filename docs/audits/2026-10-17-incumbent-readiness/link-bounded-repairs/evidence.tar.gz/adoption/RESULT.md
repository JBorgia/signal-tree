# Existing-lifetime entity adoption correction (private source-loader)

Export entityPatch(source,path) from entity-patch.mjs; compose AFTER original scalar patch. Only entity-signal.ts, physical/entity-value-store.ts and physical/entity-mutation-frame.ts transformed. Production unchanged. Native tests omit declaration helper changes by default; FULL=1 enables frozen old helper only for integration diagnosis, not acceptance. Entity structural adoption beyond existing-lifetime values is not expanded.

## Mechanism
Sparse per-subject ordinary baseline exists only while displayed inspection diverges. updateOne explicit field footprint changes only authored fields in ordinary before/after; untouched inspected siblings remain latent. Full replace-value authors whole value. Authority plans precompute ordinary before/after and retention disposition; native installers apply prepared metadata with value and terminal responsibility before capture/publication. Existing frame captures retain structural mutations; only replace-value entries receive prepared semantic values. Before/after projected responsibility uses a per-subject Map, not quadratic find. Prepared target/point realization also install corresponding authority outcome. Retired values and clear discharge stored baselines.

## Preserved failures/corrections
First patch created terminal responsibility but physical-equal notification had no chronology: four inspect() scenarios threw 'authored contribution has no mutation chronology'. first-entity-patch/first-bundle/first.log retained. Ordinary-before notification payload now exposes meaningful authority change without inventing physical value change; unchanged adoption tests pass.
Preparation script briefly had a quoting syntax error (no execution); corrected before next run. No source-runtime test changed.
First reentry oracle expected77 after throwing outer transaction. Actual7 reflects same-transaction rollback of reentrant77, not lost independent work; original assertion remains failing and is a test-contract mismatch. Added nontransaction reentry preserves77. That control also expected a throw but observed none: unchanged expectation preserved; timing/throw status not counted as a safety pass. Held/all/raw agree77. Do not claim all extra assertions pass. Throwing value preparation does prove display99 unchanged and later adoption rollback7 still works.

## Results
Final-native tests cover field rollback/confirm, full replacement, repeated inspection, untouched inspected sibling (including later adoption+rollback7), genuine noop, equal external acquisition and same-key lifetime isolation. No errors or assertion failures in final-native-traces.json.
Existing aggregate16 checks pass; actual restoration undo/redo restores then removes original lifetime and publishes coherent rows. Direct store lifecycle control records baseline count1 during divergence, unchanged sibling ordinary7, count0 after full adoption, retirement and clear. This is record lifecycle evidence, not retained-heap measurement.
Typecheck of initial final structure adds zero errors beyond11 existing research semantics TS4111 diagnostics; parent should typecheck latest exact combined candidate (last Map refactor afterward). No broad Nx suite run by worker.

## Structural characterization
Existing entity-inspection-egress.spec.ts17–29,133–159 says authored UPDATE of inspection-created subject adopts necessary existence for publication; traversed neighbors remain latent, REMOVE does not adopt. No transaction compensation rule for that latent existence was found. Characterization inspection-created b99 -> pending b100 -> rollback leaves displayed b99; inspection-removed held field throws and does not target a replacement. These are observations, not authorization for structural rollback redesign.

## Replay
Node24.15.0 standalone final-native-bundle, final-aggregate-bundle, final-restoration-bundle, store-bundle export run(). extra-first/final/detail preserve reentry oracle diagnostics. Rebuild ENTRY=witness.ts node loader.mjs in this directory; loader absolute checkout/patch paths are recorded. Generic outputs overwritten by rebuild; named frozen copies remain.

Limits: no aggregate declarations, no entity adoption policy beyond the existing-lifetime value footprint, no performance/heap/general framework qualification. Prepared target fallback, user accessors and concurrent frame plans merit independent review before acceptance.

## Separately corrected reentry oracles
`extra-vetted.ts` preserves original scenario actions, changes only unjustified expected outcomes: same-owner transact reentry compensates to7; ordinary reentry requires preservation77 without a mandatory throw. Root requested these explicit contract-based corrections. Original extra.ts/first files remain unchanged and failing. extra-vetted6/6 assertions pass; structural cases remain characterization entries without pass labels. No runtime patch changed.
