// ../../../../private/tmp/prepared-placement-index/review/probe.ts
import assert from "node:assert/strict";

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/physical/entity-placement-stage.ts
var EntityPlacementStage = class {
  constructor(base, head, tail) {
    this.base = base;
    this.head = head;
    this.tail = tail;
  }
  patch = /* @__PURE__ */ new Map();
  read(subject) {
    return this.patch.get(subject) ?? this.base(subject);
  }
  change(subject, change) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement neighbor is absent");
    this.patch.set(subject, { ...row, ...change });
  }
  remove(subject) {
    const row = this.read(subject);
    if (!row.present) return;
    if (row.beforeSubject === void 0) this.head = row.afterSubject;
    else this.change(row.beforeSubject, { afterSubject: row.afterSubject });
    if (row.afterSubject === void 0) this.tail = row.beforeSubject;
    else this.change(row.afterSubject, { beforeSubject: row.beforeSubject });
    this.patch.set(subject, { present: false });
  }
  insert(subject, key, beforeSubject, afterSubject) {
    this.remove(subject);
    const after = afterSubject === void 0 ? void 0 : this.read(afterSubject);
    const before = beforeSubject === void 0 ? void 0 : this.read(beforeSubject);
    if (after?.present) beforeSubject = after.beforeSubject;
    else if (before?.present) afterSubject = before.afterSubject;
    else {
      beforeSubject = this.tail;
      afterSubject = void 0;
    }
    if (beforeSubject === void 0) this.head = subject;
    else this.change(beforeSubject, { afterSubject: subject });
    if (afterSubject === void 0) this.tail = subject;
    else this.change(afterSubject, { beforeSubject: subject });
    this.patch.set(subject, {
      present: true,
      key,
      beforeSubject,
      afterSubject
    });
  }
  snapshot() {
    const subjects = [];
    const seen = /* @__PURE__ */ new Set();
    let subject = this.head;
    while (subject !== void 0) {
      if (seen.has(subject)) throw new Error("Prepared placement cycle");
      seen.add(subject);
      subjects.push(subject);
      const row = this.read(subject);
      if (!row.present)
        throw new Error("Prepared placement contains absent lifetime");
      subject = row.afterSubject;
    }
    return Object.freeze(subjects);
  }
  orderDomain(subjects) {
    const domain = new Set(subjects);
    if (domain.size !== subjects.length)
      throw new Error("Prepared order domain repeats a lifetime");
    for (const subject of subjects)
      if (!this.read(subject).present)
        throw new Error("Prepared order domain contains absent lifetime");
    const current = this.snapshot();
    let index = 0;
    const ordered = Object.freeze(
      current.map(
        (subject) => domain.has(subject) ? subjects[index++] : subject
      )
    );
    this.order(ordered);
    return ordered;
  }
  rekey(subject, key) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement rekey lifetime is absent");
    this.patch.set(subject, { ...row, key });
  }
  order(subjects) {
    for (let i = 0; i < subjects.length; i++) {
      const row = this.read(subjects[i]);
      if (!row.present) throw new Error("Order lifetime is absent");
      this.patch.set(subjects[i], {
        ...row,
        beforeSubject: subjects[i - 1],
        afterSubject: subjects[i + 1]
      });
    }
    this.head = subjects[0];
    this.tail = subjects.at(-1);
  }
};

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/internals/production-substrate-stats.ts
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/physical/structural-store.ts
var StructuralStore = class {
  keysCache;
  subjectIds = /* @__PURE__ */ new Map();
  subjectStates = /* @__PURE__ */ new Map();
  subjectRevisions = /* @__PURE__ */ new Map();
  activeNodesByKey = /* @__PURE__ */ new Map();
  activeNodesBySubject = /* @__PURE__ */ new Map();
  nextSubjectId = 1;
  collectionIncarnation = 0;
  activeHead;
  activeTail;
  activeCount = 0;
  orderFrontier = {};
  placementForSubject(subject) {
    const node = this.activeNodesBySubject.get(subject);
    return node === void 0 ? { present: false } : {
      present: true,
      key: node.key,
      beforeSubject: node.prev?.subjectId,
      afterSubject: node.next?.subjectId
    };
  }
  preparePlacement() {
    return new EntityPlacementStage(
      (subject) => this.placementForSubject(subject),
      this.activeHead?.subjectId,
      this.activeTail?.subjectId
    );
  }
  activeOrderFrontier() {
    return this.orderFrontier;
  }
  /** Only a complete, lineage-validated compensation may restore this token. */
  installCompensatedOrderFrontier(frontier) {
    this.orderFrontier = frontier;
  }
  planFreshSubjectIds(count) {
    return Array.from(
      { length: count },
      (_, index) => this.nextSubjectId + index
    );
  }
  allocateFreshSubjectId() {
    const subjectId = this.nextSubjectId;
    this.nextSubjectId += 1;
    return subjectId;
  }
  subjectIdForKey(key) {
    return this.subjectIds.get(key);
  }
  acquireSubjectHandleForKey(key) {
    const subjectId = this.subjectIds.get(key);
    return subjectId === void 0 ? void 0 : {
      subjectId,
      acquiredRevision: this.subjectRevision(subjectId),
      collectionIncarnation: this.collectionIncarnation
    };
  }
  resolveSubjectHandle(handle) {
    if (handle.collectionIncarnation !== this.collectionIncarnation) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    const state = this.subjectStates.get(handle.subjectId);
    if (state === void 0) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    if (state.active) {
      if (state.key === void 0) {
        throw new Error(
          `Active subject ${String(
            handle.subjectId
          )} is missing its active key.`
        );
      }
      return {
        state: "active",
        subjectId: handle.subjectId,
        key: state.key,
        revision: this.subjectRevision(handle.subjectId)
      };
    }
    return {
      state: "tombstoned",
      subjectId: handle.subjectId,
      restoreAllowed: state.restoreAllowed,
      revision: this.subjectRevision(handle.subjectId)
    };
  }
  stateForSubject(subjectId) {
    return this.subjectStates.get(subjectId);
  }
  hasSubject(subjectId) {
    return this.subjectStates.has(subjectId);
  }
  subjectRevision(subjectId) {
    return this.subjectRevisions.get(subjectId) ?? 0;
  }
  bumpSubjectRevision(subjectId) {
    this.subjectRevisions.set(subjectId, this.subjectRevision(subjectId) + 1);
  }
  activeKeyForSubject(subjectId) {
    const state = this.stateForSubject(subjectId);
    return state?.active ? state.key : void 0;
  }
  hasActiveKey(key) {
    return this.subjectIds.has(key);
  }
  activeKeyCount() {
    return this.activeCount;
  }
  /**
   * Active keys in order, shared until the next list or key mutation. Every
   * mutator of the active list (or of a node's key) clears it; a field write
   * changes neither, so reading `ids()` after one no longer re-walks the list.
   * Callers must not mutate the result.
   */
  activeKeysSnapshot() {
    if (this.keysCache) return this.keysCache;
    const keys = [];
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
    }
    this.keysCache = keys;
    return keys;
  }
  /** Fills both arrays from one walk of the active order. */
  snapshotActiveOrder(keys, subjectIds) {
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
      subjectIds.push(node.subjectId);
    }
  }
  firstActiveKey() {
    return this.activeHead?.key;
  }
  lastActiveKey() {
    return this.activeTail?.key;
  }
  prepareTarget(subjects, order, orderFrontier, prepare) {
    return prepare(
      this.subjectStates,
      this.subjectRevisions,
      subjects,
      order,
      orderFrontier
    );
  }
  installPreparedTarget(target) {
    this.keysCache = void 0;
    this.subjectIds = target.subjectIds;
    this.subjectStates = target.subjectStates;
    this.subjectRevisions = target.subjectRevisions;
    this.activeNodesByKey = target.activeNodesByKey;
    this.activeNodesBySubject = target.activeNodesBySubject;
    this.activeHead = target.activeHead;
    this.activeTail = target.activeTail;
    this.activeCount = target.activeCount;
    this.orderFrontier = target.orderFrontier;
  }
  moveKeysToFront(keys) {
    this.keysCache = void 0;
    const nodes = [
      ...new Set(
        keys.map((key) => this.activeNodesByKey.get(key)).filter((node) => node !== void 0)
      )
    ];
    for (const node of nodes) {
      this.detachNode(node);
    }
    for (let index = nodes.length - 1; index >= 0; index -= 1) {
      this.prependDetachedNode(nodes[index]);
    }
    if (nodes.length > 0) this.orderFrontier = {};
  }
  reorderActiveKeys(keys) {
    let current = this.activeHead;
    let unchanged = true;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) continue;
      if (node !== current) {
        unchanged = false;
        break;
      }
      current = current.next;
    }
    if (unchanged && current === void 0) return;
    this.keysCache = void 0;
    this.activeHead = void 0;
    this.activeTail = void 0;
    for (const node of this.activeNodesByKey.values()) {
      node.prev = void 0;
      node.next = void 0;
    }
    let nextCount = 0;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) {
        continue;
      }
      this.appendDetachedNode(node);
      nextCount += 1;
    }
    this.activeCount = nextCount;
    this.orderFrontier = {};
  }
  neighborSubjectsForKey(key) {
    const node = this.activeNodesByKey.get(key);
    if (node === void 0) {
      return {};
    }
    return {
      beforeSubject: node.prev?.subjectId,
      afterSubject: node.next?.subjectId
    };
  }
  tombstonedSubjectsSnapshot() {
    return [...this.subjectStates.entries()].filter(([, subjectState]) => !subjectState.active).map(([subjectId]) => subjectId).sort((left, right) => left - right);
  }
  createSubject(subjectId, key) {
    recordProductionSubstrateStat("structuralSubjectsCreated");
    this.nextSubjectId = Math.max(this.nextSubjectId, subjectId + 1);
    this.activateSubject(subjectId, key);
    this.subjectRevisions.set(subjectId, 0);
    this.createAndAppendActiveNode(subjectId, key);
    this.orderFrontier = {};
  }
  transferSubject(subjectId, from, to, restoreAllowed = true) {
    recordProductionSubstrateStat("structuralSubjectTransfers");
    const node = this.activeNodesByKey.get(from);
    this.subjectIds.delete(from);
    this.activateSubject(subjectId, to, restoreAllowed);
    if (node === void 0) {
      this.createAndAppendActiveNode(subjectId, to);
      return;
    }
    this.activeNodesByKey.delete(from);
    node.key = to;
    this.keysCache = void 0;
    this.activeNodesByKey.set(to, node);
    this.activeNodesBySubject.set(subjectId, node);
  }
  tombstoneSubject(subjectId, key, restoreAllowed) {
    recordProductionSubstrateStat("structuralSubjectTombstones");
    this.subjectIds.delete(key);
    const node = this.activeNodesByKey.get(key);
    if (node !== void 0) {
      this.unregisterActiveNode(node);
      this.detachNode(node);
      this.activeCount -= 1;
    }
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed
    });
    this.orderFrontier = {};
  }
  restoreSubject(subjectId, key, beforeSubject, afterSubject, restoreAllowed = true) {
    const placement = this.resolveSubjectRestorePlacement(
      beforeSubject,
      afterSubject
    );
    this.restoreSubjectAtResolvedPlacement(
      subjectId,
      key,
      placement,
      restoreAllowed
    );
  }
  resolveSubjectRestorePlacement(beforeSubject, afterSubject) {
    const beforeNode = beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(beforeSubject);
    const afterNode = afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(afterSubject);
    if (beforeNode !== void 0 && afterNode !== void 0) {
      if (this.nodePrecedes(beforeNode, afterNode)) {
        return {
          beforeSubject: beforeNode.subjectId,
          afterSubject: afterNode.subjectId,
          beforeKey: beforeNode.key,
          afterKey: afterNode.key
        };
      }
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (afterNode !== void 0) {
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (beforeNode !== void 0) {
      return {
        beforeSubject: beforeNode.subjectId,
        afterSubject: beforeNode.next?.subjectId,
        beforeKey: beforeNode.key,
        afterKey: beforeNode.next?.key
      };
    }
    return {
      beforeSubject: this.activeTail?.subjectId,
      beforeKey: this.activeTail?.key
    };
  }
  restoreSubjectAtResolvedPlacement(subjectId, key, placement, restoreAllowed = true) {
    this.activateSubject(subjectId, key, restoreAllowed);
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.activeCount += 1;
    this.orderFrontier = {};
    const beforeNode = placement.beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    const afterNode = placement.afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    if (afterNode !== void 0) {
      this.insertDetachedNodeBefore(node, afterNode);
      return;
    }
    if (beforeNode !== void 0) {
      this.insertDetachedNodeAfter(node, beforeNode);
      return;
    }
    this.appendDetachedNode(node);
  }
  /** Relocate an active lifetime without retiring it or emitting lifecycle effects. */
  placeActiveSubject(subjectId, beforeSubject, afterSubject) {
    const node = this.activeNodesBySubject.get(subjectId);
    if (!node) throw new Error("Placement lifetime is not active");
    if (beforeSubject === subjectId || afterSubject === subjectId)
      throw new Error("Placement cannot name its own lifetime");
    const placement = this.resolveSubjectRestorePlacement(
      beforeSubject,
      afterSubject
    );
    const after = placement.afterSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    const before = placement.beforeSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    this.detachNode(node);
    if (after) this.insertDetachedNodeBefore(node, after);
    else if (before) this.insertDetachedNodeAfter(node, before);
    else this.appendDetachedNode(node);
    this.keysCache = void 0;
    this.orderFrontier = {};
  }
  retireSubject(subjectId) {
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed: false
    });
  }
  /**
   * Drop a retired subject's lifetime ledger entirely — state AND revision.
   *
   * ⚠️ TRIAL. This is the null hypothesis for "is the ~117 B/retired lifetime
   * record earned?" (docs/architecture/retired-subject-churn.md, open question
   * 2). `retireSubject` above keeps a `{active:false, restoreAllowed:false}`
   * record forever, which is what makes zero-owner churn linear in every subject
   * that ever existed. This deletes it.
   *
   * SAFE ONLY FOR A TERMINAL, ZERO-OWNER RETIREMENT, and the reason is subject
   * id allocation: `nextSubjectId` only ever increases, and `tombstoneSubject`
   * has already removed the key -> subject mapping. A later add of the same
   * business key therefore gets a FRESH subject id and cannot collide with the
   * forgotten one. Deleting the record cannot resurrect or alias a subject.
   *
   * WHAT IT GIVES UP: `resolveSubjectHandle` reports `missing` rather than
   * `tombstoned` for the forgotten subject, and `planRestore`'s
   * "has retired backing and cannot be restored" guard loses its input. Both are
   * acceptable only because a tree with no restoration authority has no path to
   * a restore at all — the guard becomes unreachable rather than unenforced. If
   * a restorer can exist, DO NOT call this.
   */
  forgetSubject(subjectId) {
    this.subjectStates.delete(subjectId);
    this.subjectRevisions.delete(subjectId);
    this.activeNodesBySubject.delete(subjectId);
  }
  clear() {
    this.keysCache = void 0;
    this.subjectIds.clear();
    this.subjectStates.clear();
    this.subjectRevisions.clear();
    this.activeNodesByKey.clear();
    this.activeNodesBySubject.clear();
    this.activeHead = void 0;
    this.activeTail = void 0;
    this.activeCount = 0;
    this.nextSubjectId = 1;
    this.collectionIncarnation += 1;
    this.orderFrontier = {};
  }
  createAndAppendActiveNode(subjectId, key) {
    this.keysCache = void 0;
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.appendDetachedNode(node);
    this.activeCount += 1;
  }
  unregisterActiveNode(node) {
    this.keysCache = void 0;
    this.activeNodesByKey.delete(node.key);
    this.activeNodesBySubject.delete(node.subjectId);
  }
  prependDetachedNode(node) {
    this.keysCache = void 0;
    node.prev = void 0;
    node.next = this.activeHead;
    if (this.activeHead !== void 0) {
      this.activeHead.prev = node;
    } else {
      this.activeTail = node;
    }
    this.activeHead = node;
  }
  appendDetachedNode(node) {
    this.keysCache = void 0;
    node.next = void 0;
    node.prev = this.activeTail;
    if (this.activeTail !== void 0) {
      this.activeTail.next = node;
    } else {
      this.activeHead = node;
    }
    this.activeTail = node;
  }
  insertDetachedNodeAfter(node, anchor) {
    this.keysCache = void 0;
    node.prev = anchor;
    node.next = anchor.next;
    if (anchor.next !== void 0) {
      anchor.next.prev = node;
    } else {
      this.activeTail = node;
    }
    anchor.next = node;
  }
  insertDetachedNodeBefore(node, anchor) {
    this.keysCache = void 0;
    node.next = anchor;
    node.prev = anchor.prev;
    if (anchor.prev !== void 0) {
      anchor.prev.next = node;
    } else {
      this.activeHead = node;
    }
    anchor.prev = node;
  }
  detachNode(node) {
    this.keysCache = void 0;
    if (node.prev !== void 0) {
      node.prev.next = node.next;
    } else {
      this.activeHead = node.next;
    }
    if (node.next !== void 0) {
      node.next.prev = node.prev;
    } else {
      this.activeTail = node.prev;
    }
    node.prev = void 0;
    node.next = void 0;
  }
  nodePrecedes(left, right) {
    let node = left;
    while (node !== void 0) {
      if (node === right) {
        return true;
      }
      node = node.next;
    }
    return false;
  }
  activateSubject(subjectId, key, restoreAllowed = true) {
    this.subjectIds.set(key, subjectId);
    this.subjectStates.set(subjectId, {
      active: true,
      key,
      restoreAllowed
    });
  }
};

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/write-context.ts
var activeContext;
function getActiveWriteContext() {
  return activeContext;
}

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/internals/utilities/deep-equal.ts
function deepEqual(a, b) {
  return equalsInner(a, b, 0, void 0);
}
var CYCLE_GUARD_DEPTH = 64;
function equalsInner(a, b, depth, seen) {
  if (a === b) return true;
  if (a == null || b == null) return a === b;
  const typeA = typeof a;
  const typeB = typeof b;
  if (typeA !== typeB) return false;
  if (typeA !== "object") return a !== a && b !== b;
  if (depth >= CYCLE_GUARD_DEPTH) {
    seen ??= /* @__PURE__ */ new WeakMap();
    if (seen.get(a) === b) return true;
    seen.set(a, b);
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    const bArr = b;
    for (let i = 0; i < a.length; i++) {
      const x = a[i];
      const y = bArr[i];
      if (x === y) continue;
      if (!equalsInner(x, y, depth + 1, seen)) return false;
    }
    return true;
  }
  if (Array.isArray(b)) return false;
  if (a instanceof Date && b instanceof Date) {
    try {
      const ta = a.getTime();
      const tb = b.getTime();
      return ta === tb || ta !== ta && tb !== tb;
    } catch {
      return false;
    }
  }
  if (a instanceof RegExp && b instanceof RegExp) {
    return a.source === b.source && a.flags === b.flags;
  }
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    for (const [key, value] of a) {
      if (!b.has(key) || !equalsInner(value, b.get(key), depth + 1, seen))
        return false;
    }
    return true;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    for (const value of a) {
      if (!b.has(value)) return false;
    }
    return true;
  }
  if (a instanceof Error && b instanceof Error) {
    if (a.name !== b.name || a.message !== b.message) return false;
  } else if (a instanceof Number && b instanceof Number || a instanceof String && b instanceof String || a instanceof Boolean && b instanceof Boolean) {
    const va = a.valueOf();
    const vb = b.valueOf();
    if (!(va === vb || va !== va && vb !== vb)) return false;
  }
  try {
    if (a.constructor !== b.constructor) {
      return false;
    }
  } catch {
    return false;
  }
  const objA = a;
  const objB = b;
  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  const hasOwn = Object.prototype.hasOwnProperty;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!hasOwn.call(objB, key)) return false;
    const x = objA[key];
    const y = objB[key];
    if (x === y) continue;
    if (!equalsInner(x, y, depth + 1, seen)) return false;
  }
  return true;
}

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/internals/utilities/deep-clone.ts
var globalStructuredClone = typeof globalThis === "object" && globalThis !== null ? globalThis.structuredClone : void 0;
function deepClone(value) {
  if (globalStructuredClone) {
    try {
      return globalStructuredClone(value);
    } catch {
    }
  }
  return cloneValue(value, /* @__PURE__ */ new WeakMap());
}
function cloneValue(value, seen) {
  if (value === null || typeof value !== "object") {
    return value;
  }
  if (typeof value === "function") {
    return value;
  }
  const existing = seen.get(value);
  if (existing) {
    return existing;
  }
  if (value instanceof Date) {
    return new Date(value.getTime());
  }
  if (value instanceof RegExp) {
    return new RegExp(value.source, value.flags);
  }
  if (value instanceof Map) {
    const result2 = /* @__PURE__ */ new Map();
    seen.set(value, result2);
    for (const [key, entryValue] of value) {
      result2.set(cloneValue(key, seen), cloneValue(entryValue, seen));
    }
    return result2;
  }
  if (value instanceof Set) {
    const result2 = /* @__PURE__ */ new Set();
    seen.set(value, result2);
    for (const entry of value) {
      result2.add(cloneValue(entry, seen));
    }
    return result2;
  }
  if (Array.isArray(value)) {
    const result2 = new Array(value.length);
    seen.set(value, result2);
    for (let i = 0; i < value.length; i++) {
      result2[i] = cloneValue(value[i], seen);
    }
    return result2;
  }
  if (ArrayBuffer.isView(value)) {
    if (value instanceof DataView) {
      const bufferClone2 = cloneValue(value.buffer, seen);
      return new DataView(bufferClone2, value.byteOffset, value.byteLength);
    }
    const viewWithSlice = value;
    if (typeof viewWithSlice.slice === "function") {
      return viewWithSlice.slice();
    }
    const bufferClone = cloneValue(
      value.buffer,
      seen
    );
    return new value.constructor(
      bufferClone,
      value.byteOffset,
      value.length
    );
  }
  if (value instanceof ArrayBuffer) {
    return value.slice(0);
  }
  const proto = Object.getPrototypeOf(value);
  const result = proto ? Object.create(proto) : {};
  seen.set(value, result);
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor) continue;
    if ("value" in descriptor) {
      descriptor.value = cloneValue(descriptor.value, seen);
    }
    Object.defineProperty(result, key, descriptor);
  }
  return result;
}

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/physical/entity-value-store.ts
var EntityValueStore = class {
  retainedEntities = /* @__PURE__ */ new Map();
  inspectionBaselines = /* @__PURE__ */ new Map();
  prepareValueTransition(subject, physicalAfter, fields, previous) {
    const physicalBefore = previous?.physicalAfter ?? this.retainedEntities.get(subject);
    if (fields === "derive") {
      const descriptors = Object.getOwnPropertyDescriptors(physicalAfter);
      let hasAccessors = false;
      for (const field of Object.keys(physicalAfter)) {
        const descriptor = descriptors[field];
        if (!descriptor || "value" in descriptor) continue;
        const value = physicalAfter[field];
        hasAccessors = true;
        descriptors[field] = {
          value,
          enumerable: descriptor.enumerable,
          writable: true,
          configurable: descriptor.configurable
        };
      }
      if (hasAccessors) {
        physicalAfter = Object.create(
          Object.getPrototypeOf(physicalAfter),
          descriptors
        );
      }
      fields = physicalBefore ? [.../* @__PURE__ */ new Set([
        ...Object.keys(physicalBefore),
        ...Object.keys(physicalAfter)
      ])].filter(
        (field) => Object.prototype.hasOwnProperty.call(physicalBefore, field) !== Object.prototype.hasOwnProperty.call(physicalAfter, field) || !Object.is(physicalBefore[field], physicalAfter[field])
      ) : Object.keys(physicalAfter);
    }
    const ordinaryBefore = previous?.ordinaryAfter ?? this.inspectionBaselines.get(subject) ?? physicalBefore;
    let ordinaryAfter = physicalAfter;
    if (getActiveWriteContext()?.participation === "inspection") {
      ordinaryAfter = ordinaryBefore ?? physicalAfter;
    } else if (fields && ordinaryBefore) {
      const merged = { ...ordinaryBefore };
      for (const field of fields) {
        if (Object.prototype.hasOwnProperty.call(physicalAfter, field))
          Object.defineProperty(merged, field, {
            value: physicalAfter[field],
            enumerable: true,
            writable: true,
            configurable: true
          });
        else delete merged[field];
      }
      ordinaryAfter = merged;
    }
    return Object.freeze({
      subject,
      physicalBefore,
      physicalAfter,
      ordinaryBefore,
      ordinaryAfter,
      retainDivergence: ordinaryBefore !== void 0 && !deepEqual(ordinaryAfter, physicalAfter)
    });
  }
  prepareRealizationTransition(subject, physicalAfter, edits) {
    const physicalBefore = this.retainedEntities.get(subject);
    const ordinaryBefore = this.inspectionBaselines.get(subject) ?? physicalBefore;
    if (!ordinaryBefore)
      throw new Error("Point realization ordinary lifetime is unavailable");
    let ordinaryAfter = ordinaryBefore;
    for (const edit of edits) {
      if (edit.kind === "row") {
        ordinaryAfter = deepClone(edit.value);
      } else {
        const next = { ...ordinaryAfter };
        if (edit.present)
          Object.defineProperty(next, edit.field, {
            value: deepClone(edit.value),
            enumerable: true,
            configurable: true,
            writable: true
          });
        else delete next[edit.field];
        ordinaryAfter = next;
      }
    }
    return Object.freeze({
      subject,
      physicalBefore,
      physicalAfter,
      ordinaryBefore,
      ordinaryAfter,
      retainDivergence: !deepEqual(ordinaryAfter, physicalAfter)
    });
  }
  installValueTransition(transition) {
    if (transition.retainDivergence)
      this.inspectionBaselines.set(
        transition.subject,
        transition.ordinaryAfter
      );
    else this.inspectionBaselines.delete(transition.subject);
    recordProductionSubstrateStat("valueStoreWrites");
    this.retainedEntities.set(transition.subject, transition.physicalAfter);
  }
  ordinaryForSubject(subjectId) {
    return this.inspectionBaselines.get(subjectId) ?? this.retainedEntities.get(subjectId);
  }
  dischargeOrdinaryValue(subjectId) {
    this.inspectionBaselines.delete(subjectId);
  }
  backingForSubject(subjectId) {
    return this.retainedEntities.get(subjectId);
  }
  retainSubjectValue(subjectId, entity) {
    this.inspectionBaselines.delete(subjectId);
    recordProductionSubstrateStat("valueStoreWrites");
    this.retainedEntities.set(subjectId, entity);
  }
  prepareTargetValues(subjects) {
    const target = new Map(this.retainedEntities);
    for (const subject of subjects) {
      target.set(subject.subjectId, subject.value);
    }
    return target;
  }
  installPreparedTargetValues(target) {
    this.retainedEntities = target;
  }
  hasRetainedValueBacking(subjectId) {
    return this.retainedEntities.has(subjectId);
  }
  retireSubjectValue(subjectId) {
    this.inspectionBaselines.delete(subjectId);
    return this.retainedEntities.delete(subjectId);
  }
  clear() {
    this.inspectionBaselines.clear();
    this.retainedEntities.clear();
  }
};

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/internals/intrinsic-mutation.ts
function installTerminalRecord(plan) {
  for (let i = 0; i < plan.writes.length; i++) {
    const write = plan.writes[i];
    write.map.set(write.key, write.value);
  }
  for (let i = 0; i < plan.adds.length; i++) {
    const add = plan.adds[i];
    add.set.add(add.value);
  }
}
var UNOBSERVABLE_SOURCE = Object.freeze({
  observer: void 0
});

// ../../../../private/tmp/prepared-placement-index/candidate/packages/kernel/src/lib/physical/entity-mutation-frame.ts
var EntityMutationFrame = class {
  constructor(valueStore, structuralStore) {
    this.valueStore = valueStore;
    this.structuralStore = structuralStore;
  }
  /**
   * The staged instructions. Read-only after commit by membership observation
   * (`entity-membership-source.ts`), which derives point deltas from them.
   */
  mutations = [];
  preparedInstructions;
  ordinaryOrder;
  orderEndpoints;
  finalFront;
  finalOrder;
  stageFinalFront(keys) {
    this.finalFront = keys;
  }
  stageFinalOrder(keys) {
    this.finalOrder = keys;
  }
  preparePlacement() {
    const instructions = this.preparedInstructions = this.prepareCommitInstructions();
    const stage2 = this.structuralStore.preparePlacement();
    const base = this.structuralStore.preparePlacement();
    let beforeOrder = this.ordinaryOrder ? base.snapshot() : void 0;
    for (const mutation of instructions) {
      if (mutation.kind === "create-fresh-subject")
        stage2.insert(mutation.subjectId, mutation.key);
      else if (mutation.kind === "tombstone-subject")
        stage2.remove(mutation.subjectId);
      else if (mutation.kind === "restore-subject")
        stage2.insert(
          mutation.subjectId,
          mutation.key,
          mutation.resolvedPlacement.beforeSubject,
          mutation.resolvedPlacement.afterSubject
        );
      else if (mutation.kind === "transfer-key") {
        stage2.rekey(mutation.subjectId, mutation.toKey);
        if (mutation.placement)
          stage2.insert(
            mutation.subjectId,
            mutation.toKey,
            mutation.placement.beforeSubject,
            mutation.placement.afterSubject
          );
      }
    }
    const stagedSubjects = /* @__PURE__ */ new Map();
    if (this.finalFront || this.finalOrder) {
      for (const [id, row] of stage2.patch) {
        if (row.present && !Number.isNaN(row.key) && !stagedSubjects.has(row.key))
          stagedSubjects.set(row.key, id);
      }
    }
    const subjectFor = (key) => stagedSubjects.get(key) ?? this.structuralStore.subjectIdForKey(key);
    let prefixOrder;
    if (this.finalFront) {
      const ids = this.finalFront.map(subjectFor).filter((id) => id !== void 0);
      const existing = ids.filter((subject) => base.read(subject).present);
      let cursor = base.head;
      let moved = false;
      for (const subject of existing) {
        if (cursor !== subject) {
          moved = true;
          break;
        }
        const row = base.read(subject);
        cursor = row.present ? row.afterSubject : void 0;
      }
      if (moved) beforeOrder = base.snapshot();
      for (const id of ids) stage2.remove(id);
      const after = stage2.head;
      let before;
      for (let index = 0; index < ids.length; index++) {
        stage2.insert(ids[index], this.finalFront[index], before, after);
        before = ids[index];
      }
      if (moved) this.ordinaryOrder = prefixOrder = stage2.snapshot();
    }
    if (this.finalOrder)
      stage2.order(
        this.finalOrder.map(subjectFor).filter((id) => id !== void 0)
      );
    if (beforeOrder)
      this.orderEndpoints = Object.freeze({
        before: beforeOrder,
        // A later full order changes the prepared stage. Otherwise the prefix
        // domain already is this exact immutable physical-after sequence.
        after: !this.finalOrder && prefixOrder ? prefixOrder : stage2.snapshot()
      });
    return stage2;
  }
  stageValueReplacement(replacement) {
    this.mutations.push(replacement);
  }
  stageRetainedValueRetirement(retirement) {
    this.mutations.push(retirement);
  }
  stageKeyTransfer(transfer) {
    this.mutations.push(transfer);
  }
  stageSubjectTombstone(tombstone) {
    this.mutations.push(tombstone);
  }
  stageFreshSubject(freshSubject) {
    this.mutations.push(freshSubject);
  }
  stageSubjectRestore(restoration) {
    this.mutations.push(restoration);
  }
  /**
   * @param observeCommitted Supplied only when a committed-entity observer is
   * active. Receives every touched lifetime once, after EVERY prepared
   * instruction has applied and before the caller publishes or notifies, so a
   * multi-row frame is never visible to admission one row at a time. A
   * preparation failure throws before anything applies or is reported.
   */
  commit(observeCommitted, responsibility, structuralFrontier, valueTransitions, installOrdinary) {
    const preparedMutations = this.preparedInstructions ?? this.prepareCommitInstructions();
    const before = observeCommitted ? /* @__PURE__ */ new Map() : void 0;
    if (before) {
      for (const mutation of preparedMutations) {
        const previous = before.get(mutation.subjectId);
        before.set(mutation.subjectId, {
          value: previous ? previous.value : this.structuralStore.activeKeyForSubject(mutation.subjectId) === void 0 ? void 0 : this.valueStore.backingForSubject(mutation.subjectId),
          structural: (previous?.structural ?? false) || mutation.kind !== "replace-value"
        });
      }
    }
    const physicallyChangedSubjectIds = /* @__PURE__ */ new Set();
    const allocatedSubjectIds = [];
    for (const mutation of preparedMutations) {
      if (mutation.kind === "create-fresh-subject") {
        this.structuralStore.createSubject(mutation.subjectId, mutation.key);
        this.valueStore.retainSubjectValue(
          mutation.subjectId,
          mutation.nextValue
        );
        allocatedSubjectIds.push(mutation.subjectId);
        continue;
      }
      if (mutation.kind === "restore-subject") {
        this.structuralStore.restoreSubjectAtResolvedPlacement(
          mutation.subjectId,
          mutation.key,
          mutation.resolvedPlacement,
          mutation.restoreAllowed
        );
        if (mutation.resolvedValue !== void 0) {
          this.valueStore.retainSubjectValue(
            mutation.subjectId,
            mutation.resolvedValue
          );
        }
        physicallyChangedSubjectIds.add(mutation.subjectId);
        continue;
      }
      if (mutation.kind === "replace-value") {
        const transition = valueTransitions?.get(mutation);
        if (transition) this.valueStore.installValueTransition(transition);
        else
          this.valueStore.retainSubjectValue(
            mutation.subjectId,
            mutation.nextValue
          );
        continue;
      }
      if (mutation.kind === "retire-retained-value") {
        const hadBacking = this.valueStore.retireSubjectValue(
          mutation.subjectId
        );
        if (mutation.forgetLifetime) {
          this.structuralStore.forgetSubject(mutation.subjectId);
        } else {
          this.structuralStore.retireSubject(mutation.subjectId);
        }
        if (hadBacking) {
          physicallyChangedSubjectIds.add(mutation.subjectId);
        }
        continue;
      }
      if (mutation.kind === "transfer-key") {
        this.structuralStore.transferSubject(
          mutation.subjectId,
          mutation.fromKey,
          mutation.toKey
        );
        if (mutation.placement)
          this.structuralStore.placeActiveSubject(
            mutation.subjectId,
            mutation.placement.beforeSubject,
            mutation.placement.afterSubject
          );
        physicallyChangedSubjectIds.add(mutation.subjectId);
        continue;
      }
      this.structuralStore.tombstoneSubject(
        mutation.subjectId,
        mutation.key,
        mutation.restoreAllowed
      );
      physicallyChangedSubjectIds.add(mutation.subjectId);
    }
    if (this.finalFront) this.structuralStore.moveKeysToFront(this.finalFront);
    if (this.finalOrder)
      this.structuralStore.reorderActiveKeys(this.finalOrder);
    if (structuralFrontier) {
      structuralFrontier.after = this.structuralStore.activeOrderFrontier();
    }
    installOrdinary?.();
    if (responsibility) {
      installTerminalRecord(responsibility);
    }
    if (before && observeCommitted) {
      observeCommitted(
        [...before].map(([subject, entry]) => ({
          subject,
          before: entry.value,
          after: this.structuralStore.activeKeyForSubject(subject) === void 0 ? void 0 : this.valueStore.backingForSubject(subject),
          structural: entry.structural
        }))
      );
    }
    return {
      physicallyChangedSubjectIds: [...physicallyChangedSubjectIds],
      allocatedSubjectIds
    };
  }
  prepareCommitInstructions() {
    return this.mutations.map((mutation) => {
      if (mutation.kind === "retire-retained-value" && mutation.forgetLifetime) {
        const state = this.structuralStore.stateForSubject(mutation.subjectId);
        if (!state || state.active) {
          throw new Error(
            `Subject ${String(
              mutation.subjectId
            )} must be tombstoned before forgetting its lifetime.`
          );
        }
      }
      if (mutation.kind !== "restore-subject") {
        return mutation;
      }
      return {
        ...mutation,
        resolvedValue: mutation.realizedValue ?? this.valueStore.backingForSubject(mutation.subjectId),
        resolvedPlacement: this.structuralStore.resolveSubjectRestorePlacement(
          mutation.beforeSubject,
          mutation.afterSubject
        )
      };
    });
  }
};

// ../../../../private/tmp/prepared-placement-index/review/probe.ts
var s = new StructuralStore();
var one = s.allocateFreshSubjectId();
s.createSubject(one, 0);
var nan = s.allocateFreshSubjectId();
s.createSubject(nan, NaN);
var f = new EntityMutationFrame(new EntityValueStore(), s);
var fresh = s.allocateFreshSubjectId();
f.stageFreshSubject({ kind: "create-fresh-subject", key: "0", subjectId: fresh, nextValue: { id: "0" } });
f.stageFinalFront(["0", -0]);
f.stageFinalOrder([NaN, "0", 0]);
var stage = f.preparePlacement();
assert.deepEqual(stage.snapshot(), [nan, fresh, one]);
assert.deepEqual(s.activeKeysSnapshot().map((k) => Number.isNaN(k) ? "NaN" : k), [0, "NaN"]);
console.log(JSON.stringify({ prepared: stage.snapshot(), live: s.activeKeysSnapshot().map((k) => Number.isNaN(k) ? "NaN" : k) }));
var h = new EntityMutationFrame(new EntityValueStore(), s);
var newNan = s.allocateFreshSubjectId();
h.stageFreshSubject({ kind: "create-fresh-subject", key: "new", subjectId: newNan, nextValue: { id: "new" } });
h.stageKeyTransfer({ kind: "transfer-key", fromKey: "new", toKey: "renamed", subjectId: newNan });
h.stageFinalOrder(["renamed", 0, NaN]);
console.log(JSON.stringify({ rekeyPrepared: h.preparePlacement().snapshot() }));
