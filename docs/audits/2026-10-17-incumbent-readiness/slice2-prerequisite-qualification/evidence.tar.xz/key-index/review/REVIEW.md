# Independent prepared-placement key index review

No concrete blocker demonstrated in this bounded private lookup correction. Reviewed entity-mutation-frame.ts SHA256 3cb6d065c1700cfcd4b6a023d3ae8679d207c9e6e1c31234ae479b18e5900e01 against entity-marker-retention candidate. Independent package comparison found only this runtime file and prepared-placement-index.spec.ts changed. No runtime/controller/test edits by reviewer.

Old subjectFor searched stage.patch for every supplied final key. Fresh batch measured visits N(N+1)/2 at16/64/256/1024, matching source nested iteration. The reported130k E10 processes terminated after376 CPU-bound seconds are incomplete executions, not27 assertion failures. Seven other files115 pass does not complete those missing cases. The correction targets that exact algorithmic loop, not general collection work or CPU acceptance.

The new Map is prepared once after all create/tombstone/restore/transfer instructions. It reads final stage rows, keeps first present subject for a strict-equal key, and falls back to existing committed key lookup. Number.isNaN excludes staged numericNaN, preserving old === nonmatch; stringNaN is not excluded. SameValueZero Map treatment of0/-0 matches prior ===. String0 remains distinct. Removed staged rows are omitted just as before; committed fallback behavior is not silently changed. Rekey uses final stage key rather than stale instruction key. Both finalFront and finalOrder use the same local index before any live installation; their established ordering remains prefix then final target.

No Map escapes preparePlacement or installs into source/index/authority state. It carries subject numbers and primitive keys only. No new callbacks, live reentry boundary or reflection beyond existing private staged-row reads introduced; a throw constructing/iterating this local index cannot install a partial map. Existing frame revision validation and preparation fault/reentry tests remain applicable; no universal OOM recovery claimed. It does not create an ordinary owner, extra lifetime root or public API.

## Executed discriminating probe

EXPECTED.md and BEFORE.sha256 precede execution. Same private prepared-frame probe bundled against previous control and current source, with all source inputs hashed in control-INPUTS.json/indexed-INPUTS.json. It combines fresh string0, committed numeric0/-0 and committedNaN, finalFront plus finalOrder; both produce [NaN subject2, string0 subject3, numeric0 subject1]. Live physical order remains unchanged after preparation. Separate create then staged rekey resolves final renamed key identically. CONTROL-FIRST.log and INDEXED-FIRST.log match exactly. This is a private contract-preservation probe, not new public key semantics.

Read seven preregistered tests: six exact staged-map iterator work assertions for setAll/prepend32/128/512 (<=2N), and public remove/reuse rollback lifetime identity. First6fail/1pass establishes old quadratic loop rather than vacuous timing. Worker focused result is separate evidence; reviewer did not rerun its Nx vector. Counted iterator work omits legitimate whole-order snapshots, allocations, physical installation and other consumers; no overall linear CPU claim.

## Remaining gate

Re-execute the previously incomplete unchanged E10 correctness shards on frozen source with pre/post identity, preserving original workloads/assertions. This review does not turn their timeout/termination into either passes or semantic failures. Parent owns full finite slice2 reconciliation, marker-retention correction review, types and original controls. No later-slice, broad kernel/framework, retention/GC, production cost or release sign-off follows.
