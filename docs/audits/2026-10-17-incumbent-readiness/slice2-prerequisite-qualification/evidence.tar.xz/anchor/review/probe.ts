import assert from 'node:assert/strict';
import {EntityPlacementStage} from '@case/lib/physical/entity-placement-stage';
import {createPreparedPlacementVisibility} from '@case/lib/physical/prepared-placement-visibility';
let seed=71237;const rand=(n:number)=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;};let queries=0;
for(let trial=0;trial<3000;trial++){
 const n=1+rand(12),ids=Array.from({length:n},(_,i)=>i+1);for(let i=n-1;i;i--){const j=rand(i+1);[ids[i],ids[j]]=[ids[j],ids[i]];}const cyclic=rand(5)===0;const rows=new Map(ids.map((id,i)=>[id,{present:true as const,key:id,beforeSubject:i?ids[i-1]:cyclic?ids.at(-1):undefined,afterSubject:i+1<n?ids[i+1]:cyclic?ids[0]:undefined}]));const p=new EntityPlacementStage<number>(id=>rows.get(id)??{present:false},ids[0],ids.at(-1));for(const [id,row]of rows)if(rand(2))p.patch.set(id,row);const visible=new Set(ids.filter(()=>rand(3)===0));if(rand(2))visible.add(99);const q=createPreparedPlacementVisibility(p,id=>visible.has(id));
 const reference=(start:number|undefined,direction:'before'|'after',excluded?:number)=>{let id=start;const seen=new Set<number>();while(id!==undefined&&id!==excluded&&!seen.has(id)){seen.add(id);if(visible.has(id))return id;const r=p.read(id);id=r.present?(direction==='before'?r.beforeSubject:r.afterSubject):undefined;}return undefined;};
 for(let turn=0;turn<30;turn++){const id=rand(n+2)+1,on=!!rand(2);if(on)visible.add(id);else visible.delete(id);q.setVisible(id,on);for(const direction of ['before','after'] as const){const start=rand(n+3)===0?99:ids[rand(n)],excluded=rand(3)?ids[rand(n)]:undefined;assert.equal(q.resolve(start,direction,excluded),reference(start,direction,excluded),JSON.stringify({trial,turn,ids,cyclic,patch:[...p.patch.keys()],visible:[...visible],start,direction,excluded}));queries++;}}
}
console.log(JSON.stringify({trials:3000,queries,seed,match:true}));
