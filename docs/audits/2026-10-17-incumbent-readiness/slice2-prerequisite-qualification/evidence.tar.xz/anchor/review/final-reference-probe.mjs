// ../../../../private/tmp/anchor-index-candidate/review/probe.ts
import assert from "node:assert/strict";

// ../../../../private/tmp/anchor-index-candidate/candidate/packages/kernel/src/lib/physical/entity-placement-stage.ts
var EntityPlacementStage = class {
  constructor(base, head, tail) {
    this.base = base;
    this.head = head;
    this.tail = tail;
  }
  patch = /* @__PURE__ */ new Map();
  read(subject) {
    return this.patch.get(subject) ?? this.base(subject);
  }
  change(subject, change) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement neighbor is absent");
    this.patch.set(subject, { ...row, ...change });
  }
  remove(subject) {
    const row = this.read(subject);
    if (!row.present) return;
    if (row.beforeSubject === void 0) this.head = row.afterSubject;
    else this.change(row.beforeSubject, { afterSubject: row.afterSubject });
    if (row.afterSubject === void 0) this.tail = row.beforeSubject;
    else this.change(row.afterSubject, { beforeSubject: row.beforeSubject });
    this.patch.set(subject, { present: false });
  }
  insert(subject, key, beforeSubject, afterSubject) {
    this.remove(subject);
    const after = afterSubject === void 0 ? void 0 : this.read(afterSubject);
    const before = beforeSubject === void 0 ? void 0 : this.read(beforeSubject);
    if (after?.present) beforeSubject = after.beforeSubject;
    else if (before?.present) afterSubject = before.afterSubject;
    else {
      beforeSubject = this.tail;
      afterSubject = void 0;
    }
    if (beforeSubject === void 0) this.head = subject;
    else this.change(beforeSubject, { afterSubject: subject });
    if (afterSubject === void 0) this.tail = subject;
    else this.change(afterSubject, { beforeSubject: subject });
    this.patch.set(subject, {
      present: true,
      key,
      beforeSubject,
      afterSubject
    });
  }
  snapshot() {
    const subjects = [];
    const seen = /* @__PURE__ */ new Set();
    let subject = this.head;
    while (subject !== void 0) {
      if (seen.has(subject)) throw new Error("Prepared placement cycle");
      seen.add(subject);
      subjects.push(subject);
      const row = this.read(subject);
      if (!row.present)
        throw new Error("Prepared placement contains absent lifetime");
      subject = row.afterSubject;
    }
    return Object.freeze(subjects);
  }
  orderDomain(subjects) {
    const domain = new Set(subjects);
    if (domain.size !== subjects.length)
      throw new Error("Prepared order domain repeats a lifetime");
    for (const subject of subjects)
      if (!this.read(subject).present)
        throw new Error("Prepared order domain contains absent lifetime");
    const current = this.snapshot();
    let index = 0;
    const ordered = Object.freeze(
      current.map(
        (subject) => domain.has(subject) ? subjects[index++] : subject
      )
    );
    this.order(ordered);
    return ordered;
  }
  rekey(subject, key) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement rekey lifetime is absent");
    this.patch.set(subject, { ...row, key });
  }
  order(subjects) {
    for (let i = 0; i < subjects.length; i++) {
      const row = this.read(subjects[i]);
      if (!row.present) throw new Error("Order lifetime is absent");
      this.patch.set(subjects[i], {
        ...row,
        beforeSubject: subjects[i - 1],
        afterSubject: subjects[i + 1]
      });
    }
    this.head = subjects[0];
    this.tail = subjects.at(-1);
  }
};

// ../../../../private/tmp/anchor-index-candidate/candidate/packages/kernel/src/lib/physical/prepared-placement-visibility.ts
function createPreparedPlacementVisibility(physical, isVisible) {
  const overrides = /* @__PURE__ */ new Map();
  const positions = /* @__PURE__ */ new Map();
  let built = false;
  const visible = (id) => overrides.get(id) ?? isVisible(id);
  function build() {
    if (built) return;
    built = true;
    const present = new Map(
      [...physical.patch].filter(
        (entry) => entry[1].present
      )
    );
    const visited = /* @__PURE__ */ new Set();
    for (const [id, row] of present) {
      if (visited.has(id) || row.beforeSubject !== void 0 && present.has(row.beforeSubject))
        continue;
      const ids = [];
      let next = id;
      while (next !== void 0 && present.has(next) && !visited.has(next)) {
        visited.add(next);
        ids.push(next);
        next = present.get(next)?.afterSubject;
      }
      let size = 1;
      while (size < ids.length) size *= 2;
      const run = { ids, size, counts: new Array(size * 2).fill(0) };
      ids.forEach((subject, at) => {
        positions.set(subject, { run, at });
        run.counts[size + at] = Number(visible(subject));
      });
      for (let i = size - 1; i > 0; i--)
        run.counts[i] = run.counts[i * 2] + run.counts[i * 2 + 1];
    }
  }
  function find(run, lo, hi, reverse, node = 1, left = 0, right = run.size - 1) {
    if (lo > right || hi < left || run.counts[node] === 0) return void 0;
    if (left === right) return left;
    const mid = left + right >>> 1;
    const first = reverse ? find(run, lo, hi, reverse, node * 2 + 1, mid + 1, right) : find(run, lo, hi, reverse, node * 2, left, mid);
    return first ?? (reverse ? find(run, lo, hi, reverse, node * 2, left, mid) : find(run, lo, hi, reverse, node * 2 + 1, mid + 1, right));
  }
  return {
    setVisible(subject, value) {
      overrides.set(subject, value);
      const at = positions.get(subject);
      if (!at) return;
      let n = at.run.size + at.at;
      at.run.counts[n] = Number(value);
      while (n > 1) {
        n >>>= 1;
        at.run.counts[n] = at.run.counts[n * 2] + at.run.counts[n * 2 + 1];
      }
    },
    resolve(start, direction, excluded) {
      build();
      let subject = start;
      const seen = /* @__PURE__ */ new Set();
      while (subject !== void 0 && subject !== excluded && !seen.has(subject)) {
        seen.add(subject);
        const indexed = positions.get(subject);
        if (indexed) {
          const { run, at } = indexed;
          const stop = excluded === void 0 ? void 0 : positions.get(excluded);
          const reverse = direction === "before";
          const bound = stop?.run === run ? stop.at : void 0;
          const lo = reverse ? bound !== void 0 && bound <= at ? bound + 1 : 0 : at;
          const hi = reverse ? at : bound !== void 0 && bound >= at ? bound - 1 : run.ids.length - 1;
          const found = find(run, lo, hi, reverse);
          if (found !== void 0) return run.ids[found];
          if (bound !== void 0 && (reverse ? bound <= at : bound >= at))
            return void 0;
          const edge = physical.patch.get(
            run.ids[reverse ? 0 : run.ids.length - 1]
          );
          subject = edge?.present ? reverse ? edge.beforeSubject : edge.afterSubject : void 0;
        } else {
          if (visible(subject)) return subject;
          const row = physical.read(subject);
          if (!row.present) return void 0;
          subject = direction === "before" ? row.beforeSubject : row.afterSubject;
        }
      }
      return void 0;
    }
  };
}

// ../../../../private/tmp/anchor-index-candidate/review/probe.ts
var seed = 71237;
var rand = (n) => {
  seed = Math.imul(seed, 1664525) + 1013904223 >>> 0;
  return seed % n;
};
var queries = 0;
for (let trial = 0; trial < 3e3; trial++) {
  const n = 1 + rand(12), ids = Array.from({ length: n }, (_, i) => i + 1);
  for (let i = n - 1; i; i--) {
    const j = rand(i + 1);
    [ids[i], ids[j]] = [ids[j], ids[i]];
  }
  const cyclic = rand(5) === 0;
  const rows = new Map(ids.map((id, i) => [id, { present: true, key: id, beforeSubject: i ? ids[i - 1] : cyclic ? ids.at(-1) : void 0, afterSubject: i + 1 < n ? ids[i + 1] : cyclic ? ids[0] : void 0 }]));
  const p = new EntityPlacementStage((id) => rows.get(id) ?? { present: false }, ids[0], ids.at(-1));
  for (const [id, row] of rows) if (rand(2)) p.patch.set(id, row);
  const visible = new Set(ids.filter(() => rand(3) === 0));
  if (rand(2)) visible.add(99);
  const q = createPreparedPlacementVisibility(p, (id) => visible.has(id));
  const reference = (start, direction, excluded) => {
    let id = start;
    const seen = /* @__PURE__ */ new Set();
    while (id !== void 0 && id !== excluded && !seen.has(id)) {
      seen.add(id);
      if (visible.has(id)) return id;
      const r = p.read(id);
      id = r.present ? direction === "before" ? r.beforeSubject : r.afterSubject : void 0;
    }
    return void 0;
  };
  for (let turn = 0; turn < 30; turn++) {
    const id = rand(n + 2) + 1, on = !!rand(2);
    if (on) visible.add(id);
    else visible.delete(id);
    q.setVisible(id, on);
    for (const direction of ["before", "after"]) {
      const start = rand(n + 3) === 0 ? 99 : ids[rand(n)], excluded = rand(3) ? ids[rand(n)] : void 0;
      assert.equal(q.resolve(start, direction, excluded), reference(start, direction, excluded), JSON.stringify({ trial, turn, ids, cyclic, patch: [...p.patch.keys()], visible: [...visible], start, direction, excluded }));
      queries++;
    }
  }
}
console.log(JSON.stringify({ trials: 3e3, queries, seed, match: true }));
