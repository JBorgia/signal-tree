# Independent pending-subject cost boundary

Proposal is within bounded existing gate: maintain a private per-call occurrence-count Map for pending subject IDs instead of recreating Set(pending.map(...)) every iteration. It can preserve exact semantics without new topology/authority or a queue/order rewrite. No correction source is present yet, so this is premise adjudication, not implementation acceptance. No runtime edits or new executions by reviewer.

## Cause and history

BASE-SOURCE.sha256 stamps original target-transition source. Parent ROLLBACK-MAP-FIRST.json gives deterministic map slots N+N(N+1)/2 for16/64/256/1024; COUNTS.json independently checks formula and useful public endpoint sizes/first/last. The N term is applyTurnOrder additions.map; suffix sum is placeAdditions rebuilding pendingSubjects. This inherited loop is independent of corrected source anchor visibility and prepared key lookup. Incomplete130k worker termination remains incomplete, not an assertion failure.

Historical19a5bd034 `preserve lifetime fields and placement through reversal` preserves deliberate unblocked-first anchor priority, with lineage6b6badc75/d2cbd16f1 for ghost rows/replay order/anchor readiness. Current comment explains `updateOne c; removeOne a; removeOne c`: c must be placed before a, otherwise restored z,c,a instead of correct placement. Counts must not alter waitsOnPending, unblockedIndex selection, fallback readyIndex, pending array order, insertion positions, survivor predicates or cycle/contradictory/no-live-anchor errors. Ghost rows and per-turn replay remain intact.

## Exact invariant sufficient for equivalence

At every iteration start, count(subject) equals number of remaining pending entries with that subject; membership iff count>0. Initialize once from the exact pending array. After removing selected pending[readyIndex] through the same splice, decrement its subject count and delete only when zero. A plain Set.delete is incorrect for repeated same-subject entries. All pendingSubjects.has queries then equal the recomputed Set at that iteration; every branch and selected effect remains identical by induction. Cycle fallback drains pending and exits, so count Map is discarded; no new live authority or lifetime retention survives the function. No effect sorting/dedup is authorized.

This assumes existing immutable prepared lifetime identities, not arbitrary getters changing subjectId between reads. Do not invent new public dynamic identity semantics to defeat an existing captured-fact invariant. Failure before installation remains covered by the enclosing prepared target; there are no new user callbacks or live writes in count updates.

## Minimal acceptance evidence

Preserve prewritten map-work red and unchanged original tests. Add direct reference-equivalence controls with duplicate subjects, pending anchor to a duplicate subject after first occurrence removed, ghost add/remove, mutual anchor cycle with/without survivor, contradictory/missing anchor refusals, chain and unblocked-first mixed priority. Compare exact result/error and selected ordering where observable; final membership alone is insufficient. Measure subject-map rebuild work at increasing N; do not count untouched readiness scans as optimized.

Readiness findIndex, order.includes/indexOf and splice remain potentially expensive. This correction removes only the demonstrated repeated pending Set build; it does not prove overall linear rollback or promise130k completion. If unchanged E10 remains incomplete, preserve next causal evidence and assess its actual scope rather than broad queue replacement. This correct-cost-result loop is not a renewed loss of ordinary responsibility under a claimed general semantic repair, so evidence alone does not invoke recurrence stop. No later-slice or production cost acceptance follows.
