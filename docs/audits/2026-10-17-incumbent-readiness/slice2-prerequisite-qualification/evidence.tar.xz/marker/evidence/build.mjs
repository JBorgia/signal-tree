import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
const root='/private/tmp/entity-marker-retention/candidate';const out='/private/tmp/entity-marker-retention/evidence';
const {build}=createRequire(resolve(root,'package.json'))('esbuild');
const sha=s=>createHash('sha256').update(s).digest('hex');
for(const name of ['receipt-graph-gc','receipt-graph-dropped-gc']){
 const source=readFileSync(`/private/tmp/link-fallback-successor/controls-original/combined/${name}.ts`,'utf8');writeFileSync(resolve(out,name+'.ts'),source);
 const r=await build({stdin:{contents:source,loader:'ts',resolveDir:root},bundle:true,write:false,metafile:true,platform:'node',format:'esm',target:'node24',plugins:[{name:'native',setup(b){b.onResolve({filter:/^research-private$/},()=>({path:resolve(root,'packages/kernel/src/lib/experimental-publication/private.ts')}));}}]});
 writeFileSync(resolve(out,name+'.mjs'),r.outputFiles[0].text);writeFileSync(resolve(out,name+'.inputs.json'),JSON.stringify({witness:sha(source),inputs:Object.keys(r.metafile.inputs).filter(p=>p!=='<stdin>').map(path=>({path,sha256:sha(readFileSync(path))}))},null,2));
}
