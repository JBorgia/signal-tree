// ../../../../private/tmp/entity-marker-retention/review/distinct-config.ts
import assert from "node:assert/strict";

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/cell-identity.ts
var CELL_MARK = Symbol("SignalTree:Cell");
function markTreeCell(cell) {
  Object.defineProperty(cell, CELL_MARK, {
    value: true,
    enumerable: false,
    writable: false,
    configurable: true
  });
  return cell;
}
function isTreeCell(value) {
  return typeof value === "function" && value[CELL_MARK] === true;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/leaf.ts
var LEAF_DEFINITION = Symbol.for("SignalTree:LeafDefinition");
function leaf(value) {
  const definition = {};
  Object.defineProperty(definition, LEAF_DEFINITION, { value });
  return definition;
}
function isLeafDefinition(value) {
  return typeof value === "object" && value !== null && Object.prototype.hasOwnProperty.call(value, LEAF_DEFINITION) && Object.getOwnPropertyDescriptor(value, LEAF_DEFINITION)?.enumerable === false;
}
function leafDefinitionValue(definition) {
  return definition[LEAF_DEFINITION];
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/observation-adapter.ts
var NEUTRAL_OBSERVATION_ADAPTER = {
  createToken: () => ({
    observe: () => void 0,
    invalidate: () => void 0
  }),
  runInvalidationGroup: (run) => run()
};

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/production-substrate-stats.ts
var PRODUCTION_SUBSTRATE_STATS_ENABLED = true;
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/intrinsic-mutation.ts
function installTerminalRecord(plan) {
  for (let i = 0; i < plan.writes.length; i++) {
    const write = plan.writes[i];
    write.map.set(write.key, write.value);
  }
  for (let i = 0; i < plan.adds.length; i++) {
    const add = plan.adds[i];
    add.set.add(add.value);
  }
}
var SOURCES = /* @__PURE__ */ new WeakMap();
var SOURCE_ACCESSORS = {
  prepareTerminal: {
    get() {
      return this.terminalPreparer;
    }
  },
  terminal: {
    get() {
      return this.terminalRecord?.observer;
    }
  },
  capture: {
    get() {
      return this.captureRecord?.observer;
    }
  }
};
function compose(record) {
  const { observers } = record;
  if (observers === void 0 || observers.size === 0) {
    record.observer = void 0;
    return;
  }
  if (observers.size === 1) {
    const only = observers.values().next().value;
    record.observer = (mutation) => {
      try {
        only(mutation);
      } catch {
      }
    };
    return;
  }
  const snapshot = [...observers];
  record.observer = (mutation) => {
    for (const observer of snapshot) {
      try {
        observer(mutation);
      } catch {
      }
    }
  };
}
var UNOBSERVABLE_SOURCE = Object.freeze({
  observer: void 0
});
function registerIntrinsicMutationSource(node) {
  const record = { observers: void 0, observer: void 0 };
  Object.defineProperties(record, SOURCE_ACCESSORS);
  SOURCES.set(node, record);
  return record;
}
function observeIntrinsicMutations(node, observer, capture = false) {
  const source = SOURCES.get(node);
  if (!source) return void 0;
  const record = capture === "terminal" ? source.terminalRecord ??= { observers: void 0, observer: void 0 } : capture ? source.captureRecord ??= { observers: void 0, observer: void 0 } : source;
  const installed = observer;
  (record.observers ??= /* @__PURE__ */ new Set()).add(installed);
  compose(record);
  let active = true;
  return () => {
    if (!active) return;
    active = false;
    record.observers?.delete(installed);
    compose(record);
  };
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/location-runtime.ts
var WRITABLE_LOCATION_BINDINGS = /* @__PURE__ */ new WeakMap();
var writableLocationBinding = (location) => {
  const binding = WRITABLE_LOCATION_BINDINGS.get(location);
  if (!binding) throw new Error("Expected a writable SignalTree location");
  return binding;
};
function isWritableLocation(value) {
  return WRITABLE_LOCATION_BINDINGS.has(value);
}
function writableLocationPublisher(value) {
  return WRITABLE_LOCATION_BINDINGS.get(value);
}
function replaceLocation(location, value) {
  writableLocationBinding(location).replace(value);
}
function deriveLocation(location, update) {
  writableLocationBinding(location).derive(update);
}
function registerWritableLocationBinding(binding) {
  WRITABLE_LOCATION_BINDINGS.set(
    binding.location,
    binding
  );
}
function createWritableProjection(source, write) {
  const location = markTreeCell(function(value) {
    if (arguments.length === 0) return source();
    if (typeof value === "function") {
      binding.derive(value);
    } else if (isLeafDefinition(value)) {
      binding.replace(leafDefinitionValue(value));
    } else {
      binding.replace(value);
    }
    return void 0;
  });
  const mutationSource1 = registerIntrinsicMutationSource(
    location
  );
  const binding = {
    location,
    notify: () => void 0,
    replace: (value) => {
      const observer = mutationSource1.observer;
      const before = observer ? source.peek() : void 0;
      write(value, "replace");
      if (observer) {
        const after = source.peek();
        observer({
          intent: "replace",
          before,
          after,
          changed: !Object.is(before, after)
        });
      }
    },
    derive: (update) => {
      const before = source.peek();
      write(update(before), "derive");
      const observer = mutationSource1.observer;
      if (observer) {
        const after = source.peek();
        observer({
          intent: "derive",
          before,
          after,
          changed: !Object.is(before, after)
        });
      }
    }
  };
  WRITABLE_LOCATION_BINDINGS.set(
    location,
    binding
  );
  location.peek = source.peek;
  location.subscribe = source.subscribe;
  location.asReadonly = () => location;
  return location;
}
var activeConsumer;
var publicationDepth = 0;
var pendingConsumers = /* @__PURE__ */ new Set();
var dependencyFinalizer = new FinalizationRegistry((dependencies) => {
  for (const [node, edge] of dependencies) {
    node.consumers.delete(edge.reference);
  }
});
var flushConsumers = () => {
  const errors = [];
  while (pendingConsumers.size > 0) {
    const consumer = [...pendingConsumers].sort(
      (left, right) => left.level - right.level
    )[0];
    pendingConsumers.delete(consumer);
    try {
      consumer.settle();
    } catch (error) {
      errors.push(error);
    }
  }
  return errors;
};
var NO_LISTENERS = /* @__PURE__ */ new Set();
var notifyObservers = (token, listeners2) => {
  let failure;
  let hasFailure = false;
  try {
    token?.invalidate();
  } catch (error) {
    failure = error;
    hasFailure = true;
  }
  for (const listener of [...listeners2]) {
    try {
      listener();
    } catch {
    }
  }
  if (hasFailure) throw failure;
};
var trackDependency = (node, token) => {
  if (activeConsumer) {
    let edge = activeConsumer.dependencies.get(node);
    if (!edge) {
      const reference = new WeakRef(activeConsumer);
      edge = { reference, version: node.version };
      node.consumers.add(reference);
      activeConsumer.dependencies.set(node, edge);
    } else {
      edge.version = node.version;
    }
    activeConsumer.level = Math.max(activeConsumer.level, node.level + 1);
    return;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("publicationDependencyReads");
  }
  token().observe();
};
var notifyDependents = (node) => {
  for (const reference of node.consumers) {
    const consumer = reference.deref();
    if (consumer) consumer.invalidate();
    else node.consumers.delete(reference);
  }
};
var NODE_LOCATION_RUNTIMES = /* @__PURE__ */ new WeakMap();
function bindLocationRuntime(node, runtime2) {
  NODE_LOCATION_RUNTIMES.set(node, runtime2);
}
function getLocationRuntime(node) {
  return NODE_LOCATION_RUNTIMES.get(node);
}
function createLocationRuntime(realization) {
  const hasReactiveObservation = realization !== NEUTRAL_OBSERVATION_ADAPTER;
  let invalidationGroupDepth = 0;
  const groupedPublishers = /* @__PURE__ */ new Set();
  const deliver = (publishers) => {
    const errors = [];
    realization.runInvalidationGroup(() => {
      publicationDepth += 1;
      try {
        for (const publisher of publishers) {
          try {
            publisher.notify();
          } catch (error) {
            errors.push(error);
          }
        }
        if (publicationDepth === 1) errors.push(...flushConsumers());
      } finally {
        publicationDepth -= 1;
        if (publicationDepth === 0) pendingConsumers.clear();
      }
    });
    if (errors.length > 0) throw errors[0];
  };
  const publish = (publishers) => {
    if (invalidationGroupDepth > 0) {
      for (const publisher of publishers) groupedPublishers.add(publisher);
      return;
    }
    deliver(publishers);
  };
  const runInvalidationGroup = (run) => {
    let failure;
    let hasFailure = false;
    invalidationGroupDepth += 1;
    try {
      run();
    } catch (error) {
      failure = error;
      hasFailure = true;
    } finally {
      invalidationGroupDepth -= 1;
      if (invalidationGroupDepth === 0 && groupedPublishers.size > 0) {
        const publishers = [...groupedPublishers];
        groupedPublishers.clear();
        try {
          deliver(publishers);
        } catch (error) {
          if (!hasFailure) {
            failure = error;
            hasFailure = true;
          }
        }
      }
    }
    if (hasFailure) throw failure;
  };
  const createWritable = (read, write) => {
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const location = markTreeCell(function(value) {
      if (arguments.length === 0) {
        trackDependency(node, token);
        return read();
      }
      if (typeof value === "function") {
        binding.derive(value);
      } else if (isLeafDefinition(value)) {
        binding.replace(leafDefinitionValue(value));
      } else {
        binding.replace(value);
      }
      return void 0;
    });
    const mutationSource2 = registerIntrinsicMutationSource(
      location
    );
    const binding = {
      location,
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, listeners2);
      },
      replace: (next) => {
        const observer = mutationSource2.observer;
        const before = observer ? read(true) : void 0;
        const result = write(next, "replace", () => mutationSource2.prepareTerminal?.({ intent: "replace", before, after: next, changed: true }));
        const changed = typeof result === "boolean" ? result : result.changed;
        const physicalChanged = typeof result === "boolean" ? result : result.physicalChanged;
        if (observer) {
          observer({
            intent: "replace",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (physicalChanged) publish([binding]);
      },
      derive: (update) => {
        const current = read();
        const before = mutationSource2.observer ? read(true) : current;
        const next = update(current);
        const result = write(next, "derive", () => mutationSource2.prepareTerminal?.({ intent: "derive", before, after: next, changed: true }));
        const changed = typeof result === "boolean" ? result : result.changed;
        const physicalChanged = typeof result === "boolean" ? result : result.physicalChanged;
        const observer = mutationSource2.observer;
        if (observer) {
          observer({
            intent: "derive",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (physicalChanged) publish([binding]);
      }
    };
    registerWritableLocationBinding(binding);
    location.peek = () => read();
    location.subscribe = (listener) => {
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    location.asReadonly = () => location;
    return binding;
  };
  const createCell = (initial, equal = Object.is) => {
    let value = initial;
    const binding = createWritable(
      () => value,
      (next) => {
        if (equal(value, next)) return false;
        value = next;
        return true;
      }
    );
    return binding.location;
  };
  const createDerived = (compute) => {
    let initialized = false;
    let dirty = true;
    let computationFailed = false;
    let value;
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const token = () => observationToken ??= realization.createToken();
    const consumer = {
      dependencies: /* @__PURE__ */ new Map(),
      level: 1,
      invalidate: () => {
        if (dirty) {
          if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
            pendingConsumers.add(consumer);
          }
          return;
        }
        dirty = true;
        notifyDependents(node);
        if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
          pendingConsumers.add(consumer);
        }
      },
      settle: () => {
        if (!dirty) return;
        const previous = value;
        const wasInitialized = initialized;
        readCurrent();
        if (wasInitialized && !Object.is(previous, value)) {
          publisher.notify();
        }
      }
    };
    dependencyFinalizer.register(consumer, consumer.dependencies);
    const publisher = {
      notify: () => {
        notifyObservers(observationToken, listeners2);
      }
    };
    const readCurrent = () => {
      if (!dirty && initialized) return value;
      if (initialized && !computationFailed) {
        let changed = false;
        for (const [dependency, edge] of consumer.dependencies) {
          dependency.refresh();
          if (dependency.version !== edge.version) changed = true;
        }
        if (!changed) {
          dirty = false;
          return value;
        }
      }
      for (const [dependency, edge] of consumer.dependencies) {
        dependency.consumers.delete(edge.reference);
      }
      consumer.dependencies.clear();
      consumer.level = 1;
      const previous = value;
      const wasInitialized = initialized;
      const previousConsumer = activeConsumer;
      activeConsumer = consumer;
      try {
        value = compute();
        node.level = consumer.level;
        initialized = true;
        dirty = false;
        computationFailed = false;
        if (wasInitialized && !Object.is(previous, value)) {
          node.version += 1;
        }
        return value;
      } catch (error) {
        computationFailed = true;
        throw error;
      } finally {
        activeConsumer = previousConsumer;
      }
    };
    node.refresh = () => {
      if (dirty) readCurrent();
    };
    const location = markTreeCell((() => {
      const current = readCurrent();
      trackDependency(node, token);
      return current;
    }));
    location.peek = readCurrent;
    location.subscribe = (listener) => {
      readCurrent();
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    return location;
  };
  const createEpoch = () => {
    let observationToken;
    let version = 0;
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const publisher = {
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, NO_LISTENERS);
      }
    };
    const epoch = (() => {
      trackDependency(node, token);
      return version;
    });
    epoch.set = (next) => {
      if (next === version) return;
      version = next;
      publish([publisher]);
    };
    epoch.update = (fn) => epoch.set(fn(version));
    epoch.asReadonly = () => epoch;
    return epoch;
  };
  const advanceEpoch = (handle) => {
    handle.update((v) => v + 1);
  };
  return {
    createCell,
    createDerived,
    createWritable,
    createEpoch,
    advanceEpoch,
    publish,
    runInvalidationGroup
  };
}
var NEUTRAL_LOCATION_RUNTIME = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
);
function needsLocationAuthorityAdmission(value) {
  return WRITABLE_LOCATION_BINDINGS.get(value)?.needsAuthorityAdmission?.() ?? false;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/error-reporter.ts
var listeners = /* @__PURE__ */ new Set();
function reportTreeError(event) {
  if (listeners.size === 0) return false;
  let received = false;
  for (const listener of listeners) {
    try {
      listener(event);
      received = true;
    } catch (err) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        safeConsoleError(
          "SignalTree: an onTreeError listener threw. The original error was still handled normally; this is the listener failing. [ST2025]",
          err
        );
      }
    }
  }
  return received;
}
function safeConsoleError(message, error) {
  try {
    if (error === void 0) console.error(message);
    else console.error(message, error);
  } catch {
  }
}
var CONTAINED_REPORT_BUDGET = 50;
var CONTAINED_REPORT_WINDOW_MS = 1e3;
var containedReportWindows = /* @__PURE__ */ new Map();
function registerContainedReportBudget(treeId) {
  containedReportWindows.set(treeId, null);
}
function takeContainedReportBudget(treeId) {
  let now = 0;
  try {
    now = Date.now();
  } catch {
  }
  const owner = containedReportWindows.has(treeId) ? treeId : void 0;
  let window2 = containedReportWindows.get(owner);
  if (!window2 || now - window2.start >= CONTAINED_REPORT_WINDOW_MS) {
    window2 = { start: now, count: 0 };
    containedReportWindows.set(owner, window2);
  }
  if (window2.count >= CONTAINED_REPORT_BUDGET) {
    if (window2.count === CONTAINED_REPORT_BUDGET && listeners.size > 0) {
      window2.count++;
      safeConsoleError(
        `SignalTree: more than ${CONTAINED_REPORT_BUDGET} contained observer errors for one tree within a second; further ones go to the console only, not onTreeError. [ST2034]`
      );
    }
    return false;
  }
  window2.count++;
  return true;
}
function reportContainedObserverError(event) {
  const { error, operation, treeId, path } = event;
  let received = false;
  if (treeId !== void 0) {
    if (takeContainedReportBudget(treeId)) {
      received = reportTreeError({
        error,
        operation,
        treeId,
        ...path === void 0 ? {} : { path }
      });
    }
  }
  if (received && !(typeof ngDevMode === "undefined" || ngDevMode)) {
    return;
  }
  safeConsoleError(
    operation === "notify:subscriber" ? `SignalTree: a write subscriber threw while observing '${path}'; delivery continued. [ST2034]` : "SignalTree: a transaction turn listener threw; the transaction continued. [ST2034]",
    error
  );
}
function releaseContainedReportBudget(treeId) {
  containedReportWindows.delete(treeId);
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/constants.ts
var DEV_MESSAGES = {
  NULL_OR_UNDEFINED: "null/undefined [ST1001]",
  TREE_DESTROYED: "destroyed [ST1012]",
  ENHANCER_CYCLE_DETECTED: "enhancer cycle [ST1024]"
  // ST1032 (LAZY_NOT_INJECTED) and ST1004 (LAZY_FALLBACK) were removed in 15.0
  // with the lazy feature. ST1032 in particular told users to import from
  // `@signal-tree/kernel/lazy`, a subpath withdrawn from the published surface —
  // a runtime diagnostic giving advice that could not be followed.
};
var PROD_MESSAGES = DEV_MESSAGES;
var _isProdByEnv = Boolean(
  typeof globalThis === "object" && globalThis !== null && "process" in globalThis && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  typeof globalThis.process === "object" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  "env" in globalThis.process && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  globalThis.process.env.NODE_ENV === "production"
);
var _isDev = typeof ngDevMode !== "undefined" ? Boolean(ngDevMode) : !_isProdByEnv;
var SIGNAL_TREE_MESSAGES = Object.freeze(
  _isDev ? DEV_MESSAGES : PROD_MESSAGES
);

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/enhancer-types.ts
var ENHANCER_META = Symbol("signaltree:enhancer:meta");

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/enhancers/index.ts
function resolveEnhancerOrder(enhancers, availableCapabilities = /* @__PURE__ */ new Set(), debugMode = false) {
  const nodes = enhancers.map((e, idx) => ({
    fn: e,
    name: e.metadata && e.metadata.name ? String(e.metadata.name) : `enhancer#${idx}`,
    requires: new Set(e.metadata?.requires ?? []),
    provides: new Set(e.metadata?.provides ?? [])
  }));
  const provided = new Set(availableCapabilities);
  const nameCounts = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    for (const capability of node.provides) provided.add(capability);
    if (node.fn.metadata?.name) {
      nameCounts.set(node.name, (nameCounts.get(node.name) ?? 0) + 1);
    }
  }
  const problems = [];
  for (const node of nodes) {
    for (const capability of node.requires) {
      if (!provided.has(capability)) {
        problems.push(
          `  - ${node.fn.metadata?.name ? `"${node.name}"` : "an unnamed enhancer"} requires capability "${capability}", but no configured enhancer provides it.`
        );
      }
    }
  }
  for (const [name, count] of nameCounts) {
    if (count > 1) {
      problems.push(
        `  - enhancer "${name}" is configured ${count} times; each enhancer may appear once.`
      );
    }
  }
  if (problems.length > 0) {
    throw new Error(
      `SignalTree could not finalize the enhancer configuration:
${problems.join("\n")}`
    );
  }
  const adj = /* @__PURE__ */ new Map();
  const nameToNode = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    nameToNode.set(n.name, n);
    adj.set(n.name, /* @__PURE__ */ new Set());
  }
  for (const a of nodes) {
    for (const b of nodes) {
      if (a === b) continue;
      for (const req of b.requires) {
        if (availableCapabilities.has(req)) continue;
        if (a.provides.has(req)) {
          const set = adj.get(a.name);
          if (set) set.add(b.name);
        }
      }
    }
  }
  const inDegree = /* @__PURE__ */ new Map();
  for (const entry of adj.keys()) inDegree.set(entry, 0);
  for (const [, outs] of adj) {
    for (const to of outs) inDegree.set(to, (inDegree.get(to) || 0) + 1);
  }
  const queue = [];
  for (const [name, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(name);
  }
  const ordered = [];
  while (queue.length > 0) {
    const n = queue.shift();
    if (!n) break;
    ordered.push(n);
    const outs = adj.get(n);
    if (!outs) continue;
    for (const m of outs) {
      inDegree.set(m, (inDegree.get(m) || 0) - 1);
      if (inDegree.get(m) === 0) queue.push(m);
    }
  }
  if (ordered.length !== nodes.length) {
    if (debugMode) {
      console.warn(SIGNAL_TREE_MESSAGES.ENHANCER_CYCLE_DETECTED);
    }
    return enhancers;
  }
  return ordered.map((name) => {
    const n = nameToNode.get(name);
    return n ? n.fn : enhancers[0];
  });
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/node-shape.ts
function isTraversableNode(value) {
  return value != null && (typeof value === "object" || typeof value === "function");
}
var CALLABLE_SIGNAL_SYMBOL = Symbol.for("SignalTree:NodeAccessor");
var NODE_STORE_SYMBOL = Symbol.for("SignalTree:NodeStore");
function nodeStoreOf(node) {
  const store = node[NODE_STORE_SYMBOL];
  return store !== void 0 && store !== null ? store : void 0;
}
function snapshotNodeKey(node) {
  return nodeStoreOf(node) ?? node;
}
function isNodeAccessor(value) {
  return typeof value === "function" && value[CALLABLE_SIGNAL_SYMBOL] === true;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/owned-metadata.ts
var OWNED_NODE_METADATA = /* @__PURE__ */ new WeakMap();
function getOwnedPositionIds(node) {
  if (isTraversableNode(node)) {
    const direct = node.__positionIds;
    if (direct) {
      return [...direct];
    }
    const sidecar = OWNED_NODE_METADATA.get(node)?.positionIds;
    return sidecar ? [...sidecar] : void 0;
  }
  return void 0;
}
function getOwnedOwnerPath(node) {
  if (isTraversableNode(node)) {
    const direct = node.__ownerPath;
    if (direct !== void 0) {
      return direct;
    }
    return OWNED_NODE_METADATA.get(node)?.ownerPath;
  }
  return void 0;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/owner-invalidation-port.ts
var dispatch;
function markOwnerInvalidated(ownerId) {
  dispatch?.mark(ownerId);
}
function markOwnerInvalidatedFrom(owner) {
  dispatch?.markFrom(owner);
}
function terminateOwnerInvalidation(owner) {
  dispatch?.terminate(owner);
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/path-observation-port.ts
var runtime;
var branchMembershipCapture;
var pathReAddCapture;
function captureBranchMembershipIfObserved(branch, supplied, partial) {
  return branchMembershipCapture?.(branch, supplied, partial);
}
function capturePathReAddIfObserved(path, outer) {
  return pathReAddCapture?.(path, outer);
}
function hasPathObservers() {
  return runtime?.hasObservers() ?? false;
}
var PORT = {
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    runtime?.notify(
      path,
      value,
      prev,
      ownerPath,
      subjectIds,
      positionIds,
      metaOverride,
      ownerId,
      subjectFieldFootprint
    );
  }
};
function pathObservation() {
  return PORT;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/snapshot-authority.ts
var MATERIALIZED = /* @__PURE__ */ new WeakMap();
var SNAPSHOT_PARENT = /* @__PURE__ */ new WeakMap();
var TREE_STORES = /* @__PURE__ */ new WeakSet();
var VOLATILE_SNAPSHOTS = /* @__PURE__ */ new WeakSet();
var MEMBERSHIP_REVISION = /* @__PURE__ */ new WeakMap();
function markTreeStore(store) {
  TREE_STORES.add(store);
}
function isSnapshotNode(node) {
  return TREE_STORES.has(node) || isNodeAccessor(node);
}
function bindSnapshotParent(node, parent) {
  SNAPSHOT_PARENT.set(
    snapshotNodeKey(node),
    new WeakRef(snapshotNodeKey(parent))
  );
}
function markSnapshotVolatile(node) {
  let current = snapshotNodeKey(node);
  while (current) {
    VOLATILE_SNAPSHOTS.add(current);
    current = SNAPSHOT_PARENT.get(current)?.deref();
  }
}
function membershipRevisionFor(key, locations) {
  let revision = MEMBERSHIP_REVISION.get(key);
  if (!revision) {
    revision = locations.createCell(0);
    MEMBERSHIP_REVISION.set(key, revision);
  }
  return revision;
}
function observeMembership(node) {
  membershipRevisionFor(
    snapshotNodeKey(node),
    getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME
  )();
}
function publishMembershipChange(node) {
  const key = snapshotNodeKey(node);
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  deriveLocation(membershipRevisionFor(key, locations), (value) => value + 1);
  markOwnerInvalidatedFrom(node);
}
function materializeSnapshotNode(node, build) {
  const key = snapshotNodeKey(node);
  if (VOLATILE_SNAPSHOTS.has(key)) return build();
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  let snapshot = MATERIALIZED.get(key);
  if (!snapshot) {
    const membershipRevision = membershipRevisionFor(key, locations);
    const read = () => {
      membershipRevision();
      const built = build();
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        if (built !== null && typeof built === "object") Object.freeze(built);
      }
      return built;
    };
    snapshot = { observe: locations.createDerived(read) };
    MATERIALIZED.set(key, snapshot);
  }
  return snapshot.observe();
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/tree-scalar-slot-port.ts
var TREE_SCALAR_SLOT_RUNTIME = Symbol.for("SignalTree:ScalarSlotRuntime");
function defineTreeScalarSlotRuntime(node, runtime2) {
  Object.defineProperty(node, TREE_SCALAR_SLOT_RUNTIME, {
    value: runtime2,
    enumerable: false,
    configurable: true
  });
}
function getTreeScalarSlotRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[TREE_SCALAR_SLOT_RUNTIME];
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/member-membership.ts
var DORMANT = Symbol.for("SignalTree:DormantMember");
var membershipEpoch = 1;
var omittedMembers = /* @__PURE__ */ new WeakMap();
var ABSENCE_CHECK_EVERY = 64;
var absenceChecks = 0;
var MEMBERSHIP_CHANGED = Symbol.for("SignalTree:MembershipChanged");
function membershipHook(node) {
  return node?.[MEMBERSHIP_CHANGED];
}
var NODE_ACCESSOR_PEER = Symbol.for("SignalTree:NodeAccessorPeer");
function memberBinding(leaf2) {
  if (!isTraversableNode(leaf2)) {
    return void 0;
  }
  return leaf2[DORMANT];
}
function reactivateOnWrite(leaf2) {
  const binding = memberBinding(leaf2);
  if (!binding) return false;
  return setMemberPresence(binding.parent, binding.key, "active");
}
function nodeOf(parent) {
  return parent[NODE_ACCESSOR_PEER] ?? parent;
}
function isAbsentMember(node) {
  const first = memberBinding(node);
  if (first === void 0) return false;
  if (first.epoch === membershipEpoch) {
    if ((typeof ngDevMode === "undefined" || ngDevMode) && ++absenceChecks % ABSENCE_CHECK_EVERY === 0 && walkAbsence(first) !== first.absent)
      throw new Error(
        "SignalTree internal: a cached absence answer disagrees with enumerability (membershipEpoch was not advanced)."
      );
    return first.absent;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  first.absent = walkAbsence(first);
  first.epoch = membershipEpoch;
  return first.absent;
}
function walkAbsence(first) {
  for (let binding = first; binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) return true;
  }
  return false;
}
var structuralWrites = {
  depth: 0,
  stamp: 0
};
function beginStructuralWrite() {
  structuralWrites.depth++;
}
function endStructuralWrite(failed) {
  if (--structuralWrites.depth) return;
  structuralWrites.readded = void 0;
  structuralWrites.end?.(failed);
}
function inStructuralWrite(node) {
  return node !== void 0 && structuralWrites.own === node;
}
function readdedDuringStructuralWrite(branch, key, since) {
  return (structuralWrites.readded?.get(nodeOf(branch))?.get(key) ?? 0) > since;
}
var storedReads = { depth: 0 };
function reactivatePathOnWrite(node) {
  if (!isAbsentMember(node)) return false;
  if (inStructuralWrite(node)) return reactivateOnWrite(node);
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  const path = [];
  let outer = -1;
  for (let binding = memberBinding(node); binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) outer = path.length;
    path.push(binding);
  }
  if (outer < 0) return false;
  const announce = capturePathReAddIfObserved(path, outer);
  for (let i = outer - 1; i >= 0; i--) {
    const { parent, key: kept } = path[i];
    for (const member of Object.keys(parent))
      if (member !== kept) setMemberPresence(parent, member, "dormant");
  }
  for (let i = outer; i >= 0; i--) {
    const { parent, key } = path[i];
    setMemberPresence(parent, key, "active");
    if (structuralWrites.depth) {
      const readded = structuralWrites.readded ??= /* @__PURE__ */ new Map();
      let keys = readded.get(parent);
      if (!keys) readded.set(parent, keys = /* @__PURE__ */ new Map());
      keys.set(key, ++structuralWrites.stamp);
    }
  }
  if (!isWritableLocation(node) || outer > 0)
    republishMembers(path[outer].parent, [path[outer].key]);
  announce?.();
  return true;
}
var ABSENCE = {
  // History capture reads what storage holds (`storedReads`).
  isAbsent: (node) => !storedReads.depth && isAbsentMember(node),
  reAdd: reactivatePathOnWrite
};
function republishMembers(parent, keys) {
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (!runtime2) return;
  const changedSlots = [];
  const unaddressedLeaves = [];
  const branches = [];
  const publish = (child) => {
    const positionId = getOwnedPositionIds(child)?.[0];
    const slot = positionId === void 0 ? void 0 : runtime2.resolveScalarSlot(positionId);
    if (slot !== void 0) return changedSlots.push(slot) > 0;
    const publisher = writableLocationPublisher(child);
    if (publisher) return unaddressedLeaves.push(publisher) > 0;
    membershipHook(child)?.();
    if (isNodeAccessor(child)) {
      branches.push(child);
      for (const key of Object.keys(child))
        publish(child[key]);
    }
    return false;
  };
  let tokenCarrying = 0;
  for (const key of keys)
    if (publish(parent[key])) tokenCarrying++;
  if (tokenCarrying < keys.length) {
    publishMembershipChange(parent);
  } else {
    markOwnerInvalidatedFrom(parent);
  }
  for (const branch of branches) publishMembershipChange(branch);
  if (changedSlots.length > 0) {
    runtime2.publishPrepared({ revision: runtime2.revision(), changedSlots });
  }
  if (unaddressedLeaves.length > 0) {
    (getLocationRuntime(parent) ?? NEUTRAL_LOCATION_RUNTIME).publish(
      unaddressedLeaves
    );
  }
}
function deactivateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === false) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: false });
  membershipEpoch++;
  markHasDormant(parent);
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (runtime2) {
    omittedMembers.set(runtime2, (omittedMembers.get(runtime2) ?? 0) + 1);
    runtime2.enableAbsence?.(ABSENCE);
  }
  const child = parent[key];
  if (isTraversableNode(child)) {
    linkMember(parent, key, child);
    linkDescendants(child);
  }
  return true;
}
function linkMember(parent, key, child) {
  membershipEpoch++;
  Object.defineProperty(child, DORMANT, {
    value: {
      parent: nodeOf(parent),
      key,
      epoch: 0,
      absent: false
    },
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function linkDescendants(node) {
  if (!isNodeAccessor(node)) return;
  for (const key of Object.getOwnPropertyNames(node)) {
    const child = Object.getOwnPropertyDescriptor(node, key)?.value;
    if (!isNodeAccessor(child) && !isWritableLocation(child) && !membershipHook(child) || memberBinding(child))
      continue;
    linkMember(node, key, child);
    linkDescendants(child);
  }
}
function linkAddedMember(branch, key, child) {
  if (!isTraversableNode(child) || !memberBinding(nodeOf(branch))) return;
  linkMember(branch, key, child);
  linkDescendants(child);
}
function activateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === true) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: true });
  membershipEpoch++;
  const runtime2 = getTreeScalarSlotRuntime(parent);
  const omitted = runtime2 ? omittedMembers.get(runtime2) : void 0;
  if (runtime2 && omitted !== void 0) {
    omittedMembers.set(runtime2, omitted - 1);
    if (omitted === 1) runtime2.disableAbsence?.();
  }
  return true;
}
var HAS_DORMANT = Symbol.for("SignalTree:HasDormantMembers");
function hasDormantMembers(parent) {
  return parent[HAS_DORMANT] === true;
}
function markHasDormant(parent) {
  if (hasDormantMembers(parent)) return;
  Object.defineProperty(parent, HAS_DORMANT, {
    value: true,
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function dormantKeys(parent) {
  return Object.getOwnPropertyNames(parent).filter((key) => {
    const d = Object.getOwnPropertyDescriptor(parent, key);
    return d !== void 0 && d.enumerable === false && "value" in d;
  });
}
function peerOf(branch) {
  const record = branch;
  const peer = record[NODE_STORE_SYMBOL] ?? record[NODE_ACCESSOR_PEER];
  return isTraversableNode(peer) && peer !== branch ? peer : void 0;
}
function setMemberPresence(branch, key, presence) {
  const apply = presence === "active" ? activateOne : deactivateOne;
  let changed = apply(branch, key);
  const peer = peerOf(branch);
  if (peer) changed = apply(peer, key) || changed;
  return changed;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/write-context.ts
var activeContext;
function getActiveWriteContext() {
  return activeContext;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/owned-mutation.ts
function mergeOwnedNodeMetadata(node, patch) {
  const existing = OWNED_NODE_METADATA.get(node) ?? {};
  OWNED_NODE_METADATA.set(node, { ...existing, ...patch });
}
function defineOwnedPositionIds(node, positionIds, storage = "property") {
  if (!positionIds || positionIds.length === 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { positionIds: [...positionIds] });
    return;
  }
  Object.defineProperty(node, "__positionIds", {
    get: () => [...positionIds],
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerPath(node, ownerPath, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerPath });
    return;
  }
  Object.defineProperty(node, "__ownerPath", {
    value: ownerPath,
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerId(node, ownerId, storage = "property") {
  if (ownerId === void 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerId });
    return;
  }
  Object.defineProperty(node, "__ownerId", {
    value: ownerId,
    enumerable: false,
    configurable: true
  });
}
function defineIntrinsicMutationEmitter(node, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { emitsMutations: true });
    return;
  }
  Object.defineProperty(node, "__emitsMutations", {
    value: true,
    enumerable: false,
    configurable: true
  });
}
function emitOwnedMutation(options, before, after, mutationIntent) {
  markOwnerInvalidated(options.ownerId);
  const positionId = options.positionIds?.[0];
  if (positionId === void 0) {
    return;
  }
  if (!hasPathObservers()) {
    return;
  }
  pathObservation().notify(
    options.path,
    after,
    before,
    options.path,
    // subjectIds: this generic scalar route has no subject-identity producer
    // and must not acquire one. Entity/structural notification owns that fact.
    void 0,
    [positionId],
    {
      ...getActiveWriteContext() ?? {},
      mutationIntent
    },
    options.ownerId
  );
}
function wrapOwnedWritableSignal(leaf2, options, hooks = {}) {
  const metadataStorage = options.metadataStorage ?? "property";
  defineOwnedPositionIds(leaf2, options.positionIds, metadataStorage);
  defineOwnedOwnerId(leaf2, options.ownerId, metadataStorage);
  defineOwnedOwnerPath(leaf2, options.path, metadataStorage);
  defineIntrinsicMutationEmitter(leaf2, metadataStorage);
  const releaseIntrinsicObserver = observeIntrinsicMutations(
    leaf2,
    (mutation) => {
      if (mutation.changed) {
        emitOwnedMutation(
          options,
          mutation.before,
          mutation.after,
          mutation.intent
        );
      }
      if (mutation.intent === "replace") {
        hooks.afterSet?.(
          mutation.after,
          mutation.before,
          mutation.after,
          mutation.changed
        );
      } else {
        hooks.afterUpdate?.(
          mutation.before,
          mutation.after,
          mutation.changed
        );
      }
    }
  );
  if (!releaseIntrinsicObserver) {
    throw new Error("SignalTree location has no intrinsic mutation source");
  }
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/position-registry.ts
var POSITION_REGISTRY_SYMBOL = Symbol.for("SignalTree:PositionRegistry");
var nextRegistryId = 1;
var TreePositionRegistry = class {
  /**
   * ⚠️ THE ONE PLACE a counter value becomes a tree-namespace identity.
   *
   * Branding HERE rather than at each consumer means `registry.id` and
   * `ownerRegistry.id` are already `TreeId` everywhere downstream — no producer
   * has to independently assert that some number is a tree identity.
   */
  id = nextRegistryId++;
  nextPositionId = 1;
  parents = /* @__PURE__ */ new Map();
  addresses = /* @__PURE__ */ new Map();
  registerPositionAddress(position, address) {
    this.addresses.set(position, sealedAddress(address));
  }
  addressFor(position) {
    return this.addresses.get(position);
  }
  collectionPaths = /* @__PURE__ */ new Map();
  registerCollectionPath(position, path) {
    this.collectionPaths.set(position, path);
  }
  collectionPathFor(position) {
    return this.collectionPaths.get(position);
  }
  allocate(parent) {
    const positionId = this.nextPositionId++;
    this.parents.set(positionId, parent);
    return positionId;
  }
  parentOf(position) {
    return this.parents.get(position);
  }
  contains(authority, participant) {
    if (authority === participant) {
      return true;
    }
    const seen = /* @__PURE__ */ new Set();
    let current = participant;
    while (current !== void 0 && !seen.has(current)) {
      seen.add(current);
      const parent = this.parentOf(current);
      if (parent === authority) {
        return true;
      }
      current = parent;
    }
    return false;
  }
};
function createPositionRegistry() {
  return new TreePositionRegistry();
}
function definePositionRegistry(node, registry) {
  Object.defineProperty(node, POSITION_REGISTRY_SYMBOL, {
    value: registry,
    enumerable: false,
    configurable: true
  });
}
function getPositionRegistry(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[POSITION_REGISTRY_SYMBOL];
}
var nodeAddresses = /* @__PURE__ */ new WeakMap();
function sealedAddress(address) {
  return Object.isFrozen(address) ? address : Object.freeze(address.slice());
}
function childAddressOf(address, key) {
  return Object.freeze(address.concat(key));
}
function defineNodeAddress(node, address) {
  nodeAddresses.set(node, sealedAddress(address));
}
function getNodeAddress(node) {
  return isTraversableNode(node) ? nodeAddresses.get(node) : void 0;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/runtime-tree-plan.ts
var RESTORATION_CAPABILITIES = [
  "causal-runtime",
  "temporal-snapshots"
];
function createRuntimeTreePlan(hasCapability) {
  return Object.freeze({
    hasCapability,
    hasRestorationAuthority: RESTORATION_CAPABILITIES.some(
      (capability) => hasCapability(capability)
    )
  });
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/materialize-markers.ts
function createMaterializationContext(positionTopologyEnabled = true, hasCapability = (capability) => capability === "position-topology" ? positionTopologyEnabled : true, physicalCommitClock, locationRuntime = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const positionRegistry = createPositionRegistry();
  return {
    locationRuntime,
    positionRegistry,
    positionTopologyEnabled,
    physicalCommitClock,
    hasCapability,
    runtimeTreePlan: createRuntimeTreePlan(hasCapability),
    allocatePositionId: (parentPositionId) => positionRegistry.allocate(parentPositionId),
    physicalOwners: []
  };
}
var PROCESSOR_STAMP = Symbol.for("SignalTree:MarkerProcessor");
function getNodeProcessor(node) {
  if (!isTraversableNode(node)) return void 0;
  return node[PROCESSOR_STAMP];
}
function snapshotMarkerNode(node, parent) {
  const proc = getNodeProcessor(node);
  if (!proc?.snapshot) return void 0;
  if (!isTraversableNode(node)) return { value: proc.snapshot(node) };
  if (parent) bindSnapshotParent(node, parent);
  if (!proc.cacheSnapshot) {
    markSnapshotVolatile(node);
    return { value: proc.snapshot(node) };
  }
  const snapshot = proc.snapshot;
  return materializeSnapshotNode(node, () => ({
    value: snapshot(node)
  }));
}
function hydrateMarkerNode(node, value, mode) {
  const proc = getNodeProcessor(node);
  if (!proc?.hydrate) return false;
  proc.hydrate(node, value, mode);
  return true;
}
var MARKER_PROCESSORS = [];
function isRegisteredMarker(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  if (Object.getOwnPropertySymbols(value).length === 0) {
    return false;
  }
  for (const processor of MARKER_PROCESSORS) {
    if (processor.check(value)) {
      return true;
    }
  }
  return false;
}
function registerBuiltinMarkerProcessor(check, create2, hooks) {
  registerProcessor(
    check,
    create2,
    /* suppressTimingWarning */
    true,
    /* cacheSnapshot */
    true,
    hooks
  );
}
function warnUndeclaredMarker() {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  console.warn(
    "SignalTree: a marker was registered without `snapshot` or `transient: true`. Its value will be DROPPED from every snapshot \u2014 tree.$(), persistence(), devtools, audit and undo/redo \u2014 silently, except for an ST2008 report at read time. Declare what of your marker is state: pass `{ snapshot, hydrate }`, or `{ transient: true }` if it deliberately has none. [ST2022]"
  );
}
var warnedWriteOnly = /* @__PURE__ */ new WeakSet();
function warnWriteOnlyMarker(processor, node) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (!processor.snapshot || processor.hydrate) return;
  if (typeof node === "function" && "set" in node && typeof node.set === "function") {
    return;
  }
  if (warnedWriteOnly.has(processor)) return;
  warnedWriteOnly.add(processor);
  console.warn(
    "SignalTree: a marker declares `snapshot` but no `hydrate`, and its node is not a writable signal. It will be captured by tree.$(), persistence(), devtools, audit and undo/redo \u2014 and every attempt to write it back is SILENTLY DISCARDED, so tree.$(tree.$()) loses its value. Add a `hydrate` hook, or mark it `transient: true` if it is genuinely not restorable. [ST2023]"
  );
}
function registerProcessor(check, create2, suppressTimingWarning, cacheSnapshot, hooks) {
  if (typeof check !== "function" || typeof create2 !== "function") {
    throw new TypeError(
      "registerMarkerProcessor: both 'check' (type guard) and 'create' (materializer) must be functions. Received check=" + typeof check + ", create=" + typeof create2 + ". See https://signaltree.io/docs (custom markers section) for usage."
    );
  }
  const alreadyRegistered = MARKER_PROCESSORS.some((p) => p.check === check);
  if (alreadyRegistered) {
    return;
  }
  if (!suppressTimingWarning && (typeof ngDevMode === "undefined" || ngDevMode) && treesConstructedCount > 0) {
    console.warn(
      `[SignalTree] registerMarkerProcessor() was called AFTER at least one signalTree() had already been constructed (${treesConstructedCount} trees so far). Existing trees will NOT pick up this marker \u2014 only trees built after this point will use it. To process your custom marker in existing trees, register it at module load time (before any signalTree() call), or rebuild the tree after registration.`
    );
  }
  if (!hooks?.snapshot && !hooks?.transient) warnUndeclaredMarker();
  MARKER_PROCESSORS.push({
    check,
    create: create2,
    snapshot: hooks?.snapshot,
    hydrate: hooks?.hydrate,
    cacheSnapshot
  });
}
var treesConstructedCount = 0;
function _recordTreeConstruction() {
  treesConstructedCount += 1;
}
var ORDINARY_STATE = Symbol.for("SignalTree:OrdinaryStateRequest");
var KEY_INDEX = Symbol.for("SignalTree:DynamicKeyIndex");
var MEMBER_MATERIALIZER = Symbol.for("SignalTree:MemberMaterializer");
function attachKeyIndex(branch) {
  const members = /* @__PURE__ */ new Map();
  for (const key of Object.keys(branch)) {
    members.set(key, branch[key]);
  }
  Object.defineProperty(branch, KEY_INDEX, {
    value: members,
    enumerable: false,
    configurable: true
  });
}
function installPreparedMember(branch, key, child, responsibility) {
  const define = (target) => {
    Object.defineProperty(target, key, {
      value: child,
      enumerable: true,
      writable: true,
      configurable: true
    });
  };
  define(branch);
  const backingStore = branch[NODE_STORE_SYMBOL];
  if (backingStore && backingStore !== branch) define(backingStore);
  if (responsibility) {
    installTerminalRecord(responsibility);
  }
  linkAddedMember(branch, key, child);
  branch[KEY_INDEX]?.set(
    key,
    child
  );
}
var applyMemberValue;
function setMemberValueApplier(fn) {
  applyMemberValue = fn;
}
function isOrdinaryStateRequest(v) {
  return isTraversableNode(v) && v[ORDINARY_STATE] === true;
}
function materializeKeyedAware(authority, request, path, parentPositionId, address) {
  const branch = authority.materialize(
    request.value,
    path,
    parentPositionId,
    address
  );
  if (request.keyedLookup && isTraversableNode(branch)) {
    attachKeyIndex(branch);
    Object.defineProperty(branch, MEMBER_MATERIALIZER, {
      value: authority.bindMember(branch),
      enumerable: false,
      configurable: true
    });
  }
  return branch;
}
function materializeMarkers(node, notifier, path = [], context = createMaterializationContext(), authority) {
  if (!isTraversableNode(node)) return;
  if (isTreeCell(node)) return;
  const isAccessor = typeof node === "function" && isNodeAccessor(node);
  if (typeof node === "function" && !isAccessor) return;
  const getNotifier = () => notifier ?? pathObservation();
  const keys = Object.keys(node);
  for (const key of keys) {
    const value = node[key];
    const currentPath = childAddressOf(path, key);
    const pathString = currentPath.join(".");
    let processed = false;
    for (const processor of MARKER_PROCESSORS) {
      if (processor.check(value)) {
        try {
          const parentPositionId = node.__positionIds?.[0];
          const produced = processor.create(
            value,
            getNotifier(),
            pathString,
            context,
            parentPositionId
          );
          const materialized = isOrdinaryStateRequest(produced) && authority ? materializeKeyedAware(
            authority,
            produced,
            pathString,
            parentPositionId,
            currentPath
          ) : produced;
          if (isTraversableNode(materialized)) {
            defineNodeAddress(materialized, currentPath);
            if (context.positionTopologyEnabled) {
              for (const position of getOwnedPositionIds(materialized) ?? []) {
                context.positionRegistry.registerPositionAddress(
                  position,
                  currentPath
                );
              }
            }
            bindLocationRuntime(
              materialized,
              context.locationRuntime
            );
            Object.defineProperty(materialized, PROCESSOR_STAMP, {
              value: processor,
              enumerable: false,
              writable: false,
              configurable: true
            });
          }
          if (typeof ngDevMode === "undefined" || ngDevMode) {
            warnWriteOnlyMarker(processor, materialized);
          }
          node[key] = materialized;
          const backingStore = node[NODE_STORE_SYMBOL];
          if (backingStore && backingStore !== node) {
            backingStore[key] = materialized;
          }
          processed = true;
        } catch (err) {
          if (typeof ngDevMode === "undefined" || ngDevMode) {
            console.error(
              `SignalTree: Failed to materialize marker at "${pathString}"`,
              err
            );
          }
        }
        break;
      }
    }
    if (!processed && value != null) {
      if (isNodeAccessor(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      } else if (typeof value === "object" && !Array.isArray(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      }
    }
  }
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/observation-substrate.ts
var OBSERVATION = /* @__PURE__ */ new WeakMap();
var BRANCH_SCOPES = /* @__PURE__ */ new WeakMap();
function inheritObservationForAddedMember(parent, child) {
  const scopes = BRANCH_SCOPES.get(nodeStoreOf(parent) ?? parent);
  if (!scopes) return;
  for (const scope of scopes) scope.visit(child);
}
function installDormantObservation(leaf2) {
  OBSERVATION.set(leaf2, {
    claims: 0,
    positionId: void 0,
    releaseMutationObserver: () => void 0
  });
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/root-source.ts
var ROOT_AUTHORITIES = /* @__PURE__ */ new WeakMap();
function defineRootTree(rootAccessor, authority) {
  ROOT_AUTHORITIES.set(rootAccessor, authority);
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/utilities/deep-equal.ts
function deepEqual(a, b) {
  return equalsInner(a, b, 0, void 0);
}
var CYCLE_GUARD_DEPTH = 64;
function equalsInner(a, b, depth, seen) {
  if (a === b) return true;
  if (a == null || b == null) return a === b;
  const typeA = typeof a;
  const typeB = typeof b;
  if (typeA !== typeB) return false;
  if (typeA !== "object") return a !== a && b !== b;
  if (depth >= CYCLE_GUARD_DEPTH) {
    seen ??= /* @__PURE__ */ new WeakMap();
    if (seen.get(a) === b) return true;
    seen.set(a, b);
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    const bArr = b;
    for (let i = 0; i < a.length; i++) {
      const x = a[i];
      const y = bArr[i];
      if (x === y) continue;
      if (!equalsInner(x, y, depth + 1, seen)) return false;
    }
    return true;
  }
  if (Array.isArray(b)) return false;
  if (a instanceof Date && b instanceof Date) {
    try {
      const ta = a.getTime();
      const tb = b.getTime();
      return ta === tb || ta !== ta && tb !== tb;
    } catch {
      return false;
    }
  }
  if (a instanceof RegExp && b instanceof RegExp) {
    return a.source === b.source && a.flags === b.flags;
  }
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    for (const [key, value] of a) {
      if (!b.has(key) || !equalsInner(value, b.get(key), depth + 1, seen))
        return false;
    }
    return true;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    for (const value of a) {
      if (!b.has(value)) return false;
    }
    return true;
  }
  if (a instanceof Error && b instanceof Error) {
    if (a.name !== b.name || a.message !== b.message) return false;
  } else if (a instanceof Number && b instanceof Number || a instanceof String && b instanceof String || a instanceof Boolean && b instanceof Boolean) {
    const va = a.valueOf();
    const vb = b.valueOf();
    if (!(va === vb || va !== va && vb !== vb)) return false;
  }
  try {
    if (a.constructor !== b.constructor) {
      return false;
    }
  } catch {
    return false;
  }
  const objA = a;
  const objB = b;
  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  const hasOwn = Object.prototype.hasOwnProperty;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!hasOwn.call(objB, key)) return false;
    const x = objA[key];
    const y = objB[key];
    if (x === y) continue;
    if (!equalsInner(x, y, depth + 1, seen)) return false;
  }
  return true;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/utilities/is-built-in-object.ts
function isBuiltInObject(value) {
  if (value === null || value === void 0) return false;
  if (value instanceof Date || value instanceof RegExp || typeof value === "function" || value instanceof Map || value instanceof Set || value instanceof WeakMap || value instanceof WeakSet || value instanceof ArrayBuffer || value instanceof DataView || value instanceof Error || value instanceof Promise) {
    return true;
  }
  if (value instanceof Int8Array || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Int16Array || value instanceof Uint16Array || value instanceof Int32Array || value instanceof Uint32Array || value instanceof Float32Array || value instanceof Float64Array || value instanceof BigInt64Array || value instanceof BigUint64Array) {
    return true;
  }
  if (typeof window !== "undefined") {
    if (value instanceof URL || value instanceof URLSearchParams || value instanceof FormData || value instanceof Blob || typeof File !== "undefined" && value instanceof File || typeof FileList !== "undefined" && value instanceof FileList || typeof Headers !== "undefined" && value instanceof Headers || typeof Request !== "undefined" && value instanceof Request || typeof Response !== "undefined" && value instanceof Response || typeof AbortController !== "undefined" && value instanceof AbortController || typeof AbortSignal !== "undefined" && value instanceof AbortSignal) {
      return true;
    }
  }
  try {
    const NodeBuffer = globalThis?.Buffer;
    if (NodeBuffer && value instanceof NodeBuffer) {
      return true;
    }
  } catch {
  }
  return false;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/utils.ts
var isReactiveStateValue = isTreeCell;
function warnUnwrapSkipped(key) {
  console.error(
    `SignalTree: "${key}" OMITTED from snapshot \u2014 value is a function that is neither signal nor node accessor. [ST2008]`
  );
}
function isEntityMapMarker(value) {
  return Boolean(
    value && typeof value === "object" && value.__isEntityMap === true
  );
}
function isMemoisable(node) {
  return isSnapshotNode(node);
}
function materializeNode(store) {
  if (!isMemoisable(store)) return unwrap(store);
  return materializeSnapshotNode(store, () => unwrap(store));
}
var DERIVED_STAMP = Symbol.for("SignalTree:Derived");
function stampDerived(sig) {
  if (typeof sig === "function") markTreeCell(sig);
  if (isTraversableNode(sig) && typeof sig.set !== "function") {
    Object.defineProperty(sig, DERIVED_STAMP, {
      value: true,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  return sig;
}
function unwrap(node) {
  if (node === null || node === void 0) {
    return node;
  }
  if (isNodeAccessor(node)) {
    const target = snapshotNodeKey(node);
    return isMemoisable(node) ? materializeSnapshotNode(node, () => buildFromStore(target)) : buildFromStore(target);
  }
  if (isReactiveStateValue(node)) {
    return node();
  }
  if (typeof node !== "object") {
    return node;
  }
  if (Array.isArray(node)) {
    return node;
  }
  if (isBuiltInObject(node)) {
    return node;
  }
  return buildFromStore(node);
}
function unwrapBranchForWriteCapture(node) {
  return isNodeAccessor(node) ? buildFromStore(snapshotNodeKey(node), true) : unwrap(node);
}
function buildFromStore(node, uncachedBranches = false) {
  const own = snapshotMarkerNode(node);
  if (own) return own.value;
  const result = {};
  if (hasDormantMembers(node)) {
    for (const key of dormantKeys(node)) {
      const dormant = node[key];
      if (typeof dormant === "function") dormant();
    }
  }
  for (const key in node) {
    if (!Object.prototype.hasOwnProperty.call(node, key)) continue;
    const value = node[key];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshot = snapshotMarkerNode(value, node);
    if (markerSnapshot) {
      result[key] = markerSnapshot.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnUnwrapSkipped(key);
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      bindSnapshotParent(value, node);
      result[key] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[key] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[key] = unwrap(value);
    } else {
      result[key] = value;
    }
  }
  const symbols = Object.getOwnPropertySymbols(node);
  for (const sym of symbols) {
    if (typeof sym.description === "string" && sym.description.startsWith("SignalTree:")) {
      continue;
    }
    const value = node[sym];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshotSym = snapshotMarkerNode(value, node);
    if (markerSnapshotSym) {
      result[sym] = markerSnapshotSym.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnUnwrapSkipped(String(sym));
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      result[sym] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[sym] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[sym] = unwrap(value);
    } else {
      result[sym] = value;
    }
  }
  return result;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/mutation-capture-runtime.ts
var MUTATION_CAPTURE_RUNTIME = Symbol.for(
  "SignalTree:MutationCaptureRuntime"
);
function createMutationCaptureRuntime() {
  let activeCount = 0;
  const entityListeners = /* @__PURE__ */ new Set();
  const structuralBoundaryListeners = /* @__PURE__ */ new Set();
  const collectionOrderListeners = /* @__PURE__ */ new Set();
  return {
    hasCommittedEntityObservers() {
      return activeCount > 0 && entityListeners.size > 0;
    },
    hasStructuralBoundaryObservers() {
      return activeCount > 0 && structuralBoundaryListeners.size > 0;
    },
    subscribeStructuralBoundary(listener) {
      structuralBoundaryListeners.add(listener);
      return () => {
        structuralBoundaryListeners.delete(listener);
      };
    },
    publishCommittedEntity(capture) {
      if (activeCount === 0) return;
      const listeners2 = capture.structuralFrontier ? [...entityListeners, ...structuralBoundaryListeners] : [...entityListeners];
      for (const listener of listeners2) {
        try {
          listener(capture);
        } catch (error) {
          reportContainedObserverError({
            error,
            operation: "transaction:listener"
          });
        }
      }
    },
    subscribeCommittedEntity(listener) {
      entityListeners.add(listener);
      return () => {
        entityListeners.delete(listener);
      };
    },
    isCaptureActive() {
      return activeCount > 0;
    },
    activateCapture() {
      activeCount += 1;
      let released = false;
      return () => {
        if (released) {
          return;
        }
        released = true;
        activeCount = Math.max(0, activeCount - 1);
      };
    },
    publishCollectionOrder(capture) {
      if (activeCount === 0) {
        return;
      }
      for (const listener of [...collectionOrderListeners]) {
        listener(capture);
      }
    },
    subscribeCollectionOrder(listener) {
      collectionOrderListeners.add(listener);
      return () => collectionOrderListeners.delete(listener);
    }
  };
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/tree-scalar-slot-runtime.ts
var ScalarSlotMutationFrameImpl = class {
  constructor(baseRevision, getCommittedRevision, readValue, commitValues, assertSlotIndex, prepareValues) {
    this.baseRevision = baseRevision;
    this.getCommittedRevision = getCommittedRevision;
    this.readValue = readValue;
    this.commitValues = commitValues;
    this.assertSlotIndex = assertSlotIndex;
    this.prepareValues = prepareValues;
  }
  staged = /* @__PURE__ */ new Map();
  closed = false;
  set(slotIndex, value) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    this.staged.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    const current = this.staged.has(slotIndex) ? this.staged.get(slotIndex) : this.readValue(slotIndex);
    this.staged.set(slotIndex, updater(current));
  }
  discard() {
    this.assertOpen();
    this.closed = true;
    this.staged.clear();
  }
  prepareCommit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) throw new Error("Stale scalar preparation");
    return this.prepareValues(this.staged, options);
  }
  commit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) {
      throw new Error("ScalarSlotMutationFrame base revision is stale.");
    }
    if (this.staged.size > 0) {
      return this.commitValues(this.staged, options);
    }
    return {
      revision: this.getCommittedRevision(),
      changedSlots: []
    };
  }
  assertOpen() {
    if (this.closed) {
      throw new Error("ScalarSlotMutationFrame is already closed.");
    }
  }
};
function createTreeScalarSlotRuntime(physicalCommitClock) {
  const values = [];
  const inspectionBaseline = /* @__PURE__ */ new Map();
  const equalities = [];
  const slotByPositionId = /* @__PURE__ */ new Map();
  let revision = 0;
  const getCommittedRevision = () => physicalCommitClock?.revision() ?? revision;
  const advanceRevision = () => {
    const nextRevision = physicalCommitClock?.advance();
    if (nextRevision !== void 0) {
      return nextRevision;
    }
    revision += 1;
    return revision;
  };
  const assertSlotIndex = (slotIndex) => {
    if (!Number.isInteger(slotIndex) || slotIndex < 0 || slotIndex >= values.length) {
      throw new Error(`Scalar slot index ${slotIndex} is out of bounds.`);
    }
  };
  const collectSlotChanges = (staged) => {
    const changed = [];
    for (const [slotIndex, nextValue] of staged) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      if (!equalities[slotIndex](values[slotIndex], nextValue)) {
        changed.push({ slotIndex, nextValue });
      }
    }
    return changed;
  };
  const prepareSlots = (staged, options) => {
    const base = getCommittedRevision();
    const changed = collectSlotChanges(staged);
    const physical = new Set(changed.map((x) => x.slotIndex));
    const inspection = getActiveWriteContext()?.participation === "inspection";
    const shadowPlans = [];
    for (const [slotIndex, nextValue] of staged) {
      const has = inspectionBaseline.has(slotIndex);
      const before = has ? inspectionBaseline.get(slotIndex) : values[slotIndex];
      const equal = has ? equalities[slotIndex](before, nextValue) : !physical.has(slotIndex);
      const keep = inspection && !equal;
      if (keep !== has || keep && !Object.is(inspectionBaseline.get(slotIndex), before)) shadowPlans.push({ slotIndex, keep, value: before });
    }
    if (getCommittedRevision() !== base) throw new Error("Reentrant scalar preparation");
    let used = false;
    return () => {
      if (used) throw new Error("Prepared scalar commit already used");
      if (getCommittedRevision() !== base) throw new Error("Stale prepared scalar commit");
      used = true;
      for (const { slotIndex, nextValue } of changed) values[slotIndex] = nextValue;
      for (const p of shadowPlans) {
        if (p.keep) inspectionBaseline.set(p.slotIndex, p.value);
        else inspectionBaseline.delete(p.slotIndex);
      }
      const revision2 = (changed.length || shadowPlans.length) && options?.advanceRevision !== false ? advanceRevision() : getCommittedRevision();
      return { revision: revision2, changedSlots: changed.map((x) => x.slotIndex) };
    };
  };
  const commitSlots = (staged, options) => prepareSlots(staged, options)();
  const commitSlotValue = (slotIndex, nextValue, options) => commitSlots(/* @__PURE__ */ new Map([[slotIndex, nextValue]]), options).changedSlots.length > 0;
  const commitSlot = (slotIndex, nextValue, options) => {
    const changed = commitSlotValue(slotIndex, nextValue, options);
    return changed ? { revision: getCommittedRevision(), changed: true, slot: slotIndex } : { revision: getCommittedRevision(), changed: false };
  };
  return {
    createSlot(initialValue, equal, positionId) {
      const slotIndex = values.length;
      values.push(initialValue);
      equalities.push(equal);
      if (positionId !== void 0) {
        slotByPositionId.set(positionId, slotIndex);
      }
      return slotIndex;
    },
    readSlot(slotIndex) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotReads");
      }
      return values[slotIndex];
    },
    needsAuthorityAdmission(slotIndex) {
      return inspectionBaseline.has(slotIndex) && getActiveWriteContext()?.participation !== "inspection";
    },
    readRecordSlot(slotIndex) {
      return getActiveWriteContext()?.participation !== "inspection" && inspectionBaseline.has(slotIndex) ? inspectionBaseline.get(slotIndex) : values[slotIndex];
    },
    commitRecorded(slotIndex, value, prepare) {
      assertSlotIndex(slotIndex);
      const base = getCommittedRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      const equal = equalities[slotIndex](values[slotIndex], value);
      if (getCommittedRevision() !== base) throw new Error("Scalar equality reentered physical installation");
      const inspection = getActiveWriteContext()?.participation === "inspection";
      const shadowed = inspectionBaseline.has(slotIndex);
      const ordinaryBefore = shadowed ? inspectionBaseline.get(slotIndex) : values[slotIndex];
      const authorityEqual = shadowed ? equalities[slotIndex](ordinaryBefore, value) : equal;
      if (getCommittedRevision() !== base) throw new Error("Scalar authority equality reentered installation");
      const semanticChanged = inspection ? !equal : !authorityEqual;
      if (equal && !semanticChanged) {
        if (!inspection) inspectionBaseline.delete(slotIndex);
        return { changed: false, physicalChanged: false };
      }
      const plan = semanticChanged ? prepare?.() : void 0;
      if (getCommittedRevision() !== base) throw new Error("Terminal preparation reentered physical installation");
      if (inspection) {
        if (authorityEqual) inspectionBaseline.delete(slotIndex);
        else if (!shadowed) inspectionBaseline.set(slotIndex, ordinaryBefore);
      } else inspectionBaseline.delete(slotIndex);
      values[slotIndex] = value;
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotWrites");
      }
      if (plan) {
        installTerminalRecord(plan);
      }
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return { changed: semanticChanged, physicalChanged: !equal };
    },
    commitSlot(slotIndex, value) {
      return commitSlot(slotIndex, value);
    },
    commitSlotValue(slotIndex, value) {
      return commitSlotValue(slotIndex, value);
    },
    updateSlot(slotIndex, updater) {
      assertSlotIndex(slotIndex);
      return commitSlot(slotIndex, updater(values[slotIndex]));
    },
    beginFrame() {
      return new ScalarSlotMutationFrameImpl(
        getCommittedRevision(),
        getCommittedRevision,
        (slotIndex) => values[slotIndex],
        commitSlots,
        assertSlotIndex,
        prepareSlots
      );
    },
    resolveScalarSlot(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return slotByPositionId.get(positionId);
    },
    revision() {
      return getCommittedRevision();
    },
    slotCount() {
      return values.length;
    }
  };
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/tree-scalar-leaf-runtime.ts
var ScalarSlotPublication = class {
  constructor(locations) {
    this.locations = locations;
  }
  bindings = [];
  bind(slotIndex, binding) {
    this.bindings[slotIndex] = binding;
  }
  publish(result) {
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications", result.changedSlots.length);
    }
    const publishers = result.changedSlots.flatMap((slotIndex) => {
      const binding = this.bindings[slotIndex];
      return binding ? [binding] : [];
    });
    this.locations.publish(publishers);
  }
  prepareSlot(slotIndex, changed, force = false) {
    if (!changed && !force) {
      return false;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications");
    }
    return true;
  }
};
var ScalarSlotMutationFrameOrchestrator = class {
  constructor(frame, publication) {
    this.frame = frame;
    this.publication = publication;
  }
  set(slotIndex, value) {
    this.frame.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.frame.update(slotIndex, updater);
  }
  discard() {
    this.frame.discard();
  }
  prepareCommit(options) {
    const install = this.frame.prepareCommit({ advanceRevision: options?.advanceRevision });
    return () => {
      const result = install();
      if (options?.publish !== false) this.publication.publish(result);
      return result;
    };
  }
  commit(options) {
    const result = this.frame.commit({
      advanceRevision: options?.advanceRevision
    });
    if (options?.publish !== false) {
      this.publication.publish(result);
    }
    return result;
  }
};
function createScalarLeaf(kernel, publication, locations, slotIndex, liveness) {
  const holder = {};
  const read = (stored) => {
    if (!stored && liveness.absence?.isAbsent(holder.leaf)) {
      return void 0;
    }
    return stored ? kernel.readRecordSlot(slotIndex) : kernel.readSlot(slotIndex);
  };
  const binding = locations.createWritable(read, (value, _intent, prepare) => {
    const changedValue = kernel.commitRecorded(slotIndex, value, prepare);
    const result = { changed: changedValue.physicalChanged };
    const reAdded = liveness.absence?.reAdd(holder.leaf) === true;
    const changed = publication.prepareSlot(slotIndex, result.changed, reAdded);
    return { changed: changedValue.changed || reAdded, physicalChanged: changed };
  });
  binding.needsAuthorityAdmission = () => kernel.needsAuthorityAdmission(slotIndex);
  const leaf2 = binding.location;
  holder.leaf = leaf2;
  return { leaf: leaf2, binding };
}
function createTreeScalarLeafRuntime(physicalCommitClock, locations = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const kernel = createTreeScalarSlotRuntime(physicalCommitClock);
  const publication = new ScalarSlotPublication(locations);
  const leafByPositionId = /* @__PURE__ */ new Map();
  const liveness = {};
  return {
    enableAbsence(absence) {
      liveness.absence = absence;
    },
    disableAbsence() {
      liveness.absence = void 0;
    },
    createLeaf(initialValue, equal, positionId) {
      const slotIndex = kernel.createSlot(initialValue, equal, positionId);
      const { leaf: leaf2, binding } = createScalarLeaf(
        kernel,
        publication,
        locations,
        slotIndex,
        liveness
      );
      publication.bind(slotIndex, binding);
      if (positionId !== void 0) {
        leafByPositionId.set(positionId, leaf2);
      }
      return leaf2;
    },
    beginFrame() {
      return new ScalarSlotMutationFrameOrchestrator(
        kernel.beginFrame(),
        publication
      );
    },
    runInvalidationGroup(run) {
      locations.runInvalidationGroup(run);
    },
    publishPrepared(result) {
      publication.publish(result);
    },
    resolveScalarSlot(positionId) {
      return kernel.resolveScalarSlot(positionId);
    },
    resolveScalarLeaf(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return leafByPositionId.get(positionId);
    },
    revision() {
      return kernel.revision();
    },
    slotCount() {
      return kernel.slotCount();
    }
  };
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/physical-commit-clock.ts
var PHYSICAL_COMMIT_CLOCK = Symbol.for("SignalTree:PhysicalCommitClock");
function createPhysicalCommitClock() {
  let revision = 0;
  return {
    revision() {
      return revision;
    },
    advance() {
      revision += 1;
      return revision;
    }
  };
}
function definePhysicalCommitClock(node, clock) {
  Object.defineProperty(node, PHYSICAL_COMMIT_CLOCK, {
    value: clock,
    enumerable: false,
    configurable: true
  });
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/tree-capabilities.ts
var TREE_CAPABILITY_ORDER = [
  "mutation-capture",
  "position-topology",
  "causal-runtime",
  "temporal-snapshots"
];
var TREE_CAPABILITY_DEPENDENCIES = {
  "mutation-capture": [],
  "position-topology": [],
  "causal-runtime": ["mutation-capture", "position-topology"],
  "temporal-snapshots": []
};
var canonicalizeCapabilities = (capabilities) => {
  const set = new Set(capabilities);
  return TREE_CAPABILITY_ORDER.filter((capability) => set.has(capability));
};
function collectRequestedTreeCapabilities(enhancerMeta) {
  const requested = /* @__PURE__ */ new Set();
  for (const meta of enhancerMeta) {
    for (const capability of meta?.capabilities ?? []) {
      requested.add(capability);
    }
  }
  return canonicalizeCapabilities(requested);
}
function resolveTreeCapabilities(requestedCapabilities) {
  assertTreeCapabilityGraphAcyclic();
  const requested = canonicalizeCapabilities(requestedCapabilities);
  const resolved = new Set(requested);
  const queue = [...requested];
  while (queue.length > 0) {
    const capability = queue.shift();
    if (!capability) {
      continue;
    }
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      if (resolved.has(dependency)) {
        continue;
      }
      resolved.add(dependency);
      queue.push(dependency);
    }
  }
  return {
    requestedCapabilities: requested,
    resolvedCapabilities: canonicalizeCapabilities(resolved)
  };
}
function assertTreeCapabilityGraphAcyclic() {
  const visiting = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new Set();
  const visit = (capability) => {
    if (visited.has(capability)) {
      return;
    }
    if (visiting.has(capability)) {
      throw new Error(
        `SignalTree: capability dependency cycle detected at "${capability}".`
      );
    }
    visiting.add(capability);
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      visit(dependency);
    }
    visiting.delete(capability);
    visited.add(capability);
  };
  for (const capability of TREE_CAPABILITY_ORDER) {
    visit(capability);
  }
}
var TREE_CAPABILITIES = Symbol.for("SignalTree:TreeCapabilities");
function defineTreeCapabilities(tree, capabilities) {
  Object.defineProperty(tree, TREE_CAPABILITIES, {
    value: capabilities,
    enumerable: false,
    configurable: true
  });
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/merge-derived.ts
function ensurePathAndGetTarget($, path) {
  if (!path) return $;
  const parts = path.split(".");
  let current = $;
  for (const part of parts) {
    if (!(part in current)) {
      current[part] = {};
    }
    current = current[part];
  }
  return current;
}
function mergeDerivedState($, derivedDef, path = "", locations) {
  if (!derivedDef || typeof derivedDef !== "object") {
    return;
  }
  for (const [key, value] of Object.entries(derivedDef)) {
    const currentPath = path ? `${path}.${key}` : key;
    if (typeof value === "function" && locations) {
      const target = ensurePathAndGetTarget($, path);
      if (key in target && (typeof ngDevMode === "undefined" || ngDevMode)) {
        console.warn(
          `SignalTree: Derived location "${currentPath}" overwrites source state. Consider using a different key to avoid confusion.`
        );
      }
      target[key] = stampDerived(
        locations.createDerived(value)
      );
    } else if (typeof value === "object" && value !== null) {
      const target = ensurePathAndGetTarget($, path);
      if (!(key in target)) {
        target[key] = {};
      } else if (isTreeCell(target[key])) {
        throw new Error(
          `SignalTree: Cannot merge derived object into "${currentPath}" because source is a signal. Either make source an object or use a different key.`
        );
      }
      mergeDerivedState($, value, currentPath, locations);
    } else if (typeof ngDevMode === "undefined" || ngDevMode) {
      console.warn(
        `[SignalTree] [ST2007] Derived "${currentPath}" dropped: the value could not be realized by this tree. Return a computation recipe, a value recognized by the package realization, or a nested object. See ST2007.`
      );
    }
  }
}
function applyDerivedFactory($, factory, locations) {
  mergeDerivedState($, factory($), "", locations);
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/entity-value-transition.ts
var ENTITY_VALUE_TRANSITION = Symbol("entity-value-transition");
function withEntityValueTransition(meta, transition) {
  return transition ? { ...meta, [ENTITY_VALUE_TRANSITION]: transition } : meta;
}
var ENTITY_ORDINARY_CHANGES = Symbol("entity-ordinary-changes");
function withEntityOrdinaryChanges(meta, changes) {
  return { ...meta, [ENTITY_ORDINARY_CHANGES]: changes };
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/selected-entity-disposition.ts
var SELECTED_ENTITY_DISPOSITION = Symbol("selected-entity-disposition");
function withSelectedEntityDisposition(meta, changes) {
  const selected = {
    ...meta,
    [SELECTED_ENTITY_DISPOSITION]: true
  };
  return withEntityOrdinaryChanges(selected, changes);
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/causal-runtime/ordinary-realization.ts
var placementEvidence = /* @__PURE__ */ new WeakMap();
function realizationPlacement(effect) {
  return placementEvidence.get(effect);
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/physical/entity-placement-stage.ts
var EntityPlacementStage = class {
  constructor(base, head, tail) {
    this.base = base;
    this.head = head;
    this.tail = tail;
  }
  patch = /* @__PURE__ */ new Map();
  read(subject) {
    return this.patch.get(subject) ?? this.base(subject);
  }
  change(subject, change) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement neighbor is absent");
    this.patch.set(subject, { ...row, ...change });
  }
  remove(subject) {
    const row = this.read(subject);
    if (!row.present) return;
    if (row.beforeSubject === void 0) this.head = row.afterSubject;
    else this.change(row.beforeSubject, { afterSubject: row.afterSubject });
    if (row.afterSubject === void 0) this.tail = row.beforeSubject;
    else this.change(row.afterSubject, { beforeSubject: row.beforeSubject });
    this.patch.set(subject, { present: false });
  }
  insert(subject, key, beforeSubject, afterSubject) {
    this.remove(subject);
    const after = afterSubject === void 0 ? void 0 : this.read(afterSubject);
    const before = beforeSubject === void 0 ? void 0 : this.read(beforeSubject);
    if (after?.present) beforeSubject = after.beforeSubject;
    else if (before?.present) afterSubject = before.afterSubject;
    else {
      beforeSubject = this.tail;
      afterSubject = void 0;
    }
    if (beforeSubject === void 0) this.head = subject;
    else this.change(beforeSubject, { afterSubject: subject });
    if (afterSubject === void 0) this.tail = subject;
    else this.change(afterSubject, { beforeSubject: subject });
    this.patch.set(subject, {
      present: true,
      key,
      beforeSubject,
      afterSubject
    });
  }
  snapshot() {
    const subjects = [];
    const seen = /* @__PURE__ */ new Set();
    let subject = this.head;
    while (subject !== void 0) {
      if (seen.has(subject)) throw new Error("Prepared placement cycle");
      seen.add(subject);
      subjects.push(subject);
      const row = this.read(subject);
      if (!row.present)
        throw new Error("Prepared placement contains absent lifetime");
      subject = row.afterSubject;
    }
    return Object.freeze(subjects);
  }
  orderDomain(subjects) {
    const domain = new Set(subjects);
    if (domain.size !== subjects.length)
      throw new Error("Prepared order domain repeats a lifetime");
    for (const subject of subjects)
      if (!this.read(subject).present)
        throw new Error("Prepared order domain contains absent lifetime");
    const current = this.snapshot();
    let index = 0;
    const ordered = Object.freeze(
      current.map(
        (subject) => domain.has(subject) ? subjects[index++] : subject
      )
    );
    this.order(ordered);
    return ordered;
  }
  rekey(subject, key) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement rekey lifetime is absent");
    this.patch.set(subject, { ...row, key });
  }
  order(subjects) {
    for (let i = 0; i < subjects.length; i++) {
      const row = this.read(subjects[i]);
      if (!row.present) throw new Error("Order lifetime is absent");
      this.patch.set(subjects[i], {
        ...row,
        beforeSubject: subjects[i - 1],
        afterSubject: subjects[i + 1]
      });
    }
    this.head = subjects[0];
    this.tail = subjects.at(-1);
  }
};

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/physical/entity-ordinary-topology.ts
var EntityOrdinaryTopology = class {
  headOverride;
  tailOverride;
  divergent = /* @__PURE__ */ new Map();
  displaced = /* @__PURE__ */ new Map();
  preparePlacement(physical) {
    return new EntityPlacementStage(
      (subject) => this.divergent.get(subject) ?? physical.base(subject),
      this.headOverride ? this.headOverride.value : physical.head,
      this.tailOverride ? this.tailOverride.value : physical.tail
    );
  }
  prepareInstall(ordinary, physical) {
    const updates = /* @__PURE__ */ new Map();
    const ids = /* @__PURE__ */ new Set([...ordinary.patch.keys(), ...physical.patch.keys()]);
    for (const subject of ids) {
      const o = ordinary.read(subject), p = physical.read(subject);
      const same = o.present === p.present && (!o.present || p.present && o.key === p.key && o.beforeSubject === p.beforeSubject && o.afterSubject === p.afterSubject);
      updates.set(
        subject,
        same ? void 0 : o.present ? o : { present: false }
      );
    }
    const head = ordinary.head === physical.head ? void 0 : { value: ordinary.head };
    const tail = ordinary.tail === physical.tail ? void 0 : { value: ordinary.tail };
    return () => {
      for (const [subject, row] of updates) this.install(subject, row);
      this.headOverride = head;
      this.tailOverride = tail;
    };
  }
  read(subject) {
    return this.divergent.get(subject);
  }
  atKey(key) {
    return this.displaced.get(key);
  }
  install(subject, next) {
    const previous = this.divergent.get(subject);
    if (previous?.present && this.displaced.get(previous.key) === subject)
      this.displaced.delete(previous.key);
    if (next === void 0) this.divergent.delete(subject);
    else {
      this.divergent.set(subject, next);
      if (next.present) this.displaced.set(next.key, subject);
    }
  }
  retains(subject) {
    return this.divergent.get(subject)?.present === true;
  }
  clear() {
    this.divergent.clear();
    this.displaced.clear();
    this.headOverride = void 0;
    this.tailOverride = void 0;
  }
};
function ordinaryPresenceRecord(kind, subject, state) {
  return {
    kind,
    subject,
    key: state.key,
    value: state.value,
    beforeSubject: state.beforeSubject,
    afterSubject: state.afterSubject
  };
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/utilities/deep-clone.ts
var globalStructuredClone = typeof globalThis === "object" && globalThis !== null ? globalThis.structuredClone : void 0;
function deepClone(value) {
  if (globalStructuredClone) {
    try {
      return globalStructuredClone(value);
    } catch {
    }
  }
  return cloneValue(value, /* @__PURE__ */ new WeakMap());
}
function cloneValue(value, seen) {
  if (value === null || typeof value !== "object") {
    return value;
  }
  if (typeof value === "function") {
    return value;
  }
  const existing = seen.get(value);
  if (existing) {
    return existing;
  }
  if (value instanceof Date) {
    return new Date(value.getTime());
  }
  if (value instanceof RegExp) {
    return new RegExp(value.source, value.flags);
  }
  if (value instanceof Map) {
    const result2 = /* @__PURE__ */ new Map();
    seen.set(value, result2);
    for (const [key, entryValue] of value) {
      result2.set(cloneValue(key, seen), cloneValue(entryValue, seen));
    }
    return result2;
  }
  if (value instanceof Set) {
    const result2 = /* @__PURE__ */ new Set();
    seen.set(value, result2);
    for (const entry of value) {
      result2.add(cloneValue(entry, seen));
    }
    return result2;
  }
  if (Array.isArray(value)) {
    const result2 = new Array(value.length);
    seen.set(value, result2);
    for (let i = 0; i < value.length; i++) {
      result2[i] = cloneValue(value[i], seen);
    }
    return result2;
  }
  if (ArrayBuffer.isView(value)) {
    if (value instanceof DataView) {
      const bufferClone2 = cloneValue(value.buffer, seen);
      return new DataView(bufferClone2, value.byteOffset, value.byteLength);
    }
    const viewWithSlice = value;
    if (typeof viewWithSlice.slice === "function") {
      return viewWithSlice.slice();
    }
    const bufferClone = cloneValue(
      value.buffer,
      seen
    );
    return new value.constructor(
      bufferClone,
      value.byteOffset,
      value.length
    );
  }
  if (value instanceof ArrayBuffer) {
    return value.slice(0);
  }
  const proto = Object.getPrototypeOf(value);
  const result = proto ? Object.create(proto) : {};
  seen.set(value, result);
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor) continue;
    if ("value" in descriptor) {
      descriptor.value = cloneValue(descriptor.value, seen);
    }
    Object.defineProperty(result, key, descriptor);
  }
  return result;
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/physical/entity-mutation-frame.ts
var EntityMutationFrame = class {
  constructor(valueStore, structuralStore) {
    this.valueStore = valueStore;
    this.structuralStore = structuralStore;
  }
  /**
   * The staged instructions. Read-only after commit by membership observation
   * (`entity-membership-source.ts`), which derives point deltas from them.
   */
  mutations = [];
  preparedInstructions;
  ordinaryOrder;
  orderEndpoints;
  finalFront;
  finalOrder;
  stageFinalFront(keys) {
    this.finalFront = keys;
  }
  stageFinalOrder(keys) {
    this.finalOrder = keys;
  }
  preparePlacement() {
    const instructions = this.preparedInstructions = this.prepareCommitInstructions();
    const stage = this.structuralStore.preparePlacement();
    const base = this.structuralStore.preparePlacement();
    let beforeOrder = this.ordinaryOrder ? base.snapshot() : void 0;
    for (const mutation of instructions) {
      if (mutation.kind === "create-fresh-subject")
        stage.insert(mutation.subjectId, mutation.key);
      else if (mutation.kind === "tombstone-subject")
        stage.remove(mutation.subjectId);
      else if (mutation.kind === "restore-subject")
        stage.insert(
          mutation.subjectId,
          mutation.key,
          mutation.resolvedPlacement.beforeSubject,
          mutation.resolvedPlacement.afterSubject
        );
      else if (mutation.kind === "transfer-key") {
        stage.rekey(mutation.subjectId, mutation.toKey);
        if (mutation.placement)
          stage.insert(
            mutation.subjectId,
            mutation.toKey,
            mutation.placement.beforeSubject,
            mutation.placement.afterSubject
          );
      }
    }
    const subjectFor = (key) => {
      for (const [id, row] of stage.patch)
        if (row.present && row.key === key) return id;
      return this.structuralStore.subjectIdForKey(key);
    };
    let prefixOrder;
    if (this.finalFront) {
      const ids = this.finalFront.map(subjectFor).filter((id) => id !== void 0);
      const existing = ids.filter((subject) => base.read(subject).present);
      let cursor = base.head;
      let moved = false;
      for (const subject of existing) {
        if (cursor !== subject) {
          moved = true;
          break;
        }
        const row = base.read(subject);
        cursor = row.present ? row.afterSubject : void 0;
      }
      if (moved) beforeOrder = base.snapshot();
      for (const id of ids) stage.remove(id);
      const after = stage.head;
      let before;
      for (let index = 0; index < ids.length; index++) {
        stage.insert(ids[index], this.finalFront[index], before, after);
        before = ids[index];
      }
      if (moved) this.ordinaryOrder = prefixOrder = stage.snapshot();
    }
    if (this.finalOrder)
      stage.order(
        this.finalOrder.map(subjectFor).filter((id) => id !== void 0)
      );
    if (beforeOrder)
      this.orderEndpoints = Object.freeze({
        before: beforeOrder,
        // A later full order changes the prepared stage. Otherwise the prefix
        // domain already is this exact immutable physical-after sequence.
        after: !this.finalOrder && prefixOrder ? prefixOrder : stage.snapshot()
      });
    return stage;
  }
  stageValueReplacement(replacement) {
    this.mutations.push(replacement);
  }
  stageRetainedValueRetirement(retirement) {
    this.mutations.push(retirement);
  }
  stageKeyTransfer(transfer) {
    this.mutations.push(transfer);
  }
  stageSubjectTombstone(tombstone) {
    this.mutations.push(tombstone);
  }
  stageFreshSubject(freshSubject) {
    this.mutations.push(freshSubject);
  }
  stageSubjectRestore(restoration) {
    this.mutations.push(restoration);
  }
  /**
   * @param observeCommitted Supplied only when a committed-entity observer is
   * active. Receives every touched lifetime once, after EVERY prepared
   * instruction has applied and before the caller publishes or notifies, so a
   * multi-row frame is never visible to admission one row at a time. A
   * preparation failure throws before anything applies or is reported.
   */
  commit(observeCommitted, responsibility, structuralFrontier, valueTransitions, installOrdinary) {
    const preparedMutations = this.preparedInstructions ?? this.prepareCommitInstructions();
    const before = observeCommitted ? /* @__PURE__ */ new Map() : void 0;
    if (before) {
      for (const mutation of preparedMutations) {
        const previous = before.get(mutation.subjectId);
        before.set(mutation.subjectId, {
          value: previous ? previous.value : this.structuralStore.activeKeyForSubject(mutation.subjectId) === void 0 ? void 0 : this.valueStore.backingForSubject(mutation.subjectId),
          structural: (previous?.structural ?? false) || mutation.kind !== "replace-value"
        });
      }
    }
    const physicallyChangedSubjectIds = /* @__PURE__ */ new Set();
    const allocatedSubjectIds = [];
    for (const mutation of preparedMutations) {
      if (mutation.kind === "create-fresh-subject") {
        this.structuralStore.createSubject(mutation.subjectId, mutation.key);
        this.valueStore.retainSubjectValue(
          mutation.subjectId,
          mutation.nextValue
        );
        allocatedSubjectIds.push(mutation.subjectId);
        continue;
      }
      if (mutation.kind === "restore-subject") {
        this.structuralStore.restoreSubjectAtResolvedPlacement(
          mutation.subjectId,
          mutation.key,
          mutation.resolvedPlacement,
          mutation.restoreAllowed
        );
        if (mutation.resolvedValue !== void 0) {
          this.valueStore.retainSubjectValue(
            mutation.subjectId,
            mutation.resolvedValue
          );
        }
        physicallyChangedSubjectIds.add(mutation.subjectId);
        continue;
      }
      if (mutation.kind === "replace-value") {
        const transition = valueTransitions?.get(mutation);
        if (transition) this.valueStore.installValueTransition(transition);
        else
          this.valueStore.retainSubjectValue(
            mutation.subjectId,
            mutation.nextValue
          );
        continue;
      }
      if (mutation.kind === "retire-retained-value") {
        const hadBacking = this.valueStore.retireSubjectValue(
          mutation.subjectId
        );
        if (mutation.forgetLifetime) {
          this.structuralStore.forgetSubject(mutation.subjectId);
        } else {
          this.structuralStore.retireSubject(mutation.subjectId);
        }
        if (hadBacking) {
          physicallyChangedSubjectIds.add(mutation.subjectId);
        }
        continue;
      }
      if (mutation.kind === "transfer-key") {
        this.structuralStore.transferSubject(
          mutation.subjectId,
          mutation.fromKey,
          mutation.toKey
        );
        if (mutation.placement)
          this.structuralStore.placeActiveSubject(
            mutation.subjectId,
            mutation.placement.beforeSubject,
            mutation.placement.afterSubject
          );
        physicallyChangedSubjectIds.add(mutation.subjectId);
        continue;
      }
      this.structuralStore.tombstoneSubject(
        mutation.subjectId,
        mutation.key,
        mutation.restoreAllowed
      );
      physicallyChangedSubjectIds.add(mutation.subjectId);
    }
    if (this.finalFront) this.structuralStore.moveKeysToFront(this.finalFront);
    if (this.finalOrder)
      this.structuralStore.reorderActiveKeys(this.finalOrder);
    if (structuralFrontier) {
      structuralFrontier.after = this.structuralStore.activeOrderFrontier();
    }
    installOrdinary?.();
    if (responsibility) {
      installTerminalRecord(responsibility);
    }
    if (before && observeCommitted) {
      observeCommitted(
        [...before].map(([subject, entry]) => ({
          subject,
          before: entry.value,
          after: this.structuralStore.activeKeyForSubject(subject) === void 0 ? void 0 : this.valueStore.backingForSubject(subject),
          structural: entry.structural
        }))
      );
    }
    return {
      physicallyChangedSubjectIds: [...physicallyChangedSubjectIds],
      allocatedSubjectIds
    };
  }
  prepareCommitInstructions() {
    return this.mutations.map((mutation) => {
      if (mutation.kind === "retire-retained-value" && mutation.forgetLifetime) {
        const state = this.structuralStore.stateForSubject(mutation.subjectId);
        if (!state || state.active) {
          throw new Error(
            `Subject ${String(
              mutation.subjectId
            )} must be tombstoned before forgetting its lifetime.`
          );
        }
      }
      if (mutation.kind !== "restore-subject") {
        return mutation;
      }
      return {
        ...mutation,
        resolvedValue: mutation.realizedValue ?? this.valueStore.backingForSubject(mutation.subjectId),
        resolvedPlacement: this.structuralStore.resolveSubjectRestorePlacement(
          mutation.beforeSubject,
          mutation.afterSubject
        )
      };
    });
  }
};

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/physical/entity-handle-resolution.ts
function resolveEntityHandle(structuralStore, valueStore, handle) {
  const subject = structuralStore.resolveSubjectHandle(handle);
  if (subject.state !== "active") {
    return subject;
  }
  const value = valueStore.backingForSubject(subject.subjectId);
  return value === void 0 ? {
    state: "missing-value",
    subjectId: subject.subjectId,
    key: subject.key,
    revision: subject.revision
  } : {
    ...subject,
    value
  };
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/physical/entity-value-store.ts
var EntityValueStore = class {
  retainedEntities = /* @__PURE__ */ new Map();
  inspectionBaselines = /* @__PURE__ */ new Map();
  prepareValueTransition(subject, physicalAfter, fields, previous) {
    const physicalBefore = previous?.physicalAfter ?? this.retainedEntities.get(subject);
    if (fields === "derive") {
      const descriptors = Object.getOwnPropertyDescriptors(physicalAfter);
      let hasAccessors = false;
      for (const field of Object.keys(physicalAfter)) {
        const descriptor = descriptors[field];
        if (!descriptor || "value" in descriptor) continue;
        const value = physicalAfter[field];
        hasAccessors = true;
        descriptors[field] = {
          value,
          enumerable: descriptor.enumerable,
          writable: true,
          configurable: descriptor.configurable
        };
      }
      if (hasAccessors) {
        physicalAfter = Object.create(
          Object.getPrototypeOf(physicalAfter),
          descriptors
        );
      }
      fields = physicalBefore ? [.../* @__PURE__ */ new Set([
        ...Object.keys(physicalBefore),
        ...Object.keys(physicalAfter)
      ])].filter(
        (field) => Object.prototype.hasOwnProperty.call(physicalBefore, field) !== Object.prototype.hasOwnProperty.call(physicalAfter, field) || !Object.is(physicalBefore[field], physicalAfter[field])
      ) : Object.keys(physicalAfter);
    }
    const ordinaryBefore = previous?.ordinaryAfter ?? this.inspectionBaselines.get(subject) ?? physicalBefore;
    let ordinaryAfter = physicalAfter;
    if (getActiveWriteContext()?.participation === "inspection") {
      ordinaryAfter = ordinaryBefore ?? physicalAfter;
    } else if (fields && ordinaryBefore) {
      const merged = { ...ordinaryBefore };
      for (const field of fields) {
        if (Object.prototype.hasOwnProperty.call(physicalAfter, field))
          Object.defineProperty(merged, field, {
            value: physicalAfter[field],
            enumerable: true,
            writable: true,
            configurable: true
          });
        else delete merged[field];
      }
      ordinaryAfter = merged;
    }
    return Object.freeze({
      subject,
      physicalBefore,
      physicalAfter,
      ordinaryBefore,
      ordinaryAfter,
      retainDivergence: ordinaryBefore !== void 0 && !deepEqual(ordinaryAfter, physicalAfter)
    });
  }
  prepareRealizationTransition(subject, physicalAfter, edits) {
    const physicalBefore = this.retainedEntities.get(subject);
    const ordinaryBefore = this.inspectionBaselines.get(subject) ?? physicalBefore;
    if (!ordinaryBefore)
      throw new Error("Point realization ordinary lifetime is unavailable");
    let ordinaryAfter = ordinaryBefore;
    for (const edit of edits) {
      if (edit.kind === "row") {
        ordinaryAfter = deepClone(edit.value);
      } else {
        const next = { ...ordinaryAfter };
        if (edit.present)
          Object.defineProperty(next, edit.field, {
            value: deepClone(edit.value),
            enumerable: true,
            configurable: true,
            writable: true
          });
        else delete next[edit.field];
        ordinaryAfter = next;
      }
    }
    return Object.freeze({
      subject,
      physicalBefore,
      physicalAfter,
      ordinaryBefore,
      ordinaryAfter,
      retainDivergence: !deepEqual(ordinaryAfter, physicalAfter)
    });
  }
  installValueTransition(transition) {
    if (transition.retainDivergence)
      this.inspectionBaselines.set(
        transition.subject,
        transition.ordinaryAfter
      );
    else this.inspectionBaselines.delete(transition.subject);
    recordProductionSubstrateStat("valueStoreWrites");
    this.retainedEntities.set(transition.subject, transition.physicalAfter);
  }
  ordinaryForSubject(subjectId) {
    return this.inspectionBaselines.get(subjectId) ?? this.retainedEntities.get(subjectId);
  }
  dischargeOrdinaryValue(subjectId) {
    this.inspectionBaselines.delete(subjectId);
  }
  backingForSubject(subjectId) {
    return this.retainedEntities.get(subjectId);
  }
  retainSubjectValue(subjectId, entity) {
    this.inspectionBaselines.delete(subjectId);
    recordProductionSubstrateStat("valueStoreWrites");
    this.retainedEntities.set(subjectId, entity);
  }
  prepareTargetValues(subjects) {
    const target = new Map(this.retainedEntities);
    for (const subject of subjects) {
      target.set(subject.subjectId, subject.value);
    }
    return target;
  }
  installPreparedTargetValues(target) {
    this.retainedEntities = target;
  }
  hasRetainedValueBacking(subjectId) {
    return this.retainedEntities.has(subjectId);
  }
  retireSubjectValue(subjectId) {
    this.inspectionBaselines.delete(subjectId);
    return this.retainedEntities.delete(subjectId);
  }
  clear() {
    this.inspectionBaselines.clear();
    this.retainedEntities.clear();
  }
};

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/physical/structural-store.ts
var StructuralStore = class {
  keysCache;
  subjectIds = /* @__PURE__ */ new Map();
  subjectStates = /* @__PURE__ */ new Map();
  subjectRevisions = /* @__PURE__ */ new Map();
  activeNodesByKey = /* @__PURE__ */ new Map();
  activeNodesBySubject = /* @__PURE__ */ new Map();
  nextSubjectId = 1;
  collectionIncarnation = 0;
  activeHead;
  activeTail;
  activeCount = 0;
  orderFrontier = {};
  placementForSubject(subject) {
    const node = this.activeNodesBySubject.get(subject);
    return node === void 0 ? { present: false } : {
      present: true,
      key: node.key,
      beforeSubject: node.prev?.subjectId,
      afterSubject: node.next?.subjectId
    };
  }
  preparePlacement() {
    return new EntityPlacementStage(
      (subject) => this.placementForSubject(subject),
      this.activeHead?.subjectId,
      this.activeTail?.subjectId
    );
  }
  activeOrderFrontier() {
    return this.orderFrontier;
  }
  /** Only a complete, lineage-validated compensation may restore this token. */
  installCompensatedOrderFrontier(frontier) {
    this.orderFrontier = frontier;
  }
  planFreshSubjectIds(count) {
    return Array.from(
      { length: count },
      (_, index) => this.nextSubjectId + index
    );
  }
  allocateFreshSubjectId() {
    const subjectId = this.nextSubjectId;
    this.nextSubjectId += 1;
    return subjectId;
  }
  subjectIdForKey(key) {
    return this.subjectIds.get(key);
  }
  acquireSubjectHandleForKey(key) {
    const subjectId = this.subjectIds.get(key);
    return subjectId === void 0 ? void 0 : {
      subjectId,
      acquiredRevision: this.subjectRevision(subjectId),
      collectionIncarnation: this.collectionIncarnation
    };
  }
  resolveSubjectHandle(handle) {
    if (handle.collectionIncarnation !== this.collectionIncarnation) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    const state = this.subjectStates.get(handle.subjectId);
    if (state === void 0) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    if (state.active) {
      if (state.key === void 0) {
        throw new Error(
          `Active subject ${String(
            handle.subjectId
          )} is missing its active key.`
        );
      }
      return {
        state: "active",
        subjectId: handle.subjectId,
        key: state.key,
        revision: this.subjectRevision(handle.subjectId)
      };
    }
    return {
      state: "tombstoned",
      subjectId: handle.subjectId,
      restoreAllowed: state.restoreAllowed,
      revision: this.subjectRevision(handle.subjectId)
    };
  }
  stateForSubject(subjectId) {
    return this.subjectStates.get(subjectId);
  }
  hasSubject(subjectId) {
    return this.subjectStates.has(subjectId);
  }
  subjectRevision(subjectId) {
    return this.subjectRevisions.get(subjectId) ?? 0;
  }
  bumpSubjectRevision(subjectId) {
    this.subjectRevisions.set(subjectId, this.subjectRevision(subjectId) + 1);
  }
  activeKeyForSubject(subjectId) {
    const state = this.stateForSubject(subjectId);
    return state?.active ? state.key : void 0;
  }
  hasActiveKey(key) {
    return this.subjectIds.has(key);
  }
  activeKeyCount() {
    return this.activeCount;
  }
  /**
   * Active keys in order, shared until the next list or key mutation. Every
   * mutator of the active list (or of a node's key) clears it; a field write
   * changes neither, so reading `ids()` after one no longer re-walks the list.
   * Callers must not mutate the result.
   */
  activeKeysSnapshot() {
    if (this.keysCache) return this.keysCache;
    const keys = [];
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
    }
    this.keysCache = keys;
    return keys;
  }
  /** Fills both arrays from one walk of the active order. */
  snapshotActiveOrder(keys, subjectIds) {
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
      subjectIds.push(node.subjectId);
    }
  }
  firstActiveKey() {
    return this.activeHead?.key;
  }
  lastActiveKey() {
    return this.activeTail?.key;
  }
  prepareTarget(subjects, order, orderFrontier, prepare) {
    return prepare(
      this.subjectStates,
      this.subjectRevisions,
      subjects,
      order,
      orderFrontier
    );
  }
  installPreparedTarget(target) {
    this.keysCache = void 0;
    this.subjectIds = target.subjectIds;
    this.subjectStates = target.subjectStates;
    this.subjectRevisions = target.subjectRevisions;
    this.activeNodesByKey = target.activeNodesByKey;
    this.activeNodesBySubject = target.activeNodesBySubject;
    this.activeHead = target.activeHead;
    this.activeTail = target.activeTail;
    this.activeCount = target.activeCount;
    this.orderFrontier = target.orderFrontier;
  }
  moveKeysToFront(keys) {
    this.keysCache = void 0;
    const nodes = [
      ...new Set(
        keys.map((key) => this.activeNodesByKey.get(key)).filter((node) => node !== void 0)
      )
    ];
    for (const node of nodes) {
      this.detachNode(node);
    }
    for (let index = nodes.length - 1; index >= 0; index -= 1) {
      this.prependDetachedNode(nodes[index]);
    }
    if (nodes.length > 0) this.orderFrontier = {};
  }
  reorderActiveKeys(keys) {
    let current = this.activeHead;
    let unchanged = true;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) continue;
      if (node !== current) {
        unchanged = false;
        break;
      }
      current = current.next;
    }
    if (unchanged && current === void 0) return;
    this.keysCache = void 0;
    this.activeHead = void 0;
    this.activeTail = void 0;
    for (const node of this.activeNodesByKey.values()) {
      node.prev = void 0;
      node.next = void 0;
    }
    let nextCount = 0;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) {
        continue;
      }
      this.appendDetachedNode(node);
      nextCount += 1;
    }
    this.activeCount = nextCount;
    this.orderFrontier = {};
  }
  neighborSubjectsForKey(key) {
    const node = this.activeNodesByKey.get(key);
    if (node === void 0) {
      return {};
    }
    return {
      beforeSubject: node.prev?.subjectId,
      afterSubject: node.next?.subjectId
    };
  }
  tombstonedSubjectsSnapshot() {
    return [...this.subjectStates.entries()].filter(([, subjectState]) => !subjectState.active).map(([subjectId]) => subjectId).sort((left, right) => left - right);
  }
  createSubject(subjectId, key) {
    recordProductionSubstrateStat("structuralSubjectsCreated");
    this.nextSubjectId = Math.max(this.nextSubjectId, subjectId + 1);
    this.activateSubject(subjectId, key);
    this.subjectRevisions.set(subjectId, 0);
    this.createAndAppendActiveNode(subjectId, key);
    this.orderFrontier = {};
  }
  transferSubject(subjectId, from, to, restoreAllowed = true) {
    recordProductionSubstrateStat("structuralSubjectTransfers");
    const node = this.activeNodesByKey.get(from);
    this.subjectIds.delete(from);
    this.activateSubject(subjectId, to, restoreAllowed);
    if (node === void 0) {
      this.createAndAppendActiveNode(subjectId, to);
      return;
    }
    this.activeNodesByKey.delete(from);
    node.key = to;
    this.keysCache = void 0;
    this.activeNodesByKey.set(to, node);
    this.activeNodesBySubject.set(subjectId, node);
  }
  tombstoneSubject(subjectId, key, restoreAllowed) {
    recordProductionSubstrateStat("structuralSubjectTombstones");
    this.subjectIds.delete(key);
    const node = this.activeNodesByKey.get(key);
    if (node !== void 0) {
      this.unregisterActiveNode(node);
      this.detachNode(node);
      this.activeCount -= 1;
    }
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed
    });
    this.orderFrontier = {};
  }
  restoreSubject(subjectId, key, beforeSubject, afterSubject, restoreAllowed = true) {
    const placement = this.resolveSubjectRestorePlacement(
      beforeSubject,
      afterSubject
    );
    this.restoreSubjectAtResolvedPlacement(
      subjectId,
      key,
      placement,
      restoreAllowed
    );
  }
  resolveSubjectRestorePlacement(beforeSubject, afterSubject) {
    const beforeNode = beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(beforeSubject);
    const afterNode = afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(afterSubject);
    if (beforeNode !== void 0 && afterNode !== void 0) {
      if (this.nodePrecedes(beforeNode, afterNode)) {
        return {
          beforeSubject: beforeNode.subjectId,
          afterSubject: afterNode.subjectId,
          beforeKey: beforeNode.key,
          afterKey: afterNode.key
        };
      }
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (afterNode !== void 0) {
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (beforeNode !== void 0) {
      return {
        beforeSubject: beforeNode.subjectId,
        afterSubject: beforeNode.next?.subjectId,
        beforeKey: beforeNode.key,
        afterKey: beforeNode.next?.key
      };
    }
    return {
      beforeSubject: this.activeTail?.subjectId,
      beforeKey: this.activeTail?.key
    };
  }
  restoreSubjectAtResolvedPlacement(subjectId, key, placement, restoreAllowed = true) {
    this.activateSubject(subjectId, key, restoreAllowed);
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.activeCount += 1;
    this.orderFrontier = {};
    const beforeNode = placement.beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    const afterNode = placement.afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    if (afterNode !== void 0) {
      this.insertDetachedNodeBefore(node, afterNode);
      return;
    }
    if (beforeNode !== void 0) {
      this.insertDetachedNodeAfter(node, beforeNode);
      return;
    }
    this.appendDetachedNode(node);
  }
  /** Relocate an active lifetime without retiring it or emitting lifecycle effects. */
  placeActiveSubject(subjectId, beforeSubject, afterSubject) {
    const node = this.activeNodesBySubject.get(subjectId);
    if (!node) throw new Error("Placement lifetime is not active");
    if (beforeSubject === subjectId || afterSubject === subjectId)
      throw new Error("Placement cannot name its own lifetime");
    const placement = this.resolveSubjectRestorePlacement(
      beforeSubject,
      afterSubject
    );
    const after = placement.afterSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    const before = placement.beforeSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    this.detachNode(node);
    if (after) this.insertDetachedNodeBefore(node, after);
    else if (before) this.insertDetachedNodeAfter(node, before);
    else this.appendDetachedNode(node);
    this.keysCache = void 0;
    this.orderFrontier = {};
  }
  retireSubject(subjectId) {
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed: false
    });
  }
  /**
   * Drop a retired subject's lifetime ledger entirely — state AND revision.
   *
   * ⚠️ TRIAL. This is the null hypothesis for "is the ~117 B/retired lifetime
   * record earned?" (docs/architecture/retired-subject-churn.md, open question
   * 2). `retireSubject` above keeps a `{active:false, restoreAllowed:false}`
   * record forever, which is what makes zero-owner churn linear in every subject
   * that ever existed. This deletes it.
   *
   * SAFE ONLY FOR A TERMINAL, ZERO-OWNER RETIREMENT, and the reason is subject
   * id allocation: `nextSubjectId` only ever increases, and `tombstoneSubject`
   * has already removed the key -> subject mapping. A later add of the same
   * business key therefore gets a FRESH subject id and cannot collide with the
   * forgotten one. Deleting the record cannot resurrect or alias a subject.
   *
   * WHAT IT GIVES UP: `resolveSubjectHandle` reports `missing` rather than
   * `tombstoned` for the forgotten subject, and `planRestore`'s
   * "has retired backing and cannot be restored" guard loses its input. Both are
   * acceptable only because a tree with no restoration authority has no path to
   * a restore at all — the guard becomes unreachable rather than unenforced. If
   * a restorer can exist, DO NOT call this.
   */
  forgetSubject(subjectId) {
    this.subjectStates.delete(subjectId);
    this.subjectRevisions.delete(subjectId);
    this.activeNodesBySubject.delete(subjectId);
  }
  clear() {
    this.keysCache = void 0;
    this.subjectIds.clear();
    this.subjectStates.clear();
    this.subjectRevisions.clear();
    this.activeNodesByKey.clear();
    this.activeNodesBySubject.clear();
    this.activeHead = void 0;
    this.activeTail = void 0;
    this.activeCount = 0;
    this.nextSubjectId = 1;
    this.collectionIncarnation += 1;
    this.orderFrontier = {};
  }
  createAndAppendActiveNode(subjectId, key) {
    this.keysCache = void 0;
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.appendDetachedNode(node);
    this.activeCount += 1;
  }
  unregisterActiveNode(node) {
    this.keysCache = void 0;
    this.activeNodesByKey.delete(node.key);
    this.activeNodesBySubject.delete(node.subjectId);
  }
  prependDetachedNode(node) {
    this.keysCache = void 0;
    node.prev = void 0;
    node.next = this.activeHead;
    if (this.activeHead !== void 0) {
      this.activeHead.prev = node;
    } else {
      this.activeTail = node;
    }
    this.activeHead = node;
  }
  appendDetachedNode(node) {
    this.keysCache = void 0;
    node.next = void 0;
    node.prev = this.activeTail;
    if (this.activeTail !== void 0) {
      this.activeTail.next = node;
    } else {
      this.activeHead = node;
    }
    this.activeTail = node;
  }
  insertDetachedNodeAfter(node, anchor) {
    this.keysCache = void 0;
    node.prev = anchor;
    node.next = anchor.next;
    if (anchor.next !== void 0) {
      anchor.next.prev = node;
    } else {
      this.activeTail = node;
    }
    anchor.next = node;
  }
  insertDetachedNodeBefore(node, anchor) {
    this.keysCache = void 0;
    node.next = anchor;
    node.prev = anchor.prev;
    if (anchor.prev !== void 0) {
      anchor.prev.next = node;
    } else {
      this.activeHead = node;
    }
    anchor.prev = node;
  }
  detachNode(node) {
    this.keysCache = void 0;
    if (node.prev !== void 0) {
      node.prev.next = node.next;
    } else {
      this.activeHead = node.next;
    }
    if (node.next !== void 0) {
      node.next.prev = node.prev;
    } else {
      this.activeTail = node.prev;
    }
    node.prev = void 0;
    node.next = void 0;
  }
  nodePrecedes(left, right) {
    let node = left;
    while (node !== void 0) {
      if (node === right) {
        return true;
      }
      node = node.next;
    }
    return false;
  }
  activateSubject(subjectId, key, restoreAllowed = true) {
    this.subjectIds.set(key, subjectId);
    this.subjectStates.set(subjectId, {
      active: true,
      key,
      restoreAllowed
    });
  }
};

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/entity-membership-source.ts
var MEMBERSHIP_FACTS = 0;
var MEMBERSHIP_OPEN = 1;
var MEMBERSHIP_OPEN_ORDER = 2;
var MEMBERSHIP_CLOSE = 3;
var SOURCE = Symbol("SignalTree:EntityMembershipSource");
function defineEntityMembershipSource(node, source) {
  Object.defineProperty(node, SOURCE, { value: source });
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/entity-projection-seed.ts
var SEED = Symbol("signaltree.entityProjectionSeed");
var LOCATION_BINDING = Symbol("signaltree.entityLocationBinding");
function defineEntityLocationBinding(node, binding) {
  Object.defineProperty(node, LOCATION_BINDING, { value: binding });
}
function defineEntityProjectionSeed(api, produce) {
  Object.defineProperty(api, SEED, {
    value: produce,
    enumerable: false,
    configurable: true
  });
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/internals/physical-rows.ts
var physicalRows = [];
var taps = { depth: 0 };

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/entity-signal.ts
var WRONG_ENTITY_METHODS = {
  upsert: "upsertOne(entity) / upsertMany(entities)",
  add: "addOne(entity) / addMany(entities)",
  insert: "addOne(entity)",
  update: "updateOne(id, changes) / updateMany(ids, changes)",
  remove: "removeOne(id) / removeMany(ids)",
  delete: "removeOne(id)",
  getAll: "all() (a signal)",
  selectAll: "all() (a signal)",
  selectMany: "where(predicate)",
  selectEntity: "byId(id)",
  addEntities: "addMany(entities)",
  setEntities: "setAll(entities)",
  setProps: "set leaves directly \u2014 entityMap has no props object",
  next: "set leaves directly \u2014 not an RxJS Subject",
  asObservable: "use the signal directly \u2014 not an RxJS Subject"
};
var nextStandaloneEntityPositionId = 1;
var standaloneEntityPositionIdAllocator = () => nextStandaloneEntityPositionId++;
var entityPositionIdAllocatorOverride;
var entityPositionIdNotifyEnabled = true;
function setEntityPositionIdAllocatorForTesting(allocator) {
  entityPositionIdAllocatorOverride = allocator;
}
function setEntityPositionIdNotifyEnabledForTesting(enabled = true) {
  entityPositionIdNotifyEnabled = enabled;
}
function planEntitySubjectReclamation(inventory, options) {
  const retain = [];
  if (inventory.retainedSubjectState) {
    retain.push("subject-lifetime-record");
  }
  if (inventory.retainedValueBacking) {
    retain.push("retained-value-backing");
  }
  if (inventory.activationToken) {
    retain.push("subject-activation-channel");
  }
  if (inventory.nodeFacadeMaterialized) {
    retain.push("row-facade");
  }
  if (inventory.fieldFacadesMaterialized.length > 0) {
    retain.push("field-facades");
  }
  if ((inventory.positionIds?.length ?? 0) > 0) {
    retain.push("ownership-metadata");
  }
  if (inventory.state !== "tombstoned") {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: []
    };
  }
  if (!options.causallyEligible) {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: []
    };
  }
  const retire = [];
  const remaining = [...retain];
  const promote = (resource) => {
    retire.push(resource);
    const index = remaining.indexOf(resource);
    if (index !== -1) {
      remaining.splice(index, 1);
    }
  };
  if (inventory.retainedValueBacking) {
    promote("retained-value-backing");
  }
  if (options.reclaimLifetimeRecord && inventory.retainedSubjectState) {
    promote("subject-lifetime-record");
  }
  return {
    subjectId: inventory.subjectId,
    eligible: true,
    retire,
    retain: remaining,
    unresolved: []
  };
}
function survivingOrderChanged(before, after) {
  const inAfter = new Set(after);
  const inBefore = new Set(before);
  const survivingBefore = before.filter((subject) => inAfter.has(subject));
  const survivingAfter = after.filter((subject) => inBefore.has(subject));
  return survivingBefore.some(
    (subject, index) => subject !== survivingAfter[index]
  );
}
function createEntitySignal(config, pathNotifier, basePath, options) {
  const locations = options?.locationRuntime ?? NEUTRAL_LOCATION_RUNTIME;
  const version = locations.createCell(0);
  const pendingSubjectEpochs = /* @__PURE__ */ new Set();
  const createVersionedProjection = (compute) => {
    let projectedVersion = -1;
    let initialized = false;
    let value;
    return locations.createDerived(() => {
      const currentVersion = version();
      if (!initialized || projectedVersion !== currentVersion) {
        value = compute();
        projectedVersion = currentVersion;
        initialized = true;
      }
      return value;
    });
  };
  function getProjectedEntity(id) {
    const subjectId = structuralStore.subjectIdForKey(id);
    return subjectId === void 0 ? void 0 : valueStore.backingForSubject(subjectId);
  }
  function getProjectedEntries() {
    const entries = [];
    for (const id of structuralStore.activeKeysSnapshot()) {
      const entity = getProjectedEntity(id);
      if (entity !== void 0) {
        entries.push([id, entity]);
      }
    }
    return entries;
  }
  function getProjectedEntities() {
    return getProjectedEntries().map(([, entity]) => entity);
  }
  const absent = () => isAbsentMember(api);
  const rowAbsent = () => {
    if (!absent()) return false;
    if (!physicalRows.length) return true;
    const registry = getPositionRegistry(api);
    return !physicalRows.some(
      ([open, depth]) => open === registry && depth === taps.depth
    );
  };
  const presentEntity = (id) => rowAbsent() ? void 0 : getProjectedEntity(id);
  const presentEntries = () => absent() ? [] : getProjectedEntries();
  const presentEntities = () => absent() ? [] : getProjectedEntities();
  function acquireEntityHandleForTesting(id) {
    return structuralStore.acquireSubjectHandleForKey(id);
  }
  function resolveEntityHandleForTesting(handle) {
    return resolveEntityHandle(structuralStore, valueStore, handle);
  }
  function rebuildActiveProjectionFromOwners() {
    return new Map(getProjectedEntries());
  }
  function createEntityMutationFrame() {
    return new EntityMutationFrame(valueStore, structuralStore);
  }
  function preparePointValues(values) {
    const prepared = values.map(({ subjectId, key, value, edits }) => {
      if (structuralStore.activeKeyForSubject(subjectId) !== key) {
        throw new Error(
          "Point realization subject is no longer active at its key"
        );
      }
      const before = valueStore.backingForSubject(subjectId);
      const after = deepClone(value);
      return {
        subjectId,
        key,
        before,
        after,
        transition: valueStore.prepareRealizationTransition(
          subjectId,
          after,
          edits
        ),
        changed: !deepEqual(before, after),
        epoch: subjectEpochs.get(subjectId)
      };
    });
    return {
      install() {
        for (const row of prepared)
          valueStore.installValueTransition(row.transition);
      },
      invalidate() {
        let failed = false;
        let firstError;
        const stage = (fn) => {
          try {
            fn();
          } catch (error) {
            if (!failed) {
              failed = true;
              firstError = error;
            }
          }
        };
        for (const row of prepared) {
          const epoch = row.epoch;
          if (epoch) stage(() => advanceEpochHandle(epoch));
        }
        stage(() => updateSignals());
        if (failed) throw firstError;
      },
      publish() {
        for (const row of prepared) {
          pathNotifier.notify(
            `${basePath}.${String(row.key)}`,
            row.after,
            row.before,
            basePath,
            [row.subjectId],
            getPositionIdsForNotify(),
            withEntityValueTransition(
              {
                ...ambientMeta() ?? {},
                intent: "system",
                participation: "realized"
              },
              row.transition
            )
          );
          if (row.changed) emitTap("onUpdate", row.key, row.after, row.after);
        }
      }
    };
  }
  function readTransitionSource() {
    if (positionId === void 0) {
      throw new Error("Collection transition binding has no owner PositionId");
    }
    const subjects = structuralStore.activeKeysSnapshot().map((key) => {
      const subject = structuralStore.subjectIdForKey(key);
      const value = subject === void 0 ? void 0 : valueStore.backingForSubject(subject);
      if (subject === void 0 || value === void 0) {
        throw new Error(
          "Collection transition source is missing active subject truth"
        );
      }
      return { subject, key, value };
    });
    return {
      owner: positionId,
      subjects,
      order: subjects.map(({ subject }) => subject),
      orderFrontier: structuralStore.activeOrderFrontier()
    };
  }
  function prepareOrdinaryRealization(effects, physicalAfter, physicalEffects = effects, physicalPlacement, ordinaryOrder) {
    const physical = physicalPlacement ?? structuralStore.preparePlacement();
    if (!physicalPlacement)
      for (const effect of physicalEffects) {
        if (typeof effect.subjectId !== "number") continue;
        const id = effect.subjectId;
        const placement2 = realizationPlacement(effect) ?? effect, context = placement2.structuralContext;
        if (effect.structural === "remove") physical.remove(id);
        else if (effect.structural === "add")
          physical.insert(
            id,
            effect.after,
            context && context.kind !== "rekey" ? context.beforeSubject : void 0,
            context && context.kind !== "rekey" ? context.afterSubject : void 0
          );
        else if (effect.structural === "rekey") {
          physical.rekey(id, effect.after);
          if (realizationPlacement(effect))
            physical.insert(
              id,
              effect.after,
              context && context.kind !== "rekey" ? context.beforeSubject : void 0,
              context && context.kind !== "rekey" ? context.afterSubject : void 0
            );
        }
      }
    const placement = ordinaryTopology.preparePlacement(
      structuralStore.preparePlacement()
    );
    const orderBefore = ordinaryOrder ? placement.snapshot() : void 0;
    const staged = /* @__PURE__ */ new Map();
    const physicalValues = /* @__PURE__ */ new Map();
    const changes = [];
    const read = (subject) => {
      const row = placement.read(subject);
      if (!row.present) return { present: false };
      const known = staged.get(subject);
      return {
        ...row,
        value: known?.present ? known.value : valueStore.ordinaryForSubject(subject)
      };
    };
    for (const effect of effects) {
      if (typeof effect.subjectId !== "number") continue;
      const subject = effect.subjectId;
      const previous = read(subject);
      const storedContext = effect.structuralContext;
      let context = effect.structural === "add" || effect.structural === "remove" ? storedContext && storedContext.kind !== "rekey" ? {
        ...storedContext,
        kind: effect.structural,
        key: effect.structural === "add" ? effect.after : effect.before
      } : void 0 : effect.structural === "rekey" ? {
        kind: "rekey",
        subject,
        beforeKey: effect.before,
        afterKey: effect.after
      } : void 0;
      if (context?.kind === "remove") {
        placement.remove(subject);
        staged.set(subject, { present: false });
        changes.push({
          subject,
          before: previous.present ? previous.value : context.value,
          after: void 0,
          structural: true,
          path: `${basePath}.${String(context.key)}`,
          structuralRecord: context
        });
      } else if (context?.kind === "add") {
        const value = deepClone(context.value);
        placement.insert(
          subject,
          context.key,
          context.beforeSubject,
          context.afterSubject
        );
        const resolved = placement.read(subject);
        if (resolved.present)
          context = {
            ...context,
            beforeSubject: resolved.beforeSubject,
            afterSubject: resolved.afterSubject
          };
        staged.set(subject, {
          present: true,
          key: context.key,
          value,
          beforeSubject: context.beforeSubject,
          afterSubject: context.afterSubject
        });
        physicalValues.set(
          subject,
          physicalAfter?.get(subject) ?? (structuralStore.activeKeyForSubject(subject) === void 0 ? value : valueStore.backingForSubject(subject))
        );
        changes.push({
          subject,
          before: void 0,
          after: value,
          structural: true,
          path: `${basePath}.${String(context.key)}`,
          structuralRecord: { ...context, value }
        });
      } else if (context?.kind === "rekey") {
        if (!previous.present)
          throw new Error("Ordinary rekey realization lacks its lifetime");
        placement.rekey(subject, context.afterKey);
        staged.set(subject, { ...previous, key: context.afterKey });
        changes.push({
          subject,
          before: previous.value,
          after: previous.value,
          structural: true,
          path: `${basePath}.${String(context.beforeKey)}`,
          structuralRecord: context
        });
      } else if (!effect.structural) {
        if (!previous.present)
          throw new Error("Ordinary field realization lacks its lifetime");
        const segments = effect.subjectFieldSegments;
        if (segments === void 0 || segments.length > 1)
          throw new Error(
            "Ordinary realization requires an explicit top-level field address"
          );
        let value;
        if (segments.length === 0) value = deepClone(effect.after);
        else {
          value = { ...previous.value };
          if (effect.fieldPresence?.after !== false)
            Object.defineProperty(value, segments[0], {
              value: deepClone(effect.after),
              enumerable: true,
              configurable: true,
              writable: true
            });
          else delete value[segments[0]];
        }
        staged.set(subject, { ...previous, value });
        const beforeP = physicalValues.get(subject) ?? valueStore.backingForSubject(subject);
        let afterP = physicalAfter?.get(subject);
        if (afterP === void 0) {
          if (segments.length === 0) afterP = value;
          else {
            afterP = { ...beforeP };
            if (effect.fieldPresence?.after !== false)
              Object.defineProperty(afterP, segments[0], {
                value: deepClone(effect.after),
                enumerable: true,
                configurable: true,
                writable: true
              });
            else delete afterP[segments[0]];
          }
        }
        physicalValues.set(subject, afterP);
        changes.push({
          subject,
          before: previous.value,
          after: value,
          structural: false,
          path: `${basePath}.${String(previous.key)}`
        });
      }
    }
    const valueTransitions = [];
    for (const [subject, state] of staged) {
      if (!state.present) continue;
      const physical2 = physicalAfter?.get(subject) ?? physicalValues.get(subject) ?? valueStore.backingForSubject(subject);
      valueTransitions.push(
        Object.freeze({
          subject,
          physicalBefore: valueStore.backingForSubject(subject),
          physicalAfter: physical2,
          ordinaryBefore: valueStore.ordinaryForSubject(subject),
          ordinaryAfter: state.value,
          retainDivergence: !deepEqual(state.value, physical2)
        })
      );
    }
    if (ordinaryOrder) placement.orderDomain(ordinaryOrder);
    const installPlacement = ordinaryTopology.prepareInstall(
      placement,
      physical
    );
    const ordinaryEndpoints = ordinaryOrder && orderBefore ? Object.freeze({
      before: Object.freeze(
        orderBefore.filter((subject) => ordinaryOrder.includes(subject))
      ),
      after: Object.freeze([...ordinaryOrder]),
      domain: ordinaryOrder
    }) : void 0;
    return {
      changes,
      ordinaryEndpoints,
      install: () => {
        for (const transition of valueTransitions)
          valueStore.installValueTransition(transition);
        for (const [subject, state] of staged)
          if (!state.present) valueStore.dischargeOrdinaryValue(subject);
        installPlacement();
      }
    };
  }
  function prepareOrdinaryTopology(changes, physical = structuralStore.preparePlacement(), authoredOrder, authoredDomain) {
    const placement = ordinaryTopology.preparePlacement(
      structuralStore.preparePlacement()
    );
    const inspection = ambientMeta()?.participation === "inspection";
    const orderBefore = !inspection && authoredOrder ? placement.snapshot() : void 0;
    const staged = /* @__PURE__ */ new Map();
    const keys = /* @__PURE__ */ new Map();
    const selected = [];
    const byStep = [];
    const byPhysicalSubject = /* @__PURE__ */ new Map();
    const read = (subject) => {
      const row = placement.read(subject);
      if (!row.present) return { present: false };
      const known = staged.get(subject);
      return {
        ...row,
        value: known?.present ? known.value : valueStore.ordinaryForSubject(subject)
      };
    };
    const atKey = (key) => {
      if (keys.has(key)) return keys.get(key);
      const subject = ordinaryTopology.atKey(key) ?? structuralStore.subjectIdForKey(key);
      if (subject === void 0) return void 0;
      const state = read(subject);
      return state.present && state.key === key ? subject : void 0;
    };
    const write = (subject, next) => {
      const previous = read(subject);
      if (previous.present) keys.set(previous.key, void 0);
      if (!next.present) placement.remove(subject);
      else if (!previous.present)
        placement.insert(
          subject,
          next.key,
          next.beforeSubject,
          next.afterSubject
        );
      else if (previous.key !== next.key) placement.rekey(subject, next.key);
      staged.set(subject, next);
      if (next.present) keys.set(next.key, subject);
    };
    const record = (kind, subject, state) => ({
      subject,
      before: kind === "remove" ? state.value : void 0,
      after: kind === "add" ? state.value : void 0,
      structural: true,
      path: `${basePath}.${String(state.key)}`,
      structuralRecord: ordinaryPresenceRecord(kind, subject, state)
    });
    for (const change of changes) {
      const effect = change.structuralRecord;
      const physicalKey = (effect?.kind === "rekey" ? effect.beforeKey : effect?.key) ?? structuralStore.activeKeyForSubject(change.subject);
      const ordinary = read(change.subject);
      const group = [];
      if (inspection) {
        group.push(change);
      } else if (change.after === void 0) {
        if (ordinary.present)
          group.push(record("remove", change.subject, ordinary));
        write(change.subject, { present: false });
      } else {
        const key = effect?.kind === "rekey" ? effect.afterKey : physicalKey;
        const binds = !ordinary.present || effect?.kind === "add" || effect?.kind === "rekey";
        if (binds) {
          if (key === void 0)
            throw new Error("Ordinary entity admission lacks a key");
          const displaced = atKey(key);
          if (displaced !== void 0 && displaced !== change.subject) {
            const state = read(displaced);
            if (!state.present)
              throw new Error(
                "Ordinary occupancy index disagrees with lifetime"
              );
            group.push(record("remove", displaced, state));
            write(displaced, { present: false });
          }
          const resolveAnchor = (subject, direction) => {
            const seen = /* @__PURE__ */ new Set();
            while (subject !== void 0 && subject !== change.subject && !seen.has(subject)) {
              seen.add(subject);
              if (placement.read(subject).present) return subject;
              const row = physical.read(subject);
              subject = row.present ? row[direction] : void 0;
            }
            return void 0;
          };
          const physicalRow = physical.read(change.subject);
          const before = effect?.kind === "add" ? effect.beforeSubject : physicalRow.present ? physicalRow.beforeSubject : void 0;
          const after = effect?.kind === "add" ? effect.afterSubject : physicalRow.present ? physicalRow.afterSubject : void 0;
          const next = ordinary.present ? { ...ordinary, key } : {
            present: true,
            key,
            value: deepClone(change.after),
            beforeSubject: resolveAnchor(before, "beforeSubject"),
            afterSubject: resolveAnchor(after, "afterSubject")
          };
          if (!ordinary.present) {
            placement.insert(
              change.subject,
              next.key,
              next.beforeSubject,
              next.afterSubject
            );
            const resolved = placement.read(change.subject);
            if (resolved.present) Object.assign(next, resolved);
            group.push(record("add", change.subject, next));
          } else if (ordinary.key !== key)
            group.push({
              subject: change.subject,
              before: ordinary.value,
              after: ordinary.value,
              structural: true,
              path: `${basePath}.${String(ordinary.key)}`,
              structuralRecord: {
                kind: "rekey",
                subject: change.subject,
                beforeKey: ordinary.key,
                afterKey: key
              }
            });
          write(change.subject, next);
        } else {
          group.push({ ...change, before: ordinary.value });
          write(change.subject, { ...ordinary, value: change.after });
        }
      }
      const previous = byPhysicalSubject.get(change.subject);
      byPhysicalSubject.set(
        change.subject,
        previous === void 0 ? group : [...previous, ...group]
      );
      byStep.push(group);
      selected.push(...group);
    }
    let ordinaryEndpoints;
    if (!inspection && authoredOrder) {
      const ordered = authoredOrder.filter(
        (subject) => placement.read(subject).present
      );
      const orderAfter = placement.orderDomain(ordered);
      if (orderBefore)
        ordinaryEndpoints = Object.freeze({
          before: orderBefore,
          after: orderAfter,
          domain: Object.freeze([
            .../* @__PURE__ */ new Set([
              ...authoredDomain ?? authoredOrder,
              ...authoredOrder
            ])
          ])
        });
    }
    const installPlacement = ordinaryTopology.prepareInstall(
      placement,
      physical
    );
    return {
      changes: selected,
      byPhysicalSubject,
      byStep,
      install: installPlacement,
      ordinaryEndpoints
    };
  }
  function commitAndProjectEntityMutationFrame(frame, options2) {
    const revision = physicalCommitClock?.revision();
    const changes = [];
    const valueTransitions = /* @__PURE__ */ new Map();
    const valueResults = /* @__PURE__ */ new Map();
    for (const mutation of frame.mutations) {
      if (mutation.kind !== "replace-value") continue;
      const previous = valueResults.get(mutation.subjectId);
      const prepared = valueStore.prepareValueTransition(
        mutation.subjectId,
        mutation.nextValue,
        mutation.authoredFields,
        previous
      );
      valueTransitions.set(mutation, prepared);
      valueResults.set(
        mutation.subjectId,
        previous ? Object.freeze({
          ...prepared,
          physicalBefore: previous.physicalBefore,
          ordinaryBefore: previous.ordinaryBefore
        }) : prepared
      );
    }
    const hasFreshSubjects = frame.mutations.some(
      (mutation) => mutation.kind === "create-fresh-subject"
    );
    const tailKey = hasFreshSubjects ? structuralStore.lastActiveKey() : void 0;
    let tail = tailKey === void 0 ? void 0 : structuralStore.subjectIdForKey(tailKey);
    const changeIndexByMutation = /* @__PURE__ */ new Map();
    for (const m of frame.mutations) {
      changeIndexByMutation.set(m, changes.length);
      const key = "key" in m ? m.key : structuralStore.activeKeyForSubject(m.subjectId);
      const before = valueStore.backingForSubject(m.subjectId);
      const path = `${basePath}.${String(key)}`;
      if (m.kind === "replace-value") {
        const transition = valueTransitions.get(m);
        changes.push({
          subject: m.subjectId,
          before: transition.ordinaryBefore,
          after: transition.ordinaryAfter,
          structural: false,
          path
        });
      } else if (m.kind === "create-fresh-subject") {
        changes.push({
          subject: m.subjectId,
          before: void 0,
          after: m.nextValue,
          structural: true,
          path,
          structuralRecord: {
            kind: "add",
            subject: m.subjectId,
            key: m.key,
            value: deepClone(m.nextValue),
            beforeSubject: tail
          }
        });
        tail = m.subjectId;
      } else if (m.kind === "tombstone-subject") {
        const neighbors = getNeighborSubjects(m.key);
        changes.push({
          subject: m.subjectId,
          before,
          after: void 0,
          structural: true,
          path,
          structuralRecord: {
            kind: "remove",
            subject: m.subjectId,
            key: m.key,
            value: deepClone(before),
            ...neighbors
          }
        });
      } else if (m.kind === "transfer-key") {
        changes.push({
          subject: m.subjectId,
          before,
          after: before,
          structural: true,
          path: `${basePath}.${String(m.fromKey)}`,
          structuralRecord: {
            kind: "rekey",
            subject: m.subjectId,
            beforeKey: m.fromKey,
            afterKey: m.toKey
          }
        });
      }
    }
    const physicalPlacement = frame.preparePlacement();
    for (let index = 0; index < changes.length; index++) {
      const change = changes[index];
      if (change.structuralRecord?.kind !== "add") continue;
      const row = physicalPlacement.read(change.subject);
      if (row.present)
        changes[index] = {
          ...change,
          structuralRecord: {
            ...change.structuralRecord,
            beforeSubject: row.beforeSubject,
            afterSubject: row.afterSubject
          }
        };
    }
    const ordinaryPlan = prepareOrdinaryTopology(
      changes,
      physicalPlacement,
      frame.ordinaryOrder,
      frame.orderEndpoints?.before
    );
    const valueResultsByStep = frame.mutations.map((mutation) => {
      if (mutation.kind !== "replace-value") return void 0;
      const transition = valueTransitions.get(mutation);
      return Object.freeze({
        ...transition,
        ordinaryChanges: ordinaryPlan.byStep[changeIndexByMutation.get(mutation)]
      });
    });
    for (const [subject, transition] of valueResults) {
      valueResults.set(
        subject,
        Object.freeze({
          ...transition,
          ordinaryChanges: ordinaryPlan.byPhysicalSubject.get(subject)
        })
      );
    }
    const structuralFrontier = changes.some((change) => change.structural) && !frame.mutations.some((mutation) => mutation.kind === "restore-subject") ? {
      before: structuralStore.activeOrderFrontier(),
      after: void 0
    } : void 0;
    const responsibility = changes.length ? mutationCaptureRuntime?.prepareEntityResponsibility?.({
      owner: getPositionIds()?.[0],
      ownerPath: basePath,
      meta: ambientMeta(),
      changes: ordinaryPlan.changes,
      structuralFrontier
    }) : void 0;
    if (physicalCommitClock?.revision() !== revision)
      throw new Error(
        "Entity frame responsibility preparation reentered installation"
      );
    const observe = committedEntityObserver(
      structuralFrontier,
      ordinaryPlan.changes
    );
    const result = frame.commit(
      observe ? () => observe(ordinaryPlan.changes) : void 0,
      responsibility,
      structuralFrontier,
      valueTransitions,
      ordinaryPlan.install
    );
    if (options2?.advancePhysicalRevision !== false) {
      physicalCommitClock?.advance();
    }
    membershipTap?.(MEMBERSHIP_FACTS, frame.mutations);
    return {
      ...result,
      valueResults,
      valueResultsByStep,
      ordinaryChanges: ordinaryPlan.byPhysicalSubject,
      ordinaryEndpoints: ordinaryPlan.ordinaryEndpoints,
      orderEndpoints: frame.orderEndpoints
    };
  }
  const computeAll = () => {
    const entities = presentEntities();
    if (config.sortComparer) entities.sort(config.sortComparer);
    return entities;
  };
  const allSignal = createVersionedProjection(computeAll);
  const computeCount = () => absent() ? 0 : structuralStore.activeKeyCount();
  const countSignal = createVersionedProjection(computeCount);
  const fresh = (read) => (() => {
    version();
    return read();
  });
  const inTap = (cell, read) => taps.depth ? fresh(read) : cell;
  let idsSource;
  let idsValue = [];
  const computeIds = (all) => {
    if (absent()) return [];
    if (config.sortComparer) return all().map((e) => selectId(e));
    const keys = structuralStore.activeKeysSnapshot();
    if (keys !== idsSource) {
      idsSource = keys;
      idsValue = [...keys];
    }
    return idsValue;
  };
  const idsSignal = createVersionedProjection(
    () => computeIds(allSignal)
  );
  const computeMap = () => new Map(presentEntries());
  const mapSignal = createVersionedProjection(computeMap);
  const subjectEpochs = /* @__PURE__ */ new Map();
  const advanceEpochHandle = (handle) => {
    locations.advanceEpoch?.(handle);
  };
  const structuralStore = new StructuralStore();
  let membershipTap;
  function withMembershipGroup(run) {
    const tap = membershipTap;
    tap?.(MEMBERSHIP_OPEN);
    try {
      return run();
    } finally {
      tap?.(MEMBERSHIP_CLOSE);
    }
  }
  const valueStore = new EntityValueStore();
  const ordinaryTopology = new EntityOrdinaryTopology();
  const subjectStateSignals = /* @__PURE__ */ new Map();
  const ownerMetadataEnabled = options?.ownerMetadataEnabled ?? true;
  const subjectMetadataEnabled = options?.subjectMetadataEnabled ?? ownerMetadataEnabled;
  const positionMetadataEnabled = options?.positionMetadataEnabled ?? true;
  const hasRestorationAuthority = options?.hasRestorationAuthority ?? true;
  const ownerId = options?.ownerId;
  const physicalCommitClock = options?.physicalCommitClock;
  const mutationCaptureRuntime = options?.mutationCaptureRuntime;
  let positionId = (options?.positionIdAllocator ?? (positionMetadataEnabled ? entityPositionIdAllocatorOverride ?? standaloneEntityPositionIdAllocator : void 0))?.();
  let lastSubjectIds;
  let callableWriteIntent;
  function withCallableWriteIntent(intent, write) {
    const previous = callableWriteIntent;
    callableWriteIntent = intent;
    try {
      write();
    } finally {
      callableWriteIntent = previous;
    }
  }
  function consumeCallableWriteIntent() {
    const intent = callableWriteIntent;
    callableWriteIntent = void 0;
    return intent;
  }
  function ambientMeta() {
    const active = getActiveWriteContext();
    if (ownerId === void 0) return active;
    return { ...active ?? {}, ownerId };
  }
  function getPositionIds() {
    if (positionId === void 0) {
      const registry = getPositionRegistry(api);
      if (registry) {
        const allocated = registry.allocate();
        registry.registerCollectionPath(allocated, basePath);
        const address = getNodeAddress(proxy);
        if (address) registry.registerPositionAddress(allocated, address);
        positionId = allocated;
      }
    }
    return positionId === void 0 ? void 0 : [positionId];
  }
  function getPositionIdsForNotify() {
    return entityPositionIdNotifyEnabled && (positionId !== void 0 || mutationCaptureRuntime?.isCaptureActive()) ? getPositionIds() : void 0;
  }
  function createStructuralEffectMeta(effect, ordinaryChanges) {
    const meta = ambientMeta();
    const physical = { ...meta ?? {}, structuralEffect: effect };
    return ordinaryChanges === void 0 ? physical : withEntityOrdinaryChanges(physical, ordinaryChanges);
  }
  const predicateWindows = /* @__PURE__ */ new Map();
  const warnedPredicates = /* @__PURE__ */ new Set();
  const PREDICATE_CHURN_THRESHOLD = 12;
  const PREDICATE_CHURN_WINDOW_MS = 2e3;
  function warnOnPredicateChurn(method, predicate) {
    const source = String(predicate);
    if (predicateWindows.size > 200 || warnedPredicates.has(source)) return;
    const now = typeof performance !== "undefined" ? performance.now() : Date.now();
    const window2 = predicateWindows.get(source);
    if (!window2 || now - window2.start > PREDICATE_CHURN_WINDOW_MS) {
      predicateWindows.set(source, { count: 1, start: now });
      return;
    }
    window2.count++;
    if (window2.count < PREDICATE_CHURN_THRESHOLD) return;
    warnedPredicates.add(source);
    const perSecond = Math.round(
      window2.count / Math.max(now - window2.start, 1) * 1e3
    );
    console.warn(
      `SignalTree: \`${method}()\` received ${window2.count} DIFFERENT functions with identical source in ${Math.round(now - window2.start)}ms (~${perSecond}/second) \u2014 a rate only change detection produces. Results are memoised per predicate IDENTITY, so an inline arrow misses the cache every cycle and re-scans the collection: measured at 75x a hoisted predicate over 1,000 entities. Hoist it to a stable reference (a class field or module constant) and call \`${method}(thePredicate)()\`. Source: ${source.slice(0, 80)} [ST2026]`
    );
  }
  const rekeyedSubjects = /* @__PURE__ */ new Set();
  function planRekey(from, to) {
    const entity = getProjectedEntity(from);
    if (!entity) {
      throw new Error(`Entity with id ${String(from)} not found`);
    }
    if (from === to) {
      const noOpSubjectId = allocateSubjectId(from);
      return {
        commit() {
          lastSubjectIds = [noOpSubjectId];
        },
        publish() {
        }
      };
    }
    if (structuralStore.hasActiveKey(to)) {
      throw new Error(`Cannot change id to ${String(to)}: already in use`);
    }
    return planPreparedRekey(from, to, allocateSubjectId(from), entity);
  }
  function planPreparedRekey(from, to, subjectId, entity, placement) {
    if (from === to && !placement) {
      return {
        commit() {
          lastSubjectIds = [subjectId];
        },
        publish() {
        }
      };
    }
    let ordinaryChanges;
    const structuralEffect = {
      kind: "rekey",
      subject: subjectId,
      beforeKey: from,
      afterKey: to
    };
    return {
      commit(options2) {
        const transfer = {
          kind: "transfer-key",
          placement,
          fromKey: from,
          toKey: to,
          subjectId
        };
        const frame = createEntityMutationFrame();
        if (placement && !deepEqual(valueStore.backingForSubject(subjectId), entity))
          frame.stageValueReplacement({
            kind: "replace-value",
            key: from,
            subjectId,
            nextValue: entity
          });
        frame.stageKeyTransfer(transfer);
        const result = commitAndProjectEntityMutationFrame(frame, options2);
        ordinaryChanges = result.ordinaryChanges.get(subjectId);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        rekeyedSubjects.add(subjectId);
        lastSubjectIds = [subjectId];
        if (activeIdSignal() === from) {
          replaceLocation(activeIdSignal, to);
        }
        syncEntitySignal(to);
        updateSignals();
      },
      publish(metaOverride) {
        const meta = metaOverride ?? ambientMeta();
        pathNotifier.notify(
          `${basePath}.${String(to)}`,
          entity,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          ordinaryChanges === void 0 ? { ...meta, structuralEffect } : withEntityOrdinaryChanges(
            { ...meta, structuralEffect },
            ordinaryChanges
          )
        );
      }
    };
  }
  const activeIdSignal = locations.createCell(void 0);
  let cachedActiveEntity;
  function publishOrderChange(beforeSubjects, afterSubjects, beforeFrontier, afterFrontier = structuralStore.activeOrderFrontier(), ordinaryEndpoints, selectedDisposition = false) {
    if (positionId === void 0) return;
    mutationCaptureRuntime?.publishCollectionOrder?.({
      owner: positionId,
      ownerPath: basePath,
      beforeSubjects,
      afterSubjects,
      beforeFrontier,
      afterFrontier,
      ordinaryEndpoints,
      meta: selectedDisposition ? withSelectedEntityDisposition(ambientMeta(), []) : ambientMeta()
    });
  }
  function resolveSubjectId(id) {
    return structuralStore.subjectIdForKey(id);
  }
  function resolveSubjectState(subjectId) {
    return structuralStore.stateForSubject(subjectId);
  }
  function getSubjectRevision(subjectId) {
    return structuralStore.subjectRevision(subjectId);
  }
  function bumpSubjectRevision(subjectId) {
    structuralStore.bumpSubjectRevision(subjectId);
  }
  function stageSubjectEpoch(subjectId) {
    const epoch = subjectEpochs.get(subjectId);
    if (epoch) pendingSubjectEpochs.add(epoch);
  }
  function getSubjectEpoch(subjectId) {
    let epoch = subjectEpochs.get(subjectId);
    if (!epoch) {
      epoch = locations.createEpoch ? locations.createEpoch() : neutralEpoch();
      subjectEpochs.set(subjectId, epoch);
    }
    return epoch;
  }
  function neutralEpoch() {
    const cell = locations.createCell(0);
    const epoch = (() => cell());
    epoch.set = (value) => cell(value);
    epoch.update = (fn) => cell(fn);
    epoch.asReadonly = () => cell;
    return epoch;
  }
  function readSubjectEntity(subjectId) {
    getSubjectEpoch(subjectId)();
    return rowAbsent() ? void 0 : valueStore.backingForSubject(subjectId);
  }
  function readEntityByKey(id) {
    const subjectId = resolveSubjectId(id);
    if (subjectId === void 0) return presentEntity(id);
    return readSubjectEntity(subjectId);
  }
  function getSubjectStateSignal(subjectId) {
    const existing = subjectStateSignals.get(subjectId)?.deref();
    if (existing) return existing;
    const created = locations.createCell(0);
    subjectStateSignals.set(subjectId, new WeakRef(created));
    return created;
  }
  function bumpSubjectStateSignal(subjectId) {
    const signal = subjectStateSignals.get(subjectId)?.deref();
    if (signal) deriveLocation(signal, (value) => value + 1);
  }
  function publishSubjectPhysicalChange(subjectId) {
    bumpSubjectRevision(subjectId);
    bumpSubjectStateSignal(subjectId);
  }
  function allocateSubjectId(id) {
    const existing = structuralStore.subjectIdForKey(id);
    if (existing !== void 0) {
      return existing;
    }
    return commitFreshSubject(id);
  }
  function commitFreshSubject(id) {
    const subjectId = structuralStore.allocateFreshSubjectId();
    const physical = structuralStore.preparePlacement();
    const ordinary = ordinaryTopology.preparePlacement(
      structuralStore.preparePlacement()
    );
    physical.insert(subjectId, id);
    const installOrdinary = ordinaryTopology.prepareInstall(ordinary, physical);
    structuralStore.createSubject(subjectId, id);
    installOrdinary();
    physicalCommitClock?.advance();
    return subjectId;
  }
  function rememberSubjectId(id) {
    const resolved = allocateSubjectId(id);
    lastSubjectIds = [resolved];
    return resolved;
  }
  function commitExistingSubjectValue(subjectId, nextValue, fields) {
    const revision = physicalCommitClock?.revision();
    const transition = valueStore.prepareValueTransition(
      subjectId,
      nextValue,
      fields
    );
    const ordinaryPlan = prepareOrdinaryTopology([
      {
        subject: subjectId,
        before: transition.ordinaryBefore,
        after: transition.ordinaryAfter,
        structural: false,
        path: `${basePath}.${String(
          structuralStore.activeKeyForSubject(subjectId)
        )}`
      }
    ]);
    const capture = committedEntityObserver(void 0, ordinaryPlan.changes);
    const plan = mutationCaptureRuntime?.prepareEntityResponsibility?.({
      owner: getPositionIds()?.[0],
      ownerPath: basePath,
      changes: ordinaryPlan.changes,
      meta: ambientMeta()
    });
    if (physicalCommitClock?.revision() !== revision)
      throw new Error(
        "Entity responsibility preparation reentered installation"
      );
    valueStore.installValueTransition(transition);
    ordinaryPlan.install();
    if (plan) installTerminalRecord(plan);
    capture?.(ordinaryPlan.changes);
    physicalCommitClock?.advance();
    return Object.freeze({
      ...transition,
      ordinaryChanges: ordinaryPlan.changes
    });
  }
  function committedEntityObserver(structuralFrontier, preparedChanges) {
    if (!mutationCaptureRuntime?.hasCommittedEntityObservers?.() && !(structuralFrontier && mutationCaptureRuntime?.hasStructuralBoundaryObservers?.()))
      return void 0;
    const owner = getPositionIds()?.[0];
    if (owner === void 0) return void 0;
    const meta = ambientMeta();
    const structuralRecords = structuralFrontier ? preparedChanges?.flatMap((change) => {
      const record = change.structuralRecord;
      if (!record) return [];
      if (record.kind === "rekey") return [record];
      const { value: _value, ...placement } = record;
      return [placement];
    }) : void 0;
    return (changes) => mutationCaptureRuntime.publishCommittedEntity?.({
      owner,
      ownerPath: basePath,
      changes,
      structuralFrontier,
      structuralRecords,
      meta
    });
  }
  function rememberSubjectIds(ids) {
    const resolved = ids.map((id) => allocateSubjectId(id));
    lastSubjectIds = resolved;
    return resolved;
  }
  function findKeyBySubjectId(subjectId) {
    return structuralStore.activeKeyForSubject(subjectId);
  }
  function getNeighborSubjects(id) {
    return structuralStore.neighborSubjectsForKey(id);
  }
  function restoreOne(key, entity, subjectId, beforeSubject, afterSubject) {
    const planned = planRestore(
      key,
      entity,
      subjectId,
      beforeSubject,
      afterSubject
    );
    planned.commit();
    planned.publish();
  }
  function planRestore(key, entity, subjectId, beforeSubject, afterSubject, vacatingKeys) {
    if (structuralStore.hasActiveKey(key) && !vacatingKeys?.has(key)) {
      throw new Error(`Entity with id ${String(key)} already exists`);
    }
    const state = resolveSubjectState(subjectId);
    if (state && !state.restoreAllowed) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} has retired backing and cannot be restored.`
      );
    }
    const restoration = {
      kind: "restore-subject",
      key,
      subjectId,
      restoreAllowed: state?.restoreAllowed ?? true,
      beforeSubject,
      afterSubject,
      realizedValue: entity
    };
    return {
      commit(options2) {
        const frame = createEntityMutationFrame();
        frame.stageSubjectRestore(restoration);
        const result = commitAndProjectEntityMutationFrame(frame, options2);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride) {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          void 0,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...metaOverride ?? ambientMeta() ?? {},
            structuralEffect: {
              kind: "add",
              subject: subjectId,
              key,
              value: deepClone(entity),
              beforeSubject,
              afterSubject
            }
          }
        );
        emitTap("onAdd", entity, key);
      }
    };
  }
  function planFreshAdd(key, entity, subjectId) {
    const existingState = resolveSubjectState(subjectId);
    if (existingState) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} already exists and cannot be realized as fresh.`
      );
    }
    return {
      commit(options2) {
        const frame = createEntityMutationFrame();
        frame.stageFreshSubject({
          kind: "create-fresh-subject",
          key,
          subjectId,
          nextValue: entity
        });
        commitAndProjectEntityMutationFrame(frame, options2);
        lastSubjectIds = [subjectId];
        invalidateNodeCache(key);
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride) {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          void 0,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          metaOverride
        );
        emitTap("onAdd", entity, key);
      }
    };
  }
  function planRemove(key, subjectId) {
    const entity = getProjectedEntity(key);
    if (!entity) {
      throw new Error(`Entity with id ${String(key)} not found`);
    }
    const { beforeSubject, afterSubject } = getNeighborSubjects(key);
    const structuralEffect = {
      kind: "remove",
      subject: subjectId,
      key,
      value: deepClone(entity),
      beforeSubject,
      afterSubject
    };
    const currentState = resolveSubjectState(subjectId);
    const tombstone = {
      kind: "tombstone-subject",
      key,
      subjectId,
      restoreAllowed: currentState?.restoreAllowed ?? true
    };
    return {
      commit(options2) {
        const frame = createEntityMutationFrame();
        frame.stageSubjectTombstone(tombstone);
        const result = commitAndProjectEntityMutationFrame(frame, options2);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        tombstoneSubjectSignal(subjectId);
        updateSignals();
      },
      publish(metaOverride) {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          void 0,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...metaOverride ?? ambientMeta() ?? {},
            structuralEffect
          }
        );
        emitTap("onRemove", key, entity);
      }
    };
  }
  function rewritePendingAddEffect(effect, beforeSubject, afterSubject) {
    effect.beforeSubject = beforeSubject;
    effect.afterSubject = afterSubject;
  }
  function assertSynchronousInterceptorFunction(handler, hookName) {
    if (typeof handler === "function" && handler.constructor?.name === "AsyncFunction") {
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }
  function assertSynchronousInterceptorResult(result, hookName) {
    if (result && typeof result.then === "function") {
      void result.catch(() => void 0);
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }
  function assertSynchronousInterceptors(handlers) {
    assertSynchronousInterceptorFunction(handlers.onAdd, "onAdd");
    assertSynchronousInterceptorFunction(handlers.onUpdate, "onUpdate");
    assertSynchronousInterceptorFunction(handlers.onRemove, "onRemove");
  }
  function interceptAddedEntity(entity) {
    if (interceptsSuppressed) return entity;
    let transformedEntity = entity;
    for (const handler of interceptHandlers) {
      const ctx = {
        block: (reason) => {
          throw new Error(
            `Cannot add entity: ${reason || "blocked by interceptor"}`
          );
        },
        transform: (value) => {
          transformedEntity = value;
        },
        blocked: false,
        blockReason: void 0
      };
      assertSynchronousInterceptorResult(handler.onAdd?.(entity, ctx), "onAdd");
    }
    return transformedEntity;
  }
  function interceptReplacedEntity(id, entity) {
    if (interceptsSuppressed) return entity;
    let replacement = entity;
    for (const handler of interceptHandlers) {
      const ctx = {
        block: (reason) => {
          throw new Error(
            `Cannot replace entity: ${reason || "blocked by interceptor"}`
          );
        },
        transform: (value) => {
          replacement = value;
        },
        blocked: false,
        blockReason: void 0
      };
      assertSynchronousInterceptorResult(
        handler.onUpdate?.(id, entity, ctx),
        "onUpdate"
      );
    }
    return replacement;
  }
  function interceptUpdatedEntity(id, changes) {
    if (interceptsSuppressed) return changes;
    let transformedChanges = changes;
    for (const handler of interceptHandlers) {
      const ctx = {
        block: (reason) => {
          throw new Error(
            `Cannot update entity: ${reason || "blocked by interceptor"}`
          );
        },
        transform: (value) => {
          transformedChanges = value;
        },
        blocked: false,
        blockReason: void 0
      };
      assertSynchronousInterceptorResult(
        handler.onUpdate?.(id, changes, ctx),
        "onUpdate"
      );
    }
    return transformedChanges;
  }
  function addManyInOrder(entities, opts, prepend = false) {
    const mode = opts?.mode ?? "strict";
    const lastPreviousKey = structuralStore.lastActiveKey();
    const toProcess = [];
    const copies = [];
    const earlier = /* @__PURE__ */ new Map();
    for (const entity of entities) {
      const id = deriveId(entity, opts);
      const existingSubjectId = structuralStore.subjectIdForKey(id);
      let processed = earlier.get(id);
      if (existingSubjectId !== void 0 || processed) {
        if (mode === "strict") {
          throw new Error(`Entity with id ${String(id)} already exists`);
        } else if (mode === "skip") {
          continue;
        }
      }
      if (!processed) {
        processed = { entity, id, existingSubjectId };
        earlier.set(id, processed);
        toProcess.push(processed);
      }
      copies.push([processed, entity]);
    }
    if (toProcess.length === 0) return [];
    for (const [processed, entity] of copies) {
      processed.entity = interceptAddedEntity(entity);
    }
    const stagedAdds = toProcess;
    const plannedFreshSubjectIds = structuralStore.planFreshSubjectIds(
      stagedAdds.filter(
        ({ existingSubjectId }) => existingSubjectId === void 0
      ).length
    );
    let plannedFreshIndex = 0;
    const preparedAdds = stagedAdds.map(
      ({ id, entity, existingSubjectId }) => ({
        id,
        entity,
        existingSubjectId,
        // A replacement retains its lifetime; capture what it replaces
        // before the physical frame installs the new value.
        prev: existingSubjectId === void 0 ? void 0 : valueStore.backingForSubject(existingSubjectId),
        subjectId: existingSubjectId ?? plannedFreshSubjectIds[plannedFreshIndex++]
      })
    );
    const beforeFrontier = structuralStore.activeOrderFrontier();
    const frame = createEntityMutationFrame();
    for (const {
      id,
      entity: transformedEntity,
      existingSubjectId,
      subjectId
    } of preparedAdds) {
      if (existingSubjectId === void 0) {
        frame.stageFreshSubject({
          kind: "create-fresh-subject",
          key: id,
          subjectId,
          nextValue: transformedEntity
        });
        continue;
      }
      frame.stageValueReplacement({
        kind: "replace-value",
        key: id,
        subjectId: existingSubjectId,
        nextValue: transformedEntity
      });
    }
    if (prepend) frame.stageFinalFront(preparedAdds.map((row) => row.id));
    const committed = commitAndProjectEntityMutationFrame(frame);
    const subjectIdsByKey = /* @__PURE__ */ new Map();
    for (const { id, subjectId } of preparedAdds) {
      subjectIdsByKey.set(id, subjectId);
    }
    const processedIds = [];
    const addedEntities = [];
    for (const { entity: transformedEntity, id } of preparedAdds) {
      const subjectId = subjectIdsByKey.get(id);
      if (subjectId === void 0) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      invalidateNodeCache(id);
      syncEntitySignal(id);
      processedIds.push(id);
      addedEntities.push({ id, entity: transformedEntity, subjectId });
    }
    updateSignals();
    if (committed.orderEndpoints) {
      if (mutationCaptureRuntime?.isCaptureActive()) getPositionIds();
      publishOrderChange(
        committed.orderEndpoints.before,
        committed.orderEndpoints.after,
        beforeFrontier,
        void 0,
        committed.ordinaryEndpoints
      );
    }
    const subjectIdsForWrite = processedIds.map((id) => {
      const subjectId = subjectIdsByKey.get(id);
      if (subjectId === void 0) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      return subjectId;
    });
    lastSubjectIds = subjectIdsForWrite;
    let previousAppendedSubject = lastPreviousKey === void 0 ? void 0 : allocateSubjectId(lastPreviousKey);
    for (let i = 0; i < addedEntities.length; i++) {
      const { id, entity } = addedEntities[i];
      const beforeSubject = previousAppendedSubject;
      if (preparedAdds[i].existingSubjectId === void 0) {
        previousAppendedSubject = subjectIdsForWrite[i];
      }
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        entity,
        preparedAdds[i].prev,
        basePath,
        [subjectIdsForWrite[i]],
        getPositionIdsForNotify(),
        preparedAdds[i].existingSubjectId === void 0 ? createStructuralEffectMeta(
          {
            kind: "add",
            subject: subjectIdsForWrite[i],
            key: id,
            value: deepClone(entity),
            ...prepend ? getNeighborSubjects(id) : { beforeSubject }
          },
          committed.ordinaryChanges.get(subjectIdsForWrite[i])
        ) : withEntityValueTransition(
          ambientMeta(),
          committed.valueResults.get(subjectIdsForWrite[i])
        )
      );
    }
    for (const { id, entity } of addedEntities) {
      emitTap("onAdd", entity, id);
    }
    return processedIds;
  }
  function addOneWithStructuralEffect(entity, opts, prepend = false) {
    const id = deriveId(entity, opts);
    const previousLastKey = structuralStore.lastActiveKey();
    recordProductionSubstrateStat("publicAddPreviousTailReads");
    if (structuralStore.hasActiveKey(id)) {
      throw new Error(`Entity with id ${String(id)} already exists`);
    }
    const transformedEntity = interceptAddedEntity(entity);
    const subjectId = structuralStore.planFreshSubjectIds(1)[0];
    if (subjectId === void 0) {
      throw new Error(
        `Fresh subject planning for ${String(id)} did not produce an id.`
      );
    }
    const frame = createEntityMutationFrame();
    const freshSubject = {
      kind: "create-fresh-subject",
      key: id,
      subjectId,
      nextValue: transformedEntity
    };
    frame.stageFreshSubject(freshSubject);
    if (prepend) frame.stageFinalFront([id]);
    const committed = commitAndProjectEntityMutationFrame(frame);
    const structuralEffect = {
      kind: "add",
      subject: subjectId,
      key: id,
      value: deepClone(transformedEntity),
      beforeSubject: previousLastKey === void 0 ? void 0 : allocateSubjectId(previousLastKey)
    };
    if (prepend) {
      const neighbors = getNeighborSubjects(id);
      rewritePendingAddEffect(
        structuralEffect,
        neighbors.beforeSubject,
        neighbors.afterSubject
      );
    }
    lastSubjectIds = [subjectId];
    invalidateNodeCache(id);
    syncEntitySignal(id);
    updateSignals();
    pathNotifier.notify(
      `${basePath}.${String(id)}`,
      transformedEntity,
      void 0,
      basePath,
      [subjectId],
      getPositionIdsForNotify(),
      createStructuralEffectMeta(
        structuralEffect,
        committed.ordinaryChanges.get(subjectId)
      )
    );
    emitTap("onAdd", transformedEntity, id);
    return { id, structuralEffect };
  }
  function syncEntitySignal(id) {
    const subjectId = resolveSubjectId(id);
    if (subjectId === void 0) {
      return;
    }
    stageSubjectEpoch(subjectId);
  }
  function tombstoneSubjectSignal(subjectId) {
    stageSubjectEpoch(subjectId);
  }
  const nodeCache = /* @__PURE__ */ new Map();
  const nodeFinalizer = typeof FinalizationRegistry === "function" ? new FinalizationRegistry((subjectId) => {
    if (nodeCache.get(subjectId)?.deref() === void 0) {
      nodeCache.delete(subjectId);
    }
  }) : null;
  function invalidateNodeCache(id) {
    const subjectId = resolveSubjectId(id);
    if (subjectId !== void 0) {
      nodeCache.delete(subjectId);
    }
  }
  let cachedEmpty = null;
  const selectId = config.selectId ?? ((entity) => entity["id"]);
  let warnedMissingId = false;
  function deriveId(entity, opts) {
    const id = opts?.selectId?.(entity) ?? selectId(entity);
    if (id == null && (typeof ngDevMode === "undefined" || ngDevMode) && !warnedMissingId) {
      warnedMissingId = true;
      console.warn(
        `SignalTree entityMap${basePath ? ` at "${basePath}"` : ""}: an entity resolved to id=${String(
          id
        )}. Entities need a stable key \u2014 give them an \`id\` field or pass entityMap({ selectId: (e) => e.yourKey }). Without it, entities collide under a single key. [ST2001]`
      );
    }
    return id;
  }
  const tapHandlers = [];
  const emitTap = (method, ...args) => {
    if (pendingReAdd) {
      pendingReAdd = false;
      reactivatePathOnWrite(api);
    }
    const suppressed = interceptsSuppressed;
    const nested = reAdding;
    interceptsSuppressed = 0;
    reAdding = false;
    taps.depth++;
    try {
      for (const handler of tapHandlers)
        handler[method]?.(
          ...args
        );
    } finally {
      taps.depth--;
      interceptsSuppressed = suppressed;
      reAdding = nested;
    }
  };
  let interceptsSuppressed = 0;
  let reAdding = false;
  let pendingReAdd = false;
  let silentClear = 0;
  const interceptHandlers = [];
  function updateSignals() {
    const pending = [...pendingSubjectEpochs];
    pendingSubjectEpochs.clear();
    if (absent()) return;
    locations.runInvalidationGroup(() => {
      for (const epoch of pending) {
        advanceEpochHandle(epoch);
      }
      deriveLocation(version, (value) => value + 1);
      markOwnerInvalidated(ownerId);
    });
  }
  function createEntityNode(subjectId, initialKey, entity) {
    const handle = acquireEntityHandleForTesting(initialKey);
    if (handle === void 0 || handle.subjectId !== subjectId) {
      throw new Error(
        `Entity with id ${String(initialKey)} has no acquired subject handle`
      );
    }
    let activationCarrier;
    const currentKey = () => {
      (activationCarrier ??= getSubjectStateSignal(subjectId))();
      const resolved = structuralStore.resolveSubjectHandle(handle);
      return resolved.state === "active" ? resolved.key : void 0;
    };
    const entitySig = () => {
      const key = currentKey();
      return key === void 0 ? void 0 : readEntityByKey(key);
    };
    const node = ((valueOrUpdater) => {
      if (valueOrUpdater === void 0) {
        return entitySig();
      }
      const key = currentKey();
      if (key === void 0) {
        throw new Error(`Entity with subject ${String(subjectId)} not found`);
      }
      const current = presentEntity(key);
      if (current === void 0) {
        throw new Error(`Entity with id ${String(key)} not found`);
      }
      const next = typeof valueOrUpdater === "function" ? valueOrUpdater(current) : valueOrUpdater;
      withCallableWriteIntent(
        typeof valueOrUpdater === "function" ? "derive" : "replace",
        () => api.replaceOne(key, next)
      );
      return void 0;
    });
    const registry = getPositionRegistry(api);
    const owner = registry ? getPositionIds()?.[0] : void 0;
    const bindLocation = (location, fieldKey) => {
      if (!registry || owner === void 0) return;
      definePositionRegistry(location, registry);
      defineEntityLocationBinding(location, { owner, subjectId, fieldKey });
      if (mutationCaptureRuntime) {
        Object.defineProperty(location, MUTATION_CAPTURE_RUNTIME, {
          value: mutationCaptureRuntime
        });
      }
    };
    bindLocation(node);
    for (const key of Object.keys(entity)) {
      const fieldKey = key;
      const computeField = () => {
        const current = entitySig();
        return current && Object.prototype.hasOwnProperty.call(current, fieldKey) ? current[fieldKey] : void 0;
      };
      const writeField = (value, intent) => {
        const key2 = currentKey();
        if (key2 === void 0) {
          throw new Error(`Entity with subject ${String(subjectId)} not found`);
        }
        withCallableWriteIntent(
          intent,
          () => api.updateOne(key2, { [fieldKey]: value })
        );
      };
      const fieldSignal = locations.createWritableProjection ? locations.createWritableProjection(computeField, writeField) : createWritableProjection(
        locations.createDerived(computeField),
        writeField
      );
      bindLocation(fieldSignal, key);
      if (ownerMetadataEnabled) {
        Object.defineProperty(fieldSignal, "__ownerPath", {
          get: () => {
            const key2 = currentKey();
            return key2 === void 0 ? void 0 : `${basePath}.${String(key2)}`;
          },
          enumerable: false,
          configurable: true
        });
      }
      if (subjectMetadataEnabled) {
        Object.defineProperty(fieldSignal, "__subjectIds", {
          get: () => [subjectId],
          enumerable: false,
          configurable: true
        });
      }
      if (positionMetadataEnabled) {
        Object.defineProperty(fieldSignal, "__positionIds", {
          get: getPositionIds,
          enumerable: false,
          configurable: true
        });
      }
      Object.defineProperty(node, key, {
        get: () => fieldSignal,
        enumerable: true,
        configurable: true
      });
    }
    return node;
  }
  function getOrCreateNode(id, entity) {
    const subjectId = resolveSubjectId(id);
    if (subjectId === void 0) {
      throw new Error(`Entity with id ${String(id)} has no subject id`);
    }
    let node = nodeCache.get(subjectId)?.deref();
    if (!node) {
      node = createEntityNode(subjectId, id, entity);
      nodeCache.set(subjectId, new WeakRef(node));
      nodeFinalizer?.register(node, subjectId);
    }
    return node;
  }
  function inspectSubjectResources(subjectId) {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState) {
      return void 0;
    }
    const node = nodeCache.get(subjectId)?.deref();
    const fieldFacadesMaterialized = node === void 0 ? [] : Object.keys(node).filter(
      (key) => typeof node[key] === "function"
    ).sort((left, right) => left.localeCompare(right));
    return {
      subjectId,
      state: subjectState.active ? "active" : "tombstoned",
      subjectRevision: getSubjectRevision(subjectId),
      activeKey: subjectState.active ? subjectState.key : void 0,
      retainedSubjectState: structuralStore.hasSubject(subjectId),
      entitySignal: subjectEpochs.has(subjectId),
      activationToken: subjectStateSignals.get(subjectId)?.deref() !== void 0,
      nodeFacadeMaterialized: node !== void 0,
      fieldFacadesMaterialized,
      positionIds: getPositionIds(),
      retainedValueBacking: valueStore.hasRetainedValueBacking(subjectId) ? { kind: "retained-entity-signal" } : void 0
    };
  }
  function listSubjectReclamationCandidates() {
    return structuralStore.tombstonedSubjectsSnapshot().filter((subjectId) => valueStore.hasRetainedValueBacking(subjectId));
  }
  function prepareSubjectReclamation(subjectId, options2) {
    const inventory = inspectSubjectResources(subjectId);
    if (!inventory) {
      return void 0;
    }
    const plan = planEntitySubjectReclamation(inventory, options2);
    if (!plan.eligible) {
      return void 0;
    }
    return {
      subjectId,
      expectedLifetime: "tombstoned",
      expectedSubjectRevision: inventory.subjectRevision,
      retire: plan.retire,
      retain: plan.retain
    };
  }
  function applyPreparedSubjectReclamation(prepared) {
    const state = resolveSubjectState(prepared.subjectId);
    if (prepared.expectedLifetime !== "tombstoned") {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} has an unsupported expected lifetime.`
      );
    }
    if (!state) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }
    if (getSubjectRevision(prepared.subjectId) !== prepared.expectedSubjectRevision) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} is stale.`
      );
    }
    if (state.active) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }
    const frame = createEntityMutationFrame();
    const forgetLifetime = prepared.retire.includes("subject-lifetime-record");
    const retiresValue = prepared.retire.includes("retained-value-backing");
    if (forgetLifetime || retiresValue) {
      const retirement = {
        kind: "retire-retained-value",
        subjectId: prepared.subjectId,
        forgetLifetime
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(prepared.subjectId);
    }
    const result = commitAndProjectEntityMutationFrame(frame);
    for (const changedSubjectId of result.physicallyChangedSubjectIds) {
      if (forgetLifetime && changedSubjectId === prepared.subjectId) {
        continue;
      }
      publishSubjectPhysicalChange(changedSubjectId);
    }
  }
  function reclaimRetiredSubjectsWithoutOwner(subjectIds) {
    if (hasRestorationAuthority || subjectIds.length === 0) {
      return;
    }
    const frame = createEntityMutationFrame();
    let staged = 0;
    for (const subjectId of subjectIds) {
      const state = resolveSubjectState(subjectId);
      if (!state || state.active) {
        continue;
      }
      if (ordinaryTopology.retains(subjectId)) continue;
      if (!valueStore.hasRetainedValueBacking(subjectId)) {
        continue;
      }
      const retirement = {
        kind: "retire-retained-value",
        subjectId,
        forgetLifetime: true
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(subjectId);
      staged += 1;
    }
    if (staged === 0) {
      return;
    }
    commitAndProjectEntityMutationFrame(frame);
  }
  function retireSubjectRetainedValueBackingForTesting(subjectId) {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState || subjectState.active) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} must be tombstoned before retiring retained value backing.`
      );
    }
    valueStore.retireSubjectValue(subjectId);
    subjectEpochs.delete(subjectId);
  }
  const whereCache = /* @__PURE__ */ new WeakMap();
  const findCache = /* @__PURE__ */ new WeakMap();
  const api = {
    // ==================
    // EXPLICIT ACCESS
    // ==================
    byId(id) {
      if (!rowAbsent() && structuralStore.hasActiveKey(id)) {
        const entity = readEntityByKey(id);
        return entity ? getOrCreateNode(id, entity) : void 0;
      }
      idsSignal();
      return void 0;
    },
    byIdOrFail(id) {
      const node = api.byId(id);
      if (!node) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      return node;
    },
    // ==================
    // QUERIES (return Signals)
    // ==================
    get all() {
      return inTap(allSignal, computeAll);
    },
    get count() {
      return inTap(countSignal, computeCount);
    },
    get ids() {
      return inTap(idsSignal, () => computeIds(computeAll));
    },
    /**
     * The collection as a `ReadonlyMap`, keyed by id.
     *
     * Named `asMap` since 14.1.1. It was `map`, which read as a PROJECTION beside
     * `all()` — every JS developer expects `.map(fn)` to transform elements, and an
     * agent or newcomer reaching for that is a documented failure class (see
     * `WRONG_ENTITY_METHODS`). `asMap` says what it returns.
     */
    get asMap() {
      return inTap(mapSignal, computeMap);
    },
    // ── Active entity ───────────────────────────────────────────────────────
    get activeId() {
      return activeIdSignal.asReadonly();
    },
    /**
     * Resolved through the per-entity signal, NOT through `mapSignal`.
     *
     * That is the whole reason to build this here rather than leave it to the
     * app: a hand-rolled `getDerivedRuntime().createDerived(() => all().find(e => id(e) === activeId()))`
     * depends on the entire collection, so it recomputes when ANY row changes.
     * This depends on the active row's own signal, so it recomputes only when
     * that row changes — which is what `byId` exists for.
     */
    get activeEntity() {
      const read = () => {
        const id = activeIdSignal();
        if (id === void 0) return void 0;
        if (resolveSubjectId(id) === void 0) idsSignal();
        return readEntityByKey(id);
      };
      if (taps.depth) return fresh(read);
      return cachedActiveEntity ??= locations.createDerived(read);
    },
    setActiveId(id) {
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, id);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },
    clearActiveId() {
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, void 0);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },
    has(id) {
      const read = () => !absent() && structuralStore.hasActiveKey(id);
      return taps.depth ? fresh(read) : createVersionedProjection(read);
    },
    // Bare canonical name (the `.isEmpty` alias was removed in v11).
    get empty() {
      if (taps.depth) return fresh(() => computeCount() === 0);
      return cachedEmpty ??= locations.createDerived(
        () => countSignal() === 0
      );
    },
    where(predicate) {
      if (taps.depth) return fresh(() => computeAll().filter(predicate));
      const cached = whereCache.get(predicate);
      if (cached) return cached;
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnOnPredicateChurn("where", predicate);
      }
      const s = createVersionedProjection(() => {
        if (config.sortComparer) return allSignal().filter(predicate);
        const out = [];
        for (const entity of presentEntities()) {
          if (predicate(entity)) out.push(entity);
        }
        return out;
      });
      whereCache.set(predicate, s);
      return s;
    },
    find(predicate) {
      if (taps.depth) return fresh(() => computeAll().find(predicate));
      const cached = findCache.get(predicate);
      if (cached) return cached;
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnOnPredicateChurn("find", predicate);
      }
      const s = createVersionedProjection(() => {
        if (config.sortComparer) return allSignal().find(predicate);
        for (const entity of presentEntities()) {
          if (predicate(entity)) return entity;
        }
        return void 0;
      });
      findCache.set(predicate, s);
      return s;
    },
    // ==================
    // MUTATIONS: ADD
    // ==================
    addOne(entity, opts) {
      return addOneWithStructuralEffect(entity, opts).id;
    },
    /** Insert at the front before notification and lifecycle callbacks. */
    prependOne(entity, opts) {
      return withMembershipGroup(
        () => addOneWithStructuralEffect(entity, opts, true).id
      );
    },
    prependMany(entities, opts) {
      return withMembershipGroup(() => addManyInOrder(entities, opts, true));
    },
    /**
     * Change an entity's id in place — the missing half of optimistic creation.
     *
     * Insert with a temp id, then adopt the id the server assigned. Everything
     * keyed by the old id moves together: storage (keeping list position), the
     * per-entity signal, the node cache, and the active-entity selection.
     *
     * Held row/field references follow the rekey by SUBJECT identity rather than
     * by the old key. The old lookup disappears, but already-materialized row
     * state, metadata, and field signals remain attached to the same subject.
     * That keeps list position, active selection, and row-local reactivity while
     * still allowing the freed id to be reused by a different subject.
     */
    changeId(from, to) {
      if (rowAbsent())
        throw new Error(`Entity with id ${String(from)} not found`);
      const planned = planRekey(from, to);
      planned.commit();
      planned.publish();
    },
    addMany(entities, opts) {
      return addManyInOrder(entities, opts);
    },
    // ==================
    // MUTATIONS: UPDATE
    // ==================
    updateOne(id, changes) {
      const callableIntent = consumeCallableWriteIntent();
      const entity = presentEntity(id);
      if (!entity) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      const prev = entity;
      let transformedChanges = changes;
      for (const handler of interceptHandlers) {
        const ctx = {
          block: (reason) => {
            throw new Error(
              `Cannot update entity: ${reason || "blocked by interceptor"}`
            );
          },
          transform: (value) => {
            transformedChanges = value;
          },
          blocked: false,
          blockReason: void 0
        };
        assertSynchronousInterceptorResult(
          handler.onUpdate?.(id, changes, ctx),
          "onUpdate"
        );
      }
      const finalUpdated = { ...entity, ...transformedChanges };
      const subjectIdForWrite = rememberSubjectId(id);
      const transition = commitExistingSubjectValue(
        subjectIdForWrite,
        finalUpdated,
        Object.keys(transformedChanges)
      );
      syncEntitySignal(id);
      updateSignals();
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        finalUpdated,
        prev,
        basePath,
        lastSubjectIds,
        getPositionIdsForNotify(),
        withEntityValueTransition(ambientMeta(), transition),
        void 0,
        (callableIntent ?? getActiveWriteContext()?.mutationIntent) === "derive" ? void 0 : Object.keys(transformedChanges)
      );
      emitTap("onUpdate", id, transformedChanges, finalUpdated);
    },
    /**
     * Replace, not merge — and the write path behind `byId(id)(next)`.
     *
     * Identical to `updateOne` except the one line that matters: assign the whole
     * entity instead of spreading it over the current one. That single difference
     * is the only way to REMOVE a key, which `updateOne` cannot express at all.
     *
     * **Why `replaceOne(id, entity)` and not `setOne(entity)`.** The id comes from
     * the caller on purpose. A `setOne` deriving it via `selectId(entity)` writes
     * to whatever slot the entity's own id field names — and `changeId` can leave
     * `entity.id` disagreeing with the storage key, so that form has a silent
     * wrong-slot write built into it. This one cannot drift.
     */
    replaceOne(id, entity) {
      const callableIntent = consumeCallableWriteIntent();
      const prev = presentEntity(id);
      if (!prev) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      let next = entity;
      for (const handler of interceptHandlers) {
        const ctx = {
          block: (reason) => {
            throw new Error(
              `Cannot replace entity: ${reason || "blocked by interceptor"}`
            );
          },
          transform: (value) => {
            next = value;
          },
          blocked: false,
          blockReason: void 0
        };
        assertSynchronousInterceptorResult(
          handler.onUpdate?.(id, entity, ctx),
          "onUpdate"
        );
      }
      const subjectId = structuralStore.subjectIdForKey(id);
      if (subjectId === void 0) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      const mutationIntent = callableIntent ?? getActiveWriteContext()?.mutationIntent;
      const replacement = {
        kind: "replace-value",
        key: id,
        subjectId,
        nextValue: next,
        authoredFields: mutationIntent === "derive" ? "derive" : null
      };
      const frame = createEntityMutationFrame();
      frame.stageValueReplacement(replacement);
      const committed = commitAndProjectEntityMutationFrame(frame);
      const transition = committed.valueResults.get(subjectId);
      next = transition?.physicalAfter ?? next;
      syncEntitySignal(id);
      updateSignals();
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        next,
        prev,
        basePath,
        // REPLACE-ONE-SUBJECT-1. This was `undefined`, and it was the ONLY
        // entity notification in this file that dropped subject identity —
        // `updateOne`, `updateMany` and `removeOne` all pass theirs. The id
        // above is DATA; `subjectId` is IDENTITY, and it was already resolved
        // from `structuralStore` a few lines up, so nothing new is looked up
        // here.
        //
        // Without it, reversal effects arrive with `subjectId: undefined`,
        // `hasInlineSubjectAddress` is false, no inline subject address is
        // derived, and no fallback descriptor can be keyed — so rollback and
        // undo both REFUSE, at TOP level as well as nested.
        [subjectId],
        getPositionIdsForNotify(),
        withEntityValueTransition(
          ambientMeta(),
          committed.valueResults.get(subjectId)
        ),
        void 0,
        (callableIntent ?? getActiveWriteContext()?.mutationIntent) === "derive" ? void 0 : null
      );
      emitTap("onUpdate", id, next, next);
    },
    updateMany(ids, changes) {
      if (ids.length === 0) return;
      const updatedEntities = [];
      for (const id of ids) {
        const entity = presentEntity(id);
        if (!entity) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        const prev = entity;
        let transformedChanges = changes;
        for (const handler of interceptHandlers) {
          const ctx = {
            block: (reason) => {
              throw new Error(
                `Cannot update entity: ${reason || "blocked by interceptor"}`
              );
            },
            transform: (value) => {
              transformedChanges = value;
            },
            blocked: false,
            blockReason: void 0
          };
          assertSynchronousInterceptorResult(
            handler.onUpdate?.(id, changes, ctx),
            "onUpdate"
          );
        }
        const finalUpdated = { ...entity, ...transformedChanges };
        const subjectId = structuralStore.subjectIdForKey(id);
        if (subjectId === void 0) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        updatedEntities.push({
          id,
          subjectId,
          prev,
          finalUpdated,
          transformedChanges
        });
      }
      const frame = createEntityMutationFrame();
      for (const {
        id,
        subjectId,
        finalUpdated,
        transformedChanges
      } of updatedEntities) {
        frame.stageValueReplacement({
          kind: "replace-value",
          key: id,
          subjectId,
          nextValue: finalUpdated,
          authoredFields: Object.keys(transformedChanges)
        });
      }
      const committed = commitAndProjectEntityMutationFrame(frame);
      for (const { id } of updatedEntities) {
        syncEntitySignal(id);
      }
      updateSignals();
      const subjectIdsForWrite = rememberSubjectIds(ids);
      for (let i = 0; i < updatedEntities.length; i++) {
        const { id, prev, finalUpdated, transformedChanges } = updatedEntities[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          finalUpdated,
          prev,
          basePath,
          [subjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          withEntityValueTransition(
            ambientMeta(),
            committed.valueResultsByStep[i]
          ),
          void 0,
          getActiveWriteContext()?.mutationIntent === "derive" ? void 0 : Object.keys(transformedChanges)
        );
      }
      for (const { id, transformedChanges, finalUpdated } of updatedEntities) {
        emitTap("onUpdate", id, transformedChanges, finalUpdated);
      }
    },
    updateWhere(predicate, changes) {
      const idsToUpdate = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToUpdate.push(id);
        }
      }
      if (idsToUpdate.length > 0) {
        api.updateMany(idsToUpdate, changes);
      }
      return idsToUpdate.length;
    },
    // ==================
    // MUTATIONS: REMOVE
    // ==================
    removeOne(id) {
      const entity = presentEntity(id);
      if (!entity) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      const { beforeSubject, afterSubject } = getNeighborSubjects(id);
      for (const handler of interceptHandlers) {
        const ctx = {
          block: (reason) => {
            throw new Error(
              `Cannot remove entity: ${reason || "blocked by interceptor"}`
            );
          },
          transform: () => {
          },
          blocked: false,
          blockReason: void 0
        };
        assertSynchronousInterceptorResult(
          handler.onRemove?.(id, entity, ctx),
          "onRemove"
        );
      }
      const subjectIdsForWrite = rememberSubjectIds([id]);
      const structuralEffect = {
        kind: "remove",
        subject: subjectIdsForWrite[0],
        key: id,
        value: deepClone(entity),
        beforeSubject,
        afterSubject
      };
      const currentState = resolveSubjectState(subjectIdsForWrite[0]);
      const tombstone = {
        kind: "tombstone-subject",
        key: id,
        subjectId: subjectIdsForWrite[0],
        restoreAllowed: currentState?.restoreAllowed ?? true
      };
      const frame = createEntityMutationFrame();
      frame.stageSubjectTombstone(tombstone);
      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }
      tombstoneSubjectSignal(subjectIdsForWrite[0]);
      reclaimRetiredSubjectsWithoutOwner([subjectIdsForWrite[0]]);
      updateSignals();
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        void 0,
        entity,
        basePath,
        subjectIdsForWrite,
        getPositionIdsForNotify(),
        createStructuralEffectMeta(
          structuralEffect,
          result.ordinaryChanges.get(subjectIdsForWrite[0])
        )
      );
      emitTap("onRemove", id, entity);
    },
    removeMany(ids) {
      if (ids.length === 0) return;
      const preparedRemovals = [];
      for (const id of ids) {
        const entity = presentEntity(id);
        if (!entity) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        const subjectId = resolveSubjectId(id);
        if (subjectId === void 0) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        const { beforeSubject, afterSubject } = getNeighborSubjects(id);
        for (const handler of interceptHandlers) {
          const ctx = {
            block: (reason) => {
              throw new Error(
                `Cannot remove entity: ${reason || "blocked by interceptor"}`
              );
            },
            transform: () => {
            },
            blocked: false,
            blockReason: void 0
          };
          assertSynchronousInterceptorResult(
            handler.onRemove?.(id, entity, ctx),
            "onRemove"
          );
        }
        preparedRemovals.push({
          id,
          entity,
          subjectId,
          beforeSubject,
          afterSubject
        });
      }
      const subjectIdsForWrite = preparedRemovals.map(
        ({ subjectId }) => subjectId
      );
      lastSubjectIds = subjectIdsForWrite;
      const frame = createEntityMutationFrame();
      for (const { id, subjectId } of preparedRemovals) {
        const currentState = resolveSubjectState(subjectId);
        frame.stageSubjectTombstone({
          kind: "tombstone-subject",
          key: id,
          subjectId,
          restoreAllowed: currentState?.restoreAllowed ?? true
        });
      }
      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }
      for (const { subjectId } of preparedRemovals) {
        tombstoneSubjectSignal(subjectId);
      }
      reclaimRetiredSubjectsWithoutOwner(
        preparedRemovals.map(({ subjectId }) => subjectId)
      );
      updateSignals();
      for (let i = 0; i < preparedRemovals.length; i++) {
        const { id, entity, beforeSubject, afterSubject } = preparedRemovals[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          void 0,
          entity,
          basePath,
          [subjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            {
              kind: "remove",
              subject: subjectIdsForWrite[i],
              key: id,
              value: deepClone(entity),
              beforeSubject,
              afterSubject
            },
            result.ordinaryChanges.get(subjectIdsForWrite[i])
          )
        );
      }
      for (const { id, entity } of preparedRemovals) {
        emitTap("onRemove", id, entity);
      }
    },
    removeWhere(predicate) {
      const idsToRemove = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToRemove.push(id);
        }
      }
      if (idsToRemove.length > 0) {
        api.removeMany(idsToRemove);
      }
      return idsToRemove.length;
    },
    // ==================
    // MUTATIONS: UPSERT
    // ==================
    upsertOne(entity, opts) {
      const id = deriveId(entity, opts);
      if (structuralStore.hasActiveKey(id)) {
        api.updateOne(id, entity);
      } else {
        api.addOne(entity, opts);
      }
      return id;
    },
    upsertMany(entities, opts) {
      if (entities.length === 0) return [];
      const lastPreviousKey = structuralStore.lastActiveKey();
      const toAdd = [];
      const toUpdate = [];
      const copies = [];
      const earlier = /* @__PURE__ */ new Map();
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        let row = earlier.get(id);
        if (!row) {
          const prev = getProjectedEntity(id);
          if (prev === void 0) row = { id };
          else {
            const subjectId = resolveSubjectId(id);
            if (subjectId === void 0) {
              throw new Error(`Entity with id ${String(id)} has no subject id`);
            }
            row = { id, prev, entity: prev, subjectId };
          }
          (prev === void 0 ? toAdd : toUpdate).push(row);
          earlier.set(id, row);
        }
        copies.push([row, entity]);
      }
      for (const [row, entity] of copies) {
        if (row.entity === void 0) {
          row.entity = interceptAddedEntity(entity);
        } else {
          const changes = interceptUpdatedEntity(row.id, entity);
          row.changes = { ...row.changes, ...changes };
          row.entity = { ...row.entity, ...changes };
        }
      }
      const stagedAdds = toAdd;
      const stagedUpdates = toUpdate.map(
        ({ id, subjectId, prev, entity, changes }) => ({
          id,
          subjectId,
          prev,
          transformedChanges: changes,
          finalUpdated: entity
        })
      );
      let ordinaryChanges = /* @__PURE__ */ new Map();
      let valueResults = /* @__PURE__ */ new Map();
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      const addedEntities = [];
      try {
        const freshSubjectIds = structuralStore.planFreshSubjectIds(
          stagedAdds.length
        );
        const frame = createEntityMutationFrame();
        for (let i = 0; i < stagedAdds.length; i++)
          frame.stageFreshSubject({
            kind: "create-fresh-subject",
            key: stagedAdds[i].id,
            subjectId: freshSubjectIds[i],
            nextValue: stagedAdds[i].entity
          });
        for (const row of stagedUpdates)
          frame.stageValueReplacement({
            kind: "replace-value",
            key: row.id,
            subjectId: row.subjectId,
            nextValue: row.finalUpdated,
            authoredFields: Object.keys(row.transformedChanges)
          });
        const committed = commitAndProjectEntityMutationFrame(frame);
        valueResults = committed.valueResults;
        ordinaryChanges = committed.ordinaryChanges;
        const addedSubjectIdsByKey = /* @__PURE__ */ new Map();
        for (let i = 0; i < stagedAdds.length; i++) {
          addedSubjectIdsByKey.set(stagedAdds[i].id, freshSubjectIds[i]);
        }
        for (const { entity: transformedEntity, id } of stagedAdds) {
          const subjectId = addedSubjectIdsByKey.get(id);
          if (subjectId === void 0) {
            throw new Error(`Entity with id ${String(id)} has no subject id`);
          }
          invalidateNodeCache(id);
          syncEntitySignal(id);
          addedEntities.push({ id, entity: transformedEntity, subjectId });
        }
      } finally {
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      const updatedEntities = [];
      for (const {
        id,
        subjectId,
        prev,
        finalUpdated,
        transformedChanges
      } of stagedUpdates) {
        syncEntitySignal(id);
        updatedEntities.push({
          id,
          subjectId,
          prev,
          finalUpdated,
          transformedChanges
        });
      }
      updateSignals();
      const addedSubjectIdsForWrite = addedEntities.map(
        ({ subjectId }) => subjectId
      );
      const updatedSubjectIdsForWrite = updatedEntities.map(
        ({ subjectId }) => subjectId
      );
      lastSubjectIds = [
        ...addedSubjectIdsForWrite,
        ...updatedSubjectIdsForWrite
      ];
      let beforeSubject = lastPreviousKey === void 0 ? void 0 : allocateSubjectId(lastPreviousKey);
      for (let i = 0; i < addedEntities.length; i++) {
        const { id, entity } = addedEntities[i];
        const subject = addedSubjectIdsForWrite[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          void 0,
          basePath,
          [subject],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            {
              kind: "add",
              subject,
              key: id,
              value: deepClone(entity),
              beforeSubject
            },
            ordinaryChanges.get(subject)
          )
        );
        beforeSubject = subject;
      }
      for (let i = 0; i < updatedEntities.length; i++) {
        const { id, prev, finalUpdated, transformedChanges } = updatedEntities[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          finalUpdated,
          prev,
          basePath,
          [updatedSubjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          withEntityValueTransition(
            ambientMeta(),
            valueResults.get(updatedSubjectIdsForWrite[i])
          ),
          void 0,
          getActiveWriteContext()?.mutationIntent === "derive" ? void 0 : Object.keys(transformedChanges)
        );
      }
      for (const { id, entity } of addedEntities) {
        emitTap("onAdd", entity, id);
      }
      for (const { id, transformedChanges, finalUpdated } of updatedEntities) {
        emitTap("onUpdate", id, transformedChanges, finalUpdated);
      }
      return [...toAdd.map((a) => a.id), ...toUpdate.map((u) => u.id)];
    },
    // ==================
    // MUTATIONS: CLEAR/RESET
    // ==================
    clear() {
      const activeIds = structuralStore.activeKeysSnapshot();
      const activeSubjects = activeIds.map((id) => {
        const subjectId = resolveSubjectId(id);
        if (subjectId === void 0) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        const entity = getProjectedEntity(id);
        const { beforeSubject, afterSubject } = getNeighborSubjects(id);
        return { id, subjectId, entity, beforeSubject, afterSubject };
      });
      let ordinaryChanges = /* @__PURE__ */ new Map();
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      try {
        const frame = createEntityMutationFrame();
        for (const { id, subjectId } of activeSubjects)
          frame.stageSubjectTombstone({
            kind: "tombstone-subject",
            key: id,
            subjectId,
            restoreAllowed: resolveSubjectState(subjectId)?.restoreAllowed ?? true
          });
        ordinaryChanges = commitAndProjectEntityMutationFrame(frame).ordinaryChanges;
      } finally {
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      for (const { subjectId } of activeSubjects)
        publishSubjectPhysicalChange(subjectId);
      for (const { subjectId } of activeSubjects) {
        tombstoneSubjectSignal(subjectId);
      }
      reclaimRetiredSubjectsWithoutOwner(
        activeSubjects.map(({ subjectId }) => subjectId)
      );
      replaceLocation(activeIdSignal, void 0);
      lastSubjectIds = activeSubjects.map(({ subjectId }) => subjectId);
      updateSignals();
      for (const {
        id,
        subjectId,
        entity,
        beforeSubject,
        afterSubject
      } of activeSubjects) {
        if (!entity) continue;
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          void 0,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            {
              kind: "remove",
              subject: subjectId,
              key: id,
              value: deepClone(entity),
              beforeSubject,
              afterSubject
            },
            ordinaryChanges.get(subjectId)
          )
        );
      }
      for (const { id, entity } of activeSubjects) {
        if (!entity || silentClear) continue;
        emitTap("onRemove", id, entity);
      }
    },
    setAll(entities, opts) {
      const currentKeys = [];
      const currentSubjects = [];
      structuralStore.snapshotActiveOrder(currentKeys, currentSubjects);
      const beforeOrderFrontier = structuralStore.activeOrderFrontier();
      const incomingIndex = /* @__PURE__ */ new Map();
      const incomingIds = [];
      const incomingEntities = [];
      const incomingSubjects = [];
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        const existing = structuralStore.subjectIdForKey(id);
        const transformedEntity = existing !== void 0 ? interceptReplacedEntity(id, entity) : interceptAddedEntity(entity);
        const index = incomingIndex.get(id);
        if (index === void 0) {
          incomingIndex.set(id, incomingIds.length);
          incomingIds.push(id);
          incomingEntities.push(transformedEntity);
          incomingSubjects.push(existing);
          continue;
        }
        incomingEntities[index] = transformedEntity;
      }
      const stagedRemovals = [];
      for (let index = 0; index < currentKeys.length; index += 1) {
        const id = currentKeys[index];
        if (incomingIndex.has(id)) continue;
        const subjectId = currentSubjects[index];
        const entity = valueStore.backingForSubject(subjectId);
        if (entity === void 0) continue;
        for (const handler of interceptHandlers) {
          const ctx = {
            block: (reason) => {
              throw new Error(
                `Cannot remove entity: ${reason || "blocked by interceptor"}`
              );
            },
            transform: () => {
            },
            blocked: false,
            blockReason: void 0
          };
          assertSynchronousInterceptorResult(
            handler.onRemove?.(id, entity, ctx),
            "onRemove"
          );
        }
        stagedRemovals.push({ id, entity, subjectId, index });
      }
      if (structuralStore.activeOrderFrontier() !== beforeOrderFrontier || currentKeys.some(
        (key, index) => structuralStore.subjectIdForKey(key) !== currentSubjects[index]
      )) {
        throw new Error(
          "Cannot setAll: collection topology changed during staging"
        );
      }
      const stagedUpdates = [];
      const stagedAdds = [];
      for (let index = 0; index < incomingIds.length; index += 1) {
        const id = incomingIds[index];
        const entity = incomingEntities[index];
        const subjectId = incomingSubjects[index];
        if (subjectId === void 0) {
          stagedAdds.push({ id, entity, index });
          continue;
        }
        const prev = valueStore.backingForSubject(subjectId);
        if (prev === void 0) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        stagedUpdates.push({ id, prev, entity, subjectId });
      }
      let ordinaryChanges = /* @__PURE__ */ new Map();
      let valueResults = /* @__PURE__ */ new Map();
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      let addedSubjectIds;
      let afterSubjects;
      const stagedRemovalStructuralEffects = [];
      try {
        addedSubjectIds = structuralStore.planFreshSubjectIds(
          stagedAdds.length
        );
        for (let k = 0; k < stagedAdds.length; k += 1) {
          incomingSubjects[stagedAdds[k].index] = addedSubjectIds[k];
        }
        afterSubjects = incomingSubjects;
        for (const { id, entity, subjectId, index } of stagedRemovals) {
          stagedRemovalStructuralEffects.push({
            kind: "remove",
            subject: subjectId,
            key: id,
            value: deepClone(entity),
            beforeSubject: index > 0 ? currentSubjects[index - 1] : void 0,
            afterSubject: currentSubjects[index + 1]
          });
        }
        const frame = createEntityMutationFrame();
        for (const { id, subjectId } of stagedRemovals)
          frame.stageSubjectTombstone({
            kind: "tombstone-subject",
            key: id,
            subjectId,
            restoreAllowed: resolveSubjectState(subjectId)?.restoreAllowed ?? true
          });
        for (const { id, subjectId, entity } of stagedUpdates)
          frame.stageValueReplacement({
            kind: "replace-value",
            key: id,
            subjectId,
            nextValue: entity
          });
        for (let k = 0; k < stagedAdds.length; k++)
          frame.stageFreshSubject({
            kind: "create-fresh-subject",
            key: stagedAdds[k].id,
            subjectId: addedSubjectIds[k],
            nextValue: stagedAdds[k].entity
          });
        frame.stageFinalOrder(incomingIds);
        if (survivingOrderChanged(currentSubjects, afterSubjects))
          frame.ordinaryOrder = afterSubjects;
        const committed = commitAndProjectEntityMutationFrame(frame);
        valueResults = committed.valueResults;
        ordinaryChanges = committed.ordinaryChanges;
        for (const { subjectId } of stagedRemovals)
          tombstoneSubjectSignal(subjectId);
        for (const { id } of stagedAdds) syncEntitySignal(id);
        for (const { id } of stagedUpdates) {
          syncEntitySignal(id);
        }
        lastSubjectIds = [
          ...stagedRemovals.map(({ subjectId }) => subjectId),
          ...stagedUpdates.map(({ subjectId }) => subjectId),
          ...addedSubjectIds
        ];
        if (mutationCaptureRuntime?.isCaptureActive()) getPositionIds();
        if (positionId !== void 0 && mutationCaptureRuntime?.publishCollectionOrder && survivingOrderChanged(currentSubjects, afterSubjects)) {
          publishOrderChange(
            currentSubjects,
            afterSubjects,
            beforeOrderFrontier,
            void 0,
            committed.ordinaryEndpoints
          );
        }
      } finally {
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      for (const { subjectId } of stagedRemovals)
        publishSubjectPhysicalChange(subjectId);
      reclaimRetiredSubjectsWithoutOwner(
        stagedRemovals.map(({ subjectId }) => subjectId)
      );
      const stagedAddStructuralEffects = [];
      for (let k = 0; k < stagedAdds.length; k += 1) {
        const { id, entity, index } = stagedAdds[k];
        stagedAddStructuralEffects.push({
          kind: "add",
          subject: addedSubjectIds[k],
          key: id,
          value: deepClone(entity),
          beforeSubject: index > 0 ? afterSubjects[index - 1] : void 0,
          afterSubject: afterSubjects[index + 1]
        });
      }
      updateSignals();
      for (let index = 0; index < stagedRemovals.length; index += 1) {
        const { id, entity, subjectId } = stagedRemovals[index];
        const structuralEffect = stagedRemovalStructuralEffects[index];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          void 0,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            structuralEffect,
            ordinaryChanges.get(structuralEffect.subject)
          )
        );
      }
      for (const { id, prev, entity, subjectId } of stagedUpdates) {
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          prev,
          basePath,
          subjectId === void 0 ? void 0 : [subjectId],
          getPositionIdsForNotify(),
          withEntityValueTransition(ambientMeta(), valueResults.get(subjectId)),
          void 0,
          getActiveWriteContext()?.mutationIntent === "derive" ? void 0 : null
        );
      }
      for (let i = 0; i < stagedAdds.length; i++) {
        const { id, entity } = stagedAdds[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          void 0,
          basePath,
          [addedSubjectIds[i]],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            stagedAddStructuralEffects[i],
            ordinaryChanges.get(stagedAddStructuralEffects[i].subject)
          )
        );
      }
      for (const { id, entity } of stagedRemovals) {
        emitTap("onRemove", id, entity);
      }
      for (const { id, entity } of stagedAdds) {
        emitTap("onAdd", entity, id);
      }
      for (const { id, entity } of stagedUpdates) {
        emitTap("onUpdate", id, entity, entity);
      }
    },
    // ==================
    // HOOKS
    // ==================
    tap(handlers) {
      tapHandlers.push(handlers);
      return () => {
        const idx = tapHandlers.indexOf(handlers);
        if (idx > -1) tapHandlers.splice(idx, 1);
      };
    },
    intercept(handlers) {
      assertSynchronousInterceptors(handlers);
      interceptHandlers.push(handlers);
      return () => {
        const idx = interceptHandlers.indexOf(handlers);
        if (idx > -1) interceptHandlers.splice(idx, 1);
      };
    }
  };
  if (subjectMetadataEnabled) {
    Object.defineProperty(api, "__subjectIds", {
      get: () => lastSubjectIds,
      enumerable: false,
      configurable: true
    });
  }
  Object.defineProperty(api, "__positionIds", {
    get: getPositionIds,
    enumerable: false,
    configurable: true
  });
  defineOwnedOwnerPath(api, basePath);
  const clearRetained = api.clear;
  const interceptAsEmpty = (name, args) => {
    const opts = args[1];
    const many = name.endsWith("Many") || name === "setAll";
    const input = many ? args[0] : [args[0]];
    const upsert = name.startsWith("upsert");
    const mode = name === "addMany" || name === "prependMany" ? opts?.mode ?? "strict" : "overwrite";
    const copies = [];
    const firsts = /* @__PURE__ */ new Set();
    for (const row of input) {
      const id = deriveId(row, opts);
      if (firsts.has(id)) {
        if (mode === "strict")
          throw new Error(`Entity with id ${String(id)} already exists`);
        if (mode === "skip") continue;
      }
      firsts.add(id);
      copies.push([id, row]);
    }
    const rows = /* @__PURE__ */ new Map();
    for (const [id, row] of copies) {
      const running = rows.get(id);
      rows.set(
        id,
        upsert && running !== void 0 ? { ...running, ...interceptUpdatedEntity(id, row) } : interceptAddedEntity(row)
      );
    }
    const keys = /* @__PURE__ */ new Map();
    const out = [];
    for (const [id, row] of rows) {
      const own = keys.has(row) ? { ...row } : row;
      keys.set(own, id);
      out.push(own);
    }
    const resolved = {
      ...opts,
      selectId: (row) => keys.get(row) ?? deriveId(row, opts)
    };
    return [many ? out : out[0], resolved];
  };
  for (const name of [
    "addOne",
    "prependOne",
    "addMany",
    "prependMany",
    "upsertOne",
    "upsertMany",
    "setAll",
    "clear"
  ]) {
    const write = api[name];
    api[name] = (...args) => {
      if (reAdding || !absent() || inStructuralWrite(proxy))
        return write(...args);
      const prepared = name === "clear" ? [] : interceptAsEmpty(name, args);
      const writePrepared = () => {
        interceptsSuppressed++;
        try {
          return write(...prepared);
        } finally {
          interceptsSuppressed--;
        }
      };
      if (!absent() || name !== "setAll" && Array.isArray(prepared[0]) && !prepared[0].length)
        return writePrepared();
      reAdding = pendingReAdd = true;
      try {
        silentClear++;
        try {
          clearRetained();
        } finally {
          silentClear--;
        }
        const result = writePrepared();
        if (pendingReAdd) {
          pendingReAdd = false;
          reactivatePathOnWrite(api);
        }
        return result;
      } finally {
        reAdding = pendingReAdd = false;
      }
    };
  }
  const wake = () => locations.runInvalidationGroup(() => {
    for (const epoch of subjectEpochs.values()) advanceEpochHandle(epoch);
    deriveLocation(version, (value) => value + 1);
    markOwnerInvalidated(ownerId);
  });
  let wakeQueued = false;
  Object.defineProperty(api, MEMBERSHIP_CHANGED, {
    value: () => {
      if (!structuralWrites.depth) return wake();
      if (wakeQueued) return;
      wakeQueued = true;
      const earlier = structuralWrites.end;
      structuralWrites.end = (failed) => {
        structuralWrites.end = void 0;
        wakeQueued = false;
        let caught;
        for (const run of [() => earlier?.(failed), wake]) {
          try {
            run();
          } catch (error2) {
            caught ??= { error: error2 };
          }
        }
        if (!caught) return;
        if (!failed) throw caught.error;
        const { error } = caught;
        queueMicrotask(() => {
          throw error;
        });
      };
    }
  });
  defineEntityMembershipSource(api, (tap) => {
    membershipTap = tap;
    return structuralStore;
  });
  defineEntityProjectionSeed(api, () => {
    const seed = [];
    for (const key of absent() ? [] : structuralStore.activeKeysSnapshot()) {
      const subjectId = structuralStore.subjectIdForKey(key);
      if (subjectId === void 0) continue;
      const row = getProjectedEntity(key);
      if (row === void 0) continue;
      seed.push({ subjectId, key, row });
    }
    return seed;
  });
  Object.defineProperty(api, "__findKeyBySubjectId", {
    value: findKeyBySubjectId,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__prepareOrdinaryRealization", {
    value: prepareOrdinaryRealization,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__preparePointValues", {
    value: preparePointValues,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planFreshAdd", {
    value: planFreshAdd,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__restoreOne", {
    value: restoreOne,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planRekey", {
    value: planRekey,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planPreparedRekey", {
    value: planPreparedRekey,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planRemove", {
    value: planRemove,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planRestore", {
    value: planRestore,
    enumerable: false,
    configurable: true
  });
  if (positionId !== void 0) {
    Object.defineProperty(api, "__prepareTransitionTarget", {
      value: {
        owner: positionId,
        ownerPath: basePath,
        readSource: readTransitionSource,
        readOrderFrontier: () => structuralStore.activeOrderFrontier(),
        installCompensatedOrderFrontier: (frontier) => structuralStore.installCompensatedOrderFrontier(frontier),
        prepareTarget: (target, prepare) => prepare(
          {
            positionId,
            structuralStore,
            valueStore,
            ordinaryTopology,
            prepareOrdinaryRealization,
            activeIdSignal,
            subjectEpochs,
            subjectStateSignals,
            get membershipTap() {
              return membershipTap;
            },
            advanceEpochHandle,
            updateSignals,
            physicalCommitClock,
            pathNotifier,
            basePath,
            getPositionIdsForNotify,
            createStructuralEffectMeta,
            ambientMeta,
            emitTap,
            publishOrderChange(before, after, beforeFrontier, afterFrontier, ordinaryEndpoints, selectedDisposition) {
              if (survivingOrderChanged(before, after) || ordinaryEndpoints !== void 0)
                publishOrderChange(
                  before,
                  after,
                  beforeFrontier,
                  afterFrontier,
                  ordinaryEndpoints,
                  selectedDisposition
                );
            }
          },
          target
        )
      },
      enumerable: false,
      configurable: true
    });
  }
  Object.defineProperty(api, "__inspectSubjectResources", {
    value: inspectSubjectResources,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__listSubjectReclamationCandidates", {
    value: listSubjectReclamationCandidates,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__acquireEntityHandleForTesting", {
    value: acquireEntityHandleForTesting,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__resolveEntityHandleForTesting", {
    value: resolveEntityHandleForTesting,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__rebuildActiveProjectionFromOwnersForTesting", {
    value: rebuildActiveProjectionFromOwners,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planSubjectReclamation", {
    value: (subjectId, options2) => {
      const inventory = inspectSubjectResources(subjectId);
      return inventory ? planEntitySubjectReclamation(inventory, options2) : void 0;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__prepareSubjectReclamation", {
    value: prepareSubjectReclamation,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__applyPreparedSubjectReclamation", {
    value: applyPreparedSubjectReclamation,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__retireSubjectRetainedValueBackingForTesting", {
    value: retireSubjectRetainedValueBackingForTesting,
    enumerable: false,
    configurable: true
  });
  const warnedWrongMethods = /* @__PURE__ */ new Set();
  const proxy = new Proxy(api, {
    get: (target, prop) => {
      if (typeof prop === "string" && !isNaN(Number(prop))) {
        return api.byId(Number(prop));
      }
      if (typeof prop === "string" && !(prop in target) && WRONG_ENTITY_METHODS[prop] && (typeof ngDevMode === "undefined" || ngDevMode) && !warnedWrongMethods.has(prop)) {
        warnedWrongMethods.add(prop);
        console.warn(
          `SignalTree entityMap has no \`.${prop}()\`. Did you mean: ${WRONG_ENTITY_METHODS[prop]}? [ST2002]`
        );
      }
      return target[prop];
    }
  });
  return proxy;
}
Object.defineProperty(
  createEntitySignal,
  "__setPositionIdAllocatorForTesting",
  {
    value: setEntityPositionIdAllocatorForTesting,
    enumerable: false,
    configurable: true
  }
);
Object.defineProperty(
  createEntitySignal,
  "__setPositionIdNotifyEnabledForTesting",
  {
    value: setEntityPositionIdNotifyEnabledForTesting,
    enumerable: false,
    configurable: true
  }
);

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/markers/entity-map.ts
var ENTITY_SLICE_RESERVED_NAMES = "byId|byIdOrFail|all|count|ids|has|empty|asMap|where|find|activeId|activeEntity|setActiveId|clearActiveId|addOne|addMany|prependOne|prependMany|changeId|updateOne|replaceOne|updateMany|updateWhere|upsertOne|upsertMany|removeOne|removeMany|removeWhere|clear|setAll|tap|intercept".split(
  "|"
);
function entityMap(config) {
  registerEntityMapProcessor();
  const slices = {};
  const combined = {
    __isEntityMap: true,
    __entityMapConfig: config ?? {},
    __computedSlices: slices,
    computed(name, compute) {
      if (ENTITY_SLICE_RESERVED_NAMES.includes(name)) {
        throw new TypeError(`SignalTree: reserved entityMap slice "${name}".`);
      }
      slices[name] = { compute };
      return combined;
    },
    build() {
      return combined;
    }
  };
  return combined;
}
function registerEntityMapProcessor() {
  registerBuiltinMarkerProcessor(
    isEntityMapMarker,
    (marker, notifier, path, context, parentPositionId) => {
      const cfg = marker.__entityMapConfig ?? {};
      const hasPositionTopology = context.hasCapability("position-topology");
      const hasMutationCapture = context.hasCapability("mutation-capture");
      const entitySignal = createEntitySignal(
        cfg,
        notifier,
        path,
        {
          physicalCommitClock: context.physicalCommitClock,
          mutationCaptureRuntime: context.mutationCaptureRuntime,
          // ADDRESS-REPAIR-1. The collection's own position is allocated
          // here, and `path` IS its canonical address — both facts are known
          // at exactly this point and nowhere later. Registering them makes
          // every downstream consumer able to ASK which collection owns a
          // position instead of guessing from a path's dot shape, which
          // REALIZATION-ADDRESS-0 measured wrong for every nested case.
          positionIdAllocator: hasPositionTopology ? () => {
            const positionId = context.allocatePositionId(parentPositionId);
            if (positionId !== void 0) {
              context.positionRegistry.registerCollectionPath(
                positionId,
                path
              );
            }
            return positionId;
          } : () => void 0,
          ownerMetadataEnabled: hasMutationCapture,
          subjectMetadataEnabled: hasMutationCapture,
          positionMetadataEnabled: hasPositionTopology,
          ownerId: context.positionRegistry.id,
          locationRuntime: context.locationRuntime,
          // Immutable for the life of the tree — see RuntimeTreePlan. False
          // is what lets the retirement boundary release a retired subject's
          // value backing immediately.
          hasRestorationAuthority: context.runtimeTreePlan.hasRestorationAuthority
        }
      );
      definePositionRegistry(
        entitySignal,
        context.positionRegistry
      );
      Object.defineProperty(entitySignal, MUTATION_CAPTURE_RUNTIME, {
        value: context.mutationCaptureRuntime
      });
      if (context.runtimeTreePlan.hasRestorationAuthority) {
        context.physicalOwners.push(
          entitySignal
        );
      }
      const slices = marker.__computedSlices;
      if (slices) {
        for (const [name, sliceConfig] of Object.entries(slices)) {
          const computedSignal = context.locationRuntime.createDerived(
            () => sliceConfig.compute(entitySignal.all())
          );
          entitySignal[name] = computedSignal;
        }
      }
      return entitySignal;
    },
    {
      // STATE: the entities. `ids`, `count`, `empty` and `map` are all
      // derived from `all` — and `map` is a JS `Map`, which JSON cannot
      // represent, so it used to serialise as `{}`: a snapshot claiming the
      // collection was EMPTY while holding 10,000 entities.
      snapshot: (node) => ({ all: node.all() }),
      hydrate: (node, value) => {
        if (value === null || typeof value !== "object") return;
        const all = Array.isArray(value) ? value : value.all;
        if (Array.isArray(all)) {
          const incoming = all;
          const current = node.all();
          let diffed = false;
          if (current.length === incoming.length) {
            const changed = [];
            for (let i = 0; i < incoming.length; i++) {
              if (current[i] !== incoming[i]) changed.push(incoming[i]);
            }
            if (changed.length < incoming.length) {
              for (const entity of changed) node.upsertOne(entity);
              const updated = node.all();
              diffed = updated.length === incoming.length && updated.every((entity, index) => entity === incoming[index]);
            }
          }
          if (!diffed) node.setAll(incoming);
        } else if (typeof ngDevMode === "undefined" || ngDevMode) {
          console.warn(
            `SignalTree: entityMap hydrate ignored a payload with no \`all\` array. The collection was left unchanged. This is a PAYLOAD problem, not a registration one \u2014 a pre-2.0.0 snapshot emitted \`map\`, which JSON renders as \`{}\`, so the entities were never in it. [ST2024]`
          );
        }
      }
    }
  );
}

// ../../../../private/tmp/entity-marker-retention/candidate/packages/kernel/src/lib/signal-tree.ts
var isWritableCell = (v) => typeof v === "function" && "set" in v && typeof v.set === "function";
var readWritableCell = (cell) => "peek" in cell && typeof cell.peek === "function" ? cell.peek() : cell();
var ENTITY_ARRAY_MIN_LENGTH = 32;
var ENTITY_ARRAY_SAMPLE = 64;
var ENTITY_ID_KEYS = ["id", "_id", "uuid", "key"];
var ENTITY_ARRAY_WARNED = /* @__PURE__ */ new Set();
var ENTITY_ARRAY_WARN_CAP = 256;
var NODE_ACCESSOR_PEER2 = Symbol.for("SignalTree:NodeAccessorPeer");
function createTreeBuildPlan(requestedCapabilities, leafMetadataStorage) {
  const resolved = resolveTreeCapabilities(requestedCapabilities);
  return {
    requestedCapabilities: resolved.requestedCapabilities,
    capabilities: resolved.resolvedCapabilities,
    has(capability) {
      return resolved.resolvedCapabilities.includes(capability);
    },
    leafMetadataStorage
  };
}
function finalizeLeafSignal(leaf2, path, positionIds, buildPlan, captureRuntime, registry, address) {
  defineNodeAddress(leaf2, address);
  for (const position of positionIds ?? [])
    registry?.registerPositionAddress(position, address);
  if (buildPlan.has("position-topology") && registry) {
    definePositionRegistry(leaf2, registry);
  }
  if (buildPlan.has("mutation-capture")) {
    wrapOwnedWritableSignal(leaf2, {
      path,
      // `ownerPath: path` sat here until 15.0 (ME-B). The owner-address fact is
      // still installed on the leaf — it is now derived from `path` inside
      // owned-mutation rather than passed as a second, identical argument.
      positionIds,
      ownerId: registry?.id,
      metadataStorage: buildPlan.leafMetadataStorage,
      captureRuntime
    });
    return;
  }
  if (buildPlan.has("position-topology")) {
    defineOwnedPositionIds(leaf2, positionIds);
    defineOwnedOwnerId(leaf2, registry?.id);
  }
  if (registry) {
    definePositionRegistry(leaf2, registry);
    defineOwnedOwnerPath(leaf2, path);
    installDormantObservation(leaf2);
  }
}
function getEnhancerMeta(enhancer) {
  return enhancer[ENHANCER_META] ?? enhancer.metadata;
}
function buildTreePlan(enhancers, explicitCapabilities = []) {
  const requestedCapabilities = collectRequestedTreeCapabilities([
    ...enhancers.map((enhancer) => getEnhancerMeta(enhancer)),
    // An explicit request is treated as one more declaration, so it goes
    // through the same dependency resolution rather than bypassing it.
    { capabilities: [...explicitCapabilities] }
  ]);
  return createTreeBuildPlan(requestedCapabilities, "property");
}
function materializeTreeMarkers(tree, materializationContext, authority) {
  materializeMarkers(tree.$, void 0, [], materializationContext, authority);
  _recordTreeConstruction();
}
function isEntityMapMarker2(value) {
  return Boolean(
    value && typeof value === "object" && value["__isEntityMap"] === true
  );
}
function createEqualityFn(useShallowComparison) {
  return useShallowComparison ? Object.is : deepEqual;
}
function makeNodeAccessor(store, ownerPath, positionIds, registry, locations) {
  const isRoot = ownerPath === "";
  const self = {};
  const applyGrouped = (run) => {
    if (locations) locations.runInvalidationGroup(run);
    else run();
  };
  const accessor = {
    node(arg) {
      if (arguments.length === 0) {
        if (!isRoot && self.accessor !== void 0 && isAbsentMember(self.accessor)) {
          observeMembership(store);
          return void 0;
        }
        return materializeNode(store);
      }
      const absent = !isRoot && isAbsentMember(self.accessor);
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = absent ? void 0 : unwrap(store);
        updates = updater(current);
      }
      applyGrouped(() => {
        recursiveUpdate(store, updates, void 0, "");
        if (absent && updates && typeof updates === "object")
          reactivatePathOnWrite(self.accessor);
      });
    }
  }.node;
  self.accessor = accessor;
  accessor[CALLABLE_SIGNAL_SYMBOL] = true;
  Object.defineProperty(accessor, NODE_STORE_SYMBOL, {
    value: store,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(store, NODE_ACCESSOR_PEER2, {
    value: accessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  for (const key of Object.keys(store)) {
    Object.defineProperty(accessor, key, {
      value: store[key],
      enumerable: true,
      writable: true,
      configurable: true
    });
  }
  const address = getNodeAddress(store);
  if (address) defineNodeAddress(accessor, address);
  if (positionIds && positionIds.length > 0) {
    defineOwnedPositionIds(accessor, positionIds);
  }
  if (ownerPath !== void 0) {
    defineOwnedOwnerPath(accessor, ownerPath);
  }
  if (registry) {
    definePositionRegistry(accessor, registry);
    defineOwnedOwnerId(accessor, registry.id);
    definePositionRegistry(store, registry);
    defineOwnedOwnerId(store, registry.id);
  }
  if (locations) {
    bindLocationRuntime(accessor, locations);
    bindLocationRuntime(store, locations);
  }
  return accessor;
}
var MARKER_IN_ARRAY_WARNED = /* @__PURE__ */ new Set();
var looksLikeMarker = (item) => item !== null && typeof item === "object" && (isEntityMapMarker2(item) || isRegisteredMarker(item));
function warnMarkerInContainer(key, value) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (MARKER_IN_ARRAY_WARNED.has(key)) return;
  let where;
  let container;
  if (Array.isArray(value)) {
    const limit = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
    for (let i = 0; i < limit; i++) {
      if (looksLikeMarker(value[i])) {
        where = `"${key}[${i}]"`;
        container = "an array. Array elements";
        break;
      }
    }
  } else if (value instanceof Map) {
    let i = 0;
    for (const [k, v] of value) {
      if (i++ >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(v)) {
        where = `"${key}" -> Map value at key ${JSON.stringify(String(k))}`;
        container = "a Map. Map values";
        break;
      }
    }
  } else if (value instanceof Set) {
    let i = 0;
    for (const member of value) {
      if (i >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(member)) {
        where = `"${key}" -> Set member #${i}`;
        container = "a Set. Set members";
        break;
      }
      i++;
    }
  }
  if (where === void 0 || container === void 0) return;
  MARKER_IN_ARRAY_WARNED.add(key);
  console.warn(
    `SignalTree: ${where} holds a MARKER inside ${container} are never traversed, so the marker is never materialised \u2014 it stays a raw object, it is not a signal, and writes to it are lost. Markers belong at object positions; for a keyed collection use entityMap({ selectId }). [ST2021]`
  );
}
function warnEntityArrayLeaf(key, value) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (value.length < ENTITY_ARRAY_MIN_LENGTH) return;
  const first = value[0];
  if (first === null || typeof first !== "object" || Array.isArray(first)) {
    return;
  }
  const idKey = ENTITY_ID_KEYS.find((candidate) => {
    const v = first[candidate];
    return typeof v === "string" || typeof v === "number";
  });
  if (!idKey) return;
  const sampleSize = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
  const seen = /* @__PURE__ */ new Set();
  for (let i = 0; i < sampleSize; i++) {
    const item = value[i];
    if (item === null || typeof item !== "object" || Array.isArray(item)) {
      return;
    }
    const id = item[idKey];
    if (typeof id !== "string" && typeof id !== "number") return;
    if (seen.has(id)) return;
    seen.add(id);
  }
  const seenKey = `${key}:${idKey}`;
  if (ENTITY_ARRAY_WARNED.has(seenKey)) return;
  if (ENTITY_ARRAY_WARNED.size >= ENTITY_ARRAY_WARN_CAP) return;
  ENTITY_ARRAY_WARNED.add(seenKey);
  console.warn(
    `SignalTree: "${key}" holds ${value.length} objects with a stable "${idKey}" \u2014 use entityMap({ selectId: (e) => e.${idKey} }). An array leaf rebuilds and re-compares the whole array on every update \u2014 two orders of magnitude at 50k. Read-only or replaced wholesale? Leave it plain; otherwise model it as an entityMap. [ST2018]`
  );
}
function warnDiscardedBranchWrite(path, value) {
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    console.error(
      `SignalTree: write to "${path}" DISCARDED \u2014 a branch cannot be replaced by a non-object value (received ${value === null ? "null" : typeof value}). Write the leaves, or use a marker if this position should hold a value. [ST2014]`
    );
  }
}
function warnMissingForward(method) {
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    console.error(
      `SignalTree: "${method}" could not be forwarded \u2014 an enhancer in the configured set returned a tree without it, so this call did NOTHING. An enhancer that builds a new tree object must copy own property DESCRIPTORS, not Object.assign, which skips non-enumerable methods. [ST2017]`
    );
  }
}
var warnedNoopPaths = /* @__PURE__ */ new Set();
var warnedNoopCopyPaths = /* @__PURE__ */ new Set();
function isLargeEnoughToMatter(value) {
  if (Array.isArray(value)) return value.length >= 32;
  if (value instanceof Map || value instanceof Set) return value.size >= 32;
  return Object.keys(value).length >= 32;
}
setMemberValueApplier(
  (parent, key, member, value) => {
    if (typeof member === "function") {
      member(value);
    }
    const woke = setMemberPresence(parent, key, "active");
    if (woke) publishMembershipChange(parent);
  }
);
var ordinaryMemberBuilders = /* @__PURE__ */ new WeakMap();
function ordinaryConstructionValue(value, key) {
  if (isEntityMapMarker2(value) || isRegisteredMarker(value)) {
    throw new TypeError("SignalTree: marker definitions belong in initial state, not ordinary whole-value writes.");
  }
  if (isLeafDefinition(value)) {
    const inner = leafDefinitionValue(value);
    if (isEntityMapMarker2(inner) || isRegisteredMarker(inner)) {
      throw new TypeError("SignalTree: leaf() cannot wrap a semantic marker.");
    }
    return leaf(inner);
  }
  if (value === null || typeof value !== "object") return leaf(value);
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    if (!Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
      console.warn(
        `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
      );
    }
  }
  if (Array.isArray(value) || isBuiltInObject(value)) {
    warnMarkerInContainer(key, value);
    if (Array.isArray(value)) warnEntityArrayLeaf(key, value);
    return leaf(value);
  }
  const prepared = {};
  for (const [childKey, child] of Object.entries(value)) {
    if (childKey !== "__proto__") prepared[childKey] = ordinaryConstructionValue(child, childKey);
  }
  return prepared;
}
function prepareOrdinaryMembers(target, updates, whole) {
  const plans = /* @__PURE__ */ new Map();
  const visit = (target2, updates2, whole2) => {
    if (!updates2 || typeof updates2 !== "object") return;
    const store = isNodeAccessor(target2) ? target2[NODE_STORE_SYMBOL] : target2;
    const entries = Object.entries(updates2);
    const additions = /* @__PURE__ */ new Map();
    plans.set(store, { entries, additions });
    const build = whole2 ? ordinaryMemberBuilders.get(store) : void 0;
    for (const [key, value] of entries) {
      if (key === "__proto__") continue;
      if (build && !Object.prototype.hasOwnProperty.call(store, key)) {
        const prepared = ordinaryConstructionValue(value, key);
        additions.set(key, () => build(key, prepared));
      } else if (isNodeAccessor(store[key]) && value && typeof value === "object") {
        visit(store[key], value, true);
      }
    }
  };
  visit(target, updates, whole);
  return plans;
}
function recursiveUpdate(target, updates, out, pathPrefix = "", reconcileMembership = true, since = ++structuralWrites.stamp, prepared = prepareOrdinaryMembers(target, updates, reconcileMembership)) {
  if (!updates || typeof updates !== "object") return;
  beginStructuralWrite();
  let publishMembership;
  let applicationFailed = false;
  let applicationError;
  try {
    const targetObj = isNodeAccessor(target) ? target[NODE_STORE_SYMBOL] : target;
    const plan = prepared.get(targetObj);
    if (!plan) return;
    const { entries, additions } = plan;
    const branch = targetObj[NODE_ACCESSOR_PEER2] ?? targetObj;
    const dormant = hasDormantMembers(targetObj);
    publishMembership = reconcileMembership || dormant ? captureBranchMembershipIfObserved(
      targetObj[NODE_ACCESSOR_PEER2] ?? targetObj,
      updates,
      !reconcileMembership
    ) : void 0;
    const installed = dormant ? /* @__PURE__ */ new Set() : void 0;
    for (const [key, rawValue] of entries) {
      let value = rawValue;
      if (key === "__proto__") continue;
      const buildAddition = additions.get(key);
      if (buildAddition && !Object.prototype.hasOwnProperty.call(targetObj, key)) {
        const { child, responsibility } = buildAddition();
        inheritObservationForAddedMember(branch, child);
        installPreparedMember(branch, key, child, responsibility);
        publishMembershipChange(branch);
        installed?.add(key);
        out?.push(pathPrefix ? `${pathPrefix}.${key}` : key);
        continue;
      }
      const prop = Object.getOwnPropertyDescriptor(targetObj, key)?.value;
      const childPath = pathPrefix ? `${pathPrefix}.${key}` : key;
      if (prop === void 0) {
        if (typeof ngDevMode === "undefined" || ngDevMode) {
          console.error(
            `SignalTree: write to "${childPath}" DISCARDED \u2014 key is not in the tree's initial shape. [ST2010]`
          );
        }
        continue;
      }
      const ownHydrate = structuralWrites.own;
      structuralWrites.own = prop;
      let hydrated;
      try {
        hydrated = hydrateMarkerNode(prop, value, "restore");
      } finally {
        structuralWrites.own = ownHydrate;
      }
      if (hydrated) {
        if (out) out.push(childPath);
        installed?.add(key);
        continue;
      }
      if (isNodeAccessor(prop)) {
        if (typeof value === "function") {
          const updater = value;
          value = updater(isAbsentMember(prop) ? void 0 : unwrap(prop));
          const mergeable = isTraversableNode(value) && typeof value !== "function" && !isBuiltInObject(value) && !Array.isArray(value) && typeof value.then !== "function";
          if (!mergeable) {
            warnDiscardedBranchWrite(childPath, value);
            continue;
          }
        }
        if (typeof value === "function") {
          warnDiscardedBranchWrite(childPath, value);
        } else if (value && typeof value === "object") {
          recursiveUpdate(
            prop,
            value,
            out,
            childPath,
            true,
            since,
            prepared.has(
              prop[NODE_STORE_SYMBOL]
            ) ? prepared : prepareOrdinaryMembers(prop, value, true)
          );
          installed?.add(key);
        } else if (value === void 0) {
          continue;
        } else {
          warnDiscardedBranchWrite(childPath, value);
        }
      } else if (isWritableLocation(prop) || isWritableCell(prop)) {
        const sig = prop;
        const current = readWritableCell(sig);
        if (current === value && !isAbsentMember(sig) && !needsLocationAuthorityAdmission(sig)) {
          if ((typeof ngDevMode === "undefined" || ngDevMode) && value !== null && typeof value === "object" && !warnedNoopPaths.has(childPath)) {
            warnedNoopPaths.add(childPath);
            console.warn(
              `SignalTree: write at "${childPath}" was skipped \u2014 the value is reference-identical to the current value. If you mutated an object/array in place, create a NEW reference (spread/slice/map) so the change is observed. [ST2003]`
            );
          }
          continue;
        }
        const wasAbsent = out !== void 0 && isAbsentMember(sig);
        const ownWrite = structuralWrites.own;
        structuralWrites.own = sig;
        try {
          if (isWritableLocation(sig)) replaceLocation(sig, value);
          else sig.set(value);
        } finally {
          structuralWrites.own = ownWrite;
        }
        installed?.add(key);
        if (out) {
          if (wasAbsent || !Object.is(readWritableCell(sig), current))
            out.push(childPath);
        }
      }
    }
    const membershipChanged = [];
    const supplied = reconcileMembership || installed ? new Set(Object.keys(updates)) : void 0;
    if (supplied)
      for (const key of reconcileMembership ? Object.getOwnPropertyNames(targetObj) : supplied) {
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("membershipKeysVisited");
        }
        const descriptor = Object.getOwnPropertyDescriptor(targetObj, key);
        if (!descriptor || !("value" in descriptor)) continue;
        if (!supplied.has(key)) {
          if (descriptor.enumerable && // A write made while this whole value ran re-added it: it stays.
          !readdedDuringStructuralWrite(targetObj, key, since) && setMemberPresence(targetObj, key, "dormant")) {
            membershipChanged.push(key);
          }
        } else if (
          // Only a member whose supplied value was installed is re-added: a key
          // supplied as `undefined`, or with a value the loop discarded, would
          // otherwise come back with its retained storage. Measured before v16 8d:
          // `$({ a: undefined, count: 0 })` re-added an omitted `a` as `{ v: 1 }`.
          // "DORMANT STORAGE MUST NOT SUPPLY THE REACTIVATED VALUE" (case 18).
          !descriptor.enumerable && installed?.has(key) && setMemberPresence(targetObj, key, "active")
        ) {
          membershipChanged.push(key);
        }
      }
    if (membershipChanged.length > 0) {
      republishMembers(targetObj, membershipChanged);
    }
  } catch (error) {
    applicationFailed = true;
    applicationError = error;
  } finally {
    try {
      try {
        publishMembership?.();
      } catch (error) {
        if (!applicationFailed) {
          applicationFailed = true;
          applicationError = error;
        } else {
          reportContainedObserverError({ error, operation: "notify:subscriber" });
        }
      }
    } finally {
      endStructuralWrite();
    }
  }
  if (applicationFailed) throw applicationError;
}
function leafEqual(base, path) {
  return (a, b) => {
    const eq = base(a, b);
    if (eq && a !== b && a !== null && typeof a === "object" && isLargeEnoughToMatter(a) && !warnedNoopCopyPaths.has(path)) {
      warnedNoopCopyPaths.add(path);
      console.warn(
        `SignalTree: a write to "${path || "(root leaf)"}" changed NOTHING \u2014 the new value is a different object but deep-equals the current one, so the whole structure was compared and the write discarded. A re-fetched payload does this. Skip the write when the data is unchanged, or write the smaller changed leaf. [ST2027]`
      );
    }
    return eq;
  };
}
function materializeOrdinaryBranch(value, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, childPositionIds, childPath, address, preparedOrdinary = false) {
  const nested = createSignalStore(
    value,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    childPositionIds,
    childPath,
    address,
    preparedOrdinary
  );
  const accessor = makeNodeAccessor(
    nested,
    childPath,
    childPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(accessor, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(nested, scalarSlotRuntime);
  }
  return accessor;
}
function createSignalStore(obj, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, positionIds, path = "", address = [], preparedOrdinary = false) {
  for (const position of positionIds ?? []) {
    materializationContext.positionRegistry.registerPositionAddress(
      position,
      address
    );
  }
  const createLeafSignal = (value, leafPositionIds, equal) => {
    if (scalarSlotRuntime) {
      return scalarSlotRuntime.createLeaf(
        value,
        equal,
        leafPositionIds?.[0]
      );
    }
    return materializationContext.locationRuntime.createCell(value, equal);
  };
  if (obj === null || obj === void 0 || typeof obj !== "object") {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (Array.isArray(obj)) {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (isBuiltInObject(obj)) {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  const store = {};
  defineNodeAddress(store, address);
  ordinaryMemberBuilders.set(store, (key, value) => {
    const prepared = createSignalStore(
      { [key]: value },
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      positionIds,
      path,
      address,
      true
    );
    const child = prepared[key];
    const branch = store[NODE_ACCESSOR_PEER2] ?? store;
    return { child, responsibility: captureRuntime.prepareMemberResponsibility?.(branch, key, child) };
  });
  for (const [key, definedValue] of Object.entries(
    obj
  )) {
    const childAddress = childAddressOf(address, key);
    const childPath = path ? `${path}.${key}` : key;
    const terminal = isLeafDefinition(definedValue);
    const value = terminal ? leafDefinitionValue(definedValue) : definedValue;
    if (!preparedOrdinary && terminal && (isEntityMapMarker2(value) || isRegisteredMarker(value))) {
      throw new Error(
        `SignalTree: leaf() cannot wrap a semantic marker at "${childPath}".`
      );
    }
    let childPositionIds;
    const getChildPositionIds = () => {
      if (!materializationContext.positionTopologyEnabled) {
        return void 0;
      }
      return childPositionIds ??= [
        materializationContext.allocatePositionId(positionIds?.[0])
      ];
    };
    if (key === "__proto__") {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        console.error(
          `SignalTree: dropped a "__proto__" key from the initial state \u2014 it cannot be a state key. If this came from JSON.parse, the payload is attempting prototype pollution. [ST2016]`
        );
      }
      continue;
    }
    if (!preparedOrdinary && isEntityMapMarker2(value)) {
      store[key] = value;
      continue;
    }
    if (!preparedOrdinary && isRegisteredMarker(value)) {
      store[key] = value;
      continue;
    }
    if (typeof ngDevMode === "undefined" || ngDevMode) {
      if (!preparedOrdinary && !terminal && value !== null && typeof value === "object" && !Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
        console.warn(
          `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
        );
      }
    }
    if (terminal || value === null || value === void 0 || typeof value !== "object") {
      const childPositionIds2 = getChildPositionIds();
      const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    if (Array.isArray(value) || isBuiltInObject(value)) {
      warnMarkerInContainer(key, value);
      if (Array.isArray(value)) {
        warnEntityArrayLeaf(key, value);
      }
      const childPositionIds2 = getChildPositionIds();
      const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    store[key] = materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      getChildPositionIds(),
      childPath,
      childAddress,
      preparedOrdinary
    );
  }
  markTreeStore(store);
  return store;
}
function create(initialState, config, materializationContext, buildPlan, captureRuntime = createMutationCaptureRuntime(), createScalarLeafRuntime = createTreeScalarLeafRuntime) {
  if (initialState === null || initialState === void 0) {
    throw new Error(SIGNAL_TREE_MESSAGES.NULL_OR_UNDEFINED);
  }
  const equalityFn = createEqualityFn(config.useShallowComparison ?? false);
  const scalarSlotRuntime = createScalarLeafRuntime(
    materializationContext.physicalCommitClock,
    materializationContext.locationRuntime
  );
  const materializeOrdinaryState = (value, path, parentPositionId, address) => {
    const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(parentPositionId)] : void 0;
    return materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      childPositionIds,
      path,
      address
    );
  };
  const constructionAuthority = {
    materialize: materializeOrdinaryState,
    bindMember: (ownerBranch) => {
      const ownerPositionId = getOwnedPositionIds(ownerBranch)?.[0];
      const ownerPath = getOwnedOwnerPath(ownerBranch) ?? "";
      const ownerAddress = getNodeAddress(ownerBranch);
      if (!ownerAddress)
        throw new Error("Missing dynamic branch construction address.");
      return (key, value) => {
        const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(ownerPositionId)] : void 0;
        const childPath = ownerPath ? `${ownerPath}.${key}` : key;
        return materializeOrdinaryBranch(
          value,
          equalityFn,
          materializationContext,
          buildPlan,
          captureRuntime,
          scalarSlotRuntime,
          childPositionIds,
          childPath,
          childAddressOf(ownerAddress, key)
        );
      };
    }
  };
  const rootPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId()] : void 0;
  const signalState = createSignalStore(
    initialState,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    rootPositionIds
  );
  const rootAccessor = makeNodeAccessor(
    signalState,
    "",
    rootPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  const tree = {};
  defineNodeAddress(tree, []);
  bindLocationRuntime(tree, materializationContext.locationRuntime);
  bindLocationRuntime(
    signalState,
    materializationContext.locationRuntime
  );
  bindLocationRuntime(
    rootAccessor,
    materializationContext.locationRuntime
  );
  tree[MUTATION_CAPTURE_RUNTIME] = captureRuntime;
  if (rootPositionIds) {
    defineOwnedPositionIds(tree, rootPositionIds);
    defineOwnedPositionIds(signalState, rootPositionIds);
    defineOwnedPositionIds(rootAccessor, rootPositionIds);
  }
  defineTreeCapabilities(tree, buildPlan.capabilities);
  if (buildPlan.has("mutation-capture")) {
    defineOwnedOwnerPath(tree, "");
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  if (materializationContext.positionTopologyEnabled) {
    definePositionRegistry(
      tree,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      rootAccessor,
      materializationContext.positionRegistry
    );
  }
  if (materializationContext.positionRegistry) {
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  defineRootTree(rootAccessor, {
    read: () => rootAccessor(),
    replace: (value) => rootAccessor(value),
    derive: (update) => rootAccessor(update)
  });
  if (materializationContext.physicalCommitClock) {
    definePhysicalCommitClock(
      tree,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      signalState,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      rootAccessor,
      materializationContext.physicalCommitClock
    );
  }
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(tree, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(signalState, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(rootAccessor, scalarSlotRuntime);
  }
  const cleanupFns = [];
  const destroyedSig = materializationContext.locationRuntime.createCell(false);
  Object.defineProperty(tree, "$", {
    value: rootAccessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "destroy", {
    value: function() {
      if (destroyedSig()) return;
      try {
        replaceLocation(destroyedSig, true);
      } finally {
        terminateOwnerInvalidation(tree);
        for (const fn of cleanupFns) {
          try {
            fn();
          } catch {
          }
        }
        cleanupFns.length = 0;
        releaseContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
      if (config.debugMode) {
        console.log(SIGNAL_TREE_MESSAGES.TREE_DESTROYED);
      }
    },
    enumerable: false,
    // Allow enhancers (like guardrails) to override/replace `destroy` at runtime.
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree, "destroyed", {
    value: destroyedSig.asReadonly(),
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "registerCleanup", {
    value: function(fn) {
      if (typeof fn === "function") {
        cleanupFns.push(fn);
      }
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "clearCache", {
    value: () => {
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree, "updateAndReport", {
    value: function(arg) {
      if (arguments.length === 0) return [];
      const out = [];
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = unwrap(signalState);
        updates = updater(current);
      }
      materializationContext.locationRuntime.runInvalidationGroup(() => {
        recursiveUpdate(signalState, updates, out, "", false);
      });
      return out;
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  return {
    tree,
    authority: constructionAuthority,
    activateReporting() {
      if (!readWritableCell(destroyedSig)) {
        registerContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
    }
  };
}
function applyEnhancers(tree, ordered) {
  let current = tree;
  for (const enhancer of ordered) {
    if (typeof enhancer !== "function") {
      throw new Error("Enhancer must be a function");
    }
    const result = enhancer(
      current
    );
    if (result !== current && isTraversableNode(result)) {
      current = result;
    }
  }
  return current;
}
function signalTreeImpl(initialState, config = {}, observation = NEUTRAL_OBSERVATION_ADAPTER, createScalarLeafRuntime = createTreeScalarLeafRuntime, createLocations = createLocationRuntime) {
  const declared = config.enhancers ?? [];
  const ordered = resolveEnhancerOrder(
    [...declared],
    /* @__PURE__ */ new Set(),
    Boolean(config.debugMode)
  );
  const buildPlan = buildTreePlan(ordered, config.capabilities);
  const physicalCommitClock = buildPlan.has("causal-runtime") ? createPhysicalCommitClock() : void 0;
  const captureRuntime = createMutationCaptureRuntime();
  const materializationContext = createMaterializationContext(
    buildPlan.has("position-topology"),
    (capability) => buildPlan.has(capability),
    physicalCommitClock,
    createLocations(observation)
  );
  materializationContext.mutationCaptureRuntime = captureRuntime;
  const constructed = create(
    initialState,
    config,
    materializationContext,
    buildPlan,
    captureRuntime,
    createScalarLeafRuntime
  );
  let tree = constructed.tree;
  const authority = constructed.authority;
  const hasEnhancers = ordered.length > 0;
  if (hasEnhancers) {
    materializeTreeMarkers(tree, materializationContext, authority);
    Object.defineProperty(
      tree.$,
      Symbol.for("SignalTree:SubjectPhysicalOwners"),
      {
        value: materializationContext.physicalOwners,
        enumerable: false,
        configurable: true
      }
    );
    tree = applyEnhancers(tree, ordered);
  }
  const configured = createConfiguredTree(
    tree,
    materializationContext,
    hasEnhancers,
    authority,
    config.derived
  );
  constructed.activateReporting();
  return configured;
}
function createConfiguredTree(baseTree, materializationContext, alreadyMaterialized = false, authority, derivedFactory) {
  let isFinalized = false;
  let markersMaterialized = alreadyMaterialized;
  const materializeOnly = () => {
    if (markersMaterialized) return;
    markersMaterialized = true;
    materializeMarkers(
      baseTree.$,
      void 0,
      [],
      materializationContext,
      authority
    );
    _recordTreeConstruction();
  };
  const finalize = () => {
    if (isFinalized) return;
    isFinalized = true;
    materializeOnly();
    if (derivedFactory) {
      applyDerivedFactory(
        baseTree.$,
        derivedFactory,
        materializationContext.locationRuntime
      );
    }
  };
  const rootAccessor = baseTree.$;
  Object.defineProperty(baseTree, "$", {
    get() {
      finalize();
      Object.defineProperty(baseTree, "$", {
        value: rootAccessor,
        enumerable: false,
        configurable: true
      });
      return rootAccessor;
    },
    enumerable: false,
    configurable: true
  });
  const updateAndReport = baseTree.updateAndReport?.bind(baseTree);
  Object.defineProperty(baseTree, "updateAndReport", {
    value: function(arg) {
      finalize();
      if (!updateAndReport) {
        warnMissingForward("updateAndReport");
        return [];
      }
      return updateAndReport(arg);
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  return baseTree;
}
var signalTree = signalTreeImpl;

// ../../../../private/tmp/entity-marker-retention/review/distinct-config.ts
var one = signalTree({ rows: entityMap({ selectId: (r) => r.code }).computed("sum", (rows) => rows.reduce((s, r) => s + r.n, 0)) });
var two = signalTree({ rows: entityMap({ selectId: (r) => r.key }).computed("sum", (rows) => rows.reduce((s, r) => s + r.weight, 0)) });
try {
  one.$.rows.addOne({ code: "a", n: 7 });
  two.$.rows.addOne({ key: 42, weight: 9 });
  assert.deepEqual(one.$.rows.ids(), ["a"]);
  assert.deepEqual(two.$.rows.ids(), [42]);
  console.log("SLICES", one.$.rows.sum(), two.$.rows.sum());
  assert.equal(one.$.rows.sum(), 7);
  assert.equal(two.$.rows.sum(), 9);
} finally {
  one.destroy();
  two.destroy();
}
