import assert from 'node:assert/strict';
import {signalTree,entityMap} from '../candidate/packages/kernel/src/index';
const one=signalTree({rows:entityMap<{code:string;n:number},string>({selectId:r=>r.code}).computed('sum',rows=>rows.reduce((s,r)=>s+r.n,0))});
const two=signalTree({rows:entityMap<{key:number;weight:number},number>({selectId:r=>r.key}).computed('sum',rows=>rows.reduce((s,r)=>s+r.weight,0))});
try{one.$.rows.addOne({code:'a',n:7});two.$.rows.addOne({key:42,weight:9});assert.deepEqual(one.$.rows.ids(),['a']);assert.deepEqual(two.$.rows.ids(),[42]);console.log('SLICES',one.$.rows.sum(),two.$.rows.sum());assert.equal(one.$.rows.sum(),7);assert.equal(two.$.rows.sum(),9);}finally{one.destroy();two.destroy();}
