# Marker lexical-retention correction review

Independent October25. Only entity-map.ts delta reviewed. Exact extracted registration comment/body is byte-identical before/after; public JSDoc preceding entityMap unchanged. Builder/config/computed implementation unchanged and still called per entityMap invocation. New module-scope generic helper called at same first-use location; type parameters erase and do not bind runtime config. Registry dedup/check/hook body untouched, no boolean or import-time registration introduced.

First callback can now capture helper invocation context, but that context contains no instance config/slices/combined/tree. Registry still strongly retains callback legitimately; demonstrated accidental combined→config→selectId→tree chain is structurally removed. Per-tree materialization callback continues to read its marker argument, never first factory config. No public API/semantics change found.

Inspected raw unmodified witness outputs: RETAINED-FIRST20/20, DROPPED-FIRST20/20; both pass true, liveControl true, four sends8. This is evidence for measured first-marker retention correction, not complete entity collectibility. Root performed these GC runs; reviewer did not rerun favorable samples.

Independent executable distinct-config control uses code:string/n7 and key:number/weight9 with separate same-named computed sum slices. IDs and sums correctly differ (7/9). Replay node review/distinct-config.mjs; harness/source hashes BEFORE.sha256. This rules out first-config/slice accidental reuse in that exercised pair, not exhaustive generic validation.

Lazy registration source property preserved: helper invoked only from entityMap factory, same registry check and no top-level registration. Tree-shaking compatibility supported by source structure, not measured bundle output in this review. Fresh production artifact/tree-shaking gates remain later; do not claim byte neutrality. No blocker found for narrow correction. Preserve original18/20 witnesses/heap; current20/20 result closes only their demonstrated lexical retention path.
