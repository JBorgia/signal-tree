# Independent entity collectibility premise review

Read-only October25. Inspected supplied current frozen receipt witnesses, after-run.heapsnapshot and paths.py, RE TAINED/DROPPED outcomes, source marker registration. No new GC run or source patch. No candidate-vs-production retention attribution claimed.

## Strong path, not WeakMap speculation

paths.py excludes edge type weak and V8 synthetic edge names containing 'part of key'; those excluded ephemeron-condition paths cannot establish retention by themselves. RETAINING-PATHS.json's first-tree path, however, uses neither: Stack roots→run closure→module/bundle Context→MARKER_PROCESSORS array→processor0→property create→closure Context→combined→__entityMapConfig→selectId closure→Context→t(tree). Every displayed step is strong/context/property/element. It does not pass through receipt, publication binding, WeakRef or WeakMap.

The registry is module-global and persists across cycles. The first registered processor callback was allocated inside first entityMap(config) call. That invocation also creates `combined` builder and computed/build closures, forming a shared lexical context. Heap graph concretely shows the installed create callback retains that context's combined variable even though callback body uses its marker argument. First config's selectId closure in witness shares cycle context containing tree t and rows/current payload. This explains exactly first-cycle tree and current payload retention with all logical publication counters zero. Later entityMap callbacks are deduplicated and not retained, matching first-only survivors. Equal retained/dropped receipt outcome does not implicate receipt ownership.

## Source/history facts

lib/markers/entity-map.ts232–246 explicitly retains lazy first-use registration and rejects an extra `entityMapRegistered` boolean duplicating registry authority. Comment already suggests hoisting callback if closure cost matters. `combined`428 onward stores config and closures returning combined. internals/materialize-markers.ts540–567 deduplicates by stable check then strongly stores create on MARKER_PROCESSORS. Registry import has no eager side effect; factories self-register for tree-shaking. This supports fixing lexical allocation, not deleting legitimate marker registration or weakening GC assertions.

Readiness git history lookup identifies d2218eb0,5ce1458f,7ab2e82d as recent entity-map touches; no specific leak introduction commit established by this bounded inspection. Do not call this a new candidate regression without comparator evidence.

## Bounded correction hypothesis

Hoist processor creation callback and snapshot/transient hooks out of per-call entityMap invocation into module scope (or a separate per-registration factory with no access to invocation config/combined). Keep registerBuiltinMarkerProcessor call inside factory for lazy first-use/tree-shaking and registry dedup as sole registration authority. Callback receives all instance configuration through marker argument already; do not add global config or registration boolean. This removes demonstrated unintended root while preserving policy.

Before acceptance run unchanged retained/dropped witnesses once each fresh process with same fixedGC schedule, live control and useful sends; a run with config selectId closing over an application tree remains a valid positive stressor, not illegal application behavior. Verify two distinct configurations/derived slices materialize correctly, lazy first-use registration and no marker unused-bundle inclusion. Preserve first18/20 logs/heap and classify correction as registry lexical retention, not receipt GC proof by proxy. Test current source directly; model-only collectibility cannot qualify it.

No weak-edge path should be used as proof. Current strong registry path is sufficient causal evidence to justify the narrow hoist hypothesis; no general lifecycle/lease redesign inferred.
