// packages/kernel/src/lib/internals/cell-identity.ts
var CELL_MARK = Symbol("SignalTree:Cell");
function markTreeCell(cell) {
  Object.defineProperty(cell, CELL_MARK, {
    value: true,
    enumerable: false,
    writable: false,
    configurable: true
  });
  return cell;
}
function isTreeCell(value) {
  return typeof value === "function" && value[CELL_MARK] === true;
}

// packages/kernel/src/lib/leaf.ts
var LEAF_DEFINITION = Symbol.for("SignalTree:LeafDefinition");
function leaf(value) {
  const definition = {};
  Object.defineProperty(definition, LEAF_DEFINITION, { value });
  return definition;
}
function isLeafDefinition(value) {
  return typeof value === "object" && value !== null && Object.prototype.hasOwnProperty.call(value, LEAF_DEFINITION) && Object.getOwnPropertyDescriptor(value, LEAF_DEFINITION)?.enumerable === false;
}
function leafDefinitionValue(definition) {
  return definition[LEAF_DEFINITION];
}

// packages/kernel/src/lib/internals/observation-adapter.ts
var NEUTRAL_OBSERVATION_ADAPTER = {
  createToken: () => ({
    observe: () => void 0,
    invalidate: () => void 0
  }),
  runInvalidationGroup: (run) => run()
};

// packages/kernel/src/lib/internals/production-substrate-stats.ts
var PRODUCTION_SUBSTRATE_STATS_ENABLED = true;
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// packages/kernel/src/lib/internals/intrinsic-mutation.ts
function installTerminalRecord(plan) {
  for (let i = 0; i < plan.writes.length; i++) {
    const write = plan.writes[i];
    write.map.set(write.key, write.value);
  }
  for (let i = 0; i < plan.adds.length; i++) {
    const add = plan.adds[i];
    add.set.add(add.value);
  }
}
var SOURCES = /* @__PURE__ */ new WeakMap();
var SOURCE_ACCESSORS = {
  prepareTerminal: {
    get() {
      return this.terminalPreparer;
    }
  },
  terminal: {
    get() {
      return this.terminalRecord?.observer;
    }
  },
  capture: {
    get() {
      return this.captureRecord?.observer;
    }
  }
};
function compose(record) {
  const { observers } = record;
  if (observers === void 0 || observers.size === 0) {
    record.observer = void 0;
    return;
  }
  if (observers.size === 1) {
    const only = observers.values().next().value;
    record.observer = (mutation) => {
      try {
        only(mutation);
      } catch {
      }
    };
    return;
  }
  const snapshot = [...observers];
  record.observer = (mutation) => {
    for (const observer of snapshot) {
      try {
        observer(mutation);
      } catch {
      }
    }
  };
}
var UNOBSERVABLE_SOURCE = Object.freeze({
  observer: void 0
});
function registerIntrinsicMutationSource(node) {
  const record = { observers: void 0, observer: void 0 };
  Object.defineProperties(record, SOURCE_ACCESSORS);
  SOURCES.set(node, record);
  return record;
}
function observeIntrinsicMutations(node, observer, capture = false) {
  const source = SOURCES.get(node);
  if (!source) return void 0;
  const record = capture === "terminal" ? source.terminalRecord ??= { observers: void 0, observer: void 0 } : capture ? source.captureRecord ??= { observers: void 0, observer: void 0 } : source;
  const installed = observer;
  (record.observers ??= /* @__PURE__ */ new Set()).add(installed);
  compose(record);
  let active2 = true;
  return () => {
    if (!active2) return;
    active2 = false;
    record.observers?.delete(installed);
    compose(record);
  };
}
function prepareTerminalMutations(node, prepare) {
  const source = SOURCES.get(node);
  if (!source) return;
  if (source.terminalPreparer) throw new Error("Terminal preparation already owned");
  source.terminalPreparer = prepare;
  return () => {
    if (source.terminalPreparer === prepare) source.terminalPreparer = void 0;
  };
}

// packages/kernel/src/lib/internals/location-runtime.ts
var WRITABLE_LOCATION_BINDINGS = /* @__PURE__ */ new WeakMap();
var writableLocationBinding = (location) => {
  const binding = WRITABLE_LOCATION_BINDINGS.get(location);
  if (!binding) throw new Error("Expected a writable SignalTree location");
  return binding;
};
function isWritableLocation(value) {
  return WRITABLE_LOCATION_BINDINGS.has(value);
}
function writableLocationPublisher(value) {
  return WRITABLE_LOCATION_BINDINGS.get(value);
}
function replaceLocation(location, value) {
  writableLocationBinding(location).replace(value);
}
function deriveLocation(location, update) {
  writableLocationBinding(location).derive(update);
}
function registerWritableLocationBinding(binding) {
  WRITABLE_LOCATION_BINDINGS.set(
    binding.location,
    binding
  );
}
function createWritableProjection(source, write) {
  const location = markTreeCell(function(value) {
    if (arguments.length === 0) return source();
    if (typeof value === "function") {
      binding.derive(value);
    } else if (isLeafDefinition(value)) {
      binding.replace(leafDefinitionValue(value));
    } else {
      binding.replace(value);
    }
    return void 0;
  });
  const mutationSource1 = registerIntrinsicMutationSource(
    location
  );
  const binding = {
    location,
    notify: () => void 0,
    replace: (value) => {
      const observer = mutationSource1.observer;
      const before = observer ? source.peek() : void 0;
      write(value, "replace");
      if (observer) {
        const after = source.peek();
        observer({
          intent: "replace",
          before,
          after,
          changed: !Object.is(before, after)
        });
      }
    },
    derive: (update) => {
      const before = source.peek();
      write(update(before), "derive");
      const observer = mutationSource1.observer;
      if (observer) {
        const after = source.peek();
        observer({
          intent: "derive",
          before,
          after,
          changed: !Object.is(before, after)
        });
      }
    }
  };
  WRITABLE_LOCATION_BINDINGS.set(
    location,
    binding
  );
  location.peek = source.peek;
  location.subscribe = source.subscribe;
  location.asReadonly = () => location;
  return location;
}
var activeConsumer;
var publicationDepth = 0;
var pendingConsumers = /* @__PURE__ */ new Set();
var dependencyFinalizer = new FinalizationRegistry((dependencies) => {
  for (const [node, edge] of dependencies) {
    node.consumers.delete(edge.reference);
  }
});
var flushConsumers = () => {
  const errors = [];
  while (pendingConsumers.size > 0) {
    const consumer = [...pendingConsumers].sort(
      (left, right) => left.level - right.level
    )[0];
    pendingConsumers.delete(consumer);
    try {
      consumer.settle();
    } catch (error) {
      errors.push(error);
    }
  }
  return errors;
};
var NO_LISTENERS = /* @__PURE__ */ new Set();
var notifyObservers = (token, listeners2) => {
  let failure;
  let hasFailure = false;
  try {
    token?.invalidate();
  } catch (error) {
    failure = error;
    hasFailure = true;
  }
  for (const listener of [...listeners2]) {
    try {
      listener();
    } catch {
    }
  }
  if (hasFailure) throw failure;
};
var trackDependency = (node, token) => {
  if (activeConsumer) {
    let edge = activeConsumer.dependencies.get(node);
    if (!edge) {
      const reference = new WeakRef(activeConsumer);
      edge = { reference, version: node.version };
      node.consumers.add(reference);
      activeConsumer.dependencies.set(node, edge);
    } else {
      edge.version = node.version;
    }
    activeConsumer.level = Math.max(activeConsumer.level, node.level + 1);
    return;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("publicationDependencyReads");
  }
  token().observe();
};
var notifyDependents = (node) => {
  for (const reference of node.consumers) {
    const consumer = reference.deref();
    if (consumer) consumer.invalidate();
    else node.consumers.delete(reference);
  }
};
var NODE_LOCATION_RUNTIMES = /* @__PURE__ */ new WeakMap();
function bindLocationRuntime(node, runtime2) {
  NODE_LOCATION_RUNTIMES.set(node, runtime2);
}
function getLocationRuntime(node) {
  return NODE_LOCATION_RUNTIMES.get(node);
}
function createLocationRuntime(realization) {
  const hasReactiveObservation = realization !== NEUTRAL_OBSERVATION_ADAPTER;
  let invalidationGroupDepth = 0;
  const groupedPublishers = /* @__PURE__ */ new Set();
  const deliver = (publishers) => {
    const errors = [];
    realization.runInvalidationGroup(() => {
      publicationDepth += 1;
      try {
        for (const publisher of publishers) {
          try {
            publisher.notify();
          } catch (error) {
            errors.push(error);
          }
        }
        if (publicationDepth === 1) errors.push(...flushConsumers());
      } finally {
        publicationDepth -= 1;
        if (publicationDepth === 0) pendingConsumers.clear();
      }
    });
    if (errors.length > 0) throw errors[0];
  };
  const publish = (publishers) => {
    if (invalidationGroupDepth > 0) {
      for (const publisher of publishers) groupedPublishers.add(publisher);
      return;
    }
    deliver(publishers);
  };
  const runInvalidationGroup = (run) => {
    let failure;
    let hasFailure = false;
    invalidationGroupDepth += 1;
    try {
      run();
    } catch (error) {
      failure = error;
      hasFailure = true;
    } finally {
      invalidationGroupDepth -= 1;
      if (invalidationGroupDepth === 0 && groupedPublishers.size > 0) {
        const publishers = [...groupedPublishers];
        groupedPublishers.clear();
        try {
          deliver(publishers);
        } catch (error) {
          if (!hasFailure) {
            failure = error;
            hasFailure = true;
          }
        }
      }
    }
    if (hasFailure) throw failure;
  };
  const createWritable = (read2, write) => {
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const location = markTreeCell(function(value) {
      if (arguments.length === 0) {
        trackDependency(node, token);
        return read2();
      }
      if (typeof value === "function") {
        binding.derive(value);
      } else if (isLeafDefinition(value)) {
        binding.replace(leafDefinitionValue(value));
      } else {
        binding.replace(value);
      }
      return void 0;
    });
    const mutationSource2 = registerIntrinsicMutationSource(
      location
    );
    const binding = {
      location,
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, listeners2);
      },
      replace: (next) => {
        const observer = mutationSource2.observer;
        const before = observer ? read2(true) : void 0;
        const result = write(next, "replace", () => mutationSource2.prepareTerminal?.({ intent: "replace", before, after: next, changed: true }));
        const changed = typeof result === "boolean" ? result : result.changed;
        const physicalChanged = typeof result === "boolean" ? result : result.physicalChanged;
        if (observer) {
          observer({
            intent: "replace",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (physicalChanged) publish([binding]);
      },
      derive: (update) => {
        const current = read2();
        const before = mutationSource2.observer ? read2(true) : current;
        const next = update(current);
        const result = write(next, "derive", () => mutationSource2.prepareTerminal?.({ intent: "derive", before, after: next, changed: true }));
        const changed = typeof result === "boolean" ? result : result.changed;
        const physicalChanged = typeof result === "boolean" ? result : result.physicalChanged;
        const observer = mutationSource2.observer;
        if (observer) {
          observer({
            intent: "derive",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (physicalChanged) publish([binding]);
      }
    };
    registerWritableLocationBinding(binding);
    location.peek = () => read2();
    location.subscribe = (listener) => {
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    location.asReadonly = () => location;
    return binding;
  };
  const createCell = (initial, equal = Object.is) => {
    let value = initial;
    const binding = createWritable(
      () => value,
      (next) => {
        if (equal(value, next)) return false;
        value = next;
        return true;
      }
    );
    return binding.location;
  };
  const createDerived = (compute) => {
    let initialized = false;
    let dirty = true;
    let computationFailed = false;
    let value;
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const token = () => observationToken ??= realization.createToken();
    const consumer = {
      dependencies: /* @__PURE__ */ new Map(),
      level: 1,
      invalidate: () => {
        if (dirty) {
          if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
            pendingConsumers.add(consumer);
          }
          return;
        }
        dirty = true;
        notifyDependents(node);
        if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
          pendingConsumers.add(consumer);
        }
      },
      settle: () => {
        if (!dirty) return;
        const previous = value;
        const wasInitialized = initialized;
        readCurrent();
        if (wasInitialized && !Object.is(previous, value)) {
          publisher.notify();
        }
      }
    };
    dependencyFinalizer.register(consumer, consumer.dependencies);
    const publisher = {
      notify: () => {
        notifyObservers(observationToken, listeners2);
      }
    };
    const readCurrent = () => {
      if (!dirty && initialized) return value;
      if (initialized && !computationFailed) {
        let changed = false;
        for (const [dependency, edge] of consumer.dependencies) {
          dependency.refresh();
          if (dependency.version !== edge.version) changed = true;
        }
        if (!changed) {
          dirty = false;
          return value;
        }
      }
      for (const [dependency, edge] of consumer.dependencies) {
        dependency.consumers.delete(edge.reference);
      }
      consumer.dependencies.clear();
      consumer.level = 1;
      const previous = value;
      const wasInitialized = initialized;
      const previousConsumer = activeConsumer;
      activeConsumer = consumer;
      try {
        value = compute();
        node.level = consumer.level;
        initialized = true;
        dirty = false;
        computationFailed = false;
        if (wasInitialized && !Object.is(previous, value)) {
          node.version += 1;
        }
        return value;
      } catch (error) {
        computationFailed = true;
        throw error;
      } finally {
        activeConsumer = previousConsumer;
      }
    };
    node.refresh = () => {
      if (dirty) readCurrent();
    };
    const location = markTreeCell((() => {
      const current = readCurrent();
      trackDependency(node, token);
      return current;
    }));
    location.peek = readCurrent;
    location.subscribe = (listener) => {
      readCurrent();
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    return location;
  };
  const createEpoch = () => {
    let observationToken;
    let version = 0;
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const publisher = {
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, NO_LISTENERS);
      }
    };
    const epoch = (() => {
      trackDependency(node, token);
      return version;
    });
    epoch.set = (next) => {
      if (next === version) return;
      version = next;
      publish([publisher]);
    };
    epoch.update = (fn) => epoch.set(fn(version));
    epoch.asReadonly = () => epoch;
    return epoch;
  };
  const advanceEpoch = (handle) => {
    handle.update((v) => v + 1);
  };
  return {
    createCell,
    createDerived,
    createWritable,
    createEpoch,
    advanceEpoch,
    publish,
    runInvalidationGroup
  };
}
var NEUTRAL_LOCATION_RUNTIME = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
);
function needsLocationAuthorityAdmission(value) {
  return WRITABLE_LOCATION_BINDINGS.get(value)?.needsAuthorityAdmission?.() ?? false;
}

// packages/kernel/src/lib/internals/error-reporter.ts
var listeners = /* @__PURE__ */ new Set();
function reportTreeError(event) {
  if (listeners.size === 0) return false;
  let received = false;
  for (const listener of listeners) {
    try {
      listener(event);
      received = true;
    } catch (err) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        safeConsoleError(
          "SignalTree: an onTreeError listener threw. The original error was still handled normally; this is the listener failing. [ST2025]",
          err
        );
      }
    }
  }
  return received;
}
function safeConsoleError(message, error) {
  try {
    if (error === void 0) console.error(message);
    else console.error(message, error);
  } catch {
  }
}
var CONTAINED_REPORT_BUDGET = 50;
var CONTAINED_REPORT_WINDOW_MS = 1e3;
var containedReportWindows = /* @__PURE__ */ new Map();
function registerContainedReportBudget(treeId) {
  containedReportWindows.set(treeId, null);
}
function takeContainedReportBudget(treeId) {
  let now = 0;
  try {
    now = Date.now();
  } catch {
  }
  const owner = containedReportWindows.has(treeId) ? treeId : void 0;
  let window2 = containedReportWindows.get(owner);
  if (!window2 || now - window2.start >= CONTAINED_REPORT_WINDOW_MS) {
    window2 = { start: now, count: 0 };
    containedReportWindows.set(owner, window2);
  }
  if (window2.count >= CONTAINED_REPORT_BUDGET) {
    if (window2.count === CONTAINED_REPORT_BUDGET && listeners.size > 0) {
      window2.count++;
      safeConsoleError(
        `SignalTree: more than ${CONTAINED_REPORT_BUDGET} contained observer errors for one tree within a second; further ones go to the console only, not onTreeError. [ST2034]`
      );
    }
    return false;
  }
  window2.count++;
  return true;
}
function reportContainedObserverError(event) {
  const { error, operation, treeId, path } = event;
  let received = false;
  if (treeId !== void 0) {
    if (takeContainedReportBudget(treeId)) {
      received = reportTreeError({
        error,
        operation,
        treeId,
        ...path === void 0 ? {} : { path }
      });
    }
  }
  if (received && !(typeof ngDevMode === "undefined" || ngDevMode)) {
    return;
  }
  safeConsoleError(
    operation === "notify:subscriber" ? `SignalTree: a write subscriber threw while observing '${path}'; delivery continued. [ST2034]` : "SignalTree: a transaction turn listener threw; the transaction continued. [ST2034]",
    error
  );
}
function releaseContainedReportBudget(treeId) {
  containedReportWindows.delete(treeId);
}

// packages/kernel/src/lib/constants.ts
var DEV_MESSAGES = {
  NULL_OR_UNDEFINED: "null/undefined [ST1001]",
  TREE_DESTROYED: "destroyed [ST1012]",
  ENHANCER_CYCLE_DETECTED: "enhancer cycle [ST1024]"
  // ST1032 (LAZY_NOT_INJECTED) and ST1004 (LAZY_FALLBACK) were removed in 15.0
  // with the lazy feature. ST1032 in particular told users to import from
  // `@signal-tree/kernel/lazy`, a subpath withdrawn from the published surface —
  // a runtime diagnostic giving advice that could not be followed.
};
var PROD_MESSAGES = DEV_MESSAGES;
var _isProdByEnv = Boolean(
  typeof globalThis === "object" && globalThis !== null && "process" in globalThis && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  typeof globalThis.process === "object" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  "env" in globalThis.process && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  globalThis.process.env.NODE_ENV === "production"
);
var _isDev = typeof ngDevMode !== "undefined" ? Boolean(ngDevMode) : !_isProdByEnv;
var SIGNAL_TREE_MESSAGES = Object.freeze(
  _isDev ? DEV_MESSAGES : PROD_MESSAGES
);

// packages/kernel/src/lib/enhancer-types.ts
var ENHANCER_META = Symbol("signaltree:enhancer:meta");

// packages/kernel/src/enhancers/index.ts
function resolveEnhancerOrder(enhancers, availableCapabilities = /* @__PURE__ */ new Set(), debugMode = false) {
  const nodes = enhancers.map((e, idx) => ({
    fn: e,
    name: e.metadata && e.metadata.name ? String(e.metadata.name) : `enhancer#${idx}`,
    requires: new Set(e.metadata?.requires ?? []),
    provides: new Set(e.metadata?.provides ?? [])
  }));
  const provided = new Set(availableCapabilities);
  const nameCounts = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    for (const capability of node.provides) provided.add(capability);
    if (node.fn.metadata?.name) {
      nameCounts.set(node.name, (nameCounts.get(node.name) ?? 0) + 1);
    }
  }
  const problems = [];
  for (const node of nodes) {
    for (const capability of node.requires) {
      if (!provided.has(capability)) {
        problems.push(
          `  - ${node.fn.metadata?.name ? `"${node.name}"` : "an unnamed enhancer"} requires capability "${capability}", but no configured enhancer provides it.`
        );
      }
    }
  }
  for (const [name, count] of nameCounts) {
    if (count > 1) {
      problems.push(
        `  - enhancer "${name}" is configured ${count} times; each enhancer may appear once.`
      );
    }
  }
  if (problems.length > 0) {
    throw new Error(
      `SignalTree could not finalize the enhancer configuration:
${problems.join("\n")}`
    );
  }
  const adj = /* @__PURE__ */ new Map();
  const nameToNode = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    nameToNode.set(n.name, n);
    adj.set(n.name, /* @__PURE__ */ new Set());
  }
  for (const a of nodes) {
    for (const b of nodes) {
      if (a === b) continue;
      for (const req of b.requires) {
        if (availableCapabilities.has(req)) continue;
        if (a.provides.has(req)) {
          const set = adj.get(a.name);
          if (set) set.add(b.name);
        }
      }
    }
  }
  const inDegree = /* @__PURE__ */ new Map();
  for (const entry of adj.keys()) inDegree.set(entry, 0);
  for (const [, outs] of adj) {
    for (const to of outs) inDegree.set(to, (inDegree.get(to) || 0) + 1);
  }
  const queue = [];
  for (const [name, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(name);
  }
  const ordered = [];
  while (queue.length > 0) {
    const n = queue.shift();
    if (!n) break;
    ordered.push(n);
    const outs = adj.get(n);
    if (!outs) continue;
    for (const m of outs) {
      inDegree.set(m, (inDegree.get(m) || 0) - 1);
      if (inDegree.get(m) === 0) queue.push(m);
    }
  }
  if (ordered.length !== nodes.length) {
    if (debugMode) {
      console.warn(SIGNAL_TREE_MESSAGES.ENHANCER_CYCLE_DETECTED);
    }
    return enhancers;
  }
  return ordered.map((name) => {
    const n = nameToNode.get(name);
    return n ? n.fn : enhancers[0];
  });
}

// packages/kernel/src/lib/internals/node-shape.ts
function isTraversableNode(value) {
  return value != null && (typeof value === "object" || typeof value === "function");
}
var CALLABLE_SIGNAL_SYMBOL = Symbol.for("SignalTree:NodeAccessor");
var NODE_STORE_SYMBOL = Symbol.for("SignalTree:NodeStore");
function nodeStoreOf(node) {
  const store = node[NODE_STORE_SYMBOL];
  return store !== void 0 && store !== null ? store : void 0;
}
function snapshotNodeKey(node) {
  return nodeStoreOf(node) ?? node;
}
function isNodeAccessor(value) {
  return typeof value === "function" && value[CALLABLE_SIGNAL_SYMBOL] === true;
}

// packages/kernel/src/lib/internals/owned-metadata.ts
var OWNED_NODE_METADATA = /* @__PURE__ */ new WeakMap();
function getOwnedPositionIds(node) {
  if (isTraversableNode(node)) {
    const direct = node.__positionIds;
    if (direct) {
      return [...direct];
    }
    const sidecar = OWNED_NODE_METADATA.get(node)?.positionIds;
    return sidecar ? [...sidecar] : void 0;
  }
  return void 0;
}
function getOwnedSubjectIds(node) {
  if (isTraversableNode(node)) {
    const direct = node.__subjectIds;
    if (direct) {
      return [...direct];
    }
    return void 0;
  }
  return void 0;
}
function getOwnedOwnerPath(node) {
  if (isTraversableNode(node)) {
    const direct = node.__ownerPath;
    if (direct !== void 0) {
      return direct;
    }
    return OWNED_NODE_METADATA.get(node)?.ownerPath;
  }
  return void 0;
}
function hasIntrinsicMutationEmitter(node) {
  if (isTraversableNode(node)) {
    const direct = node.__emitsMutations;
    if (direct !== void 0) {
      return direct;
    }
    return OWNED_NODE_METADATA.get(node)?.emitsMutations === true;
  }
  return false;
}

// packages/kernel/src/lib/internals/owner-invalidation-port.ts
var dispatch;
function markOwnerInvalidated(ownerId) {
  dispatch?.mark(ownerId);
}
function markOwnerInvalidatedFrom(owner) {
  dispatch?.markFrom(owner);
}
function terminateOwnerInvalidation(owner) {
  dispatch?.terminate(owner);
}

// packages/kernel/src/lib/internals/path-observation-port.ts
var runtime;
function installPathDeliveryRuntime(next) {
  runtime = next;
}
var branchMembershipCapture;
var pathReAddCapture;
function installBranchMembershipCapture(capture, pathReAdd) {
  branchMembershipCapture = capture;
  pathReAddCapture = pathReAdd;
}
function captureBranchMembershipIfObserved(branch, supplied, partial) {
  return branchMembershipCapture?.(branch, supplied, partial);
}
function capturePathReAddIfObserved(path, outer) {
  return pathReAddCapture?.(path, outer);
}
function hasPathObservers() {
  return runtime?.hasObservers() ?? false;
}
var PORT = {
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    runtime?.notify(
      path,
      value,
      prev,
      ownerPath,
      subjectIds,
      positionIds,
      metaOverride,
      ownerId,
      subjectFieldFootprint
    );
  }
};
function pathObservation() {
  return PORT;
}

// packages/kernel/src/lib/internals/snapshot-authority.ts
var MATERIALIZED = /* @__PURE__ */ new WeakMap();
var SNAPSHOT_PARENT = /* @__PURE__ */ new WeakMap();
var TREE_STORES = /* @__PURE__ */ new WeakSet();
var VOLATILE_SNAPSHOTS = /* @__PURE__ */ new WeakSet();
var MEMBERSHIP_REVISION = /* @__PURE__ */ new WeakMap();
function markTreeStore(store) {
  TREE_STORES.add(store);
}
function isSnapshotNode(node) {
  return TREE_STORES.has(node) || isNodeAccessor(node);
}
function bindSnapshotParent(node, parent) {
  SNAPSHOT_PARENT.set(
    snapshotNodeKey(node),
    new WeakRef(snapshotNodeKey(parent))
  );
}
function markSnapshotVolatile(node) {
  let current = snapshotNodeKey(node);
  while (current) {
    VOLATILE_SNAPSHOTS.add(current);
    current = SNAPSHOT_PARENT.get(current)?.deref();
  }
}
function membershipRevisionFor(key, locations) {
  let revision = MEMBERSHIP_REVISION.get(key);
  if (!revision) {
    revision = locations.createCell(0);
    MEMBERSHIP_REVISION.set(key, revision);
  }
  return revision;
}
function observeMembership(node) {
  membershipRevisionFor(
    snapshotNodeKey(node),
    getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME
  )();
}
function publishMembershipChange(node) {
  const key = snapshotNodeKey(node);
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  deriveLocation(membershipRevisionFor(key, locations), (value) => value + 1);
  markOwnerInvalidatedFrom(node);
}
function materializeSnapshotNode(node, build) {
  const key = snapshotNodeKey(node);
  if (VOLATILE_SNAPSHOTS.has(key)) return build();
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  let snapshot = MATERIALIZED.get(key);
  if (!snapshot) {
    const membershipRevision = membershipRevisionFor(key, locations);
    const read2 = () => {
      membershipRevision();
      const built = build();
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        if (built !== null && typeof built === "object") Object.freeze(built);
      }
      return built;
    };
    snapshot = { observe: locations.createDerived(read2) };
    MATERIALIZED.set(key, snapshot);
  }
  return snapshot.observe();
}

// packages/kernel/src/lib/internals/tree-scalar-slot-port.ts
var TREE_SCALAR_SLOT_RUNTIME = Symbol.for("SignalTree:ScalarSlotRuntime");
function defineTreeScalarSlotRuntime(node, runtime2) {
  Object.defineProperty(node, TREE_SCALAR_SLOT_RUNTIME, {
    value: runtime2,
    enumerable: false,
    configurable: true
  });
}
function getTreeScalarSlotRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[TREE_SCALAR_SLOT_RUNTIME];
}

// packages/kernel/src/lib/internals/member-membership.ts
var DORMANT = Symbol.for("SignalTree:DormantMember");
var membershipEpoch = 1;
var omittedMembers = /* @__PURE__ */ new WeakMap();
var ABSENCE_CHECK_EVERY = 64;
var absenceChecks = 0;
var MEMBERSHIP_CHANGED = Symbol.for("SignalTree:MembershipChanged");
function membershipHook(node) {
  return node?.[MEMBERSHIP_CHANGED];
}
var NODE_ACCESSOR_PEER = Symbol.for("SignalTree:NodeAccessorPeer");
function memberBinding(leaf2) {
  if (!isTraversableNode(leaf2)) {
    return void 0;
  }
  return leaf2[DORMANT];
}
function reactivateOnWrite(leaf2) {
  const binding = memberBinding(leaf2);
  if (!binding) return false;
  return setMemberPresence(binding.parent, binding.key, "active");
}
function nodeOf(parent) {
  return parent[NODE_ACCESSOR_PEER] ?? parent;
}
function isAbsentMember(node) {
  const first = memberBinding(node);
  if (first === void 0) return false;
  if (first.epoch === membershipEpoch) {
    if ((typeof ngDevMode === "undefined" || ngDevMode) && ++absenceChecks % ABSENCE_CHECK_EVERY === 0 && walkAbsence(first) !== first.absent)
      throw new Error(
        "SignalTree internal: a cached absence answer disagrees with enumerability (membershipEpoch was not advanced)."
      );
    return first.absent;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  first.absent = walkAbsence(first);
  first.epoch = membershipEpoch;
  return first.absent;
}
function walkAbsence(first) {
  for (let binding = first; binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) return true;
  }
  return false;
}
var structuralWrites = {
  depth: 0,
  stamp: 0
};
function beginStructuralWrite() {
  structuralWrites.depth++;
}
function endStructuralWrite(failed) {
  if (--structuralWrites.depth) return;
  structuralWrites.readded = void 0;
  structuralWrites.end?.(failed);
}
function inStructuralWrite(node) {
  return node !== void 0 && structuralWrites.own === node;
}
function readdedDuringStructuralWrite(branch, key, since) {
  return (structuralWrites.readded?.get(nodeOf(branch))?.get(key) ?? 0) > since;
}
var storedReads = { depth: 0 };
function reactivatePathOnWrite(node) {
  if (!isAbsentMember(node)) return false;
  if (inStructuralWrite(node)) return reactivateOnWrite(node);
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  const path = [];
  let outer = -1;
  for (let binding = memberBinding(node); binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) outer = path.length;
    path.push(binding);
  }
  if (outer < 0) return false;
  const announce = capturePathReAddIfObserved(path, outer);
  for (let i = outer - 1; i >= 0; i--) {
    const { parent, key: kept } = path[i];
    for (const member of Object.keys(parent))
      if (member !== kept) setMemberPresence(parent, member, "dormant");
  }
  for (let i = outer; i >= 0; i--) {
    const { parent, key } = path[i];
    setMemberPresence(parent, key, "active");
    if (structuralWrites.depth) {
      const readded = structuralWrites.readded ??= /* @__PURE__ */ new Map();
      let keys = readded.get(parent);
      if (!keys) readded.set(parent, keys = /* @__PURE__ */ new Map());
      keys.set(key, ++structuralWrites.stamp);
    }
  }
  if (!isWritableLocation(node) || outer > 0)
    republishMembers(path[outer].parent, [path[outer].key]);
  announce?.();
  return true;
}
var ABSENCE = {
  // History capture reads what storage holds (`storedReads`).
  isAbsent: (node) => !storedReads.depth && isAbsentMember(node),
  reAdd: reactivatePathOnWrite
};
function republishMembers(parent, keys) {
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (!runtime2) return;
  const changedSlots = [];
  const unaddressedLeaves = [];
  const branches = [];
  const publish = (child) => {
    const positionId = getOwnedPositionIds(child)?.[0];
    const slot = positionId === void 0 ? void 0 : runtime2.resolveScalarSlot(positionId);
    if (slot !== void 0) return changedSlots.push(slot) > 0;
    const publisher = writableLocationPublisher(child);
    if (publisher) return unaddressedLeaves.push(publisher) > 0;
    membershipHook(child)?.();
    if (isNodeAccessor(child)) {
      branches.push(child);
      for (const key of Object.keys(child))
        publish(child[key]);
    }
    return false;
  };
  let tokenCarrying = 0;
  for (const key of keys)
    if (publish(parent[key])) tokenCarrying++;
  if (tokenCarrying < keys.length) {
    publishMembershipChange(parent);
  } else {
    markOwnerInvalidatedFrom(parent);
  }
  for (const branch of branches) publishMembershipChange(branch);
  if (changedSlots.length > 0) {
    runtime2.publishPrepared({ revision: runtime2.revision(), changedSlots });
  }
  if (unaddressedLeaves.length > 0) {
    (getLocationRuntime(parent) ?? NEUTRAL_LOCATION_RUNTIME).publish(
      unaddressedLeaves
    );
  }
}
function deactivateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === false) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: false });
  membershipEpoch++;
  markHasDormant(parent);
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (runtime2) {
    omittedMembers.set(runtime2, (omittedMembers.get(runtime2) ?? 0) + 1);
    runtime2.enableAbsence?.(ABSENCE);
  }
  const child = parent[key];
  if (isTraversableNode(child)) {
    linkMember(parent, key, child);
    linkDescendants(child);
  }
  return true;
}
function linkMember(parent, key, child) {
  membershipEpoch++;
  Object.defineProperty(child, DORMANT, {
    value: {
      parent: nodeOf(parent),
      key,
      epoch: 0,
      absent: false
    },
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function linkDescendants(node) {
  if (!isNodeAccessor(node)) return;
  for (const key of Object.getOwnPropertyNames(node)) {
    const child = Object.getOwnPropertyDescriptor(node, key)?.value;
    if (!isNodeAccessor(child) && !isWritableLocation(child) && !membershipHook(child) || memberBinding(child))
      continue;
    linkMember(node, key, child);
    linkDescendants(child);
  }
}
function linkAddedMember(branch, key, child) {
  if (!isTraversableNode(child) || !memberBinding(nodeOf(branch))) return;
  linkMember(branch, key, child);
  linkDescendants(child);
}
function activateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === true) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: true });
  membershipEpoch++;
  const runtime2 = getTreeScalarSlotRuntime(parent);
  const omitted = runtime2 ? omittedMembers.get(runtime2) : void 0;
  if (runtime2 && omitted !== void 0) {
    omittedMembers.set(runtime2, omitted - 1);
    if (omitted === 1) runtime2.disableAbsence?.();
  }
  return true;
}
var HAS_DORMANT = Symbol.for("SignalTree:HasDormantMembers");
function hasDormantMembers(parent) {
  return parent[HAS_DORMANT] === true;
}
function markHasDormant(parent) {
  if (hasDormantMembers(parent)) return;
  Object.defineProperty(parent, HAS_DORMANT, {
    value: true,
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function dormantKeys(parent) {
  return Object.getOwnPropertyNames(parent).filter((key) => {
    const d = Object.getOwnPropertyDescriptor(parent, key);
    return d !== void 0 && d.enumerable === false && "value" in d;
  });
}
function peerOf(branch) {
  const record = branch;
  const peer = record[NODE_STORE_SYMBOL] ?? record[NODE_ACCESSOR_PEER];
  return isTraversableNode(peer) && peer !== branch ? peer : void 0;
}
function setMemberPresence(branch, key, presence) {
  const apply = presence === "active" ? activateOne : deactivateOne;
  let changed = apply(branch, key);
  const peer = peerOf(branch);
  if (peer) changed = apply(peer, key) || changed;
  return changed;
}

// packages/kernel/src/lib/write-context.ts
var activeContext;
function withWriteContext(meta, fn) {
  const previous = activeContext;
  activeContext = meta;
  try {
    return fn();
  } finally {
    activeContext = previous;
  }
}
function getActiveWriteContext() {
  return activeContext;
}

// packages/kernel/src/lib/internals/owned-mutation.ts
function mergeOwnedNodeMetadata(node, patch) {
  const existing = OWNED_NODE_METADATA.get(node) ?? {};
  OWNED_NODE_METADATA.set(node, { ...existing, ...patch });
}
function defineOwnedPositionIds(node, positionIds, storage = "property") {
  if (!positionIds || positionIds.length === 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { positionIds: [...positionIds] });
    return;
  }
  Object.defineProperty(node, "__positionIds", {
    get: () => [...positionIds],
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerPath(node, ownerPath, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerPath });
    return;
  }
  Object.defineProperty(node, "__ownerPath", {
    value: ownerPath,
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerId(node, ownerId, storage = "property") {
  if (ownerId === void 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerId });
    return;
  }
  Object.defineProperty(node, "__ownerId", {
    value: ownerId,
    enumerable: false,
    configurable: true
  });
}
function defineIntrinsicMutationEmitter(node, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { emitsMutations: true });
    return;
  }
  Object.defineProperty(node, "__emitsMutations", {
    value: true,
    enumerable: false,
    configurable: true
  });
}
function emitOwnedMutation(options, before, after, mutationIntent) {
  markOwnerInvalidated(options.ownerId);
  const positionId = options.positionIds?.[0];
  if (positionId === void 0) {
    return;
  }
  if (!hasPathObservers()) {
    return;
  }
  pathObservation().notify(
    options.path,
    after,
    before,
    options.path,
    // subjectIds: this generic scalar route has no subject-identity producer
    // and must not acquire one. Entity/structural notification owns that fact.
    void 0,
    [positionId],
    {
      ...getActiveWriteContext() ?? {},
      mutationIntent
    },
    options.ownerId
  );
}
function wrapOwnedWritableSignal(leaf2, options, hooks = {}) {
  const metadataStorage = options.metadataStorage ?? "property";
  defineOwnedPositionIds(leaf2, options.positionIds, metadataStorage);
  defineOwnedOwnerId(leaf2, options.ownerId, metadataStorage);
  defineOwnedOwnerPath(leaf2, options.path, metadataStorage);
  defineIntrinsicMutationEmitter(leaf2, metadataStorage);
  const releaseIntrinsicObserver = observeIntrinsicMutations(
    leaf2,
    (mutation) => {
      if (mutation.changed) {
        emitOwnedMutation(
          options,
          mutation.before,
          mutation.after,
          mutation.intent
        );
      }
      if (mutation.intent === "replace") {
        hooks.afterSet?.(
          mutation.after,
          mutation.before,
          mutation.after,
          mutation.changed
        );
      } else {
        hooks.afterUpdate?.(
          mutation.before,
          mutation.after,
          mutation.changed
        );
      }
    }
  );
  if (!releaseIntrinsicObserver) {
    throw new Error("SignalTree location has no intrinsic mutation source");
  }
}

// packages/kernel/src/lib/internals/position-registry.ts
var POSITION_REGISTRY_SYMBOL = Symbol.for("SignalTree:PositionRegistry");
var nextRegistryId = 1;
var TreePositionRegistry = class {
  /**
   * ⚠️ THE ONE PLACE a counter value becomes a tree-namespace identity.
   *
   * Branding HERE rather than at each consumer means `registry.id` and
   * `ownerRegistry.id` are already `TreeId` everywhere downstream — no producer
   * has to independently assert that some number is a tree identity.
   */
  id = nextRegistryId++;
  nextPositionId = 1;
  parents = /* @__PURE__ */ new Map();
  addresses = /* @__PURE__ */ new Map();
  registerPositionAddress(position, address) {
    this.addresses.set(position, sealedAddress(address));
  }
  addressFor(position) {
    return this.addresses.get(position);
  }
  collectionPaths = /* @__PURE__ */ new Map();
  registerCollectionPath(position, path) {
    this.collectionPaths.set(position, path);
  }
  collectionPathFor(position) {
    return this.collectionPaths.get(position);
  }
  allocate(parent) {
    const positionId = this.nextPositionId++;
    this.parents.set(positionId, parent);
    return positionId;
  }
  parentOf(position) {
    return this.parents.get(position);
  }
  contains(authority, participant) {
    if (authority === participant) {
      return true;
    }
    const seen = /* @__PURE__ */ new Set();
    let current = participant;
    while (current !== void 0 && !seen.has(current)) {
      seen.add(current);
      const parent = this.parentOf(current);
      if (parent === authority) {
        return true;
      }
      current = parent;
    }
    return false;
  }
};
function createPositionRegistry() {
  return new TreePositionRegistry();
}
function definePositionRegistry(node, registry) {
  Object.defineProperty(node, POSITION_REGISTRY_SYMBOL, {
    value: registry,
    enumerable: false,
    configurable: true
  });
}
function getPositionRegistry(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[POSITION_REGISTRY_SYMBOL];
}
var nodeAddresses = /* @__PURE__ */ new WeakMap();
function sealedAddress(address) {
  return Object.isFrozen(address) ? address : Object.freeze(address.slice());
}
function childAddressOf(address, key) {
  return Object.freeze(address.concat(key));
}
function defineNodeAddress(node, address) {
  nodeAddresses.set(node, sealedAddress(address));
}
function getNodeAddress(node) {
  return isTraversableNode(node) ? nodeAddresses.get(node) : void 0;
}

// packages/kernel/src/lib/internals/runtime-tree-plan.ts
var RESTORATION_CAPABILITIES = [
  "causal-runtime",
  "temporal-snapshots"
];
function createRuntimeTreePlan(hasCapability) {
  return Object.freeze({
    hasCapability,
    hasRestorationAuthority: RESTORATION_CAPABILITIES.some(
      (capability) => hasCapability(capability)
    )
  });
}

// packages/kernel/src/lib/internals/materialize-markers.ts
function createMaterializationContext(positionTopologyEnabled = true, hasCapability = (capability) => capability === "position-topology" ? positionTopologyEnabled : true, physicalCommitClock, locationRuntime = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const positionRegistry = createPositionRegistry();
  return {
    locationRuntime,
    positionRegistry,
    positionTopologyEnabled,
    physicalCommitClock,
    hasCapability,
    runtimeTreePlan: createRuntimeTreePlan(hasCapability),
    allocatePositionId: (parentPositionId) => positionRegistry.allocate(parentPositionId),
    physicalOwners: []
  };
}
var PROCESSOR_STAMP = Symbol.for("SignalTree:MarkerProcessor");
function getNodeProcessor(node) {
  if (!isTraversableNode(node)) return void 0;
  return node[PROCESSOR_STAMP];
}
function snapshotMarkerNode(node, parent) {
  const proc = getNodeProcessor(node);
  if (!proc?.snapshot) return void 0;
  if (!isTraversableNode(node)) return { value: proc.snapshot(node) };
  if (parent) bindSnapshotParent(node, parent);
  if (!proc.cacheSnapshot) {
    markSnapshotVolatile(node);
    return { value: proc.snapshot(node) };
  }
  const snapshot = proc.snapshot;
  return materializeSnapshotNode(node, () => ({
    value: snapshot(node)
  }));
}
function hydrateMarkerNode(node, value, mode) {
  const proc = getNodeProcessor(node);
  if (!proc?.hydrate) return false;
  proc.hydrate(node, value, mode);
  return true;
}
var MARKER_PROCESSORS = [];
function isRegisteredMarker(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  if (Object.getOwnPropertySymbols(value).length === 0) {
    return false;
  }
  for (const processor of MARKER_PROCESSORS) {
    if (processor.check(value)) {
      return true;
    }
  }
  return false;
}
function registerBuiltinMarkerProcessor(check, create2, hooks) {
  registerProcessor(
    check,
    create2,
    /* suppressTimingWarning */
    true,
    /* cacheSnapshot */
    true,
    hooks
  );
}
function warnUndeclaredMarker() {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  console.warn(
    "SignalTree: a marker was registered without `snapshot` or `transient: true`. Its value will be DROPPED from every snapshot \u2014 tree.$(), persistence(), devtools, audit and undo/redo \u2014 silently, except for an ST2008 report at read time. Declare what of your marker is state: pass `{ snapshot, hydrate }`, or `{ transient: true }` if it deliberately has none. [ST2022]"
  );
}
var warnedWriteOnly = /* @__PURE__ */ new WeakSet();
function warnWriteOnlyMarker(processor, node) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (!processor.snapshot || processor.hydrate) return;
  if (typeof node === "function" && "set" in node && typeof node.set === "function") {
    return;
  }
  if (warnedWriteOnly.has(processor)) return;
  warnedWriteOnly.add(processor);
  console.warn(
    "SignalTree: a marker declares `snapshot` but no `hydrate`, and its node is not a writable signal. It will be captured by tree.$(), persistence(), devtools, audit and undo/redo \u2014 and every attempt to write it back is SILENTLY DISCARDED, so tree.$(tree.$()) loses its value. Add a `hydrate` hook, or mark it `transient: true` if it is genuinely not restorable. [ST2023]"
  );
}
function registerProcessor(check, create2, suppressTimingWarning, cacheSnapshot, hooks) {
  if (typeof check !== "function" || typeof create2 !== "function") {
    throw new TypeError(
      "registerMarkerProcessor: both 'check' (type guard) and 'create' (materializer) must be functions. Received check=" + typeof check + ", create=" + typeof create2 + ". See https://signaltree.io/docs (custom markers section) for usage."
    );
  }
  const alreadyRegistered = MARKER_PROCESSORS.some((p) => p.check === check);
  if (alreadyRegistered) {
    return;
  }
  if (!suppressTimingWarning && (typeof ngDevMode === "undefined" || ngDevMode) && treesConstructedCount > 0) {
    console.warn(
      `[SignalTree] registerMarkerProcessor() was called AFTER at least one signalTree() had already been constructed (${treesConstructedCount} trees so far). Existing trees will NOT pick up this marker \u2014 only trees built after this point will use it. To process your custom marker in existing trees, register it at module load time (before any signalTree() call), or rebuild the tree after registration.`
    );
  }
  if (!hooks?.snapshot && !hooks?.transient) warnUndeclaredMarker();
  MARKER_PROCESSORS.push({
    check,
    create: create2,
    snapshot: hooks?.snapshot,
    hydrate: hooks?.hydrate,
    cacheSnapshot
  });
}
var treesConstructedCount = 0;
function _recordTreeConstruction() {
  treesConstructedCount += 1;
}
var ORDINARY_STATE = Symbol.for("SignalTree:OrdinaryStateRequest");
var KEY_INDEX = Symbol.for("SignalTree:DynamicKeyIndex");
var MEMBER_MATERIALIZER = Symbol.for("SignalTree:MemberMaterializer");
function attachKeyIndex(branch) {
  const members = /* @__PURE__ */ new Map();
  for (const key of Object.keys(branch)) {
    members.set(key, branch[key]);
  }
  Object.defineProperty(branch, KEY_INDEX, {
    value: members,
    enumerable: false,
    configurable: true
  });
}
function installPreparedMember(branch, key, child, responsibility) {
  const define = (target) => {
    Object.defineProperty(target, key, {
      value: child,
      enumerable: true,
      writable: true,
      configurable: true
    });
  };
  define(branch);
  const backingStore = branch[NODE_STORE_SYMBOL];
  if (backingStore && backingStore !== branch) define(backingStore);
  if (responsibility) {
    installTerminalRecord(responsibility);
  }
  linkAddedMember(branch, key, child);
  branch[KEY_INDEX]?.set(
    key,
    child
  );
}
var applyMemberValue;
function setMemberValueApplier(fn) {
  applyMemberValue = fn;
}
function isOrdinaryStateRequest(v) {
  return isTraversableNode(v) && v[ORDINARY_STATE] === true;
}
function materializeKeyedAware(authority, request, path, parentPositionId, address) {
  const branch = authority.materialize(
    request.value,
    path,
    parentPositionId,
    address
  );
  if (request.keyedLookup && isTraversableNode(branch)) {
    attachKeyIndex(branch);
    Object.defineProperty(branch, MEMBER_MATERIALIZER, {
      value: authority.bindMember(branch),
      enumerable: false,
      configurable: true
    });
  }
  return branch;
}
function materializeMarkers(node, notifier, path = [], context = createMaterializationContext(), authority) {
  if (!isTraversableNode(node)) return;
  if (isTreeCell(node)) return;
  const isAccessor = typeof node === "function" && isNodeAccessor(node);
  if (typeof node === "function" && !isAccessor) return;
  const getNotifier = () => notifier ?? pathObservation();
  const keys = Object.keys(node);
  for (const key of keys) {
    const value = node[key];
    const currentPath = childAddressOf(path, key);
    const pathString = currentPath.join(".");
    let processed = false;
    for (const processor of MARKER_PROCESSORS) {
      if (processor.check(value)) {
        try {
          const parentPositionId = node.__positionIds?.[0];
          const produced = processor.create(
            value,
            getNotifier(),
            pathString,
            context,
            parentPositionId
          );
          const materialized = isOrdinaryStateRequest(produced) && authority ? materializeKeyedAware(
            authority,
            produced,
            pathString,
            parentPositionId,
            currentPath
          ) : produced;
          if (isTraversableNode(materialized)) {
            defineNodeAddress(materialized, currentPath);
            if (context.positionTopologyEnabled) {
              for (const position of getOwnedPositionIds(materialized) ?? []) {
                context.positionRegistry.registerPositionAddress(
                  position,
                  currentPath
                );
              }
            }
            bindLocationRuntime(
              materialized,
              context.locationRuntime
            );
            Object.defineProperty(materialized, PROCESSOR_STAMP, {
              value: processor,
              enumerable: false,
              writable: false,
              configurable: true
            });
          }
          if (typeof ngDevMode === "undefined" || ngDevMode) {
            warnWriteOnlyMarker(processor, materialized);
          }
          node[key] = materialized;
          const backingStore = node[NODE_STORE_SYMBOL];
          if (backingStore && backingStore !== node) {
            backingStore[key] = materialized;
          }
          processed = true;
        } catch (err) {
          if (typeof ngDevMode === "undefined" || ngDevMode) {
            console.error(
              `SignalTree: Failed to materialize marker at "${pathString}"`,
              err
            );
          }
        }
        break;
      }
    }
    if (!processed && value != null) {
      if (isNodeAccessor(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      } else if (typeof value === "object" && !Array.isArray(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      }
    }
  }
}

// packages/kernel/src/lib/internals/observation-substrate.ts
var OBSERVATION = /* @__PURE__ */ new WeakMap();
var BRANCH_SCOPES = /* @__PURE__ */ new WeakMap();
function inheritObservationForAddedMember(parent, child) {
  const scopes = BRANCH_SCOPES.get(nodeStoreOf(parent) ?? parent);
  if (!scopes) return;
  for (const scope of scopes) scope.visit(child);
}
function installDormantObservation(leaf2) {
  OBSERVATION.set(leaf2, {
    claims: 0,
    positionId: void 0,
    releaseMutationObserver: () => void 0
  });
}

// packages/kernel/src/lib/internals/root-source.ts
var ROOT_AUTHORITIES = /* @__PURE__ */ new WeakMap();
function defineRootTree(rootAccessor, authority) {
  ROOT_AUTHORITIES.set(rootAccessor, authority);
}

// packages/kernel/src/lib/internals/utilities/deep-equal.ts
function deepEqual(a, b) {
  return equalsInner(a, b, 0, void 0);
}
var CYCLE_GUARD_DEPTH = 64;
function equalsInner(a, b, depth, seen) {
  if (a === b) return true;
  if (a == null || b == null) return a === b;
  const typeA = typeof a;
  const typeB = typeof b;
  if (typeA !== typeB) return false;
  if (typeA !== "object") return a !== a && b !== b;
  if (depth >= CYCLE_GUARD_DEPTH) {
    seen ??= /* @__PURE__ */ new WeakMap();
    if (seen.get(a) === b) return true;
    seen.set(a, b);
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    const bArr = b;
    for (let i = 0; i < a.length; i++) {
      const x = a[i];
      const y = bArr[i];
      if (x === y) continue;
      if (!equalsInner(x, y, depth + 1, seen)) return false;
    }
    return true;
  }
  if (Array.isArray(b)) return false;
  if (a instanceof Date && b instanceof Date) {
    try {
      const ta = a.getTime();
      const tb = b.getTime();
      return ta === tb || ta !== ta && tb !== tb;
    } catch {
      return false;
    }
  }
  if (a instanceof RegExp && b instanceof RegExp) {
    return a.source === b.source && a.flags === b.flags;
  }
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    for (const [key, value] of a) {
      if (!b.has(key) || !equalsInner(value, b.get(key), depth + 1, seen))
        return false;
    }
    return true;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    for (const value of a) {
      if (!b.has(value)) return false;
    }
    return true;
  }
  if (a instanceof Error && b instanceof Error) {
    if (a.name !== b.name || a.message !== b.message) return false;
  } else if (a instanceof Number && b instanceof Number || a instanceof String && b instanceof String || a instanceof Boolean && b instanceof Boolean) {
    const va = a.valueOf();
    const vb = b.valueOf();
    if (!(va === vb || va !== va && vb !== vb)) return false;
  }
  try {
    if (a.constructor !== b.constructor) {
      return false;
    }
  } catch {
    return false;
  }
  const objA = a;
  const objB = b;
  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  const hasOwn = Object.prototype.hasOwnProperty;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!hasOwn.call(objB, key)) return false;
    const x = objA[key];
    const y = objB[key];
    if (x === y) continue;
    if (!equalsInner(x, y, depth + 1, seen)) return false;
  }
  return true;
}

// packages/kernel/src/lib/internals/utilities/is-built-in-object.ts
function isBuiltInObject(value) {
  if (value === null || value === void 0) return false;
  if (value instanceof Date || value instanceof RegExp || typeof value === "function" || value instanceof Map || value instanceof Set || value instanceof WeakMap || value instanceof WeakSet || value instanceof ArrayBuffer || value instanceof DataView || value instanceof Error || value instanceof Promise) {
    return true;
  }
  if (value instanceof Int8Array || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Int16Array || value instanceof Uint16Array || value instanceof Int32Array || value instanceof Uint32Array || value instanceof Float32Array || value instanceof Float64Array || value instanceof BigInt64Array || value instanceof BigUint64Array) {
    return true;
  }
  if (typeof window !== "undefined") {
    if (value instanceof URL || value instanceof URLSearchParams || value instanceof FormData || value instanceof Blob || typeof File !== "undefined" && value instanceof File || typeof FileList !== "undefined" && value instanceof FileList || typeof Headers !== "undefined" && value instanceof Headers || typeof Request !== "undefined" && value instanceof Request || typeof Response !== "undefined" && value instanceof Response || typeof AbortController !== "undefined" && value instanceof AbortController || typeof AbortSignal !== "undefined" && value instanceof AbortSignal) {
      return true;
    }
  }
  try {
    const NodeBuffer = globalThis?.Buffer;
    if (NodeBuffer && value instanceof NodeBuffer) {
      return true;
    }
  } catch {
  }
  return false;
}

// packages/kernel/src/lib/utils.ts
var isReactiveStateValue = isTreeCell;
function warnUnwrapSkipped(key) {
  console.error(
    `SignalTree: "${key}" OMITTED from snapshot \u2014 value is a function that is neither signal nor node accessor. [ST2008]`
  );
}
function isEntityMapMarker(value) {
  return Boolean(
    value && typeof value === "object" && value.__isEntityMap === true
  );
}
function isMemoisable(node) {
  return isSnapshotNode(node);
}
function materializeNode(store) {
  if (!isMemoisable(store)) return unwrap(store);
  return materializeSnapshotNode(store, () => unwrap(store));
}
var DERIVED_STAMP = Symbol.for("SignalTree:Derived");
function stampDerived(sig) {
  if (typeof sig === "function") markTreeCell(sig);
  if (isTraversableNode(sig) && typeof sig.set !== "function") {
    Object.defineProperty(sig, DERIVED_STAMP, {
      value: true,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  return sig;
}
function unwrap(node) {
  if (node === null || node === void 0) {
    return node;
  }
  if (isNodeAccessor(node)) {
    const target = snapshotNodeKey(node);
    return isMemoisable(node) ? materializeSnapshotNode(node, () => buildFromStore(target)) : buildFromStore(target);
  }
  if (isReactiveStateValue(node)) {
    return node();
  }
  if (typeof node !== "object") {
    return node;
  }
  if (Array.isArray(node)) {
    return node;
  }
  if (isBuiltInObject(node)) {
    return node;
  }
  return buildFromStore(node);
}
function unwrapBranchForWriteCapture(node) {
  return isNodeAccessor(node) ? buildFromStore(snapshotNodeKey(node), true) : unwrap(node);
}
function buildFromStore(node, uncachedBranches = false) {
  const own = snapshotMarkerNode(node);
  if (own) return own.value;
  const result = {};
  if (hasDormantMembers(node)) {
    for (const key of dormantKeys(node)) {
      const dormant = node[key];
      if (typeof dormant === "function") dormant();
    }
  }
  for (const key in node) {
    if (!Object.prototype.hasOwnProperty.call(node, key)) continue;
    const value = node[key];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshot = snapshotMarkerNode(value, node);
    if (markerSnapshot) {
      result[key] = markerSnapshot.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnUnwrapSkipped(key);
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      bindSnapshotParent(value, node);
      result[key] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[key] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[key] = unwrap(value);
    } else {
      result[key] = value;
    }
  }
  const symbols = Object.getOwnPropertySymbols(node);
  for (const sym of symbols) {
    if (typeof sym.description === "string" && sym.description.startsWith("SignalTree:")) {
      continue;
    }
    const value = node[sym];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshotSym = snapshotMarkerNode(value, node);
    if (markerSnapshotSym) {
      result[sym] = markerSnapshotSym.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnUnwrapSkipped(String(sym));
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      result[sym] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[sym] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[sym] = unwrap(value);
    } else {
      result[sym] = value;
    }
  }
  return result;
}

// packages/kernel/src/lib/internals/mutation-capture-runtime.ts
var MUTATION_CAPTURE_RUNTIME = Symbol.for(
  "SignalTree:MutationCaptureRuntime"
);
function createMutationCaptureRuntime() {
  let activeCount = 0;
  const entityListeners = /* @__PURE__ */ new Set();
  const structuralBoundaryListeners = /* @__PURE__ */ new Set();
  const collectionOrderListeners = /* @__PURE__ */ new Set();
  return {
    hasCommittedEntityObservers() {
      return activeCount > 0 && entityListeners.size > 0;
    },
    hasStructuralBoundaryObservers() {
      return activeCount > 0 && structuralBoundaryListeners.size > 0;
    },
    subscribeStructuralBoundary(listener) {
      structuralBoundaryListeners.add(listener);
      return () => {
        structuralBoundaryListeners.delete(listener);
      };
    },
    publishCommittedEntity(capture) {
      if (activeCount === 0) return;
      const listeners2 = capture.structuralFrontier ? [...entityListeners, ...structuralBoundaryListeners] : [...entityListeners];
      for (const listener of listeners2) {
        try {
          listener(capture);
        } catch (error) {
          reportContainedObserverError({
            error,
            operation: "transaction:listener"
          });
        }
      }
    },
    subscribeCommittedEntity(listener) {
      entityListeners.add(listener);
      return () => {
        entityListeners.delete(listener);
      };
    },
    isCaptureActive() {
      return activeCount > 0;
    },
    activateCapture() {
      activeCount += 1;
      let released = false;
      return () => {
        if (released) {
          return;
        }
        released = true;
        activeCount = Math.max(0, activeCount - 1);
      };
    },
    publishCollectionOrder(capture) {
      if (activeCount === 0) {
        return;
      }
      for (const listener of [...collectionOrderListeners]) {
        listener(capture);
      }
    },
    subscribeCollectionOrder(listener) {
      collectionOrderListeners.add(listener);
      return () => collectionOrderListeners.delete(listener);
    }
  };
}
function getMutationCaptureRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[MUTATION_CAPTURE_RUNTIME];
}

// packages/kernel/src/lib/internals/tree-scalar-slot-runtime.ts
var ScalarSlotMutationFrameImpl = class {
  constructor(baseRevision, getCommittedRevision, readValue, commitValues, assertSlotIndex, prepareValues) {
    this.baseRevision = baseRevision;
    this.getCommittedRevision = getCommittedRevision;
    this.readValue = readValue;
    this.commitValues = commitValues;
    this.assertSlotIndex = assertSlotIndex;
    this.prepareValues = prepareValues;
  }
  staged = /* @__PURE__ */ new Map();
  closed = false;
  set(slotIndex, value) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    this.staged.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    const current = this.staged.has(slotIndex) ? this.staged.get(slotIndex) : this.readValue(slotIndex);
    this.staged.set(slotIndex, updater(current));
  }
  discard() {
    this.assertOpen();
    this.closed = true;
    this.staged.clear();
  }
  prepareCommit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) throw new Error("Stale scalar preparation");
    return this.prepareValues(this.staged, options);
  }
  commit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) {
      throw new Error("ScalarSlotMutationFrame base revision is stale.");
    }
    if (this.staged.size > 0) {
      return this.commitValues(this.staged, options);
    }
    return {
      revision: this.getCommittedRevision(),
      changedSlots: []
    };
  }
  assertOpen() {
    if (this.closed) {
      throw new Error("ScalarSlotMutationFrame is already closed.");
    }
  }
};
function createTreeScalarSlotRuntime(physicalCommitClock) {
  const values = [];
  const inspectionBaseline = /* @__PURE__ */ new Map();
  const equalities = [];
  const slotByPositionId = /* @__PURE__ */ new Map();
  let revision = 0;
  const getCommittedRevision = () => physicalCommitClock?.revision() ?? revision;
  const advanceRevision = () => {
    const nextRevision = physicalCommitClock?.advance();
    if (nextRevision !== void 0) {
      return nextRevision;
    }
    revision += 1;
    return revision;
  };
  const assertSlotIndex = (slotIndex) => {
    if (!Number.isInteger(slotIndex) || slotIndex < 0 || slotIndex >= values.length) {
      throw new Error(`Scalar slot index ${slotIndex} is out of bounds.`);
    }
  };
  const collectSlotChanges = (staged) => {
    const changed = [];
    for (const [slotIndex, nextValue] of staged) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      if (!equalities[slotIndex](values[slotIndex], nextValue)) {
        changed.push({ slotIndex, nextValue });
      }
    }
    return changed;
  };
  const prepareSlots = (staged, options) => {
    const base = getCommittedRevision();
    const changed = collectSlotChanges(staged);
    const physical = new Set(changed.map((x) => x.slotIndex));
    const inspection = getActiveWriteContext()?.participation === "inspection";
    const shadowPlans = [];
    for (const [slotIndex, nextValue] of staged) {
      const has = inspectionBaseline.has(slotIndex);
      const before = has ? inspectionBaseline.get(slotIndex) : values[slotIndex];
      const equal = has ? equalities[slotIndex](before, nextValue) : !physical.has(slotIndex);
      const keep = inspection && !equal;
      if (keep !== has || keep && !Object.is(inspectionBaseline.get(slotIndex), before)) shadowPlans.push({ slotIndex, keep, value: before });
    }
    if (getCommittedRevision() !== base) throw new Error("Reentrant scalar preparation");
    let used = false;
    return () => {
      if (used) throw new Error("Prepared scalar commit already used");
      if (getCommittedRevision() !== base) throw new Error("Stale prepared scalar commit");
      used = true;
      for (const { slotIndex, nextValue } of changed) values[slotIndex] = nextValue;
      for (const p of shadowPlans) {
        if (p.keep) inspectionBaseline.set(p.slotIndex, p.value);
        else inspectionBaseline.delete(p.slotIndex);
      }
      const revision2 = (changed.length || shadowPlans.length) && options?.advanceRevision !== false ? advanceRevision() : getCommittedRevision();
      return { revision: revision2, changedSlots: changed.map((x) => x.slotIndex) };
    };
  };
  const commitSlots = (staged, options) => prepareSlots(staged, options)();
  const commitSlotValue = (slotIndex, nextValue, options) => commitSlots(/* @__PURE__ */ new Map([[slotIndex, nextValue]]), options).changedSlots.length > 0;
  const commitSlot = (slotIndex, nextValue, options) => {
    const changed = commitSlotValue(slotIndex, nextValue, options);
    return changed ? { revision: getCommittedRevision(), changed: true, slot: slotIndex } : { revision: getCommittedRevision(), changed: false };
  };
  return {
    createSlot(initialValue, equal, positionId) {
      const slotIndex = values.length;
      values.push(initialValue);
      equalities.push(equal);
      if (positionId !== void 0) {
        slotByPositionId.set(positionId, slotIndex);
      }
      return slotIndex;
    },
    readSlot(slotIndex) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotReads");
      }
      return values[slotIndex];
    },
    needsAuthorityAdmission(slotIndex) {
      return inspectionBaseline.has(slotIndex) && getActiveWriteContext()?.participation !== "inspection";
    },
    readRecordSlot(slotIndex) {
      return getActiveWriteContext()?.participation !== "inspection" && inspectionBaseline.has(slotIndex) ? inspectionBaseline.get(slotIndex) : values[slotIndex];
    },
    commitRecorded(slotIndex, value, prepare) {
      assertSlotIndex(slotIndex);
      const base = getCommittedRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      const equal = equalities[slotIndex](values[slotIndex], value);
      if (getCommittedRevision() !== base) throw new Error("Scalar equality reentered physical installation");
      const inspection = getActiveWriteContext()?.participation === "inspection";
      const shadowed = inspectionBaseline.has(slotIndex);
      const ordinaryBefore = shadowed ? inspectionBaseline.get(slotIndex) : values[slotIndex];
      const authorityEqual = shadowed ? equalities[slotIndex](ordinaryBefore, value) : equal;
      if (getCommittedRevision() !== base) throw new Error("Scalar authority equality reentered installation");
      const semanticChanged = inspection ? !equal : !authorityEqual;
      if (equal && !semanticChanged) {
        if (!inspection) inspectionBaseline.delete(slotIndex);
        return { changed: false, physicalChanged: false };
      }
      const plan = semanticChanged ? prepare?.() : void 0;
      if (getCommittedRevision() !== base) throw new Error("Terminal preparation reentered physical installation");
      if (inspection) {
        if (authorityEqual) inspectionBaseline.delete(slotIndex);
        else if (!shadowed) inspectionBaseline.set(slotIndex, ordinaryBefore);
      } else inspectionBaseline.delete(slotIndex);
      values[slotIndex] = value;
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotWrites");
      }
      if (plan) {
        installTerminalRecord(plan);
      }
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return { changed: semanticChanged, physicalChanged: !equal };
    },
    commitSlot(slotIndex, value) {
      return commitSlot(slotIndex, value);
    },
    commitSlotValue(slotIndex, value) {
      return commitSlotValue(slotIndex, value);
    },
    updateSlot(slotIndex, updater) {
      assertSlotIndex(slotIndex);
      return commitSlot(slotIndex, updater(values[slotIndex]));
    },
    beginFrame() {
      return new ScalarSlotMutationFrameImpl(
        getCommittedRevision(),
        getCommittedRevision,
        (slotIndex) => values[slotIndex],
        commitSlots,
        assertSlotIndex,
        prepareSlots
      );
    },
    resolveScalarSlot(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return slotByPositionId.get(positionId);
    },
    revision() {
      return getCommittedRevision();
    },
    slotCount() {
      return values.length;
    }
  };
}

// packages/kernel/src/lib/internals/tree-scalar-leaf-runtime.ts
var ScalarSlotPublication = class {
  constructor(locations) {
    this.locations = locations;
  }
  bindings = [];
  bind(slotIndex, binding) {
    this.bindings[slotIndex] = binding;
  }
  publish(result) {
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications", result.changedSlots.length);
    }
    const publishers = result.changedSlots.flatMap((slotIndex) => {
      const binding = this.bindings[slotIndex];
      return binding ? [binding] : [];
    });
    this.locations.publish(publishers);
  }
  prepareSlot(slotIndex, changed, force = false) {
    if (!changed && !force) {
      return false;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications");
    }
    return true;
  }
};
var ScalarSlotMutationFrameOrchestrator = class {
  constructor(frame, publication) {
    this.frame = frame;
    this.publication = publication;
  }
  set(slotIndex, value) {
    this.frame.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.frame.update(slotIndex, updater);
  }
  discard() {
    this.frame.discard();
  }
  prepareCommit(options) {
    const install = this.frame.prepareCommit({ advanceRevision: options?.advanceRevision });
    return () => {
      const result = install();
      if (options?.publish !== false) this.publication.publish(result);
      return result;
    };
  }
  commit(options) {
    const result = this.frame.commit({
      advanceRevision: options?.advanceRevision
    });
    if (options?.publish !== false) {
      this.publication.publish(result);
    }
    return result;
  }
};
function createScalarLeaf(kernel, publication, locations, slotIndex, liveness) {
  const holder = {};
  const read2 = (stored) => {
    if (!stored && liveness.absence?.isAbsent(holder.leaf)) {
      return void 0;
    }
    return stored ? kernel.readRecordSlot(slotIndex) : kernel.readSlot(slotIndex);
  };
  const binding = locations.createWritable(read2, (value, _intent, prepare) => {
    const changedValue = kernel.commitRecorded(slotIndex, value, prepare);
    const result = { changed: changedValue.physicalChanged };
    const reAdded = liveness.absence?.reAdd(holder.leaf) === true;
    const changed = publication.prepareSlot(slotIndex, result.changed, reAdded);
    return { changed: changedValue.changed || reAdded, physicalChanged: changed };
  });
  binding.needsAuthorityAdmission = () => kernel.needsAuthorityAdmission(slotIndex);
  const leaf2 = binding.location;
  holder.leaf = leaf2;
  return { leaf: leaf2, binding };
}
function createTreeScalarLeafRuntime(physicalCommitClock, locations = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const kernel = createTreeScalarSlotRuntime(physicalCommitClock);
  const publication = new ScalarSlotPublication(locations);
  const leafByPositionId = /* @__PURE__ */ new Map();
  const liveness = {};
  return {
    enableAbsence(absence) {
      liveness.absence = absence;
    },
    disableAbsence() {
      liveness.absence = void 0;
    },
    createLeaf(initialValue, equal, positionId) {
      const slotIndex = kernel.createSlot(initialValue, equal, positionId);
      const { leaf: leaf2, binding } = createScalarLeaf(
        kernel,
        publication,
        locations,
        slotIndex,
        liveness
      );
      publication.bind(slotIndex, binding);
      if (positionId !== void 0) {
        leafByPositionId.set(positionId, leaf2);
      }
      return leaf2;
    },
    beginFrame() {
      return new ScalarSlotMutationFrameOrchestrator(
        kernel.beginFrame(),
        publication
      );
    },
    runInvalidationGroup(run) {
      locations.runInvalidationGroup(run);
    },
    publishPrepared(result) {
      publication.publish(result);
    },
    resolveScalarSlot(positionId) {
      return kernel.resolveScalarSlot(positionId);
    },
    resolveScalarLeaf(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return leafByPositionId.get(positionId);
    },
    revision() {
      return kernel.revision();
    },
    slotCount() {
      return kernel.slotCount();
    }
  };
}

// packages/kernel/src/lib/internals/physical-commit-clock.ts
var PHYSICAL_COMMIT_CLOCK = Symbol.for("SignalTree:PhysicalCommitClock");
function createPhysicalCommitClock() {
  let revision = 0;
  return {
    revision() {
      return revision;
    },
    advance() {
      revision += 1;
      return revision;
    }
  };
}
function definePhysicalCommitClock(node, clock) {
  Object.defineProperty(node, PHYSICAL_COMMIT_CLOCK, {
    value: clock,
    enumerable: false,
    configurable: true
  });
}
function getPhysicalCommitClock(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[PHYSICAL_COMMIT_CLOCK];
}

// packages/kernel/src/lib/internals/tree-capabilities.ts
var TREE_CAPABILITY_ORDER = [
  "mutation-capture",
  "position-topology",
  "causal-runtime",
  "temporal-snapshots"
];
var TREE_CAPABILITY_DEPENDENCIES = {
  "mutation-capture": [],
  "position-topology": [],
  "causal-runtime": ["mutation-capture", "position-topology"],
  "temporal-snapshots": []
};
var canonicalizeCapabilities = (capabilities) => {
  const set = new Set(capabilities);
  return TREE_CAPABILITY_ORDER.filter((capability) => set.has(capability));
};
function collectRequestedTreeCapabilities(enhancerMeta) {
  const requested = /* @__PURE__ */ new Set();
  for (const meta of enhancerMeta) {
    for (const capability of meta?.capabilities ?? []) {
      requested.add(capability);
    }
  }
  return canonicalizeCapabilities(requested);
}
function resolveTreeCapabilities(requestedCapabilities) {
  assertTreeCapabilityGraphAcyclic();
  const requested = canonicalizeCapabilities(requestedCapabilities);
  const resolved = new Set(requested);
  const queue = [...requested];
  while (queue.length > 0) {
    const capability = queue.shift();
    if (!capability) {
      continue;
    }
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      if (resolved.has(dependency)) {
        continue;
      }
      resolved.add(dependency);
      queue.push(dependency);
    }
  }
  return {
    requestedCapabilities: requested,
    resolvedCapabilities: canonicalizeCapabilities(resolved)
  };
}
function assertTreeCapabilityGraphAcyclic() {
  const visiting = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new Set();
  const visit = (capability) => {
    if (visited.has(capability)) {
      return;
    }
    if (visiting.has(capability)) {
      throw new Error(
        `SignalTree: capability dependency cycle detected at "${capability}".`
      );
    }
    visiting.add(capability);
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      visit(dependency);
    }
    visiting.delete(capability);
    visited.add(capability);
  };
  for (const capability of TREE_CAPABILITY_ORDER) {
    visit(capability);
  }
}
var TREE_CAPABILITIES = Symbol.for("SignalTree:TreeCapabilities");
function defineTreeCapabilities(tree, capabilities) {
  Object.defineProperty(tree, TREE_CAPABILITIES, {
    value: capabilities,
    enumerable: false,
    configurable: true
  });
}

// packages/kernel/src/lib/internals/merge-derived.ts
function ensurePathAndGetTarget($, path) {
  if (!path) return $;
  const parts = path.split(".");
  let current = $;
  for (const part of parts) {
    if (!(part in current)) {
      current[part] = {};
    }
    current = current[part];
  }
  return current;
}
function mergeDerivedState($, derivedDef, path = "", locations) {
  if (!derivedDef || typeof derivedDef !== "object") {
    return;
  }
  for (const [key, value] of Object.entries(derivedDef)) {
    const currentPath = path ? `${path}.${key}` : key;
    if (typeof value === "function" && locations) {
      const target = ensurePathAndGetTarget($, path);
      if (key in target && (typeof ngDevMode === "undefined" || ngDevMode)) {
        console.warn(
          `SignalTree: Derived location "${currentPath}" overwrites source state. Consider using a different key to avoid confusion.`
        );
      }
      target[key] = stampDerived(
        locations.createDerived(value)
      );
    } else if (typeof value === "object" && value !== null) {
      const target = ensurePathAndGetTarget($, path);
      if (!(key in target)) {
        target[key] = {};
      } else if (isTreeCell(target[key])) {
        throw new Error(
          `SignalTree: Cannot merge derived object into "${currentPath}" because source is a signal. Either make source an object or use a different key.`
        );
      }
      mergeDerivedState($, value, currentPath, locations);
    } else if (typeof ngDevMode === "undefined" || ngDevMode) {
      console.warn(
        `[SignalTree] [ST2007] Derived "${currentPath}" dropped: the value could not be realized by this tree. Return a computation recipe, a value recognized by the package realization, or a nested object. See ST2007.`
      );
    }
  }
}
function applyDerivedFactory($, factory, locations) {
  mergeDerivedState($, factory($), "", locations);
}

// packages/kernel/src/lib/physical/prepared-placement-visibility.ts
function createPreparedPlacementVisibility(physical, isVisible) {
  const overrides = /* @__PURE__ */ new Map();
  const positions = /* @__PURE__ */ new Map();
  let built = false;
  const visible = (id) => overrides.get(id) ?? isVisible(id);
  function build() {
    if (built) return;
    built = true;
    const present = new Map(
      [...physical.patch].filter(
        (entry) => entry[1].present
      )
    );
    const visited = /* @__PURE__ */ new Set();
    for (const [id, row] of present) {
      if (visited.has(id) || row.beforeSubject !== void 0 && present.has(row.beforeSubject))
        continue;
      const ids = [];
      let next = id;
      while (next !== void 0 && present.has(next) && !visited.has(next)) {
        visited.add(next);
        ids.push(next);
        next = present.get(next)?.afterSubject;
      }
      let size = 1;
      while (size < ids.length) size *= 2;
      const run = { ids, size, counts: new Array(size * 2).fill(0) };
      ids.forEach((subject, at) => {
        positions.set(subject, { run, at });
        run.counts[size + at] = Number(visible(subject));
      });
      for (let i = size - 1; i > 0; i--)
        run.counts[i] = run.counts[i * 2] + run.counts[i * 2 + 1];
    }
  }
  function find(run, lo, hi, reverse, node = 1, left = 0, right = run.size - 1) {
    if (lo > right || hi < left || run.counts[node] === 0) return void 0;
    if (left === right) return left;
    const mid = left + right >>> 1;
    const first = reverse ? find(run, lo, hi, reverse, node * 2 + 1, mid + 1, right) : find(run, lo, hi, reverse, node * 2, left, mid);
    return first ?? (reverse ? find(run, lo, hi, reverse, node * 2, left, mid) : find(run, lo, hi, reverse, node * 2 + 1, mid + 1, right));
  }
  return {
    setVisible(subject, value) {
      overrides.set(subject, value);
      const at = positions.get(subject);
      if (!at) return;
      let n = at.run.size + at.at;
      at.run.counts[n] = Number(value);
      while (n > 1) {
        n >>>= 1;
        at.run.counts[n] = at.run.counts[n * 2] + at.run.counts[n * 2 + 1];
      }
    },
    resolve(start, direction, excluded) {
      build();
      let subject = start;
      const seen = /* @__PURE__ */ new Set();
      while (subject !== void 0 && subject !== excluded && !seen.has(subject)) {
        seen.add(subject);
        const indexed = positions.get(subject);
        if (indexed) {
          const { run, at } = indexed;
          const stop = excluded === void 0 ? void 0 : positions.get(excluded);
          const reverse = direction === "before";
          const bound = stop?.run === run ? stop.at : void 0;
          const lo = reverse ? bound !== void 0 && bound <= at ? bound + 1 : 0 : at;
          const hi = reverse ? at : bound !== void 0 && bound >= at ? bound - 1 : run.ids.length - 1;
          const found = find(run, lo, hi, reverse);
          if (found !== void 0) return run.ids[found];
          if (bound !== void 0 && (reverse ? bound <= at : bound >= at))
            return void 0;
          const edge = physical.patch.get(
            run.ids[reverse ? 0 : run.ids.length - 1]
          );
          subject = edge?.present ? reverse ? edge.beforeSubject : edge.afterSubject : void 0;
        } else {
          if (visible(subject)) return subject;
          const row = physical.read(subject);
          if (!row.present) return void 0;
          subject = direction === "before" ? row.beforeSubject : row.afterSubject;
        }
      }
      return void 0;
    }
  };
}

// packages/kernel/src/lib/internals/entity-value-transition.ts
var ENTITY_VALUE_TRANSITION = Symbol("entity-value-transition");
function entityValueTransition(meta) {
  return meta?.[ENTITY_VALUE_TRANSITION];
}
function withEntityValueTransition(meta, transition2) {
  return transition2 ? { ...meta, [ENTITY_VALUE_TRANSITION]: transition2 } : meta;
}
function mergeEntityValueTransition(left, right, merged) {
  const a = entityValueTransition(left);
  const b = entityValueTransition(right);
  const leftChanges = getEntityOrdinaryChanges(left), rightChanges = getEntityOrdinaryChanges(right);
  if (leftChanges !== void 0 || rightChanges !== void 0)
    merged = withEntityOrdinaryChanges(merged, [...leftChanges ?? [], ...rightChanges ?? []]);
  if (!a || !b || a.subject !== b.subject) return merged;
  return withEntityValueTransition(
    merged,
    Object.freeze({
      ...b,
      physicalBefore: a.physicalBefore,
      ordinaryBefore: a.ordinaryBefore
    })
  );
}
function ordinaryEntityEntry(entry) {
  const transition2 = entityValueTransition(entry.meta);
  return transition2 ? {
    ...entry,
    newValue: transition2.ordinaryAfter,
    oldValue: transition2.ordinaryBefore
  } : entry;
}
var ENTITY_ORDINARY_CHANGES = Symbol("entity-ordinary-changes");
function getEntityOrdinaryChanges(meta) {
  return meta?.[ENTITY_ORDINARY_CHANGES] ?? entityValueTransition(meta)?.ordinaryChanges;
}
function withEntityOrdinaryChanges(meta, changes) {
  return { ...meta, [ENTITY_ORDINARY_CHANGES]: changes };
}
function withoutEntityOrdinaryChanges(meta) {
  if (!meta) return meta;
  const copy = { ...meta };
  delete copy[ENTITY_ORDINARY_CHANGES];
  delete copy[ENTITY_VALUE_TRANSITION];
  return copy;
}

// packages/kernel/src/lib/internals/selected-entity-disposition.ts
var SELECTED_ENTITY_DISPOSITION = Symbol("selected-entity-disposition");
function withSelectedEntityDisposition(meta, changes) {
  const selected = {
    ...meta,
    [SELECTED_ENTITY_DISPOSITION]: true
  };
  return withEntityOrdinaryChanges(selected, changes);
}

// packages/kernel/src/lib/internals/causal-runtime/ordinary-realization.ts
var evidence = /* @__PURE__ */ new WeakMap();
var placementEvidence = /* @__PURE__ */ new WeakMap();
function ordinaryRealization(effects) {
  return evidence.get(effects);
}
function realizationPlacement(effect) {
  return placementEvidence.get(effect);
}
function prepareOrdinaryRealization(ordinary, currentKey) {
  const keys = /* @__PURE__ */ new Map();
  const physical = [];
  const placement = /* @__PURE__ */ new Map();
  for (const effect of ordinary) {
    if (!effect.structural || typeof effect.subjectId !== "number") {
      physical.push(effect);
      continue;
    }
    let owner = keys.get(effect.owner);
    if (!owner) keys.set(effect.owner, owner = /* @__PURE__ */ new Map());
    const subject = effect.subjectId;
    const key = owner.has(subject) ? owner.get(subject) : currentKey(effect.owner, subject);
    if (effect.structural === "remove") {
      owner.set(subject, void 0);
      if (key !== void 0) physical.push(Object.freeze({ ...effect, before: key }));
    } else if (effect.structural === "add") {
      owner.set(subject, effect.after);
      if (key === void 0) physical.push(effect);
      else {
        const transfer = Object.freeze({ ...effect, structural: "rekey", before: key });
        physical.push(transfer);
        placement.set(transfer, effect);
        placementEvidence.set(transfer, effect);
      }
    } else {
      if (key === void 0) throw new Error("Ordinary rekey lifetime has no physical realization");
      owner.set(subject, effect.after);
      physical.push(Object.freeze({ ...effect, before: key }));
    }
  }
  const result = Object.freeze({ ordinary, physical: Object.freeze(physical), placement });
  evidence.set(result.physical, result);
  return result;
}

// packages/kernel/src/lib/physical/entity-placement-stage.ts
var EntityPlacementStage = class {
  constructor(base, head, tail) {
    this.base = base;
    this.head = head;
    this.tail = tail;
  }
  patch = /* @__PURE__ */ new Map();
  read(subject) {
    return this.patch.get(subject) ?? this.base(subject);
  }
  change(subject, change) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement neighbor is absent");
    this.patch.set(subject, { ...row, ...change });
  }
  remove(subject) {
    const row = this.read(subject);
    if (!row.present) return;
    if (row.beforeSubject === void 0) this.head = row.afterSubject;
    else this.change(row.beforeSubject, { afterSubject: row.afterSubject });
    if (row.afterSubject === void 0) this.tail = row.beforeSubject;
    else this.change(row.afterSubject, { beforeSubject: row.beforeSubject });
    this.patch.set(subject, { present: false });
  }
  insert(subject, key, beforeSubject, afterSubject) {
    this.remove(subject);
    const after = afterSubject === void 0 ? void 0 : this.read(afterSubject);
    const before = beforeSubject === void 0 ? void 0 : this.read(beforeSubject);
    if (after?.present) beforeSubject = after.beforeSubject;
    else if (before?.present) afterSubject = before.afterSubject;
    else {
      beforeSubject = this.tail;
      afterSubject = void 0;
    }
    if (beforeSubject === void 0) this.head = subject;
    else this.change(beforeSubject, { afterSubject: subject });
    if (afterSubject === void 0) this.tail = subject;
    else this.change(afterSubject, { beforeSubject: subject });
    this.patch.set(subject, {
      present: true,
      key,
      beforeSubject,
      afterSubject
    });
  }
  snapshot() {
    const subjects = [];
    const seen = /* @__PURE__ */ new Set();
    let subject = this.head;
    while (subject !== void 0) {
      if (seen.has(subject)) throw new Error("Prepared placement cycle");
      seen.add(subject);
      subjects.push(subject);
      const row = this.read(subject);
      if (!row.present)
        throw new Error("Prepared placement contains absent lifetime");
      subject = row.afterSubject;
    }
    return Object.freeze(subjects);
  }
  orderDomain(subjects) {
    const domain = new Set(subjects);
    if (domain.size !== subjects.length)
      throw new Error("Prepared order domain repeats a lifetime");
    for (const subject of subjects)
      if (!this.read(subject).present)
        throw new Error("Prepared order domain contains absent lifetime");
    const current = this.snapshot();
    let index = 0;
    const ordered = Object.freeze(
      current.map(
        (subject) => domain.has(subject) ? subjects[index++] : subject
      )
    );
    this.order(ordered);
    return ordered;
  }
  rekey(subject, key) {
    const row = this.read(subject);
    if (!row.present) throw new Error("Placement rekey lifetime is absent");
    this.patch.set(subject, { ...row, key });
  }
  order(subjects) {
    for (let i = 0; i < subjects.length; i++) {
      const row = this.read(subjects[i]);
      if (!row.present) throw new Error("Order lifetime is absent");
      this.patch.set(subjects[i], {
        ...row,
        beforeSubject: subjects[i - 1],
        afterSubject: subjects[i + 1]
      });
    }
    this.head = subjects[0];
    this.tail = subjects.at(-1);
  }
};

// packages/kernel/src/lib/physical/entity-ordinary-topology.ts
var EntityOrdinaryTopology = class {
  headOverride;
  tailOverride;
  divergent = /* @__PURE__ */ new Map();
  displaced = /* @__PURE__ */ new Map();
  preparePlacement(physical) {
    return new EntityPlacementStage(
      (subject) => this.divergent.get(subject) ?? physical.base(subject),
      this.headOverride ? this.headOverride.value : physical.head,
      this.tailOverride ? this.tailOverride.value : physical.tail
    );
  }
  prepareInstall(ordinary, physical) {
    const updates = /* @__PURE__ */ new Map();
    const ids = /* @__PURE__ */ new Set([...ordinary.patch.keys(), ...physical.patch.keys()]);
    for (const subject of ids) {
      const o = ordinary.read(subject), p = physical.read(subject);
      const same = o.present === p.present && (!o.present || p.present && o.key === p.key && o.beforeSubject === p.beforeSubject && o.afterSubject === p.afterSubject);
      updates.set(
        subject,
        same ? void 0 : o.present ? o : { present: false }
      );
    }
    const head = ordinary.head === physical.head ? void 0 : { value: ordinary.head };
    const tail = ordinary.tail === physical.tail ? void 0 : { value: ordinary.tail };
    return () => {
      for (const [subject, row] of updates) this.install(subject, row);
      this.headOverride = head;
      this.tailOverride = tail;
    };
  }
  read(subject) {
    return this.divergent.get(subject);
  }
  atKey(key) {
    return this.displaced.get(key);
  }
  install(subject, next) {
    const previous = this.divergent.get(subject);
    if (previous?.present && this.displaced.get(previous.key) === subject)
      this.displaced.delete(previous.key);
    if (next === void 0) this.divergent.delete(subject);
    else {
      this.divergent.set(subject, next);
      if (next.present) this.displaced.set(next.key, subject);
    }
  }
  retains(subject) {
    return this.divergent.get(subject)?.present === true;
  }
  clear() {
    this.divergent.clear();
    this.displaced.clear();
    this.headOverride = void 0;
    this.tailOverride = void 0;
  }
};
function ordinaryPresenceRecord(kind, subject, state2) {
  return {
    kind,
    subject,
    key: state2.key,
    value: state2.value,
    beforeSubject: state2.beforeSubject,
    afterSubject: state2.afterSubject
  };
}

// packages/kernel/src/lib/internals/utilities/deep-clone.ts
var globalStructuredClone = typeof globalThis === "object" && globalThis !== null ? globalThis.structuredClone : void 0;
function deepClone(value) {
  if (globalStructuredClone) {
    try {
      return globalStructuredClone(value);
    } catch {
    }
  }
  return cloneValue(value, /* @__PURE__ */ new WeakMap());
}
function cloneValue(value, seen) {
  if (value === null || typeof value !== "object") {
    return value;
  }
  if (typeof value === "function") {
    return value;
  }
  const existing = seen.get(value);
  if (existing) {
    return existing;
  }
  if (value instanceof Date) {
    return new Date(value.getTime());
  }
  if (value instanceof RegExp) {
    return new RegExp(value.source, value.flags);
  }
  if (value instanceof Map) {
    const result2 = /* @__PURE__ */ new Map();
    seen.set(value, result2);
    for (const [key, entryValue] of value) {
      result2.set(cloneValue(key, seen), cloneValue(entryValue, seen));
    }
    return result2;
  }
  if (value instanceof Set) {
    const result2 = /* @__PURE__ */ new Set();
    seen.set(value, result2);
    for (const entry of value) {
      result2.add(cloneValue(entry, seen));
    }
    return result2;
  }
  if (Array.isArray(value)) {
    const result2 = new Array(value.length);
    seen.set(value, result2);
    for (let i = 0; i < value.length; i++) {
      result2[i] = cloneValue(value[i], seen);
    }
    return result2;
  }
  if (ArrayBuffer.isView(value)) {
    if (value instanceof DataView) {
      const bufferClone2 = cloneValue(value.buffer, seen);
      return new DataView(bufferClone2, value.byteOffset, value.byteLength);
    }
    const viewWithSlice = value;
    if (typeof viewWithSlice.slice === "function") {
      return viewWithSlice.slice();
    }
    const bufferClone = cloneValue(
      value.buffer,
      seen
    );
    return new value.constructor(
      bufferClone,
      value.byteOffset,
      value.length
    );
  }
  if (value instanceof ArrayBuffer) {
    return value.slice(0);
  }
  const proto = Object.getPrototypeOf(value);
  const result = proto ? Object.create(proto) : {};
  seen.set(value, result);
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor) continue;
    if ("value" in descriptor) {
      descriptor.value = cloneValue(descriptor.value, seen);
    }
    Object.defineProperty(result, key, descriptor);
  }
  return result;
}

// packages/kernel/src/lib/physical/entity-mutation-frame.ts
var EntityMutationFrame = class {
  constructor(valueStore, structuralStore) {
    this.valueStore = valueStore;
    this.structuralStore = structuralStore;
  }
  /**
   * The staged instructions. Read-only after commit by membership observation
   * (`entity-membership-source.ts`), which derives point deltas from them.
   */
  mutations = [];
  preparedInstructions;
  ordinaryOrder;
  orderEndpoints;
  finalFront;
  finalOrder;
  stageFinalFront(keys) {
    this.finalFront = keys;
  }
  stageFinalOrder(keys) {
    this.finalOrder = keys;
  }
  preparePlacement() {
    const instructions = this.preparedInstructions = this.prepareCommitInstructions();
    const stage = this.structuralStore.preparePlacement();
    const base = this.structuralStore.preparePlacement();
    let beforeOrder = this.ordinaryOrder ? base.snapshot() : void 0;
    for (const mutation of instructions) {
      if (mutation.kind === "create-fresh-subject")
        stage.insert(mutation.subjectId, mutation.key);
      else if (mutation.kind === "tombstone-subject")
        stage.remove(mutation.subjectId);
      else if (mutation.kind === "restore-subject")
        stage.insert(
          mutation.subjectId,
          mutation.key,
          mutation.resolvedPlacement.beforeSubject,
          mutation.resolvedPlacement.afterSubject
        );
      else if (mutation.kind === "transfer-key") {
        stage.rekey(mutation.subjectId, mutation.toKey);
        if (mutation.placement)
          stage.insert(
            mutation.subjectId,
            mutation.toKey,
            mutation.placement.beforeSubject,
            mutation.placement.afterSubject
          );
      }
    }
    const stagedSubjects = this.finalFront || this.finalOrder ? /* @__PURE__ */ new Map() : void 0;
    if (stagedSubjects) {
      for (const [id, row] of stage.patch) {
        if (row.present && !Number.isNaN(row.key) && !stagedSubjects.has(row.key))
          stagedSubjects.set(row.key, id);
      }
    }
    const subjectFor = (key) => stagedSubjects?.get(key) ?? this.structuralStore.subjectIdForKey(key);
    let prefixOrder;
    if (this.finalFront) {
      const ids = this.finalFront.map(subjectFor).filter((id) => id !== void 0);
      const existing = ids.filter((subject) => base.read(subject).present);
      let cursor = base.head;
      let moved = false;
      for (const subject of existing) {
        if (cursor !== subject) {
          moved = true;
          break;
        }
        const row = base.read(subject);
        cursor = row.present ? row.afterSubject : void 0;
      }
      if (moved) beforeOrder = base.snapshot();
      for (const id of ids) stage.remove(id);
      const after = stage.head;
      let before;
      for (let index = 0; index < ids.length; index++) {
        stage.insert(ids[index], this.finalFront[index], before, after);
        before = ids[index];
      }
      if (moved) this.ordinaryOrder = prefixOrder = stage.snapshot();
    }
    if (this.finalOrder)
      stage.order(
        this.finalOrder.map(subjectFor).filter((id) => id !== void 0)
      );
    if (beforeOrder)
      this.orderEndpoints = Object.freeze({
        before: beforeOrder,
        // A later full order changes the prepared stage. Otherwise the prefix
        // domain already is this exact immutable physical-after sequence.
        after: !this.finalOrder && prefixOrder ? prefixOrder : stage.snapshot()
      });
    return stage;
  }
  stageValueReplacement(replacement) {
    this.mutations.push(replacement);
  }
  stageRetainedValueRetirement(retirement) {
    this.mutations.push(retirement);
  }
  stageKeyTransfer(transfer) {
    this.mutations.push(transfer);
  }
  stageSubjectTombstone(tombstone) {
    this.mutations.push(tombstone);
  }
  stageFreshSubject(freshSubject) {
    this.mutations.push(freshSubject);
  }
  stageSubjectRestore(restoration) {
    this.mutations.push(restoration);
  }
  /**
   * @param observeCommitted Supplied only when a committed-entity observer is
   * active. Receives every touched lifetime once, after EVERY prepared
   * instruction has applied and before the caller publishes or notifies, so a
   * multi-row frame is never visible to admission one row at a time. A
   * preparation failure throws before anything applies or is reported.
   */
  commit(observeCommitted, responsibility, structuralFrontier, valueTransitions, installOrdinary) {
    const preparedMutations = this.preparedInstructions ?? this.prepareCommitInstructions();
    const before = observeCommitted ? /* @__PURE__ */ new Map() : void 0;
    if (before) {
      for (const mutation of preparedMutations) {
        const previous = before.get(mutation.subjectId);
        before.set(mutation.subjectId, {
          value: previous ? previous.value : this.structuralStore.activeKeyForSubject(mutation.subjectId) === void 0 ? void 0 : this.valueStore.backingForSubject(mutation.subjectId),
          structural: (previous?.structural ?? false) || mutation.kind !== "replace-value"
        });
      }
    }
    const physicallyChangedSubjectIds = /* @__PURE__ */ new Set();
    const allocatedSubjectIds = [];
    for (const mutation of preparedMutations) {
      if (mutation.kind === "create-fresh-subject") {
        this.structuralStore.createSubject(mutation.subjectId, mutation.key);
        this.valueStore.retainSubjectValue(
          mutation.subjectId,
          mutation.nextValue
        );
        allocatedSubjectIds.push(mutation.subjectId);
        continue;
      }
      if (mutation.kind === "restore-subject") {
        this.structuralStore.restoreSubjectAtResolvedPlacement(
          mutation.subjectId,
          mutation.key,
          mutation.resolvedPlacement,
          mutation.restoreAllowed
        );
        if (mutation.resolvedValue !== void 0) {
          this.valueStore.retainSubjectValue(
            mutation.subjectId,
            mutation.resolvedValue
          );
        }
        physicallyChangedSubjectIds.add(mutation.subjectId);
        continue;
      }
      if (mutation.kind === "replace-value") {
        const transition2 = valueTransitions?.get(mutation);
        if (transition2) this.valueStore.installValueTransition(transition2);
        else
          this.valueStore.retainSubjectValue(
            mutation.subjectId,
            mutation.nextValue
          );
        continue;
      }
      if (mutation.kind === "retire-retained-value") {
        const hadBacking = this.valueStore.retireSubjectValue(
          mutation.subjectId
        );
        if (mutation.forgetLifetime) {
          this.structuralStore.forgetSubject(mutation.subjectId);
        } else {
          this.structuralStore.retireSubject(mutation.subjectId);
        }
        if (hadBacking) {
          physicallyChangedSubjectIds.add(mutation.subjectId);
        }
        continue;
      }
      if (mutation.kind === "transfer-key") {
        this.structuralStore.transferSubject(
          mutation.subjectId,
          mutation.fromKey,
          mutation.toKey
        );
        if (mutation.placement)
          this.structuralStore.placeActiveSubject(
            mutation.subjectId,
            mutation.placement.beforeSubject,
            mutation.placement.afterSubject
          );
        physicallyChangedSubjectIds.add(mutation.subjectId);
        continue;
      }
      this.structuralStore.tombstoneSubject(
        mutation.subjectId,
        mutation.key,
        mutation.restoreAllowed
      );
      physicallyChangedSubjectIds.add(mutation.subjectId);
    }
    if (this.finalFront) this.structuralStore.moveKeysToFront(this.finalFront);
    if (this.finalOrder)
      this.structuralStore.reorderActiveKeys(this.finalOrder);
    if (structuralFrontier) {
      structuralFrontier.after = this.structuralStore.activeOrderFrontier();
    }
    installOrdinary?.();
    if (responsibility) {
      installTerminalRecord(responsibility);
    }
    if (before && observeCommitted) {
      observeCommitted(
        [...before].map(([subject, entry]) => ({
          subject,
          before: entry.value,
          after: this.structuralStore.activeKeyForSubject(subject) === void 0 ? void 0 : this.valueStore.backingForSubject(subject),
          structural: entry.structural
        }))
      );
    }
    return {
      physicallyChangedSubjectIds: [...physicallyChangedSubjectIds],
      allocatedSubjectIds
    };
  }
  prepareCommitInstructions() {
    return this.mutations.map((mutation) => {
      if (mutation.kind === "retire-retained-value" && mutation.forgetLifetime) {
        const state2 = this.structuralStore.stateForSubject(mutation.subjectId);
        if (!state2 || state2.active) {
          throw new Error(
            `Subject ${String(
              mutation.subjectId
            )} must be tombstoned before forgetting its lifetime.`
          );
        }
      }
      if (mutation.kind !== "restore-subject") {
        return mutation;
      }
      return {
        ...mutation,
        resolvedValue: mutation.realizedValue ?? this.valueStore.backingForSubject(mutation.subjectId),
        resolvedPlacement: this.structuralStore.resolveSubjectRestorePlacement(
          mutation.beforeSubject,
          mutation.afterSubject
        )
      };
    });
  }
};

// packages/kernel/src/lib/physical/entity-handle-resolution.ts
function resolveEntityHandle(structuralStore, valueStore, handle) {
  const subject = structuralStore.resolveSubjectHandle(handle);
  if (subject.state !== "active") {
    return subject;
  }
  const value = valueStore.backingForSubject(subject.subjectId);
  return value === void 0 ? {
    state: "missing-value",
    subjectId: subject.subjectId,
    key: subject.key,
    revision: subject.revision
  } : {
    ...subject,
    value
  };
}

// packages/kernel/src/lib/physical/entity-value-store.ts
var EntityValueStore = class {
  retainedEntities = /* @__PURE__ */ new Map();
  inspectionBaselines = /* @__PURE__ */ new Map();
  prepareValueTransition(subject, physicalAfter, fields, previous) {
    const physicalBefore = previous?.physicalAfter ?? this.retainedEntities.get(subject);
    if (fields === "derive") {
      const descriptors = Object.getOwnPropertyDescriptors(physicalAfter);
      let hasAccessors = false;
      for (const field of Object.keys(physicalAfter)) {
        const descriptor = descriptors[field];
        if (!descriptor || "value" in descriptor) continue;
        const value = physicalAfter[field];
        hasAccessors = true;
        descriptors[field] = {
          value,
          enumerable: descriptor.enumerable,
          writable: true,
          configurable: descriptor.configurable
        };
      }
      if (hasAccessors) {
        physicalAfter = Object.create(
          Object.getPrototypeOf(physicalAfter),
          descriptors
        );
      }
      fields = physicalBefore ? [.../* @__PURE__ */ new Set([
        ...Object.keys(physicalBefore),
        ...Object.keys(physicalAfter)
      ])].filter(
        (field) => Object.prototype.hasOwnProperty.call(physicalBefore, field) !== Object.prototype.hasOwnProperty.call(physicalAfter, field) || !Object.is(physicalBefore[field], physicalAfter[field])
      ) : Object.keys(physicalAfter);
    }
    const ordinaryBefore = previous?.ordinaryAfter ?? this.inspectionBaselines.get(subject) ?? physicalBefore;
    let ordinaryAfter = physicalAfter;
    if (getActiveWriteContext()?.participation === "inspection") {
      ordinaryAfter = ordinaryBefore ?? physicalAfter;
    } else if (fields && ordinaryBefore) {
      const merged = { ...ordinaryBefore };
      for (const field of fields) {
        if (Object.prototype.hasOwnProperty.call(physicalAfter, field))
          Object.defineProperty(merged, field, {
            value: physicalAfter[field],
            enumerable: true,
            writable: true,
            configurable: true
          });
        else delete merged[field];
      }
      ordinaryAfter = merged;
    }
    return Object.freeze({
      subject,
      physicalBefore,
      physicalAfter,
      ordinaryBefore,
      ordinaryAfter,
      retainDivergence: ordinaryBefore !== void 0 && !deepEqual(ordinaryAfter, physicalAfter)
    });
  }
  prepareRealizationTransition(subject, physicalAfter, edits) {
    const physicalBefore = this.retainedEntities.get(subject);
    const ordinaryBefore = this.inspectionBaselines.get(subject) ?? physicalBefore;
    if (!ordinaryBefore)
      throw new Error("Point realization ordinary lifetime is unavailable");
    let ordinaryAfter = ordinaryBefore;
    for (const edit of edits) {
      if (edit.kind === "row") {
        ordinaryAfter = deepClone(edit.value);
      } else {
        const next = { ...ordinaryAfter };
        if (edit.present)
          Object.defineProperty(next, edit.field, {
            value: deepClone(edit.value),
            enumerable: true,
            configurable: true,
            writable: true
          });
        else delete next[edit.field];
        ordinaryAfter = next;
      }
    }
    return Object.freeze({
      subject,
      physicalBefore,
      physicalAfter,
      ordinaryBefore,
      ordinaryAfter,
      retainDivergence: !deepEqual(ordinaryAfter, physicalAfter)
    });
  }
  installValueTransition(transition2) {
    if (transition2.retainDivergence)
      this.inspectionBaselines.set(
        transition2.subject,
        transition2.ordinaryAfter
      );
    else this.inspectionBaselines.delete(transition2.subject);
    recordProductionSubstrateStat("valueStoreWrites");
    this.retainedEntities.set(transition2.subject, transition2.physicalAfter);
  }
  ordinaryForSubject(subjectId) {
    return this.inspectionBaselines.get(subjectId) ?? this.retainedEntities.get(subjectId);
  }
  dischargeOrdinaryValue(subjectId) {
    this.inspectionBaselines.delete(subjectId);
  }
  backingForSubject(subjectId) {
    return this.retainedEntities.get(subjectId);
  }
  retainSubjectValue(subjectId, entity) {
    this.inspectionBaselines.delete(subjectId);
    recordProductionSubstrateStat("valueStoreWrites");
    this.retainedEntities.set(subjectId, entity);
  }
  prepareTargetValues(subjects) {
    const target = new Map(this.retainedEntities);
    for (const subject of subjects) {
      target.set(subject.subjectId, subject.value);
    }
    return target;
  }
  installPreparedTargetValues(target) {
    this.retainedEntities = target;
  }
  hasRetainedValueBacking(subjectId) {
    return this.retainedEntities.has(subjectId);
  }
  retireSubjectValue(subjectId) {
    this.inspectionBaselines.delete(subjectId);
    return this.retainedEntities.delete(subjectId);
  }
  clear() {
    this.inspectionBaselines.clear();
    this.retainedEntities.clear();
  }
};

// packages/kernel/src/lib/physical/structural-store.ts
var StructuralStore = class {
  keysCache;
  subjectIds = /* @__PURE__ */ new Map();
  subjectStates = /* @__PURE__ */ new Map();
  subjectRevisions = /* @__PURE__ */ new Map();
  activeNodesByKey = /* @__PURE__ */ new Map();
  activeNodesBySubject = /* @__PURE__ */ new Map();
  nextSubjectId = 1;
  collectionIncarnation = 0;
  activeHead;
  activeTail;
  activeCount = 0;
  orderFrontier = {};
  placementForSubject(subject) {
    const node = this.activeNodesBySubject.get(subject);
    return node === void 0 ? { present: false } : {
      present: true,
      key: node.key,
      beforeSubject: node.prev?.subjectId,
      afterSubject: node.next?.subjectId
    };
  }
  preparePlacement() {
    return new EntityPlacementStage(
      (subject) => this.placementForSubject(subject),
      this.activeHead?.subjectId,
      this.activeTail?.subjectId
    );
  }
  activeOrderFrontier() {
    return this.orderFrontier;
  }
  /** Only a complete, lineage-validated compensation may restore this token. */
  installCompensatedOrderFrontier(frontier) {
    this.orderFrontier = frontier;
  }
  planFreshSubjectIds(count) {
    return Array.from(
      { length: count },
      (_, index) => this.nextSubjectId + index
    );
  }
  allocateFreshSubjectId() {
    const subjectId = this.nextSubjectId;
    this.nextSubjectId += 1;
    return subjectId;
  }
  subjectIdForKey(key) {
    return this.subjectIds.get(key);
  }
  acquireSubjectHandleForKey(key) {
    const subjectId = this.subjectIds.get(key);
    return subjectId === void 0 ? void 0 : {
      subjectId,
      acquiredRevision: this.subjectRevision(subjectId),
      collectionIncarnation: this.collectionIncarnation
    };
  }
  resolveSubjectHandle(handle) {
    if (handle.collectionIncarnation !== this.collectionIncarnation) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    const state2 = this.subjectStates.get(handle.subjectId);
    if (state2 === void 0) {
      return {
        state: "missing",
        subjectId: handle.subjectId,
        acquiredRevision: handle.acquiredRevision
      };
    }
    if (state2.active) {
      if (state2.key === void 0) {
        throw new Error(
          `Active subject ${String(
            handle.subjectId
          )} is missing its active key.`
        );
      }
      return {
        state: "active",
        subjectId: handle.subjectId,
        key: state2.key,
        revision: this.subjectRevision(handle.subjectId)
      };
    }
    return {
      state: "tombstoned",
      subjectId: handle.subjectId,
      restoreAllowed: state2.restoreAllowed,
      revision: this.subjectRevision(handle.subjectId)
    };
  }
  stateForSubject(subjectId) {
    return this.subjectStates.get(subjectId);
  }
  hasSubject(subjectId) {
    return this.subjectStates.has(subjectId);
  }
  subjectRevision(subjectId) {
    return this.subjectRevisions.get(subjectId) ?? 0;
  }
  bumpSubjectRevision(subjectId) {
    this.subjectRevisions.set(subjectId, this.subjectRevision(subjectId) + 1);
  }
  activeKeyForSubject(subjectId) {
    const state2 = this.stateForSubject(subjectId);
    return state2?.active ? state2.key : void 0;
  }
  hasActiveKey(key) {
    return this.subjectIds.has(key);
  }
  activeKeyCount() {
    return this.activeCount;
  }
  /**
   * Active keys in order, shared until the next list or key mutation. Every
   * mutator of the active list (or of a node's key) clears it; a field write
   * changes neither, so reading `ids()` after one no longer re-walks the list.
   * Callers must not mutate the result.
   */
  activeKeysSnapshot() {
    if (this.keysCache) return this.keysCache;
    const keys = [];
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
    }
    this.keysCache = keys;
    return keys;
  }
  /** Fills both arrays from one walk of the active order. */
  snapshotActiveOrder(keys, subjectIds) {
    for (let node = this.activeHead; node !== void 0; node = node.next) {
      keys.push(node.key);
      subjectIds.push(node.subjectId);
    }
  }
  firstActiveKey() {
    return this.activeHead?.key;
  }
  lastActiveKey() {
    return this.activeTail?.key;
  }
  prepareTarget(subjects, order, orderFrontier, prepare) {
    return prepare(
      this.subjectStates,
      this.subjectRevisions,
      subjects,
      order,
      orderFrontier
    );
  }
  installPreparedTarget(target) {
    this.keysCache = void 0;
    this.subjectIds = target.subjectIds;
    this.subjectStates = target.subjectStates;
    this.subjectRevisions = target.subjectRevisions;
    this.activeNodesByKey = target.activeNodesByKey;
    this.activeNodesBySubject = target.activeNodesBySubject;
    this.activeHead = target.activeHead;
    this.activeTail = target.activeTail;
    this.activeCount = target.activeCount;
    this.orderFrontier = target.orderFrontier;
  }
  moveKeysToFront(keys) {
    this.keysCache = void 0;
    const nodes = [
      ...new Set(
        keys.map((key) => this.activeNodesByKey.get(key)).filter((node) => node !== void 0)
      )
    ];
    for (const node of nodes) {
      this.detachNode(node);
    }
    for (let index = nodes.length - 1; index >= 0; index -= 1) {
      this.prependDetachedNode(nodes[index]);
    }
    if (nodes.length > 0) this.orderFrontier = {};
  }
  reorderActiveKeys(keys) {
    let current = this.activeHead;
    let unchanged = true;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) continue;
      if (node !== current) {
        unchanged = false;
        break;
      }
      current = current.next;
    }
    if (unchanged && current === void 0) return;
    this.keysCache = void 0;
    this.activeHead = void 0;
    this.activeTail = void 0;
    for (const node of this.activeNodesByKey.values()) {
      node.prev = void 0;
      node.next = void 0;
    }
    let nextCount = 0;
    for (const key of keys) {
      const node = this.activeNodesByKey.get(key);
      if (node === void 0) {
        continue;
      }
      this.appendDetachedNode(node);
      nextCount += 1;
    }
    this.activeCount = nextCount;
    this.orderFrontier = {};
  }
  neighborSubjectsForKey(key) {
    const node = this.activeNodesByKey.get(key);
    if (node === void 0) {
      return {};
    }
    return {
      beforeSubject: node.prev?.subjectId,
      afterSubject: node.next?.subjectId
    };
  }
  tombstonedSubjectsSnapshot() {
    return [...this.subjectStates.entries()].filter(([, subjectState]) => !subjectState.active).map(([subjectId]) => subjectId).sort((left, right) => left - right);
  }
  createSubject(subjectId, key) {
    recordProductionSubstrateStat("structuralSubjectsCreated");
    this.nextSubjectId = Math.max(this.nextSubjectId, subjectId + 1);
    this.activateSubject(subjectId, key);
    this.subjectRevisions.set(subjectId, 0);
    this.createAndAppendActiveNode(subjectId, key);
    this.orderFrontier = {};
  }
  transferSubject(subjectId, from, to, restoreAllowed = true) {
    recordProductionSubstrateStat("structuralSubjectTransfers");
    const node = this.activeNodesByKey.get(from);
    this.subjectIds.delete(from);
    this.activateSubject(subjectId, to, restoreAllowed);
    if (node === void 0) {
      this.createAndAppendActiveNode(subjectId, to);
      return;
    }
    this.activeNodesByKey.delete(from);
    node.key = to;
    this.keysCache = void 0;
    this.activeNodesByKey.set(to, node);
    this.activeNodesBySubject.set(subjectId, node);
  }
  tombstoneSubject(subjectId, key, restoreAllowed) {
    recordProductionSubstrateStat("structuralSubjectTombstones");
    this.subjectIds.delete(key);
    const node = this.activeNodesByKey.get(key);
    if (node !== void 0) {
      this.unregisterActiveNode(node);
      this.detachNode(node);
      this.activeCount -= 1;
    }
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed
    });
    this.orderFrontier = {};
  }
  restoreSubject(subjectId, key, beforeSubject, afterSubject, restoreAllowed = true) {
    const placement = this.resolveSubjectRestorePlacement(
      beforeSubject,
      afterSubject
    );
    this.restoreSubjectAtResolvedPlacement(
      subjectId,
      key,
      placement,
      restoreAllowed
    );
  }
  resolveSubjectRestorePlacement(beforeSubject, afterSubject) {
    const beforeNode = beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(beforeSubject);
    const afterNode = afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(afterSubject);
    if (beforeNode !== void 0 && afterNode !== void 0) {
      if (this.nodePrecedes(beforeNode, afterNode)) {
        return {
          beforeSubject: beforeNode.subjectId,
          afterSubject: afterNode.subjectId,
          beforeKey: beforeNode.key,
          afterKey: afterNode.key
        };
      }
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (afterNode !== void 0) {
      return {
        beforeSubject: afterNode.prev?.subjectId,
        afterSubject: afterNode.subjectId,
        beforeKey: afterNode.prev?.key,
        afterKey: afterNode.key
      };
    }
    if (beforeNode !== void 0) {
      return {
        beforeSubject: beforeNode.subjectId,
        afterSubject: beforeNode.next?.subjectId,
        beforeKey: beforeNode.key,
        afterKey: beforeNode.next?.key
      };
    }
    return {
      beforeSubject: this.activeTail?.subjectId,
      beforeKey: this.activeTail?.key
    };
  }
  restoreSubjectAtResolvedPlacement(subjectId, key, placement, restoreAllowed = true) {
    this.activateSubject(subjectId, key, restoreAllowed);
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.activeCount += 1;
    this.orderFrontier = {};
    const beforeNode = placement.beforeSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    const afterNode = placement.afterSubject === void 0 ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    if (afterNode !== void 0) {
      this.insertDetachedNodeBefore(node, afterNode);
      return;
    }
    if (beforeNode !== void 0) {
      this.insertDetachedNodeAfter(node, beforeNode);
      return;
    }
    this.appendDetachedNode(node);
  }
  /** Relocate an active lifetime without retiring it or emitting lifecycle effects. */
  placeActiveSubject(subjectId, beforeSubject, afterSubject) {
    const node = this.activeNodesBySubject.get(subjectId);
    if (!node) throw new Error("Placement lifetime is not active");
    if (beforeSubject === subjectId || afterSubject === subjectId)
      throw new Error("Placement cannot name its own lifetime");
    const placement = this.resolveSubjectRestorePlacement(
      beforeSubject,
      afterSubject
    );
    const after = placement.afterSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.afterSubject);
    const before = placement.beforeSubject === subjectId ? void 0 : this.activeNodesBySubject.get(placement.beforeSubject);
    this.detachNode(node);
    if (after) this.insertDetachedNodeBefore(node, after);
    else if (before) this.insertDetachedNodeAfter(node, before);
    else this.appendDetachedNode(node);
    this.keysCache = void 0;
    this.orderFrontier = {};
  }
  retireSubject(subjectId) {
    this.subjectStates.set(subjectId, {
      active: false,
      restoreAllowed: false
    });
  }
  /**
   * Drop a retired subject's lifetime ledger entirely — state AND revision.
   *
   * ⚠️ TRIAL. This is the null hypothesis for "is the ~117 B/retired lifetime
   * record earned?" (docs/architecture/retired-subject-churn.md, open question
   * 2). `retireSubject` above keeps a `{active:false, restoreAllowed:false}`
   * record forever, which is what makes zero-owner churn linear in every subject
   * that ever existed. This deletes it.
   *
   * SAFE ONLY FOR A TERMINAL, ZERO-OWNER RETIREMENT, and the reason is subject
   * id allocation: `nextSubjectId` only ever increases, and `tombstoneSubject`
   * has already removed the key -> subject mapping. A later add of the same
   * business key therefore gets a FRESH subject id and cannot collide with the
   * forgotten one. Deleting the record cannot resurrect or alias a subject.
   *
   * WHAT IT GIVES UP: `resolveSubjectHandle` reports `missing` rather than
   * `tombstoned` for the forgotten subject, and `planRestore`'s
   * "has retired backing and cannot be restored" guard loses its input. Both are
   * acceptable only because a tree with no restoration authority has no path to
   * a restore at all — the guard becomes unreachable rather than unenforced. If
   * a restorer can exist, DO NOT call this.
   */
  forgetSubject(subjectId) {
    this.subjectStates.delete(subjectId);
    this.subjectRevisions.delete(subjectId);
    this.activeNodesBySubject.delete(subjectId);
  }
  clear() {
    this.keysCache = void 0;
    this.subjectIds.clear();
    this.subjectStates.clear();
    this.subjectRevisions.clear();
    this.activeNodesByKey.clear();
    this.activeNodesBySubject.clear();
    this.activeHead = void 0;
    this.activeTail = void 0;
    this.activeCount = 0;
    this.nextSubjectId = 1;
    this.collectionIncarnation += 1;
    this.orderFrontier = {};
  }
  createAndAppendActiveNode(subjectId, key) {
    this.keysCache = void 0;
    const node = {
      key,
      subjectId,
      prev: void 0,
      next: void 0
    };
    this.activeNodesByKey.set(key, node);
    this.activeNodesBySubject.set(subjectId, node);
    this.appendDetachedNode(node);
    this.activeCount += 1;
  }
  unregisterActiveNode(node) {
    this.keysCache = void 0;
    this.activeNodesByKey.delete(node.key);
    this.activeNodesBySubject.delete(node.subjectId);
  }
  prependDetachedNode(node) {
    this.keysCache = void 0;
    node.prev = void 0;
    node.next = this.activeHead;
    if (this.activeHead !== void 0) {
      this.activeHead.prev = node;
    } else {
      this.activeTail = node;
    }
    this.activeHead = node;
  }
  appendDetachedNode(node) {
    this.keysCache = void 0;
    node.next = void 0;
    node.prev = this.activeTail;
    if (this.activeTail !== void 0) {
      this.activeTail.next = node;
    } else {
      this.activeHead = node;
    }
    this.activeTail = node;
  }
  insertDetachedNodeAfter(node, anchor) {
    this.keysCache = void 0;
    node.prev = anchor;
    node.next = anchor.next;
    if (anchor.next !== void 0) {
      anchor.next.prev = node;
    } else {
      this.activeTail = node;
    }
    anchor.next = node;
  }
  insertDetachedNodeBefore(node, anchor) {
    this.keysCache = void 0;
    node.next = anchor;
    node.prev = anchor.prev;
    if (anchor.prev !== void 0) {
      anchor.prev.next = node;
    } else {
      this.activeHead = node;
    }
    anchor.prev = node;
  }
  detachNode(node) {
    this.keysCache = void 0;
    if (node.prev !== void 0) {
      node.prev.next = node.next;
    } else {
      this.activeHead = node.next;
    }
    if (node.next !== void 0) {
      node.next.prev = node.prev;
    } else {
      this.activeTail = node.prev;
    }
    node.prev = void 0;
    node.next = void 0;
  }
  nodePrecedes(left, right) {
    let node = left;
    while (node !== void 0) {
      if (node === right) {
        return true;
      }
      node = node.next;
    }
    return false;
  }
  activateSubject(subjectId, key, restoreAllowed = true) {
    this.subjectIds.set(key, subjectId);
    this.subjectStates.set(subjectId, {
      active: true,
      key,
      restoreAllowed
    });
  }
};

// packages/kernel/src/lib/internals/entity-membership-source.ts
var MEMBERSHIP_FACTS = 0;
var MEMBERSHIP_OPEN = 1;
var MEMBERSHIP_OPEN_ORDER = 2;
var MEMBERSHIP_CLOSE = 3;
var SOURCE = Symbol("SignalTree:EntityMembershipSource");
function defineEntityMembershipSource(node, source) {
  Object.defineProperty(node, SOURCE, { value: source });
}
var HOLDS = /* @__PURE__ */ new WeakMap();
var noop = () => void 0;
function holdEntityMembershipDelivery(root) {
  const registry = getPositionRegistry(root);
  return registry && HOLDS.get(registry)?.() || noop;
}

// packages/kernel/src/lib/internals/entity-projection-seed.ts
var SEED = Symbol("signaltree.entityProjectionSeed");
var LOCATION_BINDING = Symbol("signaltree.entityLocationBinding");
function defineEntityLocationBinding(node, binding) {
  Object.defineProperty(node, LOCATION_BINDING, { value: binding });
}
function defineEntityProjectionSeed(api, produce) {
  Object.defineProperty(api, SEED, {
    value: produce,
    enumerable: false,
    configurable: true
  });
}

// packages/kernel/src/lib/internals/physical-rows.ts
var physicalRows = [];
var taps = { depth: 0 };
function openPhysicalRows(registry) {
  physicalRows.push([registry, taps.depth]);
}

// packages/kernel/src/lib/entity-signal.ts
var WRONG_ENTITY_METHODS = {
  upsert: "upsertOne(entity) / upsertMany(entities)",
  add: "addOne(entity) / addMany(entities)",
  insert: "addOne(entity)",
  update: "updateOne(id, changes) / updateMany(ids, changes)",
  remove: "removeOne(id) / removeMany(ids)",
  delete: "removeOne(id)",
  getAll: "all() (a signal)",
  selectAll: "all() (a signal)",
  selectMany: "where(predicate)",
  selectEntity: "byId(id)",
  addEntities: "addMany(entities)",
  setEntities: "setAll(entities)",
  setProps: "set leaves directly \u2014 entityMap has no props object",
  next: "set leaves directly \u2014 not an RxJS Subject",
  asObservable: "use the signal directly \u2014 not an RxJS Subject"
};
var nextStandaloneEntityPositionId = 1;
var standaloneEntityPositionIdAllocator = () => nextStandaloneEntityPositionId++;
var entityPositionIdAllocatorOverride;
var entityPositionIdNotifyEnabled = true;
function setEntityPositionIdAllocatorForTesting(allocator) {
  entityPositionIdAllocatorOverride = allocator;
}
function setEntityPositionIdNotifyEnabledForTesting(enabled = true) {
  entityPositionIdNotifyEnabled = enabled;
}
function planEntitySubjectReclamation(inventory, options) {
  const retain = [];
  if (inventory.retainedSubjectState) {
    retain.push("subject-lifetime-record");
  }
  if (inventory.retainedValueBacking) {
    retain.push("retained-value-backing");
  }
  if (inventory.activationToken) {
    retain.push("subject-activation-channel");
  }
  if (inventory.nodeFacadeMaterialized) {
    retain.push("row-facade");
  }
  if (inventory.fieldFacadesMaterialized.length > 0) {
    retain.push("field-facades");
  }
  if ((inventory.positionIds?.length ?? 0) > 0) {
    retain.push("ownership-metadata");
  }
  if (inventory.state !== "tombstoned") {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: []
    };
  }
  if (!options.causallyEligible) {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: []
    };
  }
  const retire = [];
  const remaining = [...retain];
  const promote = (resource) => {
    retire.push(resource);
    const index = remaining.indexOf(resource);
    if (index !== -1) {
      remaining.splice(index, 1);
    }
  };
  if (inventory.retainedValueBacking) {
    promote("retained-value-backing");
  }
  if (options.reclaimLifetimeRecord && inventory.retainedSubjectState) {
    promote("subject-lifetime-record");
  }
  return {
    subjectId: inventory.subjectId,
    eligible: true,
    retire,
    retain: remaining,
    unresolved: []
  };
}
function survivingOrderChanged(before, after) {
  const inAfter = new Set(after);
  const inBefore = new Set(before);
  const survivingBefore = before.filter((subject) => inAfter.has(subject));
  const survivingAfter = after.filter((subject) => inBefore.has(subject));
  return survivingBefore.some(
    (subject, index) => subject !== survivingAfter[index]
  );
}
function createEntitySignal(config, pathNotifier, basePath, options) {
  const locations = options?.locationRuntime ?? NEUTRAL_LOCATION_RUNTIME;
  const version = locations.createCell(0);
  const pendingSubjectEpochs = /* @__PURE__ */ new Set();
  const createVersionedProjection = (compute) => {
    let projectedVersion = -1;
    let initialized = false;
    let value;
    return locations.createDerived(() => {
      const currentVersion = version();
      if (!initialized || projectedVersion !== currentVersion) {
        value = compute();
        projectedVersion = currentVersion;
        initialized = true;
      }
      return value;
    });
  };
  function getProjectedEntity(id) {
    const subjectId = structuralStore.subjectIdForKey(id);
    return subjectId === void 0 ? void 0 : valueStore.backingForSubject(subjectId);
  }
  function getProjectedEntries() {
    const entries = [];
    for (const id of structuralStore.activeKeysSnapshot()) {
      const entity = getProjectedEntity(id);
      if (entity !== void 0) {
        entries.push([id, entity]);
      }
    }
    return entries;
  }
  function getProjectedEntities() {
    return getProjectedEntries().map(([, entity]) => entity);
  }
  const absent = () => isAbsentMember(api);
  const rowAbsent = () => {
    if (!absent()) return false;
    if (!physicalRows.length) return true;
    const registry = getPositionRegistry(api);
    return !physicalRows.some(
      ([open, depth]) => open === registry && depth === taps.depth
    );
  };
  const presentEntity = (id) => rowAbsent() ? void 0 : getProjectedEntity(id);
  const presentEntries = () => absent() ? [] : getProjectedEntries();
  const presentEntities = () => absent() ? [] : getProjectedEntities();
  function acquireEntityHandleForTesting(id) {
    return structuralStore.acquireSubjectHandleForKey(id);
  }
  function resolveEntityHandleForTesting(handle) {
    return resolveEntityHandle(structuralStore, valueStore, handle);
  }
  function rebuildActiveProjectionFromOwners() {
    return new Map(getProjectedEntries());
  }
  function createEntityMutationFrame() {
    return new EntityMutationFrame(valueStore, structuralStore);
  }
  function preparePointValues(values) {
    const prepared = values.map(({ subjectId, key, value, edits }) => {
      if (structuralStore.activeKeyForSubject(subjectId) !== key) {
        throw new Error(
          "Point realization subject is no longer active at its key"
        );
      }
      const before = valueStore.backingForSubject(subjectId);
      const after = deepClone(value);
      return {
        subjectId,
        key,
        before,
        after,
        transition: valueStore.prepareRealizationTransition(
          subjectId,
          after,
          edits
        ),
        changed: !deepEqual(before, after),
        epoch: subjectEpochs.get(subjectId)
      };
    });
    return {
      install() {
        for (const row of prepared)
          valueStore.installValueTransition(row.transition);
      },
      invalidate() {
        let failed = false;
        let firstError;
        const stage = (fn) => {
          try {
            fn();
          } catch (error) {
            if (!failed) {
              failed = true;
              firstError = error;
            }
          }
        };
        for (const row of prepared) {
          const epoch = row.epoch;
          if (epoch) stage(() => advanceEpochHandle(epoch));
        }
        stage(() => updateSignals());
        if (failed) throw firstError;
      },
      publish() {
        for (const row of prepared) {
          pathNotifier.notify(
            `${basePath}.${String(row.key)}`,
            row.after,
            row.before,
            basePath,
            [row.subjectId],
            getPositionIdsForNotify(),
            withEntityValueTransition(
              {
                ...ambientMeta() ?? {},
                intent: "system",
                participation: "realized"
              },
              row.transition
            )
          );
          if (row.changed) emitTap("onUpdate", row.key, row.after, row.after);
        }
      }
    };
  }
  function readTransitionSource() {
    if (positionId === void 0) {
      throw new Error("Collection transition binding has no owner PositionId");
    }
    const subjects = structuralStore.activeKeysSnapshot().map((key) => {
      const subject = structuralStore.subjectIdForKey(key);
      const value = subject === void 0 ? void 0 : valueStore.backingForSubject(subject);
      if (subject === void 0 || value === void 0) {
        throw new Error(
          "Collection transition source is missing active subject truth"
        );
      }
      return { subject, key, value };
    });
    return {
      owner: positionId,
      subjects,
      order: subjects.map(({ subject }) => subject),
      orderFrontier: structuralStore.activeOrderFrontier()
    };
  }
  function prepareOrdinaryRealization2(effects, physicalAfter, physicalEffects = effects, physicalPlacement, ordinaryOrder) {
    const physical = physicalPlacement ?? structuralStore.preparePlacement();
    if (!physicalPlacement)
      for (const effect of physicalEffects) {
        if (typeof effect.subjectId !== "number") continue;
        const id = effect.subjectId;
        const placement2 = realizationPlacement(effect) ?? effect, context = placement2.structuralContext;
        if (effect.structural === "remove") physical.remove(id);
        else if (effect.structural === "add")
          physical.insert(
            id,
            effect.after,
            context && context.kind !== "rekey" ? context.beforeSubject : void 0,
            context && context.kind !== "rekey" ? context.afterSubject : void 0
          );
        else if (effect.structural === "rekey") {
          physical.rekey(id, effect.after);
          if (realizationPlacement(effect))
            physical.insert(
              id,
              effect.after,
              context && context.kind !== "rekey" ? context.beforeSubject : void 0,
              context && context.kind !== "rekey" ? context.afterSubject : void 0
            );
        }
      }
    const placement = ordinaryTopology.preparePlacement(
      structuralStore.preparePlacement()
    );
    const orderBefore = ordinaryOrder ? placement.snapshot() : void 0;
    const staged = /* @__PURE__ */ new Map();
    const physicalValues = /* @__PURE__ */ new Map();
    const changes = [];
    const read2 = (subject) => {
      const row = placement.read(subject);
      if (!row.present) return { present: false };
      const known = staged.get(subject);
      return {
        ...row,
        value: known?.present ? known.value : valueStore.ordinaryForSubject(subject)
      };
    };
    for (const effect of effects) {
      if (typeof effect.subjectId !== "number") continue;
      const subject = effect.subjectId;
      const previous = read2(subject);
      const storedContext = effect.structuralContext;
      let context = effect.structural === "add" || effect.structural === "remove" ? storedContext && storedContext.kind !== "rekey" ? {
        ...storedContext,
        kind: effect.structural,
        key: effect.structural === "add" ? effect.after : effect.before
      } : void 0 : effect.structural === "rekey" ? {
        kind: "rekey",
        subject,
        beforeKey: effect.before,
        afterKey: effect.after
      } : void 0;
      if (context?.kind === "remove") {
        placement.remove(subject);
        staged.set(subject, { present: false });
        changes.push({
          subject,
          before: previous.present ? previous.value : context.value,
          after: void 0,
          structural: true,
          path: `${basePath}.${String(context.key)}`,
          structuralRecord: context
        });
      } else if (context?.kind === "add") {
        const value = deepClone(context.value);
        placement.insert(
          subject,
          context.key,
          context.beforeSubject,
          context.afterSubject
        );
        const resolved = placement.read(subject);
        if (resolved.present)
          context = {
            ...context,
            beforeSubject: resolved.beforeSubject,
            afterSubject: resolved.afterSubject
          };
        staged.set(subject, {
          present: true,
          key: context.key,
          value,
          beforeSubject: context.beforeSubject,
          afterSubject: context.afterSubject
        });
        physicalValues.set(
          subject,
          physicalAfter?.get(subject) ?? (structuralStore.activeKeyForSubject(subject) === void 0 ? value : valueStore.backingForSubject(subject))
        );
        changes.push({
          subject,
          before: void 0,
          after: value,
          structural: true,
          path: `${basePath}.${String(context.key)}`,
          structuralRecord: { ...context, value }
        });
      } else if (context?.kind === "rekey") {
        if (!previous.present)
          throw new Error("Ordinary rekey realization lacks its lifetime");
        placement.rekey(subject, context.afterKey);
        staged.set(subject, { ...previous, key: context.afterKey });
        changes.push({
          subject,
          before: previous.value,
          after: previous.value,
          structural: true,
          path: `${basePath}.${String(context.beforeKey)}`,
          structuralRecord: context
        });
      } else if (!effect.structural) {
        if (!previous.present)
          throw new Error("Ordinary field realization lacks its lifetime");
        const segments = effect.subjectFieldSegments;
        if (segments === void 0 || segments.length > 1)
          throw new Error(
            "Ordinary realization requires an explicit top-level field address"
          );
        let value;
        if (segments.length === 0) value = deepClone(effect.after);
        else {
          value = { ...previous.value };
          if (effect.fieldPresence?.after !== false)
            Object.defineProperty(value, segments[0], {
              value: deepClone(effect.after),
              enumerable: true,
              configurable: true,
              writable: true
            });
          else delete value[segments[0]];
        }
        staged.set(subject, { ...previous, value });
        const beforeP = physicalValues.get(subject) ?? valueStore.backingForSubject(subject);
        let afterP = physicalAfter?.get(subject);
        if (afterP === void 0) {
          if (segments.length === 0) afterP = value;
          else {
            afterP = { ...beforeP };
            if (effect.fieldPresence?.after !== false)
              Object.defineProperty(afterP, segments[0], {
                value: deepClone(effect.after),
                enumerable: true,
                configurable: true,
                writable: true
              });
            else delete afterP[segments[0]];
          }
        }
        physicalValues.set(subject, afterP);
        changes.push({
          subject,
          before: previous.value,
          after: value,
          structural: false,
          path: `${basePath}.${String(previous.key)}`
        });
      }
    }
    const valueTransitions = [];
    for (const [subject, state2] of staged) {
      if (!state2.present) continue;
      const physical2 = physicalAfter?.get(subject) ?? physicalValues.get(subject) ?? valueStore.backingForSubject(subject);
      valueTransitions.push(
        Object.freeze({
          subject,
          physicalBefore: valueStore.backingForSubject(subject),
          physicalAfter: physical2,
          ordinaryBefore: valueStore.ordinaryForSubject(subject),
          ordinaryAfter: state2.value,
          retainDivergence: !deepEqual(state2.value, physical2)
        })
      );
    }
    if (ordinaryOrder) placement.orderDomain(ordinaryOrder);
    const installPlacement = ordinaryTopology.prepareInstall(
      placement,
      physical
    );
    const ordinaryEndpoints = ordinaryOrder && orderBefore ? Object.freeze({
      before: Object.freeze(
        orderBefore.filter((subject) => ordinaryOrder.includes(subject))
      ),
      after: Object.freeze([...ordinaryOrder]),
      domain: ordinaryOrder
    }) : void 0;
    return {
      changes,
      ordinaryEndpoints,
      install: () => {
        for (const transition2 of valueTransitions)
          valueStore.installValueTransition(transition2);
        for (const [subject, state2] of staged)
          if (!state2.present) valueStore.dischargeOrdinaryValue(subject);
        installPlacement();
      }
    };
  }
  function prepareOrdinaryTopology(changes, physical = structuralStore.preparePlacement(), authoredOrder, authoredDomain) {
    const placement = ordinaryTopology.preparePlacement(
      structuralStore.preparePlacement()
    );
    let visibility;
    const inspection = ambientMeta()?.participation === "inspection";
    const orderBefore = !inspection && authoredOrder ? placement.snapshot() : void 0;
    const staged = /* @__PURE__ */ new Map();
    const keys = /* @__PURE__ */ new Map();
    const selected = [];
    const byStep = [];
    const byPhysicalSubject = /* @__PURE__ */ new Map();
    const read2 = (subject) => {
      const row = placement.read(subject);
      if (!row.present) return { present: false };
      const known = staged.get(subject);
      return {
        ...row,
        value: known?.present ? known.value : valueStore.ordinaryForSubject(subject)
      };
    };
    const atKey = (key) => {
      if (keys.has(key)) return keys.get(key);
      const subject = ordinaryTopology.atKey(key) ?? structuralStore.subjectIdForKey(key);
      if (subject === void 0) return void 0;
      const state2 = read2(subject);
      return state2.present && state2.key === key ? subject : void 0;
    };
    const write = (subject, next) => {
      const previous = read2(subject);
      if (previous.present) keys.set(previous.key, void 0);
      if (!next.present) placement.remove(subject);
      else if (!previous.present)
        placement.insert(
          subject,
          next.key,
          next.beforeSubject,
          next.afterSubject
        );
      else if (previous.key !== next.key) placement.rekey(subject, next.key);
      staged.set(subject, next);
      if (next.present) keys.set(next.key, subject);
      visibility?.setVisible(subject, next.present);
    };
    const record = (kind, subject, state2) => ({
      subject,
      before: kind === "remove" ? state2.value : void 0,
      after: kind === "add" ? state2.value : void 0,
      structural: true,
      path: `${basePath}.${String(state2.key)}`,
      structuralRecord: ordinaryPresenceRecord(kind, subject, state2)
    });
    for (const change of changes) {
      const effect = change.structuralRecord;
      const physicalKey = (effect?.kind === "rekey" ? effect.beforeKey : effect?.key) ?? structuralStore.activeKeyForSubject(change.subject);
      const ordinary = read2(change.subject);
      const group = [];
      if (inspection) {
        group.push(change);
      } else if (change.after === void 0) {
        if (ordinary.present)
          group.push(record("remove", change.subject, ordinary));
        write(change.subject, { present: false });
      } else {
        const key = effect?.kind === "rekey" ? effect.afterKey : physicalKey;
        const binds = !ordinary.present || effect?.kind === "add" || effect?.kind === "rekey";
        if (binds) {
          if (key === void 0)
            throw new Error("Ordinary entity admission lacks a key");
          const displaced = atKey(key);
          if (displaced !== void 0 && displaced !== change.subject) {
            const state2 = read2(displaced);
            if (!state2.present)
              throw new Error(
                "Ordinary occupancy index disagrees with lifetime"
              );
            group.push(record("remove", displaced, state2));
            write(displaced, { present: false });
          }
          const resolveAnchor = (subject, direction) => {
            visibility ??= createPreparedPlacementVisibility(
              physical,
              (id) => placement.read(id).present
            );
            return visibility.resolve(
              subject,
              direction === "beforeSubject" ? "before" : "after",
              change.subject
            );
          };
          const physicalRow = physical.read(change.subject);
          const before = effect?.kind === "add" ? effect.beforeSubject : physicalRow.present ? physicalRow.beforeSubject : void 0;
          const after = effect?.kind === "add" ? effect.afterSubject : physicalRow.present ? physicalRow.afterSubject : void 0;
          const next = ordinary.present ? { ...ordinary, key } : {
            present: true,
            key,
            value: deepClone(change.after),
            beforeSubject: resolveAnchor(before, "beforeSubject"),
            afterSubject: resolveAnchor(after, "afterSubject")
          };
          if (!ordinary.present) {
            placement.insert(
              change.subject,
              next.key,
              next.beforeSubject,
              next.afterSubject
            );
            const resolved = placement.read(change.subject);
            if (resolved.present) Object.assign(next, resolved);
            group.push(record("add", change.subject, next));
          } else if (ordinary.key !== key)
            group.push({
              subject: change.subject,
              before: ordinary.value,
              after: ordinary.value,
              structural: true,
              path: `${basePath}.${String(ordinary.key)}`,
              structuralRecord: {
                kind: "rekey",
                subject: change.subject,
                beforeKey: ordinary.key,
                afterKey: key
              }
            });
          write(change.subject, next);
        } else {
          group.push({ ...change, before: ordinary.value });
          write(change.subject, { ...ordinary, value: change.after });
        }
      }
      const previous = byPhysicalSubject.get(change.subject);
      byPhysicalSubject.set(
        change.subject,
        previous === void 0 ? group : [...previous, ...group]
      );
      byStep.push(group);
      selected.push(...group);
    }
    let ordinaryEndpoints;
    if (!inspection && authoredOrder) {
      const ordered = authoredOrder.filter(
        (subject) => placement.read(subject).present
      );
      const orderAfter = placement.orderDomain(ordered);
      if (orderBefore)
        ordinaryEndpoints = Object.freeze({
          before: orderBefore,
          after: orderAfter,
          domain: Object.freeze([
            .../* @__PURE__ */ new Set([
              ...authoredDomain ?? authoredOrder,
              ...authoredOrder
            ])
          ])
        });
    }
    const installPlacement = ordinaryTopology.prepareInstall(
      placement,
      physical
    );
    return {
      changes: selected,
      byPhysicalSubject,
      byStep,
      install: installPlacement,
      ordinaryEndpoints
    };
  }
  function commitAndProjectEntityMutationFrame(frame, options2) {
    const revision = physicalCommitClock?.revision();
    const changes = [];
    const valueTransitions = /* @__PURE__ */ new Map();
    const valueResults = /* @__PURE__ */ new Map();
    for (const mutation of frame.mutations) {
      if (mutation.kind !== "replace-value") continue;
      const previous = valueResults.get(mutation.subjectId);
      const prepared = valueStore.prepareValueTransition(
        mutation.subjectId,
        mutation.nextValue,
        mutation.authoredFields,
        previous
      );
      valueTransitions.set(mutation, prepared);
      valueResults.set(
        mutation.subjectId,
        previous ? Object.freeze({
          ...prepared,
          physicalBefore: previous.physicalBefore,
          ordinaryBefore: previous.ordinaryBefore
        }) : prepared
      );
    }
    const hasFreshSubjects = frame.mutations.some(
      (mutation) => mutation.kind === "create-fresh-subject"
    );
    const tailKey = hasFreshSubjects ? structuralStore.lastActiveKey() : void 0;
    let tail = tailKey === void 0 ? void 0 : structuralStore.subjectIdForKey(tailKey);
    const changeIndexByMutation = /* @__PURE__ */ new Map();
    for (const m of frame.mutations) {
      changeIndexByMutation.set(m, changes.length);
      const key = "key" in m ? m.key : structuralStore.activeKeyForSubject(m.subjectId);
      const before = valueStore.backingForSubject(m.subjectId);
      const path = `${basePath}.${String(key)}`;
      if (m.kind === "replace-value") {
        const transition2 = valueTransitions.get(m);
        changes.push({
          subject: m.subjectId,
          before: transition2.ordinaryBefore,
          after: transition2.ordinaryAfter,
          structural: false,
          path
        });
      } else if (m.kind === "create-fresh-subject") {
        changes.push({
          subject: m.subjectId,
          before: void 0,
          after: m.nextValue,
          structural: true,
          path,
          structuralRecord: {
            kind: "add",
            subject: m.subjectId,
            key: m.key,
            value: deepClone(m.nextValue),
            beforeSubject: tail
          }
        });
        tail = m.subjectId;
      } else if (m.kind === "tombstone-subject") {
        const neighbors = getNeighborSubjects(m.key);
        changes.push({
          subject: m.subjectId,
          before,
          after: void 0,
          structural: true,
          path,
          structuralRecord: {
            kind: "remove",
            subject: m.subjectId,
            key: m.key,
            value: deepClone(before),
            ...neighbors
          }
        });
      } else if (m.kind === "transfer-key") {
        changes.push({
          subject: m.subjectId,
          before,
          after: before,
          structural: true,
          path: `${basePath}.${String(m.fromKey)}`,
          structuralRecord: {
            kind: "rekey",
            subject: m.subjectId,
            beforeKey: m.fromKey,
            afterKey: m.toKey
          }
        });
      }
    }
    const physicalPlacement = frame.preparePlacement();
    for (let index = 0; index < changes.length; index++) {
      const change = changes[index];
      if (change.structuralRecord?.kind !== "add") continue;
      const row = physicalPlacement.read(change.subject);
      if (row.present)
        changes[index] = {
          ...change,
          structuralRecord: {
            ...change.structuralRecord,
            beforeSubject: row.beforeSubject,
            afterSubject: row.afterSubject
          }
        };
    }
    const ordinaryPlan = prepareOrdinaryTopology(
      changes,
      physicalPlacement,
      frame.ordinaryOrder,
      frame.orderEndpoints?.before
    );
    const valueResultsByStep = frame.mutations.map((mutation) => {
      if (mutation.kind !== "replace-value") return void 0;
      const transition2 = valueTransitions.get(mutation);
      return Object.freeze({
        ...transition2,
        ordinaryChanges: ordinaryPlan.byStep[changeIndexByMutation.get(mutation)]
      });
    });
    for (const [subject, transition2] of valueResults) {
      valueResults.set(
        subject,
        Object.freeze({
          ...transition2,
          ordinaryChanges: ordinaryPlan.byPhysicalSubject.get(subject)
        })
      );
    }
    const structuralFrontier = changes.some((change) => change.structural) && !frame.mutations.some((mutation) => mutation.kind === "restore-subject") ? {
      before: structuralStore.activeOrderFrontier(),
      after: void 0
    } : void 0;
    const responsibility = changes.length ? mutationCaptureRuntime?.prepareEntityResponsibility?.({
      owner: getPositionIds()?.[0],
      ownerPath: basePath,
      meta: ambientMeta(),
      changes: ordinaryPlan.changes,
      structuralFrontier
    }) : void 0;
    if (physicalCommitClock?.revision() !== revision)
      throw new Error(
        "Entity frame responsibility preparation reentered installation"
      );
    const observe = committedEntityObserver(
      structuralFrontier,
      ordinaryPlan.changes
    );
    const result = frame.commit(
      observe ? () => observe(ordinaryPlan.changes) : void 0,
      responsibility,
      structuralFrontier,
      valueTransitions,
      ordinaryPlan.install
    );
    if (options2?.advancePhysicalRevision !== false) {
      physicalCommitClock?.advance();
    }
    membershipTap?.(MEMBERSHIP_FACTS, frame.mutations);
    return {
      ...result,
      valueResults,
      valueResultsByStep,
      ordinaryChanges: ordinaryPlan.byPhysicalSubject,
      ordinaryEndpoints: ordinaryPlan.ordinaryEndpoints,
      orderEndpoints: frame.orderEndpoints
    };
  }
  const computeAll = () => {
    const entities = presentEntities();
    if (config.sortComparer) entities.sort(config.sortComparer);
    return entities;
  };
  const allSignal = createVersionedProjection(computeAll);
  const computeCount = () => absent() ? 0 : structuralStore.activeKeyCount();
  const countSignal = createVersionedProjection(computeCount);
  const fresh = (read2) => (() => {
    version();
    return read2();
  });
  const inTap = (cell, read2) => taps.depth ? fresh(read2) : cell;
  let idsSource;
  let idsValue = [];
  const computeIds = (all) => {
    if (absent()) return [];
    if (config.sortComparer) return all().map((e) => selectId(e));
    const keys = structuralStore.activeKeysSnapshot();
    if (keys !== idsSource) {
      idsSource = keys;
      idsValue = [...keys];
    }
    return idsValue;
  };
  const idsSignal = createVersionedProjection(
    () => computeIds(allSignal)
  );
  const computeMap = () => new Map(presentEntries());
  const mapSignal = createVersionedProjection(computeMap);
  const subjectEpochs = /* @__PURE__ */ new Map();
  const advanceEpochHandle = (handle) => {
    locations.advanceEpoch?.(handle);
  };
  const structuralStore = new StructuralStore();
  let membershipTap;
  function withMembershipGroup(run) {
    const tap = membershipTap;
    tap?.(MEMBERSHIP_OPEN);
    try {
      return run();
    } finally {
      tap?.(MEMBERSHIP_CLOSE);
    }
  }
  const valueStore = new EntityValueStore();
  const ordinaryTopology = new EntityOrdinaryTopology();
  const subjectStateSignals = /* @__PURE__ */ new Map();
  const ownerMetadataEnabled = options?.ownerMetadataEnabled ?? true;
  const subjectMetadataEnabled = options?.subjectMetadataEnabled ?? ownerMetadataEnabled;
  const positionMetadataEnabled = options?.positionMetadataEnabled ?? true;
  const hasRestorationAuthority = options?.hasRestorationAuthority ?? true;
  const ownerId = options?.ownerId;
  const physicalCommitClock = options?.physicalCommitClock;
  const mutationCaptureRuntime = options?.mutationCaptureRuntime;
  let positionId = (options?.positionIdAllocator ?? (positionMetadataEnabled ? entityPositionIdAllocatorOverride ?? standaloneEntityPositionIdAllocator : void 0))?.();
  let lastSubjectIds;
  let callableWriteIntent;
  function withCallableWriteIntent(intent, write) {
    const previous = callableWriteIntent;
    callableWriteIntent = intent;
    try {
      write();
    } finally {
      callableWriteIntent = previous;
    }
  }
  function consumeCallableWriteIntent() {
    const intent = callableWriteIntent;
    callableWriteIntent = void 0;
    return intent;
  }
  function ambientMeta() {
    const active2 = getActiveWriteContext();
    if (ownerId === void 0) return active2;
    return { ...active2 ?? {}, ownerId };
  }
  function getPositionIds() {
    if (positionId === void 0) {
      const registry = getPositionRegistry(api);
      if (registry) {
        const allocated = registry.allocate();
        registry.registerCollectionPath(allocated, basePath);
        const address = getNodeAddress(proxy);
        if (address) registry.registerPositionAddress(allocated, address);
        positionId = allocated;
      }
    }
    return positionId === void 0 ? void 0 : [positionId];
  }
  function getPositionIdsForNotify() {
    return entityPositionIdNotifyEnabled && (positionId !== void 0 || mutationCaptureRuntime?.isCaptureActive()) ? getPositionIds() : void 0;
  }
  function createStructuralEffectMeta(effect, ordinaryChanges) {
    const meta = ambientMeta();
    const physical = { ...meta ?? {}, structuralEffect: effect };
    return ordinaryChanges === void 0 ? physical : withEntityOrdinaryChanges(physical, ordinaryChanges);
  }
  const predicateWindows = /* @__PURE__ */ new Map();
  const warnedPredicates = /* @__PURE__ */ new Set();
  const PREDICATE_CHURN_THRESHOLD = 12;
  const PREDICATE_CHURN_WINDOW_MS = 2e3;
  function warnOnPredicateChurn(method, predicate) {
    const source = String(predicate);
    if (predicateWindows.size > 200 || warnedPredicates.has(source)) return;
    const now = typeof performance !== "undefined" ? performance.now() : Date.now();
    const window2 = predicateWindows.get(source);
    if (!window2 || now - window2.start > PREDICATE_CHURN_WINDOW_MS) {
      predicateWindows.set(source, { count: 1, start: now });
      return;
    }
    window2.count++;
    if (window2.count < PREDICATE_CHURN_THRESHOLD) return;
    warnedPredicates.add(source);
    const perSecond = Math.round(
      window2.count / Math.max(now - window2.start, 1) * 1e3
    );
    console.warn(
      `SignalTree: \`${method}()\` received ${window2.count} DIFFERENT functions with identical source in ${Math.round(now - window2.start)}ms (~${perSecond}/second) \u2014 a rate only change detection produces. Results are memoised per predicate IDENTITY, so an inline arrow misses the cache every cycle and re-scans the collection: measured at 75x a hoisted predicate over 1,000 entities. Hoist it to a stable reference (a class field or module constant) and call \`${method}(thePredicate)()\`. Source: ${source.slice(0, 80)} [ST2026]`
    );
  }
  const rekeyedSubjects = /* @__PURE__ */ new Set();
  function planRekey(from, to) {
    const entity = getProjectedEntity(from);
    if (!entity) {
      throw new Error(`Entity with id ${String(from)} not found`);
    }
    if (from === to) {
      const noOpSubjectId = allocateSubjectId(from);
      return {
        commit() {
          lastSubjectIds = [noOpSubjectId];
        },
        publish() {
        }
      };
    }
    if (structuralStore.hasActiveKey(to)) {
      throw new Error(`Cannot change id to ${String(to)}: already in use`);
    }
    return planPreparedRekey(from, to, allocateSubjectId(from), entity);
  }
  function planPreparedRekey(from, to, subjectId, entity, placement) {
    if (from === to && !placement) {
      return {
        commit() {
          lastSubjectIds = [subjectId];
        },
        publish() {
        }
      };
    }
    let ordinaryChanges;
    const structuralEffect = {
      kind: "rekey",
      subject: subjectId,
      beforeKey: from,
      afterKey: to
    };
    return {
      commit(options2) {
        const transfer = {
          kind: "transfer-key",
          placement,
          fromKey: from,
          toKey: to,
          subjectId
        };
        const frame = createEntityMutationFrame();
        if (placement && !deepEqual(valueStore.backingForSubject(subjectId), entity))
          frame.stageValueReplacement({
            kind: "replace-value",
            key: from,
            subjectId,
            nextValue: entity
          });
        frame.stageKeyTransfer(transfer);
        const result = commitAndProjectEntityMutationFrame(frame, options2);
        ordinaryChanges = result.ordinaryChanges.get(subjectId);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        rekeyedSubjects.add(subjectId);
        lastSubjectIds = [subjectId];
        if (activeIdSignal() === from) {
          replaceLocation(activeIdSignal, to);
        }
        syncEntitySignal(to);
        updateSignals();
      },
      publish(metaOverride) {
        const meta = metaOverride ?? ambientMeta();
        pathNotifier.notify(
          `${basePath}.${String(to)}`,
          entity,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          ordinaryChanges === void 0 ? { ...meta, structuralEffect } : withEntityOrdinaryChanges(
            { ...meta, structuralEffect },
            ordinaryChanges
          )
        );
      }
    };
  }
  const activeIdSignal = locations.createCell(void 0);
  let cachedActiveEntity;
  function publishOrderChange(beforeSubjects, afterSubjects, beforeFrontier, afterFrontier = structuralStore.activeOrderFrontier(), ordinaryEndpoints, selectedDisposition = false) {
    if (positionId === void 0) return;
    mutationCaptureRuntime?.publishCollectionOrder?.({
      owner: positionId,
      ownerPath: basePath,
      beforeSubjects,
      afterSubjects,
      beforeFrontier,
      afterFrontier,
      ordinaryEndpoints,
      meta: selectedDisposition ? withSelectedEntityDisposition(ambientMeta(), []) : ambientMeta()
    });
  }
  function resolveSubjectId(id) {
    return structuralStore.subjectIdForKey(id);
  }
  function resolveSubjectState(subjectId) {
    return structuralStore.stateForSubject(subjectId);
  }
  function getSubjectRevision(subjectId) {
    return structuralStore.subjectRevision(subjectId);
  }
  function bumpSubjectRevision(subjectId) {
    structuralStore.bumpSubjectRevision(subjectId);
  }
  function stageSubjectEpoch(subjectId) {
    const epoch = subjectEpochs.get(subjectId);
    if (epoch) pendingSubjectEpochs.add(epoch);
  }
  function getSubjectEpoch(subjectId) {
    let epoch = subjectEpochs.get(subjectId);
    if (!epoch) {
      epoch = locations.createEpoch ? locations.createEpoch() : neutralEpoch();
      subjectEpochs.set(subjectId, epoch);
    }
    return epoch;
  }
  function neutralEpoch() {
    const cell = locations.createCell(0);
    const epoch = (() => cell());
    epoch.set = (value) => cell(value);
    epoch.update = (fn) => cell(fn);
    epoch.asReadonly = () => cell;
    return epoch;
  }
  function readSubjectEntity(subjectId) {
    getSubjectEpoch(subjectId)();
    return rowAbsent() ? void 0 : valueStore.backingForSubject(subjectId);
  }
  function readEntityByKey(id) {
    const subjectId = resolveSubjectId(id);
    if (subjectId === void 0) return presentEntity(id);
    return readSubjectEntity(subjectId);
  }
  function getSubjectStateSignal(subjectId) {
    const existing = subjectStateSignals.get(subjectId)?.deref();
    if (existing) return existing;
    const created = locations.createCell(0);
    subjectStateSignals.set(subjectId, new WeakRef(created));
    return created;
  }
  function bumpSubjectStateSignal(subjectId) {
    const signal = subjectStateSignals.get(subjectId)?.deref();
    if (signal) deriveLocation(signal, (value) => value + 1);
  }
  function publishSubjectPhysicalChange(subjectId) {
    bumpSubjectRevision(subjectId);
    bumpSubjectStateSignal(subjectId);
  }
  function allocateSubjectId(id) {
    const existing = structuralStore.subjectIdForKey(id);
    if (existing !== void 0) {
      return existing;
    }
    return commitFreshSubject(id);
  }
  function commitFreshSubject(id) {
    const subjectId = structuralStore.allocateFreshSubjectId();
    const physical = structuralStore.preparePlacement();
    const ordinary = ordinaryTopology.preparePlacement(
      structuralStore.preparePlacement()
    );
    physical.insert(subjectId, id);
    const installOrdinary = ordinaryTopology.prepareInstall(ordinary, physical);
    structuralStore.createSubject(subjectId, id);
    installOrdinary();
    physicalCommitClock?.advance();
    return subjectId;
  }
  function rememberSubjectId(id) {
    const resolved = allocateSubjectId(id);
    lastSubjectIds = [resolved];
    return resolved;
  }
  function commitExistingSubjectValue(subjectId, nextValue, fields) {
    const revision = physicalCommitClock?.revision();
    const transition2 = valueStore.prepareValueTransition(
      subjectId,
      nextValue,
      fields
    );
    const ordinaryPlan = prepareOrdinaryTopology([
      {
        subject: subjectId,
        before: transition2.ordinaryBefore,
        after: transition2.ordinaryAfter,
        structural: false,
        path: `${basePath}.${String(
          structuralStore.activeKeyForSubject(subjectId)
        )}`
      }
    ]);
    const capture = committedEntityObserver(void 0, ordinaryPlan.changes);
    const plan = mutationCaptureRuntime?.prepareEntityResponsibility?.({
      owner: getPositionIds()?.[0],
      ownerPath: basePath,
      changes: ordinaryPlan.changes,
      meta: ambientMeta()
    });
    if (physicalCommitClock?.revision() !== revision)
      throw new Error(
        "Entity responsibility preparation reentered installation"
      );
    valueStore.installValueTransition(transition2);
    ordinaryPlan.install();
    if (plan) installTerminalRecord(plan);
    capture?.(ordinaryPlan.changes);
    physicalCommitClock?.advance();
    return Object.freeze({
      ...transition2,
      ordinaryChanges: ordinaryPlan.changes
    });
  }
  function committedEntityObserver(structuralFrontier, preparedChanges) {
    if (!mutationCaptureRuntime?.hasCommittedEntityObservers?.() && !(structuralFrontier && mutationCaptureRuntime?.hasStructuralBoundaryObservers?.()))
      return void 0;
    const owner = getPositionIds()?.[0];
    if (owner === void 0) return void 0;
    const meta = ambientMeta();
    const structuralRecords = structuralFrontier ? preparedChanges?.flatMap((change) => {
      const record = change.structuralRecord;
      if (!record) return [];
      if (record.kind === "rekey") return [record];
      const { value: _value, ...placement } = record;
      return [placement];
    }) : void 0;
    return (changes) => mutationCaptureRuntime.publishCommittedEntity?.({
      owner,
      ownerPath: basePath,
      changes,
      structuralFrontier,
      structuralRecords,
      meta
    });
  }
  function rememberSubjectIds(ids) {
    const resolved = ids.map((id) => allocateSubjectId(id));
    lastSubjectIds = resolved;
    return resolved;
  }
  function findKeyBySubjectId(subjectId) {
    return structuralStore.activeKeyForSubject(subjectId);
  }
  function getNeighborSubjects(id) {
    return structuralStore.neighborSubjectsForKey(id);
  }
  function restoreOne(key, entity, subjectId, beforeSubject, afterSubject) {
    const planned = planRestore(
      key,
      entity,
      subjectId,
      beforeSubject,
      afterSubject
    );
    planned.commit();
    planned.publish();
  }
  function planRestore(key, entity, subjectId, beforeSubject, afterSubject, vacatingKeys) {
    if (structuralStore.hasActiveKey(key) && !vacatingKeys?.has(key)) {
      throw new Error(`Entity with id ${String(key)} already exists`);
    }
    const state2 = resolveSubjectState(subjectId);
    if (state2 && !state2.restoreAllowed) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} has retired backing and cannot be restored.`
      );
    }
    const restoration = {
      kind: "restore-subject",
      key,
      subjectId,
      restoreAllowed: state2?.restoreAllowed ?? true,
      beforeSubject,
      afterSubject,
      realizedValue: entity
    };
    return {
      commit(options2) {
        const frame = createEntityMutationFrame();
        frame.stageSubjectRestore(restoration);
        const result = commitAndProjectEntityMutationFrame(frame, options2);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride) {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          void 0,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...metaOverride ?? ambientMeta() ?? {},
            structuralEffect: {
              kind: "add",
              subject: subjectId,
              key,
              value: deepClone(entity),
              beforeSubject,
              afterSubject
            }
          }
        );
        emitTap("onAdd", entity, key);
      }
    };
  }
  function planFreshAdd(key, entity, subjectId) {
    const existingState = resolveSubjectState(subjectId);
    if (existingState) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} already exists and cannot be realized as fresh.`
      );
    }
    return {
      commit(options2) {
        const frame = createEntityMutationFrame();
        frame.stageFreshSubject({
          kind: "create-fresh-subject",
          key,
          subjectId,
          nextValue: entity
        });
        commitAndProjectEntityMutationFrame(frame, options2);
        lastSubjectIds = [subjectId];
        invalidateNodeCache(key);
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride) {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          void 0,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          metaOverride
        );
        emitTap("onAdd", entity, key);
      }
    };
  }
  function planRemove(key, subjectId) {
    const entity = getProjectedEntity(key);
    if (!entity) {
      throw new Error(`Entity with id ${String(key)} not found`);
    }
    const { beforeSubject, afterSubject } = getNeighborSubjects(key);
    const structuralEffect = {
      kind: "remove",
      subject: subjectId,
      key,
      value: deepClone(entity),
      beforeSubject,
      afterSubject
    };
    const currentState = resolveSubjectState(subjectId);
    const tombstone = {
      kind: "tombstone-subject",
      key,
      subjectId,
      restoreAllowed: currentState?.restoreAllowed ?? true
    };
    return {
      commit(options2) {
        const frame = createEntityMutationFrame();
        frame.stageSubjectTombstone(tombstone);
        const result = commitAndProjectEntityMutationFrame(frame, options2);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        tombstoneSubjectSignal(subjectId);
        updateSignals();
      },
      publish(metaOverride) {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          void 0,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...metaOverride ?? ambientMeta() ?? {},
            structuralEffect
          }
        );
        emitTap("onRemove", key, entity);
      }
    };
  }
  function rewritePendingAddEffect(effect, beforeSubject, afterSubject) {
    effect.beforeSubject = beforeSubject;
    effect.afterSubject = afterSubject;
  }
  function assertSynchronousInterceptorFunction(handler, hookName) {
    if (typeof handler === "function" && handler.constructor?.name === "AsyncFunction") {
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }
  function assertSynchronousInterceptorResult(result, hookName) {
    if (result && typeof result.then === "function") {
      void result.catch(() => void 0);
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }
  function assertSynchronousInterceptors(handlers) {
    assertSynchronousInterceptorFunction(handlers.onAdd, "onAdd");
    assertSynchronousInterceptorFunction(handlers.onUpdate, "onUpdate");
    assertSynchronousInterceptorFunction(handlers.onRemove, "onRemove");
  }
  function interceptAddedEntity(entity) {
    if (interceptsSuppressed) return entity;
    let transformedEntity = entity;
    for (const handler of interceptHandlers) {
      const ctx = {
        block: (reason) => {
          throw new Error(
            `Cannot add entity: ${reason || "blocked by interceptor"}`
          );
        },
        transform: (value) => {
          transformedEntity = value;
        },
        blocked: false,
        blockReason: void 0
      };
      assertSynchronousInterceptorResult(handler.onAdd?.(entity, ctx), "onAdd");
    }
    return transformedEntity;
  }
  function interceptReplacedEntity(id, entity) {
    if (interceptsSuppressed) return entity;
    let replacement = entity;
    for (const handler of interceptHandlers) {
      const ctx = {
        block: (reason) => {
          throw new Error(
            `Cannot replace entity: ${reason || "blocked by interceptor"}`
          );
        },
        transform: (value) => {
          replacement = value;
        },
        blocked: false,
        blockReason: void 0
      };
      assertSynchronousInterceptorResult(
        handler.onUpdate?.(id, entity, ctx),
        "onUpdate"
      );
    }
    return replacement;
  }
  function interceptUpdatedEntity(id, changes) {
    if (interceptsSuppressed) return changes;
    let transformedChanges = changes;
    for (const handler of interceptHandlers) {
      const ctx = {
        block: (reason) => {
          throw new Error(
            `Cannot update entity: ${reason || "blocked by interceptor"}`
          );
        },
        transform: (value) => {
          transformedChanges = value;
        },
        blocked: false,
        blockReason: void 0
      };
      assertSynchronousInterceptorResult(
        handler.onUpdate?.(id, changes, ctx),
        "onUpdate"
      );
    }
    return transformedChanges;
  }
  function addManyInOrder(entities, opts, prepend = false) {
    const mode = opts?.mode ?? "strict";
    const lastPreviousKey = structuralStore.lastActiveKey();
    const toProcess = [];
    const copies = [];
    const earlier = /* @__PURE__ */ new Map();
    for (const entity of entities) {
      const id = deriveId(entity, opts);
      const existingSubjectId = structuralStore.subjectIdForKey(id);
      let processed = earlier.get(id);
      if (existingSubjectId !== void 0 || processed) {
        if (mode === "strict") {
          throw new Error(`Entity with id ${String(id)} already exists`);
        } else if (mode === "skip") {
          continue;
        }
      }
      if (!processed) {
        processed = { entity, id, existingSubjectId };
        earlier.set(id, processed);
        toProcess.push(processed);
      }
      copies.push([processed, entity]);
    }
    if (toProcess.length === 0) return [];
    for (const [processed, entity] of copies) {
      processed.entity = interceptAddedEntity(entity);
    }
    const stagedAdds = toProcess;
    const plannedFreshSubjectIds = structuralStore.planFreshSubjectIds(
      stagedAdds.filter(
        ({ existingSubjectId }) => existingSubjectId === void 0
      ).length
    );
    let plannedFreshIndex = 0;
    const preparedAdds = stagedAdds.map(
      ({ id, entity, existingSubjectId }) => ({
        id,
        entity,
        existingSubjectId,
        // A replacement retains its lifetime; capture what it replaces
        // before the physical frame installs the new value.
        prev: existingSubjectId === void 0 ? void 0 : valueStore.backingForSubject(existingSubjectId),
        subjectId: existingSubjectId ?? plannedFreshSubjectIds[plannedFreshIndex++]
      })
    );
    const beforeFrontier = structuralStore.activeOrderFrontier();
    const frame = createEntityMutationFrame();
    for (const {
      id,
      entity: transformedEntity,
      existingSubjectId,
      subjectId
    } of preparedAdds) {
      if (existingSubjectId === void 0) {
        frame.stageFreshSubject({
          kind: "create-fresh-subject",
          key: id,
          subjectId,
          nextValue: transformedEntity
        });
        continue;
      }
      frame.stageValueReplacement({
        kind: "replace-value",
        key: id,
        subjectId: existingSubjectId,
        nextValue: transformedEntity
      });
    }
    if (prepend) frame.stageFinalFront(preparedAdds.map((row) => row.id));
    const committed = commitAndProjectEntityMutationFrame(frame);
    const subjectIdsByKey = /* @__PURE__ */ new Map();
    for (const { id, subjectId } of preparedAdds) {
      subjectIdsByKey.set(id, subjectId);
    }
    const processedIds = [];
    const addedEntities = [];
    for (const { entity: transformedEntity, id } of preparedAdds) {
      const subjectId = subjectIdsByKey.get(id);
      if (subjectId === void 0) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      invalidateNodeCache(id);
      syncEntitySignal(id);
      processedIds.push(id);
      addedEntities.push({ id, entity: transformedEntity, subjectId });
    }
    updateSignals();
    if (committed.orderEndpoints) {
      if (mutationCaptureRuntime?.isCaptureActive()) getPositionIds();
      publishOrderChange(
        committed.orderEndpoints.before,
        committed.orderEndpoints.after,
        beforeFrontier,
        void 0,
        committed.ordinaryEndpoints
      );
    }
    const subjectIdsForWrite = processedIds.map((id) => {
      const subjectId = subjectIdsByKey.get(id);
      if (subjectId === void 0) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      return subjectId;
    });
    lastSubjectIds = subjectIdsForWrite;
    let previousAppendedSubject = lastPreviousKey === void 0 ? void 0 : allocateSubjectId(lastPreviousKey);
    for (let i = 0; i < addedEntities.length; i++) {
      const { id, entity } = addedEntities[i];
      const beforeSubject = previousAppendedSubject;
      if (preparedAdds[i].existingSubjectId === void 0) {
        previousAppendedSubject = subjectIdsForWrite[i];
      }
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        entity,
        preparedAdds[i].prev,
        basePath,
        [subjectIdsForWrite[i]],
        getPositionIdsForNotify(),
        preparedAdds[i].existingSubjectId === void 0 ? createStructuralEffectMeta(
          {
            kind: "add",
            subject: subjectIdsForWrite[i],
            key: id,
            value: deepClone(entity),
            ...prepend ? getNeighborSubjects(id) : { beforeSubject }
          },
          committed.ordinaryChanges.get(subjectIdsForWrite[i])
        ) : withEntityValueTransition(
          ambientMeta(),
          committed.valueResults.get(subjectIdsForWrite[i])
        )
      );
    }
    for (const { id, entity } of addedEntities) {
      emitTap("onAdd", entity, id);
    }
    return processedIds;
  }
  function addOneWithStructuralEffect(entity, opts, prepend = false) {
    const id = deriveId(entity, opts);
    const previousLastKey = structuralStore.lastActiveKey();
    recordProductionSubstrateStat("publicAddPreviousTailReads");
    if (structuralStore.hasActiveKey(id)) {
      throw new Error(`Entity with id ${String(id)} already exists`);
    }
    const transformedEntity = interceptAddedEntity(entity);
    const subjectId = structuralStore.planFreshSubjectIds(1)[0];
    if (subjectId === void 0) {
      throw new Error(
        `Fresh subject planning for ${String(id)} did not produce an id.`
      );
    }
    const frame = createEntityMutationFrame();
    const freshSubject = {
      kind: "create-fresh-subject",
      key: id,
      subjectId,
      nextValue: transformedEntity
    };
    frame.stageFreshSubject(freshSubject);
    if (prepend) frame.stageFinalFront([id]);
    const committed = commitAndProjectEntityMutationFrame(frame);
    const structuralEffect = {
      kind: "add",
      subject: subjectId,
      key: id,
      value: deepClone(transformedEntity),
      beforeSubject: previousLastKey === void 0 ? void 0 : allocateSubjectId(previousLastKey)
    };
    if (prepend) {
      const neighbors = getNeighborSubjects(id);
      rewritePendingAddEffect(
        structuralEffect,
        neighbors.beforeSubject,
        neighbors.afterSubject
      );
    }
    lastSubjectIds = [subjectId];
    invalidateNodeCache(id);
    syncEntitySignal(id);
    updateSignals();
    pathNotifier.notify(
      `${basePath}.${String(id)}`,
      transformedEntity,
      void 0,
      basePath,
      [subjectId],
      getPositionIdsForNotify(),
      createStructuralEffectMeta(
        structuralEffect,
        committed.ordinaryChanges.get(subjectId)
      )
    );
    emitTap("onAdd", transformedEntity, id);
    return { id, structuralEffect };
  }
  function syncEntitySignal(id) {
    const subjectId = resolveSubjectId(id);
    if (subjectId === void 0) {
      return;
    }
    stageSubjectEpoch(subjectId);
  }
  function tombstoneSubjectSignal(subjectId) {
    stageSubjectEpoch(subjectId);
  }
  const nodeCache = /* @__PURE__ */ new Map();
  const nodeFinalizer = typeof FinalizationRegistry === "function" ? new FinalizationRegistry((subjectId) => {
    if (nodeCache.get(subjectId)?.deref() === void 0) {
      nodeCache.delete(subjectId);
    }
  }) : null;
  function invalidateNodeCache(id) {
    const subjectId = resolveSubjectId(id);
    if (subjectId !== void 0) {
      nodeCache.delete(subjectId);
    }
  }
  let cachedEmpty = null;
  const selectId = config.selectId ?? ((entity) => entity["id"]);
  let warnedMissingId = false;
  function deriveId(entity, opts) {
    const id = opts?.selectId?.(entity) ?? selectId(entity);
    if (id == null && (typeof ngDevMode === "undefined" || ngDevMode) && !warnedMissingId) {
      warnedMissingId = true;
      console.warn(
        `SignalTree entityMap${basePath ? ` at "${basePath}"` : ""}: an entity resolved to id=${String(
          id
        )}. Entities need a stable key \u2014 give them an \`id\` field or pass entityMap({ selectId: (e) => e.yourKey }). Without it, entities collide under a single key. [ST2001]`
      );
    }
    return id;
  }
  const tapHandlers = [];
  const emitTap = (method, ...args) => {
    if (pendingReAdd) {
      pendingReAdd = false;
      reactivatePathOnWrite(api);
    }
    const suppressed = interceptsSuppressed;
    const nested = reAdding;
    interceptsSuppressed = 0;
    reAdding = false;
    taps.depth++;
    try {
      for (const handler of tapHandlers)
        handler[method]?.(
          ...args
        );
    } finally {
      taps.depth--;
      interceptsSuppressed = suppressed;
      reAdding = nested;
    }
  };
  let interceptsSuppressed = 0;
  let reAdding = false;
  let pendingReAdd = false;
  let silentClear = 0;
  const interceptHandlers = [];
  function updateSignals() {
    const pending2 = [...pendingSubjectEpochs];
    pendingSubjectEpochs.clear();
    if (absent()) return;
    locations.runInvalidationGroup(() => {
      for (const epoch of pending2) {
        advanceEpochHandle(epoch);
      }
      deriveLocation(version, (value) => value + 1);
      markOwnerInvalidated(ownerId);
    });
  }
  function createEntityNode(subjectId, initialKey, entity) {
    const handle = acquireEntityHandleForTesting(initialKey);
    if (handle === void 0 || handle.subjectId !== subjectId) {
      throw new Error(
        `Entity with id ${String(initialKey)} has no acquired subject handle`
      );
    }
    let activationCarrier;
    const currentKey = () => {
      (activationCarrier ??= getSubjectStateSignal(subjectId))();
      const resolved = structuralStore.resolveSubjectHandle(handle);
      return resolved.state === "active" ? resolved.key : void 0;
    };
    const entitySig = () => {
      const key = currentKey();
      return key === void 0 ? void 0 : readEntityByKey(key);
    };
    const node = ((valueOrUpdater) => {
      if (valueOrUpdater === void 0) {
        return entitySig();
      }
      const key = currentKey();
      if (key === void 0) {
        throw new Error(`Entity with subject ${String(subjectId)} not found`);
      }
      const current = presentEntity(key);
      if (current === void 0) {
        throw new Error(`Entity with id ${String(key)} not found`);
      }
      const next = typeof valueOrUpdater === "function" ? valueOrUpdater(current) : valueOrUpdater;
      withCallableWriteIntent(
        typeof valueOrUpdater === "function" ? "derive" : "replace",
        () => api.replaceOne(key, next)
      );
      return void 0;
    });
    const registry = getPositionRegistry(api);
    const owner = registry ? getPositionIds()?.[0] : void 0;
    const bindLocation = (location, fieldKey) => {
      if (!registry || owner === void 0) return;
      definePositionRegistry(location, registry);
      defineEntityLocationBinding(location, { owner, subjectId, fieldKey });
      if (mutationCaptureRuntime) {
        Object.defineProperty(location, MUTATION_CAPTURE_RUNTIME, {
          value: mutationCaptureRuntime
        });
      }
    };
    bindLocation(node);
    for (const key of Object.keys(entity)) {
      const fieldKey = key;
      const computeField = () => {
        const current = entitySig();
        return current && Object.prototype.hasOwnProperty.call(current, fieldKey) ? current[fieldKey] : void 0;
      };
      const writeField = (value, intent) => {
        const key2 = currentKey();
        if (key2 === void 0) {
          throw new Error(`Entity with subject ${String(subjectId)} not found`);
        }
        withCallableWriteIntent(
          intent,
          () => api.updateOne(key2, { [fieldKey]: value })
        );
      };
      const fieldSignal = locations.createWritableProjection ? locations.createWritableProjection(computeField, writeField) : createWritableProjection(
        locations.createDerived(computeField),
        writeField
      );
      bindLocation(fieldSignal, key);
      if (ownerMetadataEnabled) {
        Object.defineProperty(fieldSignal, "__ownerPath", {
          get: () => {
            const key2 = currentKey();
            return key2 === void 0 ? void 0 : `${basePath}.${String(key2)}`;
          },
          enumerable: false,
          configurable: true
        });
      }
      if (subjectMetadataEnabled) {
        Object.defineProperty(fieldSignal, "__subjectIds", {
          get: () => [subjectId],
          enumerable: false,
          configurable: true
        });
      }
      if (positionMetadataEnabled) {
        Object.defineProperty(fieldSignal, "__positionIds", {
          get: getPositionIds,
          enumerable: false,
          configurable: true
        });
      }
      Object.defineProperty(node, key, {
        get: () => fieldSignal,
        enumerable: true,
        configurable: true
      });
    }
    return node;
  }
  function getOrCreateNode(id, entity) {
    const subjectId = resolveSubjectId(id);
    if (subjectId === void 0) {
      throw new Error(`Entity with id ${String(id)} has no subject id`);
    }
    let node = nodeCache.get(subjectId)?.deref();
    if (!node) {
      node = createEntityNode(subjectId, id, entity);
      nodeCache.set(subjectId, new WeakRef(node));
      nodeFinalizer?.register(node, subjectId);
    }
    return node;
  }
  function inspectSubjectResources(subjectId) {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState) {
      return void 0;
    }
    const node = nodeCache.get(subjectId)?.deref();
    const fieldFacadesMaterialized = node === void 0 ? [] : Object.keys(node).filter(
      (key) => typeof node[key] === "function"
    ).sort((left, right) => left.localeCompare(right));
    return {
      subjectId,
      state: subjectState.active ? "active" : "tombstoned",
      subjectRevision: getSubjectRevision(subjectId),
      activeKey: subjectState.active ? subjectState.key : void 0,
      retainedSubjectState: structuralStore.hasSubject(subjectId),
      entitySignal: subjectEpochs.has(subjectId),
      activationToken: subjectStateSignals.get(subjectId)?.deref() !== void 0,
      nodeFacadeMaterialized: node !== void 0,
      fieldFacadesMaterialized,
      positionIds: getPositionIds(),
      retainedValueBacking: valueStore.hasRetainedValueBacking(subjectId) ? { kind: "retained-entity-signal" } : void 0
    };
  }
  function listSubjectReclamationCandidates() {
    return structuralStore.tombstonedSubjectsSnapshot().filter((subjectId) => valueStore.hasRetainedValueBacking(subjectId));
  }
  function prepareSubjectReclamation(subjectId, options2) {
    const inventory = inspectSubjectResources(subjectId);
    if (!inventory) {
      return void 0;
    }
    const plan = planEntitySubjectReclamation(inventory, options2);
    if (!plan.eligible) {
      return void 0;
    }
    return {
      subjectId,
      expectedLifetime: "tombstoned",
      expectedSubjectRevision: inventory.subjectRevision,
      retire: plan.retire,
      retain: plan.retain
    };
  }
  function applyPreparedSubjectReclamation(prepared) {
    const state2 = resolveSubjectState(prepared.subjectId);
    if (prepared.expectedLifetime !== "tombstoned") {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} has an unsupported expected lifetime.`
      );
    }
    if (!state2) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }
    if (getSubjectRevision(prepared.subjectId) !== prepared.expectedSubjectRevision) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} is stale.`
      );
    }
    if (state2.active) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }
    const frame = createEntityMutationFrame();
    const forgetLifetime = prepared.retire.includes("subject-lifetime-record");
    const retiresValue = prepared.retire.includes("retained-value-backing");
    if (forgetLifetime || retiresValue) {
      const retirement = {
        kind: "retire-retained-value",
        subjectId: prepared.subjectId,
        forgetLifetime
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(prepared.subjectId);
    }
    const result = commitAndProjectEntityMutationFrame(frame);
    for (const changedSubjectId of result.physicallyChangedSubjectIds) {
      if (forgetLifetime && changedSubjectId === prepared.subjectId) {
        continue;
      }
      publishSubjectPhysicalChange(changedSubjectId);
    }
  }
  function reclaimRetiredSubjectsWithoutOwner(subjectIds) {
    if (hasRestorationAuthority || subjectIds.length === 0) {
      return;
    }
    const frame = createEntityMutationFrame();
    let staged = 0;
    for (const subjectId of subjectIds) {
      const state2 = resolveSubjectState(subjectId);
      if (!state2 || state2.active) {
        continue;
      }
      if (ordinaryTopology.retains(subjectId)) continue;
      if (!valueStore.hasRetainedValueBacking(subjectId)) {
        continue;
      }
      const retirement = {
        kind: "retire-retained-value",
        subjectId,
        forgetLifetime: true
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(subjectId);
      staged += 1;
    }
    if (staged === 0) {
      return;
    }
    commitAndProjectEntityMutationFrame(frame);
  }
  function retireSubjectRetainedValueBackingForTesting(subjectId) {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState || subjectState.active) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} must be tombstoned before retiring retained value backing.`
      );
    }
    valueStore.retireSubjectValue(subjectId);
    subjectEpochs.delete(subjectId);
  }
  const whereCache = /* @__PURE__ */ new WeakMap();
  const findCache = /* @__PURE__ */ new WeakMap();
  const api = {
    // ==================
    // EXPLICIT ACCESS
    // ==================
    byId(id) {
      if (!rowAbsent() && structuralStore.hasActiveKey(id)) {
        const entity = readEntityByKey(id);
        return entity ? getOrCreateNode(id, entity) : void 0;
      }
      idsSignal();
      return void 0;
    },
    byIdOrFail(id) {
      const node = api.byId(id);
      if (!node) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      return node;
    },
    // ==================
    // QUERIES (return Signals)
    // ==================
    get all() {
      return inTap(allSignal, computeAll);
    },
    get count() {
      return inTap(countSignal, computeCount);
    },
    get ids() {
      return inTap(idsSignal, () => computeIds(computeAll));
    },
    /**
     * The collection as a `ReadonlyMap`, keyed by id.
     *
     * Named `asMap` since 14.1.1. It was `map`, which read as a PROJECTION beside
     * `all()` — every JS developer expects `.map(fn)` to transform elements, and an
     * agent or newcomer reaching for that is a documented failure class (see
     * `WRONG_ENTITY_METHODS`). `asMap` says what it returns.
     */
    get asMap() {
      return inTap(mapSignal, computeMap);
    },
    // ── Active entity ───────────────────────────────────────────────────────
    get activeId() {
      return activeIdSignal.asReadonly();
    },
    /**
     * Resolved through the per-entity signal, NOT through `mapSignal`.
     *
     * That is the whole reason to build this here rather than leave it to the
     * app: a hand-rolled `getDerivedRuntime().createDerived(() => all().find(e => id(e) === activeId()))`
     * depends on the entire collection, so it recomputes when ANY row changes.
     * This depends on the active row's own signal, so it recomputes only when
     * that row changes — which is what `byId` exists for.
     */
    get activeEntity() {
      const read2 = () => {
        const id = activeIdSignal();
        if (id === void 0) return void 0;
        if (resolveSubjectId(id) === void 0) idsSignal();
        return readEntityByKey(id);
      };
      if (taps.depth) return fresh(read2);
      return cachedActiveEntity ??= locations.createDerived(read2);
    },
    setActiveId(id) {
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, id);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },
    clearActiveId() {
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, void 0);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },
    has(id) {
      const read2 = () => !absent() && structuralStore.hasActiveKey(id);
      return taps.depth ? fresh(read2) : createVersionedProjection(read2);
    },
    // Bare canonical name (the `.isEmpty` alias was removed in v11).
    get empty() {
      if (taps.depth) return fresh(() => computeCount() === 0);
      return cachedEmpty ??= locations.createDerived(
        () => countSignal() === 0
      );
    },
    where(predicate) {
      if (taps.depth) return fresh(() => computeAll().filter(predicate));
      const cached = whereCache.get(predicate);
      if (cached) return cached;
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnOnPredicateChurn("where", predicate);
      }
      const s = createVersionedProjection(() => {
        if (config.sortComparer) return allSignal().filter(predicate);
        const out = [];
        for (const entity of presentEntities()) {
          if (predicate(entity)) out.push(entity);
        }
        return out;
      });
      whereCache.set(predicate, s);
      return s;
    },
    find(predicate) {
      if (taps.depth) return fresh(() => computeAll().find(predicate));
      const cached = findCache.get(predicate);
      if (cached) return cached;
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnOnPredicateChurn("find", predicate);
      }
      const s = createVersionedProjection(() => {
        if (config.sortComparer) return allSignal().find(predicate);
        for (const entity of presentEntities()) {
          if (predicate(entity)) return entity;
        }
        return void 0;
      });
      findCache.set(predicate, s);
      return s;
    },
    // ==================
    // MUTATIONS: ADD
    // ==================
    addOne(entity, opts) {
      return addOneWithStructuralEffect(entity, opts).id;
    },
    /** Insert at the front before notification and lifecycle callbacks. */
    prependOne(entity, opts) {
      return withMembershipGroup(
        () => addOneWithStructuralEffect(entity, opts, true).id
      );
    },
    prependMany(entities, opts) {
      return withMembershipGroup(() => addManyInOrder(entities, opts, true));
    },
    /**
     * Change an entity's id in place — the missing half of optimistic creation.
     *
     * Insert with a temp id, then adopt the id the server assigned. Everything
     * keyed by the old id moves together: storage (keeping list position), the
     * per-entity signal, the node cache, and the active-entity selection.
     *
     * Held row/field references follow the rekey by SUBJECT identity rather than
     * by the old key. The old lookup disappears, but already-materialized row
     * state, metadata, and field signals remain attached to the same subject.
     * That keeps list position, active selection, and row-local reactivity while
     * still allowing the freed id to be reused by a different subject.
     */
    changeId(from, to) {
      if (rowAbsent())
        throw new Error(`Entity with id ${String(from)} not found`);
      const planned = planRekey(from, to);
      planned.commit();
      planned.publish();
    },
    addMany(entities, opts) {
      return addManyInOrder(entities, opts);
    },
    // ==================
    // MUTATIONS: UPDATE
    // ==================
    updateOne(id, changes) {
      const callableIntent = consumeCallableWriteIntent();
      const entity = presentEntity(id);
      if (!entity) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      const prev = entity;
      let transformedChanges = changes;
      for (const handler of interceptHandlers) {
        const ctx = {
          block: (reason) => {
            throw new Error(
              `Cannot update entity: ${reason || "blocked by interceptor"}`
            );
          },
          transform: (value) => {
            transformedChanges = value;
          },
          blocked: false,
          blockReason: void 0
        };
        assertSynchronousInterceptorResult(
          handler.onUpdate?.(id, changes, ctx),
          "onUpdate"
        );
      }
      const finalUpdated = { ...entity, ...transformedChanges };
      const subjectIdForWrite = rememberSubjectId(id);
      const transition2 = commitExistingSubjectValue(
        subjectIdForWrite,
        finalUpdated,
        Object.keys(transformedChanges)
      );
      syncEntitySignal(id);
      updateSignals();
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        finalUpdated,
        prev,
        basePath,
        lastSubjectIds,
        getPositionIdsForNotify(),
        withEntityValueTransition(ambientMeta(), transition2),
        void 0,
        (callableIntent ?? getActiveWriteContext()?.mutationIntent) === "derive" ? void 0 : Object.keys(transformedChanges)
      );
      emitTap("onUpdate", id, transformedChanges, finalUpdated);
    },
    /**
     * Replace, not merge — and the write path behind `byId(id)(next)`.
     *
     * Identical to `updateOne` except the one line that matters: assign the whole
     * entity instead of spreading it over the current one. That single difference
     * is the only way to REMOVE a key, which `updateOne` cannot express at all.
     *
     * **Why `replaceOne(id, entity)` and not `setOne(entity)`.** The id comes from
     * the caller on purpose. A `setOne` deriving it via `selectId(entity)` writes
     * to whatever slot the entity's own id field names — and `changeId` can leave
     * `entity.id` disagreeing with the storage key, so that form has a silent
     * wrong-slot write built into it. This one cannot drift.
     */
    replaceOne(id, entity) {
      const callableIntent = consumeCallableWriteIntent();
      const prev = presentEntity(id);
      if (!prev) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      let next = entity;
      for (const handler of interceptHandlers) {
        const ctx = {
          block: (reason) => {
            throw new Error(
              `Cannot replace entity: ${reason || "blocked by interceptor"}`
            );
          },
          transform: (value) => {
            next = value;
          },
          blocked: false,
          blockReason: void 0
        };
        assertSynchronousInterceptorResult(
          handler.onUpdate?.(id, entity, ctx),
          "onUpdate"
        );
      }
      const subjectId = structuralStore.subjectIdForKey(id);
      if (subjectId === void 0) {
        throw new Error(`Entity with id ${String(id)} has no subject id`);
      }
      const mutationIntent = callableIntent ?? getActiveWriteContext()?.mutationIntent;
      const replacement = {
        kind: "replace-value",
        key: id,
        subjectId,
        nextValue: next,
        authoredFields: mutationIntent === "derive" ? "derive" : null
      };
      const frame = createEntityMutationFrame();
      frame.stageValueReplacement(replacement);
      const committed = commitAndProjectEntityMutationFrame(frame);
      const transition2 = committed.valueResults.get(subjectId);
      next = transition2?.physicalAfter ?? next;
      syncEntitySignal(id);
      updateSignals();
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        next,
        prev,
        basePath,
        // REPLACE-ONE-SUBJECT-1. This was `undefined`, and it was the ONLY
        // entity notification in this file that dropped subject identity —
        // `updateOne`, `updateMany` and `removeOne` all pass theirs. The id
        // above is DATA; `subjectId` is IDENTITY, and it was already resolved
        // from `structuralStore` a few lines up, so nothing new is looked up
        // here.
        //
        // Without it, reversal effects arrive with `subjectId: undefined`,
        // `hasInlineSubjectAddress` is false, no inline subject address is
        // derived, and no fallback descriptor can be keyed — so rollback and
        // undo both REFUSE, at TOP level as well as nested.
        [subjectId],
        getPositionIdsForNotify(),
        withEntityValueTransition(
          ambientMeta(),
          committed.valueResults.get(subjectId)
        ),
        void 0,
        (callableIntent ?? getActiveWriteContext()?.mutationIntent) === "derive" ? void 0 : null
      );
      emitTap("onUpdate", id, next, next);
    },
    updateMany(ids, changes) {
      if (ids.length === 0) return;
      const updatedEntities = [];
      for (const id of ids) {
        const entity = presentEntity(id);
        if (!entity) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        const prev = entity;
        let transformedChanges = changes;
        for (const handler of interceptHandlers) {
          const ctx = {
            block: (reason) => {
              throw new Error(
                `Cannot update entity: ${reason || "blocked by interceptor"}`
              );
            },
            transform: (value) => {
              transformedChanges = value;
            },
            blocked: false,
            blockReason: void 0
          };
          assertSynchronousInterceptorResult(
            handler.onUpdate?.(id, changes, ctx),
            "onUpdate"
          );
        }
        const finalUpdated = { ...entity, ...transformedChanges };
        const subjectId = structuralStore.subjectIdForKey(id);
        if (subjectId === void 0) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        updatedEntities.push({
          id,
          subjectId,
          prev,
          finalUpdated,
          transformedChanges
        });
      }
      const frame = createEntityMutationFrame();
      for (const {
        id,
        subjectId,
        finalUpdated,
        transformedChanges
      } of updatedEntities) {
        frame.stageValueReplacement({
          kind: "replace-value",
          key: id,
          subjectId,
          nextValue: finalUpdated,
          authoredFields: Object.keys(transformedChanges)
        });
      }
      const committed = commitAndProjectEntityMutationFrame(frame);
      for (const { id } of updatedEntities) {
        syncEntitySignal(id);
      }
      updateSignals();
      const subjectIdsForWrite = rememberSubjectIds(ids);
      for (let i = 0; i < updatedEntities.length; i++) {
        const { id, prev, finalUpdated, transformedChanges } = updatedEntities[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          finalUpdated,
          prev,
          basePath,
          [subjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          withEntityValueTransition(
            ambientMeta(),
            committed.valueResultsByStep[i]
          ),
          void 0,
          getActiveWriteContext()?.mutationIntent === "derive" ? void 0 : Object.keys(transformedChanges)
        );
      }
      for (const { id, transformedChanges, finalUpdated } of updatedEntities) {
        emitTap("onUpdate", id, transformedChanges, finalUpdated);
      }
    },
    updateWhere(predicate, changes) {
      const idsToUpdate = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToUpdate.push(id);
        }
      }
      if (idsToUpdate.length > 0) {
        api.updateMany(idsToUpdate, changes);
      }
      return idsToUpdate.length;
    },
    // ==================
    // MUTATIONS: REMOVE
    // ==================
    removeOne(id) {
      const entity = presentEntity(id);
      if (!entity) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      const { beforeSubject, afterSubject } = getNeighborSubjects(id);
      for (const handler of interceptHandlers) {
        const ctx = {
          block: (reason) => {
            throw new Error(
              `Cannot remove entity: ${reason || "blocked by interceptor"}`
            );
          },
          transform: () => {
          },
          blocked: false,
          blockReason: void 0
        };
        assertSynchronousInterceptorResult(
          handler.onRemove?.(id, entity, ctx),
          "onRemove"
        );
      }
      const subjectIdsForWrite = rememberSubjectIds([id]);
      const structuralEffect = {
        kind: "remove",
        subject: subjectIdsForWrite[0],
        key: id,
        value: deepClone(entity),
        beforeSubject,
        afterSubject
      };
      const currentState = resolveSubjectState(subjectIdsForWrite[0]);
      const tombstone = {
        kind: "tombstone-subject",
        key: id,
        subjectId: subjectIdsForWrite[0],
        restoreAllowed: currentState?.restoreAllowed ?? true
      };
      const frame = createEntityMutationFrame();
      frame.stageSubjectTombstone(tombstone);
      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }
      tombstoneSubjectSignal(subjectIdsForWrite[0]);
      reclaimRetiredSubjectsWithoutOwner([subjectIdsForWrite[0]]);
      updateSignals();
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        void 0,
        entity,
        basePath,
        subjectIdsForWrite,
        getPositionIdsForNotify(),
        createStructuralEffectMeta(
          structuralEffect,
          result.ordinaryChanges.get(subjectIdsForWrite[0])
        )
      );
      emitTap("onRemove", id, entity);
    },
    removeMany(ids) {
      if (ids.length === 0) return;
      const preparedRemovals = [];
      for (const id of ids) {
        const entity = presentEntity(id);
        if (!entity) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        const subjectId = resolveSubjectId(id);
        if (subjectId === void 0) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        const { beforeSubject, afterSubject } = getNeighborSubjects(id);
        for (const handler of interceptHandlers) {
          const ctx = {
            block: (reason) => {
              throw new Error(
                `Cannot remove entity: ${reason || "blocked by interceptor"}`
              );
            },
            transform: () => {
            },
            blocked: false,
            blockReason: void 0
          };
          assertSynchronousInterceptorResult(
            handler.onRemove?.(id, entity, ctx),
            "onRemove"
          );
        }
        preparedRemovals.push({
          id,
          entity,
          subjectId,
          beforeSubject,
          afterSubject
        });
      }
      const subjectIdsForWrite = preparedRemovals.map(
        ({ subjectId }) => subjectId
      );
      lastSubjectIds = subjectIdsForWrite;
      const frame = createEntityMutationFrame();
      for (const { id, subjectId } of preparedRemovals) {
        const currentState = resolveSubjectState(subjectId);
        frame.stageSubjectTombstone({
          kind: "tombstone-subject",
          key: id,
          subjectId,
          restoreAllowed: currentState?.restoreAllowed ?? true
        });
      }
      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }
      for (const { subjectId } of preparedRemovals) {
        tombstoneSubjectSignal(subjectId);
      }
      reclaimRetiredSubjectsWithoutOwner(
        preparedRemovals.map(({ subjectId }) => subjectId)
      );
      updateSignals();
      for (let i = 0; i < preparedRemovals.length; i++) {
        const { id, entity, beforeSubject, afterSubject } = preparedRemovals[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          void 0,
          entity,
          basePath,
          [subjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            {
              kind: "remove",
              subject: subjectIdsForWrite[i],
              key: id,
              value: deepClone(entity),
              beforeSubject,
              afterSubject
            },
            result.ordinaryChanges.get(subjectIdsForWrite[i])
          )
        );
      }
      for (const { id, entity } of preparedRemovals) {
        emitTap("onRemove", id, entity);
      }
    },
    removeWhere(predicate) {
      const idsToRemove = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToRemove.push(id);
        }
      }
      if (idsToRemove.length > 0) {
        api.removeMany(idsToRemove);
      }
      return idsToRemove.length;
    },
    // ==================
    // MUTATIONS: UPSERT
    // ==================
    upsertOne(entity, opts) {
      const id = deriveId(entity, opts);
      if (structuralStore.hasActiveKey(id)) {
        api.updateOne(id, entity);
      } else {
        api.addOne(entity, opts);
      }
      return id;
    },
    upsertMany(entities, opts) {
      if (entities.length === 0) return [];
      const lastPreviousKey = structuralStore.lastActiveKey();
      const toAdd = [];
      const toUpdate = [];
      const copies = [];
      const earlier = /* @__PURE__ */ new Map();
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        let row = earlier.get(id);
        if (!row) {
          const prev = getProjectedEntity(id);
          if (prev === void 0) row = { id };
          else {
            const subjectId = resolveSubjectId(id);
            if (subjectId === void 0) {
              throw new Error(`Entity with id ${String(id)} has no subject id`);
            }
            row = { id, prev, entity: prev, subjectId };
          }
          (prev === void 0 ? toAdd : toUpdate).push(row);
          earlier.set(id, row);
        }
        copies.push([row, entity]);
      }
      for (const [row, entity] of copies) {
        if (row.entity === void 0) {
          row.entity = interceptAddedEntity(entity);
        } else {
          const changes = interceptUpdatedEntity(row.id, entity);
          row.changes = { ...row.changes, ...changes };
          row.entity = { ...row.entity, ...changes };
        }
      }
      const stagedAdds = toAdd;
      const stagedUpdates = toUpdate.map(
        ({ id, subjectId, prev, entity, changes }) => ({
          id,
          subjectId,
          prev,
          transformedChanges: changes,
          finalUpdated: entity
        })
      );
      let ordinaryChanges = /* @__PURE__ */ new Map();
      let valueResults = /* @__PURE__ */ new Map();
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      const addedEntities = [];
      try {
        const freshSubjectIds = structuralStore.planFreshSubjectIds(
          stagedAdds.length
        );
        const frame = createEntityMutationFrame();
        for (let i = 0; i < stagedAdds.length; i++)
          frame.stageFreshSubject({
            kind: "create-fresh-subject",
            key: stagedAdds[i].id,
            subjectId: freshSubjectIds[i],
            nextValue: stagedAdds[i].entity
          });
        for (const row of stagedUpdates)
          frame.stageValueReplacement({
            kind: "replace-value",
            key: row.id,
            subjectId: row.subjectId,
            nextValue: row.finalUpdated,
            authoredFields: Object.keys(row.transformedChanges)
          });
        const committed = commitAndProjectEntityMutationFrame(frame);
        valueResults = committed.valueResults;
        ordinaryChanges = committed.ordinaryChanges;
        const addedSubjectIdsByKey = /* @__PURE__ */ new Map();
        for (let i = 0; i < stagedAdds.length; i++) {
          addedSubjectIdsByKey.set(stagedAdds[i].id, freshSubjectIds[i]);
        }
        for (const { entity: transformedEntity, id } of stagedAdds) {
          const subjectId = addedSubjectIdsByKey.get(id);
          if (subjectId === void 0) {
            throw new Error(`Entity with id ${String(id)} has no subject id`);
          }
          invalidateNodeCache(id);
          syncEntitySignal(id);
          addedEntities.push({ id, entity: transformedEntity, subjectId });
        }
      } finally {
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      const updatedEntities = [];
      for (const {
        id,
        subjectId,
        prev,
        finalUpdated,
        transformedChanges
      } of stagedUpdates) {
        syncEntitySignal(id);
        updatedEntities.push({
          id,
          subjectId,
          prev,
          finalUpdated,
          transformedChanges
        });
      }
      updateSignals();
      const addedSubjectIdsForWrite = addedEntities.map(
        ({ subjectId }) => subjectId
      );
      const updatedSubjectIdsForWrite = updatedEntities.map(
        ({ subjectId }) => subjectId
      );
      lastSubjectIds = [
        ...addedSubjectIdsForWrite,
        ...updatedSubjectIdsForWrite
      ];
      let beforeSubject = lastPreviousKey === void 0 ? void 0 : allocateSubjectId(lastPreviousKey);
      for (let i = 0; i < addedEntities.length; i++) {
        const { id, entity } = addedEntities[i];
        const subject = addedSubjectIdsForWrite[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          void 0,
          basePath,
          [subject],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            {
              kind: "add",
              subject,
              key: id,
              value: deepClone(entity),
              beforeSubject
            },
            ordinaryChanges.get(subject)
          )
        );
        beforeSubject = subject;
      }
      for (let i = 0; i < updatedEntities.length; i++) {
        const { id, prev, finalUpdated, transformedChanges } = updatedEntities[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          finalUpdated,
          prev,
          basePath,
          [updatedSubjectIdsForWrite[i]],
          getPositionIdsForNotify(),
          withEntityValueTransition(
            ambientMeta(),
            valueResults.get(updatedSubjectIdsForWrite[i])
          ),
          void 0,
          getActiveWriteContext()?.mutationIntent === "derive" ? void 0 : Object.keys(transformedChanges)
        );
      }
      for (const { id, entity } of addedEntities) {
        emitTap("onAdd", entity, id);
      }
      for (const { id, transformedChanges, finalUpdated } of updatedEntities) {
        emitTap("onUpdate", id, transformedChanges, finalUpdated);
      }
      return [...toAdd.map((a) => a.id), ...toUpdate.map((u) => u.id)];
    },
    // ==================
    // MUTATIONS: CLEAR/RESET
    // ==================
    clear() {
      const activeIds = structuralStore.activeKeysSnapshot();
      const activeSubjects = activeIds.map((id) => {
        const subjectId = resolveSubjectId(id);
        if (subjectId === void 0) {
          throw new Error(`Entity with id ${String(id)} has no subject id`);
        }
        const entity = getProjectedEntity(id);
        const { beforeSubject, afterSubject } = getNeighborSubjects(id);
        return { id, subjectId, entity, beforeSubject, afterSubject };
      });
      let ordinaryChanges = /* @__PURE__ */ new Map();
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      try {
        const frame = createEntityMutationFrame();
        for (const { id, subjectId } of activeSubjects)
          frame.stageSubjectTombstone({
            kind: "tombstone-subject",
            key: id,
            subjectId,
            restoreAllowed: resolveSubjectState(subjectId)?.restoreAllowed ?? true
          });
        ordinaryChanges = commitAndProjectEntityMutationFrame(frame).ordinaryChanges;
      } finally {
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      for (const { subjectId } of activeSubjects)
        publishSubjectPhysicalChange(subjectId);
      for (const { subjectId } of activeSubjects) {
        tombstoneSubjectSignal(subjectId);
      }
      reclaimRetiredSubjectsWithoutOwner(
        activeSubjects.map(({ subjectId }) => subjectId)
      );
      replaceLocation(activeIdSignal, void 0);
      lastSubjectIds = activeSubjects.map(({ subjectId }) => subjectId);
      updateSignals();
      for (const {
        id,
        subjectId,
        entity,
        beforeSubject,
        afterSubject
      } of activeSubjects) {
        if (!entity) continue;
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          void 0,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            {
              kind: "remove",
              subject: subjectId,
              key: id,
              value: deepClone(entity),
              beforeSubject,
              afterSubject
            },
            ordinaryChanges.get(subjectId)
          )
        );
      }
      for (const { id, entity } of activeSubjects) {
        if (!entity || silentClear) continue;
        emitTap("onRemove", id, entity);
      }
    },
    setAll(entities, opts) {
      const currentKeys = [];
      const currentSubjects = [];
      structuralStore.snapshotActiveOrder(currentKeys, currentSubjects);
      const beforeOrderFrontier = structuralStore.activeOrderFrontier();
      const incomingIndex = /* @__PURE__ */ new Map();
      const incomingIds = [];
      const incomingEntities = [];
      const incomingSubjects = [];
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        const existing = structuralStore.subjectIdForKey(id);
        const transformedEntity = existing !== void 0 ? interceptReplacedEntity(id, entity) : interceptAddedEntity(entity);
        const index = incomingIndex.get(id);
        if (index === void 0) {
          incomingIndex.set(id, incomingIds.length);
          incomingIds.push(id);
          incomingEntities.push(transformedEntity);
          incomingSubjects.push(existing);
          continue;
        }
        incomingEntities[index] = transformedEntity;
      }
      const stagedRemovals = [];
      for (let index = 0; index < currentKeys.length; index += 1) {
        const id = currentKeys[index];
        if (incomingIndex.has(id)) continue;
        const subjectId = currentSubjects[index];
        const entity = valueStore.backingForSubject(subjectId);
        if (entity === void 0) continue;
        for (const handler of interceptHandlers) {
          const ctx = {
            block: (reason) => {
              throw new Error(
                `Cannot remove entity: ${reason || "blocked by interceptor"}`
              );
            },
            transform: () => {
            },
            blocked: false,
            blockReason: void 0
          };
          assertSynchronousInterceptorResult(
            handler.onRemove?.(id, entity, ctx),
            "onRemove"
          );
        }
        stagedRemovals.push({ id, entity, subjectId, index });
      }
      if (structuralStore.activeOrderFrontier() !== beforeOrderFrontier || currentKeys.some(
        (key, index) => structuralStore.subjectIdForKey(key) !== currentSubjects[index]
      )) {
        throw new Error(
          "Cannot setAll: collection topology changed during staging"
        );
      }
      const stagedUpdates = [];
      const stagedAdds = [];
      for (let index = 0; index < incomingIds.length; index += 1) {
        const id = incomingIds[index];
        const entity = incomingEntities[index];
        const subjectId = incomingSubjects[index];
        if (subjectId === void 0) {
          stagedAdds.push({ id, entity, index });
          continue;
        }
        const prev = valueStore.backingForSubject(subjectId);
        if (prev === void 0) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        stagedUpdates.push({ id, prev, entity, subjectId });
      }
      let ordinaryChanges = /* @__PURE__ */ new Map();
      let valueResults = /* @__PURE__ */ new Map();
      const membershipUnit = membershipTap;
      membershipUnit?.(MEMBERSHIP_OPEN_ORDER);
      let addedSubjectIds;
      let afterSubjects;
      const stagedRemovalStructuralEffects = [];
      try {
        addedSubjectIds = structuralStore.planFreshSubjectIds(
          stagedAdds.length
        );
        for (let k = 0; k < stagedAdds.length; k += 1) {
          incomingSubjects[stagedAdds[k].index] = addedSubjectIds[k];
        }
        afterSubjects = incomingSubjects;
        for (const { id, entity, subjectId, index } of stagedRemovals) {
          stagedRemovalStructuralEffects.push({
            kind: "remove",
            subject: subjectId,
            key: id,
            value: deepClone(entity),
            beforeSubject: index > 0 ? currentSubjects[index - 1] : void 0,
            afterSubject: currentSubjects[index + 1]
          });
        }
        const frame = createEntityMutationFrame();
        for (const { id, subjectId } of stagedRemovals)
          frame.stageSubjectTombstone({
            kind: "tombstone-subject",
            key: id,
            subjectId,
            restoreAllowed: resolveSubjectState(subjectId)?.restoreAllowed ?? true
          });
        for (const { id, subjectId, entity } of stagedUpdates)
          frame.stageValueReplacement({
            kind: "replace-value",
            key: id,
            subjectId,
            nextValue: entity
          });
        for (let k = 0; k < stagedAdds.length; k++)
          frame.stageFreshSubject({
            kind: "create-fresh-subject",
            key: stagedAdds[k].id,
            subjectId: addedSubjectIds[k],
            nextValue: stagedAdds[k].entity
          });
        frame.stageFinalOrder(incomingIds);
        if (survivingOrderChanged(currentSubjects, afterSubjects))
          frame.ordinaryOrder = afterSubjects;
        const committed = commitAndProjectEntityMutationFrame(frame);
        valueResults = committed.valueResults;
        ordinaryChanges = committed.ordinaryChanges;
        for (const { subjectId } of stagedRemovals)
          tombstoneSubjectSignal(subjectId);
        for (const { id } of stagedAdds) syncEntitySignal(id);
        for (const { id } of stagedUpdates) {
          syncEntitySignal(id);
        }
        lastSubjectIds = [
          ...stagedRemovals.map(({ subjectId }) => subjectId),
          ...stagedUpdates.map(({ subjectId }) => subjectId),
          ...addedSubjectIds
        ];
        if (mutationCaptureRuntime?.isCaptureActive()) getPositionIds();
        if (positionId !== void 0 && mutationCaptureRuntime?.publishCollectionOrder && survivingOrderChanged(currentSubjects, afterSubjects)) {
          publishOrderChange(
            currentSubjects,
            afterSubjects,
            beforeOrderFrontier,
            void 0,
            committed.ordinaryEndpoints
          );
        }
      } finally {
        membershipUnit?.(MEMBERSHIP_CLOSE);
      }
      for (const { subjectId } of stagedRemovals)
        publishSubjectPhysicalChange(subjectId);
      reclaimRetiredSubjectsWithoutOwner(
        stagedRemovals.map(({ subjectId }) => subjectId)
      );
      const stagedAddStructuralEffects = [];
      for (let k = 0; k < stagedAdds.length; k += 1) {
        const { id, entity, index } = stagedAdds[k];
        stagedAddStructuralEffects.push({
          kind: "add",
          subject: addedSubjectIds[k],
          key: id,
          value: deepClone(entity),
          beforeSubject: index > 0 ? afterSubjects[index - 1] : void 0,
          afterSubject: afterSubjects[index + 1]
        });
      }
      updateSignals();
      for (let index = 0; index < stagedRemovals.length; index += 1) {
        const { id, entity, subjectId } = stagedRemovals[index];
        const structuralEffect = stagedRemovalStructuralEffects[index];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          void 0,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            structuralEffect,
            ordinaryChanges.get(structuralEffect.subject)
          )
        );
      }
      for (const { id, prev, entity, subjectId } of stagedUpdates) {
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          prev,
          basePath,
          subjectId === void 0 ? void 0 : [subjectId],
          getPositionIdsForNotify(),
          withEntityValueTransition(ambientMeta(), valueResults.get(subjectId)),
          void 0,
          getActiveWriteContext()?.mutationIntent === "derive" ? void 0 : null
        );
      }
      for (let i = 0; i < stagedAdds.length; i++) {
        const { id, entity } = stagedAdds[i];
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          void 0,
          basePath,
          [addedSubjectIds[i]],
          getPositionIdsForNotify(),
          createStructuralEffectMeta(
            stagedAddStructuralEffects[i],
            ordinaryChanges.get(stagedAddStructuralEffects[i].subject)
          )
        );
      }
      for (const { id, entity } of stagedRemovals) {
        emitTap("onRemove", id, entity);
      }
      for (const { id, entity } of stagedAdds) {
        emitTap("onAdd", entity, id);
      }
      for (const { id, entity } of stagedUpdates) {
        emitTap("onUpdate", id, entity, entity);
      }
    },
    // ==================
    // HOOKS
    // ==================
    tap(handlers) {
      tapHandlers.push(handlers);
      return () => {
        const idx = tapHandlers.indexOf(handlers);
        if (idx > -1) tapHandlers.splice(idx, 1);
      };
    },
    intercept(handlers) {
      assertSynchronousInterceptors(handlers);
      interceptHandlers.push(handlers);
      return () => {
        const idx = interceptHandlers.indexOf(handlers);
        if (idx > -1) interceptHandlers.splice(idx, 1);
      };
    }
  };
  if (subjectMetadataEnabled) {
    Object.defineProperty(api, "__subjectIds", {
      get: () => lastSubjectIds,
      enumerable: false,
      configurable: true
    });
  }
  Object.defineProperty(api, "__positionIds", {
    get: getPositionIds,
    enumerable: false,
    configurable: true
  });
  defineOwnedOwnerPath(api, basePath);
  const clearRetained = api.clear;
  const interceptAsEmpty = (name, args) => {
    const opts = args[1];
    const many = name.endsWith("Many") || name === "setAll";
    const input = many ? args[0] : [args[0]];
    const upsert = name.startsWith("upsert");
    const mode = name === "addMany" || name === "prependMany" ? opts?.mode ?? "strict" : "overwrite";
    const copies = [];
    const firsts = /* @__PURE__ */ new Set();
    for (const row of input) {
      const id = deriveId(row, opts);
      if (firsts.has(id)) {
        if (mode === "strict")
          throw new Error(`Entity with id ${String(id)} already exists`);
        if (mode === "skip") continue;
      }
      firsts.add(id);
      copies.push([id, row]);
    }
    const rows = /* @__PURE__ */ new Map();
    for (const [id, row] of copies) {
      const running = rows.get(id);
      rows.set(
        id,
        upsert && running !== void 0 ? { ...running, ...interceptUpdatedEntity(id, row) } : interceptAddedEntity(row)
      );
    }
    const keys = /* @__PURE__ */ new Map();
    const out = [];
    for (const [id, row] of rows) {
      const own = keys.has(row) ? { ...row } : row;
      keys.set(own, id);
      out.push(own);
    }
    const resolved = {
      ...opts,
      selectId: (row) => keys.get(row) ?? deriveId(row, opts)
    };
    return [many ? out : out[0], resolved];
  };
  for (const name of [
    "addOne",
    "prependOne",
    "addMany",
    "prependMany",
    "upsertOne",
    "upsertMany",
    "setAll",
    "clear"
  ]) {
    const write = api[name];
    api[name] = (...args) => {
      if (reAdding || !absent() || inStructuralWrite(proxy))
        return write(...args);
      const prepared = name === "clear" ? [] : interceptAsEmpty(name, args);
      const writePrepared = () => {
        interceptsSuppressed++;
        try {
          return write(...prepared);
        } finally {
          interceptsSuppressed--;
        }
      };
      if (!absent() || name !== "setAll" && Array.isArray(prepared[0]) && !prepared[0].length)
        return writePrepared();
      reAdding = pendingReAdd = true;
      try {
        silentClear++;
        try {
          clearRetained();
        } finally {
          silentClear--;
        }
        const result = writePrepared();
        if (pendingReAdd) {
          pendingReAdd = false;
          reactivatePathOnWrite(api);
        }
        return result;
      } finally {
        reAdding = pendingReAdd = false;
      }
    };
  }
  const wake2 = () => locations.runInvalidationGroup(() => {
    for (const epoch of subjectEpochs.values()) advanceEpochHandle(epoch);
    deriveLocation(version, (value) => value + 1);
    markOwnerInvalidated(ownerId);
  });
  let wakeQueued2 = false;
  Object.defineProperty(api, MEMBERSHIP_CHANGED, {
    value: () => {
      if (!structuralWrites.depth) return wake2();
      if (wakeQueued2) return;
      wakeQueued2 = true;
      const earlier = structuralWrites.end;
      structuralWrites.end = (failed) => {
        structuralWrites.end = void 0;
        wakeQueued2 = false;
        let caught;
        for (const run of [() => earlier?.(failed), wake2]) {
          try {
            run();
          } catch (error2) {
            caught ??= { error: error2 };
          }
        }
        if (!caught) return;
        if (!failed) throw caught.error;
        const { error } = caught;
        queueMicrotask(() => {
          throw error;
        });
      };
    }
  });
  defineEntityMembershipSource(api, (tap) => {
    membershipTap = tap;
    return structuralStore;
  });
  defineEntityProjectionSeed(api, () => {
    const seed = [];
    for (const key of absent() ? [] : structuralStore.activeKeysSnapshot()) {
      const subjectId = structuralStore.subjectIdForKey(key);
      if (subjectId === void 0) continue;
      const row = getProjectedEntity(key);
      if (row === void 0) continue;
      seed.push({ subjectId, key, row });
    }
    return seed;
  });
  Object.defineProperty(api, "__findKeyBySubjectId", {
    value: findKeyBySubjectId,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__prepareOrdinaryRealization", {
    value: prepareOrdinaryRealization2,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__preparePointValues", {
    value: preparePointValues,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planFreshAdd", {
    value: planFreshAdd,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__restoreOne", {
    value: restoreOne,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planRekey", {
    value: planRekey,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planPreparedRekey", {
    value: planPreparedRekey,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planRemove", {
    value: planRemove,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planRestore", {
    value: planRestore,
    enumerable: false,
    configurable: true
  });
  if (positionId !== void 0) {
    Object.defineProperty(api, "__prepareTransitionTarget", {
      value: {
        owner: positionId,
        ownerPath: basePath,
        readSource: readTransitionSource,
        readOrderFrontier: () => structuralStore.activeOrderFrontier(),
        installCompensatedOrderFrontier: (frontier) => structuralStore.installCompensatedOrderFrontier(frontier),
        prepareTarget: (target, prepare) => prepare(
          {
            positionId,
            structuralStore,
            valueStore,
            ordinaryTopology,
            prepareOrdinaryRealization: prepareOrdinaryRealization2,
            activeIdSignal,
            subjectEpochs,
            subjectStateSignals,
            get membershipTap() {
              return membershipTap;
            },
            advanceEpochHandle,
            updateSignals,
            physicalCommitClock,
            pathNotifier,
            basePath,
            getPositionIdsForNotify,
            createStructuralEffectMeta,
            ambientMeta,
            emitTap,
            publishOrderChange(before, after, beforeFrontier, afterFrontier, ordinaryEndpoints, selectedDisposition) {
              if (survivingOrderChanged(before, after) || ordinaryEndpoints !== void 0)
                publishOrderChange(
                  before,
                  after,
                  beforeFrontier,
                  afterFrontier,
                  ordinaryEndpoints,
                  selectedDisposition
                );
            }
          },
          target
        )
      },
      enumerable: false,
      configurable: true
    });
  }
  Object.defineProperty(api, "__inspectSubjectResources", {
    value: inspectSubjectResources,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__listSubjectReclamationCandidates", {
    value: listSubjectReclamationCandidates,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__acquireEntityHandleForTesting", {
    value: acquireEntityHandleForTesting,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__resolveEntityHandleForTesting", {
    value: resolveEntityHandleForTesting,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__rebuildActiveProjectionFromOwnersForTesting", {
    value: rebuildActiveProjectionFromOwners,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__planSubjectReclamation", {
    value: (subjectId, options2) => {
      const inventory = inspectSubjectResources(subjectId);
      return inventory ? planEntitySubjectReclamation(inventory, options2) : void 0;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__prepareSubjectReclamation", {
    value: prepareSubjectReclamation,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__applyPreparedSubjectReclamation", {
    value: applyPreparedSubjectReclamation,
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(api, "__retireSubjectRetainedValueBackingForTesting", {
    value: retireSubjectRetainedValueBackingForTesting,
    enumerable: false,
    configurable: true
  });
  const warnedWrongMethods = /* @__PURE__ */ new Set();
  const proxy = new Proxy(api, {
    get: (target, prop) => {
      if (typeof prop === "string" && !isNaN(Number(prop))) {
        return api.byId(Number(prop));
      }
      if (typeof prop === "string" && !(prop in target) && WRONG_ENTITY_METHODS[prop] && (typeof ngDevMode === "undefined" || ngDevMode) && !warnedWrongMethods.has(prop)) {
        warnedWrongMethods.add(prop);
        console.warn(
          `SignalTree entityMap has no \`.${prop}()\`. Did you mean: ${WRONG_ENTITY_METHODS[prop]}? [ST2002]`
        );
      }
      return target[prop];
    }
  });
  return proxy;
}
Object.defineProperty(
  createEntitySignal,
  "__setPositionIdAllocatorForTesting",
  {
    value: setEntityPositionIdAllocatorForTesting,
    enumerable: false,
    configurable: true
  }
);
Object.defineProperty(
  createEntitySignal,
  "__setPositionIdNotifyEnabledForTesting",
  {
    value: setEntityPositionIdNotifyEnabledForTesting,
    enumerable: false,
    configurable: true
  }
);

// packages/kernel/src/lib/markers/entity-map.ts
var ENTITY_SLICE_RESERVED_NAMES = "byId|byIdOrFail|all|count|ids|has|empty|asMap|where|find|activeId|activeEntity|setActiveId|clearActiveId|addOne|addMany|prependOne|prependMany|changeId|updateOne|replaceOne|updateMany|updateWhere|upsertOne|upsertMany|removeOne|removeMany|removeWhere|clear|setAll|tap|intercept".split(
  "|"
);
function entityMap(config) {
  registerEntityMapProcessor();
  const slices = {};
  const combined = {
    __isEntityMap: true,
    __entityMapConfig: config ?? {},
    __computedSlices: slices,
    computed(name, compute) {
      if (ENTITY_SLICE_RESERVED_NAMES.includes(name)) {
        throw new TypeError(`SignalTree: reserved entityMap slice "${name}".`);
      }
      slices[name] = { compute };
      return combined;
    },
    build() {
      return combined;
    }
  };
  return combined;
}
function registerEntityMapProcessor() {
  registerBuiltinMarkerProcessor(
    isEntityMapMarker,
    (marker, notifier, path, context, parentPositionId) => {
      const cfg = marker.__entityMapConfig ?? {};
      const hasPositionTopology = context.hasCapability("position-topology");
      const hasMutationCapture = context.hasCapability("mutation-capture");
      const entitySignal = createEntitySignal(
        cfg,
        notifier,
        path,
        {
          physicalCommitClock: context.physicalCommitClock,
          mutationCaptureRuntime: context.mutationCaptureRuntime,
          // ADDRESS-REPAIR-1. The collection's own position is allocated
          // here, and `path` IS its canonical address — both facts are known
          // at exactly this point and nowhere later. Registering them makes
          // every downstream consumer able to ASK which collection owns a
          // position instead of guessing from a path's dot shape, which
          // REALIZATION-ADDRESS-0 measured wrong for every nested case.
          positionIdAllocator: hasPositionTopology ? () => {
            const positionId = context.allocatePositionId(parentPositionId);
            if (positionId !== void 0) {
              context.positionRegistry.registerCollectionPath(
                positionId,
                path
              );
            }
            return positionId;
          } : () => void 0,
          ownerMetadataEnabled: hasMutationCapture,
          subjectMetadataEnabled: hasMutationCapture,
          positionMetadataEnabled: hasPositionTopology,
          ownerId: context.positionRegistry.id,
          locationRuntime: context.locationRuntime,
          // Immutable for the life of the tree — see RuntimeTreePlan. False
          // is what lets the retirement boundary release a retired subject's
          // value backing immediately.
          hasRestorationAuthority: context.runtimeTreePlan.hasRestorationAuthority
        }
      );
      definePositionRegistry(
        entitySignal,
        context.positionRegistry
      );
      Object.defineProperty(entitySignal, MUTATION_CAPTURE_RUNTIME, {
        value: context.mutationCaptureRuntime
      });
      if (context.runtimeTreePlan.hasRestorationAuthority) {
        context.physicalOwners.push(
          entitySignal
        );
      }
      const slices = marker.__computedSlices;
      if (slices) {
        for (const [name, sliceConfig] of Object.entries(slices)) {
          const computedSignal = context.locationRuntime.createDerived(
            () => sliceConfig.compute(entitySignal.all())
          );
          entitySignal[name] = computedSignal;
        }
      }
      return entitySignal;
    },
    {
      // STATE: the entities. `ids`, `count`, `empty` and `map` are all
      // derived from `all` — and `map` is a JS `Map`, which JSON cannot
      // represent, so it used to serialise as `{}`: a snapshot claiming the
      // collection was EMPTY while holding 10,000 entities.
      snapshot: (node) => ({ all: node.all() }),
      hydrate: (node, value) => {
        if (value === null || typeof value !== "object") return;
        const all = Array.isArray(value) ? value : value.all;
        if (Array.isArray(all)) {
          const incoming = all;
          const current = node.all();
          let diffed = false;
          if (current.length === incoming.length) {
            const changed = [];
            for (let i = 0; i < incoming.length; i++) {
              if (current[i] !== incoming[i]) changed.push(incoming[i]);
            }
            if (changed.length < incoming.length) {
              for (const entity of changed) node.upsertOne(entity);
              const updated = node.all();
              diffed = updated.length === incoming.length && updated.every((entity, index) => entity === incoming[index]);
            }
          }
          if (!diffed) node.setAll(incoming);
        } else if (typeof ngDevMode === "undefined" || ngDevMode) {
          console.warn(
            `SignalTree: entityMap hydrate ignored a payload with no \`all\` array. The collection was left unchanged. This is a PAYLOAD problem, not a registration one \u2014 a pre-2.0.0 snapshot emitted \`map\`, which JSON renders as \`{}\`, so the entities were never in it. [ST2024]`
          );
        }
      }
    }
  );
}

// packages/kernel/src/lib/types.ts
var SignalTreeRollbackError = class _SignalTreeRollbackError extends Error {
  code = "SIGNALTREE_ROLLBACK_FAILED";
  /**
   * Non-enumerable when set, so structured logging cannot drag a live
   * transaction handle into a serialized error payload. Read it directly.
   */
  recovery;
  // NOT declared as a field. Whether `cause` exists on `Error` depends on the
  // lib target, and the workspace disagrees: the demo's compiler requires
  // `override` (TS4114) while core's rollup build rejects it as not present in
  // the base (TS4113). Assigning without declaring satisfies both.
  constructor(message = "SignalTree could not rollback the pending transaction", options) {
    super(message);
    this.name = "SignalTreeRollbackError";
    this.cause = options?.cause;
    Object.setPrototypeOf(this, _SignalTreeRollbackError.prototype);
  }
};

// packages/kernel/src/lib/signal-tree.ts
var isWritableCell = (v) => typeof v === "function" && "set" in v && typeof v.set === "function";
var readWritableCell = (cell) => "peek" in cell && typeof cell.peek === "function" ? cell.peek() : cell();
var ENTITY_ARRAY_MIN_LENGTH = 32;
var ENTITY_ARRAY_SAMPLE = 64;
var ENTITY_ID_KEYS = ["id", "_id", "uuid", "key"];
var ENTITY_ARRAY_WARNED = /* @__PURE__ */ new Set();
var ENTITY_ARRAY_WARN_CAP = 256;
var NODE_ACCESSOR_PEER2 = Symbol.for("SignalTree:NodeAccessorPeer");
function createTreeBuildPlan(requestedCapabilities, leafMetadataStorage) {
  const resolved = resolveTreeCapabilities(requestedCapabilities);
  return {
    requestedCapabilities: resolved.requestedCapabilities,
    capabilities: resolved.resolvedCapabilities,
    has(capability) {
      return resolved.resolvedCapabilities.includes(capability);
    },
    leafMetadataStorage
  };
}
function finalizeLeafSignal(leaf2, path, positionIds, buildPlan, captureRuntime, registry, address) {
  defineNodeAddress(leaf2, address);
  for (const position of positionIds ?? [])
    registry?.registerPositionAddress(position, address);
  if (buildPlan.has("position-topology") && registry) {
    definePositionRegistry(leaf2, registry);
  }
  if (buildPlan.has("mutation-capture")) {
    wrapOwnedWritableSignal(leaf2, {
      path,
      // `ownerPath: path` sat here until 15.0 (ME-B). The owner-address fact is
      // still installed on the leaf — it is now derived from `path` inside
      // owned-mutation rather than passed as a second, identical argument.
      positionIds,
      ownerId: registry?.id,
      metadataStorage: buildPlan.leafMetadataStorage,
      captureRuntime
    });
    return;
  }
  if (buildPlan.has("position-topology")) {
    defineOwnedPositionIds(leaf2, positionIds);
    defineOwnedOwnerId(leaf2, registry?.id);
  }
  if (registry) {
    definePositionRegistry(leaf2, registry);
    defineOwnedOwnerPath(leaf2, path);
    installDormantObservation(leaf2);
  }
}
function getEnhancerMeta(enhancer) {
  return enhancer[ENHANCER_META] ?? enhancer.metadata;
}
function buildTreePlan(enhancers, explicitCapabilities = []) {
  const requestedCapabilities = collectRequestedTreeCapabilities([
    ...enhancers.map((enhancer) => getEnhancerMeta(enhancer)),
    // An explicit request is treated as one more declaration, so it goes
    // through the same dependency resolution rather than bypassing it.
    { capabilities: [...explicitCapabilities] }
  ]);
  return createTreeBuildPlan(requestedCapabilities, "property");
}
function materializeTreeMarkers(tree, materializationContext, authority) {
  materializeMarkers(tree.$, void 0, [], materializationContext, authority);
  _recordTreeConstruction();
}
function isEntityMapMarker2(value) {
  return Boolean(
    value && typeof value === "object" && value["__isEntityMap"] === true
  );
}
function createEqualityFn(useShallowComparison) {
  return useShallowComparison ? Object.is : deepEqual;
}
function makeNodeAccessor(store, ownerPath, positionIds, registry, locations) {
  const isRoot = ownerPath === "";
  const self = {};
  const applyGrouped = (run) => {
    if (locations) locations.runInvalidationGroup(run);
    else run();
  };
  const accessor = {
    node(arg) {
      if (arguments.length === 0) {
        if (!isRoot && self.accessor !== void 0 && isAbsentMember(self.accessor)) {
          observeMembership(store);
          return void 0;
        }
        return materializeNode(store);
      }
      const absent = !isRoot && isAbsentMember(self.accessor);
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = absent ? void 0 : unwrap(store);
        updates = updater(current);
      }
      applyGrouped(() => {
        recursiveUpdate(store, updates, void 0, "");
        if (absent && updates && typeof updates === "object")
          reactivatePathOnWrite(self.accessor);
      });
    }
  }.node;
  self.accessor = accessor;
  accessor[CALLABLE_SIGNAL_SYMBOL] = true;
  Object.defineProperty(accessor, NODE_STORE_SYMBOL, {
    value: store,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(store, NODE_ACCESSOR_PEER2, {
    value: accessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  for (const key of Object.keys(store)) {
    Object.defineProperty(accessor, key, {
      value: store[key],
      enumerable: true,
      writable: true,
      configurable: true
    });
  }
  const address = getNodeAddress(store);
  if (address) defineNodeAddress(accessor, address);
  if (positionIds && positionIds.length > 0) {
    defineOwnedPositionIds(accessor, positionIds);
  }
  if (ownerPath !== void 0) {
    defineOwnedOwnerPath(accessor, ownerPath);
  }
  if (registry) {
    definePositionRegistry(accessor, registry);
    defineOwnedOwnerId(accessor, registry.id);
    definePositionRegistry(store, registry);
    defineOwnedOwnerId(store, registry.id);
  }
  if (locations) {
    bindLocationRuntime(accessor, locations);
    bindLocationRuntime(store, locations);
  }
  return accessor;
}
var MARKER_IN_ARRAY_WARNED = /* @__PURE__ */ new Set();
var looksLikeMarker = (item) => item !== null && typeof item === "object" && (isEntityMapMarker2(item) || isRegisteredMarker(item));
function warnMarkerInContainer(key, value) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (MARKER_IN_ARRAY_WARNED.has(key)) return;
  let where;
  let container;
  if (Array.isArray(value)) {
    const limit = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
    for (let i = 0; i < limit; i++) {
      if (looksLikeMarker(value[i])) {
        where = `"${key}[${i}]"`;
        container = "an array. Array elements";
        break;
      }
    }
  } else if (value instanceof Map) {
    let i = 0;
    for (const [k, v] of value) {
      if (i++ >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(v)) {
        where = `"${key}" -> Map value at key ${JSON.stringify(String(k))}`;
        container = "a Map. Map values";
        break;
      }
    }
  } else if (value instanceof Set) {
    let i = 0;
    for (const member of value) {
      if (i >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(member)) {
        where = `"${key}" -> Set member #${i}`;
        container = "a Set. Set members";
        break;
      }
      i++;
    }
  }
  if (where === void 0 || container === void 0) return;
  MARKER_IN_ARRAY_WARNED.add(key);
  console.warn(
    `SignalTree: ${where} holds a MARKER inside ${container} are never traversed, so the marker is never materialised \u2014 it stays a raw object, it is not a signal, and writes to it are lost. Markers belong at object positions; for a keyed collection use entityMap({ selectId }). [ST2021]`
  );
}
function warnEntityArrayLeaf(key, value) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (value.length < ENTITY_ARRAY_MIN_LENGTH) return;
  const first = value[0];
  if (first === null || typeof first !== "object" || Array.isArray(first)) {
    return;
  }
  const idKey = ENTITY_ID_KEYS.find((candidate) => {
    const v = first[candidate];
    return typeof v === "string" || typeof v === "number";
  });
  if (!idKey) return;
  const sampleSize = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
  const seen = /* @__PURE__ */ new Set();
  for (let i = 0; i < sampleSize; i++) {
    const item = value[i];
    if (item === null || typeof item !== "object" || Array.isArray(item)) {
      return;
    }
    const id = item[idKey];
    if (typeof id !== "string" && typeof id !== "number") return;
    if (seen.has(id)) return;
    seen.add(id);
  }
  const seenKey = `${key}:${idKey}`;
  if (ENTITY_ARRAY_WARNED.has(seenKey)) return;
  if (ENTITY_ARRAY_WARNED.size >= ENTITY_ARRAY_WARN_CAP) return;
  ENTITY_ARRAY_WARNED.add(seenKey);
  console.warn(
    `SignalTree: "${key}" holds ${value.length} objects with a stable "${idKey}" \u2014 use entityMap({ selectId: (e) => e.${idKey} }). An array leaf rebuilds and re-compares the whole array on every update \u2014 two orders of magnitude at 50k. Read-only or replaced wholesale? Leave it plain; otherwise model it as an entityMap. [ST2018]`
  );
}
function warnDiscardedBranchWrite(path, value) {
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    console.error(
      `SignalTree: write to "${path}" DISCARDED \u2014 a branch cannot be replaced by a non-object value (received ${value === null ? "null" : typeof value}). Write the leaves, or use a marker if this position should hold a value. [ST2014]`
    );
  }
}
function warnMissingForward(method) {
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    console.error(
      `SignalTree: "${method}" could not be forwarded \u2014 an enhancer in the configured set returned a tree without it, so this call did NOTHING. An enhancer that builds a new tree object must copy own property DESCRIPTORS, not Object.assign, which skips non-enumerable methods. [ST2017]`
    );
  }
}
var warnedNoopPaths = /* @__PURE__ */ new Set();
var warnedNoopCopyPaths = /* @__PURE__ */ new Set();
function isLargeEnoughToMatter(value) {
  if (Array.isArray(value)) return value.length >= 32;
  if (value instanceof Map || value instanceof Set) return value.size >= 32;
  return Object.keys(value).length >= 32;
}
setMemberValueApplier(
  (parent, key, member, value) => {
    if (typeof member === "function") {
      member(value);
    }
    const woke = setMemberPresence(parent, key, "active");
    if (woke) publishMembershipChange(parent);
  }
);
var ordinaryMemberBuilders = /* @__PURE__ */ new WeakMap();
function ordinaryConstructionValue(value, key) {
  if (isEntityMapMarker2(value) || isRegisteredMarker(value)) {
    throw new TypeError("SignalTree: marker definitions belong in initial state, not ordinary whole-value writes.");
  }
  if (isLeafDefinition(value)) {
    const inner = leafDefinitionValue(value);
    if (isEntityMapMarker2(inner) || isRegisteredMarker(inner)) {
      throw new TypeError("SignalTree: leaf() cannot wrap a semantic marker.");
    }
    return leaf(inner);
  }
  if (value === null || typeof value !== "object") return leaf(value);
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    if (!Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
      console.warn(
        `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
      );
    }
  }
  if (Array.isArray(value) || isBuiltInObject(value)) {
    warnMarkerInContainer(key, value);
    if (Array.isArray(value)) warnEntityArrayLeaf(key, value);
    return leaf(value);
  }
  const prepared = {};
  for (const [childKey, child] of Object.entries(value)) {
    if (childKey !== "__proto__") prepared[childKey] = ordinaryConstructionValue(child, childKey);
  }
  return prepared;
}
function prepareOrdinaryMembers(target, updates, whole) {
  const plans = /* @__PURE__ */ new Map();
  const visit = (target2, updates2, whole2) => {
    if (!updates2 || typeof updates2 !== "object") return;
    const store = isNodeAccessor(target2) ? target2[NODE_STORE_SYMBOL] : target2;
    const entries = Object.entries(updates2);
    const additions = /* @__PURE__ */ new Map();
    plans.set(store, { entries, additions });
    const build = whole2 ? ordinaryMemberBuilders.get(store) : void 0;
    for (const [key, value] of entries) {
      if (key === "__proto__") continue;
      if (build && !Object.prototype.hasOwnProperty.call(store, key)) {
        const prepared = ordinaryConstructionValue(value, key);
        additions.set(key, () => build(key, prepared));
      } else if (isNodeAccessor(store[key]) && value && typeof value === "object") {
        visit(store[key], value, true);
      }
    }
  };
  visit(target, updates, whole);
  return plans;
}
function recursiveUpdate(target, updates, out, pathPrefix = "", reconcileMembership = true, since = ++structuralWrites.stamp, prepared = prepareOrdinaryMembers(target, updates, reconcileMembership)) {
  if (!updates || typeof updates !== "object") return;
  beginStructuralWrite();
  let publishMembership;
  let applicationFailed = false;
  let applicationError;
  try {
    const targetObj = isNodeAccessor(target) ? target[NODE_STORE_SYMBOL] : target;
    const plan = prepared.get(targetObj);
    if (!plan) return;
    const { entries, additions } = plan;
    const branch = targetObj[NODE_ACCESSOR_PEER2] ?? targetObj;
    const dormant = hasDormantMembers(targetObj);
    publishMembership = reconcileMembership || dormant ? captureBranchMembershipIfObserved(
      targetObj[NODE_ACCESSOR_PEER2] ?? targetObj,
      updates,
      !reconcileMembership
    ) : void 0;
    const installed = dormant ? /* @__PURE__ */ new Set() : void 0;
    for (const [key, rawValue] of entries) {
      let value = rawValue;
      if (key === "__proto__") continue;
      const buildAddition = additions.get(key);
      if (buildAddition && !Object.prototype.hasOwnProperty.call(targetObj, key)) {
        const { child, responsibility } = buildAddition();
        inheritObservationForAddedMember(branch, child);
        installPreparedMember(branch, key, child, responsibility);
        publishMembershipChange(branch);
        installed?.add(key);
        out?.push(pathPrefix ? `${pathPrefix}.${key}` : key);
        continue;
      }
      const prop = Object.getOwnPropertyDescriptor(targetObj, key)?.value;
      const childPath = pathPrefix ? `${pathPrefix}.${key}` : key;
      if (prop === void 0) {
        if (typeof ngDevMode === "undefined" || ngDevMode) {
          console.error(
            `SignalTree: write to "${childPath}" DISCARDED \u2014 key is not in the tree's initial shape. [ST2010]`
          );
        }
        continue;
      }
      const ownHydrate = structuralWrites.own;
      structuralWrites.own = prop;
      let hydrated;
      try {
        hydrated = hydrateMarkerNode(prop, value, "restore");
      } finally {
        structuralWrites.own = ownHydrate;
      }
      if (hydrated) {
        if (out) out.push(childPath);
        installed?.add(key);
        continue;
      }
      if (isNodeAccessor(prop)) {
        if (typeof value === "function") {
          const updater = value;
          value = updater(isAbsentMember(prop) ? void 0 : unwrap(prop));
          const mergeable = isTraversableNode(value) && typeof value !== "function" && !isBuiltInObject(value) && !Array.isArray(value) && typeof value.then !== "function";
          if (!mergeable) {
            warnDiscardedBranchWrite(childPath, value);
            continue;
          }
        }
        if (typeof value === "function") {
          warnDiscardedBranchWrite(childPath, value);
        } else if (value && typeof value === "object") {
          recursiveUpdate(
            prop,
            value,
            out,
            childPath,
            true,
            since,
            prepared.has(
              prop[NODE_STORE_SYMBOL]
            ) ? prepared : prepareOrdinaryMembers(prop, value, true)
          );
          installed?.add(key);
        } else if (value === void 0) {
          continue;
        } else {
          warnDiscardedBranchWrite(childPath, value);
        }
      } else if (isWritableLocation(prop) || isWritableCell(prop)) {
        const sig = prop;
        const current = readWritableCell(sig);
        if (current === value && !isAbsentMember(sig) && !needsLocationAuthorityAdmission(sig)) {
          if ((typeof ngDevMode === "undefined" || ngDevMode) && value !== null && typeof value === "object" && !warnedNoopPaths.has(childPath)) {
            warnedNoopPaths.add(childPath);
            console.warn(
              `SignalTree: write at "${childPath}" was skipped \u2014 the value is reference-identical to the current value. If you mutated an object/array in place, create a NEW reference (spread/slice/map) so the change is observed. [ST2003]`
            );
          }
          continue;
        }
        const wasAbsent = out !== void 0 && isAbsentMember(sig);
        const ownWrite = structuralWrites.own;
        structuralWrites.own = sig;
        try {
          if (isWritableLocation(sig)) replaceLocation(sig, value);
          else sig.set(value);
        } finally {
          structuralWrites.own = ownWrite;
        }
        installed?.add(key);
        if (out) {
          if (wasAbsent || !Object.is(readWritableCell(sig), current))
            out.push(childPath);
        }
      }
    }
    const membershipChanged = [];
    const supplied = reconcileMembership || installed ? new Set(Object.keys(updates)) : void 0;
    if (supplied)
      for (const key of reconcileMembership ? Object.getOwnPropertyNames(targetObj) : supplied) {
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("membershipKeysVisited");
        }
        const descriptor = Object.getOwnPropertyDescriptor(targetObj, key);
        if (!descriptor || !("value" in descriptor)) continue;
        if (!supplied.has(key)) {
          if (descriptor.enumerable && // A write made while this whole value ran re-added it: it stays.
          !readdedDuringStructuralWrite(targetObj, key, since) && setMemberPresence(targetObj, key, "dormant")) {
            membershipChanged.push(key);
          }
        } else if (
          // Only a member whose supplied value was installed is re-added: a key
          // supplied as `undefined`, or with a value the loop discarded, would
          // otherwise come back with its retained storage. Measured before v16 8d:
          // `$({ a: undefined, count: 0 })` re-added an omitted `a` as `{ v: 1 }`.
          // "DORMANT STORAGE MUST NOT SUPPLY THE REACTIVATED VALUE" (case 18).
          !descriptor.enumerable && installed?.has(key) && setMemberPresence(targetObj, key, "active")
        ) {
          membershipChanged.push(key);
        }
      }
    if (membershipChanged.length > 0) {
      republishMembers(targetObj, membershipChanged);
    }
  } catch (error) {
    applicationFailed = true;
    applicationError = error;
  } finally {
    try {
      try {
        publishMembership?.();
      } catch (error) {
        if (!applicationFailed) {
          applicationFailed = true;
          applicationError = error;
        } else {
          reportContainedObserverError({ error, operation: "notify:subscriber" });
        }
      }
    } finally {
      endStructuralWrite();
    }
  }
  if (applicationFailed) throw applicationError;
}
function leafEqual(base, path) {
  return (a, b) => {
    const eq = base(a, b);
    if (eq && a !== b && a !== null && typeof a === "object" && isLargeEnoughToMatter(a) && !warnedNoopCopyPaths.has(path)) {
      warnedNoopCopyPaths.add(path);
      console.warn(
        `SignalTree: a write to "${path || "(root leaf)"}" changed NOTHING \u2014 the new value is a different object but deep-equals the current one, so the whole structure was compared and the write discarded. A re-fetched payload does this. Skip the write when the data is unchanged, or write the smaller changed leaf. [ST2027]`
      );
    }
    return eq;
  };
}
function materializeOrdinaryBranch(value, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, childPositionIds, childPath, address, preparedOrdinary = false) {
  const nested = createSignalStore(
    value,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    childPositionIds,
    childPath,
    address,
    preparedOrdinary
  );
  const accessor = makeNodeAccessor(
    nested,
    childPath,
    childPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(accessor, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(nested, scalarSlotRuntime);
  }
  return accessor;
}
function createSignalStore(obj, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, positionIds, path = "", address = [], preparedOrdinary = false) {
  for (const position of positionIds ?? []) {
    materializationContext.positionRegistry.registerPositionAddress(
      position,
      address
    );
  }
  const createLeafSignal = (value, leafPositionIds, equal) => {
    if (scalarSlotRuntime) {
      return scalarSlotRuntime.createLeaf(
        value,
        equal,
        leafPositionIds?.[0]
      );
    }
    return materializationContext.locationRuntime.createCell(value, equal);
  };
  if (obj === null || obj === void 0 || typeof obj !== "object") {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (Array.isArray(obj)) {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (isBuiltInObject(obj)) {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  const store = {};
  defineNodeAddress(store, address);
  ordinaryMemberBuilders.set(store, (key, value) => {
    const prepared = createSignalStore(
      { [key]: value },
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      positionIds,
      path,
      address,
      true
    );
    const child = prepared[key];
    const branch = store[NODE_ACCESSOR_PEER2] ?? store;
    return { child, responsibility: captureRuntime.prepareMemberResponsibility?.(branch, key, child) };
  });
  for (const [key, definedValue] of Object.entries(
    obj
  )) {
    const childAddress = childAddressOf(address, key);
    const childPath = path ? `${path}.${key}` : key;
    const terminal = isLeafDefinition(definedValue);
    const value = terminal ? leafDefinitionValue(definedValue) : definedValue;
    if (!preparedOrdinary && terminal && (isEntityMapMarker2(value) || isRegisteredMarker(value))) {
      throw new Error(
        `SignalTree: leaf() cannot wrap a semantic marker at "${childPath}".`
      );
    }
    let childPositionIds;
    const getChildPositionIds = () => {
      if (!materializationContext.positionTopologyEnabled) {
        return void 0;
      }
      return childPositionIds ??= [
        materializationContext.allocatePositionId(positionIds?.[0])
      ];
    };
    if (key === "__proto__") {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        console.error(
          `SignalTree: dropped a "__proto__" key from the initial state \u2014 it cannot be a state key. If this came from JSON.parse, the payload is attempting prototype pollution. [ST2016]`
        );
      }
      continue;
    }
    if (!preparedOrdinary && isEntityMapMarker2(value)) {
      store[key] = value;
      continue;
    }
    if (!preparedOrdinary && isRegisteredMarker(value)) {
      store[key] = value;
      continue;
    }
    if (typeof ngDevMode === "undefined" || ngDevMode) {
      if (!preparedOrdinary && !terminal && value !== null && typeof value === "object" && !Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
        console.warn(
          `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
        );
      }
    }
    if (terminal || value === null || value === void 0 || typeof value !== "object") {
      const childPositionIds2 = getChildPositionIds();
      const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    if (Array.isArray(value) || isBuiltInObject(value)) {
      warnMarkerInContainer(key, value);
      if (Array.isArray(value)) {
        warnEntityArrayLeaf(key, value);
      }
      const childPositionIds2 = getChildPositionIds();
      const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    store[key] = materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      getChildPositionIds(),
      childPath,
      childAddress,
      preparedOrdinary
    );
  }
  markTreeStore(store);
  return store;
}
function create(initialState, config, materializationContext, buildPlan, captureRuntime = createMutationCaptureRuntime(), createScalarLeafRuntime = createTreeScalarLeafRuntime) {
  if (initialState === null || initialState === void 0) {
    throw new Error(SIGNAL_TREE_MESSAGES.NULL_OR_UNDEFINED);
  }
  const equalityFn = createEqualityFn(config.useShallowComparison ?? false);
  const scalarSlotRuntime = createScalarLeafRuntime(
    materializationContext.physicalCommitClock,
    materializationContext.locationRuntime
  );
  const materializeOrdinaryState = (value, path, parentPositionId, address) => {
    const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(parentPositionId)] : void 0;
    return materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      childPositionIds,
      path,
      address
    );
  };
  const constructionAuthority = {
    materialize: materializeOrdinaryState,
    bindMember: (ownerBranch) => {
      const ownerPositionId = getOwnedPositionIds(ownerBranch)?.[0];
      const ownerPath = getOwnedOwnerPath(ownerBranch) ?? "";
      const ownerAddress = getNodeAddress(ownerBranch);
      if (!ownerAddress)
        throw new Error("Missing dynamic branch construction address.");
      return (key, value) => {
        const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(ownerPositionId)] : void 0;
        const childPath = ownerPath ? `${ownerPath}.${key}` : key;
        return materializeOrdinaryBranch(
          value,
          equalityFn,
          materializationContext,
          buildPlan,
          captureRuntime,
          scalarSlotRuntime,
          childPositionIds,
          childPath,
          childAddressOf(ownerAddress, key)
        );
      };
    }
  };
  const rootPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId()] : void 0;
  const signalState = createSignalStore(
    initialState,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    rootPositionIds
  );
  const rootAccessor = makeNodeAccessor(
    signalState,
    "",
    rootPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  const tree = {};
  defineNodeAddress(tree, []);
  bindLocationRuntime(tree, materializationContext.locationRuntime);
  bindLocationRuntime(
    signalState,
    materializationContext.locationRuntime
  );
  bindLocationRuntime(
    rootAccessor,
    materializationContext.locationRuntime
  );
  tree[MUTATION_CAPTURE_RUNTIME] = captureRuntime;
  if (rootPositionIds) {
    defineOwnedPositionIds(tree, rootPositionIds);
    defineOwnedPositionIds(signalState, rootPositionIds);
    defineOwnedPositionIds(rootAccessor, rootPositionIds);
  }
  defineTreeCapabilities(tree, buildPlan.capabilities);
  if (buildPlan.has("mutation-capture")) {
    defineOwnedOwnerPath(tree, "");
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  if (materializationContext.positionTopologyEnabled) {
    definePositionRegistry(
      tree,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      rootAccessor,
      materializationContext.positionRegistry
    );
  }
  if (materializationContext.positionRegistry) {
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  defineRootTree(rootAccessor, {
    read: () => rootAccessor(),
    replace: (value) => rootAccessor(value),
    derive: (update) => rootAccessor(update)
  });
  if (materializationContext.physicalCommitClock) {
    definePhysicalCommitClock(
      tree,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      signalState,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      rootAccessor,
      materializationContext.physicalCommitClock
    );
  }
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(tree, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(signalState, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(rootAccessor, scalarSlotRuntime);
  }
  const cleanupFns = [];
  const destroyedSig = materializationContext.locationRuntime.createCell(false);
  Object.defineProperty(tree, "$", {
    value: rootAccessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "destroy", {
    value: function() {
      if (destroyedSig()) return;
      try {
        replaceLocation(destroyedSig, true);
      } finally {
        terminateOwnerInvalidation(tree);
        for (const fn of cleanupFns) {
          try {
            fn();
          } catch {
          }
        }
        cleanupFns.length = 0;
        releaseContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
      if (config.debugMode) {
        console.log(SIGNAL_TREE_MESSAGES.TREE_DESTROYED);
      }
    },
    enumerable: false,
    // Allow enhancers (like guardrails) to override/replace `destroy` at runtime.
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree, "destroyed", {
    value: destroyedSig.asReadonly(),
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "registerCleanup", {
    value: function(fn) {
      if (typeof fn === "function") {
        cleanupFns.push(fn);
      }
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "clearCache", {
    value: () => {
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree, "updateAndReport", {
    value: function(arg) {
      if (arguments.length === 0) return [];
      const out = [];
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = unwrap(signalState);
        updates = updater(current);
      }
      materializationContext.locationRuntime.runInvalidationGroup(() => {
        recursiveUpdate(signalState, updates, out, "", false);
      });
      return out;
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  return {
    tree,
    authority: constructionAuthority,
    activateReporting() {
      if (!readWritableCell(destroyedSig)) {
        registerContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
    }
  };
}
function applyEnhancers(tree, ordered) {
  let current = tree;
  for (const enhancer of ordered) {
    if (typeof enhancer !== "function") {
      throw new Error("Enhancer must be a function");
    }
    const result = enhancer(
      current
    );
    if (result !== current && isTraversableNode(result)) {
      current = result;
    }
  }
  return current;
}
function signalTreeImpl(initialState, config = {}, observation = NEUTRAL_OBSERVATION_ADAPTER, createScalarLeafRuntime = createTreeScalarLeafRuntime, createLocations = createLocationRuntime) {
  const declared = config.enhancers ?? [];
  const ordered = resolveEnhancerOrder(
    [...declared],
    /* @__PURE__ */ new Set(),
    Boolean(config.debugMode)
  );
  const buildPlan = buildTreePlan(ordered, config.capabilities);
  const physicalCommitClock = buildPlan.has("causal-runtime") ? createPhysicalCommitClock() : void 0;
  const captureRuntime = createMutationCaptureRuntime();
  const materializationContext = createMaterializationContext(
    buildPlan.has("position-topology"),
    (capability) => buildPlan.has(capability),
    physicalCommitClock,
    createLocations(observation)
  );
  materializationContext.mutationCaptureRuntime = captureRuntime;
  const constructed = create(
    initialState,
    config,
    materializationContext,
    buildPlan,
    captureRuntime,
    createScalarLeafRuntime
  );
  let tree = constructed.tree;
  const authority = constructed.authority;
  const hasEnhancers = ordered.length > 0;
  if (hasEnhancers) {
    materializeTreeMarkers(tree, materializationContext, authority);
    Object.defineProperty(
      tree.$,
      Symbol.for("SignalTree:SubjectPhysicalOwners"),
      {
        value: materializationContext.physicalOwners,
        enumerable: false,
        configurable: true
      }
    );
    tree = applyEnhancers(tree, ordered);
  }
  const configured = createConfiguredTree(
    tree,
    materializationContext,
    hasEnhancers,
    authority,
    config.derived
  );
  constructed.activateReporting();
  return configured;
}
function createConfiguredTree(baseTree, materializationContext, alreadyMaterialized = false, authority, derivedFactory) {
  let isFinalized = false;
  let markersMaterialized = alreadyMaterialized;
  const materializeOnly = () => {
    if (markersMaterialized) return;
    markersMaterialized = true;
    materializeMarkers(
      baseTree.$,
      void 0,
      [],
      materializationContext,
      authority
    );
    _recordTreeConstruction();
  };
  const finalize = () => {
    if (isFinalized) return;
    isFinalized = true;
    materializeOnly();
    if (derivedFactory) {
      applyDerivedFactory(
        baseTree.$,
        derivedFactory,
        materializationContext.locationRuntime
      );
    }
  };
  const rootAccessor = baseTree.$;
  Object.defineProperty(baseTree, "$", {
    get() {
      finalize();
      Object.defineProperty(baseTree, "$", {
        value: rootAccessor,
        enumerable: false,
        configurable: true
      });
      return rootAccessor;
    },
    enumerable: false,
    configurable: true
  });
  const updateAndReport = baseTree.updateAndReport?.bind(baseTree);
  Object.defineProperty(baseTree, "updateAndReport", {
    value: function(arg) {
      finalize();
      if (!updateAndReport) {
        warnMissingForward("updateAndReport");
        return [];
      }
      return updateAndReport(arg);
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  return baseTree;
}
var signalTree = signalTreeImpl;

// packages/kernel/src/lib/internals/restoration-eligibility.ts
function isMetaDesignated(meta) {
  return meta?.restorationDesignated === true;
}
function markMetaDesignated(meta) {
  const stamped = { restorationDesignated: true };
  if (meta) {
    for (const key of Reflect.ownKeys(meta)) {
      if (!Object.prototype.propertyIsEnumerable.call(meta, key)) continue;
      const value = Reflect.get(meta, key);
      if (value !== void 0) Reflect.set(stamped, key, value);
    }
  }
  return stamped;
}
var designated = false;
function isRestorationDesignated() {
  return designated;
}

// packages/kernel/src/lib/internals/ordinary-entity-entries.ts
function ordinaryEntityEntries(entry) {
  const changes = getEntityOrdinaryChanges(entry.meta);
  if (changes === void 0) return [ordinaryEntityEntry(entry)];
  const clean = withoutEntityOrdinaryChanges(entry.meta);
  return changes.map((change) => ({
    ...entry,
    path: change.path ?? entry.path,
    newValue: change.after,
    oldValue: change.before,
    subjectIds: [change.subject],
    meta: { ...clean, structuralEffect: change.structuralRecord }
  }));
}

// packages/kernel/src/lib/experimental-publication/projection.ts
var envelope = Symbol("native source identity");
var bindings = /* @__PURE__ */ new Map();
var equals = /* @__PURE__ */ new Map();
function stampSource(meta, subjects, fields, value, prev) {
  return { ...meta, [envelope]: Object.freeze({ subject: subjects?.[0], fields: fields === null ? null : fields && Object.freeze([...fields]), ping: value === void 0 && prev === void 0 }) };
}
function matchingChannels(owner, positions, meta) {
  const e = meta?.[envelope];
  if (meta?.participation === "inspection" || !e || e.ping) return [];
  const effect = meta?.structuralEffect;
  return [...bindings].filter(([, b]) => {
    if (!b.identity.supported || b.owner !== owner || b.position !== positions?.[0]) return false;
    if (b.identity.subject === void 0) return e.subject === void 0;
    if (e.subject !== b.identity.subject || effect?.kind === "rekey") return false;
    return effect?.kind === "remove" || effect?.kind === "add" || e.fields === null || !!e.fields?.includes(b.identity.field);
  }).map(([channel]) => channel);
}
function admitted(channel, fact) {
  const b = bindings.get(channel);
  if (b) {
    b.latest = fact;
    b.queue.push(fact);
  }
}
function completeSource(event) {
  if (!event) return;
  const revision = event.revision;
  for (const [channel, b] of bindings) {
    let consumed = 0;
    for (const f of b.queue) {
      if (f.revision > revision) break;
      b.completed = f;
      consumed++;
    }
    if (consumed) b.queue.splice(0, consumed);
    if (b.completed) b.completions.set(event, b.completed);
  }
}
function deliverEqual(entry) {
  for (const [channel, handler] of [...equals]) {
    const b = bindings.get(channel);
    if (b?.owner === (entry.ownerId ?? entry.meta?.ownerId)) handler(entry.newValue, entry.oldValue, entry.path, entry.ownerPath, entry.origin, entry.subjectIds, entry.positionIds, entry.meta, entry.declaredScopes, entry.ownerId, entry.subjectFieldFootprint);
  }
}

// packages/kernel/src/lib/experimental-publication/lifecycle.ts
var sources = /* @__PURE__ */ new Map();
var authentic = /* @__PURE__ */ new WeakMap();
var pending = /* @__PURE__ */ new Set();
var wakeQueued = false;
function registerOwnerSource(owner, token) {
  if (!sources.has(owner)) sources.set(owner, { token, cells: /* @__PURE__ */ new Map() });
}
function ownerToken(owner) {
  return sources.get(owner)?.token;
}
function ownerCell(owner, id) {
  return sources.get(owner)?.cells.get(id);
}
function pendingOwners() {
  return [...pending];
}
function wake() {
  if (wakeQueued) return;
  wakeQueued = true;
  queueMicrotask(() => {
    wakeQueued = false;
    refreshAll();
    for (const c of [...connections.values()]) c.wake();
  });
}
function ownerTransition(owner, event) {
  const source = sources.get(owner);
  if (!source) return;
  let cell = source.cells.get(event.transactionId);
  if (!cell) {
    if (event.kind !== "opened" && event.kind !== "staged") return;
    cell = { owner, id: event.transactionId, outcome: "pending" };
    source.cells.set(cell.id, cell);
  }
  if (event.kind === "opened" || event.kind === "staged") {
    if (cell.outcome === "pending") pending.add(cell);
    return;
  }
  if (!["confirmed", "rolled-back", "abandoned"].includes(event.kind)) return;
  const outcome = event.kind;
  if (cell.outcome !== "pending" && cell.outcome !== outcome) throw Error("Terminal publication dependency outcome reversed");
  cell.outcome = outcome;
  pending.delete(cell);
  const retired = cell;
  queueMicrotask(() => {
    if (source.cells.get(retired.id) === retired && retired.outcome !== "pending") source.cells.delete(retired.id);
  });
  wake();
}
function abandonOwnerSource(owner) {
  const source = sources.get(owner);
  if (!source) return;
  for (const cell of source.cells.values()) pending.delete(cell);
  source.cells.clear();
  sources.delete(owner);
  wake();
}
function enroll(handle, owner, id) {
  if (owner !== void 0) {
    const cell = ownerCell(owner, id);
    if (cell) authentic.set(handle, cell);
  }
  return handle;
}
var connections = /* @__PURE__ */ new Map();
var stack = [];
function state(view, value) {
  if (["started", "superseded", "disposed", "no-write"].includes(view.value.state)) return;
  view.value = Object.freeze(value);
}
function setOperationState(op, value) {
  for (const view of op.views) state(view, value);
}
function refresh(op) {
  if (op.started) return;
  if (op.frames.size) {
    for (const view of op.views) state(view, { state: "validating" });
    return;
  }
  const p = op.proof;
  if (!p) return;
  if (p.invalid || p.unknown) {
    setOperationState(op, { state: "conservative", reason: p.invalid ? "invalid-declaration" : "unknown" });
    return;
  }
  if (p.owners.some((x) => x.outcome === "rolled-back" || x.outcome === "abandoned")) {
    setOperationState(op, { state: "conservative", reason: "rejected-dependency" });
    return;
  }
  setOperationState(op, p.owners.some((x) => x.outcome === "pending") ? { state: "held", reason: "pending-dependency" } : { state: "eligible", basis: "declared" });
}
function refreshAll() {
  for (const c of connections.values()) for (const op of c.ops.values()) refresh(op);
}
function attachRevision(channel, revision, known, unknown = false) {
  const c = connections.get(channel);
  if (!c || c.disposed) return;
  const matches = stack.filter((f) => f.channel === channel);
  if (matches.length === 0) return;
  const inherited = stack.flatMap((f) => f.owners);
  if (known.some((owner) => !inherited.includes(owner))) for (const f of stack) f.invalid = true;
  let op = c.ops.get(revision);
  if (!op) {
    op = { revision, frames: /* @__PURE__ */ new Set(), views: /* @__PURE__ */ new Set(), started: false, surviving: false };
    c.ops.set(revision, op);
  }
  for (const f of matches) {
    if (f.last && f.last !== revision) {
      const old = c.ops.get(f.last);
      if (old) {
        old.views.delete(f.view);
        if (!old.views.size) c.ops.delete(f.last);
      }
    }
    f.last = revision;
    f.unknown ||= unknown || stack.some((x) => x.unknown);
    for (const owner of [...inherited, ...known]) if (!f.owners.includes(owner)) f.owners.push(owner);
    op.frames.add(f);
    op.views.add(f.view);
    f.ops.add(op);
  }
}
function supersede(channel, revision) {
  const c = connections.get(channel), op = c?.ops.get(revision);
  if (!op) return;
  if (!op.started) setOperationState(op, { state: "superseded" });
  c.ops.delete(revision);
}
var unregisterOwnerSource = abandonOwnerSource;

// packages/kernel/src/lib/experimental-publication/private.ts
var stamp = Symbol("research revision");
var facts = /* @__PURE__ */ new WeakSet();
var latest = /* @__PURE__ */ new Map();
var serial = 0;
var ingress;
var receipts = [];
function log(value) {
  receipts.push(value);
  if (receipts.length > 64) receipts.shift();
}
function register(owner, _source, token) {
  registerOwnerSource(owner, token);
}
function unregister(owner) {
  if (owner !== void 0) unregisterOwnerSource(owner);
}
function transition(owner, event) {
  if (owner !== void 0) {
    ownerTransition(owner, event);
    log({ event: "lifecycle", owner, ...event });
  }
}
function annotate(meta, owner, positions, authored, _payload) {
  if (meta?.participation === "inspection") return { ...meta };
  const clean = !!ingress && !ingress.consumed && owner === ingress.owner && positions?.[0] === ingress.position;
  if (clean && ingress) ingress.consumed = true;
  const blockers = pendingOwners();
  const attributed = meta?.transactionId;
  const known = owner !== void 0 && typeof attributed === "number" ? ownerCell(owner, attributed) : void 0;
  const valid = attributed === void 0 || !!known && meta?.transactionOwner === ownerToken(owner);
  const unknown = !clean && (!authored || meta?.origin !== void 0 || owner === void 0 || !ownerToken(owner) || !valid);
  const fact = Object.freeze({ revision: ++serial, clean, blockers: Object.freeze([...blockers]), unknown });
  facts.add(fact);
  for (const channel of matchingChannels(owner, positions, meta)) {
    const prior = latest.get(channel);
    latest.set(channel, fact);
    admitted(channel, fact);
    attachRevision(channel, fact, known ? [known] : [], unknown);
    if (prior) supersede(channel, prior);
  }
  log({ event: "revision", owner, revision: fact.revision, clean, unknown });
  return { ...meta, [stamp]: fact };
}
function evidence2(meta) {
  const value = meta?.[stamp];
  return value && typeof value === "object" && facts.has(value) ? value : void 0;
}
function complete(meta) {
  completeSource(evidence2(meta));
}

// packages/kernel/src/lib/internals/plain-branch-membership.ts
var MEMBERSHIP = Symbol("SignalTree:PlainBranchMembership");
function plainBranchMembershipChange(meta) {
  return meta?.[MEMBERSHIP];
}
function isCollectionMember(node) {
  if (!isTraversableNode(node)) return false;
  const binding = node.__prepareTransitionTarget;
  return binding !== void 0 && binding.owner === getOwnedPositionIds(node)?.[0];
}
function isRecordedMember(node) {
  return isNodeAccessor(node) || isWritableLocation(node) || isCollectionMember(node);
}
function capturePlainBranchMembership(branch, supplied, partial) {
  if (!hasPathObservers()) return void 0;
  const registry = getPositionRegistry(branch);
  const path = getOwnedOwnerPath(branch);
  if (!registry || path === void 0) return void 0;
  const storage = nodeStoreOf(branch) ?? branch;
  const keys = new Set(
    partial ? [...Object.keys(branch), ...Object.keys(supplied)] : Object.keys(supplied)
  );
  const before = /* @__PURE__ */ new Map();
  for (const key of Object.keys(supplied)) {
    if (key !== "__proto__" && !Object.prototype.hasOwnProperty.call(storage, key)) {
      before.set(key, { present: false });
    }
  }
  storedReads.depth++;
  try {
    for (const key of Object.getOwnPropertyNames(storage)) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("membershipKeysVisited");
      }
      const descriptor = Object.getOwnPropertyDescriptor(storage, key);
      if (!descriptor || !("value" in descriptor)) continue;
      const present = descriptor.enumerable === true;
      if (present === keys.has(key)) continue;
      if (!present && typeof descriptor.value !== "function" && !isCollectionMember(descriptor.value))
        continue;
      before.set(
        key,
        present ? {
          present: true,
          value: unwrapBranchForWriteCapture(descriptor.value)
        } : { present: false }
      );
    }
  } finally {
    storedReads.depth--;
  }
  if (before.size === 0) return void 0;
  const meta = getActiveWriteContext();
  return () => {
    const members = [];
    for (const [key, previous] of before) {
      const descriptor = Object.getOwnPropertyDescriptor(branch, key);
      const present = descriptor?.enumerable === true;
      if (present === previous.present) continue;
      if (previous.present) rememberHiddenRows(descriptor?.value);
      members.push({
        key,
        positionIds: getOwnedPositionIds(descriptor?.value),
        before: previous,
        after: present ? {
          present: true,
          value: unwrapBranchForWriteCapture(descriptor?.value)
        } : { present: false }
      });
    }
    if (members.length === 0) return;
    const notification = {
      ...meta,
      [MEMBERSHIP]: { kind: "plain-branch-membership", branch, members }
    };
    pathObservation().notify(
      path,
      void 0,
      void 0,
      path,
      void 0,
      getOwnedPositionIds(branch),
      notification,
      registry.id
    );
  };
}
function capturePathReAdd(path, outer) {
  if (!hasPathObservers()) return void 0;
  const publishers = [];
  for (let i = 0; i <= outer; i++) {
    const { parent, key } = path[i];
    publishers.push(
      capturePlainBranchMembership(parent, { [key]: true }, i === outer)
    );
  }
  return () => {
    for (const publish of publishers) publish?.();
  };
}
var MEMBER_ADDRESSES = /* @__PURE__ */ new WeakMap();
function prepareNewMemberResponsibility(branch, key, node) {
  const registry = getPositionRegistry(branch);
  const position = getOwnedPositionIds(node)?.[0];
  const path = getOwnedOwnerPath(node);
  if (!registry || position === void 0 || path === void 0) return void 0;
  let addresses = MEMBER_ADDRESSES.get(registry);
  if (!addresses) {
    addresses = /* @__PURE__ */ new Map();
    MEMBER_ADDRESSES.set(registry, addresses);
  }
  const effect = {
    kind: "set",
    position,
    path,
    ownerPath: path,
    before: void 0,
    after: unwrapBranchForWriteCapture(node),
    plainBranchMembership: { before: false, after: true },
    mutationIntent: "replace"
  };
  return { effect, address: { map: addresses, key: position, value: { branch, key, node } } };
}
function plainBranchMembershipEffects(meta) {
  const change = plainBranchMembershipChange(meta);
  if (!change) return void 0;
  const registry = getPositionRegistry(change.branch);
  if (!registry) return [];
  let addresses = MEMBER_ADDRESSES.get(registry);
  if (!addresses) {
    addresses = /* @__PURE__ */ new Map();
    MEMBER_ADDRESSES.set(registry, addresses);
  }
  return change.members.flatMap((member) => {
    const position = member.positionIds?.[0];
    if (position === void 0) return [];
    const node = Object.getOwnPropertyDescriptor(
      change.branch,
      member.key
    )?.value;
    const path = getOwnedOwnerPath(node);
    if (path === void 0 || !isRecordedMember(node)) return [];
    addresses.set(position, { branch: change.branch, key: member.key, node });
    return [
      {
        kind: "set",
        position,
        path,
        ownerPath: path,
        before: member.before.present ? member.before.value : void 0,
        after: member.after.present ? member.after.value : void 0,
        plainBranchMembership: {
          before: member.before.present,
          after: member.after.present
        },
        mutationIntent: "replace"
      }
    ];
  });
}
function composePlainBranchMemberEffect(existing, incoming) {
  if (!existing.plainBranchMembership && !incoming.plainBranchMembership)
    return false;
  const before = existing.plainBranchMembership?.before ?? incoming.plainBranchMembership?.before ?? true;
  if (!existing.plainBranchMembership && incoming.plainBranchMembership?.before === false) {
    existing.before = incoming.before;
  }
  existing.after = incoming.after;
  existing.plainBranchMembership = {
    before,
    after: incoming.plainBranchMembership?.after ?? true
  };
  return true;
}
function plainBranchMemberEffectIsNoop(effect) {
  const before = effect.plainBranchMembership?.before ?? true;
  const after = effect.plainBranchMembership?.after ?? true;
  return before === after && (!before || effect.before === effect.after);
}
function settleTurnMemberEffects(root, turnEffects) {
  const effects = turnEffects;
  const registry = getPositionRegistry(root);
  const addresses = /* @__PURE__ */ new Map();
  const addressOf = (position) => {
    if (!addresses.has(position))
      addresses.set(position, registry?.addressFor(position));
    return addresses.get(position);
  };
  const relative = (outer, position) => {
    const address = addressOf(position);
    if (!address || address.length <= outer.length) return void 0;
    for (let i = 0; i < outer.length; i++)
      if (address[i] !== outer[i]) return void 0;
    return address.slice(outer.length);
  };
  const members = effects.some(
    (effect) => effect.kind === "set" && effect.plainBranchMembership
  );
  if (members && registry)
    effects.forEach((member, index) => {
      if (member.kind !== "set" || !member.plainBranchMembership) return;
      const at = addressOf(member.position);
      if (!at) return;
      if (member.plainBranchMembership.before && isPlainImage(member.before)) {
        let image;
        for (let j = 0; j < index; j++) {
          const earlier = effects[j];
          if (earlier.kind !== "set" || earlier.subject !== void 0) continue;
          const below = relative(at, earlier.position);
          if (!below) continue;
          image ??= cloneImage(member.before);
          placeInImage(
            image,
            below,
            earlier.plainBranchMembership?.before ?? true,
            earlier.before
          );
        }
        if (image) member.before = image;
      }
    });
  if (members)
    for (const member of effects) {
      if (member.kind !== "set" || !member.plainBranchMembership?.after)
        continue;
      const address = memberAddress(root, member.position);
      if (!address || !Object.getOwnPropertyDescriptor(address.branch, address.key)?.enumerable)
        continue;
      storedReads.depth++;
      try {
        member.after = unwrapBranchForWriteCapture(address.node);
      } finally {
        storedReads.depth--;
      }
    }
  const noop2 = (effect) => effect.kind === "set" && plainBranchMemberEffectIsNoop(effect) && (effect.fieldPresence?.before ?? true) === (effect.fieldPresence?.after ?? true);
  const kept = effects.filter(
    (effect) => !noop2(effect) || effect.plainBranchMembership?.before === false && registry !== void 0
  );
  return kept.filter((effect) => {
    if (!noop2(effect)) return true;
    const at = addressOf(effect.position);
    return !!at && kept.some(
      (other) => other !== effect && relative(at, other.position) !== void 0
    );
  });
}
function isPlainImage(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}
function cloneImage(value) {
  if (!isPlainImage(value)) return value;
  const copy = {};
  for (const key of Object.keys(value)) copy[key] = cloneImage(value[key]);
  return copy;
}
function placeInImage(image, path, present, value) {
  let level = image;
  for (let i = 0; i < path.length - 1; i++) {
    const next = level[path[i]];
    if (!isPlainImage(next)) return;
    level = next;
  }
  const key = path[path.length - 1];
  if (present) level[key] = cloneImage(value);
  else delete level[key];
}
function memberAddress(root, position) {
  const registry = getPositionRegistry(root);
  if (!registry) return void 0;
  const address = MEMBER_ADDRESSES.get(registry)?.get(position);
  if (!address || getPositionRegistry(address.branch) !== registry)
    return void 0;
  const descriptor = Object.getOwnPropertyDescriptor(
    address.branch,
    address.key
  );
  return descriptor?.value === address.node && descriptor.configurable === true && getOwnedPositionIds(address.node)?.[0] === position && isRecordedMember(address.node) ? address : void 0;
}
var OMITTED_ROWS = /* @__PURE__ */ new WeakMap();
function collectionRows(node) {
  const binding = node.__prepareTransitionTarget;
  return binding?.readSource().subjects.map(
    ({ subject, key, value }) => [subject, key, value]
  ) ?? [];
}
function rememberOmittedRows(node) {
  OMITTED_ROWS.set(node, collectionRows(node));
}
function collectionsWithin(member, visit) {
  if (isCollectionMember(member)) {
    visit(member);
    return;
  }
  if (!isNodeAccessor(member)) return;
  for (const key of Object.keys(member)) {
    const child = member[key];
    if (isCollectionMember(child) || isNodeAccessor(child))
      collectionsWithin(child, visit);
  }
}
function rememberHiddenRows(member) {
  collectionsWithin(member, rememberOmittedRows);
}
function omittedRowsChanged(node, touched, reordered) {
  const expected = OMITTED_ROWS.get(node);
  if (!expected) return false;
  const untouched = (rows) => {
    const kept = rows.filter(([subject]) => !touched.has(subject));
    return reordered ? [...kept].sort(([a], [b]) => String(a) < String(b) ? -1 : 1) : kept;
  };
  return !deepEqual(untouched(collectionRows(node)), untouched(expected));
}
function changedOmittedCollection(root, position, touched, reordered) {
  const address = memberAddress(root, position);
  if (!address || Object.getOwnPropertyDescriptor(address.branch, address.key)?.enumerable)
    return void 0;
  let changed;
  collectionsWithin(address.node, (node) => {
    const owner = getOwnedPositionIds(node)?.[0];
    if (changed === void 0 && omittedRowsChanged(node, touched(owner), reordered(owner)))
      changed = getOwnedOwnerPath(node) ?? String(owner);
  });
  return changed;
}
function refreshOmittedCollection(root, position) {
  if (!hidingMembers(root, position)?.length) return;
  const address = getPositionRegistry(root)?.addressFor(position);
  let node = root;
  for (const key of address ?? []) {
    if (!isTraversableNode(node)) return;
    node = Object.getOwnPropertyDescriptor(node, key)?.value;
  }
  if (isCollectionMember(node)) rememberOmittedRows(node);
}
function canRealizePlainBranchMember(root, position) {
  return memberAddress(root, position) !== void 0;
}
function hidingMembers(root, position) {
  const address = getPositionRegistry(root)?.addressFor(position);
  if (!address) return void 0;
  const hiding = [];
  let node = root;
  for (let i = 0; i < address.length; i++) {
    const descriptor = isTraversableNode(node) ? Object.getOwnPropertyDescriptor(node, address[i]) : void 0;
    if (!descriptor || !("value" in descriptor)) return void 0;
    node = descriptor.value;
    if (!descriptor.enumerable)
      hiding.push({
        position: getOwnedPositionIds(node)?.[0],
        path: getOwnedOwnerPath(node),
        node,
        below: address.slice(i + 1)
      });
  }
  return getOwnedPositionIds(node)?.includes(position) ? hiding : void 0;
}
function collectionBindingAt(root, position) {
  const address = getPositionRegistry(root)?.addressFor(position);
  if (!address) return void 0;
  let node = root;
  for (const key of address) {
    if (!isTraversableNode(node)) return void 0;
    node = Object.getOwnPropertyDescriptor(node, key)?.value;
  }
  const binding = node?.__prepareTransitionTarget;
  return binding?.owner === position ? binding : void 0;
}
function preparePlainBranchMembers(root, targets, scalarTargets) {
  const registry = getPositionRegistry(root);
  const runtime2 = getTreeScalarSlotRuntime(root);
  if (!registry || !runtime2)
    throw new Error("Plain branch target has no scalar runtime");
  const members = /* @__PURE__ */ new Map();
  const values = /* @__PURE__ */ new Map();
  const resolveSlot = (node) => {
    const position = getOwnedPositionIds(node)?.[0];
    const slot = position === void 0 ? void 0 : runtime2.resolveScalarSlot(position);
    if (position === void 0 || slot === void 0 || runtime2.resolveScalarLeaf(position) !== node)
      throw new Error("Plain branch target has no retained scalar slot");
    return { position, slot };
  };
  const stage = (address, present, value, turn) => {
    const { branch, key, node } = address;
    const descriptor = Object.getOwnPropertyDescriptor(branch, key);
    if (getPositionRegistry(branch) !== registry || descriptor?.value !== node || !descriptor.configurable)
      throw new Error("Plain branch target location is unavailable");
    const previous = members.get(node);
    members.set(node, {
      address,
      present,
      before: previous?.before ?? (descriptor.enumerable ? { present: true, value: unwrapBranchForWriteCapture(node) } : { present: false })
    });
    if (!present) return;
    if (isCollectionMember(node)) return;
    if (isWritableLocation(node)) {
      const { position, slot } = resolveSlot(node);
      values.set(slot, {
        node,
        position,
        before: values.get(slot)?.before ?? unwrapBranchForWriteCapture(node),
        after: value,
        turn
      });
      return;
    }
    if (!isNodeAccessor(node) || value === null || typeof value !== "object" || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
      throw new Error("Plain branch target requires a plain object");
    const supplied = new Set(Object.keys(value));
    for (const childKey of Object.getOwnPropertyNames(node)) {
      const child = Object.getOwnPropertyDescriptor(node, childKey)?.value;
      if (!isNodeAccessor(child) && !isWritableLocation(child)) {
        if (isTraversableNode(child)) supplied.delete(childKey);
        continue;
      }
      const childPresent = supplied.delete(childKey);
      const next = childPresent ? Object.getOwnPropertyDescriptor(value, childKey) : void 0;
      if (next && !("value" in next))
        throw new Error("Plain branch target cannot read an accessor");
      stage(
        { branch: node, key: childKey, node: child },
        childPresent,
        next?.value,
        turn
      );
    }
    if (supplied.size)
      throw new Error("Plain branch target contains an unavailable member");
  };
  for (const [position, target] of targets) {
    const address = memberAddress(root, position);
    if (!address)
      throw new Error("Plain branch member location is unavailable");
    stage(address, target.present, target.value, target.turn);
  }
  const staged = /* @__PURE__ */ new Map();
  for (const { position, turn } of values.values())
    if (turn !== void 0) staged.set(position, turn);
  for (const target of scalarTargets ?? []) {
    if (target.turn !== void 0 && (staged.get(target.owner) ?? target.turn) > target.turn)
      continue;
    const node = runtime2.resolveScalarLeaf(target.owner);
    if (!node) throw new Error("Plain branch scalar target is unavailable");
    const { slot, position } = resolveSlot(node);
    const previous = values.get(slot);
    values.set(slot, {
      node,
      position,
      before: previous ? previous.before : unwrapBranchForWriteCapture(node),
      after: target.after,
      turn: target.turn
    });
  }
  const frame = runtime2.beginFrame();
  for (const [slot, value] of values) frame.set(slot, value.after);
  const installFrame = scalarTargets === void 0 ? () => frame.commit({ advanceRevision: false, publish: false }) : frame.prepareCommit?.({ advanceRevision: false, publish: false });
  if (!installFrame)
    throw new Error("Plain branch scalar frame cannot be prepared");
  let result;
  let invalidated = false;
  let published = false;
  const changedSlots = /* @__PURE__ */ new Set();
  const changedBranches = /* @__PURE__ */ new Set();
  const changedBranchMembers = [];
  let changes = [];
  const captureChanges = () => {
    const byBranch = /* @__PURE__ */ new Map();
    for (const { address, present, before } of members.values()) {
      if (before.present === present) continue;
      let entries = byBranch.get(address.branch);
      if (!entries) byBranch.set(address.branch, entries = []);
      entries.push({
        key: address.key,
        positionIds: getOwnedPositionIds(address.node),
        before,
        after: present ? {
          present: true,
          value: unwrapBranchForWriteCapture(address.node)
        } : { present: false }
      });
    }
    changes = [...byBranch].map(([branch, members2]) => ({
      kind: "plain-branch-membership",
      branch,
      members: members2
    }));
  };
  const invalidate = () => {
    const installed = result;
    if (!installed)
      throw new Error("Plain branch target invalidated before installation");
    if (invalidated) return;
    invalidated = true;
    let failed = false;
    let firstError;
    const run = (fn) => {
      if (scalarTargets === void 0) {
        fn();
        return;
      }
      try {
        fn();
      } catch (error) {
        if (!failed) {
          failed = true;
          firstError = error;
        }
      }
    };
    withWriteContext(
      {
        ...getActiveWriteContext(),
        intent: "system",
        participation: "realized"
      },
      () => runtime2.runInvalidationGroup(() => {
        for (const branch of changedBranches)
          run(() => publishMembershipChange(branch));
        for (const { branch, key, node } of changedBranchMembers) {
          run(() => republishMembers(branch, [key]));
          run(() => {
            if (!Object.getOwnPropertyDescriptor(branch, key)?.enumerable)
              rememberHiddenRows(node);
          });
        }
        run(
          () => runtime2.publishPrepared({
            revision: installed.revision,
            changedSlots: [...changedSlots]
          })
        );
        if (failed) throw firstError;
      })
    );
  };
  return {
    staged,
    invalidate,
    install() {
      if (result) return;
      for (const { address } of members.values()) {
        const descriptor = Object.getOwnPropertyDescriptor(
          address.branch,
          address.key
        );
        if (descriptor?.value !== address.node || !descriptor.configurable) {
          frame.discard();
          throw new Error(
            "Plain branch target location changed before installation"
          );
        }
      }
      result = installFrame();
      for (const slot of result.changedSlots) changedSlots.add(slot);
      for (const { address, present } of members.values()) {
        if (setMemberPresence(
          address.branch,
          address.key,
          present ? "active" : "dormant"
        )) {
          changedBranches.add(address.branch);
          if (isWritableLocation(address.node))
            changedSlots.add(resolveSlot(address.node).slot);
          else changedBranchMembers.push(address);
        }
      }
      if (scalarTargets === void 0) captureChanges();
    },
    publish() {
      const installed = result;
      if (!installed)
        throw new Error("Plain branch target published before installation");
      if (published) return;
      published = true;
      const meta = {
        ...getActiveWriteContext(),
        intent: "system",
        participation: "realized"
      };
      withWriteContext(meta, () => {
        invalidate();
        if (scalarTargets !== void 0) captureChanges();
        for (const [slot, value] of values) {
          if (!installed.changedSlots.includes(slot)) continue;
          const path = getOwnedOwnerPath(value.node);
          if (path === void 0) continue;
          pathObservation().notify(
            path,
            value.after,
            value.before,
            path,
            void 0,
            [value.position],
            meta,
            registry.id
          );
        }
        for (const change of changes) {
          const path = getOwnedOwnerPath(change.branch);
          if (path === void 0) continue;
          const notification = {
            ...meta,
            [MEMBERSHIP]: change
          };
          pathObservation().notify(
            path,
            void 0,
            void 0,
            path,
            void 0,
            getOwnedPositionIds(change.branch),
            notification,
            registry.id
          );
        }
      });
    }
  };
}

// packages/kernel/src/lib/internals/write-observation-scope.ts
var maxTokens = 8;
var active = /* @__PURE__ */ new Map();
var freeze = (tokens, includesUnscoped, omitted) => Object.freeze({
  tokens: Object.freeze(tokens),
  includesUnscoped,
  omitted
});
function currentWriteObservationScopes(ownerId) {
  return ownerId === void 0 ? void 0 : active.get(ownerId);
}
function mergeWriteObservationScopes(left, right) {
  if (!left && !right) return void 0;
  const tokens = [...left?.tokens ?? []];
  let omitted = left?.omitted === true || right?.omitted === true;
  for (const token of right?.tokens ?? []) {
    if (tokens.includes(token)) continue;
    if (tokens.length < maxTokens) tokens.push(token);
    else omitted = true;
  }
  return freeze(tokens, !left || !right || left.includesUnscoped || right.includesUnscoped, omitted);
}
function withoutWriteObservationScopes(deliver) {
  if (active.size === 0) return deliver();
  const previous = active;
  active = /* @__PURE__ */ new Map();
  try {
    return deliver();
  } finally {
    active = previous;
  }
}

// packages/kernel/src/lib/write-participation.ts
var getWriteParticipation = (meta) => meta?.participation ?? "authored";
var isInspectionWrite = (meta) => meta?.participation === "inspection";

// packages/kernel/src/lib/path-notifier.ts
var isPlainRowRecord = (value) => {
  if (value === null || typeof value !== "object") return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === null || prototype === Object.prototype;
};
var changedSubjectFieldKeys = (before, after, subjectIds) => {
  if (subjectIds?.length !== 1 || !isPlainRowRecord(before) || !isPlainRowRecord(after)) {
    return void 0;
  }
  return [.../* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)])].filter(
    (key) => Object.prototype.hasOwnProperty.call(before, key) !== Object.prototype.hasOwnProperty.call(after, key) || !Object.is(before[key], after[key])
  );
};
var materializeDeliveryMeta = (meta) => {
  if (!meta?.structuralEffect) {
    return meta;
  }
  return {
    ...meta,
    structuralEffect: Object.freeze({ ...meta.structuralEffect })
  };
};
var PathNotifier = class _PathNotifier {
  static ownerBoundarySeparator = "\0";
  // Map of pattern -> Set of handlers
  subscribers = /* @__PURE__ */ new Map();
  // Batching state
  resetCallbacks = /* @__PURE__ */ new Set();
  batchingEnabled = true;
  batchIdentityMode = "path-position-subject";
  pendingFlush = false;
  pending = /* @__PURE__ */ new Map();
  pendingBeforeMembership = [];
  flushCallbacks = /* @__PURE__ */ new Set();
  /**
   * @internal Installed while a reversal or rollback applies
   * (`publishingExposedOnly`): true for a realized write to a location the
   * operation leaves absent, which is then not published. Path observers see
   * what the tree exposes, never retained storage (v15 c6258aab, v16 8g).
   */
  absentRealized;
  enqueueObservers = /* @__PURE__ */ new Map();
  /** @internal Owner-scoped evidence before batching can discard chronology. */
  observeEnqueue(ownerId, listener) {
    let listeners2 = this.enqueueObservers.get(ownerId);
    if (!listeners2) this.enqueueObservers.set(ownerId, listeners2 = /* @__PURE__ */ new Set());
    listeners2.add(listener);
    return () => {
      listeners2.delete(listener);
      if (listeners2.size === 0 && this.enqueueObservers.get(ownerId) === listeners2)
        this.enqueueObservers.delete(ownerId);
    };
  }
  constructor(options) {
    if (options && options.batching === false) this.batchingEnabled = false;
  }
  /**
   * Enable or disable batching at runtime (global opt-out)
   */
  setBatchingEnabled(enabled) {
    this.batchingEnabled = enabled;
  }
  isBatchingEnabled() {
    return this.batchingEnabled;
  }
  hasObservers() {
    return this.subscribers.size > 0 || this.flushCallbacks.size > 0;
  }
  /**
   * ⚠️ RETURNS VOID SINCE 15.0. It used to return `{ blocked, value }`, the
   * result protocol of the deleted delivery interceptors. The only producer —
   * `owned-mutation` — already discarded it, and no surviving caller consumed
   * it. Keeping the shape would have preserved archaeological evidence of a
   * retired mechanism as though it were a contract.
   */
  // ⚠️ `emitMutation(envelope)` WAS DELETED IN 15.0 — ME-B,
  // MUTATION-ENVELOPE-OWNERSHIP-0.
  //
  // It was a pure adapter: unpack a `MutationEnvelope` produced by exactly one
  // caller and immediately call `this.notify(...)` field-for-field. No decision
  // was made at that boundary — it joined path segments the same caller had
  // just split, and rewrapped a position id the same caller had just unwrapped.
  //
  //     ONE SEMANTIC PUBLICATION JOB, ONE PORT OPERATION.
  //
  // `owned-mutation` now calls `notify` through the port directly. Do not
  // reintroduce a parameter object BESIDE this protocol; that recreates the
  // dual-protocol problem this deletion removed. Replacing the positional
  // signature IN PLACE, derived from all producers and consumers, is admissible
  // representation cleanup — adding a second entry point is not.
  /** @internal Bench/test-only hook to isolate batching-key overhead. */
  setBatchIdentityModeForTesting(mode = "path-position-subject") {
    this.batchIdentityMode = mode;
  }
  /**
   * Subscribe to mutations matching a path pattern
   * Returns unsubscribe function
   */
  subscribe(pattern, handler) {
    if (!this.subscribers.has(pattern)) {
      this.subscribers.set(pattern, /* @__PURE__ */ new Set());
    }
    const handlers = this.subscribers.get(pattern);
    if (!handlers) {
      return () => {
      };
    }
    handlers.add(handler);
    return () => {
      handlers.delete(handler);
      if (handlers.size === 0) {
        this.subscribers.delete(pattern);
      }
    };
  }
  /**
   * Notify all subscribers matching the path
   * When batching is enabled, notifications are queued and flushed at
   * the end of the current microtask (via queueMicrotask).
   */
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    const ambientMeta = metaOverride ?? getActiveWriteContext();
    if (this.absentRealized?.(positionIds, ambientMeta)) return;
    const metaBeforeOwner = isRestorationDesignated() ? markMetaDesignated(ambientMeta) : ambientMeta;
    let meta = ownerId === void 0 ? metaBeforeOwner : { ...metaBeforeOwner ?? {}, ownerId };
    const declaredScopes = currentWriteObservationScopes(ownerId);
    const origin = meta?.origin;
    const evidenceOwner = ownerId ?? meta?.ownerId;
    const evidenceListeners = evidenceOwner === void 0 ? void 0 : this.enqueueObservers.get(evidenceOwner);
    if (evidenceListeners?.size) {
      const snapshot = Object.freeze({
        path,
        newValue: value,
        oldValue: prev,
        ownerPath,
        origin,
        ownerId: evidenceOwner,
        meta: meta ? Object.freeze({ ...materializeDeliveryMeta(meta) }) : void 0,
        positionIds: positionIds ? [...positionIds] : void 0,
        subjectIds: subjectIds ? [...subjectIds] : void 0
      });
      if (snapshot.positionIds) Object.freeze(snapshot.positionIds);
      if (snapshot.subjectIds) Object.freeze(snapshot.subjectIds);
      for (const listener of [...evidenceListeners]) {
        try {
          withoutWriteObservationScopes(() => listener(snapshot));
        } catch (error) {
          try {
            console.error("SignalTree: enqueue observation failed.", error);
          } catch {
          }
        }
      }
    }
    const transition2 = entityValueTransition(meta);
    const fieldKeys = changedSubjectFieldKeys(
      transition2 ? transition2.ordinaryBefore : prev,
      transition2 ? transition2.ordinaryAfter : value,
      subjectIds
    );
    const footprintKeys = subjectFieldFootprint ?? fieldKeys;
    const knownFootprint = subjectFieldFootprint === null ? null : footprintKeys === void 0 ? void 0 : Object.freeze([...footprintKeys]);
    meta = annotate(
      stampSource(meta, subjectIds, knownFootprint, value, prev),
      ownerId ?? meta?.ownerId,
      positionIds,
      getWriteParticipation(meta) === "authored",
      value
    );
    if (!this.batchingEnabled) {
      const deliveryMeta = materializeDeliveryMeta(meta);
      return this._runNotify(
        path,
        value,
        prev,
        ownerPath,
        origin,
        subjectIds,
        positionIds,
        deliveryMeta,
        declaredScopes,
        ownerId,
        knownFootprint
      );
    }
    const entry = {
      path,
      newValue: value,
      oldValue: prev,
      ownerPath,
      origin,
      meta,
      declaredScopes,
      subjectId: subjectIds?.[0],
      positionId: positionIds?.[0],
      ownerId,
      subjectIds,
      positionIds,
      subjectFieldKeys: fieldKeys,
      subjectFieldFootprint: knownFootprint
    };
    this.enqueuePending(entry);
    if (!this.pendingFlush) {
      this.pendingFlush = true;
      queueMicrotask(() => this.flush());
    }
    return;
  }
  /**
   * Internal synchronous notification runner (subscribers)
   */
  _runNotify(path, value, prev, ownerPath, origin, subjectIds, positionIds, meta, declaredScopes, ownerId, subjectFieldFootprint, isolateSubscribers = false) {
    const transformed = value;
    for (const [pattern, handlers] of this.subscribers) {
      if (this.matches(pattern, path)) {
        for (const handler of handlers) {
          try {
            withoutWriteObservationScopes(
              () => handler(
                transformed,
                prev,
                path,
                ownerPath,
                origin,
                subjectIds,
                positionIds,
                meta,
                declaredScopes,
                ownerId,
                subjectFieldFootprint
              )
            );
          } catch (error) {
            if (!isolateSubscribers) throw error;
            reportContainedObserverError({
              error,
              operation: "notify:subscriber",
              // Entity and compensation writes name their tree in meta only.
              treeId: ownerId ?? meta?.ownerId,
              path
            });
          }
        }
      }
    }
    return;
  }
  /**
   * Flush pending batched notifications immediately.
   * This is re-entrant safe and will process notifications queued during
   * subscriber callbacks in subsequent rounds.
   */
  flush() {
    const toNotify = [
      ...this.pendingBeforeMembership,
      ...this.pending.values()
    ];
    this.pendingBeforeMembership = [];
    this.pending.clear();
    this.pendingFlush = false;
    for (const slot of toNotify)
      for (const entry of Array.isArray(slot) ? slot : [slot])
        complete(entry.meta);
    for (const slot of toNotify) {
      const entries = Array.isArray(slot) ? slot : [slot];
      for (const entry of entries) {
        const isOwnerOnlyMarkerSignal = entry.ownerPath !== void 0 && entry.newValue === void 0 && entry.oldValue === void 0;
        const hasStructuralEffect = entry.meta?.structuralEffect !== void 0;
        if (entry.newValue === entry.oldValue && !entry.subjectFieldKeys?.length && !isOwnerOnlyMarkerSignal && !hasStructuralEffect) {
          deliverEqual(entry);
          continue;
        }
        this._runNotify(
          entry.path,
          entry.newValue,
          entry.oldValue,
          entry.ownerPath,
          entry.origin,
          entry.subjectIds,
          entry.positionIds,
          materializeDeliveryMeta(entry.meta),
          entry.declaredScopes,
          entry.ownerId,
          entry.subjectFieldFootprint,
          true
        );
      }
    }
    for (const cb of Array.from(this.flushCallbacks)) {
      try {
        withoutWriteObservationScopes(cb);
      } catch {
      }
    }
  }
  /**
   * Force synchronous flush of pending notifications
   */
  flushSync() {
    while (this.hasPending() || this.pendingFlush) {
      if (this.pendingFlush && !this.hasPending()) {
        this.pendingFlush = false;
        break;
      }
      this.flush();
    }
  }
  /**
   * Subscribe to flush events (called after a flush completes)
   */
  onFlush(callback) {
    this.flushCallbacks.add(callback);
    return () => this.flushCallbacks.delete(callback);
  }
  /** Internal evidence only: never drains the queue or invokes observers.
   * Include net-equal entries: an ABA write still changed ownership.
   */
  readPending() {
    return [...this.pendingBeforeMembership, ...this.pending.values()].flatMap(
      (slot) => (Array.isArray(slot) ? slot : [slot]).map((entry) => ({
        ...entry,
        subjectFieldKeys: entry.subjectFieldKeys ? [...entry.subjectFieldKeys] : void 0
      }))
    );
  }
  /**
   * Check if there are pending notifications
   */
  hasPending() {
    return this.pending.size > 0 || this.pendingBeforeMembership.length > 0;
  }
  /**
   * Simple pattern matching
   * - 'users' matches exactly 'users'
   * - 'users.*' matches 'users.u1', 'users.u2', etc.
   * - '**' matches everything
   */
  matches(pattern, path) {
    if (pattern === "**") return true;
    if (pattern === path) return true;
    if (pattern.endsWith(".*")) {
      const prefix = pattern.slice(0, -2);
      return path.startsWith(prefix + ".");
    }
    return false;
  }
  enqueuePending(entry) {
    if (plainBranchMembershipChange(entry.meta)) {
      for (const slot of this.pending.values())
        this.pendingBeforeMembership.push(slot);
      this.pendingBeforeMembership.push(entry);
      this.pending.clear();
      return;
    }
    const path = entry.path;
    const existing = this.pending.get(path);
    if (!existing) {
      this.pending.set(path, entry);
      return;
    }
    if (this.batchIdentityMode === "path") {
      if (Array.isArray(existing)) {
        const tail = existing[existing.length - 1];
        if (this.hasSameSemanticIdentity(tail, entry)) {
          this.coalesceEntry(tail, entry);
          return;
        }
        existing.push(entry);
        return;
      }
      if (this.hasSameSemanticIdentity(existing, entry)) {
        this.coalesceEntry(existing, entry);
        return;
      }
      this.pending.set(path, [existing, entry]);
      return;
    }
    if (this.batchIdentityMode === "path-position-subject-composite") {
      this.enqueuePendingComposite(entry);
      return;
    }
    if (Array.isArray(existing)) {
      const tail = existing[existing.length - 1];
      if (this.hasSameSemanticIdentity(tail, entry)) {
        this.coalesceEntry(tail, entry);
        return;
      }
      existing.push(entry);
      return;
    }
    if (this.hasSameSemanticIdentity(existing, entry)) {
      this.coalesceEntry(existing, entry);
      return;
    }
    this.pending.set(path, [existing, entry]);
  }
  enqueuePendingComposite(entry) {
    const compositeKey = this.getCompositeBatchKey(entry);
    const existing = this.pending.get(compositeKey);
    if (!existing) {
      this.pending.set(compositeKey, entry);
      return;
    }
    const target = Array.isArray(existing) ? existing[0] : existing;
    this.coalesceEntry(target, entry);
  }
  hasSameSemanticIdentity(left, right) {
    if (this.crossesStructuralBoundary(left, right)) {
      return false;
    }
    if (this.crossesScalarIntentBoundary(left, right)) {
      return false;
    }
    if (this.crossesCausalModeBoundary(left, right)) {
      return false;
    }
    if ((left.ownerId ?? left.meta?.ownerId) !== (right.ownerId ?? right.meta?.ownerId)) {
      return false;
    }
    if (this.batchIdentityMode === "path-position") {
      return left.positionId === right.positionId;
    }
    return left.positionId === right.positionId && left.subjectId === right.subjectId;
  }
  crossesStructuralBoundary(left, right) {
    const leftEffect = left.meta?.structuralEffect;
    const rightEffect = right.meta?.structuralEffect;
    const leftStructural = leftEffect !== void 0;
    const rightStructural = rightEffect !== void 0;
    if (leftStructural !== rightStructural) {
      return true;
    }
    if (leftStructural && rightStructural && leftEffect.kind !== rightEffect.kind) {
      return true;
    }
    return false;
  }
  crossesScalarIntentBoundary(left, right) {
    const leftIntent = left.meta?.mutationIntent;
    const rightIntent = right.meta?.mutationIntent;
    return leftIntent !== void 0 && rightIntent !== void 0 && leftIntent !== rightIntent;
  }
  crossesCausalModeBoundary(left, right) {
    return getWriteParticipation(left.meta) !== getWriteParticipation(right.meta) || left.origin !== right.origin || left.meta?.transactionId !== right.meta?.transactionId || left.meta?.transactionOwner !== right.meta?.transactionOwner;
  }
  coalesceEntry(target, next) {
    target.subjectFieldFootprint = target.subjectFieldFootprint === void 0 || next.subjectFieldFootprint === void 0 ? void 0 : target.subjectFieldFootprint === null || next.subjectFieldFootprint === null ? null : Object.freeze([
      .../* @__PURE__ */ new Set([
        ...target.subjectFieldFootprint,
        ...next.subjectFieldFootprint
      ])
    ]);
    target.subjectFieldKeys = target.subjectFieldKeys !== void 0 && next.subjectFieldKeys !== void 0 ? [.../* @__PURE__ */ new Set([...target.subjectFieldKeys, ...next.subjectFieldKeys])] : void 0;
    target.declaredScopes = mergeWriteObservationScopes(
      target.declaredScopes,
      next.declaredScopes
    );
    target.newValue = next.newValue;
    target.ownerPath = next.ownerPath;
    target.origin = this.mergeOrigin(target.origin, next.origin);
    target.meta = this.mergeMeta(target.meta, next.meta);
    target.subjectId = next.subjectId;
    target.positionId = next.positionId;
    target.subjectIds = next.subjectIds;
    target.positionIds = next.positionIds;
  }
  mergeOrigin(left, right) {
    if (!left && !right) return void 0;
    if (left === right) return left;
    return "mixed";
  }
  mergeMeta(left, right) {
    if (!left && !right) {
      return void 0;
    }
    if (!left || !right) {
      return void 0;
    }
    if (left.origin !== right.origin) {
      return void 0;
    }
    if (left.transactionId !== right.transactionId || left.transactionOwner !== right.transactionOwner || left.mutationIntent !== right.mutationIntent || getWriteParticipation(left) !== getWriteParticipation(right)) {
      return void 0;
    }
    const merged = left.structuralEffect && !right.structuralEffect ? { ...right, structuralEffect: left.structuralEffect } : right;
    return mergeEntityValueTransition(
      left,
      right,
      isMetaDesignated(left) ? { ...merged, ...markMetaDesignated(void 0) } : merged
    );
  }
  getCompositeBatchKey(entry) {
    const positionKey = entry.positionIds?.join(",") ?? "";
    const subjectKey = entry.subjectIds?.join(",") ?? "";
    const participation = getWriteParticipation(entry.meta);
    return `${entry.path}${_PathNotifier.ownerBoundarySeparator}${positionKey}${_PathNotifier.ownerBoundarySeparator}${subjectKey}${_PathNotifier.ownerBoundarySeparator}${participation}`;
  }
  /**
   * Clear all subscribers
   */
  clear() {
    this.subscribers.clear();
    this.pending.clear();
    this.pendingBeforeMembership = [];
    this.pendingFlush = false;
  }
  /** Reset queued runtime state but preserve registered listeners. */
  onReset(callback) {
    this.resetCallbacks.add(callback);
    return () => this.resetCallbacks.delete(callback);
  }
  emitReset() {
    for (const cb of Array.from(this.resetCallbacks)) {
      try {
        withoutWriteObservationScopes(cb);
      } catch {
      }
    }
  }
  /**
   * Get count of active subscribers (for debugging)
   */
  getSubscriberCount() {
    let count = 0;
    for (const handlers of this.subscribers.values()) {
      count += handlers.size;
    }
    return count;
  }
};
var globalPathNotifier = null;
function getPathNotifier() {
  if (!globalPathNotifier) {
    globalPathNotifier = new PathNotifier();
  }
  installPathDeliveryRuntime(globalPathNotifier);
  installBranchMembershipCapture(
    capturePlainBranchMembership,
    capturePathReAdd
  );
  return globalPathNotifier;
}

// packages/kernel/src/lib/internals/commit-consequence.ts
var scopesByOwner = /* @__PURE__ */ new WeakMap();
var openScopesByKey = /* @__PURE__ */ new WeakMap();
var settleListenersByKey = /* @__PURE__ */ new WeakMap();
var heldByKey = /* @__PURE__ */ new WeakMap();
function resolveScopeKey(node) {
  if (node === void 0 || node === null) return void 0;
  const candidate = node;
  const registry = getPositionRegistry(candidate.$ ?? node) ?? getPositionRegistry(node);
  return registry ?? node;
}
function hasOpen(key) {
  const scopes = openScopesByKey.get(key);
  return scopes !== void 0 && scopes.size > 0;
}
function openCommitScope(owner, transactionId, tree) {
  let byId = scopesByOwner.get(owner);
  if (!byId) {
    byId = /* @__PURE__ */ new Map();
    scopesByOwner.set(owner, byId);
  }
  const key = resolveScopeKey(tree);
  byId.set(transactionId, { key, consequences: /* @__PURE__ */ new Map() });
  if (key) {
    let open = openScopesByKey.get(key);
    if (!open) {
      open = /* @__PURE__ */ new Set();
      openScopesByKey.set(key, open);
    }
    open.add(transactionId);
  }
}
function settleCommitScope(owner, transactionId, outcome) {
  const byId = scopesByOwner.get(owner);
  const scope = byId?.get(transactionId);
  if (!byId || !scope) return;
  byId.delete(transactionId);
  if (byId.size === 0) scopesByOwner.delete(owner);
  const key = scope.key;
  if (key) {
    const open = openScopesByKey.get(key);
    open?.delete(transactionId);
    if (open && open.size === 0) openScopesByKey.delete(key);
  }
  let firstError;
  let failed = false;
  const capture = (error) => {
    if (!failed) {
      failed = true;
      firstError = error;
    }
  };
  const attempt = (fn) => {
    try {
      fn();
    } catch (error) {
      capture(error);
    }
  };
  if (outcome === "commit") {
    for (const consequence of scope.consequences.values()) attempt(consequence);
  }
  scope.consequences.clear();
  if (key && !hasOpen(key)) {
    const held = heldByKey.get(key);
    if (held) {
      heldByKey.delete(key);
      for (const consequence of held.values()) attempt(consequence);
      held.clear();
    }
    const listeners2 = settleListenersByKey.get(key);
    if (listeners2) {
      for (const listener of [...listeners2]) attempt(listener);
    }
  }
  if (failed) throw firstError;
}
function cancelCommitScopes(owner) {
  const scopes = scopesByOwner.get(owner);
  if (!scopes) return;
  scopesByOwner.delete(owner);
  for (const [id, scope] of scopes) {
    scope.consequences.clear();
    if (!scope.key) continue;
    const open = openScopesByKey.get(scope.key);
    open?.delete(id);
    if (open?.size === 0) openScopesByKey.delete(scope.key);
    heldByKey.delete(scope.key);
    settleListenersByKey.delete(scope.key);
  }
  scopes.clear();
}
function isCommitScopeOpen(owner, transactionId) {
  return scopesByOwner.get(owner)?.has(transactionId) === true;
}

// packages/kernel/src/lib/internals/visit-tree.ts
function visitTree(root, visit, options = {}) {
  const maxDepth = options.maxDepth ?? 32;
  const skipKey = options.skipKey;
  const seen = /* @__PURE__ */ new WeakSet();
  const walk = (node, path, key, parent, depth) => {
    if (depth > maxDepth) return;
    if (!isTraversableNode(node)) return;
    if (seen.has(node)) return;
    seen.add(node);
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("treeVisits");
    }
    if (visit(node, path, key, parent) === false) return;
    let keys;
    try {
      keys = Object.keys(node);
    } catch {
      return;
    }
    for (const k of keys) {
      if (skipKey && skipKey(k)) continue;
      let child;
      try {
        child = node[k];
      } catch {
        continue;
      }
      if (!isTraversableNode(child)) continue;
      walk(child, path ? `${path}.${k}` : k, k, node, depth + 1);
    }
  };
  walk(root, "", null, null, 0);
}

// packages/kernel/src/lib/internals/causal-runtime/pending-rollback.ts
function rollbackPendingTurnAt(options) {
  const turn = options.store.getPendingTurn(options.turnId);
  if (!turn) {
    return { ok: false, refusal: { kind: "turn-evicted" } };
  }
  if (!turn.participants.every(
    (participant) => options.topology.contains(options.authority, participant)
  )) {
    return { ok: false, refusal: { kind: "outside-boundary" } };
  }
  if (hasLaterStructuralDependency(turn, options.store)) {
    return { ok: false, refusal: { kind: "dependency-conflict" } };
  }
  const effects = options.selectedCompensation ? placeFieldReversalsWhileRowsExist(options.selectedCompensation) : createPendingRollbackEffects(turn, options.realizationContext);
  const validationRefusal = options.port.validateEffects?.(effects);
  if (validationRefusal) {
    return { ok: false, refusal: validationRefusal };
  }
  const transition2 = options.store.prepareDiscardPendingTurn(turn.id);
  if (!transition2.ok) {
    return mapDiscardFailure(transition2);
  }
  options.port.applyAtomically(effects);
  const discardedTurn = options.store.commitPreparedDiscardPending(
    transition2.transition
  );
  const maintenanceObserver = options.onMaintenanceMayBeUseful ?? options.onPendingTurnDiscarded;
  const maintenanceErrorObserver = options.reportMaintenanceObserverError ?? options.reportDiscardObserverError;
  if (discardedTurn && maintenanceObserver) {
    try {
      maintenanceObserver(discardedTurn);
    } catch (error) {
      if (maintenanceErrorObserver) {
        maintenanceErrorObserver(error, discardedTurn);
      } else {
        queueMicrotask(() => {
          throw normalizeError(error);
        });
      }
    }
  }
  return { ok: true, turnId: turn.id };
}
function createPendingRollbackEffects(turn, realizationContext) {
  const dominantStructuralEffects = /* @__PURE__ */ new Map();
  for (const effect of turn.effects) {
    if (effect.subjectId !== void 0 && (effect.structural === "add" || effect.structural === "remove")) {
      const candidates = dominantStructuralEffects.get(effect.subjectId);
      if (candidates) candidates.push(effect);
      else dominantStructuralEffects.set(effect.subjectId, [effect]);
    }
  }
  const firstEffectIndexByOwner = /* @__PURE__ */ new Map();
  turn.effects.forEach((effect, index) => {
    const effectKey = rollbackAddressKey(effect);
    if (!firstEffectIndexByOwner.has(effectKey)) {
      firstEffectIndexByOwner.set(effectKey, index);
    }
  });
  return placeFieldReversalsWhileRowsExist(
    turn.effects.filter((effect, index) => {
      if (effect.subjectId !== void 0) {
        const dominantStructuralEffect = dominantStructuralEffects.get(effect.subjectId)?.find((candidate) => sameSubjectScope(candidate, effect));
        if (dominantStructuralEffect && (dominantStructuralEffect === effect || dominantStructuralEffect.structural === "add" || dominantStructuralEffect.owner !== effect.owner)) {
          return dominantStructuralEffect === effect;
        }
      }
      const effectKey = rollbackAddressKey(effect);
      return firstEffectIndexByOwner.get(effectKey) === index;
    }).map(
      (effect) => createPendingRollbackEffect(effect, turn.id, realizationContext)
    ).filter(
      (effect) => effect.plainBranchMembership !== void 0 && effect.plainBranchMembership.before !== effect.plainBranchMembership.after || effect.before !== effect.after || effect.fieldPresence !== void 0 && effect.fieldPresence.before !== effect.fieldPresence.after
    )
  );
}
function placeFieldReversalsWhileRowsExist(effects) {
  if (effects.length === 0) return effects;
  const segments = [];
  let segment;
  let previous;
  for (const effect of effects) {
    if (!segment || !Object.is(previous, effect.turn)) {
      segments.push(segment = []);
      previous = effect.turn;
    }
    segment.push(effect);
  }
  let changed = false;
  const result = [];
  for (const unit of segments) {
    const rows = /* @__PURE__ */ new Map();
    const row = (e) => (e.structural === "add" || e.structural === "remove") && e.subjectId !== void 0;
    const scope = (e) => rows.get(e.owner)?.get(e.subjectId);
    for (const e of unit)
      if (row(e)) {
        let owners = rows.get(e.owner);
        if (!owners) rows.set(e.owner, owners = /* @__PURE__ */ new Map());
        const existing = owners.get(e.subjectId);
        if (existing && existing.kind !== e.structural) existing.mixed = true;
        if (!existing)
          owners.set(e.subjectId, {
            kind: e.structural,
            fields: [],
            mixed: false
          });
      }
    for (const e of unit)
      if (e.structural === void 0 && e.subjectId !== void 0) {
        const entry = scope(e);
        if (entry && !entry.mixed) entry.fields.push(e);
      }
    const ordered = [];
    for (const e of unit) {
      const candidate = scope(e);
      const entry = candidate?.mixed ? void 0 : candidate;
      if (e.structural === void 0 && e.subjectId !== void 0 && entry)
        continue;
      if (row(e) && e.structural === "remove" && entry) {
        for (const field of entry.fields) ordered.push(field);
        entry.fields = [];
      }
      ordered.push(e);
      if (row(e) && e.structural === "add" && entry) {
        for (const field of entry.fields) ordered.push(field);
        entry.fields = [];
      }
    }
    changed ||= ordered.some((effect, index) => effect !== unit[index]);
    for (const effect of ordered) result.push(effect);
  }
  return changed ? result : effects;
}
function rollbackAddressKey(effect) {
  if (effect.plainBranchMembership !== void 0) {
    return `${String(effect.owner)}\0membership`;
  }
  if (effect.structural === "rekey" && effect.subjectId !== void 0) {
    return JSON.stringify([effect.owner, effect.subjectId, "rekey"]);
  }
  if (effect.subjectFieldSegments !== void 0) {
    return JSON.stringify([
      effect.owner,
      effect.subjectId,
      effect.subjectFieldSegments
    ]);
  }
  return hasInlineScopedLeafAddress(effect) ? `${String(effect.owner)}\0${effect.path}` : String(effect.owner);
}
function createPendingRollbackEffect(effect, turnId, realizationContext) {
  const structural = deriveCompensationStructuralEffect(effect.structural);
  if (effect.structural !== void 0) {
    return {
      owner: effect.owner,
      before: deriveStructuralRollbackBefore(effect),
      after: deriveStructuralRollbackAfter(effect),
      subjectId: effect.subjectId,
      subjectFieldSegments: effect.subjectFieldSegments,
      plainBranchMembership: effect.plainBranchMembership ? {
        before: effect.plainBranchMembership.after,
        after: effect.plainBranchMembership.before
      } : void 0,
      fieldPresence: effect.fieldPresence ? {
        before: effect.fieldPresence.after,
        after: effect.fieldPresence.before
      } : void 0,
      structural,
      structuralContext: effect.structuralContext
    };
  }
  if (effect.plainBranchMembership !== void 0 || hasInlineScopedLeafAddress(effect)) {
    return {
      owner: effect.owner,
      before: effect.after,
      after: effect.before,
      subjectId: effect.subjectId,
      subjectFieldSegments: effect.subjectFieldSegments,
      plainBranchMembership: effect.plainBranchMembership ? {
        before: effect.plainBranchMembership.after,
        after: effect.plainBranchMembership.before
      } : void 0,
      fieldPresence: effect.fieldPresence ? {
        before: effect.fieldPresence.after,
        after: effect.fieldPresence.before
      } : void 0,
      path: effect.path,
      ownerPath: effect.ownerPath,
      structural,
      structuralContext: effect.structuralContext
    };
  }
  return {
    owner: effect.owner,
    before: realizationContext.getCurrentValue(effect.owner),
    after: realizationContext.getValueWithoutPendingTurn(turnId, effect.owner),
    subjectId: effect.subjectId,
    subjectFieldSegments: effect.subjectFieldSegments,
    fieldPresence: effect.fieldPresence ? {
      before: effect.fieldPresence.after,
      after: effect.fieldPresence.before
    } : void 0,
    structural,
    structuralContext: effect.structuralContext
  };
}
function hasInlineScopedLeafAddress(effect) {
  if (effect.subjectFieldSegments !== void 0) return true;
  return effect.structural === void 0 && effect.path !== effect.ownerPath;
}
function deriveStructuralRollbackBefore(effect) {
  switch (effect.structural) {
    case "add":
    case "rekey":
      return effect.after;
    case "remove":
      return effect.after;
    default:
      return effect.before;
  }
}
function deriveStructuralRollbackAfter(effect) {
  switch (effect.structural) {
    case "add":
      return effect.before;
    case "remove":
    case "rekey":
      return effect.before;
    default:
      return effect.after;
  }
}
function hasLaterStructuralDependency(pendingTurn, store) {
  const laterTurns = [...store.getTurns(), ...store.getPendingTurns()].filter(
    (turn) => turn.id > pendingTurn.id
  );
  return pendingTurn.effects.some((pendingEffect) => {
    if (!pendingEffect.structural || !pendingEffect.subjectId) {
      return false;
    }
    if (pendingEffect.structural === "add") {
      return laterTurns.some(
        (turn) => turn.effects.some((effect) => sameSubjectScope(effect, pendingEffect))
      );
    }
    const restoredStructuralResource = getRestoredStructuralResource(pendingEffect);
    if (restoredStructuralResource !== void 0 && laterTurns.some(
      (turn) => turn.effects.some(
        (effect) => getAcquiredStructuralResource(effect) === restoredStructuralResource && sameStructuralScope(effect, pendingEffect)
      )
    )) {
      return true;
    }
    return laterTurns.some(
      (turn) => turn.effects.some(
        (effect) => effect.structural !== void 0 && sameSubjectScope(effect, pendingEffect)
      )
    );
  });
}
function sameSubjectScope(left, right) {
  if (left.subjectId !== right.subjectId) {
    return false;
  }
  const leftOwnerPath = left.ownerPath;
  const rightOwnerPath = right.ownerPath;
  return typeof leftOwnerPath === "string" && typeof rightOwnerPath === "string" ? leftOwnerPath === rightOwnerPath : true;
}
function sameStructuralScope(left, right) {
  const leftOwnerPath = left.ownerPath;
  const rightOwnerPath = right.ownerPath;
  return typeof leftOwnerPath === "string" && typeof rightOwnerPath === "string" ? leftOwnerPath === rightOwnerPath : left.owner === right.owner;
}
function getRestoredStructuralResource(effect) {
  switch (effect.structural) {
    case "remove":
    case "rekey":
      return effect.before;
    default:
      return void 0;
  }
}
function getAcquiredStructuralResource(effect) {
  switch (effect.structural) {
    case "add":
    case "rekey":
      return effect.after;
    default:
      return void 0;
  }
}
function deriveCompensationStructuralEffect(structural) {
  switch (structural) {
    case "add":
      return "remove";
    case "remove":
      return "add";
    case "rekey":
      return "rekey";
    default:
      return void 0;
  }
}
function mapDiscardFailure(result) {
  if (result.reason === "turn-evicted") {
    return { ok: false, refusal: { kind: "turn-evicted" } };
  }
  return { ok: false, refusal: { kind: "turn-evicted" } };
}
function normalizeError(error) {
  if (error instanceof Error) {
    return error;
  }
  return new Error(String(error));
}

// packages/kernel/src/lib/internals/exposed-publication.ts
function publishingExposedOnly(root, run) {
  const notifier = getPathNotifier();
  const outer = notifier.absentRealized;
  notifier.absentRealized = (positionIds, meta) => meta?.participation === "realized" && positionIds?.[0] !== void 0 && !!hidingMembers(root, positionIds[0])?.length;
  try {
    return run();
  } finally {
    notifier.absentRealized = outer;
  }
}

// packages/kernel/src/lib/internals/causal-runtime/post-application-failure.ts
var AppliedDeliveryFailure = class {
  constructor(cause) {
    this.cause = cause;
  }
};
function applicationFailureCause(error) {
  return error instanceof AppliedDeliveryFailure ? error.cause : error;
}
function applyInInvalidationGroup(root, apply) {
  const locations = getLocationRuntime(root);
  let applied = false;
  try {
    const run = () => {
      apply();
      applied = true;
    };
    if (locations) locations.runInvalidationGroup(run);
    else run();
  } catch (error) {
    const cause = applicationFailureCause(error);
    throw applied ? new AppliedDeliveryFailure(cause) : cause;
  }
}

// packages/kernel/src/lib/internals/subject-restoration-claims.ts
function createSubjectRestorationClaims() {
  const byOwner = /* @__PURE__ */ new Map();
  const bySubject = /* @__PURE__ */ new Map();
  function addClaim(owner, subjectId) {
    let owners = bySubject.get(subjectId);
    if (!owners) {
      owners = /* @__PURE__ */ new Set();
      bySubject.set(subjectId, owners);
    }
    owners.add(owner);
  }
  function dropClaim(owner, subjectId) {
    const owners = bySubject.get(subjectId);
    if (!owners) {
      return false;
    }
    owners.delete(owner);
    if (owners.size > 0) {
      return false;
    }
    bySubject.delete(subjectId);
    return true;
  }
  return {
    retain(owner, subjects) {
      const next = new Set(subjects);
      const previous = byOwner.get(owner);
      const newlyUnowned = [];
      if (previous) {
        for (const subjectId of previous) {
          if (next.has(subjectId)) {
            continue;
          }
          if (dropClaim(owner, subjectId)) {
            newlyUnowned.push(subjectId);
          }
        }
      }
      if (next.size === 0) {
        byOwner.delete(owner);
        return newlyUnowned;
      }
      for (const subjectId of next) {
        addClaim(owner, subjectId);
      }
      byOwner.set(owner, next);
      return newlyUnowned;
    },
    release(owner) {
      const held = byOwner.get(owner);
      if (!held) {
        return [];
      }
      byOwner.delete(owner);
      const newlyUnowned = [];
      for (const subjectId of held) {
        if (dropClaim(owner, subjectId)) {
          newlyUnowned.push(subjectId);
        }
      }
      return newlyUnowned;
    },
    releaseAll() {
      const released = [...bySubject.keys()];
      byOwner.clear();
      bySubject.clear();
      return released;
    },
    isClaimed(subjectId) {
      return bySubject.has(subjectId);
    },
    ownersOf(subjectId) {
      const owners = bySubject.get(subjectId);
      return owners ? [...owners] : [];
    },
    claimedSubjects() {
      return [...bySubject.keys()];
    },
    snapshot() {
      return { owners: byOwner.size, claimedSubjects: bySubject.size };
    }
  };
}
var SUBJECT_RESTORATION_CLAIMS_SYMBOL = Symbol.for(
  "SignalTree:SubjectRestorationClaims"
);
function getOrCreateSubjectRestorationClaims(node) {
  const existing = getSubjectRestorationClaims(node);
  if (existing) {
    return existing;
  }
  const host = node?.$ ?? node;
  if (!isTraversableNode(host)) {
    return void 0;
  }
  const claims = createSubjectRestorationClaims();
  defineSubjectRestorationClaims(host, claims);
  return claims;
}
function defineSubjectRestorationClaims(node, claims) {
  Object.defineProperty(node, SUBJECT_RESTORATION_CLAIMS_SYMBOL, {
    value: claims,
    enumerable: false,
    configurable: true
  });
}
function getSubjectRestorationClaims(node) {
  return read(node) ?? read(node?.$);
}
function read(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[SUBJECT_RESTORATION_CLAIMS_SYMBOL];
}

// packages/kernel/src/lib/internals/intercept-leaf-signals.ts
function interceptLeafSignals(root, onWrite, options = {}) {
  const restorers = [];
  const maxDepth = options.maxDepth ?? 32;
  const withMutationIntent = (meta, mutationIntent) => ({
    ...meta ?? {},
    mutationIntent
  });
  const getOwnerPath = (node, path) => {
    return getOwnedOwnerPath(node) ?? path;
  };
  const getSubjectIds = (node) => {
    return getOwnedSubjectIds(node);
  };
  const getPositionIds = (node) => {
    return getOwnedPositionIds(node);
  };
  const wrapWritableSignal = (node, path, ownerPathOverride) => {
    const original2 = node;
    const originalSet = original2.set.bind(original2);
    const originalUpdate = original2.update.bind(original2);
    restorers.push(() => {
      original2.set = originalSet;
      original2.update = originalUpdate;
    });
    original2.set = (value) => {
      const prev = original2();
      originalSet(value);
      const next = original2();
      const ownerPath = ownerPathOverride ?? getOwnerPath(node, path);
      const subjectIds = getSubjectIds(node);
      const positionIds = getPositionIds(node);
      if (next !== prev) {
        onWrite(
          path,
          next,
          prev,
          withMutationIntent(getActiveWriteContext(), "replace"),
          ownerPath,
          subjectIds,
          positionIds
        );
      }
    };
    original2.update = (updater) => {
      const prev = original2();
      originalUpdate(updater);
      const next = original2();
      const ownerPath = ownerPathOverride ?? getOwnerPath(node, path);
      const subjectIds = getSubjectIds(node);
      const positionIds = getPositionIds(node);
      if (next !== prev) {
        onWrite(
          path,
          next,
          prev,
          withMutationIntent(getActiveWriteContext(), "derive"),
          ownerPath,
          subjectIds,
          positionIds
        );
      }
    };
  };
  const observeLocation = (node, path, ownerPathOverride, normal = true) => {
    const release = normal ? observeIntrinsicMutations(node, (mutation) => {
      if (!mutation.changed) return;
      onWrite(
        path,
        mutation.after,
        mutation.before,
        withMutationIntent(getActiveWriteContext(), mutation.intent),
        ownerPathOverride ?? getOwnerPath(node, path),
        getSubjectIds(node),
        getPositionIds(node)
      );
    }) : void 0;
    const terminalRecord = options.terminalRecord;
    if (terminalRecord) {
      const terminalRelease = prepareTerminalMutations(node, (mutation) => {
        if (!mutation.changed) return;
        return terminalRecord.call(options, path, mutation.after, mutation.before, withMutationIntent(getActiveWriteContext(), mutation.intent), ownerPathOverride ?? getOwnerPath(node, path), getSubjectIds(node), getPositionIds(node));
      });
      if (terminalRelease) restorers.push(terminalRelease);
    }
    const beforePublication = options.beforePublication;
    if (beforePublication) {
      const captureRelease = observeIntrinsicMutations(node, (mutation) => {
        if (!mutation.changed) return;
        beforePublication.call(
          options,
          path,
          mutation.after,
          mutation.before,
          withMutationIntent(getActiveWriteContext(), mutation.intent),
          ownerPathOverride ?? getOwnerPath(node, path),
          getSubjectIds(node),
          getPositionIds(node)
        );
      }, true);
      if (captureRelease) restorers.push(captureRelease);
    }
    if (release) restorers.push(release);
  };
  const wrapOwnedFieldAccessors = (node, basePath, ownerPath, seen = /* @__PURE__ */ new WeakSet()) => {
    if (!isTraversableNode(node)) {
      return;
    }
    const ref = node;
    if (seen.has(ref)) return;
    seen.add(ref);
    const isWritableSignal = typeof node === "function" && "set" in node && "update" in node && // eslint-disable-next-line @typescript-eslint/no-explicit-any
    typeof node.set === "function" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
    typeof node.update === "function";
    if (isWritableSignal) {
      wrapWritableSignal(node, basePath, ownerPath);
    }
    for (const key of Object.keys(node)) {
      const child = node[key];
      if (child !== null && typeof child === "object" && !(Array.isArray(child) || child instanceof Date || child instanceof Map || child instanceof Set)) {
        wrapOwnedFieldAccessors(child, `${basePath}.${key}`, ownerPath, seen);
      } else if (typeof child === "function") {
        wrapOwnedFieldAccessors(child, `${basePath}.${key}`, ownerPath, seen);
      }
    }
  };
  const wrapMutator = (target, method, path) => {
    if (typeof target[method] !== "function") return;
    const originalMethod = target[method].bind(target);
    restorers.push(() => {
      target[method] = originalMethod;
    });
    target[method] = (...args) => {
      const canSnapshotMutatorState = typeof target.__findKeyBySubjectId !== "function";
      const prevSnapshot = canSnapshotMutatorState ? snapshotMarkerNode(target)?.value : void 0;
      const result = originalMethod(...args);
      const nextSnapshot = canSnapshotMutatorState ? snapshotMarkerNode(target)?.value : void 0;
      onWrite(
        path,
        nextSnapshot,
        prevSnapshot,
        getActiveWriteContext(),
        path,
        getSubjectIds(target),
        getPositionIds(target)
      );
      return result;
    };
  };
  try {
    visitTree(
      root,
      (node, path) => {
        if (path === "") return true;
        if (isWritableLocation(node)) {
          if (!hasIntrinsicMutationEmitter(node) || options.beforePublication) {
            observeLocation(node, path, void 0, !hasIntrinsicMutationEmitter(node));
          }
          return false;
        }
        const isWritableSignal = typeof node === "function" && "set" in node && "update" in node && // eslint-disable-next-line @typescript-eslint/no-explicit-any
        typeof node.set === "function" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
        typeof node.update === "function";
        if (isWritableSignal) {
          const isEntityCollection = "add" in node || "remove" in node;
          if (isEntityCollection) return false;
          const hasOwnedMutationEmitter = hasIntrinsicMutationEmitter(node);
          if (hasOwnedMutationEmitter) {
            return false;
          }
          wrapWritableSignal(node, path);
          const proc2 = getNodeProcessor(node);
          if (proc2 && isTraversableNode(node)) {
            for (const method of ["clear", "reload", "reset", "refresh"]) {
              wrapMutator(node, method, path);
            }
          }
          return false;
        }
        const proc = getNodeProcessor(node);
        if (proc && hasIntrinsicMutationEmitter(node)) {
          return false;
        }
        if (proc && isTraversableNode(node)) {
          const marker = node;
          const MUTATORS = [
            "set",
            "patch",
            "setAll",
            "addOne",
            "addMany",
            "prependMany",
            "updateOne",
            "updateMany",
            "upsertOne",
            "upsertMany",
            "changeId",
            "removeOne",
            "removeMany",
            "clear",
            "setLoading",
            "setLoaded",
            "setError",
            "setNotLoaded",
            "start",
            "setSuccess",
            "succeed",
            "fail",
            "refresh",
            "rerun",
            "reset"
          ];
          for (const method of MUTATORS) {
            wrapMutator(marker, method, path);
          }
          const fields = marker.$;
          if (fields && isTraversableNode(fields)) {
            wrapOwnedFieldAccessors(fields, path, path);
          }
          return false;
        }
        if (typeof node === "object" && (Array.isArray(node) || node instanceof Date || node instanceof Map || node instanceof Set)) {
          return false;
        }
        return true;
      },
      { maxDepth }
    );
  } catch {
  }
  return () => {
    for (const restore of restorers) {
      try {
        restore();
      } catch {
      }
    }
    restorers.length = 0;
  };
}

// packages/kernel/src/lib/physical/prepare-structural-target.ts
function prepareStructuralTarget(sourceStates, sourceRevisions, subjects, order, orderFrontier) {
  const subjectIds = /* @__PURE__ */ new Map();
  const targetBySubject = /* @__PURE__ */ new Map();
  for (const subject of subjects) {
    if (targetBySubject.has(subject.subjectId) || subjectIds.has(subject.key)) {
      throw new Error("Structural target contains duplicate identity or key");
    }
    const current = sourceStates.get(subject.subjectId);
    if (!current || !current.active && !current.restoreAllowed) {
      throw new Error(
        `Subject ${subject.subjectId} cannot enter the structural target`
      );
    }
    targetBySubject.set(subject.subjectId, subject);
    subjectIds.set(subject.key, subject.subjectId);
  }
  if (order.length !== targetBySubject.size || new Set(order).size !== order.length || order.some((subjectId) => !targetBySubject.has(subjectId))) {
    throw new Error(
      "Structural target order does not match its active subjects"
    );
  }
  const subjectStates = new Map(sourceStates);
  const subjectRevisions = new Map(sourceRevisions);
  for (const [subjectId, current] of sourceStates) {
    const target = targetBySubject.get(subjectId);
    if (!target) {
      if (current.active) {
        subjectStates.set(subjectId, {
          active: false,
          restoreAllowed: current.restoreAllowed
        });
        subjectRevisions.set(
          subjectId,
          (sourceRevisions.get(subjectId) ?? 0) + 1
        );
      }
      continue;
    }
    if (!current.active || current.key !== target.key) {
      subjectRevisions.set(
        subjectId,
        (sourceRevisions.get(subjectId) ?? 0) + 1
      );
    }
    subjectStates.set(subjectId, {
      active: true,
      key: target.key,
      restoreAllowed: current.restoreAllowed
    });
  }
  const activeNodesByKey = /* @__PURE__ */ new Map();
  const activeNodesBySubject = /* @__PURE__ */ new Map();
  let activeHead;
  let activeTail;
  for (const subjectId of order) {
    const target = targetBySubject.get(subjectId);
    const node = {
      key: target.key,
      subjectId,
      prev: activeTail,
      next: void 0
    };
    if (activeTail) {
      activeTail.next = node;
    } else {
      activeHead = node;
    }
    activeTail = node;
    activeNodesByKey.set(node.key, node);
    activeNodesBySubject.set(node.subjectId, node);
  }
  return {
    subjectIds,
    subjectStates,
    subjectRevisions,
    activeNodesByKey,
    activeNodesBySubject,
    activeHead,
    activeTail,
    activeCount: order.length,
    orderFrontier
  };
}

// packages/kernel/src/lib/physical/prepare-entity-target.ts
function prepareEntityTransitionTarget(host, target) {
  const {
    positionId,
    structuralStore,
    valueStore,
    activeIdSignal,
    subjectEpochs,
    subjectStateSignals,
    advanceEpochHandle,
    updateSignals,
    physicalCommitClock,
    pathNotifier,
    basePath,
    getPositionIdsForNotify,
    createStructuralEffectMeta,
    ambientMeta,
    emitTap
  } = host;
  if (positionId === void 0 || target.owner !== positionId) {
    throw new Error(
      "Collection transition target owner does not match the binding"
    );
  }
  const beforeOrderFrontier = structuralStore.activeOrderFrontier();
  const currentSubjects = /* @__PURE__ */ new Map();
  const activeIdBefore = activeIdSignal();
  const activeSubjectBefore = activeIdBefore === void 0 ? void 0 : structuralStore.subjectIdForKey(activeIdBefore);
  for (const key of structuralStore.activeKeysSnapshot()) {
    const subjectId = structuralStore.subjectIdForKey(key);
    const value = subjectId === void 0 ? void 0 : valueStore.backingForSubject(subjectId);
    if (subjectId !== void 0 && value !== void 0) {
      currentSubjects.set(subjectId, { key, value });
    }
  }
  const beforeOrder = [...currentSubjects.keys()];
  const afterOrder = [...target.order];
  const preparedSubjects = target.subjects.map((subject) => {
    if (subject.value === null || typeof subject.value !== "object" || Array.isArray(subject.value)) {
      throw new Error(
        `Collection target subject ${subject.subject} has no entity value`
      );
    }
    return {
      subjectId: subject.subject,
      key: subject.key,
      value: deepClone(subject.value)
    };
  });
  const structuralTarget = structuralStore.prepareTarget(
    preparedSubjects,
    target.order,
    target.orderFrontier,
    prepareStructuralTarget
  );
  const valueTarget = valueStore.prepareTargetValues(preparedSubjects);
  const physicalPlacement = structuralStore.preparePlacement();
  for (const subject of currentSubjects.keys())
    physicalPlacement.remove(subject);
  const targetKeys = new Map(
    preparedSubjects.map((row) => [row.subjectId, row.key])
  );
  for (const subject of target.order) {
    const key = targetKeys.get(subject);
    if (key === void 0)
      throw new Error("Prepared target order lacks a lifetime");
    physicalPlacement.insert(subject, key);
  }
  const ordinaryPlan = host.prepareOrdinaryRealization(
    target.admittedEffects ?? [],
    new Map(preparedSubjects.map((row) => [row.subjectId, row.value])),
    [],
    physicalPlacement,
    target.admittedOrder
  );
  const ordinaryBySubject = /* @__PURE__ */ new Map();
  for (const change of ordinaryPlan?.changes ?? []) {
    let changes = ordinaryBySubject.get(change.subject);
    if (!changes) ordinaryBySubject.set(change.subject, changes = []);
    changes.push(change);
  }
  const affectedSubjects = /* @__PURE__ */ new Set([
    ...currentSubjects.keys(),
    ...preparedSubjects.map(({ subjectId }) => subjectId)
  ]);
  const preparedBySubject = new Map(
    preparedSubjects.map((subject) => [subject.subjectId, subject])
  );
  const activeIdAfter = (activeSubjectBefore === void 0 ? void 0 : preparedBySubject.get(activeSubjectBefore)?.key) ?? activeIdBefore;
  const targetNeighborBySubject = new Map(
    target.order.map((subjectId, index) => [
      subjectId,
      {
        beforeSubject: target.order[index - 1],
        afterSubject: target.order[index + 1]
      }
    ])
  );
  const subjectChanges = [...affectedSubjects].map((subjectId) => {
    const before = currentSubjects.get(subjectId);
    const after = preparedBySubject.get(subjectId);
    return {
      subjectId,
      beforeKey: before?.key,
      afterKey: after?.key,
      beforeValue: before?.value,
      valueEpoch: subjectEpochs.get(subjectId),
      stateSignal: subjectStateSignals.get(subjectId)?.deref(),
      afterValue: after?.value,
      bindingChanged: !before || !after || before.key !== after.key,
      targetNeighbors: targetNeighborBySubject.get(subjectId)
    };
  });
  return {
    install() {
      const tap = host.membershipTap;
      tap?.(MEMBERSHIP_OPEN_ORDER);
      try {
        structuralStore.installPreparedTarget(structuralTarget);
        valueStore.installPreparedTargetValues(valueTarget);
        ordinaryPlan?.install();
        if (activeIdBefore !== activeIdAfter) {
          replaceLocation(activeIdSignal, activeIdAfter);
        }
      } finally {
        tap?.(MEMBERSHIP_CLOSE);
      }
    },
    publishOrder() {
      host.publishOrderChange(
        beforeOrder,
        afterOrder,
        beforeOrderFrontier,
        target.orderFrontier,
        ordinaryPlan.ordinaryEndpoints,
        target.admittedEffects !== void 0
      );
    },
    publish(options) {
      for (const publication of subjectChanges) {
        if (publication.valueEpoch) advanceEpochHandle(publication.valueEpoch);
        if (publication.bindingChanged) {
          if (publication.stateSignal) {
            deriveLocation(publication.stateSignal, (value) => value + 1);
          }
        }
      }
      updateSignals();
      if (options?.advancePhysicalRevision !== false) {
        physicalCommitClock?.advance();
      }
      for (const publication of subjectChanges) {
        const key = publication.afterKey ?? publication.beforeKey;
        if (key === void 0) {
          continue;
        }
        const structuralEffect = publication.beforeKey === void 0 ? {
          kind: "add",
          subject: publication.subjectId,
          key,
          value: publication.afterValue,
          ...publication.targetNeighbors
        } : publication.afterKey === void 0 ? {
          kind: "remove",
          subject: publication.subjectId,
          key,
          value: publication.beforeValue
        } : publication.beforeKey !== publication.afterKey ? {
          kind: "rekey",
          subject: publication.subjectId,
          beforeKey: publication.beforeKey,
          afterKey: publication.afterKey
        } : void 0;
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          publication.afterValue,
          publication.beforeValue,
          basePath,
          [publication.subjectId],
          getPositionIdsForNotify(),
          (target.admittedEffects === void 0 ? withEntityOrdinaryChanges : withSelectedEntityDisposition)(
            {
              ...structuralEffect ? createStructuralEffectMeta(structuralEffect) : ambientMeta(),
              // Replay publishes retained storage too. Apply the same exposed
              // path protocol as the ordinary realization adapter, without
              // changing the ambient context of subsequent application taps.
              intent: "system",
              participation: "realized"
            },
            ordinaryPlan ? ordinaryBySubject.get(publication.subjectId) ?? [] : [
              {
                subject: publication.subjectId,
                before: publication.beforeValue,
                after: publication.afterValue,
                structural: structuralEffect !== void 0,
                path: `${basePath}.${String(key)}`,
                structuralRecord: structuralEffect
              }
            ]
          )
        );
        const { beforeValue, afterValue } = publication;
        const kind = structuralEffect?.kind;
        if (kind === "add") emitTap("onAdd", afterValue, key);
        else if (kind === "remove") emitTap("onRemove", key, beforeValue);
        else if (!kind && !deepEqual(beforeValue, afterValue))
          emitTap("onUpdate", key, afterValue, afterValue);
      }
    }
  };
}

// packages/kernel/src/lib/internals/utilities/append-all.ts
function appendAll(target, items) {
  for (let i = 0; i < items.length; i++) target.push(items[i]);
}

// packages/kernel/src/lib/internals/causal-runtime/target-transition.ts
function prepareDeclarativeTransitionInstallation(target, bindings2, scalarBinding, memberBinding2, completion) {
  const prepared = [];
  let scalars = target.scalars;
  if (target.plainBranchMembers?.size) {
    if (!memberBinding2)
      throw new Error(
        "Declarative transition has member targets but no member binding"
      );
    const members = memberBinding2.prepareTarget(target.plainBranchMembers);
    prepared.push(members);
    scalars = withoutSupersededScalars(
      target.scalars,
      target.scalarTurns,
      members.staged
    );
  }
  for (const [owner, collection] of target.collections) {
    const binding = bindings2.get(owner);
    if (!binding || binding.owner !== owner) {
      throw new Error(
        `Declarative transition has no collection binding ${owner}`
      );
    }
    prepared.push(
      binding.prepareTarget(collection, prepareEntityTransitionTarget)
    );
  }
  if (scalars.size > 0) {
    if (!scalarBinding) {
      throw new Error(
        "Declarative transition has scalar targets but no scalar binding"
      );
    }
    prepared.push(scalarBinding.prepareTarget(scalars));
  }
  return {
    install() {
      for (const collection of prepared) {
        collection.install();
      }
      completion?.onCommitted();
      let failed = false;
      let first;
      for (const collection of prepared) {
        try {
          collection.publishOrder?.();
        } catch (error) {
          if (!failed) {
            failed = true;
            first = error;
          }
        }
      }
      for (const collection of prepared) {
        try {
          collection.publish();
        } catch (error) {
          if (!failed) {
            failed = true;
            first = error;
          }
        }
      }
      if (failed) throw first;
    }
  };
}
function withoutSupersededScalars(scalars, scalarTurns, staged) {
  if (!scalarTurns?.size || !staged?.size) return scalars;
  let kept;
  for (const [owner, turn] of scalarTurns) {
    const stagedTurn = staged.get(owner);
    if (stagedTurn === void 0 || stagedTurn <= turn) continue;
    kept ??= new Map(scalars);
    kept.delete(owner);
  }
  return kept ?? scalars;
}
var CollectionOrderConflict = class extends Error {
  constructor(owner, reason, failure) {
    super(failure.message);
    this.owner = owner;
    this.reason = reason;
    this.name = "CollectionOrderConflict";
  }
};
var ORDER_FAILURES = [
  [
    "frontier does not match the transition endpoint",
    "the order change being reversed no longer applies to its current order"
  ],
  [
    "no live placement anchor",
    "a restored row's recorded neighbours are no longer in it"
  ],
  [
    "Collection order does not match active SubjectIds",
    "its reconstructed order and its rows disagree"
  ],
  ["contains an anchor cycle", "its rows' recorded neighbours form a cycle"],
  [
    "contains contradictory anchors",
    "its rows' recorded neighbours contradict each other"
  ]
];
function asOrderConflict(owner, failure) {
  if (!(failure instanceof Error) || failure instanceof CollectionOrderConflict)
    return failure;
  const known = ORDER_FAILURES.find(
    ([message]) => failure.message.includes(message)
  );
  return known ? new CollectionOrderConflict(owner, known[1], failure) : failure;
}
function requiresDeclarativeStructuralTarget(effects, readSource) {
  const structural = effects.filter(
    (effect) => effect.structural !== void 0
  );
  const occupiedKeyOf = (effect) => effect.structural === "add" || effect.structural === "rekey" ? effect.after : void 0;
  const occupying = /* @__PURE__ */ new Map();
  structural.forEach((effect, index) => {
    const key = occupiedKeyOf(effect);
    if (key === void 0) return;
    let byKey = occupying.get(effect.owner);
    if (!byKey) occupying.set(effect.owner, byKey = /* @__PURE__ */ new Map());
    const indices = byKey.get(key);
    if (indices) indices.push(index);
    else byKey.set(key, [index]);
  });
  const hasKeyHandoff = structural.some((vacating, vacatingIndex) => {
    const vacatedKey = vacating.structural === "remove" || vacating.structural === "rekey" ? vacating.before : void 0;
    if (vacatedKey === void 0) {
      return false;
    }
    const candidates = occupying.get(vacating.owner)?.get(vacatedKey);
    return candidates?.some(
      (occupyingIndex) => occupyingIndex !== vacatingIndex && Object.is(vacatedKey, occupiedKeyOf(structural[occupyingIndex]))
    ) ?? false;
  });
  if (hasKeyHandoff) {
    return true;
  }
  const additions = structural.filter(
    (effect) => effect.structural === "add" && typeof effect.subjectId === "number"
  );
  if (additions.length < 2) {
    const addition = additions[0];
    const context = addition?.structuralContext;
    if (readSource && (context?.kind === "remove" || context?.kind === "add") && (context.beforeSubject !== void 0 || context.afterSubject !== void 0)) {
      const source = readSource(addition.owner);
      return ![context.beforeSubject, context.afterSubject].some(
        (anchor) => anchor !== void 0 && source?.order.includes(anchor)
      );
    }
    return false;
  }
  const addedSubjects = /* @__PURE__ */ new Map();
  for (const addition of additions) {
    if (typeof addition.subjectId !== "number") continue;
    let turns = addedSubjects.get(addition.owner);
    if (!turns) addedSubjects.set(addition.owner, turns = /* @__PURE__ */ new Map());
    let subjects = turns.get(addition.turn);
    if (!subjects) turns.set(addition.turn, subjects = /* @__PURE__ */ new Set());
    subjects.add(addition.subjectId);
  }
  return additions.some((effect) => {
    const context = effect.structuralContext;
    if (context?.kind !== "add" && context?.kind !== "remove") {
      return false;
    }
    const subjects = addedSubjects.get(effect.owner)?.get(effect.turn);
    return context.beforeSubject !== void 0 && !subjects?.has(context.beforeSubject) || context.afterSubject !== void 0 && !subjects?.has(context.afterSubject);
  });
}
function deriveDeclarativeTransitionTarget(options) {
  const collections = /* @__PURE__ */ new Map();
  for (const source of options.collections) {
    if (collections.has(source.owner)) {
      throw new Error(`Duplicate collection transition owner ${source.owner}`);
    }
    assertUniqueSubjects(source.order);
    assertUniqueSubjects(source.subjects.map(({ subject }) => subject));
    const subjects = new Map(
      source.subjects.map((subject) => [subject.subject, { ...subject }])
    );
    try {
      assertCollectionOrderMatchesSubjects(source.order, subjects);
    } catch (failure) {
      throw asOrderConflict(source.owner, failure);
    }
    collections.set(source.owner, {
      subjects,
      order: [...source.order],
      sourceSubjects: new Set(subjects.keys())
    });
  }
  const scalars = /* @__PURE__ */ new Map();
  const scalarTurns = /* @__PURE__ */ new Map();
  const plainBranchMembers = /* @__PURE__ */ new Map();
  for (const effect of options.effects) {
    if (effect.plainBranchMembership) {
      plainBranchMembers.delete(effect.owner);
      plainBranchMembers.set(effect.owner, {
        present: effect.plainBranchMembership.after,
        value: effect.after,
        ...effect.turn === void 0 ? {} : { turn: effect.turn }
      });
      continue;
    }
    if (effect.structural === void 0) {
      applyValueEffect(collections, scalars, effect);
      if (typeof effect.subjectId !== "number" && effect.turn !== void 0)
        scalarTurns.set(effect.owner, effect.turn);
      continue;
    }
    try {
      applyStructuralEffect(collections, effect);
    } catch (failure) {
      throw asOrderConflict(effect.owner, failure);
    }
  }
  const orderDeltas = /* @__PURE__ */ new Map();
  for (const delta of options.orderDeltas ?? []) {
    if (orderDeltas.has(delta.owner)) {
      throw new Error(
        `Duplicate collection order delta for owner ${delta.owner}`
      );
    }
    orderDeltas.set(delta.owner, delta);
  }
  const targets = /* @__PURE__ */ new Map();
  for (const [owner, collection] of collections) {
    const delta = orderDeltas.get(owner);
    const orderEndpoint = options.orderEndpoints?.get(owner) ?? options.orderEndpoint ?? "after";
    let order;
    try {
      order = delta ? applyCollectionOrderDelta(
        collection.order,
        delta,
        orderEndpoint,
        options.collections.find((source) => source.owner === owner)?.orderFrontier
      ) : deriveStructuralTargetOrder(
        collection.order,
        collection.subjects,
        options.effects.filter((effect) => effect.owner === owner).map((effect) => realizationPlacement(effect) ?? effect)
      );
      assertCollectionOrderMatchesSubjects(order, collection.subjects);
    } catch (failure) {
      throw asOrderConflict(owner, failure);
    }
    assertUniqueTargetKeys(collection.subjects);
    targets.set(owner, {
      owner,
      subjects: [...collection.subjects.values()].sort(
        (left, right) => left.subject - right.subject
      ),
      order,
      orderFrontier: delta ? orderEndpoint === "before" ? delta.beforeFrontier : delta.afterFrontier : options.collections.find((source) => source.owner === owner)?.orderFrontier === void 0 || sameSubjects(collection.sourceSubjects, collection.subjects) ? options.collections.find((source) => source.owner === owner)?.orderFrontier : {}
    });
  }
  for (const owner of orderDeltas.keys()) {
    if (!targets.has(owner)) {
      throw new Error(`Collection order delta has no owner ${owner}`);
    }
  }
  return {
    collections: targets,
    scalars,
    ...scalarTurns.size ? { scalarTurns } : {},
    ...plainBranchMembers.size ? { plainBranchMembers } : {}
  };
}
function deriveCollectionOrderDelta(owner, before, after, beforeFrontier, afterFrontier, ordinaryEndpoints) {
  assertUniqueSubjects(before);
  assertUniqueSubjects(after);
  const beforeRank = indexSubjects(before);
  const afterRank = indexSubjects(after);
  const commonBefore = before.filter((subject) => afterRank.has(subject));
  const commonAfter = after.filter((subject) => beforeRank.has(subject));
  const backbone = lexicographicallySmallestCommonSubsequence(
    commonBefore,
    commonAfter
  );
  const backboneSubjects = new Set(backbone);
  const participants = /* @__PURE__ */ new Map();
  for (const [subject, rank] of beforeRank) {
    if (!backboneSubjects.has(subject)) {
      participants.set(subject, { subject, beforeRank: rank });
    }
  }
  for (const [subject, rank] of afterRank) {
    if (backboneSubjects.has(subject)) {
      continue;
    }
    participants.set(subject, {
      ...participants.get(subject),
      subject,
      afterRank: rank
    });
  }
  return {
    owner,
    beforeLength: before.length,
    afterLength: after.length,
    beforeFrontier,
    afterFrontier,
    ordinaryEndpoints,
    participants: [...participants.values()].sort(
      (left, right) => left.subject - right.subject
    )
  };
}
function applyCollectionOrderDelta(current, delta, endpoint, currentFrontier) {
  assertUniqueSubjects(current);
  const sourceEndpoint = endpoint === "before" ? "after" : "before";
  const sourceLength = sourceEndpoint === "before" ? delta.beforeLength : delta.afterLength;
  const sourceFrontier = sourceEndpoint === "before" ? delta.beforeFrontier : delta.afterFrontier;
  if (current.length !== sourceLength || currentFrontier !== sourceFrontier) {
    throw frontierMismatch();
  }
  const currentRank = indexSubjects(current);
  for (const participant of delta.participants) {
    const expectedRank = rankAt(participant, sourceEndpoint);
    if (expectedRank === void 0 && currentRank.has(participant.subject) || expectedRank !== void 0 && current[expectedRank] !== participant.subject) {
      throw frontierMismatch();
    }
  }
  const participantSubjects = new Set(
    delta.participants.map(({ subject }) => subject)
  );
  const backbone = current.filter(
    (subject) => !participantSubjects.has(subject)
  );
  const targetLength = endpoint === "before" ? delta.beforeLength : delta.afterLength;
  const target = new Array(targetLength);
  for (const participant of delta.participants) {
    const rank = rankAt(participant, endpoint);
    if (rank === void 0) {
      continue;
    }
    if (rank < 0 || rank >= targetLength || target[rank] !== void 0) {
      throw frontierMismatch();
    }
    target[rank] = participant.subject;
  }
  let backboneIndex = 0;
  for (let rank = 0; rank < target.length; rank += 1) {
    if (target[rank] !== void 0) {
      continue;
    }
    const subject = backbone[backboneIndex];
    if (subject === void 0) {
      throw frontierMismatch();
    }
    target[rank] = subject;
    backboneIndex += 1;
  }
  if (backboneIndex !== backbone.length) {
    throw frontierMismatch();
  }
  return target;
}
function lexicographicallySmallestCommonSubsequence(before, after) {
  if (before.length === 0 || after.length === 0) {
    return [];
  }
  const afterRank = indexSubjects(after);
  const mappedRanks = before.map((subject) => afterRank.get(subject));
  const suffixLengths = longestIncreasingSuffixLengths(mappedRanks);
  let maximumLength = 0;
  for (const length of suffixLengths) {
    maximumLength = Math.max(maximumLength, length);
  }
  const candidatesByLength = /* @__PURE__ */ new Map();
  for (let index = 0; index < before.length; index += 1) {
    const length = suffixLengths[index];
    const candidates = candidatesByLength.get(length) ?? [];
    candidates.push(index);
    candidatesByLength.set(length, candidates);
  }
  for (const candidates of candidatesByLength.values()) {
    candidates.sort((left, right) => before[left] - before[right]);
  }
  const result = [];
  let previousBeforeIndex = -1;
  let previousAfterRank = -1;
  for (let remaining = maximumLength; remaining > 0; remaining -= 1) {
    const candidates = candidatesByLength.get(remaining) ?? [];
    const selected = candidates.find(
      (index) => index > previousBeforeIndex && mappedRanks[index] > previousAfterRank
    );
    if (selected === void 0) {
      throw new Error("Unable to derive a canonical collection order backbone");
    }
    result.push(before[selected]);
    previousBeforeIndex = selected;
    previousAfterRank = mappedRanks[selected];
  }
  return result;
}
function applyStructuralEffect(collections, effect) {
  const collection = collections.get(effect.owner);
  if (!collection || typeof effect.subjectId !== "number") {
    throw new Error(
      `Structural effect has no collection target ${effect.owner}`
    );
  }
  const subject = effect.subjectId;
  if (effect.structural === "add") {
    if (collection.subjects.has(subject)) {
      throw new Error(
        `Subject ${subject} is already active in owner ${effect.owner}`
      );
    }
    const key2 = effect.after;
    if (typeof key2 !== "string" && typeof key2 !== "number") {
      throw new Error(`Restored subject ${subject} has no target key`);
    }
    collection.subjects.set(subject, {
      subject,
      key: key2,
      value: structuralValue(effect)
    });
    return;
  }
  const existing = collection.subjects.get(subject);
  if (!existing) {
    throw new Error(
      `Subject ${subject} is not active in owner ${effect.owner}`
    );
  }
  if (effect.structural === "remove") {
    if (existing.key !== effect.before) {
      throw new Error(`Subject ${subject} is not at its expected source key`);
    }
    collection.subjects.delete(subject);
    return;
  }
  if (existing.key !== effect.before) {
    throw new Error(`Subject ${subject} is not at its expected source key`);
  }
  const key = effect.after;
  if (typeof key !== "string" && typeof key !== "number") {
    throw new Error(`Rekeyed subject ${subject} has no target key`);
  }
  collection.subjects.set(subject, { ...existing, key });
}
function deriveStructuralTargetOrder(sourceOrder, subjects, effects) {
  if (effects.some((effect) => effect.turn !== void 0))
    return replayStructuralOrderByTurn(sourceOrder, subjects, effects);
  return applyTurnOrder(
    [...sourceOrder],
    effects,
    (subject) => subjects.has(subject)
  ).filter((subject) => subjects.has(subject));
}
function replayStructuralOrderByTurn(sourceOrder, subjects, effects) {
  let order = [...sourceOrder];
  const turns = /* @__PURE__ */ new Map();
  for (const effect of effects) {
    if (effect.structural !== "add" && effect.structural !== "remove" || typeof effect.subjectId !== "number")
      continue;
    let turn = turns.get(effect.turn);
    if (!turn) turns.set(effect.turn, turn = []);
    turn.push(effect);
  }
  for (const turn of turns.values()) {
    const removed = netRemovals(turn);
    order = applyTurnOrder(
      order,
      turn,
      (subject) => !removed.has(subject)
    ).filter((subject) => !removed.has(subject));
  }
  return order.filter((subject) => subjects.has(subject));
}
function netRemovals(turn) {
  const removed = /* @__PURE__ */ new Set();
  for (const effect of turn) {
    const subject = effect.subjectId;
    if (effect.structural === "remove") removed.add(subject);
    else if (effect.structural === "add") removed.delete(subject);
  }
  return removed;
}
function applyTurnOrder(order, effects, survives) {
  const additions = effects.filter(
    (effect) => effect.structural === "add" && typeof effect.subjectId === "number"
  );
  const added = new Set(additions.map((effect) => effect.subjectId));
  const next = order.filter((subject) => !added.has(subject));
  placeAdditions(next, additions, survives);
  return next;
}
function placeAdditions(order, additions, survives) {
  const pending2 = [...additions];
  const pendingSubjects = /* @__PURE__ */ new Map();
  for (const effect of pending2) {
    const subject = effect.subjectId;
    pendingSubjects.set(subject, (pendingSubjects.get(subject) ?? 0) + 1);
  }
  while (pending2.length > 0) {
    const waitsOnPending = (effect2) => {
      const context2 = effect2.structuralContext;
      return (context2?.kind === "add" || context2?.kind === "remove") && (context2.beforeSubject !== void 0 && pendingSubjects.has(context2.beforeSubject) || context2.afterSubject !== void 0 && pendingSubjects.has(context2.afterSubject));
    };
    const unblockedIndex = pending2.findIndex(
      (effect2) => !waitsOnPending(effect2)
    );
    const readyIndex = unblockedIndex >= 0 ? unblockedIndex : pending2.findIndex((effect2) => {
      const context2 = effect2.structuralContext;
      if (context2?.kind !== "add" && context2?.kind !== "remove") {
        return true;
      }
      const beforeLive = context2.beforeSubject !== void 0 && order.includes(context2.beforeSubject);
      const afterLive = context2.afterSubject !== void 0 && order.includes(context2.afterSubject);
      if (beforeLive || afterLive) {
        return true;
      }
      const hasNoAnchors = context2.beforeSubject === void 0 && context2.afterSubject === void 0;
      if (hasNoAnchors) {
        return true;
      }
      const anchorMayBecomeLive = context2.beforeSubject !== void 0 && pendingSubjects.has(context2.beforeSubject) || context2.afterSubject !== void 0 && pendingSubjects.has(context2.afterSubject);
      return !anchorMayBecomeLive;
    });
    if (readyIndex < 0) {
      if (!order.some(survives)) {
        appendAll(order, derivePendingAnchorOrder(pending2));
        pending2.length = 0;
        continue;
      }
      throw new Error("Collection structural target contains an anchor cycle");
    }
    const effect = pending2.splice(readyIndex, 1)[0];
    const subject = effect.subjectId;
    const remaining = (pendingSubjects.get(subject) ?? 1) - 1;
    if (remaining === 0) pendingSubjects.delete(subject);
    else pendingSubjects.set(subject, remaining);
    const context = effect.structuralContext;
    const beforeSubject = context?.kind === "add" || context?.kind === "remove" ? context.beforeSubject : void 0;
    const afterSubject = context?.kind === "add" || context?.kind === "remove" ? context.afterSubject : void 0;
    const afterIndex = afterSubject === void 0 ? -1 : order.indexOf(afterSubject);
    const beforeIndex = beforeSubject === void 0 ? -1 : order.indexOf(beforeSubject);
    if (beforeIndex >= 0 && afterIndex >= 0 && beforeIndex >= afterIndex) {
      throw new Error(
        "Collection structural target contains contradictory anchors"
      );
    }
    if (afterIndex >= 0) {
      order.splice(afterIndex, 0, subject);
      continue;
    }
    if (beforeIndex >= 0) {
      order.splice(beforeIndex + 1, 0, subject);
      continue;
    }
    if (beforeSubject === void 0 && afterSubject === void 0) {
      order.push(subject);
      continue;
    }
    throw new Error(
      "Collection structural target has no live placement anchor"
    );
  }
}
function derivePendingAnchorOrder(effects) {
  const subjects = effects.map((effect) => effect.subjectId);
  const subjectSet = new Set(subjects);
  const outgoing = new Map(
    subjects.map((subject) => [subject, /* @__PURE__ */ new Set()])
  );
  const indegree = new Map(subjects.map((subject) => [subject, 0]));
  const addEdge = (before, after) => {
    const edges = outgoing.get(before);
    if (!edges || edges.has(after)) {
      return;
    }
    edges.add(after);
    indegree.set(after, (indegree.get(after) ?? 0) + 1);
  };
  for (const effect of effects) {
    const subject = effect.subjectId;
    const context = effect.structuralContext;
    if (context?.kind !== "add" && context?.kind !== "remove") {
      continue;
    }
    if (context.beforeSubject !== void 0 && subjectSet.has(context.beforeSubject)) {
      addEdge(context.beforeSubject, subject);
    }
    if (context.afterSubject !== void 0 && subjectSet.has(context.afterSubject)) {
      addEdge(subject, context.afterSubject);
    }
  }
  const sourceRank = new Map(
    subjects.map((subject, index) => [subject, index])
  );
  const ready = subjects.filter((subject) => indegree.get(subject) === 0);
  const result = [];
  while (ready.length > 0) {
    ready.sort(
      (left, right) => (sourceRank.get(left) ?? 0) - (sourceRank.get(right) ?? 0)
    );
    const subject = ready.shift();
    result.push(subject);
    for (const after of outgoing.get(subject) ?? []) {
      const nextIndegree = (indegree.get(after) ?? 0) - 1;
      indegree.set(after, nextIndegree);
      if (nextIndegree === 0) {
        ready.push(after);
      }
    }
  }
  if (result.length !== subjects.length) {
    throw new Error("Collection structural target contains an anchor cycle");
  }
  return result;
}
function applyValueEffect(collections, scalars, effect) {
  if (typeof effect.subjectId !== "number") {
    scalars.set(effect.owner, effect.after);
    return;
  }
  const collection = collections.get(effect.owner);
  const subject = collection?.subjects.get(effect.subjectId);
  if (!collection || !subject) {
    throw new Error(
      `Value effect has no active subject ${String(
        effect.subjectId
      )} in owner ${effect.owner}`
    );
  }
  const fieldPath = effect.subjectFieldSegments ?? deriveSubjectFieldPath(effect.path, effect.ownerPath);
  collection.subjects.set(effect.subjectId, {
    ...subject,
    value: fieldPath.length === 0 ? effect.after : effect.fieldPresence?.after === false ? removeValueAtPath(subject.value, fieldPath) : setValueAtPath(subject.value, fieldPath, effect.after)
  });
}
function removeValueAtPath(value, path) {
  if (path.length === 0 || !isRecord(value)) return value;
  const [head, ...rest] = path;
  if (!Object.prototype.hasOwnProperty.call(value, head)) return value;
  if (rest.length === 0) {
    const { [head]: _removed, ...remaining } = value;
    return remaining;
  }
  return { ...value, [head]: removeValueAtPath(value[head], rest) };
}
function deriveSubjectFieldPath(path, ownerPath) {
  if (!path || !ownerPath || path === ownerPath || !path.startsWith(`${ownerPath}.`)) {
    throw new Error("Subject value effect has no collection-relative address");
  }
  const relative = path.slice(ownerPath.length + 1);
  const [, ...fieldPath] = relative.split(".");
  return fieldPath;
}
function structuralValue(effect) {
  const context = effect.structuralContext;
  return context?.kind === "add" || context?.kind === "remove" ? context.value : void 0;
}
function setValueAtPath(value, path, replacement) {
  if (path.length === 0) {
    return replacement;
  }
  const [head, ...rest] = path;
  const record = isRecord(value) ? value : {};
  return {
    ...record,
    [head]: setValueAtPath(record[head], rest, replacement)
  };
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function assertCollectionOrderMatchesSubjects(order, subjects) {
  if (order.length !== subjects.size || order.some((subject) => !subjects.has(subject))) {
    throw new Error("Collection order does not match active SubjectIds");
  }
}
function assertUniqueTargetKeys(subjects) {
  const keys = [...subjects.values()].map(({ key }) => key);
  if (new Set(keys).size !== keys.length) {
    throw new Error("Collection transition target contains duplicate keys");
  }
}
function longestIncreasingSuffixLengths(values) {
  const tree = new FenwickMaximum(values.length);
  const lengths = new Array(values.length);
  for (let index = values.length - 1; index >= 0; index -= 1) {
    const reversedRank = values.length - values[index];
    const length = 1 + tree.query(reversedRank - 1);
    lengths[index] = length;
    tree.update(reversedRank, length);
  }
  return lengths;
}
var FenwickMaximum = class {
  values;
  constructor(size) {
    this.values = new Array(size + 1).fill(0);
  }
  update(index, value) {
    for (let cursor = index; cursor < this.values.length; cursor += cursor & -cursor) {
      this.values[cursor] = Math.max(this.values[cursor], value);
    }
  }
  query(index) {
    let maximum = 0;
    for (let cursor = index; cursor > 0; cursor -= cursor & -cursor) {
      maximum = Math.max(maximum, this.values[cursor]);
    }
    return maximum;
  }
};
function indexSubjects(subjects) {
  return new Map(subjects.map((subject, rank) => [subject, rank]));
}
function assertUniqueSubjects(subjects) {
  if (subjects.some((subject) => !Number.isSafeInteger(subject) || subject <= 0)) {
    throw new Error("Collection order contains an invalid SubjectId");
  }
  if (new Set(subjects).size !== subjects.length) {
    throw new Error("Collection order contains duplicate SubjectIds");
  }
}
function sameSubjects(left, right) {
  return left.size === right.size && [...left].every((subject) => right.has(subject));
}
function rankAt(participant, endpoint) {
  return endpoint === "before" ? participant.beforeRank : participant.afterRank;
}
function frontierMismatch() {
  return new Error(
    "collection order frontier does not match the transition endpoint"
  );
}

// packages/kernel/src/lib/internals/causal-runtime/scoped-value-addressing.ts
function normalizeScopedValuePath(relativePath) {
  return relativePath === "values" ? "" : relativePath.startsWith("values.") ? relativePath.slice("values.".length) : relativePath;
}

// packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter.ts
var TREE_REALIZATION_DESCRIPTORS = Symbol.for(
  "SignalTree:TreeRealizationDescriptors"
);
var TREE_REALIZATION_PORT = Symbol.for("SignalTree:TreeRealizationPort");
var PreparedRealizationContext = class {
  constructor(scopeOf) {
    this.scopeOf = scopeOf;
  }
  subjects = /* @__PURE__ */ new Map();
  occupancy = /* @__PURE__ */ new Map();
  setOccupancy(scope, key, state2) {
    let entries = this.occupancy.get(scope);
    if (!entries) {
      entries = /* @__PURE__ */ new Map();
      this.occupancy.set(scope, entries);
    }
    entries.set(key, state2);
  }
  subjectsIn(scope) {
    let subjects = this.subjects.get(scope);
    if (!subjects) {
      subjects = /* @__PURE__ */ new Map();
      this.subjects.set(scope, subjects);
    }
    return subjects;
  }
  rememberRestoredSubject(effect, subjectId, collectionPath, key, value) {
    const scope = this.scopeOf(effect);
    if (!scope) return;
    this.subjectsIn(scope).set(subjectId, {
      collectionPath,
      scope,
      subjectId,
      reachable: true,
      currentKey: key,
      value
    });
    this.setOccupancy(scope, key, subjectId);
  }
  rememberRekeyedSubject(effect, subjectId, key) {
    const existing = this.resolveSubject(effect, subjectId);
    if (!existing) {
      return;
    }
    this.setOccupancy(
      existing.scope,
      existing.currentKey,
      "vacant"
    );
    this.setOccupancy(existing.scope, key, subjectId);
    this.subjectsIn(existing.scope).set(subjectId, {
      ...existing,
      reachable: true,
      currentKey: key
    });
  }
  rememberRemovedSubject(effect, subjectId, collectionPath, key, value) {
    const scope = this.scopeOf(effect);
    if (!scope) return;
    const existing = this.subjectsIn(scope).get(subjectId);
    const currentValue = existing?.value ?? value;
    this.setOccupancy(scope, existing?.currentKey ?? key, "vacant");
    this.subjectsIn(scope).set(subjectId, {
      collectionPath,
      scope,
      subjectId,
      reachable: false,
      currentKey: void 0,
      value: currentValue
    });
  }
  resolveSubject(effect, subjectId) {
    const scope = this.scopeOf(effect);
    return scope === void 0 ? void 0 : this.subjects.get(scope)?.get(subjectId);
  }
  resolveOccupancy(scope, key) {
    return this.occupancy.get(scope)?.get(key);
  }
};
function isRealizationAttachmentHost(node) {
  return isTraversableNode(node) || typeof node === "function";
}
function rememberTreeRealizationDescriptor(options) {
  const owner = options.positionIds?.[0];
  if (owner === void 0) {
    return;
  }
  const existing = options.descriptors.get(owner);
  const structuralEffects = existing?.structuralEffects instanceof Map ? existing.structuralEffects : new Map(existing?.structuralEffects ?? []);
  const structuralEffectBySubject = existing?.structuralEffectBySubject instanceof Map ? existing.structuralEffectBySubject : new Map(existing?.structuralEffectBySubject ?? []);
  const subjectDescriptors = existing?.subjectDescriptors instanceof Map ? existing.subjectDescriptors : new Map(existing?.subjectDescriptors ?? []);
  if (options.meta?.structuralEffect) {
    structuralEffects.set(
      toStructuralEffectKey(options.meta.structuralEffect),
      options.meta.structuralEffect
    );
    if (options.meta.structuralEffect.kind === "add" || options.meta.structuralEffect.kind === "remove") {
      structuralEffectBySubject.set(
        String(options.meta.structuralEffect.subject),
        options.meta.structuralEffect
      );
    }
  }
  const subjectId = options.subjectIds?.[0];
  const ownerPath = options.ownerPath ?? options.path;
  const { collectionPath, fieldPathFromRow } = deriveRealizationAddress(
    options.path,
    ownerPath,
    subjectId,
    options.meta?.structuralEffect,
    options.registry?.collectionPathFor(owner)
  );
  if (typeof subjectId === "number") {
    const subjectKey = String(subjectId);
    const existingSubjectDescriptor = subjectDescriptors.get(subjectKey);
    if (!existingSubjectDescriptor || existingSubjectDescriptor.path !== options.path || existingSubjectDescriptor.ownerPath !== ownerPath || existingSubjectDescriptor.collectionPath !== collectionPath || existingSubjectDescriptor.fieldPathFromRow !== fieldPathFromRow) {
      subjectDescriptors.set(subjectKey, {
        path: options.path,
        ownerPath,
        collectionPath,
        fieldPathFromRow
      });
    }
  }
  const nextPath = existing?.path ?? options.path;
  const nextOwnerPath = existing?.ownerPath ?? ownerPath;
  const nextCollectionPath = existing?.collectionPath ?? collectionPath;
  const nextFieldPathFromRow = existing?.fieldPathFromRow ?? fieldPathFromRow;
  if (existing?.path === nextPath && existing?.ownerPath === nextOwnerPath && existing?.collectionPath === nextCollectionPath && existing?.fieldPathFromRow === nextFieldPathFromRow && existing?.structuralEffects === structuralEffects && existing?.structuralEffectBySubject === structuralEffectBySubject && existing?.subjectDescriptors === subjectDescriptors) {
    return;
  }
  options.descriptors.set(owner, {
    path: nextPath,
    ownerPath: nextOwnerPath,
    collectionPath: nextCollectionPath,
    fieldPathFromRow: nextFieldPathFromRow,
    structuralEffects,
    structuralEffectBySubject,
    subjectDescriptors
  });
}
function createTreeRealizationAdapter(options) {
  const scalarSlotRuntime = getTreeScalarSlotRuntime(options.tree) ?? getTreeScalarSlotRuntime(options.tree.$);
  const physicalCommitClock = getPhysicalCommitClock(options.tree) ?? getPhysicalCommitClock(options.tree.$);
  const structuralOwnerPaths = indexStructuralOwnerPaths(options.tree.$);
  return {
    prepareOrdinaryEffects(effects) {
      const byOwner = new Map(effects.map((effect) => [effect.owner, effect]));
      return prepareOrdinaryRealization(effects, (owner, subject) => {
        const effect = byOwner.get(owner);
        return effect ? resolveCollectionNode(
          options.tree,
          options.descriptors.get(owner),
          structuralOwnerPaths,
          effect
        )?.__findKeyBySubjectId?.(subject) : void 0;
      }).physical;
    },
    validateEffects(effects) {
      const preparedContext = buildPreparedRealizationContext(
        options.tree,
        options.descriptors,
        structuralOwnerPaths,
        scalarSlotRuntime,
        effects
      );
      if (!preparedContext) {
        return { kind: "structural-drift" };
      }
      return void 0;
    },
    applyAtomically(effects) {
      const memberTargets = /* @__PURE__ */ new Map();
      const authoredValueEffects = [];
      for (const effect of effects) {
        if (effect.plainBranchMembership) {
          memberTargets.delete(effect.owner);
          memberTargets.set(effect.owner, {
            present: effect.plainBranchMembership.after,
            value: effect.after,
            ...effect.turn === void 0 ? {} : { turn: effect.turn }
          });
        } else {
          authoredValueEffects.push(effect);
        }
      }
      const members = memberTargets.size ? preparePlainBranchMembers(options.tree.$, memberTargets) : void 0;
      const staged = members?.staged;
      const valueEffects = staged?.size ? authoredValueEffects.filter(
        (effect) => effect.turn === void 0 || effect.structural !== void 0 || typeof effect.subjectId === "number" || (staged.get(effect.owner) ?? effect.turn) <= effect.turn
      ) : authoredValueEffects;
      const apply = () => {
        const heterogeneousFrame = valueEffects.length ? planHeterogeneousFrame(
          options.tree,
          options.descriptors,
          structuralOwnerPaths,
          scalarSlotRuntime,
          physicalCommitClock,
          valueEffects,
          ordinaryRealization(effects)?.ordinary
        ) : void 0;
        let scalarFrame = !heterogeneousFrame && valueEffects.length ? planScalarFrame(
          options.tree,
          options.descriptors,
          structuralOwnerPaths,
          scalarSlotRuntime,
          valueEffects
        ) : void 0;
        let perEffect = heterogeneousFrame || scalarFrame ? [] : valueEffects;
        if (perEffect.length) {
          const slotScalars = valueEffects.filter(
            (effect) => effect.structural === void 0 && effect.subjectId === void 0 && effect.subjectFieldSegments === void 0 && !hasInlineScopedAddress(effect) && !hasInlineSubjectAddress(effect) && scalarSlotRuntime?.resolveScalarSlot(effect.owner) !== void 0
          );
          scalarFrame = slotScalars.length ? planScalarFrame(
            options.tree,
            options.descriptors,
            structuralOwnerPaths,
            scalarSlotRuntime,
            slotScalars
          ) : void 0;
          if (scalarFrame) {
            const framed = new Set(slotScalars);
            perEffect = valueEffects.filter((effect) => !framed.has(effect));
          }
        }
        members?.install();
        if (members && valueEffects.length === 0)
          physicalCommitClock?.advance();
        if (heterogeneousFrame) {
          heterogeneousFrame.commit();
        } else {
          scalarFrame?.commit();
          for (const effect of perEffect) {
            applyEffect(
              options.tree,
              options.descriptors,
              structuralOwnerPaths,
              scalarSlotRuntime,
              effect
            );
          }
        }
        members?.publish();
      };
      const releaseMembership = holdEntityMembershipDelivery(options.tree.$);
      try {
        applyInInvalidationGroup(options.tree.$, apply);
      } finally {
        releaseMembership();
      }
    }
  };
}
function defineTreeRealizationDescriptors(node, descriptors) {
  Object.defineProperty(node, TREE_REALIZATION_DESCRIPTORS, {
    value: descriptors,
    enumerable: false,
    configurable: true
  });
}
function getTreeRealizationDescriptors(node) {
  if (!isRealizationAttachmentHost(node)) {
    return void 0;
  }
  return node[TREE_REALIZATION_DESCRIPTORS];
}
function defineTreeRealizationPort(node, port) {
  Object.defineProperty(node, TREE_REALIZATION_PORT, {
    value: port,
    enumerable: false,
    configurable: true
  });
}
function getTreeRealizationPort(node) {
  if (!isRealizationAttachmentHost(node)) {
    return void 0;
  }
  return node[TREE_REALIZATION_PORT];
}
function preparePointRealization(tree, effects) {
  if (!effects.length || !effects.some((effect) => typeof effect.subjectId === "number"))
    return void 0;
  const descriptors = getTreeRealizationDescriptors(tree.$);
  const slots = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
  const clock = getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree);
  if (!descriptors || !slots || !clock) return void 0;
  const baseRevision = clock.revision();
  const owners = effects.some(
    (effect) => effect.structural || effect.plainBranchMembership
  ) ? indexStructuralOwnerPaths(tree.$) : indexPointOwnerPaths(tree.$, effects);
  const memberTargets = /* @__PURE__ */ new Map();
  for (const effect of effects)
    if (effect.plainBranchMembership) {
      memberTargets.delete(effect.owner);
      memberTargets.set(effect.owner, {
        present: effect.plainBranchMembership.after,
        value: effect.after,
        ...effect.turn === void 0 ? {} : { turn: effect.turn }
      });
    }
  if (effects.some((effect) => effect.structural)) {
    const scalarEffects2 = effects.filter(
      (effect) => !effect.plainBranchMembership && !effect.structural && typeof effect.subjectId !== "number"
    );
    const members2 = memberTargets.size ? preparePlainBranchMembers(tree.$, memberTargets, scalarEffects2) : void 0;
    const entityEffects = effects.filter(
      (effect) => !effect.plainBranchMembership && (!members2 || effect.structural || typeof effect.subjectId === "number")
    );
    const heterogeneous = planHeterogeneousFrame(
      tree,
      descriptors,
      owners,
      slots,
      clock,
      entityEffects,
      ordinaryRealization(effects)?.ordinary
    );
    if (!heterogeneous) return void 0;
    if (clock.revision() !== baseRevision)
      throw new Error("Point realization preparation reentered installation");
    let installed2 = false;
    return {
      install() {
        if (installed2 || clock.revision() !== baseRevision)
          throw new Error("Point realization base revision is stale");
        members2?.install();
        heterogeneous.install();
        installed2 = true;
      },
      publish() {
        if (!installed2)
          throw new Error("Point realization published before installation");
        let failed = false;
        let firstError;
        const run = (fn) => {
          try {
            fn();
          } catch (error) {
            if (!failed) {
              failed = true;
              firstError = error;
            }
          }
        };
        run(() => heterogeneous.invalidate());
        if (members2) run(() => members2.invalidate());
        if (members2) run(() => members2.publish());
        run(() => heterogeneous.publish());
        if (failed) throw firstError;
      }
    };
  }
  const pointPaths = /* @__PURE__ */ new Map();
  for (const effect of effects) {
    if (effect.plainBranchMembership || typeof effect.subjectId !== "number")
      continue;
    const path = resolveSubjectFieldPath(
      descriptors.get(effect.owner),
      effect,
      getPositionRegistry(tree.$)
    );
    if (path === void 0 || path.length > 1) return void 0;
    pointPaths.set(effect, path);
  }
  const rows = /* @__PURE__ */ new Map();
  const scalarEffects = [];
  const frame = slots.beginFrame();
  for (const effect of effects) {
    if (effect.plainBranchMembership) continue;
    if (typeof effect.subjectId !== "number") {
      if (effect.subjectFieldSegments !== void 0 || hasInlineScopedAddress(effect) || hasInlineSubjectAddress(effect))
        return void 0;
      const slot = slots.resolveScalarSlot(effect.owner);
      if (slot === void 0) return void 0;
      frame.set(slot, effect.after);
      scalarEffects.push(effect);
      continue;
    }
    const descriptor = descriptors.get(effect.owner);
    const collection = resolveCollectionNode(tree, descriptor, owners, effect);
    if (!collection?.__preparePointValues) return void 0;
    const key = collection.__findKeyBySubjectId?.(effect.subjectId);
    if (key === void 0) return void 0;
    let bySubject = rows.get(collection);
    if (!bySubject) rows.set(collection, bySubject = /* @__PURE__ */ new Map());
    let row = bySubject.get(effect.subjectId);
    if (!row) {
      row = {
        subjectId: effect.subjectId,
        key,
        value: deepClone(snapshotCollectionEntityValue(collection, key)),
        edits: []
      };
      bySubject.set(effect.subjectId, row);
    }
    const path = pointPaths.get(effect);
    if (path === void 0) return void 0;
    const after = deepClone(effect.after);
    const present = effect.fieldPresence?.after !== false;
    if (path.length === 0) row.edits.push({ kind: "row", value: after });
    else
      row.edits.push({ kind: "field", field: path[0], present, value: after });
    if (path.length === 0) row.value = deepClone(after);
    else if (!present) row.value = withoutFieldAtSegments(row.value, path);
    else assignPreparedSubjectValue(row.value, path, deepClone(after));
  }
  const members = memberTargets.size ? preparePlainBranchMembers(tree.$, memberTargets, scalarEffects) : void 0;
  const collections = [...rows].map(([collection, subjects]) => {
    const prepare = collection.__preparePointValues;
    if (!prepare)
      throw new Error("Point realization preparation is unavailable");
    return prepare.call(collection, [...subjects.values()]);
  });
  if (!frame.prepareCommit) return void 0;
  const installScalars = members ? () => void 0 : frame.prepareCommit({ advanceRevision: false, publish: false });
  if (clock.revision() !== baseRevision)
    throw new Error("Point realization preparation reentered installation");
  let result;
  let installed = false;
  return {
    install() {
      if (installed || clock.revision() !== baseRevision)
        throw new Error("Point realization base revision is stale");
      if (members) members.install();
      else result = installScalars();
      for (const collection of collections) collection.install();
      clock.advance();
      installed = true;
    },
    publish() {
      const installedScalars = result;
      if (!installed || !members && !installedScalars)
        throw new Error("Point realization published before installation");
      let failed = false;
      let firstError;
      const run = (fn) => {
        try {
          fn();
        } catch (error) {
          if (!failed) {
            failed = true;
            firstError = error;
          }
        }
      };
      for (const collection of collections) run(() => collection.invalidate());
      if (members) run(() => members.invalidate());
      else if (installedScalars)
        run(() => slots.publishPrepared(installedScalars));
      if (members) run(() => members.publish());
      for (const collection of collections) run(() => collection.publish());
      for (const effect of members ? [] : scalarEffects)
        run(() => {
          const descriptor = descriptors.get(effect.owner);
          const path = resolveNotifyPath(tree, descriptor, owners, effect);
          if (path)
            getPathNotifier().notify(
              path,
              effect.after,
              effect.before,
              descriptor?.ownerPath ?? path,
              void 0,
              [effect.owner],
              {
                ...getActiveWriteContext() ?? {},
                intent: "system",
                participation: "realized"
              }
            );
        });
      run(() => markOwnerInvalidatedFrom(tree));
      if (failed) throw firstError;
    }
  };
}
function planHeterogeneousFrame(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, physicalCommitClock, effects, ordinaryEffects) {
  if (effects.length === 0 || !effects.some(
    (effect) => effect.structural === "rekey" || effect.structural === "add" || effect.structural === "remove"
  ) || effects.some(
    (effect) => effect.structural && effect.structural !== "rekey" && effect.structural !== "add" && effect.structural !== "remove"
  )) {
    return void 0;
  }
  const scalarEffects = effects.filter((effect) => !effect.structural);
  const preparedContext = buildPreparedRealizationContext(
    tree,
    descriptors,
    structuralOwnerPaths,
    scalarSlotRuntime,
    effects
  );
  if (!preparedContext) {
    return void 0;
  }
  const removeKeysByEffect = /* @__PURE__ */ new Map();
  const planningPreparedContext = new PreparedRealizationContext(
    preparedSubjectScope(tree, descriptors, structuralOwnerPaths)
  );
  for (const effect of effects) {
    const removeEffect = effect.structural === "remove" && typeof effect.subjectId === "number" ? effect : void 0;
    if (removeEffect) {
      const descriptor = descriptors.get(effect.owner);
      const collectionNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        removeEffect
      );
      if (!collectionNode) {
        return void 0;
      }
      const effectiveRemoveKey = resolveEffectiveRemoveKey(
        collectionNode,
        planningPreparedContext,
        removeEffect
      );
      if (effectiveRemoveKey === void 0) {
        return void 0;
      }
      removeKeysByEffect.set(removeEffect, effectiveRemoveKey);
    }
    updatePreparedRealizationContext(
      tree,
      descriptors,
      structuralOwnerPaths,
      planningPreparedContext,
      effect
    );
  }
  const vacatingKeysByOwner = /* @__PURE__ */ new Map();
  for (const [removeEffect, removedKey] of removeKeysByEffect) {
    let keys = vacatingKeysByOwner.get(removeEffect.owner);
    if (!keys) {
      keys = /* @__PURE__ */ new Set();
      vacatingKeysByOwner.set(removeEffect.owner, keys);
    }
    keys.add(removedKey);
  }
  const preparedSubjectScalarEffects = scalarEffects.filter(
    (effect) => isPreparedSubjectScalarEffect(effect, preparedContext)
  );
  const framedScalarEffects = scalarEffects.filter(
    (effect) => !isPreparedSubjectScalarEffect(effect, preparedContext)
  );
  const rekeyEffects = effects.filter(
    (effect) => effect.structural === "rekey"
  );
  const restoreEffects = effects.filter(
    (effect) => effect.structural === "add" && typeof effect.subjectId === "number"
  );
  const placementEffects = orderPhysicalPlacements(
    tree,
    descriptors,
    structuralOwnerPaths,
    effects
  ).filter(
    (effect) => effect.structural === "add" || realizationPlacement(effect) !== void 0
  );
  const baseRevision = scalarSlotRuntime?.revision();
  const scalarFrameRuntime = framedScalarEffects.length > 0 ? scalarSlotRuntime : void 0;
  const scalarFrame = framedScalarEffects.length > 0 ? scalarFrameRuntime?.beginFrame() : void 0;
  if (framedScalarEffects.length > 0 && (!scalarFrameRuntime || !scalarFrame)) {
    return void 0;
  }
  const resolvedScalarFrameRuntime = scalarFrameRuntime;
  const plannedRestores = [];
  const plannedFreshAdds = [];
  const plannedRekeys = [];
  const plannedRemoves = [];
  const placementPlans = /* @__PURE__ */ new Map();
  for (const effect of restoreEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    const structuralEffect = getStructuralAddEffect(descriptor, effect);
    const collectionPath = resolveCollectionPath(
      descriptor,
      structuralOwnerPaths,
      effect
    );
    const subjectInventory = collectionNode?.__inspectSubjectResources?.(
      effect.subjectId
    );
    const isFreshSubject = subjectInventory === void 0;
    if (!collectionNode || !structuralEffect || !collectionPath || (isFreshSubject ? typeof collectionNode.__planFreshAdd !== "function" : typeof collectionNode.__planRestore !== "function")) {
      scalarFrame?.discard();
      return void 0;
    }
    const preparedSubject = preparedContext.resolveSubject(
      effect,
      effect.subjectId
    );
    if (!preparedSubject) {
      scalarFrame?.discard();
      return void 0;
    }
    if (isFreshSubject) {
      const planFreshAdd = collectionNode.__planFreshAdd;
      if (typeof planFreshAdd !== "function") {
        scalarFrame?.discard();
        return void 0;
      }
      plannedFreshAdds.push({
        effect,
        plan: planFreshAdd(
          effect.after,
          preparedSubject.value,
          effect.subjectId
        )
      });
      continue;
    }
    const planRestore = collectionNode.__planRestore;
    if (typeof planRestore !== "function") {
      scalarFrame?.discard();
      return void 0;
    }
    plannedRestores.push({
      effect,
      plan: planRestore(
        effect.after,
        preparedSubject.value,
        effect.subjectId,
        structuralEffect.beforeSubject,
        structuralEffect.afterSubject,
        vacatingKeysByOwner.get(effect.owner)
      )
    });
  }
  for (const effect of framedScalarEffects) {
    if (!resolvedScalarFrameRuntime) {
      scalarFrame?.discard();
      return void 0;
    }
    const slotIndex = resolvedScalarFrameRuntime.resolveScalarSlot(
      effect.owner
    );
    if (slotIndex === void 0) {
      scalarFrame?.discard();
      return void 0;
    }
    scalarFrame?.set(slotIndex, effect.after);
  }
  for (const effect of rekeyEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    if (!collectionNode || typeof collectionNode.__planRekey !== "function" && typeof collectionNode.__planPreparedRekey !== "function") {
      scalarFrame?.discard();
      return void 0;
    }
    const preparedSubject = typeof effect.subjectId === "number" ? preparedContext.resolveSubject(effect, effect.subjectId) : void 0;
    const plan = preparedSubject && typeof collectionNode.__planPreparedRekey === "function" ? collectionNode.__planPreparedRekey(
      effect.before,
      effect.after,
      effect.subjectId,
      preparedSubject.value,
      realizationPlacement(effect)?.structuralContext
    ) : typeof collectionNode.__planRekey === "function" ? collectionNode.__planRekey(
      effect.before,
      effect.after
    ) : void 0;
    if (!plan) {
      scalarFrame?.discard();
      return void 0;
    }
    plannedRekeys.push({
      effect,
      plan
    });
    if (typeof effect.subjectId === "number") {
      preparedContext.rememberRekeyedSubject(
        effect,
        effect.subjectId,
        effect.after
      );
    }
  }
  const removeEffects = effects.filter(
    (effect) => effect.structural === "remove" && typeof effect.subjectId === "number"
  );
  for (const effect of removeEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    if (!collectionNode || typeof collectionNode.__planRemove !== "function") {
      scalarFrame?.discard();
      return void 0;
    }
    const effectiveRemoveKey = removeKeysByEffect.get(effect);
    if (effectiveRemoveKey === void 0) {
      scalarFrame?.discard();
      return void 0;
    }
    plannedRemoves.push({
      effect,
      plan: collectionNode.__planRemove(effectiveRemoveKey, effect.subjectId)
    });
  }
  for (const { effect, plan } of [...plannedFreshAdds, ...plannedRestores])
    placementPlans.set(effect, plan);
  for (const { effect, plan } of plannedRekeys)
    if (realizationPlacement(effect)) placementPlans.set(effect, plan);
  const ordinaryPlans = /* @__PURE__ */ new Map();
  if (ordinaryEffects) {
    const groups = /* @__PURE__ */ new Map();
    for (const effect of ordinaryEffects) {
      if (typeof effect.subjectId !== "number") continue;
      let group = groups.get(effect.owner);
      if (!group) groups.set(effect.owner, group = []);
      group.push(effect);
    }
    for (const [owner, group] of groups) {
      const node = resolveCollectionNode(
        tree,
        descriptors.get(owner),
        structuralOwnerPaths,
        group[0]
      );
      if (!node?.__prepareOrdinaryRealization)
        throw new Error("Ordinary realization binding is unavailable");
      const physicalGroup = [
        ...removeEffects,
        ...placementEffects,
        ...plannedRekeys.filter(({ effect }) => !realizationPlacement(effect)).map(({ effect }) => effect)
      ].filter((effect) => effect.owner === owner);
      ordinaryPlans.set(
        owner,
        node.__prepareOrdinaryRealization(group, void 0, physicalGroup)
      );
    }
  }
  const publicationMeta = (effect) => {
    const meta = {
      ...getActiveWriteContext() ?? {},
      intent: "system",
      participation: "realized"
    };
    const plan = ordinaryPlans.get(effect.owner);
    return plan ? withSelectedEntityDisposition(
      meta,
      plan.changes.filter((change) => change.subject === effect.subjectId)
    ) : meta;
  };
  let scalarCommitResult;
  const install = () => {
    if (scalarFrame && physicalCommitClock && physicalCommitClock.revision() !== baseRevision) {
      throw new Error("Heterogeneous realization base revision is stale.");
    }
    scalarCommitResult = scalarFrame?.commit({
      advanceRevision: false,
      publish: false
    });
    for (const { plan } of plannedRemoves) {
      plan.commit({ advancePhysicalRevision: false });
    }
    for (const effect of placementEffects)
      placementPlans.get(effect)?.commit({ advancePhysicalRevision: false });
    for (const { effect, plan } of plannedRekeys) {
      if (!realizationPlacement(effect))
        plan.commit({ advancePhysicalRevision: false });
    }
    for (const plan of ordinaryPlans.values()) plan.install();
    physicalCommitClock?.advance();
  };
  const invalidate = () => {
    if (scalarCommitResult && scalarSlotRuntime) {
      scalarSlotRuntime.publishPrepared(scalarCommitResult);
    }
  };
  const publish = () => {
    let failed = false;
    let firstError;
    const run = (fn) => {
      try {
        fn();
      } catch (error) {
        if (!failed) {
          failed = true;
          firstError = error;
        }
      }
    };
    for (const { plan, effect } of plannedRemoves) {
      run(() => plan.publish(publicationMeta(effect)));
    }
    for (const { plan, effect } of plannedRestores) {
      run(() => plan.publish(publicationMeta(effect)));
    }
    for (const { plan, effect } of plannedFreshAdds) {
      run(() => plan.publish(publicationMeta(effect)));
    }
    for (const { plan, effect } of plannedRekeys) {
      run(() => plan.publish(publicationMeta(effect)));
    }
    for (const effect of [
      ...preparedSubjectScalarEffects,
      ...framedScalarEffects
    ]) {
      const descriptor = descriptors.get(effect.owner);
      const notifyPath = resolveNotifyPath(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!notifyPath) {
        continue;
      }
      run(
        () => getPathNotifier().notify(
          notifyPath,
          effect.after,
          effect.before,
          descriptor?.ownerPath ?? notifyPath,
          typeof effect.subjectId === "number" ? [effect.subjectId] : void 0,
          [effect.owner],
          {
            ...getActiveWriteContext() ?? {},
            intent: "system",
            participation: "realized"
          }
        )
      );
    }
    run(() => markOwnerInvalidatedFrom(tree));
    if (failed) throw firstError;
  };
  return {
    install,
    invalidate,
    publish,
    commit() {
      const commitAndPublish = () => {
        install();
        invalidate();
        publish();
      };
      const locations = getLocationRuntime(tree.$);
      if (locations) locations.runInvalidationGroup(commitAndPublish);
      else if (scalarSlotRuntime)
        scalarSlotRuntime.runInvalidationGroup(commitAndPublish);
      else commitAndPublish();
    }
  };
}
function planScalarFrame(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effects) {
  void tree;
  void descriptors;
  void structuralOwnerPaths;
  if (effects.length === 0 || effects.some(
    (effect) => effect.structural || effect.subjectFieldSegments !== void 0 || hasInlineScopedAddress(effect) || hasInlineSubjectAddress(effect)
  )) {
    return void 0;
  }
  if (!scalarSlotRuntime) {
    return void 0;
  }
  const frame = scalarSlotRuntime.beginFrame();
  for (const effect of effects) {
    const slotIndex = scalarSlotRuntime.resolveScalarSlot(effect.owner);
    if (slotIndex === void 0) {
      return void 0;
    }
    frame.set(slotIndex, effect.after);
  }
  return {
    commit() {
      frame.commit();
      for (const effect of effects) {
        const descriptor = descriptors.get(effect.owner);
        const notifyPath = resolveNotifyPath(
          tree,
          descriptor,
          structuralOwnerPaths,
          effect
        );
        if (!notifyPath) {
          continue;
        }
        getPathNotifier().notify(
          notifyPath,
          effect.after,
          effect.before,
          descriptor?.ownerPath ?? notifyPath,
          typeof effect.subjectId === "number" ? [effect.subjectId] : void 0,
          [effect.owner],
          {
            ...getActiveWriteContext() ?? {},
            intent: "system",
            participation: "realized"
          }
        );
      }
    }
  };
}
function canApplyEffect(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effect, preparedContext) {
  if (effect.plainBranchMembership)
    return canRealizePlainBranchMember(tree.$, effect.owner);
  const descriptor = descriptors.get(effect.owner);
  if (!descriptor && !effect.structural && effect.subjectFieldSegments === void 0 && !scalarSlotRuntime?.resolveScalarLeaf(effect.owner) && !hasInlineSubjectAddress(effect) && !hasInlineScopedAddress(effect)) {
    return false;
  }
  if (!effect.structural) {
    if (canResolvePreparedSubjectTarget(
      descriptor,
      effect,
      preparedContext,
      getPositionRegistry(tree.$)
    )) {
      return true;
    }
    const target = resolveLiveScalarNode(
      tree,
      descriptor,
      scalarSlotRuntime,
      effect,
      structuralOwnerPaths
    );
    return isWritableLeaf(target) || isWritableEntityNode(target);
  }
  const ownerNode = resolveCollectionNode(
    tree,
    descriptor,
    structuralOwnerPaths,
    effect
  );
  if (!ownerNode) {
    return false;
  }
  const currentSubjectKey = typeof effect.subjectId === "number" ? resolvePreparedOrLiveSubjectKey(
    ownerNode,
    preparedContext,
    effect,
    effect.subjectId
  ) : void 0;
  const destinationOccupied = effect.structural === "rekey" || effect.structural === "add" ? isCollectionKeyOccupied(
    ownerNode,
    effect.after,
    preparedContext
  ) : false;
  switch (effect.structural) {
    case "remove": {
      const removeEffect = typeof effect.subjectId === "number" ? effect : void 0;
      return (removeEffect ? resolveEffectiveRemoveKey(
        ownerNode,
        preparedContext,
        removeEffect
      ) !== void 0 : hasCollectionKey(ownerNode, effect.before)) && (typeof effect.subjectId !== "number" || currentSubjectKey !== void 0);
    }
    case "rekey":
      return (typeof effect.subjectId === "number" ? currentSubjectKey === effect.before : hasCollectionKey(ownerNode, effect.before)) && (typeof effect.subjectId !== "number" || currentSubjectKey === effect.before) && (!destinationOccupied || realizationPlacement(effect) !== void 0 && currentSubjectKey === effect.after);
    case "add": {
      if (typeof effect.subjectId !== "number" || typeof ownerNode.__restoreOne !== "function" || destinationOccupied || currentSubjectKey !== void 0) {
        return false;
      }
      return getStructuralAddEffect(descriptor, effect) !== void 0;
    }
  }
}
function applyEffect(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effect) {
  const descriptor = descriptors.get(effect.owner);
  if (!descriptor && !effect.structural && effect.subjectFieldSegments === void 0 && !scalarSlotRuntime?.resolveScalarLeaf(effect.owner) && !hasInlineSubjectAddress(effect) && !hasInlineScopedAddress(effect)) {
    throw new Error(
      `Missing live descriptor for owner ${String(effect.owner)}`
    );
  }
  withWriteContext(
    {
      ...getActiveWriteContext() ?? {},
      intent: "system",
      participation: "realized"
    },
    () => {
      if (!effect.structural && effect.fieldPresence?.after === false && typeof effect.subjectId === "number" && effect.subjectFieldSegments?.length) {
        const row = resolveCurrentSubjectTarget(
          tree,
          descriptor,
          effect.subjectId,
          { ...effect, subjectFieldSegments: [] },
          structuralOwnerPaths
        );
        if (isWritableEntityNode(row)) {
          const read2 = row;
          row(withoutFieldAtSegments(read2(), effect.subjectFieldSegments));
          return;
        }
      }
      if (!effect.structural) {
        const target = resolveLiveScalarNode(
          tree,
          descriptor,
          scalarSlotRuntime,
          effect,
          structuralOwnerPaths
        );
        if (isWritableLeaf(target)) {
          target.set(effect.after);
          return;
        }
        if (isWritableEntityNode(target)) {
          target(effect.after);
          return;
        }
        if (!isWritableLeaf(target)) {
          throw new Error(
            `Missing live leaf for owner ${String(effect.owner)}`
          );
        }
        return;
      }
      const ownerNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!ownerNode) {
        throw new Error(`Missing structural owner for ${String(effect.owner)}`);
      }
      switch (effect.structural) {
        case "rekey":
          ownerNode.changeId(
            effect.before,
            effect.after
          );
          return;
        case "remove": {
          const removeEffect = typeof effect.subjectId === "number" ? effect : void 0;
          const effectiveRemoveKey = removeEffect ? resolveEffectiveRemoveKey(ownerNode, void 0, removeEffect) : effect.before;
          if (effectiveRemoveKey === void 0) {
            throw new Error(
              `Missing live structural subject for owner ${String(
                effect.owner
              )}`
            );
          }
          ownerNode.removeOne(effectiveRemoveKey);
          return;
        }
        case "add": {
          const structuralEffect = getStructuralAddEffect(descriptor, effect);
          if (!structuralEffect) {
            throw new Error(
              `Missing structural restore metadata for owner ${String(
                effect.owner
              )}`
            );
          }
          ownerNode.__restoreOne?.(
            effect.after,
            structuralEffect.value,
            effect.subjectId,
            structuralEffect.beforeSubject,
            structuralEffect.afterSubject
          );
          return;
        }
      }
    }
  );
}
function resolveLiveScalarNode(tree, descriptor, scalarSlotRuntime, effect, structuralOwnerPaths) {
  if (typeof effect.subjectId === "number") {
    return resolveCurrentSubjectTarget(
      tree,
      descriptor,
      effect.subjectId,
      effect,
      structuralOwnerPaths
    );
  }
  if (hasInlineScopedAddress(effect)) {
    return resolveCurrentScopedTarget(tree, descriptor, effect);
  }
  const directLeaf = scalarSlotRuntime?.resolveScalarLeaf(effect.owner);
  if (directLeaf) {
    return directLeaf;
  }
  if (!descriptor?.path) {
    return void 0;
  }
  const pathNode = resolveNodeAtPath(
    tree.$,
    descriptor.path
  );
  return isWritableLeaf(pathNode) || isWritableEntityNode(pathNode) ? pathNode : void 0;
}
function canResolvePreparedSubjectTarget(descriptor, effect, preparedContext, registry) {
  if (typeof effect.subjectId !== "number") {
    return false;
  }
  const preparedSubject = preparedContext?.resolveSubject(
    effect,
    effect.subjectId
  );
  if (!preparedSubject) {
    return false;
  }
  if (!preparedSubject.reachable) {
    return false;
  }
  const fieldPathFromRow = resolveSubjectFieldPath(
    descriptor,
    effect,
    registry
  );
  if (!fieldPathFromRow) {
    return false;
  }
  const value = preparedSubject.value;
  return effect.fieldPresence?.after === true && fieldPathFromRow.length > 0 ? isTraversableNode(
    resolveNodeAtSegments(value, fieldPathFromRow.slice(0, -1))
  ) : resolveNodeAtSegments(value, fieldPathFromRow) !== void 0;
}
function resolveCollectionNode(tree, descriptor, structuralOwnerPaths, effect) {
  const owned = structuralOwnerPaths.nodes.get(effect.owner);
  if (owned) return owned;
  if (effect.subjectFieldSegments !== void 0) return void 0;
  const collectionPath = resolveCollectionPath(
    descriptor,
    structuralOwnerPaths,
    effect
  );
  if (collectionPath === void 0) {
    return void 0;
  }
  const node = resolveNodeAtPath(
    tree.$,
    collectionPath
  );
  return isCollectionNode(node) ? node : void 0;
}
function resolveCollectionPath(descriptor, structuralOwnerPaths, effect) {
  return descriptor?.collectionPath ?? (effect.structural ? descriptor?.ownerPath : void 0) ?? structuralOwnerPaths.get(effect.owner);
}
function isCollectionKeyOccupied(ownerNode, key, preparedContext) {
  const preparedOccupancy = preparedContext?.resolveOccupancy(ownerNode, key);
  if (preparedOccupancy === "vacant") {
    return false;
  }
  if (preparedOccupancy !== void 0) {
    return true;
  }
  return hasCollectionKey(ownerNode, key);
}
function resolvePreparedOrLiveSubjectKey(ownerNode, preparedContext, effect, subjectId) {
  const preparedSubject = preparedContext?.resolveSubject(effect, subjectId);
  if (preparedSubject) {
    return preparedSubject.currentKey;
  }
  return ownerNode.__findKeyBySubjectId?.(subjectId);
}
function resolveEffectiveRemoveKey(ownerNode, preparedContext, effect) {
  return resolvePreparedOrLiveSubjectKey(
    ownerNode,
    preparedContext,
    effect,
    effect.subjectId
  );
}
function snapshotCollectionEntityValue(collectionNode, key) {
  const rowNode = collectionNode.byIdOrFail(key);
  return typeof rowNode === "function" ? rowNode() : rowNode;
}
function updatePreparedRealizationContext(tree, descriptors, structuralOwnerPaths, preparedContext, effect) {
  if (typeof effect.subjectId === "number" && !effect.structural) {
    const descriptor2 = descriptors.get(effect.owner);
    const preparedSubject = preparedContext.resolveSubject(
      effect,
      effect.subjectId
    );
    const fieldPathFromRow = resolveSubjectFieldPath(
      descriptor2,
      effect,
      getPositionRegistry(tree.$)
    );
    if (preparedSubject && fieldPathFromRow?.length === 0) {
      preparedSubject.value = effect.after;
    } else if (preparedSubject && fieldPathFromRow && effect.fieldPresence?.after === false) {
      preparedSubject.value = withoutFieldAtSegments(
        preparedSubject.value,
        fieldPathFromRow
      );
    } else if (preparedSubject && fieldPathFromRow) {
      assignPreparedSubjectValue(
        preparedSubject.value,
        fieldPathFromRow,
        effect.after
      );
    }
    return;
  }
  if (typeof effect.subjectId !== "number" || !effect.structural) {
    return;
  }
  const descriptor = descriptors.get(effect.owner);
  switch (effect.structural) {
    case "add": {
      const collectionPath = resolveCollectionPath(
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionPath) {
        return;
      }
      const structuralEffect = getStructuralAddEffect(descriptor, effect);
      if (!structuralEffect) {
        return;
      }
      const preparedValue = deepClone(structuralEffect.value);
      preparedContext.rememberRestoredSubject(
        effect,
        effect.subjectId,
        collectionPath,
        effect.after,
        preparedValue
      );
      return;
    }
    case "rekey": {
      if (realizationPlacement(effect) && !preparedContext.resolveSubject(effect, effect.subjectId)) {
        const collectionNode = resolveCollectionNode(
          tree,
          descriptor,
          structuralOwnerPaths,
          effect
        );
        const path = resolveCollectionPath(
          descriptor,
          structuralOwnerPaths,
          effect
        );
        if (collectionNode && path)
          preparedContext.rememberRestoredSubject(
            effect,
            effect.subjectId,
            path,
            effect.before,
            deepClone(
              snapshotCollectionEntityValue(
                collectionNode,
                effect.before
              )
            )
          );
      }
      preparedContext.rememberRekeyedSubject(
        effect,
        effect.subjectId,
        effect.after
      );
      return;
    }
    case "remove": {
      const collectionPath = resolveCollectionPath(
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionPath) {
        return;
      }
      const collectionNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionNode) {
        return;
      }
      const removeEffect = effect;
      const effectiveRemoveKey = resolveEffectiveRemoveKey(
        collectionNode,
        preparedContext,
        removeEffect
      );
      if (effectiveRemoveKey === void 0) {
        return;
      }
      const liveValue = snapshotCollectionEntityValue(
        collectionNode,
        effectiveRemoveKey
      );
      if (liveValue === void 0) {
        return;
      }
      preparedContext.rememberRemovedSubject(
        effect,
        effect.subjectId,
        collectionPath,
        effectiveRemoveKey,
        liveValue
      );
      return;
    }
  }
}
function preparedSubjectScope(tree, descriptors, structuralOwnerPaths) {
  return (effect) => resolveCollectionNode(
    tree,
    descriptors.get(effect.owner),
    structuralOwnerPaths,
    effect
  );
}
function buildPreparedRealizationContext(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effects) {
  const preparedContext = new PreparedRealizationContext(
    preparedSubjectScope(tree, descriptors, structuralOwnerPaths)
  );
  for (const effect of effects) {
    if (!canApplyEffect(
      tree,
      descriptors,
      structuralOwnerPaths,
      scalarSlotRuntime,
      effect,
      preparedContext
    )) {
      return void 0;
    }
    updatePreparedRealizationContext(
      tree,
      descriptors,
      structuralOwnerPaths,
      preparedContext,
      effect
    );
  }
  return preparedContext;
}
function resolveSubjectFieldPath(descriptor, effect, registry) {
  if (typeof effect.subjectId !== "number") return void 0;
  if (effect.subjectFieldSegments !== void 0) {
    return effect.subjectFieldSegments;
  }
  const legacy = deriveFieldPathFromEffect(effect, registry) ?? descriptor?.subjectDescriptors?.get(String(effect.subjectId))?.fieldPathFromRow ?? descriptor?.fieldPathFromRow;
  return legacy === void 0 ? void 0 : legacy === "" ? [] : legacy.split(".");
}
function assignPreparedSubjectValue(subjectValue, fieldPathFromRow, nextValue) {
  if (fieldPathFromRow.length === 0) {
    return;
  }
  if (!isTraversableNode(subjectValue)) {
    return;
  }
  const segments = fieldPathFromRow;
  let cursor = subjectValue;
  for (const segment of segments.slice(0, -1)) {
    if (!isTraversableNode(cursor)) {
      return;
    }
    cursor = cursor[segment];
  }
  const leafKey = segments.at(-1);
  if (leafKey === void 0 || !isTraversableNode(cursor)) {
    return;
  }
  cursor[leafKey] = nextValue;
}
function isPreparedSubjectScalarEffect(effect, preparedContext) {
  return typeof effect.subjectId === "number" && !effect.structural && preparedContext.resolveSubject(effect, effect.subjectId) !== void 0;
}
function indexPointOwnerPaths(root, effects) {
  const registry = getPositionRegistry(root);
  const owners = Object.assign(/* @__PURE__ */ new Map(), {
    nodes: /* @__PURE__ */ new Map()
  });
  for (const effect of effects) {
    if (typeof effect.subjectId !== "number" || owners.nodes.has(effect.owner))
      continue;
    const address = registry?.addressFor(effect.owner);
    if (!address || address.length > 32) return indexStructuralOwnerPaths(root);
    let node = root;
    for (const key of address) {
      if (!isTraversableNode(node) || key === "set" || key === "update" || key.startsWith("_")) {
        return indexStructuralOwnerPaths(root);
      }
      const property = Object.getOwnPropertyDescriptor(node, key);
      if (!property?.enumerable || !("value" in property))
        return indexStructuralOwnerPaths(root);
      node = property.value;
    }
    if (!isCollectionNode(node) || getOwnedPositionIds(node)?.[0] !== effect.owner) {
      return indexStructuralOwnerPaths(root);
    }
    const path = getOwnedOwnerPath(node);
    if (path === void 0) return indexStructuralOwnerPaths(root);
    owners.set(effect.owner, path);
    owners.nodes.set(effect.owner, node);
  }
  return owners;
}
function indexStructuralOwnerPaths(root) {
  const ownerPaths = Object.assign(/* @__PURE__ */ new Map(), {
    nodes: /* @__PURE__ */ new Map()
  });
  visitTree(
    root,
    (node) => {
      if (!isCollectionNode(node)) {
        return void 0;
      }
      const positionId = getOwnedPositionIds(node)?.[0];
      const ownerPath = getOwnedOwnerPath(node);
      if (positionId === void 0 || ownerPath === void 0) {
        return void 0;
      }
      ownerPaths.set(positionId, ownerPath);
      ownerPaths.nodes.set(positionId, node);
      return void 0;
    },
    {
      skipKey: (key) => key === "set" || key === "update" || key.startsWith("_")
    }
  );
  return ownerPaths;
}
function resolveCurrentSubjectTarget(tree, descriptor, subjectId, effect, structuralOwnerPaths) {
  if (effect.subjectFieldSegments !== void 0) {
    const collection = structuralOwnerPaths.nodes.get(effect.owner);
    const key = collection?.__findKeyBySubjectId?.(subjectId);
    if (!collection || key === void 0) return void 0;
    const row = collection.byIdOrFail(key);
    return resolveStructuredSubjectTarget(row, effect.subjectFieldSegments);
  }
  const registry = getPositionRegistry(tree.$);
  const inlineCollectionPath = deriveCollectionPathFromEffect(effect, registry);
  const inlineFieldPathFromRow = deriveFieldPathFromEffect(effect, registry);
  const subjectDescriptor = descriptor?.subjectDescriptors?.get(
    String(subjectId)
  );
  const collectionPath = inlineCollectionPath ?? subjectDescriptor?.collectionPath ?? descriptor?.collectionPath ?? (effect.structural ? descriptor?.ownerPath : void 0);
  if (!collectionPath && collectionPath !== "") {
    return void 0;
  }
  const collectionNode = resolveNodeAtPath(
    tree.$,
    collectionPath
  );
  if (!isCollectionNode(collectionNode)) {
    return void 0;
  }
  const currentKey = collectionNode.__findKeyBySubjectId?.(subjectId);
  if (currentKey === void 0) {
    return void 0;
  }
  const rowNode = collectionNode.byIdOrFail(currentKey);
  const fieldPathFromRow = inlineFieldPathFromRow ?? subjectDescriptor?.fieldPathFromRow ?? descriptor?.fieldPathFromRow;
  if (fieldPathFromRow === "") {
    return rowNode;
  }
  if (!fieldPathFromRow) {
    return void 0;
  }
  return resolveNodeAtPath(
    rowNode,
    fieldPathFromRow
  );
}
function resolveNotifyPath(tree, descriptor, structuralOwnerPaths, effect) {
  if (hasInlineScopedAddress(effect)) {
    return effect.path;
  }
  if (typeof effect.subjectId !== "number") {
    return descriptor?.path ?? effect.path;
  }
  if (effect.subjectFieldSegments !== void 0) {
    const collection = structuralOwnerPaths.nodes.get(effect.owner);
    const key = collection?.__findKeyBySubjectId?.(effect.subjectId);
    const path = structuralOwnerPaths.get(effect.owner);
    if (key === void 0 || path === void 0) return void 0;
    return [path, String(key), ...effect.subjectFieldSegments].join(".");
  }
  const registry = getPositionRegistry(tree.$);
  const inlineCollectionPath = deriveCollectionPathFromEffect(effect, registry);
  const inlineFieldPathFromRow = deriveFieldPathFromEffect(effect, registry);
  const collectionPath = inlineCollectionPath ?? descriptor?.subjectDescriptors?.get(String(effect.subjectId))?.collectionPath ?? descriptor?.collectionPath ?? structuralOwnerPaths.get(effect.owner);
  if (collectionPath === void 0) {
    return descriptor?.path;
  }
  const collectionNode = resolveNodeAtPath(
    tree.$,
    collectionPath
  );
  if (!isCollectionNode(collectionNode)) {
    return descriptor?.path;
  }
  const currentKey = collectionNode.__findKeyBySubjectId?.(effect.subjectId);
  if (currentKey === void 0) {
    return descriptor?.path;
  }
  const fieldPathFromRow = inlineFieldPathFromRow ?? descriptor?.subjectDescriptors?.get(String(effect.subjectId))?.fieldPathFromRow ?? descriptor?.fieldPathFromRow;
  const rowPath = `${collectionPath}.${String(currentKey)}`;
  if (fieldPathFromRow === "") {
    return rowPath;
  }
  return fieldPathFromRow ? `${rowPath}.${fieldPathFromRow}` : descriptor?.path;
}
function hasInlineSubjectAddress(effect) {
  return typeof effect.subjectId === "number" && typeof effect.path === "string" && typeof effect.ownerPath === "string";
}
function hasInlineScopedAddress(effect) {
  return typeof effect.path === "string" && typeof effect.ownerPath === "string" && effect.path !== effect.ownerPath;
}
function deriveCollectionPathFromEffect(effect, registry) {
  if (!hasInlineSubjectAddress(effect)) {
    return void 0;
  }
  return deriveRealizationAddress(
    effect.path,
    effect.ownerPath,
    effect.subjectId,
    void 0,
    registry?.collectionPathFor(effect.owner)
  ).collectionPath;
}
function deriveFieldPathFromEffect(effect, registry) {
  if (!hasInlineSubjectAddress(effect)) {
    return void 0;
  }
  return deriveRealizationAddress(
    effect.path,
    effect.ownerPath,
    effect.subjectId,
    void 0,
    registry?.collectionPathFor(effect.owner)
  ).fieldPathFromRow;
}
function resolveCurrentScopedTarget(tree, descriptor, effect) {
  const scopePath = effect.ownerPath ?? descriptor?.ownerPath;
  if (!scopePath) {
    return void 0;
  }
  const scopeNode = resolveNodeAtPath(
    tree.$,
    scopePath
  );
  if (scopeNode === void 0) {
    return void 0;
  }
  const relativePath = effect.path.startsWith(`${scopePath}.`) ? effect.path.slice(scopePath.length + 1) : "";
  const normalizedRelativePath = normalizeScopedValuePath(relativePath);
  if (normalizedRelativePath === "") {
    return scopeNode;
  }
  const scopedFieldTree = scopeNode && typeof scopeNode === "function" && "$" in scopeNode ? scopeNode.$ : void 0;
  if (isTraversableNode(scopedFieldTree)) {
    const scopedTarget = resolveNodeAtPath(
      scopedFieldTree,
      normalizedRelativePath
    );
    if (isWritableLeaf(scopedTarget) || isWritableEntityNode(scopedTarget)) {
      return scopedTarget;
    }
  }
  if (!isTraversableNode(scopeNode)) {
    return void 0;
  }
  return resolveNodeAtPath(
    scopeNode,
    normalizedRelativePath
  );
}
function withoutFieldAtSegments(value, segments) {
  if (segments.length === 0 || !isTraversableNode(value)) return value;
  const [head, ...tail] = segments;
  const record = value;
  if (!Object.prototype.hasOwnProperty.call(record, head)) return value;
  if (tail.length === 0) {
    const { [head]: _removed, ...rest } = record;
    return rest;
  }
  return { ...record, [head]: withoutFieldAtSegments(record[head], tail) };
}
function resolveNodeAtSegments(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (cursor === null || cursor === void 0) return void 0;
    cursor = cursor[segment];
  }
  return cursor;
}
function resolveStructuredSubjectTarget(row, segments) {
  if (segments.length === 0) return row;
  const direct = resolveNodeAtSegments(row, segments);
  if (isWritableLeaf(direct) || isWritableEntityNode(direct)) return direct;
  if (!isWritableEntityNode(row)) return void 0;
  const read2 = row;
  const parent = resolveNodeAtSegments(read2(), segments.slice(0, -1));
  if (!isTraversableNode(parent)) return void 0;
  return (value) => row(replaceValueAtSegments(read2(), segments, value));
}
function replaceValueAtSegments(value, segments, next) {
  if (segments.length === 0) return next;
  const [key, ...rest] = segments;
  const record = isTraversableNode(value) ? value : {};
  return { ...record, [key]: replaceValueAtSegments(record[key], rest, next) };
}
function resolveNodeAtPath(root, path) {
  if (path === "") {
    return root;
  }
  let cursor = root;
  for (const segment of path.split(".")) {
    if (cursor === null || cursor === void 0) {
      return void 0;
    }
    cursor = cursor[segment];
  }
  return cursor;
}
var rowScope = (owner, subject) => `${String(owner)}\0${String(subject)}`;
function orderPhysicalPlacements(tree, descriptors, ownerPaths, effects) {
  const placements = effects.filter(
    (effect) => typeof effect.subjectId === "number" && (effect.structural === "add" || realizationPlacement(effect) !== void 0)
  );
  if (placements.length < 2) return effects;
  const removed = new Set(
    effects.filter((effect) => effect.structural === "remove").map((effect) => rowScope(effect.owner, effect.subjectId))
  );
  const nodes = /* @__PURE__ */ new Map();
  const ordered = orderRestoresForPlacement(
    placements,
    (effect) => getStructuralAddEffect(
      descriptors.get(effect.owner),
      realizationPlacement(effect) ?? effect
    ),
    (effect, subject) => {
      if (removed.has(rowScope(effect.owner, subject))) return false;
      if (!nodes.has(effect.owner))
        nodes.set(
          effect.owner,
          resolveCollectionNode(
            tree,
            descriptors.get(effect.owner),
            ownerPaths,
            effect
          )
        );
      return nodes.get(effect.owner)?.__findKeyBySubjectId?.(subject) !== void 0;
    }
  );
  const placementSet = new Set(placements);
  let next = 0;
  return effects.map(
    (effect) => placementSet.has(effect) ? ordered[next++] : effect
  );
}
function orderRestoresForPlacement(restores, anchorsOf, isLive) {
  if (restores.length < 2) return [...restores];
  const pending2 = /* @__PURE__ */ new Map();
  for (const effect of restores) {
    pending2.set(rowScope(effect.owner, effect.subjectId), effect);
  }
  const waiting = /* @__PURE__ */ new Map();
  const hasLiveAnchor = /* @__PURE__ */ new Set();
  const dependents = /* @__PURE__ */ new Map();
  const full = [];
  const partial = [];
  for (const effect of restores) {
    const anchors = anchorsOf(effect);
    let count = 0;
    for (const subject of [anchors?.beforeSubject, anchors?.afterSubject]) {
      if (subject === void 0) continue;
      const key = rowScope(effect.owner, subject);
      if (pending2.has(key)) {
        count += 1;
        const list = dependents.get(key);
        if (list) list.push(effect);
        else dependents.set(key, [effect]);
      } else if (isLive(effect, subject)) {
        hasLiveAnchor.add(effect);
      }
    }
    waiting.set(effect, count);
    if (count === 0) full.push(effect);
    else if (hasLiveAnchor.has(effect)) partial.push(effect);
  }
  const placed = /* @__PURE__ */ new Set();
  const ordered = [];
  let fullHead = 0;
  let partialHead = 0;
  const isWaitingOn = (effect, subject) => {
    if (subject === void 0) return false;
    const anchor = pending2.get(rowScope(effect.owner, subject));
    return anchor !== void 0 && !placed.has(anchor);
  };
  while (ordered.length < restores.length) {
    while (fullHead < full.length && placed.has(full[fullHead])) fullHead += 1;
    while (partialHead < partial.length && placed.has(partial[partialHead])) {
      partialHead += 1;
    }
    const next = fullHead < full.length ? full[fullHead++] : partialHead < partial.length ? partial[partialHead++] : restores.find(
      (effect) => !placed.has(effect) && !isWaitingOn(effect, anchorsOf(effect)?.beforeSubject)
    ) ?? restores.find((effect) => !placed.has(effect));
    placed.add(next);
    ordered.push(next);
    for (const dependent of dependents.get(
      rowScope(next.owner, next.subjectId)
    ) ?? []) {
      if (placed.has(dependent)) continue;
      const left = (waiting.get(dependent) ?? 1) - 1;
      waiting.set(dependent, left);
      hasLiveAnchor.add(dependent);
      if (left === 0) full.push(dependent);
      else partial.push(dependent);
    }
  }
  return ordered;
}
function getStructuralAddEffect(descriptor, effect) {
  if (effect.structural !== "add" || typeof effect.subjectId !== "number") {
    return void 0;
  }
  if (isStructuralEffect(effect.structuralContext)) {
    return effect.structuralContext.kind === "remove" || effect.structuralContext.kind === "add" ? effect.structuralContext : void 0;
  }
  const removeEffect = descriptor?.structuralEffects?.get(
    `remove:${String(effect.subjectId)}:${String(effect.after)}`
  );
  if (removeEffect?.kind === "remove") {
    return removeEffect;
  }
  const subjectEffect = descriptor?.structuralEffectBySubject?.get(
    String(effect.subjectId)
  );
  if (subjectEffect?.kind === "remove" || subjectEffect?.kind === "add") {
    return subjectEffect;
  }
  const addEffect = descriptor?.structuralEffects?.get(
    `add:${String(effect.subjectId)}:${String(effect.after)}`
  );
  return addEffect?.kind === "add" ? addEffect : void 0;
}
var WHOLE_SUBJECT = { kind: "whole" };
function deriveSubjectAddress(path, subjectId, structuralEffect, canonicalCollectionPath) {
  if (structuralEffect) {
    return void 0;
  }
  if (path === canonicalCollectionPath) {
    return void 0;
  }
  const prefix = `${canonicalCollectionPath}.`;
  if (!path.startsWith(prefix)) {
    return void 0;
  }
  const relative = path.slice(prefix.length);
  const firstDot = relative.indexOf(".");
  if (firstDot === -1) {
    return typeof subjectId === "number" ? WHOLE_SUBJECT : void 0;
  }
  const fieldPath = relative.slice(firstDot + 1);
  return fieldPath === "" ? void 0 : { kind: "field", path: fieldPath };
}
function encodeSubjectAddress(address) {
  if (!address) return void 0;
  return address.kind === "whole" ? "" : address.path;
}
function deriveCollectionPathLegacy(path, ownerPath, subjectId, structuralEffect) {
  if (structuralEffect) return ownerPath;
  if (path === ownerPath) {
    return ownerPath.includes(".") ? parentPath(ownerPath) : void 0;
  }
  if (!path.startsWith(`${ownerPath}.`)) return void 0;
  if (!ownerPath.includes(".")) return ownerPath;
  if (typeof subjectId !== "number") return void 0;
  return parentPath(ownerPath);
}
function deriveFieldPathFromRowLegacy(path, ownerPath, subjectId, structuralEffect) {
  if (structuralEffect) {
    return void 0;
  }
  if (path === ownerPath) {
    return "";
  }
  if (typeof subjectId !== "number" || !path.startsWith(`${ownerPath}.`)) {
    return void 0;
  }
  const relativePath = path.slice(ownerPath.length + 1);
  if (!ownerPath.includes(".")) {
    const firstDot = relativePath.indexOf(".");
    return firstDot === -1 ? "" : relativePath.slice(firstDot + 1);
  }
  return relativePath;
}
function deriveRealizationAddress(path, ownerPath, subjectId, structuralEffect, canonicalCollectionPath) {
  if (canonicalCollectionPath !== void 0) {
    return {
      collectionPath: canonicalCollectionPath,
      fieldPathFromRow: encodeSubjectAddress(
        deriveSubjectAddress(
          path,
          subjectId,
          structuralEffect,
          canonicalCollectionPath
        )
      )
    };
  }
  return {
    collectionPath: deriveCollectionPathLegacy(
      path,
      ownerPath,
      subjectId,
      structuralEffect
    ),
    fieldPathFromRow: deriveFieldPathFromRowLegacy(
      path,
      ownerPath,
      subjectId,
      structuralEffect
    )
  };
}
function parentPath(path) {
  const lastDot = path.lastIndexOf(".");
  return lastDot === -1 ? "" : path.slice(0, lastDot);
}
function forgetSubjectsInTreeRealizationDescriptors(descriptors, subjectIds) {
  if (subjectIds.length === 0 || descriptors.size === 0) {
    return;
  }
  const forgotten = new Set(subjectIds.map((id) => String(id)));
  for (const descriptor of descriptors.values()) {
    const bySubject = descriptor.structuralEffectBySubject;
    if (bySubject instanceof Map) {
      for (const key of forgotten) {
        bySubject.delete(key);
      }
    }
    const subjectDescriptors = descriptor.subjectDescriptors;
    if (subjectDescriptors instanceof Map) {
      for (const key of forgotten) {
        subjectDescriptors.delete(key);
      }
    }
    const effects = descriptor.structuralEffects;
    if (effects instanceof Map) {
      for (const key of [...effects.keys()]) {
        const firstColon = key.indexOf(":");
        if (firstColon === -1) {
          continue;
        }
        const secondColon = key.indexOf(":", firstColon + 1);
        const subject = key.slice(
          firstColon + 1,
          secondColon === -1 ? void 0 : secondColon
        );
        if (forgotten.has(subject)) {
          effects.delete(key);
        }
      }
    }
  }
}
function toStructuralEffectKey(effect) {
  switch (effect.kind) {
    case "add":
    case "remove":
      return `${effect.kind}:${String(effect.subject)}:${String(effect.key)}`;
    case "rekey":
      return `rekey:${String(effect.subject)}:${String(
        effect.beforeKey
      )}:${String(effect.afterKey)}`;
  }
}
function isWritableLeaf(value) {
  return Boolean(
    value && typeof value === "function" && "set" in value && typeof value.set === "function"
  );
}
function isWritableEntityNode(value) {
  return Boolean(
    value && typeof value === "function" && !("set" in value)
  );
}
function isStructuralEffect(value) {
  return Boolean(
    value && typeof value === "object" && "kind" in value && (value.kind === "add" || value.kind === "remove" || value.kind === "rekey")
  );
}
function isCollectionNode(value) {
  return Boolean(
    value && "byIdOrFail" in value && "changeId" in value && "removeOne" in value
  );
}
function hasCollectionKey(node, key) {
  try {
    node.byIdOrFail(key);
    return true;
  } catch {
    return false;
  }
}

// packages/kernel/src/lib/internals/causal-runtime/transaction-lifecycle.ts
var TRANSACTION_LIFECYCLE = Symbol.for(
  "SignalTree:TransactionLifecycleChannel"
);
var TRANSACTION_LIFECYCLE_OWNER = Symbol.for(
  "SignalTree:TransactionLifecycleOwnerPresent"
);
function createChannel() {
  const listeners2 = /* @__PURE__ */ new Set();
  return {
    announce(event) {
      for (const listener of [...listeners2]) {
        try {
          listener(event);
        } catch {
        }
      }
    },
    subscribe(listener) {
      listeners2.add(listener);
      return () => {
        listeners2.delete(listener);
      };
    }
  };
}
function installTransactionLifecycleChannel(tree) {
  const host = tree;
  if (!host[TRANSACTION_LIFECYCLE_OWNER]) {
    Object.defineProperty(host, TRANSACTION_LIFECYCLE_OWNER, {
      value: true,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  const existing = host[TRANSACTION_LIFECYCLE];
  if (existing) {
    return existing;
  }
  const channel = createChannel();
  Object.defineProperty(host, TRANSACTION_LIFECYCLE, {
    value: channel,
    enumerable: false,
    writable: false,
    configurable: true
  });
  return channel;
}
function hasTransactionOwner(tree) {
  const host = tree;
  return !!host[TRANSACTION_LIFECYCLE_OWNER];
}
function tryGetTransactionLifecycleChannel(tree) {
  const host = tree;
  return host[TRANSACTION_LIFECYCLE];
}
function getTransactionLifecycleChannel(tree) {
  const channel = tryGetTransactionLifecycleChannel(tree);
  if (channel) {
    return channel;
  }
  if (hasTransactionOwner(tree)) {
    throw new Error(
      "ST1036: this tree has a transaction authority but no lifecycle channel could be resolved. The channel is installed by that owner on the tree's canonical host; failing to find one here means the install and the lookup disagree about that host, which would silently deliver no lifecycle events at all."
    );
  }
  throw new Error(
    "ST1036: this tree has no transaction capability, so it has no lifecycle channel. Add `transactions()` to the enhancers, or use `tryGetTransactionLifecycleChannel()` where absence is legitimate."
  );
}

// packages/kernel/src/enhancers/transactions/occupancy-composition.ts
function composeOccupancy(previous, effect) {
  const before = effect.kind === "add" ? void 0 : effect.kind === "remove" ? effect.key : effect.beforeKey;
  const after = effect.kind === "remove" ? void 0 : effect.kind === "add" ? effect.key : effect.afterKey;
  if (previous && !Object.is(previous.afterKey, before)) {
    throw new Error("Discontinuous ordinary occupancy capture");
  }
  return {
    first: previous?.first ?? effect,
    beforeKey: previous ? previous.beforeKey : before,
    afterKey: after,
    removal: previous?.removal ?? (effect.kind === "remove" ? effect : void 0),
    latestRemoval: effect.kind === "remove" ? effect : previous?.latestRemoval,
    addition: effect.kind === "add" ? effect : previous?.addition
  };
}
function occupancyEffect(state2) {
  if (Object.is(state2.beforeKey, state2.afterKey)) return void 0;
  const { ownerPath, position, path, subject } = state2.first;
  if (state2.beforeKey === void 0) {
    if (!state2.addition || state2.afterKey === void 0)
      throw new Error("Missing ordinary addition context");
    return { ...state2.addition, key: state2.afterKey };
  }
  if (state2.afterKey === void 0) {
    if (!state2.removal) throw new Error("Missing ordinary removal context");
    return { ...state2.removal, key: state2.beforeKey };
  }
  return {
    kind: "rekey",
    ownerPath,
    position,
    path,
    subject,
    beforeKey: state2.beforeKey,
    afterKey: state2.afterKey
  };
}

// packages/kernel/src/lib/internals/transaction-lifecycle-source.ts
var SOURCES2 = /* @__PURE__ */ new WeakMap();
function defineTransactionLifecycleSource(registry, source) {
  SOURCES2.set(registry, source);
}

// packages/kernel/src/lib/internals/causal-runtime/applied-turn-projection.ts
var AppliedTurnProjection = class {
  constructor(store) {
    this.store = store;
  }
  appliedTurnIds = [];
  redoTurnIds = [];
  admitConfirmed(turnId) {
    const turn = this.store.getTurn(turnId);
    if (!turn) {
      return { ok: false, reason: "turn-evicted" };
    }
    const transition2 = this.prepareAdmitConfirmedTurn({
      turnId,
      participants: turn.participants
    });
    this.commitPreparedAdmitConfirmed(transition2);
    return { ok: true };
  }
  prepareAdmitConfirmedTurn(turn) {
    return {
      turnId: turn.turnId,
      participants: [...turn.participants]
    };
  }
  commitPreparedAdmitConfirmed(transition2) {
    this.insertAppliedTurnCanonical(transition2.turnId);
    if (this.redoTurnIds.length > 0) {
      return this.invalidateOverlappingRedoTurns(transition2.participants);
    }
    return [];
  }
  prepareUnapplyConfirmedTurn(turnId) {
    const turn = this.store.getTurn(turnId);
    if (!turn) {
      return { ok: false, reason: "turn-evicted" };
    }
    const isApplied = this.appliedTurnIds.includes(turnId);
    const isParticipantFrontier = turn.participants.every(
      (participant) => this.getFrontier(participant) === turnId
    );
    if (!isApplied || !isParticipantFrontier) {
      return { ok: false, reason: "not-applied-frontier" };
    }
    return {
      ok: true,
      transition: { turnId }
    };
  }
  commitPreparedUnapply(transition2) {
    const { turnId } = transition2;
    this.removeAppliedTurn(turnId);
    this.redoTurnIds.unshift(turnId);
  }
  moveConfirmedTurnToRedo(turnId) {
    const prepared = this.prepareUnapplyConfirmedTurn(turnId);
    if (!prepared.ok) {
      return prepared;
    }
    this.commitPreparedUnapply(prepared.transition);
    return { ok: true };
  }
  prepareReapplyConfirmedTurn(turnId) {
    const turn = this.store.getTurn(turnId);
    if (!turn) {
      return { ok: false, reason: "turn-evicted" };
    }
    const isRedoable = this.redoTurnIds.includes(turnId);
    const restoresValidPrefix = turn.participants.every(
      (participant) => this.getFirstUnappliedTurnIdForPosition(participant) === turnId
    );
    if (!isRedoable || !restoresValidPrefix) {
      return { ok: false, reason: "not-redoable-next" };
    }
    return {
      ok: true,
      transition: { turnId }
    };
  }
  commitPreparedReapply(transition2) {
    const { turnId } = transition2;
    this.redoTurnIds.splice(this.redoTurnIds.indexOf(turnId), 1);
    this.insertAppliedTurnCanonical(turnId);
  }
  moveRedoTurnToApplied(turnId) {
    const prepared = this.prepareReapplyConfirmedTurn(turnId);
    if (!prepared.ok) {
      return prepared;
    }
    this.commitPreparedReapply(prepared.transition);
    return { ok: true };
  }
  getAppliedTurnIds() {
    return [...this.appliedTurnIds];
  }
  getRedoTurnIds() {
    return [...this.redoTurnIds];
  }
  forgetRetainedTurn(turnId) {
    const wasApplied = this.appliedTurnIds.includes(turnId);
    const wasRedoable = this.redoTurnIds.includes(turnId);
    if (wasApplied) {
      this.removeAppliedTurn(turnId);
    }
    if (wasRedoable) {
      this.redoTurnIds.splice(this.redoTurnIds.indexOf(turnId), 1);
    }
    return {
      wasApplied,
      wasRedoable
    };
  }
  getFrontier(positionId) {
    for (let index = this.appliedTurnIds.length - 1; index >= 0; index -= 1) {
      const turn = this.store.getTurn(this.appliedTurnIds[index]);
      if (turn?.participants.includes(positionId)) {
        return turn.id;
      }
    }
    return void 0;
  }
  inspect() {
    const frontiers = /* @__PURE__ */ new Map();
    for (const turnId of this.appliedTurnIds) {
      const turn = this.store.getTurn(turnId);
      if (!turn) {
        continue;
      }
      for (const participant of turn.participants) {
        frontiers.set(participant, turn.id);
      }
    }
    return {
      appliedTurnIds: [...this.appliedTurnIds],
      redoTurnIds: [...this.redoTurnIds],
      frontiers: Object.fromEntries(
        [...frontiers.entries()].map(([positionId, turnId]) => [
          String(positionId),
          turnId
        ])
      )
    };
  }
  removeAppliedTurn(turnId) {
    const index = this.appliedTurnIds.indexOf(turnId);
    if (index === -1) {
      return;
    }
    this.appliedTurnIds.splice(index, 1);
  }
  getFirstUnappliedTurnIdForPosition(positionId) {
    return this.store.getTurnIdsForPosition(positionId).find((turnId) => !this.appliedTurnIds.includes(turnId));
  }
  insertAppliedTurnCanonical(turnId) {
    if (this.appliedTurnIds.includes(turnId)) {
      return;
    }
    const insertionIndex = this.appliedTurnIds.findIndex(
      (appliedTurnId) => appliedTurnId > turnId
    );
    if (insertionIndex === -1) {
      this.appliedTurnIds.push(turnId);
      return;
    }
    this.appliedTurnIds.splice(insertionIndex, 0, turnId);
  }
  invalidateOverlappingRedoTurns(participants) {
    const participantSet = new Set(participants);
    const invalidatedTurnIds = this.redoTurnIds.filter((turnId) => {
      const turn = this.store.getTurn(turnId);
      if (!turn) {
        return true;
      }
      return turn.participants.some((participant) => participantSet.has(participant));
    });
    this.redoTurnIds.splice(
      0,
      this.redoTurnIds.length,
      ...this.redoTurnIds.filter((turnId) => {
        const turn = this.store.getTurn(turnId);
        if (!turn) {
          return false;
        }
        return !turn.participants.some(
          (participant) => participantSet.has(participant)
        );
      })
    );
    return invalidatedTurnIds;
  }
};

// packages/kernel/src/lib/internals/causal-runtime/realization-context.ts
var ProjectionRealizationContextSource = class {
  constructor(options) {
    this.options = options;
    for (const [positionId, value] of options.baselineValues ?? []) {
      this.baselineValues.set(positionId, value);
    }
  }
  baselineValues = /* @__PURE__ */ new Map();
  forgottenConfirmedTurns = [];
  getCurrentValue(positionId) {
    return this.computeValues().get(positionId);
  }
  getValueWithoutConfirmedTurn(turnId, positionId) {
    return this.computeValues(turnId).get(positionId);
  }
  getValueWithoutPendingTurn(turnId, positionId) {
    return this.computeValues(void 0, turnId).get(positionId);
  }
  retainEvictedConfirmedTurn(turn) {
    const disposition = this.options.appliedTurns.forgetRetainedTurn(turn.id);
    if (!disposition.wasApplied && !disposition.wasRedoable) {
      return;
    }
    if (disposition.wasApplied) {
      for (const effect of turn.effects) {
        this.baselineValues.set(effect.owner, effect.after);
      }
    }
    this.forgottenConfirmedTurns.push(copyTurn(turn));
  }
  consumeForgottenConfirmedTurns() {
    const forgotten = this.forgottenConfirmedTurns.map(copyTurn);
    this.forgottenConfirmedTurns.length = 0;
    return forgotten;
  }
  computeValues(excludingConfirmedTurnId, excludingPendingTurnId) {
    const values = new Map(this.baselineValues);
    const activeConfirmedTurns = this.options.appliedTurns.getAppliedTurnIds().filter((turnId) => turnId !== excludingConfirmedTurnId).map((turnId) => this.options.store.getTurn(turnId)).filter((turn) => turn !== void 0);
    const activePendingTurns = this.options.store.getPendingTurns().filter((turn) => turn.id !== excludingPendingTurnId);
    const activeTurns = [...activeConfirmedTurns, ...activePendingTurns].sort(
      (left, right) => left.id - right.id
    );
    for (const turn of activeTurns) {
      for (const effect of turn.effects) {
        values.set(effect.owner, effect.after);
      }
    }
    for (const [positionId, value] of this.options.getOverlayValues?.() ?? []) {
      values.set(positionId, value);
    }
    return values;
  }
};
function createRealizationContextSource(options) {
  return new ProjectionRealizationContextSource(options);
}
function copyTurn(turn) {
  return {
    ...turn,
    effects: turn.effects.map((effect) => ({
      ...effect
    })),
    participants: [...turn.participants]
  };
}

// packages/kernel/src/lib/internals/causal-runtime/turn-store.ts
var TurnStore = class {
  capacity;
  retainEvictedConfirmedTurn;
  onEvictConfirmedTurn;
  reportEvictionObserverError;
  confirmedTurns = /* @__PURE__ */ new Map();
  pendingTurns = /* @__PURE__ */ new Map();
  orderedConfirmedTurnIds = [];
  positionIndex = /* @__PURE__ */ new Map();
  constructor(options) {
    this.capacity = options?.capacity ?? Number.POSITIVE_INFINITY;
    this.retainEvictedConfirmedTurn = options?.retainEvictedConfirmedTurn;
    this.onEvictConfirmedTurn = options?.onEvictConfirmedTurn;
    this.reportEvictionObserverError = options?.reportEvictionObserverError;
  }
  admitConfirmed(turn) {
    this.assertTurnIdAvailable(turn.id);
    const canonicalTurn = {
      id: turn.id,
      effects: [...turn.effects],
      participants: this.deriveParticipants(turn.effects),
      state: "confirmed"
    };
    this.insertConfirmed(canonicalTurn);
    return canonicalTurn;
  }
  admitPending(turn) {
    this.assertTurnIdAvailable(turn.id);
    const pendingTurn = {
      id: turn.id,
      effects: [...turn.effects],
      participants: this.deriveParticipants(turn.effects),
      state: "pending"
    };
    this.pendingTurns.set(pendingTurn.id, pendingTurn);
    return pendingTurn;
  }
  confirmPending(turnId) {
    const prepared = this.prepareConfirmPendingTurn(turnId);
    if (!prepared.ok) {
      return void 0;
    }
    return this.commitPreparedConfirmPending(prepared.transition);
  }
  discardPending(turnId) {
    const pendingTurn = this.pendingTurns.get(turnId);
    if (!pendingTurn) {
      return void 0;
    }
    this.pendingTurns.delete(turnId);
    return pendingTurn;
  }
  prepareDiscardPendingTurn(turnId) {
    if (!this.pendingTurns.has(turnId)) {
      return { ok: false, reason: "turn-evicted" };
    }
    return {
      ok: true,
      transition: { turnId }
    };
  }
  prepareConfirmPendingTurn(turnId) {
    const pendingTurn = this.pendingTurns.get(turnId);
    if (!pendingTurn) {
      return { ok: false, reason: "turn-evicted" };
    }
    return {
      ok: true,
      transition: {
        turnId,
        pendingTurn: {
          ...pendingTurn,
          effects: [...pendingTurn.effects],
          participants: [...pendingTurn.participants]
        }
      }
    };
  }
  commitPreparedConfirmPending(transition2) {
    const pendingTurn = this.pendingTurns.get(transition2.turnId);
    if (!pendingTurn) {
      throw new Error(`Prepared pending turn ${transition2.turnId} no longer exists`);
    }
    this.assertTurnIdNotConfirmed(transition2.turnId);
    this.pendingTurns.delete(transition2.turnId);
    const confirmedTurn = {
      ...transition2.pendingTurn,
      effects: [...transition2.pendingTurn.effects],
      participants: [...transition2.pendingTurn.participants],
      state: "confirmed"
    };
    this.insertConfirmed(confirmedTurn);
    return confirmedTurn;
  }
  commitPreparedDiscardPending(transition2) {
    return this.discardPending(transition2.turnId);
  }
  hasPendingTurn(turnId) {
    return this.pendingTurns.has(turnId);
  }
  getTurn(turnId) {
    return this.confirmedTurns.get(turnId);
  }
  getTurns() {
    return this.orderedConfirmedTurnIds.map((turnId) => this.confirmedTurns.get(turnId)).filter((turn) => turn !== void 0);
  }
  getPendingTurn(turnId) {
    return this.pendingTurns.get(turnId);
  }
  getPendingTurns() {
    return [...this.pendingTurns.values()].sort((left, right) => left.id - right.id);
  }
  getPendingTurnIds() {
    return this.getPendingTurns().map(({ id }) => id);
  }
  getTurnIdsForPosition(positionId) {
    return [...this.positionIndex.get(positionId) ?? []];
  }
  getTurnsForPosition(positionId) {
    return this.getTurnIdsForPosition(positionId).map((turnId) => this.confirmedTurns.get(turnId)).filter((turn) => turn !== void 0);
  }
  getFrontier(positionId) {
    const turnIds = this.positionIndex.get(positionId);
    if (!turnIds || turnIds.length === 0) {
      return void 0;
    }
    return turnIds[turnIds.length - 1];
  }
  inspect() {
    const positionIndex = Object.fromEntries(
      [...this.positionIndex.entries()].map(([positionId, turnIds]) => [
        String(positionId),
        [...turnIds]
      ])
    );
    return {
      turnIds: [...this.orderedConfirmedTurnIds],
      positionIndex,
      frontiers: Object.fromEntries(
        Object.entries(positionIndex).map(([positionId, turnIds]) => [
          positionId,
          turnIds[turnIds.length - 1]
        ])
      )
    };
  }
  deriveParticipants(effects) {
    return [...new Set(effects.map(({ owner }) => owner))];
  }
  assertTurnIdAvailable(turnId) {
    if (this.confirmedTurns.has(turnId) || this.pendingTurns.has(turnId)) {
      throw new Error(`Turn ${turnId} already exists`);
    }
  }
  assertTurnIdNotConfirmed(turnId) {
    if (this.confirmedTurns.has(turnId)) {
      throw new Error(`Turn ${turnId} already exists`);
    }
  }
  insertConfirmed(turn) {
    this.assertTurnIdNotConfirmed(turn.id);
    this.confirmedTurns.set(turn.id, turn);
    const insertAt = this.orderedConfirmedTurnIds.findIndex(
      (candidateTurnId) => candidateTurnId > turn.id
    );
    if (insertAt === -1) {
      this.orderedConfirmedTurnIds.push(turn.id);
    } else {
      this.orderedConfirmedTurnIds.splice(insertAt, 0, turn.id);
    }
    for (const participant of turn.participants) {
      const turnIds = this.positionIndex.get(participant) ?? [];
      const participantInsertAt = turnIds.findIndex(
        (candidateTurnId) => candidateTurnId > turn.id
      );
      if (participantInsertAt === -1) {
        turnIds.push(turn.id);
      } else {
        turnIds.splice(participantInsertAt, 0, turn.id);
      }
      this.positionIndex.set(participant, turnIds);
    }
    this.enforceCapacity();
  }
  enforceCapacity() {
    while (this.orderedConfirmedTurnIds.length > this.capacity) {
      const evictedTurnId = this.orderedConfirmedTurnIds.shift();
      if (evictedTurnId === void 0) {
        return;
      }
      const evictedTurn = this.confirmedTurns.get(evictedTurnId);
      if (evictedTurn) {
        this.retainEvictedConfirmedTurn?.(evictedTurn);
        try {
          this.onEvictConfirmedTurn?.(evictedTurn);
        } catch (error) {
          this.reportObserverFailure(error, evictedTurn);
        }
      }
      this.confirmedTurns.delete(evictedTurnId);
      if (!evictedTurn) {
        continue;
      }
      for (const participant of evictedTurn.participants) {
        const turnIds = this.positionIndex.get(participant);
        if (!turnIds) {
          continue;
        }
        const nextTurnIds = turnIds.filter((turnId) => turnId !== evictedTurnId);
        if (nextTurnIds.length === 0) {
          this.positionIndex.delete(participant);
          continue;
        }
        this.positionIndex.set(participant, nextTurnIds);
      }
    }
  }
  reportObserverFailure(error, turn) {
    if (this.reportEvictionObserverError) {
      this.reportEvictionObserverError(error, turn);
      return;
    }
    queueMicrotask(() => {
      throw normalizeError2(error);
    });
  }
};
function normalizeError2(error) {
  if (error instanceof Error) {
    return error;
  }
  return new Error(String(error));
}

// packages/kernel/src/enhancers/transactions/transactions.ts
var captureIdentity = Symbol("transaction source admission");
var identityOf = (effect) => effect[captureIdentity];
var identify = (effect, identity) => {
  Object.defineProperty(effect, captureIdentity, {
    value: Object.freeze(identity),
    enumerable: true,
    configurable: true
  });
  return effect;
};
var isLaterAdmission = (own, later) => {
  const a = identityOf(own), b = identityOf(later);
  return !a || !b || b.revision > a.revision;
};
var INTERNAL_TRANSACTION_RUNTIME = Symbol(
  "signaltree:internal:transaction-runtime"
);
var PENDING_TURN_ID = Symbol("signaltree:internal:pending-turn-id");
var ROLLBACK_ERROR_MESSAGE = "SignalTree could not rollback the pending transaction";
var explainRollbackFailure = (cause) => {
  if (cause.kind === "later-confirmed-dependency") {
    const at = cause.conflictingTurnId === void 0 ? "later work" : `turn ${cause.conflictingTurnId}`;
    return `${ROLLBACK_ERROR_MESSAGE}: ${at} depends on state this rollback would invalidate, so reversing turn ${cause.pendingTurnId} is no longer safe [later-confirmed-dependency]`;
  }
  return `${ROLLBACK_ERROR_MESSAGE}: compensating turn ${cause.pendingTurnId} failed validation \u2014 ${cause.errorMessage} [effect-validation-failed]`;
};
var createRollbackError = (cause) => new SignalTreeRollbackError(explainRollbackFailure(cause), { cause });
function cloneTurnEffect(effect) {
  return effect.kind === "set" && effect.subjectFieldSegments ? { ...effect, subjectFieldSegments: [...effect.subjectFieldSegments] } : { ...effect };
}
function combineScalarMutationIntent(left, right) {
  if (left === "replace" || right === "replace") {
    return "replace";
  }
  if (left === "derive" || right === "derive") {
    return "derive";
  }
  return void 0;
}
function scalarRelation(left, right) {
  const a = left.subjectFieldSegments;
  const b = right.subjectFieldSegments;
  if (a && b) {
    const common = Math.min(a.length, b.length);
    for (let i = 0; i < common; i++) if (a[i] !== b[i]) return "disjoint";
    return a.length === b.length ? "same" : "overlap";
  }
  if (left.path === right.path) return "same";
  return left.path.startsWith(`${right.path}.`) || right.path.startsWith(`${left.path}.`) ? "overlap" : "disjoint";
}
function buildPendingRollbackPlan(pendingTurn, laterEffects, encloses) {
  if (!pendingTurn) {
    return { compensation: [] };
  }
  laterEffects = laterEffects.slice().sort((a, b) => {
    const left = identityOf(a.effect), right = identityOf(b.effect);
    return left && right ? left.revision - right.revision : 0;
  });
  const pendingEffects = pendingTurn.__effects ?? [];
  const makeScalarKey = (effect) => JSON.stringify([
    effect.position,
    effect.subject,
    effect.subjectFieldSegments ?? effect.path
  ]);
  const classifyLaterOverlap = (effect) => {
    let superseded = false;
    for (const laterEntry of laterEffects) {
      if (!isLaterAdmission(effect, laterEntry.effect)) continue;
      const laterEffect = laterEntry.effect;
      if (laterEffect.position !== effect.position) {
        if (effect.plainBranchMembership?.before === false && effect.plainBranchMembership.after === true && encloses?.(effect.position, laterEffect.position)) {
          return {
            kind: "conflict",
            conflictingTurnId: laterEntry.turnId,
            conflictingEffect: laterEffect
          };
        }
        continue;
      }
      if (laterEffect.subject !== void 0 && effect.subject !== void 0 && laterEffect.subject !== effect.subject) {
        continue;
      }
      if (laterEffect.kind === "set" ? scalarRelation(effect, laterEffect) === "same" : laterEffect.path === effect.path) {
        if (laterEffect.kind !== "set") {
          return {
            kind: "conflict",
            conflictingTurnId: laterEntry.turnId,
            conflictingEffect: laterEffect
          };
        }
        if (laterEffect.mutationIntent === "replace") {
          if (laterEffects.some(
            ({ effect: candidate }) => candidate.kind === "set" && isLaterAdmission(effect, candidate) && makeScalarKey(candidate) === makeScalarKey(effect)
          )) {
            superseded = true;
            continue;
          }
        }
        return {
          kind: "conflict",
          conflictingTurnId: laterEntry.turnId,
          conflictingEffect: laterEffect
        };
      }
      if (laterEffect.kind === "set" ? scalarRelation(effect, laterEffect) === "overlap" : laterEffect.path.startsWith(`${effect.path}.`) || effect.path.startsWith(`${laterEffect.path}.`)) {
        return {
          kind: "conflict",
          conflictingTurnId: laterEntry.turnId,
          conflictingEffect: laterEffect
        };
      }
    }
    return superseded ? { kind: "superseded" } : { kind: "none" };
  };
  const hasSameSubjectDependency = (effect) => {
    for (const laterEntry of laterEffects) {
      if (!isLaterAdmission(effect, laterEntry.effect)) continue;
      const laterEffect = laterEntry.effect;
      if (laterEffect.ownerPath !== effect.ownerPath) {
        continue;
      }
      if (laterEffect.kind === "set") {
        if (laterEffect.subject === effect.subject && effect.kind !== "rekey") {
          return {
            conflictingTurnId: laterEntry.turnId,
            conflictingEffect: laterEffect
          };
        }
        continue;
      }
      if (laterEffect.subject === effect.subject) {
        return {
          conflictingTurnId: laterEntry.turnId,
          conflictingEffect: laterEffect
        };
      }
    }
    return void 0;
  };
  const classifyStructuralOverlap = (effect) => {
    if (effect.kind === "add" || effect.kind === "rekey") {
      let erased = false;
      for (const laterEntry of laterEffects) {
        if (!isLaterAdmission(effect, laterEntry.effect)) continue;
        const laterEffect = laterEntry.effect;
        if (laterEffect.ownerPath !== effect.ownerPath) {
          continue;
        }
        if (laterEffect.subject !== effect.subject) {
          continue;
        }
        erased = laterEffect.kind === "remove";
      }
      if (erased) {
        return { kind: "superseded" };
      }
    }
    if (effect.kind === "rekey") {
      let occupant;
      for (const laterEntry of laterEffects) {
        if (!isLaterAdmission(effect, laterEntry.effect)) continue;
        const later = laterEntry.effect;
        if (later.ownerPath !== effect.ownerPath) continue;
        if (later.kind === "add" && later.key === effect.beforeKey) {
          occupant = later.subject === effect.subject ? void 0 : laterEntry;
        } else if (later.kind === "remove" && later.key === effect.beforeKey) {
          occupant = void 0;
        } else if (later.kind === "rekey") {
          if (later.beforeKey === effect.beforeKey) occupant = void 0;
          if (later.afterKey === effect.beforeKey && later.subject !== effect.subject) {
            occupant = laterEntry;
          }
        }
      }
      if (occupant) {
        return {
          kind: "conflict",
          conflictingTurnId: occupant.turnId,
          conflictingEffect: occupant.effect
        };
      }
    }
    const dependency = hasSameSubjectDependency(effect);
    return dependency ? {
      kind: "conflict",
      conflictingTurnId: dependency.conflictingTurnId,
      conflictingEffect: dependency.conflictingEffect
    } : { kind: "none" };
  };
  const compensation = [];
  for (let i = pendingEffects.length - 1; i >= 0; i--) {
    const effect = pendingEffects[i];
    switch (effect.kind) {
      case "set": {
        const overlap = classifyLaterOverlap(effect);
        if (overlap.kind === "conflict") {
          return {
            conflict: {
              kind: "later-confirmed-dependency",
              pendingTurnId: pendingTurn.id,
              pendingEffect: effect,
              conflictingTurnId: overlap.conflictingTurnId,
              conflictingEffect: overlap.conflictingEffect
            }
          };
        }
        if (overlap.kind === "superseded") {
          continue;
        }
        compensation.push(effect);
        break;
      }
      case "add":
      case "remove":
      case "rekey": {
        const overlap = classifyStructuralOverlap(effect);
        if (overlap.kind === "conflict") {
          return {
            conflict: {
              kind: "later-confirmed-dependency",
              pendingTurnId: pendingTurn.id,
              pendingEffect: effect,
              conflictingTurnId: overlap.conflictingTurnId,
              conflictingEffect: overlap.conflictingEffect
            }
          };
        }
        if (overlap.kind === "superseded") {
          continue;
        }
        compensation.push(effect);
        break;
      }
    }
  }
  return { compensation };
}
var TransactionAuthority = class {
  /**
   * Restoration-claim hooks, injected because the authority has no tree.
   *
   * An UNSETTLED turn owns the subjects it retired: Phase 6B measured that
   * reclaiming one makes `rollback()` throw and loses the row permanently. The
   * claim exists for exactly that interval — optimistic mutation to settlement,
   * confirm or reject alike — so the bound is how many operations are
   * outstanding right now, never a configured depth.
   */
  constructor(retainPendingClaims = () => void 0, releasePendingClaims = () => void 0, encloses) {
    this.retainPendingClaims = retainPendingClaims;
    this.releasePendingClaims = releasePendingClaims;
    this.encloses = encloses;
  }
  confirmedTurns = [];
  /**
   * L15. Records kept purely as evidence, beyond what correctness requires.
   * 0 means correctness-only, which is the default.
   */
  historyRetain = 0;
  /**
   * Whether an explicit retention contract exists. Until one does, the ledger
   * is left exactly as it has always behaved: the reader-visible history
   * policy may not change silently, and `confirmedTurnReader` is a shipped
   * surface whose purpose is reading confirmed history.
   */
  /**
   * Set once any confirmed record has actually been dropped. The reader must
   * never infer truncation from id gaps — pending and rejected turns leave
   * gaps too — so this is the explicit metadata internals.ts asks for,
   * including the case where the whole window is gone.
   */
  evictedConfirmed = false;
  pendingTurns = /* @__PURE__ */ new Map();
  // How many pending turns wrote each position. Kept in step with
  // `pendingTurns` at its only three mutation sites, so asking whether a
  // settlement may forget a descriptor is O(1) rather than a rebuild of every
  // pending turn's positions (which made settling P overlapping turns O(P^2)).
  pendingPositionCounts = /* @__PURE__ */ new Map();
  nextTurnId = 1;
  queuedEvidence = /* @__PURE__ */ new Map();
  /**
   * TX-LEDGER C3 — later effects that are NOT authored turns.
   *
   * Rollback safety asks "has anything since relied on the structure I am about
   * to invalidate?". That question is about causal DEPENDENCE, not authorship,
   * and the old answer came only from `confirmedTurns` — which excludes
   * realizations by construction. So a server refresh landing on a speculative
   * row created no dependency and the rollback deleted the row the server had
   * just written to: RESTORE-P0 P0-C one layer up.
   *
   * Deliberately NOT a causal history:
   *
   *   recorded ONLY while a pending turn exists   nothing outstanding, nothing
   *                                               retained
   *   dropped when the last pending turn settles  no accumulation
   *   monotonic                                   a dependency latches; the
   *                                               later write being reversed by
   *                                               hand does not un-depend it
   *                                               (measured, case 4)
   *   sequence-scoped                             a turn only sees effects that
   *                                               landed after IT opened
   *
   * The sequence matters with two open transactions: an effect recorded before
   * the second opened is not "later" for the second, only for the first.
   */
  dependencyLedger = [];
  ledgerSeq = 0;
  sourceDependencies = /* @__PURE__ */ new Map();
  getSourceDependencyCountForTesting() {
    return this.sourceDependencies.size;
  }
  prepareSourceDependencies(revision, effects) {
    return { map: this.sourceDependencies, key: revision, value: effects };
  }
  pendingOpenedAtSeq = /* @__PURE__ */ new Map();
  buildTurn(subjectIds, positionIds, effects, baselineValues, reservedId) {
    if ((subjectIds?.length ?? 0) === 0 && (positionIds?.length ?? 0) === 0 && (effects?.length ?? 0) === 0) {
      return void 0;
    }
    return {
      id: reservedId ?? this.nextTurnId++,
      restorationSubjectIds: subjectIds ? [...subjectIds] : void 0,
      __positionIds: positionIds ? [...positionIds] : void 0,
      __effects: effects ? effects.map(cloneTurnEffect) : void 0,
      __baselineValues: baselineValues ? new Map(baselineValues) : void 0
    };
  }
  recordConfirmed(subjectIds, positionIds, effects) {
    const turn = this.buildTurn(subjectIds, positionIds, effects);
    if (!turn) {
      return void 0;
    }
    this.insertConfirmed(turn);
    this.releaseConfirmedBeyondObligation();
    return cloneTurnRecord(turn);
  }
  /**
   * Reserve a transaction's contribution order before anything can re-enter.
   *
   * The id used to be allocated at materialization, AFTER the post-callback
   * flush. A write made by an observer of the callback's own writes was then
   * recorded first, received the OLDER id, and was invisible to this turn's
   * rollback: `confirmedTurns.filter(t => t.id > pendingId)` excluded it, the
   * obligation bound could evict it, and an external write never entered the
   * dependency ledger because nothing was pending yet. Observed writes must
   * stay later than the transaction they observe.
   *
   * The placeholder owns no second ledger: its effects are a live view of the
   * open capture, so an older handle settled from inside this callback (or by
   * an observer before this handle exists) sees the writes captured so far.
   * `createPending` replaces it; `discardPending` releases it.
   */
  reservePending(bucket) {
    const id = this.nextTurnId++;
    this.pendingTurns.set(id, {
      id,
      get __effects() {
        return [
          ...bucket.effects.values(),
          ...bucket.entityFootprints.values()
        ];
      }
    });
    this.pendingOpenedAtSeq.set(id, this.ledgerSeq);
    return id;
  }
  createPending(reservedId, subjectIds, positionIds, effects, baselineValues) {
    const turn = this.buildTurn(
      subjectIds,
      positionIds,
      effects,
      baselineValues,
      reservedId
    );
    if (!turn) {
      this.discardPending(reservedId);
      return void 0;
    }
    this.pendingTurns.set(turn.id, turn);
    this.countPendingPositions(turn, 1);
    this.retainPendingClaims(turn.id, turn.restorationSubjectIds ?? []);
    return cloneTurnRecord(turn);
  }
  /**
   * Record a later effect for dependency purposes, whatever authored it.
   *
   * Returns immediately when nothing is pending, which is what keeps this a
   * projection rather than an inventory: with no outstanding rollback right
   * there is no question to answer and nothing is kept.
   *
   * @internal
   */
  observeLaterEffects(effects) {
    if (this.pendingTurns.size === 0 || effects.length === 0) {
      return;
    }
    this.ledgerSeq += 1;
    for (const effect of effects) {
      this.dependencyLedger.push({ seq: this.ledgerSeq, effect });
    }
  }
  /** Drop the ledger once no pending turn can ask about it. */
  releaseLedgerIfQuiet() {
    if (this.pendingTurns.size === 0) {
      this.dependencyLedger = [];
      this.sourceDependencies.clear();
      this.ledgerSeq = 0;
      this.pendingOpenedAtSeq.clear();
    }
  }
  confirmPending(turnId) {
    const turn = this.pendingTurns.get(turnId);
    if (!turn) {
      return void 0;
    }
    this.pendingTurns.delete(turnId);
    this.countPendingPositions(turn, -1);
    this.pendingOpenedAtSeq.delete(turnId);
    this.queuedEvidence.delete(turnId);
    this.releasePendingClaims(turnId);
    this.insertConfirmed(turn);
    this.releaseLedgerIfQuiet();
    this.releaseConfirmedBeyondObligation();
    return cloneTurnRecord(turn);
  }
  discardPending(turnId) {
    const turn = this.pendingTurns.get(turnId);
    if (!turn) {
      return void 0;
    }
    this.pendingTurns.delete(turnId);
    this.countPendingPositions(turn, -1);
    this.pendingOpenedAtSeq.delete(turnId);
    this.queuedEvidence.delete(turnId);
    this.releasePendingClaims(turnId);
    this.releaseLedgerIfQuiet();
    this.releaseConfirmedBeyondObligation();
    return cloneTurnRecord(turn);
  }
  observeQueuedEffects(turnId, queued) {
    if (!this.pendingTurns.has(turnId)) return;
    let retained = this.queuedEvidence.get(turnId);
    if (!retained && queued.length) {
      retained = /* @__PURE__ */ new Map();
      this.queuedEvidence.set(turnId, retained);
    }
    for (const effect of queued) {
      retained?.set(
        JSON.stringify([
          effect.kind,
          effect.position,
          effect.subject ?? null,
          effect.kind === "set" ? effect.subjectFieldSegments ?? effect.path : effect.path
        ]),
        effect
      );
    }
  }
  getPendingRollbackPlan(turnId, queued = [], orderInterference) {
    this.observeQueuedEffects(turnId, queued);
    const pending2 = this.pendingTurns.get(turnId);
    if (pending2 && orderInterference)
      return {
        conflict: {
          kind: "effect-validation-failed",
          pendingTurnId: turnId,
          compensation: [],
          errorMessage: `Collection ordering conflict at ${orderInterference.ownerPath}: an independent order was admitted between this transaction's own order operations`
        }
      };
    const retained = this.queuedEvidence.get(turnId);
    for (const later of this.pendingTurns.values()) {
      if (later.id <= turnId) continue;
      for (const effect of pending2?.__effects ?? []) {
        const overlap = later.__effects?.find(
          (candidate) => candidate.position === effect.position && (candidate.subject === void 0 || effect.subject === void 0 || candidate.subject === effect.subject) && (candidate.kind === "set" && effect.kind === "set" ? scalarRelation(candidate, effect) !== "disjoint" : candidate.path === effect.path || candidate.path.startsWith(`${effect.path}.`) || effect.path.startsWith(`${candidate.path}.`)) || // A later pending membership change of an enclosing member
          // captured this location in its own before-image just the same.
          // (v16 integration 8b.)
          candidate.kind === "set" && candidate.plainBranchMembership !== void 0 && this.encloses?.(candidate.position, effect.position) === true || effect.kind === "set" && effect.plainBranchMembership?.before === false && effect.plainBranchMembership.after === true && this.encloses?.(effect.position, candidate.position) === true
        );
        if (overlap)
          return {
            conflict: {
              kind: "later-confirmed-dependency",
              pendingTurnId: turnId,
              pendingEffect: effect,
              conflictingTurnId: later.id,
              conflictingEffect: overlap
            }
          };
        if (effect.kind === "rekey") {
          const occupant = later.__effects?.find(
            (candidate) => candidate.kind === "add" && candidate.ownerPath === effect.ownerPath && candidate.key === effect.beforeKey && candidate.subject !== effect.subject
          );
          if (occupant)
            return {
              conflict: {
                kind: "later-confirmed-dependency",
                pendingTurnId: turnId,
                pendingEffect: effect,
                conflictingTurnId: later.id,
                conflictingEffect: occupant
              }
            };
        }
      }
    }
    const authoredLater = this.confirmedTurns.filter((turn) => turn.id > turnId).flatMap(
      (turn) => (turn.__effects ?? []).map((effect) => ({ turnId: turn.id, effect }))
    );
    const openedAt = this.pendingOpenedAtSeq.get(turnId) ?? 0;
    const observedLater = this.dependencyLedger.filter((entry) => entry.seq > openedAt).map((entry) => ({
      entry: { turnId, effect: entry.effect },
      seq: entry.seq
    }));
    const ordered = [
      ...authoredLater.map((entry) => ({
        entry,
        seq: this.confirmedAtSeq.get(entry.turnId) ?? 0
      })),
      ...observedLater
    ].sort((a, b) => a.seq - b.seq).map((wrapped) => wrapped.entry);
    return buildPendingRollbackPlan(
      this.pendingTurns.get(turnId),
      [
        ...ordered,
        ...[...this.sourceDependencies.values()].flatMap(
          (effects) => effects.map((effect) => ({ turnId, effect }))
        ),
        ...[...retained?.values() ?? []].map((effect) => ({
          turnId,
          effect
        }))
      ],
      this.encloses
    );
  }
  setHistoryRetention(retain) {
    this.historyRetain = Number.isFinite(retain) && retain > 0 ? retain : 0;
    this.releaseConfirmedBeyondObligation();
  }
  /**
   * L15: correctness retention follows live responsibility.
   *
   * `getPendingRollbackPlan` is the ONLY correctness consumer of this ledger,
   * and it selects `confirmedTurns.filter(t => t.id > pendingId)`. Turn ids are
   * monotonic, so a confirmed turn can only ever be needed by a pending turn
   * OLDER than itself. Once no such pending turn remains, the record can never
   * appear in any future plan, and keeping it is diagnostics, not correctness.
   * (A `hasConfirmedTurnAfter` reader existed alongside it with no call sites
   * anywhere and was deleted, so it imposes no obligation either.)
   *
   * This is not an arbitrary cap: the bound is derived from the obligation.
   * `historyRetain` is a SEPARATE, explicitly requested evidence facility
   * layered on top of it.
   */
  releaseConfirmedBeyondObligation() {
    if (this.confirmedTurns.length === 0) return;
    let minPending = Infinity;
    for (const id of this.pendingTurns.keys()) {
      if (id < minPending) minPending = id;
    }
    const required = (turn) => turn.id > minPending;
    const before = this.confirmedTurns.length;
    if (this.historyRetain <= 0) {
      this.confirmedTurns = this.confirmedTurns.filter(required);
      if (this.confirmedTurns.length < before) this.evictedConfirmed = true;
      this.forgetStampsOutside();
      return;
    }
    const keep = /* @__PURE__ */ new Set();
    for (const turn of this.confirmedTurns)
      if (required(turn)) keep.add(turn.id);
    for (const turn of this.confirmedTurns.slice(-this.historyRetain))
      keep.add(turn.id);
    this.confirmedTurns = this.confirmedTurns.filter((t) => keep.has(t.id));
    if (this.confirmedTurns.length < before) this.evictedConfirmed = true;
    this.forgetStampsOutside();
  }
  /**
   * `confirmedAtSeq` is CORRECTNESS state — `getPendingRollbackPlan` reads it
   * to order `authoredLater` — so L15 binds it exactly as it binds the records
   * themselves. Bounding the array while letting the stamps accumulate left
   * ~50 B per settled turn growing linearly forever while the ledger reported
   * zero retained records, which made "correctness-only retention" only half
   * true.
   */
  forgetStampsOutside() {
    if (this.confirmedAtSeq.size === 0) return;
    const live = new Set(this.confirmedTurns.map((turn) => turn.id));
    for (const id of this.confirmedAtSeq.keys()) {
      if (!live.has(id)) this.confirmedAtSeq.delete(id);
    }
  }
  /** Explicit retention metadata for the reader. Never inferred from ids. */
  getConfirmedRetention() {
    return {
      truncated: this.evictedConfirmed,
      firstAvailableTurnId: this.confirmedTurns[0]?.id
    };
  }
  releaseConfirmedTurnsOnDestroy() {
    this.confirmedAtSeq.clear();
    this.confirmedTurns = [];
  }
  getConfirmedTurnCount() {
    return this.confirmedTurns.length;
  }
  getPendingTurn(turnId) {
    return turnId === void 0 ? void 0 : this.pendingTurns.get(turnId);
  }
  getPendingTurnCount() {
    return this.pendingTurns.size;
  }
  getConfirmedTurnIds() {
    return this.confirmedTurns.map((turn) => turn.id);
  }
  getPendingTurnIds() {
    return [...this.pendingTurns.keys()].sort((left, right) => left - right);
  }
  /** Whether a still-pending turn wrote this position; its rollback needs the realization. */
  isPositionPending(position) {
    return this.pendingPositionCounts.has(position);
  }
  countPendingPositions(turn, delta) {
    for (const position of new Set(turn.__positionIds ?? [])) {
      const next = (this.pendingPositionCounts.get(position) ?? 0) + delta;
      if (next > 0) this.pendingPositionCounts.set(position, next);
      else this.pendingPositionCounts.delete(position);
    }
  }
  /**
   * @internal Raw retained records, for the `/internals` read seam.
   *
   *     A PROJECTION ON THIS CLASS CANNOT BE TREE-SHAKEN.
   *
   * ⚠️ This used to be `readConfirmedTurns()`, which built the whole
   * `ConfirmedTurnView` here. Class methods are retained whenever the class is
   * instantiated, and the transactions enhancer always instantiates this one —
   * so every consumer of `transactions()` paid for the projection whether or
   * not any tool ever read it. Measured: +489 B minified / +161 B gzip against
   * a 100 B budget.
   *
   * The projection now lives in `internals.ts` and is pulled in only by a build
   * that imports `@signal-tree/kernel/internals`. What remains here is the
   * narrow accessor that cannot live anywhere else.
   */
  getConfirmedTurnRecords() {
    return this.confirmedTurns;
  }
  /**
   * When each confirmed turn entered the ledger, on the SAME clock the
   * dependency ledger uses. Without this, later-effects can only be ordered
   * within their own source.
   */
  confirmedAtSeq = /* @__PURE__ */ new Map();
  insertConfirmed(turn) {
    this.ledgerSeq += 1;
    this.confirmedAtSeq.set(turn.id, this.ledgerSeq);
    const insertIndex = this.confirmedTurns.findIndex(
      (candidate) => candidate.id > turn.id
    );
    if (insertIndex === -1) {
      this.confirmedTurns.push(turn);
    } else {
      this.confirmedTurns.splice(insertIndex, 0, turn);
    }
  }
};
function cloneTurnRecord(turn) {
  return {
    ...turn,
    restorationSubjectIds: turn.restorationSubjectIds ? [...turn.restorationSubjectIds] : void 0,
    __positionIds: turn.__positionIds ? [...turn.__positionIds] : void 0,
    __effects: turn.__effects ? turn.__effects.map(cloneTurnEffect) : void 0,
    __baselineValues: turn.__baselineValues ? new Map(turn.__baselineValues) : void 0
  };
}
function createCaptureBucket() {
  return {
    entityFootprints: /* @__PURE__ */ new Map(),
    ownWriteSeq: /* @__PURE__ */ new Map(),
    ownerPaths: /* @__PURE__ */ new Set(),
    subjectIds: /* @__PURE__ */ new Set(),
    positionIds: /* @__PURE__ */ new Set(),
    baselineValues: /* @__PURE__ */ new Map(),
    effects: /* @__PURE__ */ new Map(),
    occupancy: /* @__PURE__ */ new Map(),
    collectionOrders: /* @__PURE__ */ new Map()
  };
}
function getOrCreateInternalTransactionRuntime(tree) {
  const existing = tree[INTERNAL_TRANSACTION_RUNTIME];
  if (existing) {
    return existing;
  }
  const authority = new TransactionAuthority(
    (turnId, subjectIds) => {
      if (subjectIds.length === 0) {
        return;
      }
      getOrCreateSubjectRestorationClaims(tree)?.retain(
        `transaction:${turnId}`,
        subjectIds
      );
    },
    (turnId) => {
      getOrCreateSubjectRestorationClaims(tree)?.release(
        `transaction:${turnId}`
      );
    },
    // Structured addresses, never display paths: `outer` encloses `inner`
    // when its address is a strict prefix of inner's.
    (outer, inner) => {
      const registry = getPositionRegistry(tree.$);
      const prefix = registry?.addressFor(outer);
      const address = registry?.addressFor(inner);
      return !!prefix && !!address && prefix.length < address.length && prefix.every((key, index) => key === address[index]);
    }
  );
  const transactionOwnerToken = {};
  let nextTransactionId = 1;
  let destroyed = false;
  const isRestoring = false;
  let selfDirty = false;
  let unsubscribeFlush = null;
  let unsubscribeNotifications = null;
  let unsubscribeEnqueue = null;
  let unsubscribeReset = null;
  let unsubscribeCollectionOrders = null;
  let restoreLeafInterceptors = null;
  const pendingCapture = createCaptureBucket();
  const pendingTransactions = /* @__PURE__ */ new Map();
  const callbackExternalEffects = /* @__PURE__ */ new Map();
  let sourceRevision = 0;
  const sourceSegments = /* @__PURE__ */ new Map();
  const sourceAdmissions = /* @__PURE__ */ new Map();
  let pairedEntityAdmissions = /* @__PURE__ */ new WeakMap();
  const unpairedEntityMetadata = (meta) => {
    const changes = getEntityOrdinaryChanges(meta);
    return changes === void 0 ? meta : withEntityOrdinaryChanges(
      meta,
      changes.filter((change) => !pairedEntityAdmissions.has(change))
    );
  };
  const sourceLifetimeKey = (effect) => `${effect.position}:${effect.subject ?? ""}`;
  let inspectionSeq = 0;
  let inspectionUnavailable = false;
  const inspectionWrites = /* @__PURE__ */ new Map();
  const inspectionTransactionByTurn = /* @__PURE__ */ new Map();
  let registerEnqueueObserver = null;
  let enqueueReleaseScheduled = false;
  const ensureEnqueueObserver = () => {
    if (!unsubscribeEnqueue && !destroyed) registerEnqueueObserver?.();
  };
  const releaseEnqueueObserverWhenIdle = () => {
    if (enqueueReleaseScheduled || !unsubscribeEnqueue) return;
    enqueueReleaseScheduled = true;
    queueMicrotask(() => {
      enqueueReleaseScheduled = false;
      if (authority.getPendingTurnCount() || pendingTransactions.size) return;
      unsubscribeEnqueue?.();
      unsubscribeEnqueue = null;
    });
  };
  const releaseInspectionIfQuiet = () => {
    if (authority.getPendingTurnCount() || pendingTransactions.size) return;
    inspectionWrites.clear();
    sourceSegments.clear();
    sourceAdmissions.clear();
    pairedEntityAdmissions = /* @__PURE__ */ new WeakMap();
    inspectionTransactionByTurn.clear();
    transactionOrderAdmissions.clear();
    inspectionSeq = 0;
    inspectionUnavailable = false;
    releaseEnqueueObserverWhenIdle();
  };
  const pendingOrderDeltas = /* @__PURE__ */ new Map();
  let orderAdmission = 0;
  const transactionOrderAdmissions = /* @__PURE__ */ new Map();
  const orderInterferenceFor = (transactionId) => {
    for (const admission of transactionOrderAdmissions.get(transactionId)?.values() ?? [])
      if (admission.conflict) return admission.conflict;
    return void 0;
  };
  const pendingCreatedListeners = /* @__PURE__ */ new Set();
  const pendingConfirmedListeners = /* @__PURE__ */ new Set();
  const pendingDiscardedListeners = /* @__PURE__ */ new Set();
  const lifecycleViews = /* @__PURE__ */ new Map();
  const lifecycleScopes = /* @__PURE__ */ new Set();
  const consequencesReleased = (transactionId) => lifecycleScopes.has(transactionId) && !isCommitScopeOpen(transactionOwnerToken, transactionId);
  let lifecycleSequence = 0;
  let lifecycleObserver;
  const lifecycleRegistry = getPositionRegistry(tree.$);
  if (lifecycleRegistry)
    defineTransactionLifecycleSource(lifecycleRegistry, {
      treeId: lifecycleRegistry.id,
      read: () => ({
        sequence: lifecycleSequence,
        pending: [...lifecycleViews.values()].map(
          ({ transactionId, phase }) => ({
            transactionId,
            phase,
            consequencesReleased: consequencesReleased(transactionId)
          })
        )
      }),
      attach: (observer) => {
        lifecycleObserver = observer;
      }
    });
  if (lifecycleRegistry)
    register(
      lifecycleRegistry.id,
      { read: () => ({ pending: [...lifecycleViews.values()] }) },
      transactionOwnerToken
    );
  const publishLifecycle = (fact) => {
    transition(lifecycleRegistry?.id, fact);
    lifecycleSequence++;
    lifecycleObserver?.record(fact);
  };
  const holdLifecycle = () => lifecycleObserver?.hold();
  const retireLifecycleView = (transactionId) => {
    lifecycleViews.delete(transactionId);
    lifecycleScopes.delete(transactionId);
  };
  const abandonLifecycleView = (transactionId) => {
    if (!lifecycleViews.has(transactionId)) return;
    transition(lifecycleRegistry?.id, {
      kind: "abandoned",
      transactionId
    });
    retireLifecycleView(transactionId);
    lifecycleSequence++;
  };
  const publishRefusal = (transactionId, error) => publishLifecycle({ kind: "refused", transactionId, error });
  const realizationTree = tree;
  const treeWrapper = tree;
  const stateRoot = tree.$;
  const realizationDescriptors = getTreeRealizationDescriptors(stateRoot) ?? getTreeRealizationDescriptors(treeWrapper) ?? /* @__PURE__ */ new Map();
  defineTreeRealizationDescriptors(treeWrapper, realizationDescriptors);
  defineTreeRealizationDescriptors(stateRoot, realizationDescriptors);
  const realizationPort = getTreeRealizationPort(stateRoot) ?? getTreeRealizationPort(treeWrapper) ?? createTreeRealizationAdapter({
    tree: realizationTree,
    descriptors: realizationDescriptors
  });
  defineTreeRealizationPort(treeWrapper, realizationPort);
  defineTreeRealizationPort(stateRoot, realizationPort);
  let windowWriteSeq = 0;
  const lastWindowWriteSeq = /* @__PURE__ */ new Map();
  const lastWindowRowWriteSeq = /* @__PURE__ */ new Map();
  const windowKeys = (positionIds, subjectIds) => {
    const keys = [];
    for (const position of positionIds ?? []) {
      if (subjectIds && subjectIds.length > 0) {
        for (const subject of subjectIds) keys.push(`${position}:${subject}`);
      } else {
        keys.push(String(position));
      }
    }
    return keys;
  };
  const recordWindowWrite = (positionIds, subjectIds) => {
    const seq = ++windowWriteSeq;
    for (const key of windowKeys(positionIds, subjectIds)) {
      lastWindowWriteSeq.set(key, seq);
      const colon = key.indexOf(":");
      if (colon !== -1) {
        lastWindowRowWriteSeq.set(Number(key.slice(0, colon)), seq);
      }
    }
  };
  const writtenSinceBy = (bucket) => {
    for (const [key, own] of bucket.ownWriteSeq) {
      const colon = key.indexOf(":");
      const position = colon === -1 ? key : key.slice(0, colon);
      if ((lastWindowWriteSeq.get(key) ?? 0) > own) return true;
      if ((lastWindowWriteSeq.get(position) ?? 0) > own) return true;
      if (colon === -1 && (lastWindowRowWriteSeq.get(Number(position)) ?? 0) > own) {
        return true;
      }
    }
    return false;
  };
  const releaseWindowIfClosed = () => {
    if (pendingTransactions.size === 0) {
      lastWindowWriteSeq.clear();
      lastWindowRowWriteSeq.clear();
    }
  };
  const forgetUnclaimedDescriptorSubjects = (subjectIds, descriptorOwnersBefore, ownPositions = []) => {
    if (subjectIds.length === 0 && ownPositions.length === 0) return;
    const claims = getSubjectRestorationClaims(tree);
    const unclaimed = [...new Set(subjectIds)].filter((subjectId) => {
      if (claims?.isClaimed(subjectId)) return false;
      for (const bucket of pendingTransactions.values())
        if (bucket.subjectIds.has(subjectId)) return false;
      return true;
    });
    forgetSubjectsInTreeRealizationDescriptors(
      realizationDescriptors,
      unclaimed
    );
    const neededByPending = (owner) => {
      if (authority.isPositionPending(owner)) return true;
      for (const bucket of pendingTransactions.values())
        if (bucket.positionIds.has(owner)) return true;
      return false;
    };
    for (const owner of new Set(ownPositions)) {
      if (descriptorOwnersBefore?.has(owner)) {
        continue;
      }
      const descriptor = realizationDescriptors.get(owner);
      if (descriptor && (descriptor.subjectDescriptors?.size ?? 0) === 0 && (descriptor.structuralEffects?.size ?? 0) === 0 && (descriptor.structuralEffectBySubject?.size ?? 0) === 0 && !neededByPending(owner)) {
        realizationDescriptors.delete(owner);
      }
    }
  };
  const notifyListeners = (listeners2, turn) => {
    const payload = cloneTurnRecord(turn);
    for (const listener of listeners2) {
      try {
        listener(payload);
      } catch (error) {
        reportContainedObserverError({
          error,
          operation: "transaction:listener",
          treeId: getPositionRegistry(tree.$)?.id
        });
      }
    }
  };
  const drainCaptureBucket = (bucket) => {
    const ownerPaths = Array.from(bucket.ownerPaths).sort();
    bucket.ownerPaths.clear();
    bucket.ownWriteSeq.clear();
    bucket.entityFootprints.clear();
    const subjectIds = Array.from(bucket.subjectIds).sort((a, b) => a - b);
    bucket.subjectIds.clear();
    const positionIds = Array.from(bucket.positionIds).sort((a, b) => a - b);
    bucket.positionIds.clear();
    const baselineValues = new Map(bucket.baselineValues);
    bucket.baselineValues.clear();
    const effects = settleTurnMemberEffects(
      tree.$,
      Array.from(bucket.effects.values()).filter(Boolean).map(cloneTurnEffect)
    );
    bucket.effects.clear();
    bucket.occupancy.clear();
    const collectionOrders = Array.from(bucket.collectionOrders.values()).map(
      (order) => ({
        ...order,
        beforeSubjects: [...order.beforeSubjects],
        afterSubjects: [...order.afterSubjects]
      })
    );
    bucket.collectionOrders.clear();
    return {
      ownerPaths,
      subjectIds,
      positionIds,
      baselineValues,
      effects,
      collectionOrders
    };
  };
  const rememberBaselineValue = (bucket, effect) => {
    if (!bucket.baselineValues.has(effect.position)) {
      switch (effect.kind) {
        case "set":
          bucket.baselineValues.set(effect.position, effect.before);
          break;
        case "add":
          bucket.baselineValues.set(effect.position, void 0);
          break;
        case "remove":
          bucket.baselineValues.set(effect.position, effect.key);
          break;
        case "rekey":
          bucket.baselineValues.set(effect.position, effect.beforeKey);
          break;
      }
    }
  };
  const effectKey = (effect) => {
    switch (effect.kind) {
      case "set":
        return JSON.stringify([
          effect.kind,
          effect.position,
          effect.subject,
          effect.subjectFieldSegments ?? effect.path
        ]);
      // RESTORE-P0 P0-B: keyed by SUBJECT, deliberately without `kind`, so the
      // transaction's effects on one subject collide and can be composed into
      // the NET effect. With `kind` in the key, `rekey('a','a2')` and
      // `removeOne('a2')` occupied separate slots and rollback applied both
      // inverses, returning the row under the name it had been renamed TO.
      // Mirrors the same repair in restoration.ts.
      case "remove":
      case "add":
      case "rekey":
        return `structural\0${effect.ownerPath}\0${effect.position}\0${effect.subject}`;
    }
  };
  const captureKey = (effect) => {
    const identity = identityOf(effect);
    return identity ? `${effectKey(effect)}\0segment:${identity.segment}` : effectKey(effect);
  };
  const enqueueEffect = (bucket, effectMap, effect) => {
    const key = captureKey(effect);
    const identity = identityOf(effect);
    if (effect.kind !== "set") {
      const previous = bucket.occupancy.get(key);
      const state2 = composeOccupancy(previous, effect);
      const normalized = occupancyEffect(state2);
      if (normalized && identity) identify(normalized, identity);
      if (effect.kind === "add" && previous?.beforeKey !== void 0 && previous.latestRemoval) {
        const fields = createCaptureBucket();
        captureEffects(
          fields,
          fields.effects,
          effect.path,
          effect.value,
          previous.latestRemoval.value,
          void 0,
          effect.ownerPath,
          [effect.subject],
          [effect.position]
        );
        for (const field of fields.effects.values()) {
          if (field.kind !== "set")
            throw new Error("Invalid rebind field fact");
          if (identity) identify(field, identity);
          bucket.derivedFields?.push(cloneTurnEffect(field));
          enqueueEffect(bucket, effectMap, field);
        }
      }
      bucket.occupancy.set(key, state2);
      if (effectMap !== bucket.entityFootprints)
        rememberBaselineValue(bucket, effect);
      if (normalized) effectMap.set(key, normalized);
      else effectMap.delete(key);
      return;
    }
    let existing2 = effectMap.get(key);
    if (!existing2 && bucket.priorEffects) {
      const prior = bucket.priorEffects.get(key);
      if (prior) {
        existing2 = cloneTurnEffect(prior);
        effectMap.set(key, existing2);
      }
    }
    if (existing2) {
      if (existing2.kind === "set" && effect.kind === "set") {
        if (identity) identify(existing2, identity);
        if (!composePlainBranchMemberEffect(existing2, effect)) {
          existing2.after = effect.after;
          const beforePresent = existing2.fieldPresence?.before ?? true;
          const afterPresent = effect.fieldPresence?.after ?? true;
          if (beforePresent && afterPresent) delete existing2.fieldPresence;
          else
            existing2.fieldPresence = {
              before: beforePresent,
              after: afterPresent
            };
        }
        existing2.mutationIntent = combineScalarMutationIntent(
          existing2.mutationIntent,
          effect.mutationIntent
        );
        if (effectMap === bucket.entityFootprints && plainBranchMemberEffectIsNoop(existing2) && (existing2.fieldPresence?.before ?? true) === (existing2.fieldPresence?.after ?? true)) {
          effectMap.delete(key);
        }
        return;
      }
      return;
    }
    if (effectMap !== bucket.entityFootprints) {
      rememberBaselineValue(bucket, effect);
    }
    effectMap.set(key, effect);
  };
  const buildTurnEffectFromStructural = (meta, ownerPath, path, positionIds, subjectIds) => {
    const position = positionIds?.[0];
    const subject = subjectIds?.[0];
    if (position === void 0 || subject === void 0) {
      return void 0;
    }
    const effect = meta?.structuralEffect;
    if (!effect || effect.subject !== subject) {
      return void 0;
    }
    return {
      ...effect,
      ownerPath,
      path,
      position
    };
  };
  const isPlainRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value) && !(value instanceof Date) && !(value instanceof Map) && !(value instanceof Set);
  const captureEffects = (bucket, effectMap, path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
    if (getEntityOrdinaryChanges(meta) !== void 0) {
      for (const entry of ordinaryEntityEntries({
        path,
        newValue: next,
        oldValue: prev,
        meta,
        subjectIds
      })) {
        captureEffects(
          bucket,
          effectMap,
          entry.path,
          entry.newValue,
          entry.oldValue,
          entry.meta,
          ownerPath,
          entry.subjectIds,
          positionIds
        );
      }
      return;
    }
    const membership = plainBranchMembershipEffects(meta);
    if (membership) {
      for (const effect of membership) {
        bucket.positionIds.add(effect.position);
        enqueueEffect(bucket, effectMap, effect);
      }
      return;
    }
    const structuralEffect = ownerPath ? buildTurnEffectFromStructural(
      meta,
      ownerPath,
      path,
      positionIds,
      subjectIds
    ) : void 0;
    if (structuralEffect) {
      enqueueEffect(bucket, effectMap, structuralEffect);
      return;
    }
    if (next === void 0 && prev === void 0) {
      return;
    }
    if (isPlainRecord(next) && isPlainRecord(prev) && !(!subjectIds?.length && positionIds?.[0] !== void 0 && (getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$))?.resolveScalarSlot(positionIds[0]) !== void 0)) {
      const position2 = positionIds?.[0];
      const subject = subjectIds?.[0];
      if (position2 === void 0) {
        return;
      }
      const keys = /* @__PURE__ */ new Set([...Object.keys(prev), ...Object.keys(next)]);
      for (const key of keys) {
        const before = prev[key];
        const after = next[key];
        const beforePresent = Object.prototype.hasOwnProperty.call(prev, key);
        const afterPresent = Object.prototype.hasOwnProperty.call(next, key);
        if (before === after && beforePresent === afterPresent) {
          continue;
        }
        enqueueEffect(bucket, effectMap, {
          kind: "set",
          path: `${path}.${key}`,
          ownerPath: ownerPath ?? path,
          position: position2,
          subject,
          subjectFieldSegments: subject === void 0 ? void 0 : [key],
          ...subject !== void 0 && !(beforePresent && afterPresent) ? { fieldPresence: { before: beforePresent, after: afterPresent } } : {},
          before,
          after,
          mutationIntent: meta?.mutationIntent
        });
      }
      return;
    }
    const position = positionIds?.[0];
    if (position === void 0 || prev === next) {
      return;
    }
    enqueueEffect(bucket, effectMap, {
      kind: "set",
      path,
      ownerPath: ownerPath ?? path,
      position,
      subject: subjectIds?.[0],
      before: prev,
      after: next,
      mutationIntent: meta?.mutationIntent
    });
  };
  const inspectPendingTurn = (turnId) => {
    if (inspectionUnavailable)
      throw new Error(
        "SignalTree: pending inspection unavailable because mutation chronology capture failed."
      );
    const turn = authority.getPendingTurn(turnId);
    if (!turn) return void 0;
    const effects = [
      ...new Map(
        (turn.__effects ?? []).map((effect) => [effectKey(effect), effect])
      ).values()
    ];
    const transactionId = inspectionTransactionByTurn.get(turnId);
    const own = inspectionWrites.get(transactionId);
    const later = /* @__PURE__ */ new Set();
    for (const effect of effects) {
      const authored = own?.get(captureKey(effect));
      if (!authored) {
        inspectionUnavailable = true;
        throw new Error(
          "SignalTree: pending inspection unavailable because an authored contribution has no mutation chronology."
        );
      }
      for (const [writer, writes] of inspectionWrites) {
        if (writer === transactionId) continue;
        for (const candidate of writes.values()) {
          if (identityOf(effect) && identityOf(candidate.effect) ? !isLaterAdmission(effect, candidate.effect) : candidate.seq <= authored.seq)
            continue;
          const other = candidate.effect;
          if (other.position !== effect.position || other.subject !== effect.subject)
            continue;
          if (effect.kind === "set") {
            if (other.kind === "remove" || other.kind === "set" && scalarRelation(other, effect) === "same")
              later.add(candidate);
          } else if (other.kind !== "set") later.add(candidate);
        }
      }
    }
    return {
      effects,
      laterEffects: [...later].sort((a, b) => a.seq - b.seq).map(({ effect }) => cloneTurnEffect(effect))
    };
  };
  const observeOpenEntityCapture = (transactionId, bucket) => getMutationCaptureRuntime(tree)?.subscribeCommittedEntity?.((capture) => {
    if (capture.meta?.origin === "transaction-rollback" || capture.meta?.origin === "restoration" || isInspectionWrite(capture.meta) || getWriteParticipation(capture.meta) === "realized" || resolveTransactionId(capture.meta) !== transactionId)
      return;
    for (const change of capture.changes) {
      bucket.subjectIds.add(change.subject);
      if (change.structural) {
        const effect = {
          kind: "set",
          position: capture.owner,
          ownerPath: capture.ownerPath,
          path: capture.ownerPath,
          subject: change.subject,
          subjectFieldSegments: [],
          before: change.before,
          after: change.after
        };
        bucket.entityFootprints.set(effectKey(effect), effect);
      } else {
        captureEffects(
          bucket,
          bucket.entityFootprints,
          capture.ownerPath,
          change.after,
          change.before,
          withoutEntityOrdinaryChanges(capture.meta),
          capture.ownerPath,
          [change.subject],
          [capture.owner]
        );
      }
    }
  });
  const installedOperations = /* @__PURE__ */ new Map();
  const expectedDispositions = /* @__PURE__ */ new Map();
  tree.registerCleanup(() => {
    installedOperations.clear();
    expectedDispositions.clear();
  });
  const sourceCaptureRuntime = getMutationCaptureRuntime(tree);
  if (sourceCaptureRuntime) {
    sourceCaptureRuntime.prepareMemberResponsibility = (branch, key, child) => {
      const meta = getActiveWriteContext();
      const id = resolveTransactionId(meta);
      if (id === void 0 || isRestoring || isInspectionWrite(meta) || getWriteParticipation(meta) === "realized" || meta?.origin === "restoration" || meta?.origin === "transaction-rollback")
        return;
      const prepared = prepareNewMemberResponsibility(branch, key, child);
      if (!prepared) return;
      const { effect, address } = prepared;
      const bucket = getTransactionBucket(id);
      const previous = installedOperations.get(id);
      const operation = {
        sequence: (previous?.sequence ?? -1) + 1,
        owner: effect.position,
        effects: [cloneTurnEffect(effect)],
        previous,
        owners: previous?.owners ?? /* @__PURE__ */ new Set()
      };
      return {
        writes: [
          address,
          { map: bucket.effects, key: effectKey(effect), value: effect },
          {
            map: bucket.baselineValues,
            key: effect.position,
            value: void 0
          },
          { map: installedOperations, key: id, value: operation }
        ],
        adds: [
          { set: operation.owners, value: effect.position },
          { set: bucket.positionIds, value: effect.position },
          { set: bucket.ownerPaths, value: effect.ownerPath }
        ]
      };
    };
    sourceCaptureRuntime.prepareEntityResponsibility = (capture) => {
      const id = getWriteParticipation(capture.meta) === "realized" ? void 0 : resolveTransactionId(capture.meta);
      if (isRestoring || isInspectionWrite(capture.meta) || capture.meta?.origin === "transaction-rollback" || capture.meta?.origin === "restoration")
        return;
      if (id === void 0 && !pendingTransactions.size && !authority.getPendingTurnCount())
        return;
      const bucket = id === void 0 ? createCaptureBucket() : getTransactionBucket(id);
      const scratch = createCaptureBucket();
      scratch.priorEffects = bucket.effects;
      scratch.derivedFields = [];
      const effects = [];
      for (const change of capture.changes) {
        const path = change.path;
        if (path === void 0)
          throw new Error("Entity responsibility has no mutation path");
        if (change.structuralRecord)
          effects.push({
            ...change.structuralRecord,
            position: capture.owner,
            ownerPath: capture.ownerPath,
            path
          });
        else if (!isPlainRecord(change.before) || !isPlainRecord(change.after)) {
          if (change.before !== change.after)
            effects.push({
              kind: "set",
              position: capture.owner,
              ownerPath: capture.ownerPath,
              path,
              subject: change.subject,
              before: change.before,
              after: change.after,
              mutationIntent: capture.meta?.mutationIntent
            });
        } else {
          const before = change.before, after = change.after;
          for (const key of /* @__PURE__ */ new Set([
            ...Object.keys(before),
            ...Object.keys(after)
          ])) {
            const beforeValue = before[key], afterValue = after[key];
            const beforePresent = Object.prototype.hasOwnProperty.call(
              before,
              key
            ), afterPresent = Object.prototype.hasOwnProperty.call(after, key);
            if (beforeValue === afterValue && beforePresent === afterPresent)
              continue;
            effects.push({
              kind: "set",
              position: capture.owner,
              ownerPath: capture.ownerPath,
              path: `${path}.${key}`,
              subject: change.subject,
              subjectFieldSegments: [key],
              before: beforeValue,
              after: afterValue,
              mutationIntent: capture.meta?.mutationIntent,
              ...!(beforePresent && afterPresent) ? {
                fieldPresence: {
                  before: beforePresent,
                  after: afterPresent
                }
              } : {}
            });
          }
        }
      }
      const revision = ++sourceRevision;
      const segmentWrites = /* @__PURE__ */ new Map();
      for (const effect of effects) {
        const key = sourceLifetimeKey(effect);
        const previous2 = segmentWrites.get(key) ?? sourceSegments.get(key);
        const segment = previous2 && id !== void 0 && previous2.writer === id ? previous2.segment : revision;
        identify(effect, { revision, segment });
        segmentWrites.set(key, { writer: id, segment });
      }
      const admissionWrites = [
        { map: sourceAdmissions, key: capture.owner, value: effects },
        ...capture.changes.map((change) => ({
          map: pairedEntityAdmissions,
          key: change,
          value: Object.freeze({
            revision,
            segment: segmentWrites.get(`${capture.owner}:${change.subject}`)?.segment ?? revision
          })
        })),
        ...[...segmentWrites].map(([key, value]) => ({
          map: sourceSegments,
          key,
          value
        }))
      ];
      const sequence = ++inspectionSeq;
      let footprints = inspectionWrites.get(id);
      if (!footprints) {
        footprints = /* @__PURE__ */ new Map();
        admissionWrites.push({
          map: inspectionWrites,
          key: id,
          value: footprints
        });
      }
      for (const effect of effects) {
        const footprint = effect.kind === "set" ? { ...effect, before: void 0, after: void 0 } : effect.kind === "rekey" ? { ...effect } : { ...effect, value: void 0 };
        admissionWrites.push({
          map: footprints,
          key: captureKey(effect),
          value: { seq: sequence, effect: footprint }
        });
      }
      if (id === void 0) {
        admissionWrites.push(
          authority.prepareSourceDependencies(revision, effects)
        );
        for (const transactionId of pendingTransactions.keys())
          admissionWrites.push({
            map: callbackExternalEffects,
            key: transactionId,
            value: [
              ...callbackExternalEffects.get(transactionId) ?? [],
              ...effects
            ]
          });
        return { writes: admissionWrites, adds: [] };
      }
      const touchedKeys = new Set(effects.map(captureKey));
      for (const key of touchedKeys) {
        const prior = bucket.effects.get(key);
        if (prior) scratch.effects.set(key, cloneTurnEffect(prior));
        const occupancy = bucket.occupancy.get(key);
        if (occupancy) scratch.occupancy.set(key, occupancy);
      }
      for (const effect of effects) {
        if (bucket.baselineValues.has(effect.position))
          scratch.baselineValues.set(
            effect.position,
            bucket.baselineValues.get(effect.position)
          );
      }
      for (const effect of effects)
        enqueueEffect(scratch, scratch.effects, cloneTurnEffect(effect));
      const previous = installedOperations.get(id);
      const operation = {
        sequence: (previous?.sequence ?? -1) + 1,
        structuralFrontier: capture.structuralFrontier,
        owner: capture.owner,
        effects,
        previous,
        owners: previous?.owners ?? /* @__PURE__ */ new Set()
      };
      const writes = [
        ...admissionWrites,
        { map: installedOperations, key: id, value: operation }
      ];
      if (scratch.derivedFields.length) {
        const sequence2 = ++inspectionSeq;
        let footprints2 = inspectionWrites.get(id);
        if (!footprints2) {
          footprints2 = /* @__PURE__ */ new Map();
          writes.push({ map: inspectionWrites, key: id, value: footprints2 });
        }
        for (const field of scratch.derivedFields) {
          const footprint = {
            ...field,
            before: void 0,
            after: void 0
          };
          writes.push({
            map: footprints2,
            key: captureKey(field),
            value: { seq: sequence2, effect: footprint }
          });
        }
      }
      for (const key of touchedKeys)
        if (!scratch.effects.has(key))
          writes.push({ map: bucket.effects, key, value: void 0 });
      for (const [key, value] of scratch.effects)
        writes.push({ map: bucket.effects, key, value });
      for (const [key, value] of scratch.occupancy)
        writes.push({ map: bucket.occupancy, key, value });
      for (const [key, value] of scratch.baselineValues)
        writes.push({ map: bucket.baselineValues, key, value });
      if (pendingTransactions.size > 0)
        for (const key of windowKeys(
          [capture.owner],
          capture.changes.map((c) => c.subject)
        ))
          writes.push({ map: bucket.ownWriteSeq, key, value: windowWriteSeq });
      return {
        writes,
        adds: [
          { set: operation.owners, value: capture.owner },
          { set: bucket.positionIds, value: capture.owner },
          { set: bucket.ownerPaths, value: capture.ownerPath },
          ...capture.changes.map((c) => ({
            set: bucket.subjectIds,
            value: c.subject
          }))
        ]
      };
    };
    tree.registerCleanup(() => {
      delete sourceCaptureRuntime.prepareEntityResponsibility;
      delete sourceCaptureRuntime.prepareMemberResponsibility;
    });
  }
  const foldOperationDisposition = (id) => {
    const newest = installedOperations.get(id);
    if (!newest) return [];
    const records = new Array(newest.sequence + 1);
    let record = newest;
    for (let i = records.length - 1; i >= 0; i--) {
      if (!record || record.sequence !== i)
        throw new Error("Operation journal sequence gap");
      records[i] = record;
      record = record.previous;
    }
    if (record) throw new Error("Operation journal sequence gap");
    const expected = createCaptureBucket();
    for (const operation of records)
      for (const effect of operation.effects)
        enqueueEffect(expected, expected.effects, cloneTurnEffect(effect));
    return settleTurnMemberEffects(
      tree.$,
      [...expected.effects.values()].map(cloneTurnEffect)
    );
  };
  const validateOperationDisposition = (id, turnId) => {
    const folded = expectedDispositions.get(id);
    if (!folded?.length) return;
    const retained = authority.getPendingTurn(turnId)?.__effects ?? [];
    const indexed = new Map(
      retained.map((effect) => [captureKey(effect), effect])
    );
    for (const effect of folded) {
      const actual = indexed.get(captureKey(effect));
      const same = actual && actual.kind === effect.kind && [.../* @__PURE__ */ new Set([...Object.keys(effect), ...Object.keys(actual)])].every(
        (key) => {
          const expectedValue = effect[key];
          const actualValue = actual[key];
          const memberImage = (key === "before" || key === "after") && effect.kind === "set" && effect.plainBranchMembership !== void 0;
          return memberImage || key === "subjectFieldSegments" || key === "fieldPresence" || key === "plainBranchMembership" ? deepEqual(actualValue, expectedValue) : Object.is(actualValue, expectedValue);
        }
      );
      if (!same) {
        const refusal = createRollbackError({
          kind: "effect-validation-failed",
          pendingTurnId: turnId ?? id,
          compensation: [],
          errorMessage: "Installed operation lacks a matching settlement disposition"
        });
        publishRefusal(id, refusal);
        throw refusal;
      }
    }
  };
  const resolveOwnerPositionId = (ownerPath) => {
    if (!ownerPath) {
      return void 0;
    }
    const segments = ownerPath.split(".");
    let cursor = tree.$;
    for (const segment of segments) {
      if (!isTraversableNode(cursor)) {
        return void 0;
      }
      cursor = cursor[segment];
    }
    const resolved = cursor?.__positionIds?.[0];
    return typeof resolved === "number" ? resolved : void 0;
  };
  const captureIntoBucket = (bucket, path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
    const membership = plainBranchMembershipEffects(meta);
    const membershipTransaction = resolveTransactionId(meta);
    if (membership?.length && membershipTransaction !== void 0) {
      const previous = installedOperations.get(membershipTransaction);
      installedOperations.set(membershipTransaction, {
        sequence: (previous?.sequence ?? -1) + 1,
        owner: membership[0].position,
        effects: membership.map(cloneTurnEffect),
        previous,
        owners: previous?.owners ?? /* @__PURE__ */ new Set()
      });
    }
    if (membership) {
      for (const effect of membership) {
        bucket.positionIds.add(effect.position);
        bucket.ownerPaths.add(effect.ownerPath);
        if (pendingTransactions.size > 0) {
          for (const key of windowKeys([effect.position], void 0))
            bucket.ownWriteSeq.set(key, windowWriteSeq);
        }
        enqueueEffect(bucket, bucket.effects, effect);
      }
      return;
    }
    bucket.ownerPaths.add(ownerPath ?? path);
    for (const subjectId of subjectIds ?? []) {
      bucket.subjectIds.add(subjectId);
    }
    const resolvedPositionIds = positionIds && positionIds.length > 0 ? positionIds : (() => {
      const fallback = resolveOwnerPositionId(ownerPath);
      return fallback === void 0 ? [] : [fallback];
    })();
    for (const positionId of resolvedPositionIds) {
      bucket.positionIds.add(positionId);
    }
    if (pendingTransactions.size > 0) {
      for (const key of windowKeys(resolvedPositionIds, subjectIds)) {
        bucket.ownWriteSeq.set(key, windowWriteSeq);
      }
    }
    rememberTreeRealizationDescriptor({
      descriptors: realizationDescriptors,
      path,
      ownerPath,
      positionIds: resolvedPositionIds,
      subjectIds,
      meta,
      registry: getPositionRegistry(tree.$)
    });
    const recorded = resolveTransactionId(meta);
    if (recorded !== void 0 && subjectIds?.length && installedOperations.get(recorded)?.owners.has(resolvedPositionIds[0]))
      return;
    captureEffects(
      bucket,
      bucket.effects,
      path,
      next,
      prev,
      meta,
      ownerPath,
      subjectIds,
      resolvedPositionIds
    );
  };
  const recordConfirmedBucket = (bucket) => {
    const { subjectIds, positionIds, effects } = drainCaptureBucket(bucket);
    const turn = authority.recordConfirmed(
      subjectIds.length > 0 ? subjectIds : void 0,
      positionIds.length > 0 ? positionIds : void 0,
      effects.length > 0 ? effects : void 0
    );
    forgetUnclaimedDescriptorSubjects(subjectIds);
    return turn;
  };
  const getTransactionBucket = (transactionId) => {
    let bucket = pendingTransactions.get(transactionId);
    if (!bucket) {
      bucket = createCaptureBucket();
      pendingTransactions.set(transactionId, bucket);
    }
    return bucket;
  };
  const resolveTransactionId = (meta) => typeof meta?.transactionId === "number" && meta.transactionOwner === transactionOwnerToken ? meta.transactionId : void 0;
  unsubscribeCollectionOrders = getMutationCaptureRuntime(tree)?.subscribeCollectionOrder?.((capture) => {
    if (isInspectionWrite(capture.meta) || capture.meta?.origin === "restoration" || capture.meta?.origin === "transaction-rollback")
      return;
    const revision = ++orderAdmission;
    const transactionId = getWriteParticipation(capture.meta) === "realized" ? void 0 : resolveTransactionId(capture.meta);
    for (const [id, owners2] of transactionOrderAdmissions) {
      if (id === transactionId || !pendingTransactions.has(id)) continue;
      const prior2 = owners2.get(capture.owner);
      if (prior2) prior2.independentAfterOwn = revision;
    }
    if (transactionId === void 0) return;
    let owners = transactionOrderAdmissions.get(transactionId);
    if (!owners)
      transactionOrderAdmissions.set(transactionId, owners = /* @__PURE__ */ new Map());
    const prior = owners.get(capture.owner) ?? {};
    if (prior.independentAfterOwn !== void 0 && !prior.conflict)
      prior.conflict = Object.freeze({
        ownerPath: capture.ownerPath,
        independentAdmission: prior.independentAfterOwn,
        resumedOwnAdmission: revision
      });
    prior.independentAfterOwn = void 0;
    owners.set(capture.owner, prior);
    const bucket = getTransactionBucket(transactionId);
    const existing2 = bucket.collectionOrders.get(capture.owner);
    bucket.collectionOrders.set(capture.owner, {
      owner: capture.owner,
      ownerPath: capture.ownerPath,
      beforeSubjects: existing2?.beforeSubjects ?? [...capture.beforeSubjects],
      afterSubjects: [...capture.afterSubjects],
      beforeFrontier: existing2?.beforeFrontier ?? capture.beforeFrontier,
      afterFrontier: capture.afterFrontier,
      ordinaryEndpoints: capture.ordinaryEndpoints && (!existing2 || existing2.ordinaryEndpoints) ? Object.freeze({
        before: existing2?.ordinaryEndpoints?.before ?? capture.ordinaryEndpoints.before,
        after: capture.ordinaryEndpoints.after,
        domain: Object.freeze([
          .../* @__PURE__ */ new Set([
            ...existing2?.ordinaryEndpoints?.domain ?? capture.ordinaryEndpoints.domain ?? capture.ordinaryEndpoints.before,
            ...capture.ordinaryEndpoints.domain ?? capture.ordinaryEndpoints.after
          ])
        ])
      }) : void 0
    });
    bucket.ownerPaths.add(capture.ownerPath);
    bucket.positionIds.add(capture.owner);
  }) ?? null;
  const materializePendingTransaction = (transactionId, reservedId) => {
    const bucket = pendingTransactions.get(transactionId);
    pendingTransactions.delete(transactionId);
    releaseWindowIfClosed();
    if (!bucket) {
      authority.discardPending(reservedId);
      return void 0;
    }
    const dispositions = foldOperationDisposition(transactionId);
    expectedDispositions.set(transactionId, dispositions);
    const {
      subjectIds,
      positionIds: capturedPositionIds,
      effects,
      baselineValues,
      collectionOrders
    } = drainCaptureBucket(bucket);
    const preparedOwners = installedOperations.get(transactionId)?.owners;
    const slots = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
    const netPositions = /* @__PURE__ */ new Set([
      ...effects.map((effect) => effect.position),
      ...dispositions.map((effect) => effect.position),
      ...collectionOrders.map((order) => order.owner)
    ]);
    const positionIds = capturedPositionIds.filter(
      (position) => !preparedOwners?.has(position) || slots?.resolveScalarSlot(position) === void 0 || netPositions.has(position)
    );
    const pending2 = authority.createPending(
      reservedId,
      subjectIds.length > 0 ? subjectIds : void 0,
      positionIds.length > 0 ? positionIds : void 0,
      effects.length > 0 ? effects : void 0,
      baselineValues.size > 0 ? baselineValues : void 0
    );
    const externalEffects = callbackExternalEffects.get(transactionId) ?? [];
    callbackExternalEffects.delete(transactionId);
    if (pending2 && externalEffects.length) {
      authority.observeQueuedEffects(
        pending2.id,
        externalEffects.map(
          (effect) => effect.kind === "set" ? { ...effect, mutationIntent: "derive" } : effect
        )
      );
    }
    if (pending2 && collectionOrders.length > 0) {
      pendingOrderDeltas.set(
        pending2.id,
        collectionOrders.map(
          (order) => deriveCollectionOrderDelta(
            order.owner,
            order.beforeSubjects,
            order.afterSubjects,
            order.beforeFrontier,
            order.afterFrontier,
            order.ordinaryEndpoints
          )
        )
      );
    }
    return pending2;
  };
  const toCausalEffect = (effect) => {
    switch (effect.kind) {
      case "set":
        return {
          owner: effect.position,
          before: effect.before,
          after: effect.after,
          subjectId: effect.subject,
          subjectFieldSegments: effect.subjectFieldSegments,
          plainBranchMembership: effect.plainBranchMembership,
          fieldPresence: effect.fieldPresence,
          path: effect.path,
          ownerPath: effect.ownerPath
        };
      case "add":
        return {
          owner: effect.position,
          before: void 0,
          after: effect.key,
          subjectId: effect.subject,
          path: effect.path,
          ownerPath: effect.ownerPath,
          structural: "add",
          structuralContext: {
            kind: "add",
            subject: effect.subject,
            key: effect.key,
            value: effect.value,
            beforeSubject: effect.beforeSubject,
            afterSubject: effect.afterSubject
          }
        };
      case "remove":
        return {
          owner: effect.position,
          before: effect.key,
          after: void 0,
          subjectId: effect.subject,
          path: effect.path,
          ownerPath: effect.ownerPath,
          structural: "remove",
          structuralContext: {
            kind: "remove",
            subject: effect.subject,
            key: effect.key,
            value: effect.value,
            beforeSubject: effect.beforeSubject,
            afterSubject: effect.afterSubject
          }
        };
      case "rekey":
        return {
          owner: effect.position,
          before: effect.beforeKey,
          after: effect.afterKey,
          subjectId: effect.subject,
          path: effect.path,
          ownerPath: effect.ownerPath,
          structural: "rekey",
          structuralContext: {
            kind: "rekey",
            subject: effect.subject,
            beforeKey: effect.beforeKey,
            afterKey: effect.afterKey
          }
        };
    }
  };
  const toRollbackEffect = (effect) => {
    const causal = toCausalEffect(effect);
    return {
      ...causal,
      before: causal.after,
      after: causal.before,
      plainBranchMembership: causal.plainBranchMembership ? {
        before: causal.plainBranchMembership.after,
        after: causal.plainBranchMembership.before
      } : void 0,
      fieldPresence: causal.fieldPresence ? {
        before: causal.fieldPresence.after,
        after: causal.fieldPresence.before
      } : void 0,
      structural: causal.structural === "add" ? "remove" : causal.structural === "remove" ? "add" : causal.structural
    };
  };
  const compileSelectedCompensation = (selected) => {
    const compiled = [];
    const runs = /* @__PURE__ */ new Map();
    for (const effect of selected) {
      if (effect.kind === "set") {
        compiled.push(effect);
        continue;
      }
      const key = effectKey(effect);
      const before = effect.kind === "add" ? void 0 : effect.kind === "remove" ? effect.key : effect.beforeKey;
      const previous = runs.get(key);
      const continuous = previous && Object.is(previous.state.afterKey, before);
      const state2 = composeOccupancy(
        continuous ? previous.state : void 0,
        effect
      );
      if (continuous) {
        previous.state = state2;
        compiled[previous.index] = occupancyEffect(state2);
      } else {
        const index = compiled.length;
        runs.set(key, { index, state: state2 });
        compiled.push(occupancyEffect(state2));
      }
    }
    return compiled.filter(
      (effect) => effect !== void 0
    );
  };
  const compensatedFrontiers = (transactionId, effects, orderDeltas) => {
    if (!expectedDispositions.has(transactionId)) return /* @__PURE__ */ new Map();
    const intervals = /* @__PURE__ */ new Map();
    for (let operation = installedOperations.get(transactionId); operation; operation = operation.previous) {
      const interval = operation.structuralFrontier;
      if (!interval || interval.before === interval.after) continue;
      const newer = intervals.get(operation.owner);
      if (newer) {
        newer.valid &&= interval.after === newer.before;
        newer.before = interval.before;
      } else intervals.set(operation.owner, { ...interval, valid: true });
    }
    const expectedByOwner = /* @__PURE__ */ new Map();
    const actualByOwner = /* @__PURE__ */ new Map();
    const group = (source, into) => {
      for (const effect of source) {
        if (effect.kind === "set") continue;
        let entries = into.get(effect.position);
        if (!entries) into.set(effect.position, entries = /* @__PURE__ */ new Map());
        entries.set(effectKey(effect), effect);
      }
    };
    group(expectedDispositions.get(transactionId) ?? [], expectedByOwner);
    group(effects, actualByOwner);
    const orderedOwners = new Set(orderDeltas.map((delta) => delta.owner));
    const result = /* @__PURE__ */ new Map();
    for (const [owner, interval] of intervals) {
      if (!interval.valid || orderedOwners.has(owner)) continue;
      const expected = expectedByOwner.get(owner);
      const actual = actualByOwner.get(owner);
      if ((expected?.size ?? 0) !== (actual?.size ?? 0)) continue;
      let complete2 = true;
      for (const [key, effect] of expected ?? []) {
        const candidate = actual?.get(key);
        if (!candidate || candidate.kind !== effect.kind || candidate.subject !== effect.subject || (effect.kind === "rekey" && candidate.kind === "rekey" ? effect.beforeKey !== candidate.beforeKey || effect.afterKey !== candidate.afterKey : effect.kind !== "set" && effect.kind !== "rekey" && candidate.kind !== "set" && candidate.kind !== "rekey" ? effect.key !== candidate.key : true)) {
          complete2 = false;
          break;
        }
      }
      if (!complete2) continue;
      const binding = collectionBindingAt(tree.$, owner);
      if (binding?.installCompensatedOrderFrontier && binding.readOrderFrontier?.() === interval.after)
        result.set(owner, { ...interval, binding });
    }
    return result;
  };
  const installPreparedCompensation = (point, frontiers, completion) => {
    if (completion) completion.selected = true;
    for (const interval of frontiers.values())
      if (interval.binding.readOrderFrontier?.() !== interval.after)
        throw new Error(
          "Compensation structural frontier changed during preparation"
        );
    const releaseMembership = holdEntityMembershipDelivery(tree.$);
    try {
      point?.install();
      for (const interval of frontiers.values())
        interval.binding.installCompensatedOrderFrontier?.(interval.before);
      if (!point && frontiers.size)
        (getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree))?.advance();
      if (completion) completion.committed = true;
      point?.publish();
    } finally {
      releaseMembership();
    }
  };
  const rollbackPendingTarget = (effects, orderDeltas, completion, frontiers) => {
    if (completion) completion.selected = true;
    const preparationClock = getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree);
    const preparationRevision = preparationClock?.revision();
    const reversalEffects = placeFieldReversalsWhileRowsExist(
      ordinaryRealization(effects)?.ordinary ?? effects
    );
    const notifier = getPathNotifier();
    const treeOwnerId = getPositionRegistry(tree.$)?.id;
    const bindings2 = /* @__PURE__ */ new Map();
    visitTree(tree.$, (node) => {
      const binding = node.__prepareTransitionTarget;
      if (binding) {
        bindings2.set(binding.owner, binding);
      }
      return void 0;
    });
    const collectionOwners = /* @__PURE__ */ new Set([
      ...orderDeltas.map(({ owner }) => owner),
      ...reversalEffects.filter(({ subjectId }) => typeof subjectId === "number").map(({ owner }) => owner)
    ]);
    const collections = [...collectionOwners].map((owner) => {
      const binding = bindings2.get(owner) ?? collectionBindingAt(tree.$, owner);
      if (binding) bindings2.set(owner, binding);
      if (!binding) {
        throw new Error(
          `Transaction rollback has no collection binding ${owner}`
        );
      }
      return binding.readSource();
    });
    const physicalSources = new Map(
      collections.map((collection) => [
        collection.owner,
        new Map(collection.subjects.map((row) => [row.subject, row.key]))
      ])
    );
    const realized = prepareOrdinaryRealization(
      reversalEffects,
      (owner, subject) => physicalSources.get(owner)?.get(subject)
    );
    const derivedTarget = deriveDeclarativeTransitionTarget({
      collections,
      effects: realized.physical,
      orderDeltas,
      orderEndpoint: "before"
    });
    const admittedTarget = {
      ...derivedTarget,
      collections: new Map(
        [...derivedTarget.collections].map(([owner, collection]) => [
          owner,
          {
            ...collection,
            admittedEffects: reversalEffects.filter(
              (effect) => effect.owner === owner
            ),
            admittedOrder: (() => {
              const ordinary = orderDeltas.find(
                (delta) => delta.owner === owner
              )?.ordinaryEndpoints;
              return ordinary?.before.filter(
                (subject) => ordinary.domain === void 0 || ordinary.domain.includes(subject)
              );
            })()
          }
        ])
      )
    };
    const target = frontiers?.size ? {
      ...admittedTarget,
      collections: new Map(
        [...admittedTarget.collections].map(([owner, collection]) => {
          const interval = frontiers.get(owner);
          return [
            owner,
            interval ? { ...collection, orderFrontier: interval.before } : collection
          ];
        })
      )
    } : admittedTarget;
    const scalarSlotRuntime = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
    const scalarBinding = scalarSlotRuntime ? {
      prepareTarget(scalars) {
        const frame = scalarSlotRuntime.beginFrame();
        for (const [owner, value] of scalars) {
          const slot = scalarSlotRuntime.resolveScalarSlot(owner);
          if (slot === void 0) {
            frame.discard();
            throw new Error(
              `Transaction rollback has no scalar slot ${owner}`
            );
          }
          frame.set(slot, value);
        }
        const install = frame.prepareCommit ? frame.prepareCommit({
          advanceRevision: false,
          publish: false
        }) : () => frame.commit({ advanceRevision: false, publish: false });
        let result;
        return {
          install() {
            result = install();
          },
          publish() {
            if (!result) {
              throw new Error(
                "Transaction scalar published before installation"
              );
            }
            let failed = false;
            let first;
            try {
              scalarSlotRuntime.publishPrepared(result);
            } catch (error) {
              failed = true;
              first = error;
            }
            for (const effect of reversalEffects) {
              if (effect.subjectId !== void 0 || effect.plainBranchMembership || !scalars.has(effect.owner))
                continue;
              const descriptor = realizationDescriptors.get(effect.owner);
              const path = effect.path ?? descriptor?.ownerPath;
              if (!path) continue;
              try {
                notifier.notify(
                  path,
                  effect.after,
                  effect.before,
                  effect.ownerPath ?? descriptor?.ownerPath ?? path,
                  void 0,
                  [effect.owner],
                  {
                    ...getActiveWriteContext(),
                    intent: "system",
                    participation: "realized"
                  },
                  treeOwnerId
                );
              } catch (error) {
                if (!failed) {
                  failed = true;
                  first = error;
                }
              }
            }
            if (failed) throw first;
          }
        };
      }
    } : void 0;
    const prepared = prepareDeclarativeTransitionInstallation(
      target,
      bindings2,
      scalarBinding,
      {
        prepareTarget: (members) => preparePlainBranchMembers(tree.$, members)
      },
      {
        onCommitted() {
          for (const [owner, interval] of frontiers ?? [])
            if (!target.collections.has(owner))
              interval.binding.installCompensatedOrderFrontier?.(
                interval.before
              );
          if (completion) completion.committed = true;
        }
      }
    );
    const apply = () => {
      if (preparationClock?.revision() !== preparationRevision)
        throw new Error(
          "Compensation physical state changed during preparation"
        );
      for (const interval of frontiers?.values() ?? [])
        if (interval.binding.readOrderFrontier?.() !== interval.after)
          throw new Error(
            "Compensation structural frontier changed during preparation"
          );
      prepared.install();
    };
    const locations = getLocationRuntime(tree.$);
    const releaseMembership = holdEntityMembershipDelivery(tree.$);
    try {
      if (locations) {
        locations.runInvalidationGroup(apply);
      } else {
        apply();
      }
    } finally {
      releaseMembership();
    }
  };
  const applyRollbackCompensation = (transactionId, selectedEffects, baselineValues, orderDeltas = [], callbackError, owningTransactionId = transactionId, completion) => {
    const effects = compileSelectedCompensation(selectedEffects);
    const inverseEffects = placeFieldReversalsWhileRowsExist(
      [...effects].reverse().map(toRollbackEffect)
    );
    const frontiers = compensatedFrontiers(
      owningTransactionId,
      effects,
      orderDeltas
    );
    if (effects.length === 0 && orderDeltas.length === 0 && frontiers.size === 0) {
      return;
    }
    const ownRows = /* @__PURE__ */ new Map();
    for (const effect of effects)
      if (effect.kind !== "set" || effect.subject !== void 0) {
        let rows = ownRows.get(effect.position);
        if (!rows) ownRows.set(effect.position, rows = /* @__PURE__ */ new Set());
        rows.add(effect.subject);
      }
    for (const effect of effects) {
      if (effect.kind !== "set" || effect.plainBranchMembership?.before !== true || effect.plainBranchMembership.after)
        continue;
      const changed = changedOmittedCollection(
        tree.$,
        effect.position,
        (owner) => ownRows.get(owner) ?? /* @__PURE__ */ new Set(),
        (owner) => orderDeltas.some((delta) => delta.owner === owner)
      );
      if (changed !== void 0)
        throw createRollbackError({
          kind: "effect-validation-failed",
          pendingTurnId: transactionId,
          compensation: effects,
          errorMessage: `the entity collection at '${changed}' was omitted and changed after that, so re-adding it would not restore it as it was`,
          callbackError
        });
    }
    const positionRegistry = getPositionRegistry(tree.$);
    const authorityPosition = getOwnedPositionIds(tree.$)?.[0];
    if (!positionRegistry || authorityPosition === void 0) {
      throw createRollbackError({
        kind: "effect-validation-failed",
        pendingTurnId: transactionId,
        compensation: effects,
        errorMessage: "Transaction rollback requires tree realization infrastructure",
        callbackError
      });
    }
    const store = new TurnStore();
    store.admitPending({
      id: transactionId,
      effects: effects.map(toCausalEffect)
    });
    const appliedTurns = new AppliedTurnProjection(store);
    const realizationContext = createRealizationContextSource({
      baselineValues,
      store,
      appliedTurns
    });
    beginStructuralWrite();
    openPhysicalRows(positionRegistry);
    let result;
    let failed = true;
    try {
      result = publishingExposedOnly(
        tree.$,
        () => withWriteContext(
          {
            origin: "transaction-rollback",
            transactionId: owningTransactionId,
            // NOT `transactionOwner`. Stamping it here makes
            // `activeTransactionContext()` report an open scope during the
            // compensation, which reopens the callback scope a rollback must leave
            // closed — `active-transaction-context.spec.ts` pins that. The join
            // restoration needs is carried by `origin` plus the corrected
            // `transactionId` instead.
            // OWNER-REPLAY-1, same shape as restoration's: stamped once on the wrap
            // that already surrounds the compensation, so every downstream meta
            // that spreads `getActiveWriteContext()` carries the namespace.
            ownerId: positionRegistry?.id
          },
          () => {
            if (effects.length === 0 && orderDeltas.length === 0) {
              installPreparedCompensation(void 0, frontiers, completion);
              return { ok: true };
            }
            if (orderDeltas.length > 0 || requiresDeclarativeStructuralTarget(inverseEffects, (owner) => {
              let binding;
              visitTree(tree.$, (node) => {
                const candidate = node.__prepareTransitionTarget;
                if (candidate?.owner === owner) binding = candidate;
                return void 0;
              });
              return binding?.readSource();
            })) {
              rollbackPendingTarget(
                inverseEffects,
                orderDeltas,
                completion,
                frontiers
              );
              return { ok: true };
            }
            let preparedEffects;
            return rollbackPendingTurnAt({
              authority: authorityPosition,
              turnId: transactionId,
              store,
              topology: positionRegistry,
              realizationContext,
              selectedCompensation: inverseEffects,
              port: {
                validateEffects: (normalized) => {
                  preparedEffects = realizationPort.prepareOrdinaryEffects?.(normalized) ?? normalized;
                  return realizationPort.validateEffects?.(preparedEffects);
                },
                applyAtomically(normalized) {
                  normalized = preparedEffects ?? normalized;
                  if (frontiers.size > 0 || normalized.some((e) => e.subjectId === void 0) && normalized.some((e) => e.subjectId !== void 0)) {
                    const point = preparePointRealization(
                      realizationTree,
                      normalized
                    );
                    if (point) {
                      installPreparedCompensation(point, frontiers, completion);
                    } else if (frontiers.size > 0 || normalized.some((effect) => effect.plainBranchMembership)) {
                      rollbackPendingTarget(
                        normalized,
                        orderDeltas,
                        completion,
                        frontiers
                      );
                    } else {
                      realizationPort.applyAtomically(normalized);
                    }
                  } else {
                    realizationPort.applyAtomically(normalized);
                  }
                }
              }
            });
          }
        )
      );
      failed = false;
    } finally {
      physicalRows.pop();
      endStructuralWrite(failed);
    }
    if (!result.ok) {
      throw createRollbackError({
        kind: "effect-validation-failed",
        pendingTurnId: transactionId,
        compensation: effects,
        errorMessage: `Transaction rollback refused: ${result.refusal.kind}`,
        cause: result.refusal,
        callbackError
      });
    }
    for (const effect of effects)
      if (effect.kind !== "set" || effect.subject !== void 0)
        refreshOmittedCollection(tree.$, effect.position);
    for (const delta of orderDeltas)
      refreshOmittedCollection(tree.$, delta.owner);
  };
  const rollbackPendingEffectsThroughRealizationPort = (transactionId, effects, baselineValues, orderDeltas = [], callbackError, owningTransactionId = transactionId, completion) => {
    applyRollbackCompensation(
      transactionId,
      effects,
      baselineValues,
      orderDeltas,
      callbackError,
      owningTransactionId,
      completion
    );
    markOwnerInvalidatedFrom(tree.$);
  };
  try {
    const notifier = getPathNotifier();
    if (notifier) {
      const treeOwnerId = getPositionRegistry(tree.$)?.id;
      if (treeOwnerId !== void 0) {
        registerEnqueueObserver = () => {
          unsubscribeEnqueue = notifier.observeEnqueue(treeOwnerId, (entry) => {
            if (destroyed || !authority.getPendingTurnCount() && !pendingTransactions.size)
              return;
            const meta = entry.meta;
            if (meta?.origin === "restoration" || meta?.origin === "transaction-rollback" || isInspectionWrite(meta))
              return;
            const realized = getWriteParticipation(meta) === "realized";
            if (!realized && typeof meta?.transactionId === "number" && meta.transactionOwner !== transactionOwnerToken)
              return;
            const writer = !realized && meta?.transactionOwner === transactionOwnerToken ? meta.transactionId : void 0;
            try {
              const probe = createCaptureBucket();
              const transition2 = entityValueTransition(meta);
              captureEffects(
                probe,
                probe.effects,
                entry.path,
                transition2 ? transition2.ordinaryAfter : entry.newValue,
                transition2 ? transition2.ordinaryBefore : entry.oldValue,
                unpairedEntityMetadata(meta),
                entry.ownerPath,
                entry.subjectIds,
                entry.positionIds
              );
              const effects = drainCaptureBucket(probe).effects;
              if (!effects.length) return;
              const seq = ++inspectionSeq;
              let writes = inspectionWrites.get(writer);
              if (!writes) inspectionWrites.set(writer, writes = /* @__PURE__ */ new Map());
              for (const effect of effects) {
                const footprint = effect.kind === "set" ? { ...effect, before: void 0, after: void 0 } : effect.kind === "rekey" ? { ...effect } : { ...effect, value: void 0 };
                writes.set(captureKey(effect), { seq, effect: footprint });
              }
            } catch (error) {
              inspectionUnavailable = true;
              throw error;
            }
          });
        };
      }
      const subscribeCollectionNotifications = () => {
        unsubscribeNotifications?.();
        unsubscribeNotifications = notifier.subscribe(
          "**",
          function receiveOrdinaryNotification(next, prev, path, ownerPath, origin, subjectIds, positionIds, meta) {
            if (getWriteParticipation(meta) === "realized")
              meta = unpairedEntityMetadata(meta);
            if (getEntityOrdinaryChanges(meta) !== void 0) {
              for (const entry of ordinaryEntityEntries({
                path,
                newValue: next,
                oldValue: prev,
                meta,
                subjectIds
              })) {
                receiveOrdinaryNotification(
                  entry.newValue,
                  entry.oldValue,
                  entry.path,
                  ownerPath,
                  origin,
                  entry.subjectIds,
                  positionIds,
                  entry.meta
                );
              }
              return;
            }
            const transition2 = entityValueTransition(meta);
            if (transition2) {
              next = transition2.ordinaryAfter;
              prev = transition2.ordinaryBefore;
            }
            if (pendingTransactions.size > 0 && !isInspectionWrite(meta)) {
              const windowOwner = meta?.ownerId;
              if (windowOwner === void 0 || treeOwnerId === void 0 || windowOwner === treeOwnerId) {
                const membership = plainBranchMembershipChange(meta);
                recordWindowWrite(
                  membership ? membership.members.flatMap((member) => [
                    ...member.positionIds ?? []
                  ]) : positionIds,
                  subjectIds
                );
              }
            }
            if (origin === "restoration" || origin === "transaction-rollback") {
              return;
            }
            const writeOwnerId = meta?.ownerId;
            if (writeOwnerId !== void 0 && treeOwnerId !== void 0 && writeOwnerId !== treeOwnerId) {
              return;
            }
            if (isInspectionWrite(meta)) {
              return;
            }
            if (getWriteParticipation(meta) === "realized") {
              if (authority.getPendingTurnCount() > 0 || pendingTransactions.size > 0) {
                const probe = createCaptureBucket();
                captureIntoBucket(
                  probe,
                  path,
                  next,
                  prev,
                  meta,
                  ownerPath,
                  subjectIds,
                  positionIds
                );
                const effects = drainCaptureBucket(probe).effects;
                authority.observeLaterEffects(effects);
                for (const id of pendingTransactions.keys()) {
                  const prior = callbackExternalEffects.get(id) ?? [];
                  callbackExternalEffects.set(id, [...prior, ...effects]);
                }
              }
              return;
            }
            if (typeof meta?.transactionId === "number" && meta.transactionOwner !== transactionOwnerToken) {
              return;
            }
            const transactionId = resolveTransactionId(meta);
            if (transactionId !== void 0) {
              captureIntoBucket(
                getTransactionBucket(transactionId),
                path,
                next,
                prev,
                meta,
                ownerPath,
                subjectIds,
                positionIds
              );
              return;
            }
            selfDirty = true;
            captureIntoBucket(
              pendingCapture,
              path,
              next,
              prev,
              meta,
              ownerPath,
              subjectIds,
              positionIds
            );
          }
        );
      };
      subscribeCollectionNotifications();
      if (typeof notifier.onReset === "function") {
        unsubscribeReset = notifier.onReset(() => {
          subscribeCollectionNotifications();
        });
      }
      restoreLeafInterceptors = interceptLeafSignals(
        tree.$,
        (path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
          const effectiveMeta = meta ?? getActiveWriteContext();
          if (isRestoring) return;
          if (effectiveMeta?.origin === "restoration") {
            return;
          }
          if (isInspectionWrite(effectiveMeta) || getWriteParticipation(effectiveMeta) === "realized") {
            notifier.notify(
              path,
              next,
              prev,
              ownerPath,
              subjectIds,
              positionIds,
              effectiveMeta
            );
            return;
          }
          if (typeof effectiveMeta?.transactionId === "number" && effectiveMeta.transactionOwner !== transactionOwnerToken) {
            return;
          }
          notifier.notify(
            path,
            next,
            prev,
            ownerPath,
            subjectIds,
            positionIds,
            effectiveMeta,
            treeOwnerId
          );
        },
        {
          terminalRecord: (path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
            if (isRestoring || meta?.origin === "restoration" || isInspectionWrite(meta) || getWriteParticipation(meta) === "realized")
              return;
            if (meta?.transactionOwner !== transactionOwnerToken) return;
            const id = resolveTransactionId(meta), position = positionIds?.[0];
            if (id === void 0 || position === void 0 || subjectIds?.length || Object.is(prev, next))
              return;
            const slots = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
            if (slots?.resolveScalarSlot(position) === void 0) return;
            const bucket = getTransactionBucket(id);
            const effect = {
              kind: "set",
              path,
              ownerPath: ownerPath ?? path,
              position,
              before: prev,
              after: next,
              mutationIntent: meta?.mutationIntent
            };
            const key = effectKey(effect), old = bucket.effects.get(key);
            if (old && old.kind !== "set")
              throw new Error(
                "Terminal record conflicts with structural evidence"
              );
            const combined = old ? {
              ...old,
              after: next,
              mutationIntent: combineScalarMutationIntent(
                old.mutationIntent,
                effect.mutationIntent
              )
            } : effect;
            const previous = installedOperations.get(id);
            const operation = {
              sequence: (previous?.sequence ?? -1) + 1,
              owner: position,
              effects: [cloneTurnEffect(effect)],
              previous,
              owners: previous?.owners ?? /* @__PURE__ */ new Set()
            };
            const writes = [
              { map: bucket.effects, key, value: combined },
              { map: installedOperations, key: id, value: operation }
            ];
            if (!bucket.baselineValues.has(position))
              writes.push({
                map: bucket.baselineValues,
                key: position,
                value: prev
              });
            if (pendingTransactions.size > 0)
              for (const key2 of windowKeys([position], void 0))
                writes.push({
                  map: bucket.ownWriteSeq,
                  key: key2,
                  value: windowWriteSeq
                });
            return {
              writes,
              adds: [
                { set: operation.owners, value: position },
                { set: bucket.positionIds, value: position },
                { set: bucket.ownerPaths, value: ownerPath ?? path }
              ]
            };
          },
          beforePublication: (path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
            const effectiveMeta = meta ?? getActiveWriteContext();
            if (isRestoring || effectiveMeta?.origin === "restoration" || isInspectionWrite(effectiveMeta) || getWriteParticipation(effectiveMeta) === "realized")
              return;
            if (typeof effectiveMeta?.transactionId === "number" && effectiveMeta.transactionOwner !== transactionOwnerToken)
              return;
            const transactionId = resolveTransactionId(effectiveMeta);
            if (transactionId !== void 0) {
              captureIntoBucket(
                getTransactionBucket(transactionId),
                path,
                next,
                prev,
                effectiveMeta,
                ownerPath,
                subjectIds,
                positionIds
              );
            } else {
              captureEffects(
                pendingCapture,
                pendingCapture.effects,
                path,
                next,
                prev,
                effectiveMeta,
                ownerPath,
                subjectIds,
                positionIds
              );
            }
          }
        }
      );
      if (typeof notifier.onFlush === "function") {
        unsubscribeFlush = notifier.onFlush(() => {
          if (isRestoring || !selfDirty) {
            return;
          }
          selfDirty = false;
          recordConfirmedBucket(pendingCapture);
        });
      }
    }
  } catch {
  }
  const readQueuedLaterEffects = () => {
    const ownerId = getPositionRegistry(tree.$)?.id;
    return (getPathNotifier()?.readPending() ?? []).flatMap(
      (entry) => ordinaryEntityEntries({
        ...entry,
        meta: unpairedEntityMetadata(entry.meta)
      })
    ).flatMap((rawEntry) => {
      const entry = rawEntry;
      const meta = entry.meta;
      if ((entry.ownerId ?? meta?.ownerId) !== ownerId || meta?.origin === "restoration" || meta?.origin === "transaction-rollback" || isInspectionWrite(meta) || getWriteParticipation(meta) !== "realized" && meta?.transactionOwner === transactionOwnerToken && typeof meta.transactionId === "number")
        return [];
      const membership = plainBranchMembershipEffects(meta);
      if (membership) return [...membership];
      const position = entry.positionIds?.[0];
      if (position === void 0) return [];
      const structural = entry.ownerPath ? buildTurnEffectFromStructural(
        meta,
        entry.ownerPath,
        entry.path,
        entry.positionIds,
        entry.subjectIds
      ) : void 0;
      if (structural) return [structural];
      if (entry.subjectFieldKeys !== void 0 && entry.subjectIds?.length === 1) {
        const before = entry.oldValue;
        const after = entry.newValue;
        return entry.subjectFieldKeys.map((key) => ({
          kind: "set",
          position,
          path: `${entry.path}.${key}`,
          ownerPath: entry.ownerPath ?? entry.path,
          subject: entry.subjectIds?.[0],
          subjectFieldSegments: [key],
          fieldPresence: {
            before: Object.prototype.hasOwnProperty.call(before, key),
            after: Object.prototype.hasOwnProperty.call(after, key)
          },
          before: before[key],
          after: after[key],
          mutationIntent: "derive"
        }));
      }
      return [
        {
          kind: "set",
          position,
          path: entry.path,
          ownerPath: entry.ownerPath ?? entry.path,
          subject: entry.subjectIds?.[0],
          before: entry.oldValue,
          after: entry.newValue,
          mutationIntent: "derive"
        }
      ];
    });
  };
  const decorateHandle = (pending2, turnId) => {
    let settled;
    const read2 = () => {
      if (turnId === void 0) {
        return { changes: [] };
      }
      const raw = inspectPendingTurn(turnId);
      if (!raw) {
        return { changes: [] };
      }
      const registry = getPositionRegistry(tree.$);
      return {
        changes: raw.effects.map((effect) => ({
          path: effect.path,
          // The position address locates the OWNER (for an entity field that
          // is the collection); `subjectFieldSegments` is the producer-known
          // row-relative address. Appending it is what makes two fields of
          // one row distinguishable. The segments already existed and were
          // already authoritative — `scalarRelation` and `makeScalarKey`
          // key on them — so only the public projection was dropping them.
          address: (() => {
            const owner = registry?.addressFor(effect.position);
            if (!owner) return owner;
            const within = effect.kind === "set" ? effect.subjectFieldSegments : void 0;
            return within ? [...owner, ...within] : owner;
          })(),
          subject: "subject" in effect && typeof effect.subject === "number" ? effect.subject : void 0,
          status: classifyProposedEffect(
            effect,
            raw.laterEffects.filter((later) => isLaterAdmission(effect, later))
          )
        }))
      };
    };
    const snapshot = () => {
      try {
        return read2();
      } catch {
        return void 0;
      }
    };
    const settlementWasTerminal = () => turnId !== void 0 && !authority.getPendingTurnIds().includes(turnId);
    return {
      inspect() {
        return settled ?? read2();
      },
      confirm() {
        const atSettlement = settled ?? snapshot();
        try {
          pending2.confirm();
        } catch (error) {
          if (settlementWasTerminal()) settled = atSettlement;
          throw error;
        }
        settled = atSettlement;
      },
      rollback() {
        const atSettlement = settled ?? snapshot();
        try {
          pending2.rollback();
        } catch (error) {
          if (settlementWasTerminal()) settled = atSettlement;
          throw error;
        }
        settled = atSettlement;
      }
    };
  };
  const runtime2 = {
    transaction(fn) {
      if (destroyed) throw new Error("Cannot transact on a destroyed tree");
      const activeMeta = getActiveWriteContext();
      const notifier = getPathNotifier();
      const captureRuntime = getMutationCaptureRuntime(tree);
      if (typeof activeMeta?.transactionId === "number") {
        throw new Error("Nested transaction is not supported");
      }
      const beforeOpen = readQueuedLaterEffects();
      for (const id of authority.getPendingTurnIds()) {
        authority.observeQueuedEffects(id, beforeOpen);
      }
      notifier?.flushSync();
      const transactionId = nextTransactionId++;
      const captureBucket = createCaptureBucket();
      pendingTransactions.set(transactionId, captureBucket);
      ensureEnqueueObserver();
      const lifecycleChannel = getTransactionLifecycleChannel(tree);
      const lifecycleView = { transactionId, phase: "opened" };
      lifecycleViews.set(transactionId, lifecycleView);
      let descriptorOwnersBefore;
      let releaseCapture;
      let releaseEntityCapture;
      let reservedTurnId;
      try {
        const releaseOpenedDelivery = holdLifecycle();
        publishLifecycle({ kind: "opened", transactionId });
        try {
          lifecycleChannel.announce({
            kind: "opened",
            owner: transactionOwnerToken,
            id: transactionId
          });
        } finally {
          releaseOpenedDelivery?.();
        }
        const afterOpened = readQueuedLaterEffects();
        for (const id of authority.getPendingTurnIds()) {
          authority.observeQueuedEffects(id, afterOpened);
        }
        notifier?.flushSync();
        openCommitScope(transactionOwnerToken, transactionId, tree);
        lifecycleScopes.add(transactionId);
        descriptorOwnersBefore = new Set(realizationDescriptors.keys());
        releaseCapture = captureRuntime?.activateCapture();
        releaseEntityCapture = observeOpenEntityCapture(
          transactionId,
          captureBucket
        );
        reservedTurnId = authority.reservePending(captureBucket);
      } catch (error) {
        abandonLifecycleView(transactionId);
        throw error;
      }
      let primaryError;
      let primaryFailed = false;
      let cleanupError;
      let cleanupFailed = false;
      const executeTransaction = () => {
        try {
          withWriteContext(
            {
              ...activeMeta ?? {},
              transactionId,
              transactionOwner: transactionOwnerToken
            },
            fn
          );
        } catch (error) {
          primaryFailed = true;
          primaryError = error;
        }
      };
      try {
        const locations = getLocationRuntime(tree.$);
        if (locations) locations.runInvalidationGroup(executeTransaction);
        else executeTransaction();
      } catch (error) {
        if (!primaryFailed) {
          cleanupFailed = true;
          cleanupError = error;
        }
      } finally {
        try {
          try {
            releaseEntityCapture?.();
          } finally {
            releaseCapture?.();
          }
        } catch (error) {
          if (primaryFailed || cleanupFailed)
            reportCleanupFailure(
              "transaction capture release after failure",
              error
            );
          else {
            cleanupFailed = true;
            cleanupError = error;
          }
        }
      }
      let pendingTurn;
      let autoRollbackUnsafe = false;
      let releaseStagedDelivery;
      try {
        const callbackQueuedEvidence = readQueuedLaterEffects();
        for (const id of authority.getPendingTurnIds()) {
          if (id !== reservedTurnId)
            authority.observeQueuedEffects(id, callbackQueuedEvidence);
        }
        if (callbackQueuedEvidence.length) {
          callbackExternalEffects.set(transactionId, [
            ...callbackExternalEffects.get(transactionId) ?? [],
            ...callbackQueuedEvidence
          ]);
        }
        if (!primaryFailed) {
          lifecycleView.phase = "staged";
          releaseStagedDelivery = holdLifecycle();
          publishLifecycle({ kind: "staged", transactionId });
          lifecycleChannel.announce({
            kind: "staged",
            owner: transactionOwnerToken,
            id: transactionId
          });
        }
        notifier?.flushSync();
        const openBucket = pendingTransactions.get(transactionId);
        autoRollbackUnsafe = cleanupFailed && !primaryFailed && openBucket !== void 0 && writtenSinceBy(openBucket);
        pendingTurn = materializePendingTransaction(
          transactionId,
          reservedTurnId
        );
      } catch (error) {
        installedOperations.delete(transactionId);
        expectedDispositions.delete(transactionId);
        transactionOrderAdmissions.delete(transactionId);
        pendingTransactions.delete(transactionId);
        callbackExternalEffects.delete(transactionId);
        releaseWindowIfClosed();
        authority.discardPending(reservedTurnId);
        abandonLifecycleView(transactionId);
        throw error;
      } finally {
        releaseStagedDelivery?.();
      }
      const pendingTurnId = pendingTurn?.id;
      if (pendingTurn) {
        inspectionTransactionByTurn.set(pendingTurn.id, transactionId);
        const keys = new Set((pendingTurn.__effects ?? []).map(captureKey));
        const writes = inspectionWrites.get(transactionId);
        for (const key of writes?.keys() ?? [])
          if (!keys.has(key)) writes?.delete(key);
        notifyListeners(pendingCreatedListeners, pendingTurn);
      } else {
        inspectionWrites.delete(transactionId);
      }
      releaseInspectionIfQuiet();
      let lifecycle = "pending";
      let settling = false;
      const handle = {
        [PENDING_TURN_ID]: pendingTurnId,
        confirm() {
          validateOperationDisposition(transactionId, pendingTurnId);
          const pendingTurn2 = authority.getPendingTurn(pendingTurnId);
          if (destroyed) throw new Error("Cannot settle a destroyed tree");
          if (settling)
            throw new Error("Transaction settlement is already in progress");
          if (lifecycle === "confirmed") {
            return;
          }
          if (lifecycle === "rejected") {
            throw new Error("Cannot confirm a rolled back transaction");
          }
          lifecycle = "confirmed";
          installedOperations.delete(transactionId);
          expectedDispositions.delete(transactionId);
          transactionOrderAdmissions.delete(transactionId);
          retireLifecycleView(transactionId);
          const releaseConfirmedDelivery = holdLifecycle();
          publishLifecycle({ kind: "confirmed", transactionId });
          try {
            lifecycleChannel.announce({
              kind: "confirmed",
              owner: transactionOwnerToken,
              id: transactionId
            });
            try {
              if (pendingTurnId !== void 0) {
                const confirmedTurn = authority.confirmPending(pendingTurnId);
                const accepted = inspectionWrites.get(transactionId);
                if (accepted) {
                  let settled = inspectionWrites.get(void 0);
                  if (!settled)
                    inspectionWrites.set(void 0, settled = /* @__PURE__ */ new Map());
                  for (const [key, write] of accepted) {
                    if ((settled.get(key)?.seq ?? -1) < write.seq)
                      settled.set(key, write);
                  }
                  inspectionWrites.delete(transactionId);
                }
                inspectionTransactionByTurn.delete(pendingTurnId);
                if (confirmedTurn) {
                  notifyListeners(pendingConfirmedListeners, confirmedTurn);
                }
              }
            } finally {
              if (pendingTurnId !== void 0) {
                pendingOrderDeltas.delete(pendingTurnId);
              }
              releaseInspectionIfQuiet();
              try {
                settleCommitScope(
                  transactionOwnerToken,
                  transactionId,
                  "commit"
                );
              } finally {
                forgetUnclaimedDescriptorSubjects(
                  pendingTurn2?.restorationSubjectIds ?? [],
                  descriptorOwnersBefore,
                  pendingTurn2?.__positionIds ?? []
                );
              }
            }
          } finally {
            releaseConfirmedDelivery?.();
          }
        },
        rollback() {
          validateOperationDisposition(transactionId, pendingTurnId);
          const pendingTurn2 = authority.getPendingTurn(pendingTurnId);
          if (destroyed) throw new Error("Cannot settle a destroyed tree");
          if (settling)
            throw new Error("Transaction settlement is already in progress");
          if (lifecycle === "rejected") return;
          if (lifecycle === "confirmed")
            throw new Error("Cannot rollback a confirmed transaction");
          const plan = pendingTurnId === void 0 ? { compensation: [] } : authority.getPendingRollbackPlan(
            pendingTurnId,
            readQueuedLaterEffects(),
            orderInterferenceFor(transactionId)
          );
          if ("conflict" in plan) {
            const refusal = createRollbackError(plan.conflict);
            publishRefusal(transactionId, refusal);
            throw refusal;
          }
          const compensation = plan.compensation;
          const orderDeltas = pendingTurnId === void 0 ? [] : pendingOrderDeltas.get(pendingTurnId) ?? [];
          let installed = false;
          const completion = { selected: false, committed: false };
          let observerFailed = false;
          let observerError;
          const clock = getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree);
          const revision = clock?.revision();
          let releaseRolledBackDelivery;
          settling = true;
          try {
            const apply = () => {
              rollbackPendingEffectsThroughRealizationPort(
                pendingTurnId ?? transactionId,
                [...compensation].reverse(),
                pendingTurn2?.__baselineValues ?? /* @__PURE__ */ new Map(),
                orderDeltas,
                primaryFailed ? primaryError : void 0,
                transactionId,
                completion
              );
              installed = true;
            };
            try {
              const locations = getLocationRuntime(tree.$);
              if (locations) locations.runInvalidationGroup(apply);
              else apply();
            } catch (error) {
              installed ||= completion.selected ? completion.committed : revision !== void 0 && clock?.revision() !== revision;
              if (!installed) {
                const refusal = error instanceof SignalTreeRollbackError ? error : createRollbackError({
                  kind: "effect-validation-failed",
                  pendingTurnId: pendingTurnId ?? transactionId,
                  compensation,
                  errorMessage: error instanceof Error ? error.message : "Unknown rollback validation failure",
                  cause: error,
                  callbackError: primaryFailed ? primaryError : void 0
                });
                publishRefusal(transactionId, refusal);
                throw refusal;
              }
              observerFailed = true;
              observerError = error;
            }
            lifecycle = "rejected";
            installedOperations.delete(transactionId);
            expectedDispositions.delete(transactionId);
            transactionOrderAdmissions.delete(transactionId);
            retireLifecycleView(transactionId);
            releaseRolledBackDelivery = holdLifecycle();
            publishLifecycle({ kind: "rolled-back", transactionId });
            inspectionWrites.delete(transactionId);
            if (pendingTurnId !== void 0)
              inspectionTransactionByTurn.delete(pendingTurnId);
            const discarded = pendingTurnId === void 0 ? void 0 : authority.discardPending(pendingTurnId);
            if (pendingTurnId !== void 0)
              pendingOrderDeltas.delete(pendingTurnId);
            releaseInspectionIfQuiet();
            lifecycleChannel.announce({
              kind: "rolled-back",
              owner: transactionOwnerToken,
              id: transactionId
            });
            try {
              if (discarded)
                notifyListeners(pendingDiscardedListeners, discarded);
            } finally {
              try {
                settleCommitScope(
                  transactionOwnerToken,
                  transactionId,
                  "discard"
                );
              } finally {
                forgetUnclaimedDescriptorSubjects(
                  pendingTurn2?.restorationSubjectIds ?? [],
                  descriptorOwnersBefore,
                  pendingTurn2?.__positionIds ?? []
                );
              }
            }
            if (observerFailed) throw applicationFailureCause(observerError);
          } finally {
            settling = false;
            releaseRolledBackDelivery?.();
          }
        }
      };
      if (primaryFailed || cleanupFailed) {
        try {
          if (autoRollbackUnsafe) {
            const refusal = createRollbackError({
              kind: "effect-validation-failed",
              pendingTurnId: pendingTurnId ?? transactionId,
              compensation: [],
              errorMessage: "Transaction rollback refused: a location it wrote was written again before the transaction returned"
            });
            publishRefusal(transactionId, refusal);
            throw refusal;
          }
          handle.rollback();
        } catch (rollbackError) {
          if (lifecycle !== "pending") {
            reportCleanupFailure(
              "rollback delivery after a failed transaction",
              rollbackError
            );
            throw primaryFailed ? primaryError : cleanupError;
          }
          if (!primaryFailed) {
            reportCleanupFailure(
              "a post-callback step whose rollback was then refused",
              cleanupError
            );
          }
          if (lifecycle === "pending" && !destroyed && typeof rollbackError === "object" && rollbackError !== null) {
            Object.defineProperty(rollbackError, "recovery", {
              value: {
                transaction: enroll(
                  decorateHandle(handle, pendingTurnId),
                  lifecycleRegistry?.id,
                  transactionId
                ),
                // Explicit: the callback may have thrown `undefined`.
                callbackFailed: primaryFailed,
                callbackError: primaryFailed ? primaryError : void 0
              },
              enumerable: false,
              configurable: true,
              writable: true
            });
          }
          throw rollbackError;
        }
        throw primaryFailed ? primaryError : cleanupError;
      }
      return enroll(
        decorateHandle(handle, pendingTurnId),
        lifecycleRegistry?.id,
        transactionId
      );
    },
    getConfirmedTurnRecords: () => authority.getConfirmedTurnRecords(),
    setHistoryRetention: (retain) => authority.setHistoryRetention(retain),
    getConfirmedRetention: () => authority.getConfirmedRetention(),
    describePendingTurn: inspectPendingTurn,
    getSourceAdmissionCountsForTesting: () => ({
      segments: sourceSegments.size,
      admissions: sourceAdmissions.size,
      dependencies: authority.getSourceDependencyCountForTesting()
    }),
    getInspectionFootprintCountsForTesting: () => ({
      writers: inspectionWrites.size,
      footprints: [...inspectionWrites.values()].reduce(
        (count, writes) => count + writes.size,
        0
      )
    }),
    getConfirmedTurnCount: () => authority.getConfirmedTurnCount(),
    getPendingTurnCount: () => authority.getPendingTurnCount(),
    getConfirmedTurnIds: () => authority.getConfirmedTurnIds(),
    getPendingTurnIds: () => authority.getPendingTurnIds(),
    onPendingCreated(listener) {
      pendingCreatedListeners.add(listener);
      return () => pendingCreatedListeners.delete(listener);
    },
    onPendingConfirmed(listener) {
      pendingConfirmedListeners.add(listener);
      return () => pendingConfirmedListeners.delete(listener);
    },
    onPendingDiscarded(listener) {
      pendingDiscardedListeners.add(listener);
      return () => pendingDiscardedListeners.delete(listener);
    }
  };
  const reportCleanupFailure = (step, error) => {
    try {
      console.error(
        `SignalTree: transactions() cleanup failed during ${step}.`,
        error
      );
    } catch {
    }
  };
  if (typeof tree.registerCleanup === "function") {
    tree.registerCleanup(() => {
      destroyed = true;
      unregister(lifecycleRegistry?.id);
      lifecycleViews.clear();
      lifecycleScopes.clear();
      authority.releaseConfirmedTurnsOnDestroy();
      cancelCommitScopes(transactionOwnerToken);
      for (const id of authority.getPendingTurnIds()) {
        const discarded = authority.discardPending(id);
        forgetUnclaimedDescriptorSubjects(
          discarded?.restorationSubjectIds ?? [],
          /* @__PURE__ */ new Set(),
          discarded?.__positionIds ?? []
        );
      }
      pendingTransactions.clear();
      lastWindowWriteSeq.clear();
      lastWindowRowWriteSeq.clear();
      callbackExternalEffects.clear();
      inspectionWrites.clear();
      sourceSegments.clear();
      sourceAdmissions.clear();
      pairedEntityAdmissions = /* @__PURE__ */ new WeakMap();
      inspectionTransactionByTurn.clear();
      unsubscribeEnqueue?.();
      unsubscribeEnqueue = null;
      pendingCreatedListeners.clear();
      pendingConfirmedListeners.clear();
      pendingDiscardedListeners.clear();
      drainCaptureBucket(pendingCapture);
      try {
        unsubscribeFlush?.();
      } catch (error) {
        reportCleanupFailure("flush unsubscription", error);
      }
      try {
        unsubscribeNotifications?.();
      } catch (error) {
        reportCleanupFailure("notification unsubscription", error);
      }
      try {
        unsubscribeReset?.();
      } catch (error) {
        reportCleanupFailure("reset unsubscription", error);
      }
      try {
        unsubscribeCollectionOrders?.();
      } catch (error) {
        reportCleanupFailure("collection-order unsubscription", error);
      }
      try {
        restoreLeafInterceptors?.();
      } catch (error) {
        reportCleanupFailure("leaf interceptor teardown", error);
      }
      unsubscribeFlush = null;
      unsubscribeNotifications = null;
      unsubscribeReset = null;
      unsubscribeCollectionOrders = null;
      restoreLeafInterceptors = null;
      pendingOrderDeltas.clear();
      transactionOrderAdmissions.clear();
    });
  }
  tree[INTERNAL_TRANSACTION_RUNTIME] = runtime2;
  installTransactionLifecycleChannel(tree);
  return runtime2;
}
function classifyProposedEffect(effect, laterEffects) {
  if (effect.kind === "set") {
    const replaced = laterEffects.some(
      (later) => later.position === effect.position && (later.kind === "remove" && effect.subject !== void 0 && later.subject === effect.subject || later.kind === "set" && scalarRelation(later, effect) === "same" && (later.subject === void 0 || effect.subject === void 0 || later.subject === effect.subject))
    );
    return replaced ? "superseded" : "current";
  }
  let present = true;
  for (const later of laterEffects) {
    if (later.ownerPath !== effect.ownerPath) {
      continue;
    }
    if (later.subject !== effect.subject) {
      continue;
    }
    present = later.kind !== "remove";
  }
  return present ? "current" : "superseded";
}
function transactions(config) {
  const enhancerFn = (tree) => {
    const runtime2 = getOrCreateInternalTransactionRuntime(tree);
    if (config?.history) {
      runtime2.setHistoryRetention(config.history.retain);
    }
    const host = tree;
    host.transact = runtime2.transaction;
    tree["__transactions"] = {
      getConfirmedTurnCount: () => runtime2.getConfirmedTurnCount(),
      getPendingTurnCount: () => runtime2.getPendingTurnCount(),
      getConfirmedTurnIds: () => runtime2.getConfirmedTurnIds(),
      getPendingTurnIds: () => runtime2.getPendingTurnIds()
    };
    return tree;
  };
  const meta = {
    name: "transactions",
    provides: ["transactions"],
    capabilities: ["causal-runtime"]
  };
  enhancerFn.metadata = meta;
  enhancerFn[ENHANCER_META] = meta;
  return enhancerFn;
}

// <stdin>
var original = Array.prototype.map;
var results = [];
for (const size of [16, 64, 256, 1024]) {
  const tree = signalTree({ rows: entityMap() }, { enhancers: [transactions()] });
  let calls = 0, searchSlots = 0;
  const stacks = [];
  try {
    tree.$.rows.setAll(Array.from({ length: size }, (_, id) => ({ id, n: id })));
    const pending2 = tree.transact(() => {
      tree.$.rows.setAll(Array.from({ length: size }, (_, id) => ({ id: id + size, n: id })));
      tree.$.rows.addOne({ id: 0, n: -1 });
    });
    Array.prototype.map = function(callback, context) {
      if (this[0]?.structural === "add") {
        calls++;
        searchSlots += this.length;
        if (size === 16 && stacks.length < 8) stacks.push(new Error().stack || "");
      }
      return original.call(this, callback, context);
    };
    pending2.rollback();
    Array.prototype.map = original;
    results.push({ size, calls, searchSlots, ids: tree.$.rows.ids().length, first: tree.$.rows.ids()[0], last: tree.$.rows.ids().at(-1), value: tree.$.rows.byId(0)?.()?.n, stacks });
  } finally {
    Array.prototype.map = original;
    tree.destroy();
  }
}
console.log(JSON.stringify(results, null, 2));
