import {signalTree,entityMap} from './packages/kernel/src/index';
import {EntityPlacementStage} from './packages/kernel/src/lib/physical/entity-placement-stage';
const original=EntityPlacementStage.prototype.read;const results=[];
for(const size of [16,64,256,1024]){
 let reads=0;const firstStacks:string[]=[];
 EntityPlacementStage.prototype.read=function(subject){reads++;if(size===16&&reads<90)firstStacks.push(new Error().stack||'');return original.call(this,subject);};
 const tree=signalTree({rows:entityMap<{id:number;n:number},number>()});
 try{tree.$.rows.setAll(Array.from({length:size},(_,id)=>({id,n:id})));results.push({size,reads,count:tree.$.rows.count(),first:tree.$.rows.ids()[0],last:tree.$.rows.ids().at(-1),firstStacks});}
 finally{EntityPlacementStage.prototype.read=original;tree.destroy();}
}
console.log(JSON.stringify(results,null,2));
