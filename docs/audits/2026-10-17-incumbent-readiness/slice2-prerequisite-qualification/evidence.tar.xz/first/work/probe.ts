import {signalTree,entityMap} from './packages/kernel/src/index';
import {StructuralStore} from './packages/kernel/src/lib/physical/structural-store';
const original=StructuralStore.prototype.preparePlacement;
const results=[];
for(const size of [16,64,256,1024]){
 let visits=0;
 StructuralStore.prototype.preparePlacement=function(){
  const stage=original.call(this);const iterate=stage.patch[Symbol.iterator].bind(stage.patch);
  stage.patch[Symbol.iterator]=function*(){for(const entry of iterate()){visits++;yield entry;}};
  return stage;
 };
 const tree=signalTree({rows:entityMap<{id:number;n:number},number>()});
 try{tree.$.rows.setAll(Array.from({length:size},(_,id)=>({id,n:id})));results.push({size,visits,rows:tree.$.rows.count(),first:tree.$.rows.ids()[0],last:tree.$.rows.ids().at(-1)});}
 finally{StructuralStore.prototype.preparePlacement=original;tree.destroy();}
}
console.log(JSON.stringify(results,null,2));
