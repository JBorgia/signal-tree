import {signalTree,entityMap,transactions} from './packages/kernel/src/index';
const original=Array.prototype.includes;const results=[];
for(const size of [16,64,256,1024]){
 const tree=signalTree({rows:entityMap<{id:number;n:number},number>()},{enhancers:[transactions()]});
 let calls=0,searchSlots=0;const stacks:string[]=[];
 try{
 tree.$.rows.setAll(Array.from({length:size},(_,id)=>({id,n:id})));
 const pending=tree.transact(()=>{tree.$.rows.setAll(Array.from({length:size},(_,id)=>({id:id+size,n:id})));tree.$.rows.addOne({id:0,n:-1});});
 Array.prototype.includes=function(value,from){calls++;searchSlots+=this.length;if(size===16&&stacks.length<8&&this.length===size)stacks.push(new Error().stack||'');return original.call(this,value,from);};
 pending.rollback();Array.prototype.includes=original;
 results.push({size,calls,searchSlots,ids:tree.$.rows.ids().length,first:tree.$.rows.ids()[0],last:tree.$.rows.ids().at(-1),value:tree.$.rows.byId(0)?.()?.n,stacks});
 }finally{Array.prototype.includes=original;tree.destroy();}
}
console.log(JSON.stringify(results,null,2));
