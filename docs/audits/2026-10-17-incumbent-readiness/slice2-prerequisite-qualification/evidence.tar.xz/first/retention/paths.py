import json,collections,pathlib
b=pathlib.Path('/private/tmp/slice2-gate-reconciliation/retention');s=json.load(open(b/'after-run.heapsnapshot'));meta=s['snapshot']['meta'];ns=s['nodes'];es=s['edges'];strings=s['strings'];nf=meta['node_fields'];ef=meta['edge_fields'];nw=len(nf);ew=len(ef);nt=meta['node_types'][0];et=meta['edge_types'][0];N=len(ns)//nw
edge_starts=[];offset=0;candidates=[]
for i in range(N):
 edge_starts.append(offset);count=ns[i*nw+nf.index('edge_count')];props=set()
 for j in range(offset,offset+count*ew,ew):
  typ=et[es[j]]
  if typ=='property':props.add(strings[es[j+1]])
 if {'destroy','$','transact'}.issubset(props):candidates.append(i)
 offset+=count*ew
parent={0:None};q=collections.deque([0]);remain=set(candidates)
while q and remain:
 i=q.popleft();remain.discard(i);start=edge_starts[i];count=ns[i*nw+nf.index('edge_count')]
 for j in range(start,start+count*ew,ew):
  typ=et[es[j]]
  if typ=='weak':continue
  dest=es[j+2]//nw
  if dest in parent:continue
  name=es[j+1] if typ in ['element','hidden'] else strings[es[j+1]]
  if isinstance(name,str) and 'part of key' in name:continue
  parent[dest]=(i,typ,name);q.append(dest)
def describe(i):return {'index':i,'type':nt[ns[i*nw]],'name':strings[ns[i*nw+1]],'id':ns[i*nw+2]}
result=[]
for i in candidates:
 path=[];cur=i
 while cur in parent and parent[cur] is not None:
  prev,typ,name=parent[cur];path.append({'from':describe(prev),'edge':[typ,name],'to':describe(cur)});cur=prev
 result.append({'tree':describe(i),'reached':i in parent,'path':list(reversed(path))})
(b/'RETAINING-PATHS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
