import {writeHeapSnapshot} from 'node:v8';
import {writeFileSync} from 'node:fs';
const {run}=await import('./receipt-graph-gc.mjs');
const result=await run();writeFileSync(new URL('HEAP-RUN.json',import.meta.url),JSON.stringify(result,null,2));
// Diagnostic only: snapshot after the original harness frame returns, followed
// by one scheduled GC. No repeat-until-collected loop or acceptance rewrite.
await new Promise(r=>setTimeout(r,0));globalThis.gc();
writeHeapSnapshot('/private/tmp/slice2-gate-reconciliation/retention/after-run.heapsnapshot');
