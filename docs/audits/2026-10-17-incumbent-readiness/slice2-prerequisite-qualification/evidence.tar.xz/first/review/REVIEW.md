# Independent slice2 gate reconciliation

Slice2 is not yet demonstrated complete by the identified evidence. No new runtime blocker is asserted from this read-only assessment; the first concrete remaining evidence is unchanged selection/staged-writer compatibility, not a need for another representation or public semantics decision. Candidate manifest16d33224f969b9e284e61c8affbacd544d1ebfba6397ae69f9a3cb2030008935; readiness recorde1847393. No already-passing check rerun.

## Governing scope

Approved f80645c8 plan line180: slice2 covers W4–W8 structural branches, “Mixed add/remove/rekey/reorder, selection and callback snapshots coherent”; refusal retains state/authority, callback nested writes/throws survive, no delayed outer order. Lines190–198 require mixed upsert/setAll branches to remain experimental until structurally coherent. Line162 forbids source capture incidental topology or unowned installation. Slice3 audits realization/hidden/retirement, slice4 combined all-framework, slice5 full verification/costs. Those later gates are not imported wholesale into slice2.

Plan regression keys86–95 name exact retained tests: E2 staged setAll; E4 active/prepend/rekey, selection lifetime, order carrier; E5 held lifetime/reclaim; E6 replay callback arguments/timing; E10 batch work/count assertions. SOURCE manifest presence does not mean execution. Copied CURRENT-VECTOR.json lists46 focused files and omits every E2/E4/E6/E10 file. Searching current evidence logs/commands found no current-source executions of those missing names; old candidate research records are not accepted as current results. INPUT-HASHES.json stamps reviewed missing controls.

## What the existing evidence establishes

Reviewed source-owner/derive/native-Link corrections and named current assertions cover independent P/O placement, immutable source facts, payload ownership, indexed normalization, mixed structural rollback, rekey vacancy/refusal, fresh/prefix order, original history redo failures, compound ordinary Link leak, selected order carrier/subset, getter faults/reentry and useful original/adopted publication. The495 passing controls are finite evidence, not proof for all W4–W8 routes. The remaining original replacement+identity no-send assertion is incompatible with approved whole replacement adoption; preserve and classify it, not use it to excuse a different failure.

## First finite missing vector

Run these unchanged controls on the frozen candidate, recording commands and pre/post manifest; do not rerun the495 vector merely to increase counts:

1. entity-set-all-staging.spec.ts (E2): complete pre-state remove/update/add facts, adjacent removed-neighbor records, duplicate-key transformed values, blocked preparation, reader delivery, update/add/removal interceptor rekey, selector rekey, allowed field-only reentry. These test the prepared source boundary, not later hidden semantics.
2. entity-selection-lifetime.spec.ts and entity-active-prepend-changeid.spec.ts (E4): selected-row remove/clear distinction, selected lifetime revival, rekey selection continuity, same-key replacement isolation and newer outside selection surviving rollback. Current slice2 structural specs do not set active selection, so this is the first concrete unobserved semantic obligation.
3. entity-order-carrier.spec.ts (E4): existing neighbor vocabulary at both open ends and empty collection, not just correct physical order. Do not reinterpret predecessor/successor names to fit a new record.
4. entity-replay-tap-boundaries.spec.ts and entity-replay-taps.spec.ts (E6 compatibility): per-field/full-row arguments, completed collection before tap, nested interception exactly once, unsubscribe during delivery. These qualify the existing slice2 publication seam while leaving broad restoration disposition for slice3.
5. upsert-many-reversal.spec.ts: unchanged mixed existing/new batch inverse, including reverse action and identity. This is a small route-specific complement to the new two-row upsert case, not a new product rule.

If this finite vector finds no incompatibility, reconcile retained E5/E10 separately: E5 held row/field and same-key reclamation/restore assertions relevant to new retention guard; explicitly distinguish full GC/collectibility/eviction claims as later. E10 original entity-large-batches(-v16-controls) correctness/work-count assertions exercise setAll/clear/large compound inverse near argument limits. They are explicitly retained by plan, but large130k allocations warrant separate correctness shards; do not call them CPU/heap acceptance or a new cost campaign. Do not silently shrink their original workload/budgets to green.

No new test is required before this named existing vector. If a current historical assertion conflicts with an approved later owner decision, preserve its first result and identify the exact contract conflict as with replacement no-op; no automatic weakening. Occupied/missing permitted placement behavior may correctly refuse only where established authority requires it; independent safe controls must continue to succeed.

## Decision boundary and limits

Successful missing controls would support bounded slice2 gate reconciliation together with existing source review/first-red corrections, not close slice3–5. Hidden parent reintroduction, universal restoration/eviction/GC, broad framework suites, artifact/demo/budgets and activation stay gated. Existing-prefix4N snapshot cost versus inherited2N remains explicit overhead; no zero-collection-work or production performance claim. No candidate/controller/production edits or new execution by this reviewer.
