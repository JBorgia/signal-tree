# Replay and source identities

Node24.15.0; pinned pnpm10.17.0. No runner/config/dependency change.
Start with frozen e1847393 Link experiment source manifest16d33224f969b9e284e61c8affbacd544d1ebfba6397ae69f9a3cb2030008935 (not the evidence checkout's runtime). Its linked archive and preceding derive archive provide overlays. Each marker/key-index/anchor/final overlay in this archive is cumulative against that same frozen Link source, not an instruction to stack those four overlays. Verify its SOURCE.json after copying the chosen overlay. Final803TS/TSX manifest SHA25667869b6525433a7ad5fceb88042cf25b50d2d90d045408a249b2f673aae3caf9. Frozen final copy remains /private/tmp/pending-set-candidate/candidate.

```sh
cd /private/tmp/pending-set-candidate/candidate
export PATH=/private/tmp/derive-placement-successor/toolchain:$PATH
export COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false
python3 -c 'import json,subprocess; raise SystemExit(subprocess.call(json.load(open("/private/tmp/pending-set-candidate/evidence/FOCUSED-COMMAND.json"))))'
corepack pnpm exec nx test kernel --testFile=src/lib/entity-large-batches.spec.ts --skip-nx-cache
corepack pnpm exec nx test kernel --testFile=src/lib/entity-large-batches-v16-controls.spec.ts --skip-nx-cache
corepack pnpm run typecheck
node tools/check-spec-types.mjs
corepack pnpm exec eslint packages/kernel/src/lib/internals/causal-runtime/target-transition.ts packages/kernel/src/lib/pending-placement-work.spec.ts
node /private/tmp/pending-set-candidate/retention/build.mjs
node --expose-gc --input-type=module -e 'const m = await import("/private/tmp/pending-set-candidate/retention/receipt-graph-gc.mjs"); console.log(JSON.stringify(await m.run(),null,2));'
node --expose-gc --input-type=module -e 'const m = await import("/private/tmp/pending-set-candidate/retention/receipt-graph-dropped-gc.mjs"); console.log(JSON.stringify(await m.run(),null,2));'
node /private/tmp/pending-set-candidate/review/reference.cjs
```

FOCUSED exit1 is preserved:695passes/1previously adjudicated contract mismatch; no exclusion. Workloads were not shrunk; final E10 shards11/16passes. Prior terminated runs record actual incomplete cases and worker errors, not assertion failures. The first direct GC bundle invocation loaded exported run without calling it: empty NOT-INVOKED files preserve that nonexecution; only explicit run() invocations count. Each final retained/dropped arm ran once after rebuilding exact current inputs, same original4cycles/16GCturns; no favorable retries.

Source hashes are authoritative, not temporary candidate directory names. Build scripts record bundled input hashes; generated bundles remain evidence, not installed artifacts. Replay scripts have their original absolute input paths. For a relocated reconstruction, replace only root/output paths, keep witness/assertions byte-identical and record new inputs. Counter-generating build at first/work/build.mjs accepts CANDIDATE/ARM/ENTRY; probes and exact results retained. Marker build/selectId controls retain their generating scripts. Independent function-extraction harness uses TypeScript AST without adding a runtime export. Private synthetic graph controls do not establish new public malformed-topology semantics.

Raw after-run.heapsnapshot deliberately remains local; EXCLUDED-RAW-HEAP.json gives exact path/hash. Extracted strong retaining path excludes weak and ephemeron 'part of key' edges. The initially naive WeakMap path is archived as NOT-PROOF. No environment-rich raw heap committed. Small sampled CPU profile was only a location lead; no percentage/time-share/performance claim derives from it. Deterministic counters establish the traced work.
