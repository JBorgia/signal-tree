import { describe, expect, it } from 'vitest';
import { entityMap, link, signalTree, transactions } from '../index';

const drain = async () => {
  for (let i = 0; i < 120; i++) await Promise.resolve();
};
type Row = { id: string; n?: number };

describe('vue native entity Link address', () => {
  for (const enhanced of [false, true]) {
    it(`${
      enhanced ? 'enhanced' : 'bare'
    } omission and later authored value progress`, async () => {
      const tree = signalTree(
        { rows: entityMap<Row, string>() },
        { enhancers: enhanced ? [transactions()] : [] }
      );
      tree.$.rows.addOne({ id: 'a', n: 1 });
      await drain();
      const row = tree.$.rows.byIdOrFail('a');
      const sent: unknown[] = [];
      const c = link(row.n, {
        set: (value) => {
          sent.push(value);
        },
      });
      try {
        tree.$.rows.replaceOne('a', { id: 'a' });
        let settled = false;
        const wait = c.settled().then(() => {
          settled = true;
        });
        await drain();
        expect(row.n.value).toBeUndefined();
        expect(sent).toEqual([undefined]);
        expect(settled).toBe(true);
        await wait;
        row.n.value = 4;
        await drain();
        expect(row.n.value).toBe(4);
        expect(sent).toEqual([undefined, 4]);
      } finally {
        c.dispose();
        tree.destroy();
      }
    });
  }
});
