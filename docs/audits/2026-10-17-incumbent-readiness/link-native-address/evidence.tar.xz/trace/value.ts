import {signalTree,entityMap,link,transactions} from '../../derive-placement-successor/candidate/packages/kernel/src/index';
import {getPathNotifier} from '../../derive-placement-successor/candidate/packages/kernel/src/lib/path-notifier';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
for(const tx of [false,true]){
 const t=signalTree({rows:entityMap<{id:string;value?:number},string>()},{enhancers:tx?[transactions()]:[]});const r=t.$.rows;r.addOne({id:'a',value:1});await tick();const f=r.byIdOrFail('a').value;const sent:unknown[]=[];
 const c=link(f,{set:v=>{sent.push(v);console.log('SEND',tx,v);}});const off=getPathNotifier().subscribe('**',(v,p,path,owner,o,subs,pos,meta)=>console.log('NOTIFY',JSON.stringify({tx,path,v,prev:p,subs,meta})));
 try{r.updateOne('a',{value:2});await tick();let settled=false;const p=c.settled().then(()=>{settled=true;});await tick();console.log('BEFORE_DISPOSE',JSON.stringify({tx,physical:f(),sent,settled}));c.dispose();await p;console.log('AFTER_DISPOSE',JSON.stringify({tx,sent,settled}));}finally{off();c.dispose();t.destroy();}
}
