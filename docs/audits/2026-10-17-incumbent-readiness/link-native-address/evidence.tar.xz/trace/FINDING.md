# Exact missing-ticket boundary

Standalone esbuild onLoad console-only instrumentation; candidate untouched. Build script and harness pre-run hashes BEFORE.sha256. Initial omit.log/value.log preserved; additional omit-detailed.log exposes binding identity. No infinite waits:100 microtasks, then dispose releases settled. No production API or repair.

First decisive mismatch in no-enhancer ordinary field Link: registered channel binding {owner:1,position:-1,subject:1,field:value,supported:true}; source annotation {owner:1,positions:[1],envelope:{subject:1,fields:null,ping:false}}. matchingChannels rejects unequal position, returns0. Source fact revision1 exists but is never admitted/latest for this connection. completeSource sees event1 but empty queue; project(event1,payload undefined) produces no fact. This is identity registration loss before eligibility decision, not a missing field footprint.

Fallback original scheduler DOES execute twice (observation and send). Both admit calls receive undefined ticket; original-run callback has no fact on which to install grants. allowed sees revisionundefined/latestfalse/grantfalse; endpoint never called and send wait remains until disposal. Receipt unknowntrue from absent lifecycle ownerToken is real but not this missing-ticket's first cause; even permissive fallback has no bound revision to grant.

Transactions arm matches annotation to binding, admits latest fact4, completes/projects fact4 and undefined payload, original fallback installs grant, allowedtrue then send(undefined), settledtrue. Same ordinary numeric value2 update without enhancer has identical missing-ticket/stall, independently ruling out undefined-only queue mechanics.

Source needed next audit: Link bindSource obtains getOwnedPositionIds(field)?.[0]??-1 before instrumentation/lazy position materialization, while later entity notification uses collection position1. This observation explains binding mismatch but this trace does not authorize altering source ownership initialization or broadening allowed. Concrete requirement is coherent immutable source address at registration/admission, or supported conservative fallback retaining correct current revision; root separately traces scheduler.

No ownerToken initialization mutation presumed. Preserve current public no-enhancer field Link contract and original eight timeout assertions. No leak/GC claim from disposal success. This inherited blocker remains distinct from derive/placement correctness.
