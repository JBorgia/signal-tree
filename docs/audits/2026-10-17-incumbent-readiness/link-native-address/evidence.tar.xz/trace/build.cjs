const fs=require('fs'),esbuild=require('/private/tmp/derive-placement-successor/candidate/node_modules/esbuild');
const src=fs.readFileSync('/private/tmp/derive-placement-successor/link-boundary/probe.ts','utf8');
for(const variant of ['omit','value']){
 const p=__dirname+'/'+variant+'.ts';fs.writeFileSync(p,src.replaceAll("'../candidate/","'../../derive-placement-successor/candidate/").replace("r.replaceOne('a',{id:'a'})",variant==='omit'?"r.replaceOne('a',{id:'a'})":"r.updateOne('a',{value:2})"));
}
(async()=>{for(const variant of ['omit','value'])await esbuild.build({entryPoints:[__dirname+'/'+variant+'.ts'],bundle:true,platform:'node',format:'esm',outfile:__dirname+'/'+variant+'.mjs',plugins:[{name:'trace',setup(b){b.onLoad({filter:/experimental-publication\/(private|projection)\.ts$/},args=>{
 let s=fs.readFileSync(args.path,'utf8');
 if(args.path.endsWith('/private.ts')){
 s=s.replace('for(const channel of projection.matchingChannels(owner,positions,meta)){',"console.log('ANNOTATE',fact,owner,positions,'matched',projection.matchingChannels(owner,positions,meta).length);for(const channel of projection.matchingChannels(owner,positions,meta)){");
 s=s.replace('return !enabled||!projection.supported(channel)||!lifecycle.isValidating()&&!!fact',"console.log('ALLOWED',{revision:fact?.revision,latest:projection.isLatest(channel,fact),decision:fact&&lifecycle.decision(channel,fact),grant:!!fact&&grants.get(fact)?.has(channel)});return !enabled||!projection.supported(channel)||!lifecycle.isValidating()&&!!fact");
 s=s.replace('const d=fact&&lifecycle.decision(channel,fact);',"console.log('ADMIT',fact?.revision,projection.isLatest(channel,fact));const d=fact&&lifecycle.decision(channel,fact);");
 s=s.replace('original({...r,run:()=>{if(fact){',"original({...r,run:()=>{console.log('ORIGINAL-RUN',fact?.revision);if(fact){");
 }else{
 s=s.replace('const effect=meta?.structuralEffect',"console.log('MATCH-EVIDENCE',owner,positions,e,[...bindings.values()].map(b=>({owner:b.owner,position:b.position,identity:b.identity})));const effect=meta?.structuralEffect");
 s=s.replace('if(!event)return;const revision=',"console.log('COMPLETE',event);if(!event)return;const revision=");
 s=s.replace('const fact=event&&b?.completions.get(event);',"const fact=event&&b?.completions.get(event);console.log('PROJECT',event,fact,payload);");
 }
 return {contents:s,loader:'ts'};
});}}]});})();
