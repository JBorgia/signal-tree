import {createRequire} from 'node:module';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
const base='/private/tmp/link-fallback-successor', root=resolve(base,'candidate');
const {build}=createRequire(resolve(root,'package.json'))('esbuild');
const entries=process.argv.length>2?process.argv.slice(2):['combined/root-controls.ts','combined/nested-same-channel.ts','combined/delivery-failure.ts','lifecycle/composition.ts','lifecycle/scalar.ts','lifecycle/destroy.ts','lifecycle/retention-counts.ts','projection/projection-controls.ts'];
const sha=s=>createHash('sha256').update(s).digest('hex');
const summary=[];mkdirSync(resolve(base,'replayed'),{recursive:true});
for(const entry of entries){
 const name=entry.replaceAll('/','-').replace('.ts',''),source=readFileSync(resolve(base,'controls-original',entry),'utf8');
 const result=await build({stdin:{contents:source,loader:'ts',resolveDir:root},bundle:true,write:false,metafile:true,platform:'node',format:'esm',target:'node24',plugins:[{name:'current-native-only',setup(b){b.onResolve({filter:/^research-private$/},()=>({path:resolve(root,'packages/kernel/src/lib/experimental-publication/private.ts')}));}}]});
 const output=resolve(base,'replayed',name+'.mjs');writeFileSync(output,result.outputFiles[0].text);
 const inputs=Object.keys(result.metafile.inputs).filter(p=>p!=='<stdin>').map(p=>({path:p,sha256:sha(readFileSync(resolve(p)))}));
 writeFileSync(resolve(base,'replayed',name+'.inputs.json'),JSON.stringify({entry,witnessSha256:sha(source),bundleSha256:sha(result.outputFiles[0].text),inputs},null,2));
 const {run}=await import(output);const value=await run();writeFileSync(resolve(base,'replayed',name+'.json'),JSON.stringify(value,null,2));
 const checks=[];function walk(v){if(!v||typeof v!=='object')return;if(Object.hasOwn(v,'pass'))checks.push(v);for(const child of Object.values(v))walk(child);}walk(value);
 const row={entry,pass:checks.filter(x=>x.pass===true).length,fail:checks.filter(x=>x.pass!==true)};summary.push(row);console.log(JSON.stringify(row));
}
writeFileSync(resolve(base,'replayed',process.argv.length>2?'EXTRA-SUMMARY.json':'SUMMARY.json'),JSON.stringify(summary,null,2));
if(summary.some(x=>x.fail.length))process.exitCode=1;
