# Independent native Link address review

No concrete blocker demonstrated in this bounded correction. Reviewed link.ts SHA256 f74fa84fb70f2de16ec4e445e0d69d88e695ecadb6dedc59074acfd413cfa8c2 against frozen derive candidate. DIFF-PATHS.json independently compares package TypeScript source: only runtime link.ts and new link-native-address.spec.ts differ. Bundled independent probe inputs and hashes are recorded in review-INPUTS.json; BEFORE.sha256 stamps changed file/probe before execution. No runtime/test edits by reviewer.

## Identity and authority interpretation

The only runtime change computes publicationPosition once from entityLocation.owner, falling back to existing owned position/-1 for other sources, then uses it consistently at the six existing research binding/acquisition/admit/allowed/schedule/declaration calls. Native entityLocation.owner is the collection position, not the tree owner or subject ID. Existing registry.id continues to scope tree ownership; separate subjectId and fieldKey continue to discriminate lifetime/field. Rekey does not replace this lifetime identity; same-key recreation cannot inherit it. No arbitrary path/key inference or new owner is introduced.

Native entity event delivery already matches event position to entityLocation.owner and event subject to entityLocation.subjectId, rejects inspection/rekey, and requires declared field footprint/removal evidence. The fix aligns publication receipt binding with that same native address even when optional enhancer metadata supplies no owned-position list. The preserved trace's -1 binding/event1 mismatch explains the missing ticket receipt. Mapping to the native address enables existing matching; it does not label a write independent.

Research annotate unknown/owner/pending classification is unchanged. Clean ingress requires matching owner+position and is consumed once. Projection still binds identity and requires latest fact; allowed still requires clean, declared early permission or a channel grant, and deferred fallback grants remain fact/channel-bound. Reentry checks before entering endpoint I/O and disposed checks remain present; async continuation reattempts authority. Declaration validation/support and malformed/unknown behavior are unchanged. No public API, settlement owner, protocol carrier or permission bypass added.

## Independent executable challenge

Preregistered EXPECTED.md: two bare entity collections with equal numeric subject IDs; authoritative ingress5 into A; unrelated pending source copied to B7; later useful A6; disposal A8. FIRST.log passes: ingress updates only addressed A without echo; B remains held until confirmation then sends7; A6 sends once; A8 sends nothing after disposal. This checks clean acquisition cannot leak to the sibling native collection and that address alignment does not turn unknown cross-tree input into early permission. It is a finite microtask scheduling probe, not full asynchronous/destroy correctness.

Read the10 new controls and their prewritten expectations: bare/enhanced update/omission exact sends+settled, collection namespace, rekey/recreation lifetime isolation, inspection then useful ordinary send, pending unknown hold, serialized in-flight correction, connection diagnostic drain. Existing own-property28 assertions are unchanged. Their reported38 pass and parent's declaration/delivery/four-framework gates are distinct evidence; reviewer did not rerun Nx or infer universal coverage from counts.

## Limits

No new failure found by source review or the one independent probe. Authoritative ingress semantics remain relationship-specific rather than global ordinary independence. In-flight stale receipts, callback disposal, async declarations and tree teardown rely on unchanged authority/lifecycle checks plus the parent's relevant controls; these were not independently exhaustively re-executed here. No whole integration, later-slice, performance/GC, installed artifact or release sign-off follows.
