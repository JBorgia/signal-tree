# Replay

Node24.15.0; pnpm10.17.0; no dependency/runner changes. Root below is the isolated successor reconstructed from derive-placement-successor final overlay and this final/overlay. Verify final/SOURCE.json (798 TS/TSX files). The predecessor's manifest covered783 TS files; the added TSX coverage changes manifest cardinality, not runtime scope. Only link.ts runtime differs.

```sh
cd /private/tmp/link-fallback-successor/candidate
export PATH=/private/tmp/derive-placement-successor/toolchain:$PATH
export COREPACK_ENABLE_NETWORK=0 NX_DAEMON=false NX_ISOLATE_PLUGINS=false
corepack pnpm exec nx test kernel --testFile=src/lib/link-native-address.spec.ts --testFile=src/lib/entity-own-property-audit.spec.ts --skip-nx-cache
corepack pnpm exec nx test kernel --testFile=src/lib/link-native-address.spec.ts --testFile=src/lib/link-inflight-settlement-audit.spec.ts --testFile=src/lib/link-same-turn-settlement.spec.ts --testFile=src/lib/link-drain-settlement.spec.ts --testFile=src/lib/link-reactive-settlement.spec.ts --skip-nx-cache
corepack pnpm exec nx test angular link-native-address --skip-nx-cache
corepack pnpm exec nx test react link-native-address --skip-nx-cache
corepack pnpm exec nx test vue link-native-address --skip-nx-cache
corepack pnpm exec nx test solid link-native-address --skip-nx-cache
corepack pnpm run typecheck
node tools/check-spec-types.mjs
corepack pnpm exec eslint packages/kernel/src/lib/link.ts packages/kernel/src/lib/link-native-address.spec.ts packages/{angular,react,vue,solid}/src/lib/link-native-address.spec.*
node /private/tmp/link-fallback-successor/replay-controls.mjs
node /private/tmp/link-fallback-successor/replay-controls.mjs combined/focused-final/original-declarations/witness.ts combined/focused-final/independent/witness.ts
node /private/tmp/link-fallback-successor/review/build.cjs
node /private/tmp/link-fallback-successor/review/review-probe.mjs
```

The immutable combined/COMMAND.json is the46-file Nx argument vector, exit1 expected while preserving the original replacement/no-op mismatch. No skip/filter of that assertion. Source after that run changed only new spec guards/formatting; the final10-case spec reran in DELIVERY-FINAL. Existing assertions and runtime hashes did not change. Framework first failures are test-only optional-handle typing: guarded materialized handles then8/8. The new kernel spec also needed guards and a comment documenting intentionally unresolved endpoint I/O; FIRST bodies and diagnostics preserved. Do not attribute those compile/lint errors to runtime.

Archived witnesses are copied byte-for-byte to controls-original. replay-controls.mjs bundles current candidate kernel, aliases only research-private to the current private module, and records witness/bundle/all input hashes. No historical patch loader or historical runtime bundle is used. Rebuilt probe checks142 raw true predicates:141 contract checks plus1 explicitly labeled hidden-input misuse, excluded from safety counts. destruction control permits predestroy delivery; it does not establish automatic cancellation of started I/O. Metadata checks are strong-store diagnostic counts after drain, not GC/retained-receipt collectibility.

First new10 vector on unchanged predecessor:7fail3pass. FIRST.spec.ts exact body retained; final disposal test strengthened to require actual I/O start (no assertion weakened). trace instrumentation is diagnostic only, not candidate source. Reviewer source hashes verified before root replay. Lint final empty log indicates exit0; spec-types ratchet not updated. Angular/Vue/React config-discovery warnings refer to an archived unknown-dynamic-access tsconfig, not failing facade checks.
