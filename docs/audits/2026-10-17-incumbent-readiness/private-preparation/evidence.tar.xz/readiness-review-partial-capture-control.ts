import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
const tree=signalTree<{trigger:{x:number}[];fresh?:number}>({trigger:[{x:0}],fresh:0},{enhancers:[transactions()]});
try{tree.transact(()=>tree.$({fresh:123,trigger:[{get x():number{throw Error('equality failure')}}]}));}catch(e){console.log('error',String(e))}
console.log('after failed transact',JSON.stringify(tree.$()));
tree.destroy();
