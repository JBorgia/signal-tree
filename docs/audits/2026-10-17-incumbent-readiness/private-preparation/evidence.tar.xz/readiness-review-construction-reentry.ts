import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
import {getTreeScalarSlotRuntime} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tree-scalar-slot-port';
const tree=signalTree({rows:{},kept:{}} as {rows:Record<string,unknown>;kept:Record<string,number>},{enhancers:[transactions()]});
const slots=getTreeScalarSlotRuntime(tree.$)!;
for(let i=0;i<3;i++) { const array = [{x:1}]; Object.defineProperty(array,'0',{get(){tree.$.kept({['saved'+i]:i}); throw Error('array diagnostic getter')}}); try {tree.$.rows({fresh:{good:new Uint8Array(100000),bad:array}});}catch(e){console.log(String(e));} console.log(i,slots.slotCount(),JSON.stringify(tree.$())); }
tree.destroy();
