# Independent finite representation review

Both representations demonstrate the required ordinary-order information for the four preserved source failures within the declared model scope. Neither result qualifies native repair or establishes a universally preferable architecture. No native source changes or native sign-off.

## Identity and independent execution

Model SHA256 bdb00609a27f104d3de837c644050741d403e1bf6c5ff138ad8463414af6edff; harness7e944eb44c3bcf3a668531324716c725e70483029de95ba81778374c6c28032b; expected fixturesce11fd4c748a05eaa4732af5a5024622695bb4debea68c0e0b91ec2b13341464. PRE-RUN-FREEZE.sha256 records full preregistration. Copied immutable sources into independent-replay, hashed before running, and executed `node independent-replay/run.mjs` with Node24.15.0. All26 fixture executions pass (13 per representation). Author RESULTS.json was not overwritten; independent raw RUN.log and RESULTS.json are separate. AUTHOR-AFTER.sha256 confirms current author source identities.

Also executed independent fallback-and-live-lease.mjs: full inspection reversal followed by a local ordinary B removal/reinsert; physical DBCA and ordinary ACDB remain distinct; draining a second lease preserves the first lease's facts; inverse of the first unit preserves a later independent A removal and yields ordinary BCD. Both pass; ADDITIONAL.log records results.

## Mechanism and four failure transitions

The models derive ordinary before/after facts through Stage operations before physical installation. Immutable facts drive common inverseIntents/redoIntents. Neither representation reads expected fixture arrays as authority input. The supplied compound physical CAB is explicitly a recorded realization input shared by both; ordinary inverse ABC derives from admitted lifetime facts. This is representability, not proof of selecting the right native physical target.

- Compound: ordinaryABC survives inspectedCBX; own removals/adoptions/freshA produce ordinaryCAX; inverse restores originalA/B and removesX/freshA while ordinary returnsABC and physicalCAB; later B5 leaves ordinaryABC.
- Prepend with callback flush: prepared x has final next:a before install, callback seesXA, one retained history action; inverseA, redoXA.
- Nested append: outerXA visible before callback authorsY; finalXAY, inverseA, redoXAY.
- Nested prepend: outerXA visible before callback authorsY; finalYXA, inverseA, redoYXA.

Snapshot retains complete ordinary sequence/records when divergence requires it and clones them during preparation. Sparse retains lifetime-indexed ordinary presence/adjacency/key/value exceptions plus ordinary head/tail; before any physical patch it preserves every fallback ordinary slot that patch would change. Physical Stage patches both reciprocal neighbors, so that seam supplies an inductive fallback certificate. Both therefore require an explicit ordinary placement authority separate from inspected display, with every physical mutation participating; the result is not a downstream history/Link filter or prepend-specific exception.

Rekey, replaced/missing anchors, full-order ABA, order-only refusal, failed prepare, stale reentry and structural inverse with newer independent field are explicit controls. Full-order refusal lives in a small harness policy wrapper, so its pass shows compatibility with the frozen refusal rule, not a general transaction authority engine. Missing both anchors refuses; no new resolution policy is invented.

## Cost and retention findings

Same instrumented selected-state-operation counts, sizes16/256/1024, fixed local workload including cleanup:

| Representation |16|256|1024|
|---|---:|---:|---:|
| Snapshot |2357|21077|80981|
| Sparse |1283|1283|1283|

After that workload/drain snapshot retains N ordinary records and N order slots; sparse retains4 exceptions. Both share N physical baseline records. Zero internal leases/fact images after drain does not mean zero current ordinary state: ordinaryABC/physicalCAB divergence still requires representation.

For prior full inspection reversal followed by a local field capture/inverse/drain, sparse totals212/692/2228 and retainsN exceptions; snapshot totals682/8362/32938 and retainsN records/order slots. Sparse cleanup scans all current exceptions. Therefore the measured fixed-local advantage does not establish globally bounded cost or retention. Explicit full reorder also scales withN for both (at1024 snapshot68631, sparse70680 selected work units). Negative locality results are preserved; no optimization requested or performed.

Churn1/8/32 keeps internal history/fact leases bounded and retires stale metadata after drain while held inert identities remain external. Retention is INTERNAL model-owned state/leases only; externally returned facts, prepared handles/closures, caller input descriptors and test roots are not measured heap. Prepared plans may retain fact results and the Model closure after consumption; report explicitly disclaims GC. Minor annotation issue: fixed-local `externalInputIdentityDescriptors:3` counts base a/b/c but not also-live x/fresh descriptors; it is not a total external-root count. Do not treat it as such.

Counters are selected instrumented node/entry/map/array work, not exhaustive JavaScript operations, wall time, heap bytes or allocation proof. Initialization, full-output verification and caller array construction have separately labeled counts/exclusions. Full-array copies in snapshot and source/cleanup scans are visible; no uncounted complete ordinary baseline was found in sparse state beyond its explicit exceptions/common physical index.

## Scope verdict and limitations

Finite mechanism verdict: both pass declared scenarios and additional bounded fallback/live-lease control. Cost verdict: sparse is local for the chosen fixed local divergence, but full-order divergence/cleanup has linear cost and retention; snapshot retains/copies complete ordinary state. No universal winner established.

Trusted internal add(lifetime) commands can reinstall an absent supplied lifetime; the model does not prove public retirement authorization. Stale field/rekey commands refuse rather than retarget fresh same-key identity. General key collision preflight, arbitrary overlapping transaction field/order ownership, physical placement compiler correctness, actual collectibility and native writer coverage are out of scope. Those limitations are now explicitly declared rather than passing assertions.

The native rejected package remains identified separately by readiness HEADd441aa0a and manifestd1ff7c33..., with its ordinary-source failures unresolved. A model pass supplies evidence that complete retained ordinary order or certified sparse ordinary placement can represent the missing information; native integration would require a separately authorized scoped change and writer/consumer coverage proof. No automatic continuation follows.
