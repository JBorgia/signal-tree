import assert from 'node:assert/strict';
import {Model,add,remove,reorder} from './model.mjs';
const keys=(m,w)=>m.state(w).map(x=>x.key);
for(const kind of ['snapshot','sparse']){
 const m=new Model(kind),[a,b,c,d]=['a','b','c','d'].map(k=>m.life(k));m.commit([a,b,c,d].map(x=>add(x)));
 m.inspection([reorder([d,c,b,a])]);assert.deepEqual(keys(m),['a','b','c','d']);
 const u=m.commit([remove(b),add(b,{prev:d.id})]);m.retain('first',[u]);assert.deepEqual(keys(m),['a','c','d','b']);assert.deepEqual(keys(m,'physical'),['d','b','c','a']);
 const v=m.commit([remove(a)]);m.retain('second',[v]);m.drain('second');assert.equal(m.retained().leases,1);assert(m.retained().internalRetainedFacts>0);
 m.undo([u]);assert.deepEqual(keys(m),['b','c','d']);m.verify();assert.equal(m.ordinary.read(a.id).present,false);m.drain('first');assert.equal(m.retained().leases,0);console.log('PASS',kind,'full-divergence-local-move-and-live-lease');
}
