import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Model, add, remove, field, reorder } from './model.mjs';
const expected = JSON.parse(fs.readFileSync(new URL('./EXPECTED-FIXTURES.json', import.meta.url), 'utf8'));
const results = [], costs = [], retention = [];
const keys = (m, which) => m.state(which).map(row => row.key);
const checkKeys = (m, ordinary, physical = ordinary) => { assert.deepEqual(keys(m), ordinary); assert.deepEqual(keys(m, 'physical'), physical); m.verify(); };
const seed = (m, names) => { const lives = names.map((key, i) => m.life(key, i + 1)); m.commit(lives.map(life => add(life))); return lives; };
function both(name, run) {
  const pair = [];
  for (const kind of ['snapshot', 'sparse']) { const m = new Model(kind); const result = run(m); m.verify(); pair.push(result); results.push({ name, kind, result }); }
  assert.deepEqual(pair[0], pair[1], `${name}: representation semantic mismatch`);
}

both('compound-inspected-membership-order-rejection', m => {
  const [a,b,c] = seed(m,['a','b','c']); m.commit([field(b,4)]);
  const x = m.life('x',99), freshA = m.life('a',9);
  m.inspection([remove(a)]); m.inspection([add(x)]); m.inspection([reorder([c,b,x])]);
  checkKeys(m,['a','b','c'],['c','b','x']);
  assert.deepEqual(m.state().map(r=>r.n),[1,4,3]);
  let unit = m.commit([remove(b), remove(a), add(x,{prev:c.id}), add(freshA,{next:x.id})], [remove(b),add(freshA,{next:x.id})]);
  // The before-neighbors come from O, not physical C/B/X.
  assert.equal(unit.ordinary[0].before.prev,a.id); assert.equal(unit.ordinary[0].before.next,c.id);
  assert(!unit.ordinary.some(f=>f.kind==='order'),'fixture may not introduce a full-order fact');
  m.retain('pending',[unit]); checkKeys(m,['c','a','x']);
  m.undo([unit],[remove(freshA),remove(x),add(a,{prev:c.id}),add(b,{prev:a.id})]);
  checkKeys(m,['a','b','c'],['c','a','b']);
  assert.equal(m.ordinary.read(a.id).present,true); assert.equal(m.ordinary.read(b.id).present,true);
  assert.equal(m.ordinary.read(x.id).present,false); assert.equal(m.ordinary.read(freshA.id).present,false);
  assert.deepEqual(m.state().map(r=>r.n),[1,4,3]);
  const pendingRetention = m.retained(); unit = null; m.drain('pending');
  const drainedRetention = m.retained();
  retention.push({fixture:'compound',kind:m.kind,pending:pendingRetention,postDrain:drainedRetention,externalFactResultRoots:0,necessaryCurrentDivergence:true});
  m.commit([field(b,5)]); checkKeys(m,['a','b','c'],['c','a','b']);
  assert.deepEqual(m.state().map(r=>r.n),[1,5,3]);
  return {ordinary:m.state(),physical:m.state('physical')};
});

for (const variant of ['flush','append','prepend']) both(`prepend-${variant}-history-redo`, m => {
  const [a] = seed(m,['a']); const x=m.life('x',2),y=m.life('y',3); let history=[];
  const callbackSnapshots=[]; let callbackCount=0;
  const install = (intents, callback) => {
    const plan=m.prepare(intents);
    assert.equal(plan.facts.ordinary[0].after.next, intents[0].next ?? undefined, 'final declared placement must exist before installation');
    const unit=plan.install(); history.push(unit);m.counts.add('harness.historyArrayWrites');m.retain('history',history);
    if(callback)callback(unit);
  };
  install([add(x,{next:a.id})],unit=>{
    callbackCount++; assert.equal(m.leases.get('history')[0],unit,'capture installed before publication');
    callbackSnapshots.push(keys(m,'physical')); assert.deepEqual(keys(m),['x','a']);
    if(variant==='append') install([add(y,{prev:a.id})]);
    else if(variant==='prepend') install([add(y,{next:x.id})]);
    if(variant!=='flush')callbackSnapshots.push(keys(m,'physical'));
  });
  const forward=variant==='append'?['x','a','y']:variant==='prepend'?['y','x','a']:['x','a'];
  assert.equal(callbackCount,1);checkKeys(m,forward);
  const originalAdmissions=history.map(unit=>unit.admission);
  m.undo(history);checkKeys(m,['a']);
  const undone=m.retained(); assert(undone.internalRetiredRecoveryIdentities>=1);
  m.redo(history);checkKeys(m,forward);
  assert.deepEqual(history.map(unit=>unit.admission),originalAdmissions,'redo reuses original source facts');
  assert.equal(callbackCount,1,'redo does not rerun source callback');
  m.drain('history');history.length=0;
  retention.push({fixture:`prepend-${variant}`,kind:m.kind,undone,postDrain:m.retained(),externalFactResultRoots:0,preparedHandleGCClaim:false});
  return {forward,undo:['a'],redo:keys(m),callbackSnapshots,callbackCount};
});

both('foreign-field-preserved-by-inverse',m=>{
  const [a,b,c]=seed(m,['a','b','c']);let unit=m.commit([remove(b)]);m.retain('pending',[unit]);
  m.commit([field(c,44)]);m.undo([unit]);checkKeys(m,['a','b','c']);assert.equal(m.ordinary.read(c.id).n,44);
  unit=null;m.drain('pending');return m.state();
});
both('rekey-is-order-neutral',m=>{
  const [a,b,c]=seed(m,['a','b','c']);const unit=m.commit([{kind:'rekey',id:b.id,key:'z'}]);
  assert.equal(unit.ordinary.length,1);assert.equal(unit.ordinary[0].kind,'rekey');checkKeys(m,['a','z','c']);m.undo([unit]);
  m.inspection([{kind:'rekey',id:b.id,key:'inspected-key'}]);m.commit([field(b,9)]);
  checkKeys(m,['a','b','c'],['a','inspected-key','c']);return {ordinary:m.state(),physical:m.state('physical')};
});
for(const mode of ['removed','replaced','both-missing'])both(`${mode}-anchor-inverse`,m=>{
  const [a,b,c]=seed(m,['a','b','c']);let unit=m.commit([remove(b)]);m.retain('pending',[unit]);
  if(mode==='removed'){m.commit([remove(a)]);m.undo([unit]);checkKeys(m,['b','c']);}
  if(mode==='replaced'){const fresh=m.life('c',33);m.commit([remove(c),add(fresh,{prev:a.id})]);m.undo([unit]);checkKeys(m,['a','b','c']);assert.equal(m.state().at(-1).id,fresh.id);assert.equal(m.physical.read(c.id).present,false);}
  if(mode==='both-missing'){m.commit([remove(a),remove(c)]);const revision=m.revision;assert.throws(()=>m.undo([unit]),/anchors missing/);assert.equal(m.revision,revision);checkKeys(m,[]);}
  unit=null;m.drain('pending');return m.state();
});
both('explicit-full-order-and-ABA',m=>{
  const [a,b,c]=seed(m,['a','b','c']);let units=[m.commit([reorder([c,b,a])]),m.commit([reorder([a,b,c])])];
  assert.notEqual(units[0].admission,units[1].admission);assert.equal(units[0].ordinary[0].kind,'order');
  m.retain('history',units);m.undo(units);checkKeys(m,['a','b','c']);m.redo(units);checkKeys(m,['a','b','c']);
  m.drain('history');units=null;return m.state();
});
for(const aba of [false,true])both(`approved-interleaved-full-order-refusal-ABA-${aba}`,m=>{
  const [a,b,c]=seed(m,['a','b','c']);let units=[];let independentAfterOwn=false,conflict=false;
  // Finite order-only admission policy; no general transaction ownership engine.
  const own=lives=>{if(independentAfterOwn)conflict=true;units.push(m.commit([reorder(lives)]));m.retain('pending-order',units);};
  const independent=lives=>{m.commit([reorder(lives)]);independentAfterOwn=true;};
  own([c,b,a]);independent([b,c,a]);if(aba)independent([c,b,a]);own(aba?[a,b,c]:[a,c,b]);
  const before=m.state(),revision=m.revision;
  const reject=()=>{if(conflict)throw new Error('ordering conflict');m.undo(units);};
  assert.throws(reject,/ordering conflict/);assert.throws(reject,/ordering conflict/);assert.equal(m.revision,revision);assert.deepEqual(m.state(),before);assert.equal(m.leases.size,1);
  m.drain('pending-order');units=null;return m.state();
});
both('prepare-failure-and-reentry',m=>{
  const [a]=seed(m,['a']);const x=m.life('x',2),y=m.life('y',3),before=m.state(),revision=m.revision;
  assert.throws(()=>m.prepare([add(x,{next:a.id})],[add(x,{next:a.id})],{fail:true}),/prepared unit failed/);
  assert.equal(m.revision,revision);assert.deepEqual(m.state(),before);assert.equal(m.leases.size,0);
  const stale=m.prepare([add(x,{next:a.id})]);m.commit([add(y)]);
  assert.throws(()=>stale.install(),/stale prepared revision/);checkKeys(m,['a','y']);
  const reprepare=m.prepare([add(x,{next:a.id})]);reprepare.install();checkKeys(m,['x','a','y']);
  // Both consumed handles still expose fact results and can retain the Model
  // closure. This test explicitly makes no collectibility claim for them.
  retention.push({fixture:'reentry-handles',kind:m.kind,internal:m.retained(),externalPreparedHandles:2,externalFactResults:2,GCClaim:false});
  return m.state();
});

function localWork(kind,size){
  const m=new Model(kind);let lives=seed(m,Array.from({length:size},(_,i)=>`row${i}`));const seedCounts=m.counts.read();
  const [a,b,c]=lives;lives=null;const x=m.life('inspection-x',99),fresh=m.life('row0',9);m.counts.reset();
  m.inspection([remove(a)]);m.inspection([add(x)]);m.inspection([remove(c),add(c,{edge:'head'})]);
  let unit=m.commit([remove(b),remove(a),add(x,{prev:c.id}),add(fresh,{next:x.id})],[remove(b),add(fresh,{next:x.id})]);m.retain('pending',[unit]);
  const pending=m.retained();m.undo([unit],[remove(fresh),remove(x),add(a,{prev:c.id}),add(b,{prev:a.id})]);unit=null;m.drain('pending');
  const drained=m.retained();m.verify();assert.equal(m.ordinary.read(a.id).present,true);assert.equal(m.ordinary.read(x.id).present,false);
  costs.push({kind,size,workload:'fixed-local',counts:m.counts.read(),seedCounts,pending,drained,externalInputIdentityDescriptors:3,externalFactResultRoots:0});
}
function fullOrderWork(kind,size){
  const m=new Model(kind);const lives=seed(m,Array.from({length:size},(_,i)=>`row${i}`));m.counts.reset();
  const ids=[];m.counts.add('harness.inputArraysAllocated');for(let i=lives.length-1;i>=0;i--){ids.push(lives[i]);m.counts.add('harness.inputArrayWrites');}
  const request=reorder(ids);m.counts.add('harness.descriptorArrayEntriesCopied',size);
  m.commit([request]);m.verify();assert.equal(m.state()[0].id,lives.at(-1).id);
  costs.push({kind,size,workload:'explicit-full-order',counts:m.counts.read(),retained:m.retained(),externalInputIdentityDescriptors:size,externalFactResultRoots:0});
}
for(const size of expected.costWorkloads.sizes)for(const kind of ['snapshot','sparse']){localWork(kind,size);fullOrderWork(kind,size);}
for(const size of expected.costWorkloads.sizes)for(const kind of ['snapshot','sparse']) {
  const m=new Model(kind);const lives=seed(m,Array.from({length:size},(_,i)=>`row${i}`));
  const reversed=[];for(let i=lives.length-1;i>=0;i--)reversed.push(lives[i]);
  m.inspection([reorder(reversed)]);const priorDivergenceCounts=m.counts.read();m.counts.reset();
  let unit=m.commit([field(lives[0],999)]);m.retain('point',[unit]);const captureCounts=m.counts.read();
  m.undo([unit]);unit=null;m.drain('point');const drained=m.retained();m.verify();
  assert.equal(m.state()[0].id,lives[0].id);assert.equal(m.state('physical')[0].id,lives.at(-1).id);
  costs.push({kind,size,workload:'full-divergence-then-local-drain',captureCounts,counts:m.counts.read(),priorDivergenceCounts,drained,externalInputIdentityDescriptors:size,externalFactResultRoots:0,localCaptureDoesNotImplyLocalCleanup:true});
}
for(const cycles of [1,8,32])for(const kind of ['snapshot','sparse']){
  const m=new Model(kind);seed(m,['a','b','c']);let maxRetired=0;const held=[];
  for(let i=0;i<cycles;i++){
    let x=m.life('same-key',i);held.push(Object.freeze({id:x.id}));m.counts.add('harness.heldIdentityRecordsAllocated');
    m.inspection([add(x)]);let unit=m.commit([add(x)],[]);m.retain('one-live-obligation',[unit]);m.undo([unit]);
    maxRetired=Math.max(maxRetired,m.retained().internalRetiredRecoveryIdentities);unit=null;x=null;m.drain('one-live-obligation');
    const after=m.retained();assert.equal(after.leases,0);assert.equal(after.internalRetainedFacts,0);assert.equal(after.ordinaryRecords,0);assert.equal(after.physicalRecords,3);
  }
  // Stale field/key commands cannot bind the current same-key lifetime. The
  // privileged internal add(lifetime) command is not a public authorization API.
  const fresh=m.life('same-key',100);m.commit([add(fresh)]);
  for(const identity of held){assert.notEqual(identity.id,fresh.id);assert.equal(m.physical.read(identity.id).present,false);assert.throws(()=>m.commit([{kind:'field',id:identity.id,n:99}]),/missing lifetime/);assert.throws(()=>m.commit([{kind:'rekey',id:identity.id,key:'replacement'}]),/missing lifetime/);}
  m.verify();retention.push({fixture:'churn',kind,cycles,maxRetired,postDrain:m.retained(),externalHeldRetiredIdentities:held.length,externalFactResultRoots:0,counts:m.counts.read(),GCClaim:false});
}

const sparseLocal=costs.filter(r=>r.kind==='sparse'&&r.workload==='fixed-local');
const workTotal=row=>Object.entries(row.counts).filter(([k])=>k.startsWith('work.')||k.startsWith('cleanup.')).reduce((n,[,v])=>n+v,0);
assert.equal(new Set(sparseLocal.map(workTotal)).size,1,'fixed local sparse recorded work must not grow with N');
const report={scope:'finite order representation comparison; counts are selected instrumented state operations, not every JS operation, bytes, CPU or GC',fixtures:results,costs,retention,qualifiedLimitations:['trusted internal lifetime commands, no public authorization engine','no general key collision preflight/ownership/physical placement compiler proof','physical CAB supplied separately as recorded realization input','internal lease retention is not all externally held facts/closures','reorder helper input descriptor arrays are caller construction, counted separately in cost full-order workload','sparse drain scans all current exceptions; prior full divergence makes cleanup O(N) even for a later local field operation','test expected-value array construction/assertion internals are outside representation work'],summary:{fixtureRuns:results.length,sparseFixedLocalWork:sparseLocal.map(row=>({size:row.size,recordedWork:workTotal(row)}))}};
fs.writeFileSync(new URL('./RESULTS.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report.summary));
