# Information boundary (analytical, not another native experiment)

Consider two ordinary initial orders ABC and BAC over the same lifetimes, keys and
payloads. Inspection explicitly displays CAB in each. Current physical state is
identical, and membership/key equality is identical. Required ordinary order is
not identical. A representation that retains only physical topology plus
membership/key divergence has no information to distinguish those histories.
No Link/history formatter can infer which original order was authoritative.

Both compared candidates must retain distinguishing information BEFORE inspection
installs CAB. A snapshot stores the ordinary sequence. Sparse facts store enough
ordinary links, presence and endpoints to separate changed physical edges from
unchanged certified edges. If inspection changes a whole order, sparse facts may
be collection-sized; there is no general zero-storage solution while arbitrary
physical/ordinary permutations diverge. This is current semantic state, separate
from recovery-history retention and from any claim of a permanent canonical copy.

Matching membership or storage key is not an agreement proof for adjacency.
Matching one link does not certify its reciprocal endpoint, head/tail or lifetime
existence. Retiring an exception requires agreement for its represented facts and
preserved independent evidence for all remaining live obligations. These are
invariants to check in the model, not facts granted by naming a data structure.

A model may share authoritative current physical nodes for certified-agreeing
ordinary slots. It must count the shared base and explain every update that can
invalidate certification. Hidden full baseline arrays or uncounted map copies
would change the cost claim, not repair a missing proof.
