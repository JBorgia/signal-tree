# Finite representation check — preregistered acceptance

2026-10-24. Readiness HEAD d441aa0ab6ab2b7c461a082cf8ecdd3e444dc8cd.
Native remains rejected/frozen; no runtime, API, activation or later-slice work.
The refusal policy's bounded pass is separate from this representation question.

Shared invariant: ordinary placement cannot be reconstructed from inspected
physical neighbors. Ordinary and physical placement may differ. Capture must
obtain the ordinary-before and authored ordinary-after facts before installation;
publication, rollback and history must consume those same facts. No consumer
may substitute an expected fixture target, physical snapshot or business key for
missing lifetime-addressed facts. Model expected outcomes are not an authority
input to either candidate.

Two candidate representations, not selected in advance:
- Retained ordinary-order snapshot while ordinary/physical topology diverges.
- Sparse ordinary placement/presence facts indexed by lifetime, with an explicit
  proof obligation for every fallback to physical topology.

Equivalent required operations: ordinary and inspection add/remove/reorder,
ordinary prepend/append, rekey without implicit order authorship, same-key fresh
lifetime replacement; ordinary field-only write must not change order. Capture
must include order/placement intent separately from incidental reads. Initial
ordinary order and absence are established at construction/admission, not supplied
retroactively during rejection. Pure field values are outside the order model.

Unchanged discriminators:
1. Ordinary ABC, inspected removeA/addX/reorderCBX, own setAllCAX, reject:
   ordinary publication ABC; oldA/B restored, freshA/X detached. Physical order
   is separately constrained by authorized footprint/successor policy; do not
   assert physicalABC merely to align it with ordinary truth.
2. Ordinary A, prependX with onAdd flush: source ordinary+physical placement is
   XA; undoA; redoXA, one designated history step.
3. Same prependX with nested appendY: XAY; undoA; redoXAY.
4. Same prependX with nested prependY: YXA; undoA; redoYXA.

Additional discrimination: ordinary edits during physical-only divergence, held
retired references cannot retarget, missing/removed/replaced anchors, preparation
failure changes no admitted state, stale prepared revision refuses atomically,
publication callback reads see complete installation. Approved interleavedfullorder
refusal remains a control; no replay policy is newly selected. Full arbitrary
transaction ownership is outside the order representation model.

Capture work and retention are decision inputs from first execution. Count all
records visited/copied/allocated and retained, including snapshots, map copies,
validation, inverse captures, private preparation, pruning and obligation-held
history. Use increasing collection sizes with fixed local mutations, explicit
full reorder as a separate workload, repeated divergence/churn with fixed live
obligations. Report worst-case locality limits; full requested outputs may visit
output size. Post-drain correctness metadata must not grow with retired lifetimes
or repetitions. Held external refs may retain their own identity, not a global
retired-node table. Model object counts are not bytes, CPU, heap or production
performance. No repeated timing sampling campaign is authorized by this check.

Pass requires a mechanism explaining all four source failures with common capture
and inverse consumers, useful operations, no downstream filtering or writer-specific
neighbor exception. A model alone cannot qualify the native boundary. A missing
operation or unsupported assertion remains an explicit gap, not a safety pass.
Independent review must challenge hidden ordinary mirrors/oracles, unchecked
fallbacks, omitted copying, cleanup that drops live obligations and finalplacement
prepared too late for capture/flush. If a complete solution needs an additional
placement authority or broader topology engine, classify the required scope before
claiming this is an implementation detail. No automatic native migration follows.
