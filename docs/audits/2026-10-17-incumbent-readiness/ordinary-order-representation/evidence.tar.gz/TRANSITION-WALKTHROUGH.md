# Concrete placement facts required by the preserved cases

Analytical derivation before model execution. This is not native qualification.
A/B/C denote non-reused lifetimes; a reused business key names another lifetime.

## Compound rejection

Initial ordinary links: head=A; A.next=B; B.prev=A, B.next=C;
C.prev=B; tail=C. These links establish ordinaryABC.

Inspection removeA changes physical head and B.prev; ordinary still retains A
and B.prev=A. Inspection addX changes physical tail/C.next; ordinary excludes X
and C.next remains absent. Inspection reorderCBX changes adjacency without changing
those lifetimes' business keys. Ordinary B must still resolve prev=A,next=C,
not current physical prev=C,next=X. Presence/key agreement is insufficient to
release any retained ordinary link.

A full retained snapshot remembers ABC before the first inspection installation.
A sparse representation must freeze ordinary state for every physical adjacency
or membership slot the inspection operation changes, including reciprocal links
and head/tail, before that physical frame installs. Reading an untouched slot
from physical state is valid only while a maintained agreement invariant certifies
that slot. On later physical changes the same rule applies using the existing
ordinary representation as the pre-state, never a fresh physical baseline.

Own setAllCAX changes lifetime membership (oldA/B removed; freshA and adopted X
become ordinary), but it does not emit a surviving-order operation in the native
witness. Its captured ordinary removeB must record A/C anchors. The oldA lifetime
and its ordinary key occupancy remain separately captured; freshA cannot replace
that lifetime's identity. Inverse consumes these ordinary authored facts, yielding
ordinaryABC. Physical realization may preserve unrelated inspected C placement;
ordinary egress cannot use that display as its authority. Neither model receives
ABC as a desired inverse target from the test harness.

## Three prepend redo cases

For ordinaryA, prepare insertX beforeA as one complete placement operation. Fresh
X's ordinary add has successorA, not preframe tailA as predecessor. Complete
membership and ordering install before onAdd/flush. Source capture and physical
publication agree in this case because physical/ordinary topology start equal.

The designated history group contains ordered operation facts:
- Plain: [add X beforeA]. Undo removesX; redo installsX beforeA =>XA.
- Nested appendY: [add X beforeA, add Y afterA]. Undo reverses Y thenX;
  redo applies X thenY =>XAY.
- Nested prependY: [add X beforeA, add Y beforeX]. Undo reverses Y thenX;
  redo applies X thenY =>YXA.

A group cannot overwrite the first operation's authored placement with a later
physical snapshot. Pending/captured history owns the facts needed for replay;
current-state storage may release equivalent divergence data only when all live
obligations retain sufficient independent evidence. A retained history record
must not force retention of unrelated rows or historical payload graphs.

## Shared preparation obligation

Neither snapshot nor sparse storage fixes a compound operation whose final
placement is unspecified at preparation. The source frame must include explicit
placement intent/final adjacency before ordinary responsibility is admitted.
A downstream ordinary projection, history formatter or replay sorter cannot
supply the missing semantic distinction. Reentrant callback writes author a later
prepared unit; outer completion may not install another delayed placement.
