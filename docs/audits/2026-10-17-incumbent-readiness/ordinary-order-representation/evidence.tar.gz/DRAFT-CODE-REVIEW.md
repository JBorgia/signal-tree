# Draft code review, before harness freeze/execution

Read model/model.mjs. No executable result or final verdict claimed; no model edits.

Sparse preservation is structurally plausible: Stage physical changes patch every mutated node and reciprocal neighbor; finish preserves ordinary answers for every physical patch slot lacking an ordinary stage patch or prior exception. Heads/tails are captured before install. Existing exceptions survive unmodified physical slots. This supplies a local induction argument only while every physical mutation uses this seam; direct mutations of exposed maps would bypass it and are not proven safe.

Snapshot semantics do not appear to use an expected fixture target: it clones current ordinary records/sequence when divergence exists and captures facts through the same Stage operations. It incurs counted complete copies/scans rather than silently assuming O(1) clone. Its current ordinary mirror can remain necessary after history drain while P/O diverge.

Risks to qualify or falsify at freeze:

1. Model.retained measures internal leases only. Returned facts, prepared closure references and caller-held units are not counted. A consumed plan releases private o/p/ready but still returns facts, including before/after node images. Do not claim total retained memory or all recovery metadata becomes unreachable from internal count zero.
2. Stage.insert accepts any currently absent lifetime ID; no recovery lease or retired lifetime permission is checked. A held handle's field/rekey fails when absent, but `add(oldHeldLife)` can explicitly reinstall it after drain. Either classify add's lifetime inputs as trusted authorized commands and narrow non-reactivation claims, or demonstrate a real authorization boundary. Nonreuse by nextLife alone does not prevent resurrection through supplied IDs.
3. Duplicate active business keys are rejected only by verify after installation, not Stage.insert/rekey preparation. Same-key replacement legal command coverage does not prove invalid-key rejection atomicity. Scope that claim accurately.
4. inverseIntents for field/order restores captured before directly. Arbitrary foreign overlapping authorship is outside model scope. A 'foreign field preserved' control must mean independent newer field survives a structural inverse that does not own that field; it cannot certify general field inverse supersession.
5. Counts are modeled record/entry work, not exhaustive JavaScript allocation or memory. Prepared wrapper/closure allocation, spread delta wrappers and operation input construction are not comprehensively counted. Explain exclusions identically. Retention image counts may count references rather than unique heap objects; do not label bytes.
6. Sparse cleanup scans all current exceptions; snapshot cleanup scans the retained ordinary map. Include cleanup in locality/cost totals rather than reporting only prepare cost. Full state outputs/verifications legitimately scan N and must remain separated, but do not reclassify semantic source scans as verification.

After freeze, review exact harness commands and oracles, count all model-owned preparation clones and history leases, and attempt a bounded adversarial falsifier for any claimed lifetime/anchor capability not established by the standard cases. Native repair remains paused.
