# Existing order storage and authority ownership

Read-only October24; inspected native candidate, no model inference or runtime edits.

## Source-owned physical storage

packages/kernel/src/lib/physical/structural-store.ts:45–80 retains linked active nodes, head/tail, maps and orderFrontier. snapshotActiveOrder at209 enumerates that active order; reorderActiveKeys275 mutates it. This is current physical topology, including inspection. No separate ordinary-order channel exists in this store. The frontier is identity for order validation, not a recoverable historical ordinary sequence.

packages/kernel/src/lib/physical/entity-ordinary-topology.ts:3–28 retains per-lifetime ordinary presence/key/value/optional neighbors and displaced key index. It is source-owned but explicitly membership/key exception-oriented; it has no complete independent ordinary head/tail/order. The observed normalization at entity-signal.ts793–801 drops exceptions by membership/key agreement alone. Its possible adjacency facts cannot establish complete ordinary order after a physical-only full reorder.

## Projection seed is current physical input

packages/kernel/src/lib/entity-signal.ts:4483–4500 defines the seed producer. It enumerates structuralStore.activeKeysSnapshot and getProjectedEntity, returning ordered subject/key/row triples, empty when absent. This allocates a requested snapshot, not retained ordinary order. internals/entity-projection-seed.ts:1–30 explicitly says array order matches all(). It does not reconstruct pre-inspection ordinary topology.

## Link-owned projection

packages/kernel/src/lib/link.ts:310–338 states relationship-creation adoption explicitly: current inspection state existing before connection is legitimately adopted as that relationship's baseline. createEntityEgressProjection is instantiated only on Link construction. Nested collection projections are separately owned per relationship (370–395), and omission/reintroduction can reseed them (557–572).

packages/kernel/src/lib/internals/entity-egress-projection.ts:1–32 describes one consumer's eligible authority, distinct from local topology. Lines82–96 hold order array, rows/key maps, loaded from connection seed. Lines134 onward reorder local topology on inspection while withholding eligible reorder; reseed152 replaces both. Eligibility can therefore differ across connections created at different times. A valid Link projection is not interchangeable with source ordinary truth.

Link disposal link.ts930–958 withdraws held consequences, unsubscribes order capture, resolves/cancels held sends and waiters, and detaches source. Projection lifetime is relationship closure reachability; no source-owned projection exists before any Link connection. It cannot supply ordinary source preparation when no connection exists, and reverse-calling it would invert authority ownership.

## Transaction/history records

transactions.ts2777 onward retains pending own collection endpoints/deltas; cleanup4598/4730/4947 onward is terminal/destruction scoped. These are responsibility/history facts, not a complete current ordinary collection snapshot: foreign changes can occur with no pending transaction and history can be optional/evicted. Likewise a history state snapshot serves its historical entry; it is not current source authority.

## Inventory conclusion

Existing physical index and per-relationship eligible projections can supply algorithms/identity conventions, but neither is an already-retained complete source ordinary-order authority. Any proposed reuse must establish source-owned initialization before physical divergence, ordinary edit participation and cleanup independent of Link or optional history. This inventory selects no new representation and proposes no reverse consumer call or API.
