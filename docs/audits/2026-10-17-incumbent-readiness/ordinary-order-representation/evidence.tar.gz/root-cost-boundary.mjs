import assert from 'node:assert/strict';
import { Model,add,field,reorder } from './model/model.mjs';
// Prepared before execution: a full inspection divergence is a legitimate
// current-state obligation, but need not force every later point drain to scan it.
for(const kind of ['snapshot','sparse']) for(const size of [16,256,1024]) {
 const m=new Model(kind),lives=Array.from({length:size},(_,i)=>m.life(`k${i}`,i));
 m.commit(lives.map(l=>add(l)));m.inspection([reorder([...lives].reverse())]);
 m.counts.reset(); const unit=m.commit([field(lives[3],999)]);m.retain('point',[unit]);
 const capture=m.counts.read();m.counts.reset();m.drain('point');const cleanup=m.counts.read();
 assert.equal(m.ordinary.read(lives[3].id).n,999);
 console.log(JSON.stringify({kind,size,capture,cleanup,retained:m.retained()}));
}
