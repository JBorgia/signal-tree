# Independent premise and review criteria: finite ordinary-order representation check

Native repair is paused. This comparison evaluates two isolated representations against the same four preserved failures; it does not authorize implementing either in native runtime or accepting a broader architecture. Criteria written before model source/result review. No preferred representation or target verdict supplied.

## Raw failure premises and immutable expected transitions

1. Prepend with flush inside onAdd: ordinary [a]; designated prepend x must install/publish [x,a] before callback; callback flush retains one complete action. Undo restores [a]; redo restores [x,a], same lifetime identities and values. The previous native trace published correct physical x-afterSubject:a while ordinary metadata incorrectly said x-beforeSubject:a. Neither model may copy that erroneous native fact as its oracle.
2. Nested addMany from prepend onAdd: [a] -> outer prepend x -> callback append y yields [x,a,y]. After callbacks removed, undo returns [a]; redo returns [x,a,y]. Capture must preserve two distinct operations and their placements, even though they belong to one designated history step.
3. Nested prependMany from prepend onAdd: [a] -> outer prepend x -> callback prepend y yields [y,x,a]. Undo [a], redo [y,x,a]. Capturing only the outer operation or reading final physical order at later replay is insufficient.
4. Ordinary/inspection compound rejection: ordinary A1/B4/C3 remains authoritative while inspection removes oldA, creates X99 and displays C/B/X. Own setAll C3/freshA9/X99 has distinct lifetimes oldA, B, X and freshA in its responsibility. Reject restores oldA1 and B4, removes X and freshA, and ordinary egress remains A1/B4/C3. Subsequent ordinary B5 must publish A1/B5/C3. Physical placement during inspection divergence is not independently prescribed by the ordinary-only regression; model must expose ordinary and physical outputs separately and must not use permissive physical placement to justify ordinary CAB. No independent ordinary full-order authorship occurred in this case.

Ordinary source facts must encode these results before consumer callbacks can flush. Inspection-only placements/membership/value displays cannot become ordinary responsibility because later capture or replay consults physical state.

## Equivalent capabilities required of both representations

- Same complete operation vocabulary: ordinary insert/prepend/append/remove/rekey/replace, ordinary full reorder, ordinary field writes, inspection changes, begin/confirm/reject, undo/redo, and callback reentry at declared publication boundaries. If the finite models implement a smaller vocabulary, declare exact unsupported cases for BOTH; do not compare one complete engine against a special-case fixture runner.
- Explicit entity lifetimes independent of keys and row values. Removed oldA versus freshA using key a are distinct. Restore/rekey must resolve owner-qualified lifetime identity, preserve held oldA/B identity and retire X/freshA as required. Keys alone cannot be sparse-fact identity.
- Ordinary state remains readable while display diverges. An ordinary field write during inspection divergence updates the current ordinary value without adopting inspected neighbors; an ordinary full reorder explicitly authors order and is distinguishable from incidental current physical order encountered during membership mutation.
- Full-order authorship is supported as an authored operation, including equal endpoints after intervening operations. Sparse representation may need work/facts proportional to the touched order; that cost is part of the comparison, not a reason to omit full-order support. Snapshot representation must preserve intermediate authorship/reentry where endpoints alone cannot distinguish responsibility.
- Both retain the information needed for inverse and redo, not merely current view. History/transaction captures must remain immutable when later operations mutate current state. Applying one inverse cannot consume evidence another live handle/history action requires. Repeated terminal actions must not replay fresh mutations.
- Reentry observes the whole committed compound operation before it authors the next operation. Capturing native preparation before final prepend placement and repairing it from later display is not accepted. Preparation failure before install leaves state and responsibility unchanged; installed operation followed by callback failure remains attributable under the declared model semantics.
- Both expose the same egress oracle or ordinary snapshot. Do not let snapshot variant read retained ordinary data while sparse variant reconstructs from physical display, or let one bypass its own representation to use an omniscient fixture baseline.

## Fair work and retention accounting

Record exact model sources, command, environment, fixture sizes and operation counts. Report semantic results separately from cost counts; one timing is not a performance conclusion.

Count actual element visits, copied row/value/lifetime/order entries, map/set accesses/allocations where modeled, retained live facts/endpoints and high-water retention. Include initial state, fallback/materialization scans, hidden full-array copies, sorting, external baseline tables, lookup indexes, undo/redo journal entries, snapshots retained by closures and per-operation records. Persistent/shared storage may share unchanged objects, but account for both references and newly retained payload/facts. State what is deliberately excluded (e.g. JavaScript object overhead), identically for both.

Distinguish current storage from history/obligation retention. Record after initialization, inspection divergence, own unit, refusal/rollback or confirmation, undo/redo and cleanup. Keep handles/actions alive during one retention check; then release obligations and repeat. Count the total information actually needed to reconstruct order; a sparse map with an uncounted complete baseline array is not an O(k) storage result.

Use fixed small mutation counts with increasing untouched collection size for point/divergence workloads, and separately full-order workloads touching all members. Snapshot O(n) versus sparse O(k) is a hypothesis, not a scoring requirement. Sparse chains must count traversal/dependency work and fallback scans; snapshots must count copies and retention. No unrelated stress expansion or native benchmarks are required for this finite check.

## Independent execution review after freeze

Before execution: receive source freeze and hash implementations, harness/oracle, fixtures and scripts. Inspect code before accepting counts. Replay the same four cases on both; assert exact intermediate ordinary/display values, identity, final egress, action boundaries and cleanup. Add only a bounded falsifier when code exposes a concrete information gap (e.g. same-key replacement, full-order ABA, unrelated field during divergence, reentrant ordering); record first failure and avoid changing expectations to pass.

Verdict options: both fail; both pass within finite scope with quantified costs/limits; one lacks required information; test/model insufficient. No headcount, model name, passing-case count alone or asymptotic label establishes architectural acceptance. A toy-model pass demonstrates representability for the modeled contract, not native integration correctness, public API compatibility, reclamation or release readiness.

## Preregistered scope alignment

After writing the criteria above, read CHECK-CONTRACT.md. It fixes readiness HEAD d441aa0ab6ab2b7c461a082cf8ecdd3e444dc8cd, rejectednative manifest d1ff7c33a380d578390879a79e142950d0655920710a818af7d49fe2a017521b, runtime8ccc2ed7 and entity source0209436... . These identify preserved failures; no native execution/repair is requested.

The comparison is an order representation model, not a complete value/transaction engine: pure field payload implementation and arbitrary transaction ownership are outside scope. References above to row values/field writes require order-neutral operation handling and fixture identity labels sufficient to detect accidental adoption, not a new value engine. Equivalent supported operation surface in CHECK-CONTRACT governs. No additional feature implementation is implied by this review. Reentry, failure atomicity and history boundaries are checked only through the finite declared model interfaces. Any necessary additional topology/placement authority must be identified as required scope rather than disguised as an implementation detail.
