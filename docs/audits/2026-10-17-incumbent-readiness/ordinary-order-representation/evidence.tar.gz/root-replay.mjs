import assert from 'node:assert/strict';
import { Model, add, remove, field, reorder } from './model/model.mjs';
// Independent bounded recurrence probe. Oracle is used only by assertions;
// neither implementation receives an ordinary target during inverse execution.
for (const kind of ['snapshot','sparse']) {
 const m=new Model(kind), lives=Array.from({length:16},(_,i)=>m.life(`k${i}`,i));
 m.commit(lives.map(l=>add(l)));
 const expected=lives.map(l=>({id:l.id,key:l.key,n:l.n}));
 for(let i=0;i<25;i++) {
  const rotation=(i*7+3)%lives.length;
  const p=[...lives.slice(rotation),...lives.slice(0,rotation)];
  if(i%2) p.reverse();
  m.inspection([reorder(p)]);
  assert.deepEqual(m.state(),expected);
  const x=m.life(`fresh${i}`,900+i), a=lives[4], b=lives[5], c=lives[9];
  const unit=m.commit([remove(a),add(x,{next:b.id})]);
  m.retain('pending',[unit]);
  m.commit([field(c,100+i)]); expected[9]={...expected[9],n:100+i};
  m.undo([unit]);
  assert.deepEqual(m.state(),expected);
  assert.equal(m.ordinary.read(x.id).present,false);
  m.verify(); m.drain('pending');
  assert.equal(m.retained().leases,0);
 }
 console.log(JSON.stringify({kind,iterations:25,ordinaryOrderAndForeignFields:'pass',retention:m.retained()}));
}
