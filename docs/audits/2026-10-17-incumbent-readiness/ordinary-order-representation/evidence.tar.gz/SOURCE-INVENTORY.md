# Ordinary-order representation: neutral source inventory

Read-only October24. Source root /private/tmp/inverse-disposition-native/candidate; preserved failing-source evidence identified by d441aa0a. Native runtime remains paused. Line references describe inspected files, not a new test run or guarantee that mutable temp source equals a commit; frozen manifests remain the authoritative identity.

| Responsibility | Exact source location | Present behavior / required invariant |
| --- | --- | --- |
| Ordinary state storage | packages/kernel/src/lib/physical/entity-ordinary-topology.ts:3–28 | Per-lifetime presence/key/value/neighbors, displaced-key index. Class comment restricts retention to membership/key divergence. Order can diverge with identical membership/key; storage invariant must account for this explicitly. |
| Ordinary lookup for inverse | packages/kernel/src/lib/entity-signal.ts:616–621 | Installed/staged exception else physical active key and neighbors. A physical fallback needs a proved order-agreement condition, not merely matching key. |
| Ordinary lookup for forward source capture | same:705–736 | read(subject) falls back to physical getNeighborSubjects; atKey checks staged vacancy and lifetime. These resolve occupancy and order together although their divergence differs. |
| Inspection preservation | same:744–750 | Only the physically changed subject's ordinary state is staged when structural effect exists. A full reorder can alter adjacency of survivors that have no membership mutation. Must retain every ordinary order fact later queried. |
| Ordinary remove/inverse facts | same:737–740,751–754 | record(remove) serializes neighbors from ordinary read. Once contaminated here, inverse lowering/history cannot recover original order from that record. |
| Ordinary bind/rekey | same:755–786 | New existence can take physical neighbors; same-lifetime rekey spreads prior ordinary state. Key transfer must preserve placement unless operation expressly authors it; fresh insertion needs final intended placement. |
| Normalization | same:793–801 | Drops exception when key/presence agrees physically. Matching occupancy alone does not establish order agreement. No candidate design may silently use this normalization criterion for adjacency. |
| Fresh physical frame admission | same:850–915 | Creates add record at pre-frame tail, tombstone uses physical neighbors, transfers carry keys. Prepare ordinary plan precedes source installation. Compound final placement must already be represented before responsibility install. |
| Explicit order capture | same:1399–1409 | Publishes collection before/after subjects plus frontier using existing capture protocol. Ordinary and physical order inputs must be distinguished. |
| Prepend compound completion | same:2015–2022,2143–2150,2195 | Frame commits then moveToFront; physical publication sees final neighbors but ordinary record was prepared earlier. Nested observer flush must never observe contradictory channels. |
| Physical adjacency | same:1670 onward | Neighbor resolution refers structuralStore current physical order. Legitimate physical input; insufficient evidence of ordinary placement after inspection divergence. |
| Full setAll | same:4083–4194 | Incoming/current subjects determine target, order publication and final neighbors. Explicit full order can inspect its supplied members; merely observed survivor order cannot silently become authored ordinary truth. |
| Consumer selection | packages/kernel/src/lib/internals/ordinary-entity-entries.ts:9–27 | ordinaryChanges.structuralRecord replaces physical structuralEffect. Requires source agreement where ordinary and physical coincide; consumer must not guess which contradictory anchor wins. |
| Pending capture/drain | packages/kernel/src/enhancers/transactions/transactions.ts:2777 onward;1842 | Own order endpoints stored separately; bucket drain clears source collectionOrders. Any retained ordinary topology has its own obligations, not optional pending history. |
| Pending terminal cleanup | same:4598,4730,4947–4959 | Confirmation/rejection dispose deltas; destroy unsubscribes. New order records require precise lifetime/terminal ownership and must not be orphaned by refusal or history eviction. |
| Retired entity reclaim | packages/kernel/src/lib/entity-signal.ts:2850–2866 | Restoration authority and ordinaryTopology.retains prevent backing retirement. Order dependency retention must distinguish identity-only references from value/backing obligations. |

## Shared requirements for either representation

- Ordinary order established at construction and ordinary authored/realized installation; inspection can change physical display without changing it.
- Lifetime identity survives rekey and ordinary restoration. Same-key replacement is a new identity; held old references never retarget.
- Presence, key, placement and payload are separate. Approved relocation can retain physical99/ordinary7.
- Removing a member updates surviving adjacency consistently; inverse stores sufficient lifetime-sensitive placement facts under approved successor policy.
- Full reorder explicitly authors broader order. Append/prepend should not reconstruct growing dependency maps or scan unrelated members. Point writes do not need collection order enumeration.
- Prepare complete topology and source facts privately; responsibility, installation and publication consume that same prepared unit. Reentry/throws cannot leave early ordinary placement paired with later physical placement.
- Refusal retains records and authority; successful terminality and ordinary churn retire obligation-free records. No whole order copy retained merely because one old receipt exists.

## Representation comparison obligations (no selection)

**Full retained ordinary snapshot:** specify when created (always or first divergence), how initialized before inspection mutates base, how ordinary edits update it, and when released. Measure first-divergence O(n) capture and retained identity count; copying every append is quadratic and is not justified by snapshot convenience. A full requested reorder may legitimately enumerate its output. Must not store a second independently writable authority or duplicate payload graph unnecessarily.

**Sparse adjacency overrides with explicit physical base:** specify a checkable agreement domain for all non-overridden links; inspection changes must freeze affected ordinary links before altering physical base. Membership/key agreement cannot certify link agreement. Override updates need both directions/head/tail and lifetime-aware absence; normalization must prove complete local ordinary adjacency equals base. Full inspection reorder may require O(n) exceptions; measure this honestly rather than hiding a scan or permitting incorrect fallback. Bound chains, lookup traversal and retention after convergence.

Both must explain ordinary full-order restore after inspected remove/reorder, final prepend placement before nested flush, rejection footprints leaving unrelated inspected display untouched, and conflict/retry cleanup. No new public API or different successor placement semantics follow from this inventory.
