# Work and retention interpretation

Model counters are selected algorithm events, not every JavaScript operation,
allocation byte, CPU cost or heap measurement. Raw FIRST-RUN.log and RESULTS.json
remain unchanged. Composite totals sum unlike event categories; they demonstrate
same-work invariance only and must not be interpreted as CPU ratios.

For the fixed-local workload, externalInputIdentityDescriptors:3 in the raw result
counts retained original base descriptors a/b/c. The x/fresh descriptors also
remain fixture variables, making five explicit descriptor roots, not three total.
These are inert identity/key/token records, not trees, and their omission does not
change the separately labeled internal lease/map counts. Do not present that field
as a complete external-root measurement.

InternalRetainedNodeImages/OrderSlots/Facts are logical references through model
leases. Shared units referenced by more than one lease can be counted more than
once; they are not unique heap-object or retained-byte counts. Externally retained
fact results/prepared closures are outside that internal view and can retain facts
or a Model. No collectibility claim is made. Churn fixtures explicitly release
fact-result variables before checking internal post-drain state; held inert IDs
are separately counted. The privileged internal add(lifetime) command is not a
public lifetime-admission authority; stale field/rekey checks demonstrate no
retargeting, not universal authorization of restoration.

Current ordinary divergence is not a leak. If ordinaryABC and physicalCAB remain,
sufficient distinguishing state must remain even with zero pending/history leases.
After a full permutation this can be collection-sized in either representation.
Snapshot retention additionally covers unchanged ordinary members; sparse local
exceptions cover affected slots. History/inverse facts retire only after their
last model lease is released. Process GC and native destruction are not measured.

Explicit full-order descriptors/outputs legitimately enumerate their members.
Input descriptor construction and test-only invariant/retention walks are labeled
separately; fallback, preparation copies, ordinary sequence enumeration and cleanup
are included in the reported implementation work. Raw cleanup.cleanup.* names are
a phase/category prefix, not an extra traversal or missing counter.

The negative workload matters independently of the four semantic passes: prior
full physical divergence followed by a local point operation still makes sparse
cleanup scan all current exceptions. The model preserves this result; it has not
been optimized away or rerun until favorable. Local normalization/pruning would
need its own invariant and verification before claiming local drain.
