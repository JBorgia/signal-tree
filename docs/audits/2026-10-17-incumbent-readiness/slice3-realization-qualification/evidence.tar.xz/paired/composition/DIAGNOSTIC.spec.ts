import {expect,it} from 'vitest';
import {entityMap,restoration,signalTree,transactions,undoable} from '../index';
import {withWriteContext} from './write-context';
import type {CollectionTransitionTargetBinding} from './internals/causal-runtime/target-transition';
const flush=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
for(const reentry of [false,true])it(`hidden readd preparation preserves pending topology and history (${reentry})`,async()=>{
 const t=signalTree({count:0,g:{rows:entityMap<{id:string;n:number},string>(),k:0}},{enhancers:[transactions(),restoration()]});const r=t.$.g.rows;
 try{r.addOne({id:'a',n:7});await flush();const a=r.byIdOrFail('a');undoable(()=>t.$({count:0,g:{k:0}}));await flush();expect(r.all()).toEqual([]);
 const failure=new Error('hidden preparation');const off=r.intercept({onAdd:row=>{if(row.id==='b'){if(reentry)withWriteContext({intent:'system',participation:'realized'},()=>t.$.count(5));throw failure;}}});
 try{expect(()=>t.transact(()=>r.addOne({id:'b',n:9}))).toThrow(failure);}finally{off();}
 expect(r.all()).toEqual([]);expect(t.$.count()).toBe(reentry?5:0);
 const p=t.transact(()=>r.addOne({id:'b',n:9}));expect(r.all()).toEqual([{id:'b',n:9}]);p.rollback();await flush();expect(r.all()).toEqual([]);
 t.undo();await flush();expect(r.all()).toEqual([{id:'a',n:7}]);expect(r.byIdOrFail('a')).toBe(a);
 }finally{t.destroy();}
});
for(const reentry of [false,true])it(`mixed inspected adoption history inverse refuses atomically and retries (${reentry})`,async()=>{
 const t=signalTree({count:0,rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions(),restoration()]});const r=t.$.rows;
 try{r.setAll([{id:'a',n:7},{id:'b',n:8}]);await flush();const a=r.byIdOrFail('a'),b=r.byIdOrFail('b');withWriteContext({participation:'inspection'},()=>{r.updateOne('a',{n:99});r.removeOne('b');});await flush();
 undoable(()=>r.setAll([{id:'a',n:99},{id:'c',n:9}]));await flush();const binding=(r as unknown as {__prepareTransitionTarget:CollectionTransitionTargetBinding}).__prepareTransitionTarget;const original=binding.prepareTarget;const failure=new Error('history preparation');let entered=false;
 binding.prepareTarget=(...args)=>{const plan=original(...args);entered=true;if(reentry)t.$.count(5);else throw failure;return plan;};
 try{let error:unknown;try{t.undo();}catch(e){error=e;}console.log('HISTORY-PROBE',JSON.stringify({reentry,entered,error:String(error),rows:r.all()}));expect(entered).toBe(true);expect(error).toBeDefined();}finally{binding.prepareTarget=original;}
 expect(entered).toBe(true);expect(r.all()).toEqual([{id:'a',n:99},{id:'c',n:9}]);expect(t.$.count()).toBe(reentry?5:0);
 t.undo();await flush();expect(r.all()).toEqual([{id:'a',n:7},{id:'b',n:8}]);expect(r.byIdOrFail('a')).toBe(a);expect(r.byIdOrFail('b')).toBe(b);
 }finally{t.destroy();}
});
