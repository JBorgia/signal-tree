# New composition controls

Final3/3 pass via configured Nx newfile only (REACHABLE.log). No runtime edits. Original first source/hash and FIRST.log retained, intermediate DIAGNOSTIC.spec.ts/log and SECOND.log preserved.

Corrections to NEW test premises, not weakened established assertions:
- Hidden onAdd scalar write inside failing transact belongs to same transaction; abort restores0, not5. Original5 expectation was wrong. Intermediate realized context proved an independent producer but final case uses ordinary owned write and expects0 per existing transaction contract.
- First mixed setup inspection-removedB left B outside authored footprint, so undo did not require full target and correctly left it absent. Updated setup inspects fieldA only; designated ownsetAll replacesB withC and undo restoresB.
- __prepareTransitionTarget wrapper was unreachable for chosen undo route (enteredfalse). Final controlled fault wraps existing getTreeRealizationPort.prepareOrdinaryEffects, calls original to complete preparation then throws; atomic unchangedA99/C9 asserted, restoring method permits useful undoA7/B8 with held identities. No runtime recovery/observer policy altered.

These are supported test-only private controlled failures, not ordinary-input throw or OOM guarantees. Three tests cover hidden readd preparation failure, owned synchronous reentry under abort, and actual paired-history preparation fault/refusal/retry. They do not establish arbitrary reentrant inverse refusal or full hidden/retirement qualification.
