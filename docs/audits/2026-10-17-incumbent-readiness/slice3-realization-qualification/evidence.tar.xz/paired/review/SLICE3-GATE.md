# Independent finite slice3 gate assessment

Slice3 remains open due one concrete unchanged large-restoration work assertion, not a newly invented coverage campaign. The bounded raw-restoration pairing correction itself has no demonstrated remaining blocker under its reviewed contract. Reviewed evidence SOURCE.json SHA25642d28937e4a719c770747e87d07c019ea725df2402e1c6e7005111967613df4a; exact runtime restoration hash/probe inputs are retained in REVIEW.md and paired-INPUTS.json. No runtime/controller/test edits by reviewer.

## Mapping and actual evidence

Approved f806 slice3 audits S3–S6/W9–W11, modifying only proven incompatible handoffs. S3 minimal transaction point discharge was already slice1; current pairing migrates restoration's nondeclarative structural caller to the existing selected-O/physical lowering seam. Same prepared array validates and installs. S4 declarative target keeps separate admitted effects/order; prior redo2 O-loss was exposed by later declarative redo3 rather than caused by its field guard. S5 revive/rekey/anchor/refusal now has named positive and atomic refusal/retry controls. S6 order/selection remains existing channels; source ordinary presence and recovery claims remain independent backing obligations.

COMBINED-COMMAND.json executes actual prior missing E7 authority/Link/diff paths, W9 generic and entity membership producer plus hidden terminal/nesting, W11 last-owner/eviction/truncation/reset/destroy claim boundaries, jump-vs-undo histories, marker hydrate recovery, three composition controls and existing compensation/provenance controls. COMBINED-FIRST.log records16files362passes. These cover concrete route assertions; the aggregate is not proof. Existing prior slice1/2 exact-source controls remain inherited prerequisite evidence, not new counts.

The three new composition premises are separately adjudicated in REVIEW.md: owned failing-transaction callback reentry rolls back to0; inspection-only removedB is not owned restoration; final fault wrapper actually invokes original prepareOrdinaryEffects then throws before validation/install, preserving physical rows and useful history retry. Final fixture uses Reflect.apply only to express established runtime omission in closed construction typing; no public omission type promise or API change follows. Earlier failed new harness/type attempts remain preserved. No claim every first-red was runtime failure.

Own public/protocol replay restores hiddenE then mixedABDE and publishes subsequent ordinaryE6 coherently. An additional bounded present-parent nested entity update+same-turn add probe also succeeds (NESTED-FIRST.log), so source length>1 guard alone is not promoted into a current public defect. This negative result does not qualify arbitrary nested missing-parent policy; prior conditional contract remains conditional, without forcing a product decision for unproven shape.

## Concrete remaining gate

Unchanged large-batch-restoration-v16-controls completes rather than times out: LARGE-RESTORATION-FIRST.log is1pass/1fail after~91seconds. `jumps across a turn that cleared more rows than the argument limit` expects valueStoreWrites130000 but observes260000 at line62. This is a fresh deterministic work assertion failure. It is not a predicate counter, a timeout, or an endpoint mismatch. Do not relax its130000 assertion or call362 focused passes slice3 completion. Parent traces first duplicate write separately; this review does not speculate whether producer, ordinary/physical installation or measurement scope caused it.

This is the first concrete remaining requirement from the finite current vector. No additional broad suites or speculative new tests are needed before that causal trace. Whether correction is a missing installation handoff versus recurrence depends on exact duplicate source and prior claimed scope, not its numerical count. Preserve initial log/source identity and compare baseline if needed.

## Limits

Current owner touched-index convergence and source lifetime protection are distinct from full collectibility. Last recovery-claim release controls do not prove externally held entity handle disposal empties source maps. No slice4 full framework/lifecycle matrix, slice5 artifacts/budgets/CPU campaign, activation, new ordinary semantics or release acceptance inferred. Audit remains read-only; root owns final semantic interpretation and any authorized bounded correction.
