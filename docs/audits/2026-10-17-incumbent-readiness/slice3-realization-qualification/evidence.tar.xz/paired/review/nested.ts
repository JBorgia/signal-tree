import {signalTree,entityMap,restoration,undoable} from '@case/index';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
const t=signalTree({rows:entityMap<{id:string;box:{value:number;sibling:number}},string>()},{enhancers:[restoration()]});
try{const r=t.$.rows;r.addOne({id:'a',box:{value:1,sibling:8}});await tick();undoable(()=>{r.updateOne('a',{box:{value:2,sibling:8}});r.addOne({id:'b',box:{value:3,sibling:9}});});await tick();console.log('BEFORE',JSON.stringify(r.all()));try{t.undo();console.log('AFTER',JSON.stringify(r.all()));}catch(e){console.log('REFUSAL',String(e),'STATE',JSON.stringify(r.all()));throw e;}}finally{t.destroy();}
