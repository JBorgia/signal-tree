# Independent ordinary-only installation review

No concrete blocker demonstrated in this bounded source installation-role correction. Reviewed exact files in SOURCE-HASHES.json against frozen paired successor. Full value installers preserve existing order/semantics; only prepareOrdinaryRealization's final value loop now installs baseline authority without rewriting already-installed physical backing. No candidate/runtime/tests/controller edits by reviewer.

## Callers and coherence

Source search finds two production callers of native __prepareOrdinaryRealization: heterogeneous realization plan and complete target host. Heterogeneous install commits scalar/entity physical effects, removals/revivals/rekeys before ordinaryPlans.install. Target install applies prepared structural target and prepared value target before ordinaryPlan.install. Both preserve callback-free staging/physical installation followed by ordinary authority, with publication afterward. This source plan is not a standalone physical installer; private synthetic direct calls cannot establish a public entitlement to install P from it alone.

The new EntityValueStore.installOrdinaryValueTransition updates only inspectionBaselines using existing prepared retainDivergence. Full installValueTransition delegates that baseline operation then retains its previous valueStoreWrites/backing.set behavior; other full installers unchanged. There is no equality skip or counter exclusion for a real physical installation. Actual physical installation is no longer duplicated by a second equivalent write from source metadata. Current payload store remains sole owner; ordinary stage maps remain temporary prepared facts. Removal discharge and placement normalization remain source responsibilities.

Prepared O/P equality/presence is still calculated at prepareOrdinaryRealization's existing point; both callers supply/derive actual selected physical outcomes before ordinary-only installation. Active inspected P99 with O7 retains divergence; equal O/P discharges baseline; ordinary absent removes only O metadata while physical plan decides actual removal. Field address restrictions/nested fallback and existing revision/refusal guards are unchanged by this delta. No new adoption, placement, authority or SDK API introduced.

## Independent native discriminator

EXPECTED.md and BEFORE.sha256 precede execution; ordinary-INPUTS.json records loaded source bodies. Public history turn updates A.m and addsB after inspection A.n99 over ordinary7. Undo leaves physical A99/m0 while collection Link publishes A7/m0. A test-only wrapper around ordinary-only installer asserts retained backing identity does not change within that method. Later ordinary A.n100 publishes useful A100/m0. FIRST.log records distinct useful sends, not a vacuous absence. This exercises active inspection divergence and mixed field/structure on the heterogeneous route; complete-target physical-first ordering additionally inspected in source.

Parent3size work falsifiers and unchanged130k assertion must qualify actual physical write counts and target route; reported small green alone is not acceptance. Parent original362/695 compatibility, faults/reentry, types/spec-types/lint and large gate are separate execution evidence. Reviewer did not rerun those suites.

## Limits

Preparation failures still must install neither domain; callbacks/reentry remain under existing revision boundary. This change adds no user callbacks or late notification work. Broader nested missing-parent policy, arbitrary direct private callers, multiowner hidden combinations and current/historical backing GC are not newly qualified. No overall slice3 completion, later gates, CPU cost or release sign-off inferred. Original130k 2N failure and new small first reds remain preserved unchanged.
