import {signalTree,entityMap,restoration,undoable} from './packages/kernel/src/index';
const tick=async()=>{for(let i=0;i<10;i++)await Promise.resolve();};
const t=signalTree({g:{rows:entityMap<{id:string;n:number},string>(), k:0,s:0,h:{x:0,y:0}},count:0},{enhancers:[restoration()]});
const log=(step:string)=>console.log(JSON.stringify({step,state:t.$()}));
try{
await tick();
const steps=[()=>t.$.count(1),()=>t.$({g:{h:{x:0,y:0}},count:9} as never),()=>t.$.g.rows.addOne({id:'e',n:0}),()=>t.$.g.rows.setAll([{id:'a',n:1},{id:'b',n:2},{id:'d',n:3},{id:'e',n:4}])];
for(let i=0;i<steps.length;i++){undoable(steps[i]);await tick();log('write'+i);}
for(let i=3;i>1;i--){log('before undo'+i);t.undo();await tick();log('after undo'+i);}
log('before redo2');t.redo();await tick();log('after redo2');log('before redo3');t.redo();await tick();log('after redo3');
}catch(e){console.log(JSON.stringify({error:e instanceof Error?e.message:String(e),state:t.$()}));}finally{t.destroy();}
