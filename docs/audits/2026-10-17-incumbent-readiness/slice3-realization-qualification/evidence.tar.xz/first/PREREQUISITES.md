# Read-only slice3 prerequisite audit

Base is isolated finalpending manifest67869b6525433a7ad5fceb88042cf25b50d2d90d045408a249b2f673aae3caf9, after bounded slice2 disposition review/GATE.md. No runtime changes resumed. Approved f80645c8 plan181 requires auditing S3–S6/W9–W11 and modifying only proven incompatible handoffs: compound rollback/undo/redo, hidden reintroduction, retained lifetime identity, failed preparation/atomic refusal/useful retry and protected recovery claims. Existing completed cases are prerequisites, not inherited proof of every new route.

## Already current; do not rerun merely for counts

Current61file vector contains minimal transaction point discharge, compound occupancy/structural inverse, source ordinary placement/order/full/subset, selected O/P publication, failed owner preparation/reentry, rekey refusal, selection lifetime, source capture chronology, held lifetime minimal ledger, callbacks and ordinary/inspection egress. E10 correctness shards16+11 pass separately. These qualify specific minimal inverse dependencies already needed by slices1/2; they do not establish full history/hidden/retirement disposition.

## Smallest staged existing vector

First run the following unchanged files with command and pre/post exact source manifest, no runtime repair before first results:

- lib/entity-restoration-authority.spec.ts: construction-fixed authority, pre/post-attachment retirement rights, restored payload and no-owner reclamation. W11 must not treat source O retention as blanket restoration authority.
- lib/entity-membership-link-restoration.spec.ts: pending/undo membership remove/add/replace and actual Link endpoint coherence. W10 requires ordinary publication, not only physical rows.
- lib/entity-restore-diff.spec.ts: same-shape point fast path versus add/remove/reorder/different-ID/empty fallback, useful repeated undo. Compare source ordinary disposition at both seams rather than assuming unchanged fallback safe.
- enhancers/restoration/restoration-missing-anchors.spec.ts: exact atomic multi/single restore refusal, retained retryable history, successful placement controls and owner-qualified identities. Do not reinterpret missing placement as blanket refusal.
- lib/entity-membership-producer.spec.ts plus lib/whole-value-membership.spec.ts: entity optional collection initial reintroduction/reader identity, structural unit events, and parent absence/supplied-value baseline. The latter is generic branch membership; it cannot alone prove entity hidden payload correctness.
- enhancers/restoration/hidden-collection-nesting.spec.ts and hidden-terminal-reversal.spec.ts: genuine public hidden collections, ordinary/external omission distinctions, rollback under hidden parent, pending omission refusal/retry and re-add before/after-images. These first discriminate W9 source wrappers from unchanged point/full target consumers.
- enhancers/restoration/restoration-claim-boundary.spec.ts plus lib/internals/subject-restoration-claims.spec.ts: multiple/last owners, eviction/truncation/reset/destroy claim release and bounded claim index. Distinguish recovery claims from current ordinary-presence obligations; zero pending owners alone cannot retire hidden ordinary lifetime.

Follow only if these pass: enhancers/restoration/jump-undo-equivalence.spec.ts for per-turn ghost/add/remove/rekey/parent omission generated histories, and lib/s3-hydrate-mode-recovery.spec.ts for exact scalar+marker recovery. These target actual S4/S5 whole-target/hydrate restoration paths rather than a new broad suite. No need repeat current pure helper references.

## Source routes and first missing combined checks

S3 transaction optional point adapter is already qualified top-level/whole-row; restoration's own realizationPort/declarative target still needs O/P provenance review. S4 prepare-entity-target receives admitted effects/order, whereas restoration may construct target through separate paths. S5 key/lifetime plans must preserve selected inverse sequence and existing successor placement proof. S6 source order/selection channels are not row-value authorship; current owner exception normalization is not historical backing reclamation.

W9 entity-signal hidden-write wrapper intercepts as empty, clears retained rows, reactivates only authored path and delegates to same source seams. Existing comments promise retained rows do not resurface; test this promise with pending recovery and O/P divergence, not just generic branch wakeup. W10 restoration origin filtering deliberately avoids new pending authored chronology; absence of inspection entries is not absence of responsibility. W11 current ordinary-present/physically-absent owner row protects payload, while existing history/pending claims protect recovery independently.

The plan explicitly names two additional mapping gaps beyond ordinary existing positives: hidden collection+pending transaction preparation-failure/reentry, and multi-plan mixed adoption/inspection/restore refused then useful retry. Do not invent new expected neighbors or missing-parent construction. After existing vector, choose one smallest public control per uncovered combination with expectations derived from existing authority contracts; preserve first failure and distinguish callback-owned nested effects. No production change merely because a helper is old. If existing tests select competing semantics, present the exact governing conflict before implementation.

INPUT-HASHES.json stamps reviewed existing test bodies. This document is source/test assessment only; no slice3 test executed here, no gate pass inferred, no public API, ordinary scope, integration or later qualification authorized. Full framework/browser/artifact/CPU/GC campaigns remain slices4/5.
