# Independent slice3 first-loss trace

Concrete defect is an unmigrated restoration structural-port handoff, not evidence that the source owner cannot represent these facts. Gate remains red; no runtime correction or new semantics authorized by this report. Reviewed finalpending source manifest67869b6525433a7ad5fceb88042cf25b50d2d90d045408a249b2f673aae3caf9; input hashes accompany report. No new runtime execution by reviewer.

## Public failure and first divergence

FOLLOWUP-FIRST.log preserves six failures: two unchanged jump-undo-equivalence shapes across restoration-alone/transactions-first/restoration-first. Root diagnostic REDO-FIRST.jsonl shows actual first failing operation is chain redo3; JUMP-CONTROL.ts/jsonl shows combined jump3 succeeds. The raw diagnostic temporarily augments the throw only; no production patch. Earlier FIRST.jsonl uses jump control and must not be represented as chainredo execution.

Sequence: ordinary branch omits collection; authored addE reintroduces it; later setAll addsA/B/D and changesE0→4. Undo to the omitted point then redo addE: public P shows E0. Next redo setAll forwards coherent effects `[field E.n0→4,addA,addB,addD]`. Diagnostic at entity-signal762 shows E1 previousOabsent, ordinaryOrder[], Ptarget[2,3,4,1]. Since fieldE belongs an existing lifetime restored by earlier turn, these effects do not need invented reordering. Combined jump carries addE within its own list, so O interpreter sees existence and succeeds. Assertion expects exact recorded target and chain equivalence; no disputed physical-neighbor policy.

## Causal source join

restoration.compileReversalApplications314 maps fresh arrays and retains turn labels; placeFieldReversalsWhileRowsExist normalizes only contiguous turn runs, deliberately not crossing applications. No evidence says this contract should be reopened. Existing v16 history comments require per-turn ghost/anchor replay; do not suppress E field or hoist arbitrary adds from later turns.

Nondeclarative restoration3355 calls realizationPort.applyAtomically(appliedEffects) directly. It never calls existing prepareOrdinaryEffects. The array therefore has no ordinaryRealization WeakMap pairing. Adapter structural preparation739 passes `ordinaryRealization(effects)?.ordinary` to planHeterogeneousFrame. Its ordinaryPlans preparation1312 is conditional on ordinaryEffects, so it is skipped for raw restoration arrays. Physical remove/restore/rekey plans commit1370–1388; ordinaryPlans install1390 iterates an empty map. This is the first missing source disposition at redo2, before redo3's throw. P legitimately revives E; current O remains absent after earlier undo.

Existing private adapter prepareOrdinaryEffects474 already invokes prepareOrdinaryRealization and returns paired physical lowering. That helper retains exact admitted ordinary effects separately and joins current physical key/lifetime for installation, storing evidence by returned physical-array identity. Transaction route uses this seam. Restoration's structural caller has not migrated to it. Declarative restoration3099 separately supplies admittedEffects, and prepare-entity-target168 passes those to the O interpreter; its failure exposes missing prior O state rather than causing E's original loss. Plain-member preparation preserves retained collection rows rather than treating branch snapshots as row authority (plain-branch-membership965–999), so hydrating all branch rows as O would be an unrelated unsafe substitute.

## Scope ruling and finite next step

Approved f806 slice3 explicitly audits S3–S6/W9–W11 and modifies proven incompatible handoffs. Previous slice2 closure was W4–W8 plus minimal transaction inverses, with full restoration/hidden gate explicitly unqualified. A raw restoration producer omitting an existing paired source-disposition seam is a concrete unmigrated S5/W10 path; not another shared-representation failure after claiming this path qualified. Existing source-owner/private carrier appears sufficient; no new public API, authority classification, whole branch adoption or effect reorder is justified by evidence.

A candidate correction should preserve ordinary admitted list versus lowered physical list through existing validation and installation, raw turn boundaries, atomic refusal/retry and historical origin filtering. Before any claim, replay both unchanged failed shapes/three orders and a minimal ordinary-only forward/undo/redo control that checks O through subsequent field+Link, not just P. Also exercise activeP/absentO lowering, absentP/presentO, occupied destination refusal and independent inspected siblings as applicable existing controls. If the existing seam cannot preserve application/target identity without new authority, present that exact boundary. No implementation prescribed or approved by this review.

299 first-vector passes and34 followup passes do not close six failures; no assertion changes, broad suites, later-slice completion or release claim.
