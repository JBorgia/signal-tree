# Slice 2 structural ordinary divergence design (preimplementation)

## Traced admission and inverse

All frame structural admission currently uses physical facts in `commitAndProjectEntityMutationFrame`: create captures add, tombstone captures remove with physical row/neighbors, transfer captures rekey. The fast field path prepares only value changes. `prepareEntityResponsibility` converts supplied structural records into the existing transaction bucket before installation; rich capture repeats physical records through notifier metadata. Rollback consumes those same bucket effects, not a second settlement engine.

C1: inspected creation currently leaves no ordinary-absence fact. Later fast field write therefore records only field reversal. Required ordinary transition is absent→present for that lifetime; capture must record necessary existence as add, while preserving physical field notification and unrelated inspected C.

C2: inspection removal tombstones old lifetime, new add allocates another lifetime. Current capture records only new add; rollback removes fresh row but has no old removal to invert. Required ordinary transition contains old lifetime removal and fresh lifetime addition at the authored key, in order. Existing inverse engine must restore old lifetime (not retarget new handle). Ordinary key/placement/value facts must survive inspection removal as a live divergence obligation before reclamation.

C3: inspected creation followed by ordinary removal is ordinary absent→absent. Physical remove still publishes/taps; capture must not claim ordinary removal or recreate inspected lifetime on rollback.

## Minimal substrate extension proposed

Extend native divergence storage to record explicit ordinary presence, key and lifetime plus ordinary placement evidence for subjects whose display membership differs. This is sparse divergence storage, not a permanent collection mirror. An ordinary-vacancy index points to the displaced ordinary lifetime at a key, enabling C2 without scanning unrelated members. Current ordinary value shadow cannot encode absence: `undefined` fallback currently means no shadow. Use an explicit discriminant.

Preparation produces one operation result with physical instruction list and ordered ordinary structural/value facts. It prepares all payload clones/placements and responsibility plans before installation. Installation applies physical frame plus divergence delta and terminal responsibility before any publication. The same result feeds committed capture and existing notify metadata; neither may rebuild structural responsibility from physical callbacks. C2 requires plural ordinary facts for one physical notification, so extend internal prepared-result evidence rather than add another notify port.

Reclamation must treat displaced ordinary lifetime as a live obligation; eligible retirement/destruction releases facts and key index. No old facade may retarget replacement lifetime. Divergence discharge happens only for authored footprint or realized restoration of that footprint. Inspection-only order and neighbors are not automatically ordinary facts.

## Necessary consumer migration and open implementation seam

Transaction and restoration capture currently accept singular structuralEffect per notification. Prepared ordinary evidence must preserve multiple ordered records (C2) and explicit empty ordinary effect list (C3), while native notification retains physical effect. Existing source capture can already hold multiple CommittedEntityMutation records. The notification consumers must select the prepared ordinary list consistently for enqueue chronology, delivered capture and queued footprints. Need review of ordering/frontier endpoints: a physical field adoption can have ordinary membership responsibility despite unchanged physical frontier. Merely inventing a physical frontier transition would be wrong.

This mapping precedes runtime edits. Root must freeze tests, and the source/consumer representation must be reviewed before claiming a minimal implementation. No structural fix or later slice is implemented here.

## Narrow C2 complete-target dependency

Existing same-key handoff guard correctly declines the heterogeneous point planner when removing fresh A and restoring old A at the same key. Do not bypass it. The inverse uses existing complete-target preparation. That target contains unrelated physical rows too; `prepare-entity-target` builds/installPreparedTargetValues and publishes physical subject diffs. Therefore original inverse footprint (remove fresh / restore old) must accompany the existing target so native divergence discharge is limited to those subjects. Reconstructing footprint by comparing full physical target would repeat S3's error. This requires targeted handoff through target-transition and prepare-entity-target, not replacing their target construction or settlement authority. Explicit full-target replacement semantics remain a later independent coverage gate.
