# Slice2 inverse-route prerequisite review

Read-only source review of `/private/tmp/semantic-transition-slice2/candidate`, retaining the ordered-realization successor as prerequisite. No implementation, tests or semantic changes. References below are candidate paths relative to `packages/kernel/src`.

## Findings

C1–C3 are semantically specified by the owner. Existing source facts are **not sufficient as currently represented/admitted** to compute all three inverses without additional prepared structural evidence. That is an implementation obligation, not a reason to ask the same semantic question again. No necessity for a second authority or whole canonical mirror is established.

### C1: authored field adoption implies necessary existence

Physical row B already exists, so ordinary field installation alone sees no physical add. Ordinary B was absent; capturing only field before/after cannot express rejecting its necessary ordinary existence. The inverse needs a remove of this exact adopted subject, leaving unrelated inspected C untouched. The usual structural remove installer can perform the physical inverse, provided admission records the ordinary-absence/existence transition before installation. A value-baseline map with nullish fallback cannot distinguish no divergence record from ordinary absent subject.

Minimal structural S3/S5 is plausible for this single removal; no full-target necessity is shown merely by C1. Preserve same-lifetime identity, ordinary publication and any compensated frontier obligation. Rejecting fields then leaving B installed is insufficient; refusing everything does not satisfy C1's required useful rollback.

### C2: same-key lifetime handoff has an existing full-target admission rule

Correct inverse must remove the fresh subject and restore the prior ordinary subject at the same key. `lib/internals/causal-runtime/target-transition.ts:238–282` detects a same-owner vacate/occupy key handoff and returns true. `target-transition-key-handoff.spec.ts:42–46` pins both effect orders. `enhancers/transactions/transactions.ts:3108–3137` selects `rollbackPendingTarget` before trying point installation when this predicate holds. Therefore C2 cannot be promised complete through S3/S5 alone while preserving established admission.

Existing S4 machinery already supports physical same-key replacement: `rollbackPendingTarget:2778–2840` derives a complete target from current collection source and reversal effects. Whether it needs changes for ordinary/physical separation must be tested narrowly. Using the existing route is not equivalent to authorizing every S4 migration; bypassing the guard to stay inside a nominal S3/S5 scope is not justified.

Dependency gate: include C2's existing complete-target inverse in slice2's acceptance evidence. If ordinary evidence cannot pass that route without changing the full-target installation contract beyond the specified lifetime handoff, preserve the failing C2 and present that exact cross-slice scope dependency. Do not declare C2 accepted on capture/confirmation alone or silently resume unrelated S4/W9–W11 work.

### C3: ordinary-neutral removal must not synthesize an inverse add

Physical inspection-created B is removed, but ordinary B was already absent. The inverse has no ordinary existence to restore. Capturing the physical remove as a normal authored structural effect would generate an add and violate C3. This is primarily a preparation/capture classification requirement; keeping physical notifications/taps does not require inventing ordinary restoration responsibility. Terminal/no-op rollback must remain useful and repeatable without resurrecting B.

## What prior-lifetime storage actually preserves

- `lib/physical/structural-store.ts:5–9` lifetime state is active/key?/restoreAllowed. `tombstoneSubject:369–384` removes current key/node/order membership and stores only inactive+restoreAllowed. It does not retain old key, neighbors or whether removal was inspection versus authored.
- `lib/entity-signal.ts:2656–2690` skips immediate retirement when restoration authority exists. `lib/internals/runtime-tree-plan.ts:32–40,49–61` makes transactions' causal-runtime sufficient for that authority. Thus the exact C2 fixture can retain old value backing/lifetime and held identity. This preserves material from which a restoration can be made, but not the missing ordinary address/placement provenance.
- Successor `EntityValueStore.inspectionBaselines` holds per-subject row values only. It does not record ordinary membership absence, old occupancy/key mapping or positional constraints.
- `entity-signal.ts:1515–1556` restore plan can install a named old subject/value/key/anchors and validates restoreAllowed and vacating destinations. It needs those facts supplied; it cannot infer which retired subject was the ordinary incumbent of a physically vacant key.
- Link's `entity-egress-projection.ts:80–95` does retain a per-connection ordinary key/subject/value projection, but this is not native authority and may not exist. Borrowing it would make rejection depend on Link construction. C1–C3 must work without Link as well as with it.

Inspection structural operations already publish structural metadata while suppressing ordinary capture. A prospective shared preparation can retain required ordinary topology divergence at that operation boundary; this report does not choose a representation or prove its lifecycle costs. It establishes why merely reading retained physical rows or current key indexes is not enough after the fact.

## Scope / unresolved issues

No additional owner semantic decision is identified for the exact C1–C3 outcomes. Needed checks are prewritten coverage: no-Link versions, unrelated inspection, reentry, occupied destination/refusal, preparation failure, repeat settlement and lifetime cleanup while obligations remain. Nested missing-parent point input is not implicated in these top-level lifetime cases. Existing successor limits and the later-slice collectibility/qualification gates remain unchanged.
