import type { StructuralEffect } from '../mutation-types';

export type OrdinaryEntityPresence<K extends string | number, E> =
  | { readonly present: false }
  | { readonly present: true; readonly key: K; readonly value: E;
      readonly beforeSubject?: number; readonly afterSubject?: number };

/** Only membership/key divergence is retained, never an ordinary collection copy. */
export class EntityOrdinaryTopology<K extends string | number, E> {
  private readonly divergent = new Map<number, OrdinaryEntityPresence<K,E>>();
  private readonly displaced = new Map<K,number>();
  read(subject: number): OrdinaryEntityPresence<K,E> | undefined { return this.divergent.get(subject); }
  atKey(key: K): number | undefined { return this.displaced.get(key); }
  install(subject: number, next: OrdinaryEntityPresence<K,E> | undefined): void {
    const previous=this.divergent.get(subject);
    if(previous?.present && this.displaced.get(previous.key)===subject) this.displaced.delete(previous.key);
    if(next===undefined) this.divergent.delete(subject);
    else {
      this.divergent.set(subject,next);
      if(next.present) this.displaced.set(next.key,subject);
    }
  }
  retains(subject: number): boolean { return this.divergent.get(subject)?.present===true; }
  clear(): void { this.divergent.clear(); this.displaced.clear(); }
}

export function ordinaryPresenceRecord<K extends string | number,E>(
 kind:'add'|'remove',subject:number,state:Extract<OrdinaryEntityPresence<K,E>,{present:true}>
): StructuralEffect {
 return {kind,subject,key:state.key,value:state.value,beforeSubject:state.beforeSubject,afterSubject:state.afterSubject};
}
