# Slice2 execution ledger (in progress)

Baseline evidence80e6095e; frozen accepted slice1 source fingerprint47f5ee8aea90ffb2c9d6e89eb1e287e73b39c3eeab8f42ede9ea5b2fd125dfb7. Isolated successor copied into slice2/candidate, absolute experimental helper paths rebased only. Production untouched.

| Run | Source | Result | Classification |
| --- | --- | --- | --- |
| structural-start.log | Initial slice2 source | C1–C3:3 failed | Preserved unmigrated structural failures |
| composition-first.log | Initial source |5 pass/1 fail | Approved prepend callback contract unmet |
| composition-expanded-first.log | Initial source |5 pass/5 fail | Expanded unchanged expected order/callback throw controls |
| w4-first.log | Separate prepend correction |10 pass | Bounded W4 result; not structural qualification |
| faults-first.log | W4 source |1 pass/3 fail | Reviewed fault-model/assertion mismatch; downstream state assertions not reached |
| inverse-interceptor-control.log | No tests executed | Wrong working-directory package lookup failure | Infrastructure invocation, not test failure |
| inverse-interceptor-control-cwd.log | Frozen successor control, added new tests |4 interceptor pass/3 inverse fail | Valid fault/reentry controls; new inverse first failures |

Original getter controls/log preserved verbatim. Existing clone fallback catches structuredClone failures and preserves descriptors; neither getter exception propagation nor its precedence over a reentry guard was established by the contract. Separate interceptor tests exercise the actual controlled throwing boundary. No cloning semantic change proposed.

Runtime work is not yet qualified. Count overlapping repeated controls separately; no result inherits a later source revision. Review design, inverse dependency and fault-premise records remain distinct.
