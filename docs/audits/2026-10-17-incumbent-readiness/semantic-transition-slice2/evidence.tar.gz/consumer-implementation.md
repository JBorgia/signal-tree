# Slice2 authority consumers and admitted inverse footprint

First source freeze, before integrated validation. Runtime edits confined to the disposable candidate. No test or typecheck result is claimed here.

## Authority selection

`ordinary-entity-entries.ts` selects the prepared ordinary change list when present, including an explicit empty list. It substitutes each record's subject, path, before/after pair and structural effect, and removes both plural and legacy transition markers before a consumer processes the entry. When no plural evidence exists it preserves the existing single-pair selection.

Transactions and restoration select the sequence before their main delivered notification handlers, queued-authority readers and capture processing. The committed-capture observation channel already iterates the prepared changes; it removes markers rather than expanding them again. This avoids processing a whole plural list once for every member of that same list.

Native notification delivery and physical callback tuples are not rewritten by these consumer edits. The collection-order capture channel remains separate and requires the publisher's correct prepared order facts; no fake frontier is introduced here.

## Complete-target boundary

`CollectionTransitionTarget.admittedEffects` carries optional original ordered inverse facts. Only transaction `rollbackPendingTarget` attaches this field, by filtering the original admitted reversal sequence by owner. The existing complete-target selection, same-key vacate/occupy guard and frontier adjustment remain unchanged. The target preparer belongs to the other implementation worker.

The shared declarative target derivation does **not** automatically attach this new field. Restoration can generate nested field effects and its full-target semantics are not migrated by this bounded C2 prerequisite. Attaching the field to all target derivations would prematurely migrate those paths and force an unapproved missing-parent decision. A supplied transaction footprint has the existing audited top-level/whole-row producer restriction.

## Verification status

Prettier successfully parsed and formatted only the four owned source files. Shared tests and typecheck are deferred to the parent after the concurrent source owners freeze. This is syntax evidence, not semantic qualification.
