import {createRequire} from 'node:module';
const {build}=createRequire('/Users/jonathanborgia/code/signaltree/package.json')('esbuild');
await build({entryPoints:['/private/tmp/semantic-transition-slice2/retention-review/witness.ts'],outfile:'/private/tmp/semantic-transition-slice2/retention-review/bundle.mjs',bundle:true,platform:'node',format:'esm',target:'node24',nodePaths:['/Users/jonathanborgia/code/signaltree/node_modules']});
