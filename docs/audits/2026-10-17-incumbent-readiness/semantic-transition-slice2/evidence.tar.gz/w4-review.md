# Scoped W4 prependOne review

Read-only; no tests executed. Reviewed W4 change against evidence/w4-before/entity-signal.ts and reported w4-first.log10/10. Concurrent ordinary-topology edits are excluded from this verdict. Exact sampled helper/prepend fragments: evidence/w4-reviewed-fragments.ts.txt, SHA256bd567f4fbd13583ae3771827fa53860ccc6b96932dde7662993c6c6f8502faf0.

The onAdd-order correction is sound within its tested boundary. addOneWithStructuralEffect now accepts prepend intent, completes moveToFront and descriptor neighbor rewriting before its notify/onAdd. prependOne no longer performs any movement after the helper returns. Nested prepend/append/remove/rekey from onAdd therefore cannot be overwritten by delayed outer ordering. A throwing onAdd sees and leaves completed membership/order; transactional abort can invert the installed add through existing responsibility. The10 controls include useful mixed rollback plus callback throw/abort, not only successful ordinary adds.

Qualifications to preserve at the combined freeze:

- The helper still installs the physical add frame first, whose prepared add record and frontier describe append. It then moves the key and rewrites the local rich PendingAddStructuralEffect. The W4-only change does not itself rewrite earlier prepared ordinary records/frontier. Existing passing mixed rollback supports useful rejection of that add; it does not prove equivalence of append-stage capture and final prepend placement for every history/inspection composition. Concurrent structural-result migration must keep prepared and rich evidence consistent, without inventing physical frontiers. This is a source handoff concern, not a newly executed counterexample.
- moveToFront calls updateSignals before local descriptor rewriting and before onAdd. Thus “before callback delivery” is established for onAdd taps by these controls, not every framework observer. Native synchronous observer reentry at that earlier publication point remains a combined freeze check. withMembershipGroup groups membership observation, not necessarily every native effect.
- The patch does not alter prependMany in this scope. Its existing complete-order path and structural qualification remain separate.

No concrete W4-only regression was demonstrated by this read-only review. Accept the narrow onAdd ordering correction as supported by its reported controls, pending root verification of frozen sources. Do not convert this conclusion into acceptance of concurrent ordinary structural divergence, all observer scheduling, or complete slice2.
