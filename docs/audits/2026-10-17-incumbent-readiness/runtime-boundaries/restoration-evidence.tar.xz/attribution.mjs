import {createRequire} from 'node:module';import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const root='/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree';const require=createRequire(root+'/package.json');const {build}=require('esbuild');const inputs={};
const code=`
import assert from 'node:assert/strict';
import {signalTree,entityMap,undoable,restoration,transactions} from './packages/kernel/src/index';
import {getActiveWriteContext} from './packages/kernel/src/lib/write-context';
import {StructuralStore} from './packages/kernel/src/lib/physical/structural-store';
import {getMutationCaptureRuntime} from './packages/kernel/src/lib/internals/mutation-capture-runtime';
import {deriveCollectionOrderDelta,applyCollectionOrderDelta} from './packages/kernel/src/lib/internals/causal-runtime/target-transition';
let trace:any[]|undefined; let store:any; let label="none";
for(const name of ['createSubject','tombstoneSubject','moveKeysToFront','reorderActiveKeys','restoreSubjectAtResolvedPlacement']){
 const original=(StructuralStore.prototype as any)[name];
 (StructuralStore.prototype as any)[name]=function(...args:any[]){
  const before=this.activeOrderFrontier();const entry:any={name,args,before,label,transactionId:getActiveWriteContext()?.transactionId};
  if(trace){store=this;if(name==='createSubject') {const tail=this.lastActiveKey();entry.predecessor=tail===undefined?undefined:this.subjectIdForKey(tail);}if(name==='tombstoneSubject') Object.assign(entry,this.neighborSubjectsForKey(args[1]));}
  const result=original.apply(this,args);entry.after=this.activeOrderFrontier();
  if(trace&&entry.before!==entry.after)trace.push(entry);return result;
 };
}
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
function editMany(order:number[],events:any[],inverse:boolean){
 const nodes=new Map<number,any>();let head:any,tail:any;let visits=0;
 for(const subject of order){const node:any={subject,prev:tail,next:undefined};if(tail)tail.next=node;else head=node;tail=node;nodes.set(subject,node);visits++;}
 for(const e of events){visits++;const subject=e.args[0];const remove=e.name==='createSubject'?inverse:!inverse;
  if(e.name!=='createSubject'&&e.name!=='tombstoneSubject')throw Error('Uncovered operation '+e.name);
  if(remove){const node=nodes.get(subject);assert(node,'remove target exists');if(node.prev)node.prev.next=node.next;else head=node.next;if(node.next)node.next.prev=node.prev;else tail=node.prev;nodes.delete(subject);}
  else{assert(!nodes.has(subject));const successor=nodes.get(e.afterSubject);const predecessor=nodes.get(e.name==='createSubject'?e.predecessor:e.beforeSubject);const node:any={subject};
   if(successor){node.prev=successor.prev;node.next=successor;if(node.prev)node.prev.next=node;else head=node;successor.prev=node;}
   else if(predecessor){node.prev=predecessor;node.next=predecessor.next;if(node.next)node.next.prev=node;else tail=node;predecessor.next=node;}
   else{assert.equal(nodes.size,0,'no anchor');head=tail=node;}nodes.set(subject,node);
  }
 }
 const result:number[]=[];for(let node=head;node;node=node.next){result.push(node.subject);visits++;}
 return {result,visits};
}
function compose(raw:any[],full:any[]){const first=full[0],last=full[full.length-1];const start=raw.findIndex(e=>e.before===first.beforeFrontier),end=raw.findLastIndex(e=>e.after===last.afterFrontier);assert(start>=0&&end>=start);return{before:editMany([...first.beforeSubjects],raw.slice(0,start).reverse(),true).result,after:editMany([...last.afterSubjects],raw.slice(end+1),false).result,beforeToken:raw[0].before,afterToken:raw.at(-1).after,start,end};}
const results:any[]=[];
const tree=signalTree({rows:entityMap<any,string>({selectId:r=>r.id})},{enhancers:[transactions(),restoration()]});
try{
 for(const [id,n]of [['z',0],['a',1],['c',3]])tree.$.rows.addOne({id,n});await flush();
 const full:any[]=[];const off=getMutationCaptureRuntime(tree)?.subscribeCollectionOrder?.(c=>full.push({...c,label}));let pending:any,called=false;
 tree.$.rows.tap({onAdd:()=>{if(called)return;called=true;label='nested-transaction';pending=tree.transact(()=>tree.$.rows.removeOne('a'));label='outer';}});
 trace=[];label='outer';undoable(()=>tree.$.rows.prependMany([{id:'w',n:4},{id:'c',n:30}],{mode:'overwrite'}));const raw=trace;trace=undefined;off?.();await flush();
 const outer=full[0];const outerEnd=raw.findIndex(e=>e.after===outer.afterFrontier),foreign=raw.find(e=>e.label==='nested-transaction');assert(foreign);assert.notEqual(foreign.transactionId,undefined);assert(raw.slice(0,outerEnd+1).every(e=>e.transactionId===undefined));assert.equal(foreign.before,outer.afterFrontier);
 const prior=tree.$.rows.ids();let pendingUndo;try{tree.undo();pendingUndo='succeeded'}catch(e){pendingUndo=String(e)}assert.deepEqual(tree.$.rows.ids(),prior);
 let rollbackError;try{pending.rollback()}catch(e){rollbackError=String(e)}await flush();const afterRollback=tree.$.rows.ids();let retryUndo;try{tree.undo();retryUndo='succeeded'}catch(e){retryUndo=String(e)}
 results.push({test:'callback-independent-transaction',raw:raw.map(e=>({name:e.name,label:e.label,transactionId:e.transactionId})),outerEnd,pendingUndo,rollbackError,afterRollback,retryUndo,afterRetry:tree.$.rows.ids()});
}finally{trace=undefined;tree.destroy();}
console.log(JSON.stringify(results,null,2));
`;
const built=await build({stdin:{contents:code,resolveDir:root,loader:'ts'},absWorkingDir:root,bundle:true,write:false,platform:'node',format:'esm',target:'node24',plugins:[{name:'inputs',setup(b){b.onLoad({filter:/\/packages\/kernel\/src\/.*\.ts$/},({path})=>{const contents=readFileSync(path,'utf8');inputs[path.slice(root.length+1)]=createHash('sha256').update(contents).digest('hex');return{contents,loader:'ts'}})}}]});
writeFileSync('/private/tmp/st-restoration-interval-20261018/probe-attribution.bundle.mjs',built.outputFiles[0].text);writeFileSync('/private/tmp/st-restoration-interval-20261018/inputs-attribution.json',JSON.stringify(inputs,null,2));await import('/private/tmp/st-restoration-interval-20261018/probe-attribution.bundle.mjs');
