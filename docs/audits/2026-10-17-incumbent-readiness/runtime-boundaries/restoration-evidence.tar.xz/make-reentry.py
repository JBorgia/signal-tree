p='/private/tmp/st-restoration-interval-20261018/probe.mjs';s=open(p).read();start=s.index('const cases=');end=s.index('console.log(JSON.stringify(results,null,2));',start)
s=s[:start]+r'''function compose(raw:any[],full:any[]){const first=full[0],last=full[full.length-1];const start=raw.findIndex(e=>e.before===first.beforeFrontier),end=raw.findLastIndex(e=>e.after===last.afterFrontier);assert(start>=0&&end>=start);return{before:editMany([...first.beforeSubjects],raw.slice(0,start).reverse(),true).result,after:editMany([...last.afterSubjects],raw.slice(end+1),false).result,beforeToken:raw[0].before,afterToken:raw.at(-1).after,start,end};}
const results:any[]=[];
for(const test of ['adjacent-R1','adjacent-R2','callback-nested-reorder','callback-remove-after-order','restore-subject']){
 const tree=signalTree({rows:entityMap<any,string>({selectId:r=>r.id})},{enhancers:[restoration()]});
 try{
 for(const [id,n]of [['z',0],['a',1],['c',3]])tree.$.rows.addOne({id,n});await flush();
 const full:any[]=[];const off=getMutationCaptureRuntime(tree)?.subscribeCollectionOrder?.(c=>full.push({...c,label}));
 if(test==='restore-subject'){
  undoable(()=>tree.$.rows.removeOne('a'));await flush();trace=[];tree.undo();const raw=trace;trace=undefined;assert.deepEqual(tree.$.rows.ids(),['z','a','c']);assert(raw.some(e=>e.name==='restoreSubjectAtResolvedPlacement'));
  const restore=raw.find(e=>e.name==='restoreSubjectAtResolvedPlacement');assert.equal(restore.args[0],2);assert.equal(restore.args[2].afterSubject,3);assert.notEqual(restore.before,restore.after);
  results.push({test,sourceRestorePassed:true,subject:restore.args[0],placement:restore.args[2],frontierChanged:true});off?.();continue;
 }
 let earlier:any;
 if(test.startsWith('adjacent')){undoable(()=>tree.$.rows.setAll([{id:'a',n:1},{id:'c',n:3},{id:'z',n:0}]));await flush();earlier=full.pop();assert(earlier);}
 let called=false;
 if(test.startsWith('callback'))tree.$.rows.tap({onAdd:()=>{if(called)return;called=true;label='nested';if(test==='callback-nested-reorder')tree.$.rows.prependMany([{id:'a',n:1}],{mode:'overwrite'});else tree.$.rows.removeOne('a');label='outer';}});
 trace=[];label='outer';undoable(()=>{const r=tree.$.rows;if(test==='adjacent-R1'){r.setAll([{id:'c',n:3},{id:'z',n:0},{id:'a',n:1}]);r.removeOne('a');}else if(test==='adjacent-R2'){r.addOne({id:'w',n:4});r.prependMany([{id:'c',n:30}],{mode:'overwrite'});}else r.prependMany([{id:'w',n:4},{id:'c',n:30}],{mode:'overwrite'});});const raw=trace;trace=undefined;label='none';off?.();
 const c=compose(raw,full);const actual:any[]=[];store.snapshotActiveOrder([],actual);assert.deepEqual(c.after,actual);assert.deepEqual(c.before,earlier?.afterSubjects??[1,2,3]);
 const delta=deriveCollectionOrderDelta(full[0].owner,c.before,c.after,c.beforeToken,c.afterToken);const restored=applyCollectionOrderDelta(c.after,delta,'before',c.afterToken);assert.deepEqual(restored,c.before);
 if(earlier){const previous=deriveCollectionOrderDelta(earlier.owner,earlier.beforeSubjects,earlier.afterSubjects,earlier.beforeFrontier,earlier.afterFrontier);assert.deepEqual(applyCollectionOrderDelta(restored,previous,'before',c.beforeToken),earlier.beforeSubjects);if(test==='adjacent-R2')assert.throws(()=>applyCollectionOrderDelta(restored,previous,'before',full[0].beforeFrontier),/frontier/);}
 if(test.startsWith('callback')){assert(called);const firstNested=raw.findIndex(e=>e.label==='nested');const outer=full.find(e=>e.label==='outer');const outerEnd=raw.findIndex(e=>e.after===outer.afterFrontier);assert(firstNested>outerEnd,'outer installation closes before callback write');results.push({test,rawLabels:raw.map(e=>e.label),orderLabels:full.map(e=>e.label),outerEnd,firstNested,publicCallEnclosesNewerWork:true,before:c.before,after:c.after});}
 else results.push({test,before:c.before,after:c.after,earlierUndoValidated:true,wrongPerCallTokenRejected:test==='adjacent-R2'});
 }finally{trace=undefined;tree.destroy();}
}
''' +s[end:]
s=s.replace('let trace:any[]|undefined; let store:any;','let trace:any[]|undefined; let store:any; let label="none";').replace('const entry:any={name,args,before};','const entry:any={name,args,before,label};')
s=s.replace('probe-v2.bundle.mjs','probe-reentry.bundle.mjs').replace('inputs-v2.json','inputs-reentry.json')
open('/private/tmp/st-restoration-interval-20261018/reentry.mjs','w').write(s)
