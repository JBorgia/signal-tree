import {createRequire} from 'node:module';import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const root='/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree';const require=createRequire(root+'/package.json');const {build}=require('esbuild');const inputs={};
const code=`
import assert from 'node:assert/strict';
import {signalTree,entityMap,undoable,restoration} from './packages/kernel/src/index';
import {StructuralStore} from './packages/kernel/src/lib/physical/structural-store';
import {getMutationCaptureRuntime} from './packages/kernel/src/lib/internals/mutation-capture-runtime';
import {deriveCollectionOrderDelta,applyCollectionOrderDelta} from './packages/kernel/src/lib/internals/causal-runtime/target-transition';
let trace:any[]|undefined; let store:any; let label="none";
for(const name of ['createSubject','tombstoneSubject','moveKeysToFront','reorderActiveKeys','restoreSubjectAtResolvedPlacement']){
 const original=(StructuralStore.prototype as any)[name];
 (StructuralStore.prototype as any)[name]=function(...args:any[]){
  const before=this.activeOrderFrontier();const entry:any={name,args,before,label};
  if(trace){store=this;if(name==='createSubject') {const tail=this.lastActiveKey();entry.predecessor=tail===undefined?undefined:this.subjectIdForKey(tail);}if(name==='tombstoneSubject') Object.assign(entry,this.neighborSubjectsForKey(args[1]));}
  const result=original.apply(this,args);entry.after=this.activeOrderFrontier();
  if(trace&&entry.before!==entry.after)trace.push(entry);return result;
 };
}
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
function editMany(order:number[],events:any[],inverse:boolean){
 const nodes=new Map<number,any>();let head:any,tail:any;let visits=0;
 for(const subject of order){const node:any={subject,prev:tail,next:undefined};if(tail)tail.next=node;else head=node;tail=node;nodes.set(subject,node);visits++;}
 for(const e of events){visits++;const subject=e.args[0];const remove=e.name==='createSubject'?inverse:!inverse;
  if(e.name!=='createSubject'&&e.name!=='tombstoneSubject')throw Error('Uncovered operation '+e.name);
  if(remove){const node=nodes.get(subject);assert(node,'remove target exists');if(node.prev)node.prev.next=node.next;else head=node.next;if(node.next)node.next.prev=node.prev;else tail=node.prev;nodes.delete(subject);}
  else{assert(!nodes.has(subject));const successor=nodes.get(e.afterSubject);const predecessor=nodes.get(e.name==='createSubject'?e.predecessor:e.beforeSubject);const node:any={subject};
   if(successor){node.prev=successor.prev;node.next=successor;if(node.prev)node.prev.next=node;else head=node;successor.prev=node;}
   else if(predecessor){node.prev=predecessor;node.next=predecessor.next;if(node.next)node.next.prev=node;else tail=node;predecessor.next=node;}
   else{assert.equal(nodes.size,0,'no anchor');head=tail=node;}nodes.set(subject,node);
  }
 }
 const result:number[]=[];for(let node=head;node;node=node.next){result.push(node.subject);visits++;}
 return {result,visits};
}
function compose(raw:any[],full:any[]){const first=full[0],last=full[full.length-1];const start=raw.findIndex(e=>e.before===first.beforeFrontier),end=raw.findLastIndex(e=>e.after===last.afterFrontier);assert(start>=0&&end>=start);return{before:editMany([...first.beforeSubjects],raw.slice(0,start).reverse(),true).result,after:editMany([...last.afterSubjects],raw.slice(end+1),false).result,beforeToken:raw[0].before,afterToken:raw.at(-1).after,start,end};}
const results:any[]=[];
for(const test of ['adjacent-R1','adjacent-R2','callback-nested-reorder','callback-remove-after-order','restore-subject']){
 const tree=signalTree({rows:entityMap<any,string>({selectId:r=>r.id})},{enhancers:[restoration()]});
 try{
 for(const [id,n]of [['z',0],['a',1],['c',3]])tree.$.rows.addOne({id,n});await flush();
 const full:any[]=[];const off=getMutationCaptureRuntime(tree)?.subscribeCollectionOrder?.(c=>full.push({...c,label}));
 if(test==='restore-subject'){
  undoable(()=>tree.$.rows.removeOne('a'));await flush();trace=[];tree.undo();const raw=trace;trace=undefined;assert.deepEqual(tree.$.rows.ids(),['z','a','c']);assert(raw.some(e=>e.name==='restoreSubjectAtResolvedPlacement'));
  const restore=raw.find(e=>e.name==='restoreSubjectAtResolvedPlacement');assert.equal(restore.args[0],2);assert.equal(restore.args[2].afterSubject,3);assert.notEqual(restore.before,restore.after);
  results.push({test,sourceRestorePassed:true,subject:restore.args[0],placement:restore.args[2],frontierChanged:true});off?.();continue;
 }
 let earlier:any;
 if(test.startsWith('adjacent')){undoable(()=>tree.$.rows.setAll([{id:'a',n:1},{id:'c',n:3},{id:'z',n:0}]));await flush();earlier=full.pop();assert(earlier);}
 let called=false;
 if(test.startsWith('callback'))tree.$.rows.tap({onAdd:()=>{if(called)return;called=true;label='nested';if(test==='callback-nested-reorder')tree.$.rows.prependMany([{id:'a',n:1}],{mode:'overwrite'});else tree.$.rows.removeOne('a');label='outer';}});
 trace=[];label='outer';undoable(()=>{const r=tree.$.rows;if(test==='adjacent-R1'){r.setAll([{id:'c',n:3},{id:'z',n:0},{id:'a',n:1}]);r.removeOne('a');}else if(test==='adjacent-R2'){r.addOne({id:'w',n:4});r.prependMany([{id:'c',n:30}],{mode:'overwrite'});}else r.prependMany([{id:'w',n:4},{id:'c',n:30}],{mode:'overwrite'});});const raw=trace;trace=undefined;label='none';off?.();
 const c=compose(raw,full);const actual:any[]=[];store.snapshotActiveOrder([],actual);assert.deepEqual(c.after,actual);assert.deepEqual(c.before,earlier?.afterSubjects??[1,2,3]);
 const delta=deriveCollectionOrderDelta(full[0].owner,c.before,c.after,c.beforeToken,c.afterToken);const restored=applyCollectionOrderDelta(c.after,delta,'before',c.afterToken);assert.deepEqual(restored,c.before);
 if(earlier){const previous=deriveCollectionOrderDelta(earlier.owner,earlier.beforeSubjects,earlier.afterSubjects,earlier.beforeFrontier,earlier.afterFrontier);assert.deepEqual(applyCollectionOrderDelta(restored,previous,'before',c.beforeToken),earlier.beforeSubjects);if(test==='adjacent-R2')assert.throws(()=>applyCollectionOrderDelta(restored,previous,'before',full[0].beforeFrontier),/frontier/);}
 if(test.startsWith('callback')){assert(called);const firstNested=raw.findIndex(e=>e.label==='nested');const outer=full.find(e=>e.label==='outer');const outerEnd=raw.findIndex(e=>e.after===outer.afterFrontier);assert(firstNested>outerEnd,'outer installation closes before callback write');results.push({test,rawLabels:raw.map(e=>e.label),orderLabels:full.map(e=>e.label),outerEnd,firstNested,publicCallEnclosesNewerWork:true,before:c.before,after:c.after});}
 else results.push({test,before:c.before,after:c.after,earlierUndoValidated:true,wrongPerCallTokenRejected:test==='adjacent-R2'});
 }finally{trace=undefined;tree.destroy();}
}
console.log(JSON.stringify(results,null,2));
`;
const built=await build({stdin:{contents:code,resolveDir:root,loader:'ts'},absWorkingDir:root,bundle:true,write:false,platform:'node',format:'esm',target:'node24',plugins:[{name:'inputs',setup(b){b.onLoad({filter:/\/packages\/kernel\/src\/.*\.ts$/},({path})=>{const contents=readFileSync(path,'utf8');inputs[path.slice(root.length+1)]=createHash('sha256').update(contents).digest('hex');return{contents,loader:'ts'}})}}]});
writeFileSync('/private/tmp/st-restoration-interval-20261018/probe-reentry.bundle.mjs',built.outputFiles[0].text);writeFileSync('/private/tmp/st-restoration-interval-20261018/inputs-reentry.json',JSON.stringify(inputs,null,2));await import('/private/tmp/st-restoration-interval-20261018/probe-reentry.bundle.mjs');
