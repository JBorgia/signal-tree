import {createRequire} from 'node:module';import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const root='/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree';const require=createRequire(root+'/package.json');const {build}=require('esbuild');const inputs={};
const code=`
import assert from 'node:assert/strict';
import {signalTree,entityMap,undoable,restoration} from './packages/kernel/src/index';
import {StructuralStore} from './packages/kernel/src/lib/physical/structural-store';
import {getMutationCaptureRuntime} from './packages/kernel/src/lib/internals/mutation-capture-runtime';
import {deriveCollectionOrderDelta,applyCollectionOrderDelta} from './packages/kernel/src/lib/internals/causal-runtime/target-transition';
let trace:any[]|undefined; let store:any;
for(const name of ['createSubject','tombstoneSubject','moveKeysToFront','reorderActiveKeys','restoreSubjectAtResolvedPlacement']){
 const original=(StructuralStore.prototype as any)[name];
 (StructuralStore.prototype as any)[name]=function(...args:any[]){
  const before=this.activeOrderFrontier();const entry:any={name,args,before};
  if(trace){store=this;if(name==='createSubject') {const tail=this.lastActiveKey();entry.predecessor=tail===undefined?undefined:this.subjectIdForKey(tail);}if(name==='tombstoneSubject') Object.assign(entry,this.neighborSubjectsForKey(args[1]));}
  const result=original.apply(this,args);entry.after=this.activeOrderFrontier();
  if(trace&&entry.before!==entry.after)trace.push(entry);return result;
 };
}
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
function editMany(order:number[],events:any[],inverse:boolean){
 const nodes=new Map<number,any>();let head:any,tail:any;let visits=0;
 for(const subject of order){const node:any={subject,prev:tail,next:undefined};if(tail)tail.next=node;else head=node;tail=node;nodes.set(subject,node);visits++;}
 for(const e of events){visits++;const subject=e.args[0];const remove=e.name==='createSubject'?inverse:!inverse;
  if(e.name!=='createSubject'&&e.name!=='tombstoneSubject')throw Error('Uncovered operation '+e.name);
  if(remove){const node=nodes.get(subject);assert(node,'remove target exists');if(node.prev)node.prev.next=node.next;else head=node.next;if(node.next)node.next.prev=node.prev;else tail=node.prev;nodes.delete(subject);}
  else{assert(!nodes.has(subject));const successor=nodes.get(e.afterSubject);const predecessor=nodes.get(e.name==='createSubject'?e.predecessor:e.beforeSubject);const node:any={subject};
   if(successor){node.prev=successor.prev;node.next=successor;if(node.prev)node.prev.next=node;else head=node;successor.prev=node;}
   else if(predecessor){node.prev=predecessor;node.next=predecessor.next;if(node.next)node.next.prev=node;else tail=node;predecessor.next=node;}
   else{assert.equal(nodes.size,0,'no anchor');head=tail=node;}nodes.set(subject,node);
  }
 }
 const result:number[]=[];for(let node=head;node;node=node.next){result.push(node.subject);visits++;}
 return {result,visits};
}
const cases=[
 ['R1',(r:any)=>{r.setAll([{id:'c',n:3},{id:'z',n:0},{id:'a',n:1}]);r.removeOne('a')}],
 ['R2',(r:any)=>{r.addOne({id:'w',n:4});r.prependMany([{id:'c',n:30}],{mode:'overwrite'})}],
 ['before-between-after',(r:any)=>{r.addOne({id:'w',n:4});r.prependMany([{id:'c',n:30}],{mode:'overwrite'});r.removeOne('a');r.prependMany([{id:'z',n:0}],{mode:'overwrite'});r.addOne({id:'x',n:5});r.removeOne('w')}],
 ['transient-prefix',(r:any)=>{r.addOne({id:'w',n:4});r.removeOne('w');r.prependMany([{id:'c',n:30}],{mode:'overwrite'})}],
 ['removed-prefix',(r:any)=>{r.removeOne('a');r.prependMany([{id:'c',n:30}],{mode:'overwrite'});r.addOne({id:'w',n:4})}],
 ['compound-membership',(r:any)=>{r.addOne({id:'w',n:4});r.setAll([{id:'c',n:3},{id:'x',n:5},{id:'z',n:0}]);r.removeOne('z')}],
];
const results=[];
for(const [name,act]of cases){
 const tree=signalTree({rows:entityMap<any,string>({selectId:r=>r.id})},{enhancers:[restoration()]});
 try{
 for(const [id,n]of [['z',0],['a',1],['c',3]])tree.$.rows.addOne({id,n});await flush();
 const full:any[]=[];const off=getMutationCaptureRuntime(tree)?.subscribeCollectionOrder?.(c=>full.push(c));
 trace=[];undoable(()=>(act as any)(tree.$.rows));const raw=trace;trace=undefined;off?.();
 const actualBefore=raw[0].before,actualAfter=raw[raw.length-1].after;
 const first=full[0],last=full[full.length-1];assert(first&&last);
 const start=raw.findIndex(e=>e.before===first.beforeFrontier);const end=raw.findLastIndex(e=>e.after===last.afterFrontier);assert(start>=0&&end>=start);
 let before=[...first.beforeSubjects],after=[...last.afterSubjects];
 const prefix=editMany(before,raw.slice(0,start).reverse(),true);before=prefix.result;
 const suffix=editMany(after,raw.slice(end+1),false);after=suffix.result;
 const snapshot:any[]=[];store.snapshotActiveOrder([],snapshot);assert.deepEqual(after,snapshot);
 assert.deepEqual(before,[1,2,3]);
 const delta=deriveCollectionOrderDelta(first.owner,before,after,actualBefore,actualAfter);
 assert.deepEqual(applyCollectionOrderDelta(after,delta,'before',actualAfter),before);
 assert.deepEqual(applyCollectionOrderDelta(before,delta,'after',actualBefore),after);
 assert.throws(()=>applyCollectionOrderDelta(after,delta,'before',{}),/frontier/);
 await flush();let undoError;try{tree.undo()}catch(e){undoError=String(e)}
 results.push({name,structuralCount:raw.length,explicitOrders:full.length,coveredRange:[start,end],prefix:start,suffix:raw.length-end-1,before,after,frontierRejectsDrift:true,compositionVisits:prefix.visits+suffix.visits,existingUndo:undoError??'succeeded'});
 }finally{trace=undefined;tree.destroy()}
}
console.log(JSON.stringify(results,null,2));
`;
const built=await build({stdin:{contents:code,resolveDir:root,loader:'ts'},absWorkingDir:root,bundle:true,write:false,platform:'node',format:'esm',target:'node24',plugins:[{name:'inputs',setup(b){b.onLoad({filter:/\/packages\/kernel\/src\/.*\.ts$/},({path})=>{const contents=readFileSync(path,'utf8');inputs[path.slice(root.length+1)]=createHash('sha256').update(contents).digest('hex');return{contents,loader:'ts'}})}}]});
writeFileSync('/private/tmp/st-restoration-interval-20261018/probe-v2.bundle.mjs',built.outputFiles[0].text);writeFileSync('/private/tmp/st-restoration-interval-20261018/inputs-v2.json',JSON.stringify(inputs,null,2));await import('/private/tmp/st-restoration-interval-20261018/probe-v2.bundle.mjs');
