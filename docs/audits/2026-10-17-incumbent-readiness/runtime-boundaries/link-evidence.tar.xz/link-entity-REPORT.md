# Entity-field admission experiment — stopped on ordering counterexample

Source HEAD16f85b6d2b46ac1404ef6b089a1e6a459c28cdc3, per-input SHA256 captured in JSON. Bundle-only transform74655847c7960ac358e680afdd1b761b2ea7ad6bdf24eaab02d8c8f18ccd86b1, extending scalar transform18597149. No repository edits. No full L1 qualification.

## Extension

Query consumes existing live pending records directly. Entity field request is identified by registry, collection owner, subject lifetime and fieldKey. Same-subject pending set of another known top-level field is disjoint; same lifetime add/remove/whole-row/unknown field blocks. Rekey does not change a held field lifetime, so key-only effect is ignored for this field payload. Other subjects are disjoint. Ordinary membership/address ancestors remain conservative conflicts. Ordering captures remain conservative holds. Row/collection/ancestor full-payload requests receive no field exemption. Query never writes authorship facts or promotes an observed key.

## Passing bounded controls

All controls have finite50ms drains, not general liveness proof.
- Same-row independent y advances while x pending.
- Different row y advances.
- Held y advances during pending rekey; rollback returns original key and preserves independent y.
- Pending-created lifetime y stays withheld even after independent field write.
- Old reference after pending removal + same-key replacement never sends replacement's y; rollback refusal remains.
- Endpoint reentry creates pending x; independent held y advances.
- Whole collection payload remains held when it includes pending x, then emits restoredx0 with survivingy2.
- Prior5 controls remain passing: non-Link gate, pending-predecessor compensation withholding, drained0-only, observer-created pending9 withholding, recovery2.

## First concrete failure — stop

Public sequence:

    rows.addMany([{id:'a',x:0,y:0},{id:'b',x:0,y:0}]);
    const outbound=[];
    const connection=link(rows,{set: values => outbound.push(values.map(v=>v.id))});
    const pending=tree.transact(()=>rows.setAll(
      [{id:'b',x:0,y:0},{id:'a',x:0,y:0}], {reorder:true}));
    await drain(); // outbound remains[]
    pending.rollback();
    await drain();

Both transformed candidate and untransformed source report:
- before rollback outbound[];
- rows.ids() after rollback ['a','b'];
- outbound after rollback [['b','a']].

Thus a rejected ordering reaches endpoint after rollback although physical order restored. This is not blocked/unsupported progress and is not introduced by entity-field exemption: candidate excludes collection sources, and untransformed baseline reproduces it. No assertion changed and no repair attempted. Earlier six-case result retained separately as link-entity-first.json/code.

Source boundary identified, not fully causally proven: Link consumes subscribeCollectionOrder in link.ts862ff and asynchronously updates eligible projection from captured afterSubjects. Physical transaction rollback order follows orderDeltas through prepared transition path. Need verify whether rollback emits its corresponding order capture and when it reaches Link before gate release. Do not simply bypass projection or adopt physical snapshots, since inspection-filtering contracts remain.

## Replay

NODE=/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node
$NODE /private/tmp/link-entity-candidate.mjs
$NODE /private/tmp/link-entity-baseline.mjs
$NODE /private/tmp/link-entity-prior-controls.mjs

JSON/bundles share runner prefixes; full source test is link-entity-code.txt. Baseline uses same tests with transform disabled. Transform retained at link-entity-transform.mjs. Original10/2 semantic harness unchanged. No production typecheck/framework/budget/performance/retention qualification. Do not integrate this prototype or characterize the seven passing examples as complete structural interference coverage.
