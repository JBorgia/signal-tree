export function transform(path,contents){
if(path.endsWith('/enhancers/transactions/transactions.ts'))return contents.replace('const pendingOrderDeltas = new Map<number, CollectionOrderDelta[]>();',`const pendingOrderDeltas = new Map<number, CollectionOrderDelta[]>();
((globalThis as any).__linkAdmission ??= new WeakMap()).set(getPositionRegistry(tree.$), (address: readonly string[] | undefined, location?: any) => {
 if(!location && address?.length!==1) return false;
 if(location && location.fieldKey===undefined)return false;
 const registry=getPositionRegistry(tree.$);
 for(const id of authority.getPendingTurnIds()) for(const effect of authority.getPendingTurn(id)?.__effects??[]){
 if(location && effect.position===location.owner && effect.subject!==undefined){
  if(effect.subject!==location.subjectId)continue;
  if(effect.kind==='rekey')continue;
  if(effect.kind==='set' && effect.subjectFieldSegments?.length && effect.subjectFieldSegments[0]!==location.fieldKey)continue;
  return false;
 }
 const target=location?registry?.addressFor(location.owner):address;
 const at=registry?.addressFor(effect.position as any);if(!target||!at||at.length===0||at[0]===target[0])return false;
 }
 for(const bucket of pendingTransactions.values())for(const owner of bucket.collectionOrders.keys()){
 const at=registry?.addressFor(owner as any);if(!at||at.length===0||at[0]===(location?registry?.addressFor(location.owner)?.[0]:address?.[0]))return false;
 }
 for(const deltas of pendingOrderDeltas.values())if(deltas.length)return false;
 return true;
});`);
if(path.endsWith('/lib/internals/commit-consequence.ts'))return contents.replace("import { getPositionRegistry }", "import { getPositionRegistry, getNodeAddress }")
.replace('run: CommitConsequence;\n}', 'run: CommitConsequence;\n researchScalar?: boolean;\n researchLocation?: unknown;\n}')
.replace('if (scopeKey && hasOpen(scopeKey)) {',`const address=getNodeAddress(claimant); const independent=request.researchScalar&&((globalThis as any).__linkAdmission?.get(scopeKey)?.(address, request.researchLocation)===true);
  if (scopeKey && hasOpen(scopeKey) && !independent) {`)
.replace('held.set(key, run);', 'held.set(key, () => scheduleDurableConsequence(request));')
.replace('if (key && !hasOpen(key)) {',`if(key && hasOpen(key)) { const held=heldByKey.get(key); if(held){heldByKey.delete(key);for(const fn of held.values()) attempt(fn);held.clear();} }
  if (key && !hasOpen(key)) {`);
if(path.endsWith('/lib/link.ts'))return ("import {isNodeAccessor} from './internals/node-shape';\n"+contents).replaceAll('claimant: x as object,','claimant: x as object,\n researchScalar: (!!entityLocation && entityLocation.fieldKey!==undefined) || (!isNodeAccessor(x) && !entityLocation && !collection && sourceAddress?.length === 1),\n researchLocation: entityLocation,');
return contents;
}
