# Responsibility observation separate from value delivery

Baseline e488ca34e75a808f0f4dc26edfea5e7ea26fcaab. Private scalar/default-batched
research only. No production/API/policy/budget changes; surviving-write semantics
and reviewed delivery contract unchanged.

Owner requirement: “value equality does not imply unchanged publication
responsibility.” Preserve user value suppression; responsibility receipts must carry
an immutable exact payload/revision pair, not permission to send a different value.

One correction: collect responsibility receipts independently of value subscribers.
At a coherent completed notification-batch boundary, make the batch's receipt frontier
available to Link even when a net-equal value event is suppressed. Callback-generated
receipts belong to a later batch and must not be accidentally promoted by the older
batch's completion. Immediate latest-revision invalidation remains the final-send
safety check. Refresh payload and ticket together, with no direct read of inspection
state as a publication source. Realized/inspection receipts cannot authorize fresh
ordinary publication. Reuse existing Link queue/held/in-flight/disposal handling.

Cross-tree conservative rule: include all then-pending owners in the instrumented
runtime registry, with tree/owner namespace and transaction identity, in each ordinary
receipt's immutable possible-owner bound. Global terminal outcomes may wake affected
connections through the same reviewed delivery path. A still-pending foreign owner
must hold the copy. Rejection never cleanses the old receipt. A new actual authored
write after terminal rejection may get fresh evidence under the approved contract.
This bounds a single instrumented runtime, not arbitrary external/native/cached
provenance. No read graph or new explicit override. Account for registry traversal
and retained state rather than declaring the conservative fallback cheap.

Fixed acceptance before execution:
- Unchanged owner-window ABA now releases after every captured owner confirms.
- A value observer sees no extra net-equal ABA notification. Owner window changes
  still affect release; later same-value identity cannot erase pending ownership.
- Multiple owners, rejection/refusal, fresh overwrite, opened-listener reentry and
  immutable receipt facts retain their previous or explicitly approved outcomes.
- A callback creates a later receipt during flush: no old payload/new-ticket pair,
  no pre-delivery promotion of that later receipt, eventual delivery when eligible.
- Preserve queued preflight invalidation, in-flight corrective serialization,
  settlement waits and connection disposal using historical delivery controls.
- Cross-tree pending copy holds until real confirmation. Foreign rejection holds;
  late unrelated owner does not retroactively contaminate already authored work.
- Restore/inspection remains excluded; no payload refresh by reading current
  inspection state. Same integer IDs on two trees must not alias.
- Tree destruction remains separately classified; no automatic disposal claim.

Preserve first source, old controls and first red outputs. Source-wiring errors may
be corrected without altering an oracle. A substantive new mechanism failure ends
this revision; no guard cascade, value-emission workaround or policy expansion.
Nonbatched notification, entities, retention, cost and full framework integration
remain unqualified unless actually executed. A bounded success is not production
acceptance, and contemporaneous-owner independence is still unproved.
