// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/error-reporter.ts
var listeners = /* @__PURE__ */ new Set();
function reportTreeError(event) {
  if (listeners.size === 0) return false;
  let received = false;
  for (const listener of listeners) {
    try {
      listener(event);
      received = true;
    } catch (err) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        safeConsoleError(
          "SignalTree: an onTreeError listener threw. The original error was still handled normally; this is the listener failing. [ST2025]",
          err
        );
      }
    }
  }
  return received;
}
function safeConsoleError(message, error) {
  try {
    if (error === void 0) console.error(message);
    else console.error(message, error);
  } catch {
  }
}
var CONTAINED_REPORT_BUDGET = 50;
var CONTAINED_REPORT_WINDOW_MS = 1e3;
var containedReportWindows = /* @__PURE__ */ new Map();
function registerContainedReportBudget(treeId) {
  containedReportWindows.set(treeId, null);
}
function takeContainedReportBudget(treeId) {
  let now = 0;
  try {
    now = Date.now();
  } catch {
  }
  const owner = containedReportWindows.has(treeId) ? treeId : void 0;
  let window2 = containedReportWindows.get(owner);
  if (!window2 || now - window2.start >= CONTAINED_REPORT_WINDOW_MS) {
    window2 = { start: now, count: 0 };
    containedReportWindows.set(owner, window2);
  }
  if (window2.count >= CONTAINED_REPORT_BUDGET) {
    if (window2.count === CONTAINED_REPORT_BUDGET && listeners.size > 0) {
      window2.count++;
      safeConsoleError(
        `SignalTree: more than ${CONTAINED_REPORT_BUDGET} contained observer errors for one tree within a second; further ones go to the console only, not onTreeError. [ST2034]`
      );
    }
    return false;
  }
  window2.count++;
  return true;
}
function reportContainedObserverError(event) {
  const { error, operation, treeId, path } = event;
  let received = false;
  if (treeId !== void 0) {
    if (takeContainedReportBudget(treeId)) {
      received = reportTreeError({
        error,
        operation,
        treeId,
        ...path === void 0 ? {} : { path }
      });
    }
  }
  if (received && !(typeof ngDevMode === "undefined" || ngDevMode)) {
    return;
  }
  safeConsoleError(
    operation === "notify:subscriber" ? `SignalTree: a write subscriber threw while observing '${path}'; delivery continued. [ST2034]` : "SignalTree: a transaction turn listener threw; the transaction continued. [ST2034]",
    error
  );
}
function releaseContainedReportBudget(treeId) {
  containedReportWindows.delete(treeId);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/production-substrate-stats.ts
var PRODUCTION_SUBSTRATE_STATS_ENABLED = true;
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/cell-identity.ts
var CELL_MARK = Symbol("SignalTree:Cell");
function markTreeCell(cell) {
  Object.defineProperty(cell, CELL_MARK, {
    value: true,
    enumerable: false,
    writable: false,
    configurable: true
  });
  return cell;
}
function isTreeCell(value) {
  return typeof value === "function" && value[CELL_MARK] === true;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/leaf.ts
var LEAF_DEFINITION = Symbol.for("SignalTree:LeafDefinition");
function leaf(value) {
  const definition = {};
  Object.defineProperty(definition, LEAF_DEFINITION, { value });
  return definition;
}
function isLeafDefinition(value) {
  return typeof value === "object" && value !== null && Object.prototype.hasOwnProperty.call(value, LEAF_DEFINITION) && Object.getOwnPropertyDescriptor(value, LEAF_DEFINITION)?.enumerable === false;
}
function leafDefinitionValue(definition) {
  return definition[LEAF_DEFINITION];
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/observation-adapter.ts
var NEUTRAL_OBSERVATION_ADAPTER = {
  createToken: () => ({
    observe: () => void 0,
    invalidate: () => void 0
  }),
  runInvalidationGroup: (run2) => run2()
};

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/intrinsic-mutation.ts
function installTerminalRecord(plan) {
  for (let i = 0; i < plan.writes.length; i++) {
    const write = plan.writes[i];
    write.map.set(write.key, write.value);
  }
  for (let i = 0; i < plan.adds.length; i++) {
    const add = plan.adds[i];
    add.set.add(add.value);
  }
}
var SOURCES = /* @__PURE__ */ new WeakMap();
var SOURCE_ACCESSORS = {
  prepareTerminal: {
    get() {
      return this.terminalPreparer;
    }
  },
  terminal: {
    get() {
      return this.terminalRecord?.observer;
    }
  },
  capture: {
    get() {
      return this.captureRecord?.observer;
    }
  }
};
function compose(record) {
  const { observers } = record;
  if (observers === void 0 || observers.size === 0) {
    record.observer = void 0;
    return;
  }
  if (observers.size === 1) {
    const only = observers.values().next().value;
    record.observer = (mutation) => {
      try {
        only(mutation);
      } catch {
      }
    };
    return;
  }
  const snapshot = [...observers];
  record.observer = (mutation) => {
    for (const observer of snapshot) {
      try {
        observer(mutation);
      } catch {
      }
    }
  };
}
var UNOBSERVABLE_SOURCE = Object.freeze({
  observer: void 0
});
function registerIntrinsicMutationSource(node) {
  const record = { observers: void 0, observer: void 0 };
  Object.defineProperties(record, SOURCE_ACCESSORS);
  SOURCES.set(node, record);
  return record;
}
function observeIntrinsicMutations(node, observer, capture = false) {
  const source = SOURCES.get(node);
  if (!source) return void 0;
  const record = capture === "terminal" ? source.terminalRecord ??= { observers: void 0, observer: void 0 } : capture ? source.captureRecord ??= { observers: void 0, observer: void 0 } : source;
  const installed = observer;
  (record.observers ??= /* @__PURE__ */ new Set()).add(installed);
  compose(record);
  let active2 = true;
  return () => {
    if (!active2) return;
    active2 = false;
    record.observers?.delete(installed);
    compose(record);
  };
}
function prepareTerminalMutations(node, prepare) {
  const source = SOURCES.get(node);
  if (!source) return;
  if (source.terminalPreparer) throw new Error("Terminal preparation already owned");
  source.terminalPreparer = prepare;
  return () => {
    if (source.terminalPreparer === prepare) source.terminalPreparer = void 0;
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/location-runtime.ts
var WRITABLE_LOCATION_BINDINGS = /* @__PURE__ */ new WeakMap();
var writableLocationBinding = (location) => {
  const binding = WRITABLE_LOCATION_BINDINGS.get(location);
  if (!binding) throw new Error("Expected a writable SignalTree location");
  return binding;
};
function isWritableLocation(value) {
  return WRITABLE_LOCATION_BINDINGS.has(value);
}
function writableLocationPublisher(value) {
  return WRITABLE_LOCATION_BINDINGS.get(value);
}
function replaceLocation(location, value) {
  writableLocationBinding(location).replace(value);
}
function deriveLocation(location, update) {
  writableLocationBinding(location).derive(update);
}
function registerWritableLocationBinding(binding) {
  WRITABLE_LOCATION_BINDINGS.set(
    binding.location,
    binding
  );
}
var activeConsumer;
var publicationDepth = 0;
var pendingConsumers = /* @__PURE__ */ new Set();
var dependencyFinalizer = new FinalizationRegistry((dependencies) => {
  for (const [node, edge] of dependencies) {
    node.consumers.delete(edge.reference);
  }
});
var flushConsumers = () => {
  const errors = [];
  while (pendingConsumers.size > 0) {
    const consumer = [...pendingConsumers].sort(
      (left, right) => left.level - right.level
    )[0];
    pendingConsumers.delete(consumer);
    try {
      consumer.settle();
    } catch (error) {
      errors.push(error);
    }
  }
  return errors;
};
var NO_LISTENERS = /* @__PURE__ */ new Set();
var notifyObservers = (token, listeners3) => {
  let failure;
  let hasFailure = false;
  try {
    token?.invalidate();
  } catch (error) {
    failure = error;
    hasFailure = true;
  }
  for (const listener of [...listeners3]) {
    try {
      listener();
    } catch {
    }
  }
  if (hasFailure) throw failure;
};
var trackDependency = (node, token) => {
  if (activeConsumer) {
    let edge = activeConsumer.dependencies.get(node);
    if (!edge) {
      const reference = new WeakRef(activeConsumer);
      edge = { reference, version: node.version };
      node.consumers.add(reference);
      activeConsumer.dependencies.set(node, edge);
    } else {
      edge.version = node.version;
    }
    activeConsumer.level = Math.max(activeConsumer.level, node.level + 1);
    return;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("publicationDependencyReads");
  }
  token().observe();
};
var notifyDependents = (node) => {
  for (const reference of node.consumers) {
    const consumer = reference.deref();
    if (consumer) consumer.invalidate();
    else node.consumers.delete(reference);
  }
};
var NODE_LOCATION_RUNTIMES = /* @__PURE__ */ new WeakMap();
function bindLocationRuntime(node, runtime2) {
  NODE_LOCATION_RUNTIMES.set(node, runtime2);
}
function getLocationRuntime(node) {
  return NODE_LOCATION_RUNTIMES.get(node);
}
function createLocationRuntime(realization) {
  const hasReactiveObservation = realization !== NEUTRAL_OBSERVATION_ADAPTER;
  let invalidationGroupDepth = 0;
  const groupedPublishers = /* @__PURE__ */ new Set();
  const deliver2 = (publishers) => {
    const errors = [];
    realization.runInvalidationGroup(() => {
      publicationDepth += 1;
      try {
        for (const publisher of publishers) {
          try {
            publisher.notify();
          } catch (error) {
            errors.push(error);
          }
        }
        if (publicationDepth === 1) errors.push(...flushConsumers());
      } finally {
        publicationDepth -= 1;
        if (publicationDepth === 0) pendingConsumers.clear();
      }
    });
    if (errors.length > 0) throw errors[0];
  };
  const publish = (publishers) => {
    if (invalidationGroupDepth > 0) {
      for (const publisher of publishers) groupedPublishers.add(publisher);
      return;
    }
    deliver2(publishers);
  };
  const runInvalidationGroup = (run2) => {
    let failure;
    let hasFailure = false;
    invalidationGroupDepth += 1;
    try {
      run2();
    } catch (error) {
      failure = error;
      hasFailure = true;
    } finally {
      invalidationGroupDepth -= 1;
      if (invalidationGroupDepth === 0 && groupedPublishers.size > 0) {
        const publishers = [...groupedPublishers];
        groupedPublishers.clear();
        try {
          deliver2(publishers);
        } catch (error) {
          if (!hasFailure) {
            failure = error;
            hasFailure = true;
          }
        }
      }
    }
    if (hasFailure) throw failure;
  };
  const createWritable = (read2, write) => {
    let observationToken;
    const listeners3 = /* @__PURE__ */ new Set();
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const location = markTreeCell(function(value) {
      if (arguments.length === 0) {
        trackDependency(node, token);
        return read2();
      }
      if (typeof value === "function") {
        binding.derive(value);
      } else if (isLeafDefinition(value)) {
        binding.replace(leafDefinitionValue(value));
      } else {
        binding.replace(value);
      }
      return void 0;
    });
    const mutationSource2 = registerIntrinsicMutationSource(
      location
    );
    const binding = {
      location,
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, listeners3);
      },
      replace: (next) => {
        const observer = mutationSource2.observer;
        const before = observer ? read2(true) : void 0;
        const changed = write(next, "replace", () => mutationSource2.prepareTerminal?.({ intent: "replace", before, after: next, changed: true }));
        if (observer) {
          observer({
            intent: "replace",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (changed) publish([binding]);
      },
      derive: (update) => {
        const current = read2();
        const before = mutationSource2.observer ? read2(true) : current;
        const next = update(current);
        const changed = write(next, "derive", () => mutationSource2.prepareTerminal?.({ intent: "derive", before, after: next, changed: true }));
        const observer = mutationSource2.observer;
        if (observer) {
          observer({
            intent: "derive",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (changed) publish([binding]);
      }
    };
    registerWritableLocationBinding(binding);
    location.peek = () => read2();
    location.subscribe = (listener) => {
      listeners3.add(listener);
      return () => listeners3.delete(listener);
    };
    location.asReadonly = () => location;
    return binding;
  };
  const createCell = (initial, equal = Object.is) => {
    let value = initial;
    const binding = createWritable(
      () => value,
      (next) => {
        if (equal(value, next)) return false;
        value = next;
        return true;
      }
    );
    return binding.location;
  };
  const createDerived = (compute) => {
    let initialized = false;
    let dirty = true;
    let computationFailed = false;
    let value;
    let observationToken;
    const listeners3 = /* @__PURE__ */ new Set();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const token = () => observationToken ??= realization.createToken();
    const consumer = {
      dependencies: /* @__PURE__ */ new Map(),
      level: 1,
      invalidate: () => {
        if (dirty) {
          if (listeners3.size > 0 || hasReactiveObservation && observationToken) {
            pendingConsumers.add(consumer);
          }
          return;
        }
        dirty = true;
        notifyDependents(node);
        if (listeners3.size > 0 || hasReactiveObservation && observationToken) {
          pendingConsumers.add(consumer);
        }
      },
      settle: () => {
        if (!dirty) return;
        const previous = value;
        const wasInitialized = initialized;
        readCurrent();
        if (wasInitialized && !Object.is(previous, value)) {
          publisher.notify();
        }
      }
    };
    dependencyFinalizer.register(consumer, consumer.dependencies);
    const publisher = {
      notify: () => {
        notifyObservers(observationToken, listeners3);
      }
    };
    const readCurrent = () => {
      if (!dirty && initialized) return value;
      if (initialized && !computationFailed) {
        let changed = false;
        for (const [dependency, edge] of consumer.dependencies) {
          dependency.refresh();
          if (dependency.version !== edge.version) changed = true;
        }
        if (!changed) {
          dirty = false;
          return value;
        }
      }
      for (const [dependency, edge] of consumer.dependencies) {
        dependency.consumers.delete(edge.reference);
      }
      consumer.dependencies.clear();
      consumer.level = 1;
      const previous = value;
      const wasInitialized = initialized;
      const previousConsumer = activeConsumer;
      activeConsumer = consumer;
      try {
        value = compute();
        node.level = consumer.level;
        initialized = true;
        dirty = false;
        computationFailed = false;
        if (wasInitialized && !Object.is(previous, value)) {
          node.version += 1;
        }
        return value;
      } catch (error) {
        computationFailed = true;
        throw error;
      } finally {
        activeConsumer = previousConsumer;
      }
    };
    node.refresh = () => {
      if (dirty) readCurrent();
    };
    const location = markTreeCell((() => {
      const current = readCurrent();
      trackDependency(node, token);
      return current;
    }));
    location.peek = readCurrent;
    location.subscribe = (listener) => {
      readCurrent();
      listeners3.add(listener);
      return () => listeners3.delete(listener);
    };
    return location;
  };
  const createEpoch = () => {
    let observationToken;
    let version = 0;
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const publisher = {
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, NO_LISTENERS);
      }
    };
    const epoch = (() => {
      trackDependency(node, token);
      return version;
    });
    epoch.set = (next) => {
      if (next === version) return;
      version = next;
      publish([publisher]);
    };
    epoch.update = (fn) => epoch.set(fn(version));
    epoch.asReadonly = () => epoch;
    return epoch;
  };
  const advanceEpoch = (handle) => {
    handle.update((v) => v + 1);
  };
  return {
    createCell,
    createDerived,
    createWritable,
    createEpoch,
    advanceEpoch,
    publish,
    runInvalidationGroup
  };
}
var NEUTRAL_LOCATION_RUNTIME = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
);

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/constants.ts
var DEV_MESSAGES = {
  NULL_OR_UNDEFINED: "null/undefined [ST1001]",
  TREE_DESTROYED: "destroyed [ST1012]",
  ENHANCER_CYCLE_DETECTED: "enhancer cycle [ST1024]"
  // ST1032 (LAZY_NOT_INJECTED) and ST1004 (LAZY_FALLBACK) were removed in 15.0
  // with the lazy feature. ST1032 in particular told users to import from
  // `@signal-tree/kernel/lazy`, a subpath withdrawn from the published surface —
  // a runtime diagnostic giving advice that could not be followed.
};
var PROD_MESSAGES = DEV_MESSAGES;
var _isProdByEnv = Boolean(
  typeof globalThis === "object" && globalThis !== null && "process" in globalThis && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  typeof globalThis.process === "object" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  "env" in globalThis.process && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  globalThis.process.env.NODE_ENV === "production"
);
var _isDev = typeof ngDevMode !== "undefined" ? Boolean(ngDevMode) : !_isProdByEnv;
var SIGNAL_TREE_MESSAGES = Object.freeze(
  _isDev ? DEV_MESSAGES : PROD_MESSAGES
);

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/enhancer-types.ts
var ENHANCER_META = Symbol("signaltree:enhancer:meta");

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/index.ts
function resolveEnhancerOrder(enhancers, availableCapabilities = /* @__PURE__ */ new Set(), debugMode = false) {
  const nodes = enhancers.map((e, idx) => ({
    fn: e,
    name: e.metadata && e.metadata.name ? String(e.metadata.name) : `enhancer#${idx}`,
    requires: new Set(e.metadata?.requires ?? []),
    provides: new Set(e.metadata?.provides ?? [])
  }));
  const provided = new Set(availableCapabilities);
  const nameCounts = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    for (const capability of node.provides) provided.add(capability);
    if (node.fn.metadata?.name) {
      nameCounts.set(node.name, (nameCounts.get(node.name) ?? 0) + 1);
    }
  }
  const problems = [];
  for (const node of nodes) {
    for (const capability of node.requires) {
      if (!provided.has(capability)) {
        problems.push(
          `  - ${node.fn.metadata?.name ? `"${node.name}"` : "an unnamed enhancer"} requires capability "${capability}", but no configured enhancer provides it.`
        );
      }
    }
  }
  for (const [name, count] of nameCounts) {
    if (count > 1) {
      problems.push(
        `  - enhancer "${name}" is configured ${count} times; each enhancer may appear once.`
      );
    }
  }
  if (problems.length > 0) {
    throw new Error(
      `SignalTree could not finalize the enhancer configuration:
${problems.join("\n")}`
    );
  }
  const adj = /* @__PURE__ */ new Map();
  const nameToNode = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    nameToNode.set(n.name, n);
    adj.set(n.name, /* @__PURE__ */ new Set());
  }
  for (const a of nodes) {
    for (const b of nodes) {
      if (a === b) continue;
      for (const req of b.requires) {
        if (availableCapabilities.has(req)) continue;
        if (a.provides.has(req)) {
          const set = adj.get(a.name);
          if (set) set.add(b.name);
        }
      }
    }
  }
  const inDegree = /* @__PURE__ */ new Map();
  for (const entry of adj.keys()) inDegree.set(entry, 0);
  for (const [, outs] of adj) {
    for (const to of outs) inDegree.set(to, (inDegree.get(to) || 0) + 1);
  }
  const queue = [];
  for (const [name, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(name);
  }
  const ordered = [];
  while (queue.length > 0) {
    const n = queue.shift();
    if (!n) break;
    ordered.push(n);
    const outs = adj.get(n);
    if (!outs) continue;
    for (const m of outs) {
      inDegree.set(m, (inDegree.get(m) || 0) - 1);
      if (inDegree.get(m) === 0) queue.push(m);
    }
  }
  if (ordered.length !== nodes.length) {
    if (debugMode) {
      console.warn(SIGNAL_TREE_MESSAGES.ENHANCER_CYCLE_DETECTED);
    }
    return enhancers;
  }
  return ordered.map((name) => {
    const n = nameToNode.get(name);
    return n ? n.fn : enhancers[0];
  });
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/node-shape.ts
function isTraversableNode(value) {
  return value != null && (typeof value === "object" || typeof value === "function");
}
var CALLABLE_SIGNAL_SYMBOL = Symbol.for("SignalTree:NodeAccessor");
var NODE_STORE_SYMBOL = Symbol.for("SignalTree:NodeStore");
function nodeStoreOf(node) {
  const store = node[NODE_STORE_SYMBOL];
  return store !== void 0 && store !== null ? store : void 0;
}
function snapshotNodeKey(node) {
  return nodeStoreOf(node) ?? node;
}
function isNodeAccessor(value) {
  return typeof value === "function" && value[CALLABLE_SIGNAL_SYMBOL] === true;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/owned-metadata.ts
var OWNED_NODE_METADATA = /* @__PURE__ */ new WeakMap();
function getOwnedPositionIds(node) {
  if (isTraversableNode(node)) {
    const direct = node.__positionIds;
    if (direct) {
      return [...direct];
    }
    const sidecar = OWNED_NODE_METADATA.get(node)?.positionIds;
    return sidecar ? [...sidecar] : void 0;
  }
  return void 0;
}
function getOwnedSubjectIds(node) {
  if (isTraversableNode(node)) {
    const direct = node.__subjectIds;
    if (direct) {
      return [...direct];
    }
    return void 0;
  }
  return void 0;
}
function getOwnedOwnerPath(node) {
  if (isTraversableNode(node)) {
    const direct = node.__ownerPath;
    if (direct !== void 0) {
      return direct;
    }
    return OWNED_NODE_METADATA.get(node)?.ownerPath;
  }
  return void 0;
}
function hasIntrinsicMutationEmitter(node) {
  if (isTraversableNode(node)) {
    const direct = node.__emitsMutations;
    if (direct !== void 0) {
      return direct;
    }
    return OWNED_NODE_METADATA.get(node)?.emitsMutations === true;
  }
  return false;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/owner-invalidation-port.ts
var dispatch;
function markOwnerInvalidated(ownerId) {
  dispatch?.mark(ownerId);
}
function markOwnerInvalidatedFrom(owner) {
  dispatch?.markFrom(owner);
}
function terminateOwnerInvalidation(owner) {
  dispatch?.terminate(owner);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/path-observation-port.ts
var runtime;
function installPathDeliveryRuntime(next) {
  runtime = next;
}
var branchMembershipCapture;
var pathReAddCapture;
function installBranchMembershipCapture(capture, pathReAdd) {
  branchMembershipCapture = capture;
  pathReAddCapture = pathReAdd;
}
function captureBranchMembershipIfObserved(branch, supplied, partial) {
  return branchMembershipCapture?.(branch, supplied, partial);
}
function capturePathReAddIfObserved(path, outer) {
  return pathReAddCapture?.(path, outer);
}
function hasPathObservers() {
  return runtime?.hasObservers() ?? false;
}
var PORT = {
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    runtime?.notify(
      path,
      value,
      prev,
      ownerPath,
      subjectIds,
      positionIds,
      metaOverride,
      ownerId,
      subjectFieldFootprint
    );
  }
};
function pathObservation() {
  return PORT;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/snapshot-authority.ts
var MATERIALIZED = /* @__PURE__ */ new WeakMap();
var SNAPSHOT_PARENT = /* @__PURE__ */ new WeakMap();
var TREE_STORES = /* @__PURE__ */ new WeakSet();
var VOLATILE_SNAPSHOTS = /* @__PURE__ */ new WeakSet();
var MEMBERSHIP_REVISION = /* @__PURE__ */ new WeakMap();
function markTreeStore(store) {
  TREE_STORES.add(store);
}
function isSnapshotNode(node) {
  return TREE_STORES.has(node) || isNodeAccessor(node);
}
function bindSnapshotParent(node, parent) {
  SNAPSHOT_PARENT.set(
    snapshotNodeKey(node),
    new WeakRef(snapshotNodeKey(parent))
  );
}
function markSnapshotVolatile(node) {
  let current = snapshotNodeKey(node);
  while (current) {
    VOLATILE_SNAPSHOTS.add(current);
    current = SNAPSHOT_PARENT.get(current)?.deref();
  }
}
function membershipRevisionFor(key, locations) {
  let revision = MEMBERSHIP_REVISION.get(key);
  if (!revision) {
    revision = locations.createCell(0);
    MEMBERSHIP_REVISION.set(key, revision);
  }
  return revision;
}
function observeMembership(node) {
  membershipRevisionFor(
    snapshotNodeKey(node),
    getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME
  )();
}
function publishMembershipChange(node) {
  const key = snapshotNodeKey(node);
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  deriveLocation(membershipRevisionFor(key, locations), (value) => value + 1);
  markOwnerInvalidatedFrom(node);
}
function materializeSnapshotNode(node, build) {
  const key = snapshotNodeKey(node);
  if (VOLATILE_SNAPSHOTS.has(key)) return build();
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  let snapshot = MATERIALIZED.get(key);
  if (!snapshot) {
    const membershipRevision = membershipRevisionFor(key, locations);
    const read2 = () => {
      membershipRevision();
      const built = build();
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        if (built !== null && typeof built === "object") Object.freeze(built);
      }
      return built;
    };
    snapshot = { observe: locations.createDerived(read2) };
    MATERIALIZED.set(key, snapshot);
  }
  return snapshot.observe();
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tree-scalar-slot-port.ts
var TREE_SCALAR_SLOT_RUNTIME = Symbol.for("SignalTree:ScalarSlotRuntime");
function defineTreeScalarSlotRuntime(node, runtime2) {
  Object.defineProperty(node, TREE_SCALAR_SLOT_RUNTIME, {
    value: runtime2,
    enumerable: false,
    configurable: true
  });
}
function getTreeScalarSlotRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[TREE_SCALAR_SLOT_RUNTIME];
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/member-membership.ts
var DORMANT = Symbol.for("SignalTree:DormantMember");
var membershipEpoch = 1;
var omittedMembers = /* @__PURE__ */ new WeakMap();
var ABSENCE_CHECK_EVERY = 64;
var absenceChecks = 0;
var MEMBERSHIP_CHANGED = Symbol.for("SignalTree:MembershipChanged");
function membershipHook(node) {
  return node?.[MEMBERSHIP_CHANGED];
}
var NODE_ACCESSOR_PEER = Symbol.for("SignalTree:NodeAccessorPeer");
function isDormantMember(leaf2) {
  const binding = memberBinding(leaf2);
  if (binding === void 0) return false;
  const descriptor = Object.getOwnPropertyDescriptor(
    binding.parent,
    binding.key
  );
  return descriptor !== void 0 && descriptor.enumerable === false;
}
function memberBinding(leaf2) {
  if (!isTraversableNode(leaf2)) {
    return void 0;
  }
  return leaf2[DORMANT];
}
function reactivateOnWrite(leaf2) {
  const binding = memberBinding(leaf2);
  if (!binding) return false;
  return setMemberPresence(binding.parent, binding.key, "active");
}
function nodeOf(parent) {
  return parent[NODE_ACCESSOR_PEER] ?? parent;
}
function isAbsentMember(node) {
  const first = memberBinding(node);
  if (first === void 0) return false;
  if (first.epoch === membershipEpoch) {
    if ((typeof ngDevMode === "undefined" || ngDevMode) && ++absenceChecks % ABSENCE_CHECK_EVERY === 0 && walkAbsence(first) !== first.absent)
      throw new Error(
        "SignalTree internal: a cached absence answer disagrees with enumerability (membershipEpoch was not advanced)."
      );
    return first.absent;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  first.absent = walkAbsence(first);
  first.epoch = membershipEpoch;
  return first.absent;
}
function walkAbsence(first) {
  for (let binding = first; binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) return true;
  }
  return false;
}
var structuralWrites = {
  depth: 0,
  stamp: 0
};
function beginStructuralWrite() {
  structuralWrites.depth++;
}
function endStructuralWrite(failed) {
  if (--structuralWrites.depth) return;
  structuralWrites.readded = void 0;
  structuralWrites.end?.(failed);
}
function inStructuralWrite(node) {
  return node !== void 0 && structuralWrites.own === node;
}
function readdedDuringStructuralWrite(branch, key, since) {
  return (structuralWrites.readded?.get(nodeOf(branch))?.get(key) ?? 0) > since;
}
var storedReads = { depth: 0 };
function reactivatePathOnWrite(node) {
  if (!isAbsentMember(node)) return false;
  if (inStructuralWrite(node)) return reactivateOnWrite(node);
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  const path = [];
  let outer = -1;
  for (let binding = memberBinding(node); binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) outer = path.length;
    path.push(binding);
  }
  if (outer < 0) return false;
  const announce = capturePathReAddIfObserved(path, outer);
  for (let i = outer - 1; i >= 0; i--) {
    const { parent, key: kept } = path[i];
    for (const member of Object.keys(parent))
      if (member !== kept) setMemberPresence(parent, member, "dormant");
  }
  for (let i = outer; i >= 0; i--) {
    const { parent, key } = path[i];
    setMemberPresence(parent, key, "active");
    if (structuralWrites.depth) {
      const readded = structuralWrites.readded ??= /* @__PURE__ */ new Map();
      let keys = readded.get(parent);
      if (!keys) readded.set(parent, keys = /* @__PURE__ */ new Map());
      keys.set(key, ++structuralWrites.stamp);
    }
  }
  if (!isWritableLocation(node) || outer > 0)
    republishMembers(path[outer].parent, [path[outer].key]);
  announce?.();
  return true;
}
var ABSENCE = {
  // History capture reads what storage holds (`storedReads`).
  isAbsent: (node) => !storedReads.depth && isAbsentMember(node),
  reAdd: reactivatePathOnWrite
};
function republishMembers(parent, keys) {
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (!runtime2) return;
  const changedSlots = [];
  const unaddressedLeaves = [];
  const branches = [];
  const publish = (child) => {
    const positionId = getOwnedPositionIds(child)?.[0];
    const slot = positionId === void 0 ? void 0 : runtime2.resolveScalarSlot(positionId);
    if (slot !== void 0) return changedSlots.push(slot) > 0;
    const publisher = writableLocationPublisher(child);
    if (publisher) return unaddressedLeaves.push(publisher) > 0;
    membershipHook(child)?.();
    if (isNodeAccessor(child)) {
      branches.push(child);
      for (const key of Object.keys(child))
        publish(child[key]);
    }
    return false;
  };
  let tokenCarrying = 0;
  for (const key of keys)
    if (publish(parent[key])) tokenCarrying++;
  if (tokenCarrying < keys.length) {
    publishMembershipChange(parent);
  } else {
    markOwnerInvalidatedFrom(parent);
  }
  for (const branch of branches) publishMembershipChange(branch);
  if (changedSlots.length > 0) {
    runtime2.publishPrepared({ revision: runtime2.revision(), changedSlots });
  }
  if (unaddressedLeaves.length > 0) {
    (getLocationRuntime(parent) ?? NEUTRAL_LOCATION_RUNTIME).publish(
      unaddressedLeaves
    );
  }
}
function deactivateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === false) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: false });
  membershipEpoch++;
  markHasDormant(parent);
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (runtime2) {
    omittedMembers.set(runtime2, (omittedMembers.get(runtime2) ?? 0) + 1);
    runtime2.enableAbsence?.(ABSENCE);
  }
  const child = parent[key];
  if (isTraversableNode(child)) {
    linkMember(parent, key, child);
    linkDescendants(child);
  }
  return true;
}
function linkMember(parent, key, child) {
  membershipEpoch++;
  Object.defineProperty(child, DORMANT, {
    value: {
      parent: nodeOf(parent),
      key,
      epoch: 0,
      absent: false
    },
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function linkDescendants(node) {
  if (!isNodeAccessor(node)) return;
  for (const key of Object.getOwnPropertyNames(node)) {
    const child = Object.getOwnPropertyDescriptor(node, key)?.value;
    if (!isNodeAccessor(child) && !isWritableLocation(child) && !membershipHook(child) || memberBinding(child))
      continue;
    linkMember(node, key, child);
    linkDescendants(child);
  }
}
function linkAddedMember(branch, key, child) {
  if (!isTraversableNode(child) || !memberBinding(nodeOf(branch))) return;
  linkMember(branch, key, child);
  linkDescendants(child);
}
function activateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === true) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: true });
  membershipEpoch++;
  const runtime2 = getTreeScalarSlotRuntime(parent);
  const omitted = runtime2 ? omittedMembers.get(runtime2) : void 0;
  if (runtime2 && omitted !== void 0) {
    omittedMembers.set(runtime2, omitted - 1);
    if (omitted === 1) runtime2.disableAbsence?.();
  }
  return true;
}
var HAS_DORMANT = Symbol.for("SignalTree:HasDormantMembers");
function hasDormantMembers(parent) {
  return parent[HAS_DORMANT] === true;
}
function markHasDormant(parent) {
  if (hasDormantMembers(parent)) return;
  Object.defineProperty(parent, HAS_DORMANT, {
    value: true,
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function dormantKeys(parent) {
  return Object.getOwnPropertyNames(parent).filter((key) => {
    const d = Object.getOwnPropertyDescriptor(parent, key);
    return d !== void 0 && d.enumerable === false && "value" in d;
  });
}
function peerOf(branch) {
  const record = branch;
  const peer = record[NODE_STORE_SYMBOL] ?? record[NODE_ACCESSOR_PEER];
  return isTraversableNode(peer) && peer !== branch ? peer : void 0;
}
function setMemberPresence(branch, key, presence) {
  const apply = presence === "active" ? activateOne : deactivateOne;
  let changed = apply(branch, key);
  const peer = peerOf(branch);
  if (peer) changed = apply(peer, key) || changed;
  return changed;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/write-context.ts
var activeContext;
function withWriteContext(meta, fn) {
  const previous = activeContext;
  activeContext = meta;
  try {
    return fn();
  } finally {
    activeContext = previous;
  }
}
function getActiveWriteContext() {
  return activeContext;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/owned-mutation.ts
function mergeOwnedNodeMetadata(node, patch) {
  const existing = OWNED_NODE_METADATA.get(node) ?? {};
  OWNED_NODE_METADATA.set(node, { ...existing, ...patch });
}
function defineOwnedPositionIds(node, positionIds, storage = "property") {
  if (!positionIds || positionIds.length === 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { positionIds: [...positionIds] });
    return;
  }
  Object.defineProperty(node, "__positionIds", {
    get: () => [...positionIds],
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerPath(node, ownerPath, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerPath });
    return;
  }
  Object.defineProperty(node, "__ownerPath", {
    value: ownerPath,
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerId(node, ownerId, storage = "property") {
  if (ownerId === void 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerId });
    return;
  }
  Object.defineProperty(node, "__ownerId", {
    value: ownerId,
    enumerable: false,
    configurable: true
  });
}
function defineIntrinsicMutationEmitter(node, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { emitsMutations: true });
    return;
  }
  Object.defineProperty(node, "__emitsMutations", {
    value: true,
    enumerable: false,
    configurable: true
  });
}
function emitOwnedMutation(options, before, after, mutationIntent) {
  markOwnerInvalidated(options.ownerId);
  const positionId = options.positionIds?.[0];
  if (positionId === void 0) {
    return;
  }
  if (!hasPathObservers()) {
    return;
  }
  pathObservation().notify(
    options.path,
    after,
    before,
    options.path,
    // subjectIds: this generic scalar route has no subject-identity producer
    // and must not acquire one. Entity/structural notification owns that fact.
    void 0,
    [positionId],
    {
      ...getActiveWriteContext() ?? {},
      mutationIntent
    },
    options.ownerId
  );
}
function wrapOwnedWritableSignal(leaf2, options, hooks = {}) {
  const metadataStorage = options.metadataStorage ?? "property";
  defineOwnedPositionIds(leaf2, options.positionIds, metadataStorage);
  defineOwnedOwnerId(leaf2, options.ownerId, metadataStorage);
  defineOwnedOwnerPath(leaf2, options.path, metadataStorage);
  defineIntrinsicMutationEmitter(leaf2, metadataStorage);
  const releaseIntrinsicObserver = observeIntrinsicMutations(
    leaf2,
    (mutation) => {
      if (mutation.changed) {
        emitOwnedMutation(
          options,
          mutation.before,
          mutation.after,
          mutation.intent
        );
      }
      if (mutation.intent === "replace") {
        hooks.afterSet?.(
          mutation.after,
          mutation.before,
          mutation.after,
          mutation.changed
        );
      } else {
        hooks.afterUpdate?.(
          mutation.before,
          mutation.after,
          mutation.changed
        );
      }
    }
  );
  if (!releaseIntrinsicObserver) {
    throw new Error("SignalTree location has no intrinsic mutation source");
  }
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/position-registry.ts
var POSITION_REGISTRY_SYMBOL = Symbol.for("SignalTree:PositionRegistry");
var nextRegistryId = 1;
var TreePositionRegistry = class {
  /**
   * ⚠️ THE ONE PLACE a counter value becomes a tree-namespace identity.
   *
   * Branding HERE rather than at each consumer means `registry.id` and
   * `ownerRegistry.id` are already `TreeId` everywhere downstream — no producer
   * has to independently assert that some number is a tree identity.
   */
  id = nextRegistryId++;
  nextPositionId = 1;
  parents = /* @__PURE__ */ new Map();
  addresses = /* @__PURE__ */ new Map();
  registerPositionAddress(position, address) {
    this.addresses.set(position, sealedAddress(address));
  }
  addressFor(position) {
    return this.addresses.get(position);
  }
  collectionPaths = /* @__PURE__ */ new Map();
  registerCollectionPath(position, path) {
    this.collectionPaths.set(position, path);
  }
  collectionPathFor(position) {
    return this.collectionPaths.get(position);
  }
  allocate(parent) {
    const positionId = this.nextPositionId++;
    this.parents.set(positionId, parent);
    return positionId;
  }
  parentOf(position) {
    return this.parents.get(position);
  }
  contains(authority, participant) {
    if (authority === participant) {
      return true;
    }
    const seen = /* @__PURE__ */ new Set();
    let current = participant;
    while (current !== void 0 && !seen.has(current)) {
      seen.add(current);
      const parent = this.parentOf(current);
      if (parent === authority) {
        return true;
      }
      current = parent;
    }
    return false;
  }
};
function createPositionRegistry() {
  return new TreePositionRegistry();
}
function definePositionRegistry(node, registry) {
  Object.defineProperty(node, POSITION_REGISTRY_SYMBOL, {
    value: registry,
    enumerable: false,
    configurable: true
  });
}
function getPositionRegistry(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[POSITION_REGISTRY_SYMBOL];
}
var nodeAddresses = /* @__PURE__ */ new WeakMap();
function sealedAddress(address) {
  return Object.isFrozen(address) ? address : Object.freeze(address.slice());
}
function childAddressOf(address, key) {
  return Object.freeze(address.concat(key));
}
function defineNodeAddress(node, address) {
  nodeAddresses.set(node, sealedAddress(address));
}
function getNodeAddress(node) {
  return isTraversableNode(node) ? nodeAddresses.get(node) : void 0;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/runtime-tree-plan.ts
var RESTORATION_CAPABILITIES = [
  "causal-runtime",
  "temporal-snapshots"
];
function createRuntimeTreePlan(hasCapability) {
  return Object.freeze({
    hasCapability,
    hasRestorationAuthority: RESTORATION_CAPABILITIES.some(
      (capability) => hasCapability(capability)
    )
  });
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/materialize-markers.ts
function createMaterializationContext(positionTopologyEnabled = true, hasCapability = (capability) => capability === "position-topology" ? positionTopologyEnabled : true, physicalCommitClock, locationRuntime = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const positionRegistry = createPositionRegistry();
  return {
    locationRuntime,
    positionRegistry,
    positionTopologyEnabled,
    physicalCommitClock,
    hasCapability,
    runtimeTreePlan: createRuntimeTreePlan(hasCapability),
    allocatePositionId: (parentPositionId) => positionRegistry.allocate(parentPositionId),
    physicalOwners: []
  };
}
var PROCESSOR_STAMP = Symbol.for("SignalTree:MarkerProcessor");
function getNodeProcessor(node) {
  if (!isTraversableNode(node)) return void 0;
  return node[PROCESSOR_STAMP];
}
function snapshotMarkerNode(node, parent) {
  const proc = getNodeProcessor(node);
  if (!proc?.snapshot) return void 0;
  if (!isTraversableNode(node)) return { value: proc.snapshot(node) };
  if (parent) bindSnapshotParent(node, parent);
  if (!proc.cacheSnapshot) {
    markSnapshotVolatile(node);
    return { value: proc.snapshot(node) };
  }
  const snapshot = proc.snapshot;
  return materializeSnapshotNode(node, () => ({
    value: snapshot(node)
  }));
}
function hydrateMarkerNode(node, value, mode2) {
  const proc = getNodeProcessor(node);
  if (!proc?.hydrate) return false;
  proc.hydrate(node, value, mode2);
  return true;
}
var MARKER_PROCESSORS = [];
function isRegisteredMarker(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  if (Object.getOwnPropertySymbols(value).length === 0) {
    return false;
  }
  for (const processor of MARKER_PROCESSORS) {
    if (processor.check(value)) {
      return true;
    }
  }
  return false;
}
var warnedWriteOnly = /* @__PURE__ */ new WeakSet();
function warnWriteOnlyMarker(processor, node) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (!processor.snapshot || processor.hydrate) return;
  if (typeof node === "function" && "set" in node && typeof node.set === "function") {
    return;
  }
  if (warnedWriteOnly.has(processor)) return;
  warnedWriteOnly.add(processor);
  console.warn(
    "SignalTree: a marker declares `snapshot` but no `hydrate`, and its node is not a writable signal. It will be captured by tree.$(), persistence(), devtools, audit and undo/redo \u2014 and every attempt to write it back is SILENTLY DISCARDED, so tree.$(tree.$()) loses its value. Add a `hydrate` hook, or mark it `transient: true` if it is genuinely not restorable. [ST2023]"
  );
}
var treesConstructedCount = 0;
function _recordTreeConstruction() {
  treesConstructedCount += 1;
}
var ORDINARY_STATE = Symbol.for("SignalTree:OrdinaryStateRequest");
var KEY_INDEX = Symbol.for("SignalTree:DynamicKeyIndex");
var MEMBER_MATERIALIZER = Symbol.for("SignalTree:MemberMaterializer");
function attachKeyIndex(branch) {
  const members = /* @__PURE__ */ new Map();
  for (const key of Object.keys(branch)) {
    members.set(key, branch[key]);
  }
  Object.defineProperty(branch, KEY_INDEX, {
    value: members,
    enumerable: false,
    configurable: true
  });
}
function installPreparedMember(branch, key, child, responsibility) {
  const define = (target) => {
    Object.defineProperty(target, key, {
      value: child,
      enumerable: true,
      writable: true,
      configurable: true
    });
  };
  define(branch);
  const backingStore = branch[NODE_STORE_SYMBOL];
  if (backingStore && backingStore !== branch) define(backingStore);
  if (responsibility) {
    installTerminalRecord(responsibility);
  }
  linkAddedMember(branch, key, child);
  branch[KEY_INDEX]?.set(
    key,
    child
  );
}
var applyMemberValue;
function setMemberValueApplier(fn) {
  applyMemberValue = fn;
}
function isOrdinaryStateRequest(v) {
  return isTraversableNode(v) && v[ORDINARY_STATE] === true;
}
function materializeKeyedAware(authority, request, path, parentPositionId, address) {
  const branch = authority.materialize(
    request.value,
    path,
    parentPositionId,
    address
  );
  if (request.keyedLookup && isTraversableNode(branch)) {
    attachKeyIndex(branch);
    Object.defineProperty(branch, MEMBER_MATERIALIZER, {
      value: authority.bindMember(branch),
      enumerable: false,
      configurable: true
    });
  }
  return branch;
}
function materializeMarkers(node, notifier, path = [], context = createMaterializationContext(), authority) {
  if (!isTraversableNode(node)) return;
  if (isTreeCell(node)) return;
  const isAccessor = typeof node === "function" && isNodeAccessor(node);
  if (typeof node === "function" && !isAccessor) return;
  const getNotifier = () => notifier ?? pathObservation();
  const keys = Object.keys(node);
  for (const key of keys) {
    const value = node[key];
    const currentPath = childAddressOf(path, key);
    const pathString = currentPath.join(".");
    let processed = false;
    for (const processor of MARKER_PROCESSORS) {
      if (processor.check(value)) {
        try {
          const parentPositionId = node.__positionIds?.[0];
          const produced = processor.create(
            value,
            getNotifier(),
            pathString,
            context,
            parentPositionId
          );
          const materialized = isOrdinaryStateRequest(produced) && authority ? materializeKeyedAware(
            authority,
            produced,
            pathString,
            parentPositionId,
            currentPath
          ) : produced;
          if (isTraversableNode(materialized)) {
            defineNodeAddress(materialized, currentPath);
            if (context.positionTopologyEnabled) {
              for (const position of getOwnedPositionIds(materialized) ?? []) {
                context.positionRegistry.registerPositionAddress(
                  position,
                  currentPath
                );
              }
            }
            bindLocationRuntime(
              materialized,
              context.locationRuntime
            );
            Object.defineProperty(materialized, PROCESSOR_STAMP, {
              value: processor,
              enumerable: false,
              writable: false,
              configurable: true
            });
          }
          if (typeof ngDevMode === "undefined" || ngDevMode) {
            warnWriteOnlyMarker(processor, materialized);
          }
          node[key] = materialized;
          const backingStore = node[NODE_STORE_SYMBOL];
          if (backingStore && backingStore !== node) {
            backingStore[key] = materialized;
          }
          processed = true;
        } catch (err) {
          if (typeof ngDevMode === "undefined" || ngDevMode) {
            console.error(
              `SignalTree: Failed to materialize marker at "${pathString}"`,
              err
            );
          }
        }
        break;
      }
    }
    if (!processed && value != null) {
      if (isNodeAccessor(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      } else if (typeof value === "object" && !Array.isArray(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      }
    }
  }
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/observation-substrate.ts
var OBSERVATION = /* @__PURE__ */ new WeakMap();
var BRANCH_SCOPES = /* @__PURE__ */ new WeakMap();
function inheritObservationForAddedMember(parent, child) {
  const scopes = BRANCH_SCOPES.get(nodeStoreOf(parent) ?? parent);
  if (!scopes) return;
  for (const scope of scopes) scope.visit(child);
}
function installDormantObservation(leaf2) {
  OBSERVATION.set(leaf2, {
    claims: 0,
    positionId: void 0,
    releaseMutationObserver: () => void 0
  });
}
function claimLeaf(node) {
  const state = OBSERVATION.get(node);
  if (!state) return void 0;
  const registry = getPositionRegistry(node);
  const ownerPath = getOwnedOwnerPath(node);
  if (!registry || ownerPath === void 0) return void 0;
  if (state.claims === 0) {
    if (state.positionId === void 0) {
      state.positionId = getOwnedPositionIds(node)?.[0] ?? registry.allocate();
      const address = getNodeAddress(node);
      if (address) registry.registerPositionAddress(state.positionId, address);
      defineOwnedPositionIds(node, [state.positionId]);
      defineOwnedOwnerId(node, registry.id);
    }
    const positionIds = [state.positionId];
    state.releaseMutationObserver = observeIntrinsicMutations(node, (mutation) => {
      if (!mutation.changed) return;
      emitOwnedMutation(
        { path: ownerPath, positionIds, ownerId: registry.id },
        mutation.before,
        mutation.after,
        mutation.intent
      );
    }) ?? (() => void 0);
  }
  state.claims++;
  let released = false;
  return () => {
    if (released) return;
    released = true;
    state.claims--;
    if (state.claims === 0) {
      state.releaseMutationObserver();
      state.releaseMutationObserver = () => void 0;
    }
  };
}
function acquireObservation(source) {
  const releases = [];
  const seen = /* @__PURE__ */ new Set();
  const branches = [];
  const scope = { visit: (node) => visit(node) };
  const visit = (candidate) => {
    if (!isTraversableNode(candidate)) return;
    const node = nodeStoreOf(candidate) ?? candidate;
    if (seen.has(node)) return;
    seen.add(node);
    const claim = claimLeaf(node);
    if (claim) {
      releases.push(claim);
      return;
    }
    let scopes = BRANCH_SCOPES.get(node);
    if (!scopes) {
      scopes = /* @__PURE__ */ new Set();
      BRANCH_SCOPES.set(node, scopes);
    }
    scopes.add(scope);
    branches.push(node);
    for (const key of Object.keys(node)) {
      visit(node[key]);
    }
    if (hasDormantMembers(node)) {
      for (const key of dormantKeys(node)) {
        const child = node[key];
        if (isDormantMember(child)) visit(child);
      }
    }
  };
  visit(source);
  let released = false;
  return () => {
    if (released) return;
    released = true;
    for (const branch of branches) {
      const scopes = BRANCH_SCOPES.get(branch);
      scopes?.delete(scope);
      if (scopes?.size === 0) BRANCH_SCOPES.delete(branch);
    }
    for (const release of releases) release();
    branches.length = 0;
    releases.length = 0;
    seen.clear();
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/root-source.ts
var ROOT_AUTHORITIES = /* @__PURE__ */ new WeakMap();
function defineRootTree(rootAccessor, authority) {
  ROOT_AUTHORITIES.set(rootAccessor, authority);
}
function getRootTree(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return ROOT_AUTHORITIES.get(node);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/utilities/deep-equal.ts
function deepEqual(a, b) {
  return equalsInner(a, b, 0, void 0);
}
var CYCLE_GUARD_DEPTH = 64;
function equalsInner(a, b, depth, seen) {
  if (a === b) return true;
  if (a == null || b == null) return a === b;
  const typeA = typeof a;
  const typeB = typeof b;
  if (typeA !== typeB) return false;
  if (typeA !== "object") return a !== a && b !== b;
  if (depth >= CYCLE_GUARD_DEPTH) {
    seen ??= /* @__PURE__ */ new WeakMap();
    if (seen.get(a) === b) return true;
    seen.set(a, b);
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    const bArr = b;
    for (let i = 0; i < a.length; i++) {
      const x = a[i];
      const y = bArr[i];
      if (x === y) continue;
      if (!equalsInner(x, y, depth + 1, seen)) return false;
    }
    return true;
  }
  if (Array.isArray(b)) return false;
  if (a instanceof Date && b instanceof Date) {
    try {
      const ta = a.getTime();
      const tb = b.getTime();
      return ta === tb || ta !== ta && tb !== tb;
    } catch {
      return false;
    }
  }
  if (a instanceof RegExp && b instanceof RegExp) {
    return a.source === b.source && a.flags === b.flags;
  }
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    for (const [key, value] of a) {
      if (!b.has(key) || !equalsInner(value, b.get(key), depth + 1, seen))
        return false;
    }
    return true;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    for (const value of a) {
      if (!b.has(value)) return false;
    }
    return true;
  }
  if (a instanceof Error && b instanceof Error) {
    if (a.name !== b.name || a.message !== b.message) return false;
  } else if (a instanceof Number && b instanceof Number || a instanceof String && b instanceof String || a instanceof Boolean && b instanceof Boolean) {
    const va = a.valueOf();
    const vb = b.valueOf();
    if (!(va === vb || va !== va && vb !== vb)) return false;
  }
  try {
    if (a.constructor !== b.constructor) {
      return false;
    }
  } catch {
    return false;
  }
  const objA = a;
  const objB = b;
  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  const hasOwn = Object.prototype.hasOwnProperty;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!hasOwn.call(objB, key)) return false;
    const x = objA[key];
    const y = objB[key];
    if (x === y) continue;
    if (!equalsInner(x, y, depth + 1, seen)) return false;
  }
  return true;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/utilities/is-built-in-object.ts
function isBuiltInObject(value) {
  if (value === null || value === void 0) return false;
  if (value instanceof Date || value instanceof RegExp || typeof value === "function" || value instanceof Map || value instanceof Set || value instanceof WeakMap || value instanceof WeakSet || value instanceof ArrayBuffer || value instanceof DataView || value instanceof Error || value instanceof Promise) {
    return true;
  }
  if (value instanceof Int8Array || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Int16Array || value instanceof Uint16Array || value instanceof Int32Array || value instanceof Uint32Array || value instanceof Float32Array || value instanceof Float64Array || value instanceof BigInt64Array || value instanceof BigUint64Array) {
    return true;
  }
  if (typeof window !== "undefined") {
    if (value instanceof URL || value instanceof URLSearchParams || value instanceof FormData || value instanceof Blob || typeof File !== "undefined" && value instanceof File || typeof FileList !== "undefined" && value instanceof FileList || typeof Headers !== "undefined" && value instanceof Headers || typeof Request !== "undefined" && value instanceof Request || typeof Response !== "undefined" && value instanceof Response || typeof AbortController !== "undefined" && value instanceof AbortController || typeof AbortSignal !== "undefined" && value instanceof AbortSignal) {
      return true;
    }
  }
  try {
    const NodeBuffer = globalThis?.Buffer;
    if (NodeBuffer && value instanceof NodeBuffer) {
      return true;
    }
  } catch {
  }
  return false;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/utils.ts
var isReactiveStateValue = isTreeCell;
function warnUnwrapSkipped(key) {
  console.error(
    `SignalTree: "${key}" OMITTED from snapshot \u2014 value is a function that is neither signal nor node accessor. [ST2008]`
  );
}
function isMemoisable(node) {
  return isSnapshotNode(node);
}
function materializeNode(store) {
  if (!isMemoisable(store)) return unwrap(store);
  return materializeSnapshotNode(store, () => unwrap(store));
}
var DERIVED_STAMP = Symbol.for("SignalTree:Derived");
function stampDerived(sig) {
  if (typeof sig === "function") markTreeCell(sig);
  if (isTraversableNode(sig) && typeof sig.set !== "function") {
    Object.defineProperty(sig, DERIVED_STAMP, {
      value: true,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  return sig;
}
function unwrap(node) {
  if (node === null || node === void 0) {
    return node;
  }
  if (isNodeAccessor(node)) {
    const target = snapshotNodeKey(node);
    return isMemoisable(node) ? materializeSnapshotNode(node, () => buildFromStore(target)) : buildFromStore(target);
  }
  if (isReactiveStateValue(node)) {
    return node();
  }
  if (typeof node !== "object") {
    return node;
  }
  if (Array.isArray(node)) {
    return node;
  }
  if (isBuiltInObject(node)) {
    return node;
  }
  return buildFromStore(node);
}
function unwrapBranchForWriteCapture(node) {
  return isNodeAccessor(node) ? buildFromStore(snapshotNodeKey(node), true) : unwrap(node);
}
function buildFromStore(node, uncachedBranches = false) {
  const own = snapshotMarkerNode(node);
  if (own) return own.value;
  const result = {};
  if (hasDormantMembers(node)) {
    for (const key of dormantKeys(node)) {
      const dormant = node[key];
      if (typeof dormant === "function") dormant();
    }
  }
  for (const key in node) {
    if (!Object.prototype.hasOwnProperty.call(node, key)) continue;
    const value = node[key];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshot = snapshotMarkerNode(value, node);
    if (markerSnapshot) {
      result[key] = markerSnapshot.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnUnwrapSkipped(key);
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      bindSnapshotParent(value, node);
      result[key] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[key] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[key] = unwrap(value);
    } else {
      result[key] = value;
    }
  }
  const symbols = Object.getOwnPropertySymbols(node);
  for (const sym of symbols) {
    if (typeof sym.description === "string" && sym.description.startsWith("SignalTree:")) {
      continue;
    }
    const value = node[sym];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshotSym = snapshotMarkerNode(value, node);
    if (markerSnapshotSym) {
      result[sym] = markerSnapshotSym.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        warnUnwrapSkipped(String(sym));
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      result[sym] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[sym] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[sym] = unwrap(value);
    } else {
      result[sym] = value;
    }
  }
  return result;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/mutation-capture-runtime.ts
var MUTATION_CAPTURE_RUNTIME = Symbol.for(
  "SignalTree:MutationCaptureRuntime"
);
function createMutationCaptureRuntime() {
  let activeCount = 0;
  const entityListeners = /* @__PURE__ */ new Set();
  const structuralBoundaryListeners = /* @__PURE__ */ new Set();
  const collectionOrderListeners = /* @__PURE__ */ new Set();
  return {
    hasCommittedEntityObservers() {
      return activeCount > 0 && entityListeners.size > 0;
    },
    hasStructuralBoundaryObservers() {
      return activeCount > 0 && structuralBoundaryListeners.size > 0;
    },
    subscribeStructuralBoundary(listener) {
      structuralBoundaryListeners.add(listener);
      return () => {
        structuralBoundaryListeners.delete(listener);
      };
    },
    publishCommittedEntity(capture) {
      if (activeCount === 0) return;
      const listeners3 = capture.structuralFrontier ? [...entityListeners, ...structuralBoundaryListeners] : [...entityListeners];
      for (const listener of listeners3) {
        try {
          listener(capture);
        } catch (error) {
          reportContainedObserverError({
            error,
            operation: "transaction:listener"
          });
        }
      }
    },
    subscribeCommittedEntity(listener) {
      entityListeners.add(listener);
      return () => {
        entityListeners.delete(listener);
      };
    },
    isCaptureActive() {
      return activeCount > 0;
    },
    activateCapture() {
      activeCount += 1;
      let released = false;
      return () => {
        if (released) {
          return;
        }
        released = true;
        activeCount = Math.max(0, activeCount - 1);
      };
    },
    publishCollectionOrder(capture) {
      if (activeCount === 0) {
        return;
      }
      for (const listener of [...collectionOrderListeners]) {
        listener(capture);
      }
    },
    subscribeCollectionOrder(listener) {
      collectionOrderListeners.add(listener);
      return () => collectionOrderListeners.delete(listener);
    }
  };
}
function getMutationCaptureRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[MUTATION_CAPTURE_RUNTIME];
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tree-scalar-slot-runtime.ts
var ScalarSlotMutationFrameImpl = class {
  constructor(baseRevision, getCommittedRevision, readValue, commitValues, assertSlotIndex, prepareValues) {
    this.baseRevision = baseRevision;
    this.getCommittedRevision = getCommittedRevision;
    this.readValue = readValue;
    this.commitValues = commitValues;
    this.assertSlotIndex = assertSlotIndex;
    this.prepareValues = prepareValues;
  }
  staged = /* @__PURE__ */ new Map();
  closed = false;
  set(slotIndex, value) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    this.staged.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    const current = this.staged.has(slotIndex) ? this.staged.get(slotIndex) : this.readValue(slotIndex);
    this.staged.set(slotIndex, updater(current));
  }
  discard() {
    this.assertOpen();
    this.closed = true;
    this.staged.clear();
  }
  prepareCommit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) throw new Error("Stale scalar preparation");
    return this.prepareValues(this.staged, options);
  }
  commit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) {
      throw new Error("ScalarSlotMutationFrame base revision is stale.");
    }
    if (this.staged.size > 0) {
      return this.commitValues(this.staged, options);
    }
    return {
      revision: this.getCommittedRevision(),
      changedSlots: []
    };
  }
  assertOpen() {
    if (this.closed) {
      throw new Error("ScalarSlotMutationFrame is already closed.");
    }
  }
};
function createTreeScalarSlotRuntime(physicalCommitClock) {
  const values = [];
  const equalities = [];
  const slotByPositionId = /* @__PURE__ */ new Map();
  let revision = 0;
  const getCommittedRevision = () => physicalCommitClock?.revision() ?? revision;
  const advanceRevision = () => {
    const nextRevision = physicalCommitClock?.advance();
    if (nextRevision !== void 0) {
      return nextRevision;
    }
    revision += 1;
    return revision;
  };
  const assertSlotIndex = (slotIndex) => {
    if (!Number.isInteger(slotIndex) || slotIndex < 0 || slotIndex >= values.length) {
      throw new Error(`Scalar slot index ${slotIndex} is out of bounds.`);
    }
  };
  const collectSlotChanges = (staged) => {
    const changed = [];
    for (const [slotIndex, nextValue] of staged) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      if (!equalities[slotIndex](values[slotIndex], nextValue)) {
        changed.push({ slotIndex, nextValue });
      }
    }
    return changed;
  };
  const prepareSlots = (staged, options) => {
    const base = getCommittedRevision();
    const changed = collectSlotChanges(staged);
    if (getCommittedRevision() !== base) throw new Error("Reentrant scalar preparation");
    let used = false;
    return () => {
      if (used) throw new Error("Prepared scalar commit already used");
      if (getCommittedRevision() !== base) throw new Error("Stale prepared scalar commit");
      used = true;
      for (const { slotIndex, nextValue } of changed) {
        values[slotIndex] = nextValue;
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("slotWrites");
        }
      }
      const revision2 = changed.length && options?.advanceRevision !== false ? advanceRevision() : getCommittedRevision();
      if (changed.length && options?.advanceRevision !== false && PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return { revision: revision2, changedSlots: changed.map((x) => x.slotIndex) };
    };
  };
  const commitSlots = (staged, options) => {
    const changed = collectSlotChanges(staged);
    if (changed.length === 0) {
      return {
        revision: getCommittedRevision(),
        changedSlots: []
      };
    }
    for (const { slotIndex, nextValue } of changed) {
      values[slotIndex] = nextValue;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("slotWrites", changed.length);
    }
    const nextRevision = options?.advanceRevision === false ? getCommittedRevision() : advanceRevision();
    if (options?.advanceRevision !== false && PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("revisionIncrements");
    }
    return {
      revision: nextRevision,
      changedSlots: changed.map(({ slotIndex }) => slotIndex)
    };
  };
  const commitSlotValue = (slotIndex, nextValue, options) => {
    assertSlotIndex(slotIndex);
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("equalityChecks");
    }
    if (equalities[slotIndex](values[slotIndex], nextValue)) return false;
    values[slotIndex] = nextValue;
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("slotWrites");
    }
    if (options?.advanceRevision !== false) {
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
    }
    return true;
  };
  const commitSlot = (slotIndex, nextValue, options) => {
    const changed = commitSlotValue(slotIndex, nextValue, options);
    return changed ? { revision: getCommittedRevision(), changed: true, slot: slotIndex } : { revision: getCommittedRevision(), changed: false };
  };
  return {
    createSlot(initialValue, equal, positionId) {
      const slotIndex = values.length;
      values.push(initialValue);
      equalities.push(equal);
      if (positionId !== void 0) {
        slotByPositionId.set(positionId, slotIndex);
      }
      return slotIndex;
    },
    readSlot(slotIndex) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotReads");
      }
      return values[slotIndex];
    },
    commitRecorded(slotIndex, value, prepare) {
      assertSlotIndex(slotIndex);
      const base = getCommittedRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      const equal = equalities[slotIndex](values[slotIndex], value);
      if (getCommittedRevision() !== base) throw new Error("Scalar equality reentered physical installation");
      if (equal) return false;
      const plan = prepare?.();
      if (getCommittedRevision() !== base) throw new Error("Terminal preparation reentered physical installation");
      values[slotIndex] = value;
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotWrites");
      }
      if (plan) {
        installTerminalRecord(plan);
      }
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return true;
    },
    commitSlot(slotIndex, value) {
      return commitSlot(slotIndex, value);
    },
    commitSlotValue(slotIndex, value) {
      return commitSlotValue(slotIndex, value);
    },
    updateSlot(slotIndex, updater) {
      assertSlotIndex(slotIndex);
      return commitSlot(slotIndex, updater(values[slotIndex]));
    },
    beginFrame() {
      return new ScalarSlotMutationFrameImpl(
        getCommittedRevision(),
        getCommittedRevision,
        (slotIndex) => values[slotIndex],
        commitSlots,
        assertSlotIndex,
        prepareSlots
      );
    },
    resolveScalarSlot(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return slotByPositionId.get(positionId);
    },
    revision() {
      return getCommittedRevision();
    },
    slotCount() {
      return values.length;
    }
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tree-scalar-leaf-runtime.ts
var ScalarSlotPublication = class {
  constructor(locations) {
    this.locations = locations;
  }
  bindings = [];
  bind(slotIndex, binding) {
    this.bindings[slotIndex] = binding;
  }
  publish(result) {
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications", result.changedSlots.length);
    }
    const publishers = result.changedSlots.flatMap((slotIndex) => {
      const binding = this.bindings[slotIndex];
      return binding ? [binding] : [];
    });
    this.locations.publish(publishers);
  }
  prepareSlot(slotIndex, changed, force = false) {
    if (!changed && !force) {
      return false;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications");
    }
    return true;
  }
};
var ScalarSlotMutationFrameOrchestrator = class {
  constructor(frame, publication) {
    this.frame = frame;
    this.publication = publication;
  }
  set(slotIndex, value) {
    this.frame.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.frame.update(slotIndex, updater);
  }
  discard() {
    this.frame.discard();
  }
  prepareCommit(options) {
    const install = this.frame.prepareCommit({ advanceRevision: options?.advanceRevision });
    return () => {
      const result = install();
      if (options?.publish !== false) this.publication.publish(result);
      return result;
    };
  }
  commit(options) {
    const result = this.frame.commit({
      advanceRevision: options?.advanceRevision
    });
    if (options?.publish !== false) {
      this.publication.publish(result);
    }
    return result;
  }
};
function createScalarLeaf(kernel, publication, locations, slotIndex, liveness) {
  const holder = {};
  const read2 = (stored) => {
    if (!stored && liveness.absence?.isAbsent(holder.leaf)) {
      return void 0;
    }
    return kernel.readSlot(slotIndex);
  };
  const binding = locations.createWritable(read2, (value, _intent, prepare) => {
    const changedValue = kernel.commitRecorded(slotIndex, value, prepare);
    const result = { changed: changedValue };
    const reAdded = liveness.absence?.reAdd(holder.leaf) === true;
    const changed = publication.prepareSlot(slotIndex, result.changed, reAdded);
    return changed;
  });
  const leaf2 = binding.location;
  holder.leaf = leaf2;
  return { leaf: leaf2, binding };
}
function createTreeScalarLeafRuntime(physicalCommitClock, locations = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const kernel = createTreeScalarSlotRuntime(physicalCommitClock);
  const publication = new ScalarSlotPublication(locations);
  const leafByPositionId = /* @__PURE__ */ new Map();
  const liveness = {};
  return {
    enableAbsence(absence) {
      liveness.absence = absence;
    },
    disableAbsence() {
      liveness.absence = void 0;
    },
    createLeaf(initialValue, equal, positionId) {
      const slotIndex = kernel.createSlot(initialValue, equal, positionId);
      const { leaf: leaf2, binding } = createScalarLeaf(
        kernel,
        publication,
        locations,
        slotIndex,
        liveness
      );
      publication.bind(slotIndex, binding);
      if (positionId !== void 0) {
        leafByPositionId.set(positionId, leaf2);
      }
      return leaf2;
    },
    beginFrame() {
      return new ScalarSlotMutationFrameOrchestrator(
        kernel.beginFrame(),
        publication
      );
    },
    runInvalidationGroup(run2) {
      locations.runInvalidationGroup(run2);
    },
    publishPrepared(result) {
      publication.publish(result);
    },
    resolveScalarSlot(positionId) {
      return kernel.resolveScalarSlot(positionId);
    },
    resolveScalarLeaf(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return leafByPositionId.get(positionId);
    },
    revision() {
      return kernel.revision();
    },
    slotCount() {
      return kernel.slotCount();
    }
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/physical-commit-clock.ts
var PHYSICAL_COMMIT_CLOCK = Symbol.for("SignalTree:PhysicalCommitClock");
function createPhysicalCommitClock() {
  let revision = 0;
  return {
    revision() {
      return revision;
    },
    advance() {
      revision += 1;
      return revision;
    }
  };
}
function definePhysicalCommitClock(node, clock) {
  Object.defineProperty(node, PHYSICAL_COMMIT_CLOCK, {
    value: clock,
    enumerable: false,
    configurable: true
  });
}
function getPhysicalCommitClock(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[PHYSICAL_COMMIT_CLOCK];
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tree-capabilities.ts
var TREE_CAPABILITY_ORDER = [
  "mutation-capture",
  "position-topology",
  "causal-runtime",
  "temporal-snapshots"
];
var TREE_CAPABILITY_DEPENDENCIES = {
  "mutation-capture": [],
  "position-topology": [],
  "causal-runtime": ["mutation-capture", "position-topology"],
  "temporal-snapshots": []
};
var canonicalizeCapabilities = (capabilities) => {
  const set = new Set(capabilities);
  return TREE_CAPABILITY_ORDER.filter((capability) => set.has(capability));
};
function collectRequestedTreeCapabilities(enhancerMeta) {
  const requested = /* @__PURE__ */ new Set();
  for (const meta of enhancerMeta) {
    for (const capability of meta?.capabilities ?? []) {
      requested.add(capability);
    }
  }
  return canonicalizeCapabilities(requested);
}
function resolveTreeCapabilities(requestedCapabilities) {
  assertTreeCapabilityGraphAcyclic();
  const requested = canonicalizeCapabilities(requestedCapabilities);
  const resolved = new Set(requested);
  const queue = [...requested];
  while (queue.length > 0) {
    const capability = queue.shift();
    if (!capability) {
      continue;
    }
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      if (resolved.has(dependency)) {
        continue;
      }
      resolved.add(dependency);
      queue.push(dependency);
    }
  }
  return {
    requestedCapabilities: requested,
    resolvedCapabilities: canonicalizeCapabilities(resolved)
  };
}
function assertTreeCapabilityGraphAcyclic() {
  const visiting = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new Set();
  const visit = (capability) => {
    if (visited.has(capability)) {
      return;
    }
    if (visiting.has(capability)) {
      throw new Error(
        `SignalTree: capability dependency cycle detected at "${capability}".`
      );
    }
    visiting.add(capability);
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      visit(dependency);
    }
    visiting.delete(capability);
    visited.add(capability);
  };
  for (const capability of TREE_CAPABILITY_ORDER) {
    visit(capability);
  }
}
var TREE_CAPABILITIES = Symbol.for("SignalTree:TreeCapabilities");
function defineTreeCapabilities(tree, capabilities) {
  Object.defineProperty(tree, TREE_CAPABILITIES, {
    value: capabilities,
    enumerable: false,
    configurable: true
  });
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/merge-derived.ts
function ensurePathAndGetTarget($, path) {
  if (!path) return $;
  const parts = path.split(".");
  let current = $;
  for (const part of parts) {
    if (!(part in current)) {
      current[part] = {};
    }
    current = current[part];
  }
  return current;
}
function mergeDerivedState($, derivedDef, path = "", locations) {
  if (!derivedDef || typeof derivedDef !== "object") {
    return;
  }
  for (const [key, value] of Object.entries(derivedDef)) {
    const currentPath = path ? `${path}.${key}` : key;
    if (typeof value === "function" && locations) {
      const target = ensurePathAndGetTarget($, path);
      if (key in target && (typeof ngDevMode === "undefined" || ngDevMode)) {
        console.warn(
          `SignalTree: Derived location "${currentPath}" overwrites source state. Consider using a different key to avoid confusion.`
        );
      }
      target[key] = stampDerived(
        locations.createDerived(value)
      );
    } else if (typeof value === "object" && value !== null) {
      const target = ensurePathAndGetTarget($, path);
      if (!(key in target)) {
        target[key] = {};
      } else if (isTreeCell(target[key])) {
        throw new Error(
          `SignalTree: Cannot merge derived object into "${currentPath}" because source is a signal. Either make source an object or use a different key.`
        );
      }
      mergeDerivedState($, value, currentPath, locations);
    } else if (typeof ngDevMode === "undefined" || ngDevMode) {
      console.warn(
        `[SignalTree] [ST2007] Derived "${currentPath}" dropped: the value could not be realized by this tree. Return a computation recipe, a value recognized by the package realization, or a nested object. See ST2007.`
      );
    }
  }
}
function applyDerivedFactory($, factory, locations) {
  mergeDerivedState($, factory($), "", locations);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/utilities/deep-clone.ts
var globalStructuredClone = typeof globalThis === "object" && globalThis !== null ? globalThis.structuredClone : void 0;
function deepClone(value) {
  if (globalStructuredClone) {
    try {
      return globalStructuredClone(value);
    } catch {
    }
  }
  return cloneValue(value, /* @__PURE__ */ new WeakMap());
}
function cloneValue(value, seen) {
  if (value === null || typeof value !== "object") {
    return value;
  }
  if (typeof value === "function") {
    return value;
  }
  const existing = seen.get(value);
  if (existing) {
    return existing;
  }
  if (value instanceof Date) {
    return new Date(value.getTime());
  }
  if (value instanceof RegExp) {
    return new RegExp(value.source, value.flags);
  }
  if (value instanceof Map) {
    const result2 = /* @__PURE__ */ new Map();
    seen.set(value, result2);
    for (const [key, entryValue] of value) {
      result2.set(cloneValue(key, seen), cloneValue(entryValue, seen));
    }
    return result2;
  }
  if (value instanceof Set) {
    const result2 = /* @__PURE__ */ new Set();
    seen.set(value, result2);
    for (const entry of value) {
      result2.add(cloneValue(entry, seen));
    }
    return result2;
  }
  if (Array.isArray(value)) {
    const result2 = new Array(value.length);
    seen.set(value, result2);
    for (let i = 0; i < value.length; i++) {
      result2[i] = cloneValue(value[i], seen);
    }
    return result2;
  }
  if (ArrayBuffer.isView(value)) {
    if (value instanceof DataView) {
      const bufferClone2 = cloneValue(value.buffer, seen);
      return new DataView(bufferClone2, value.byteOffset, value.byteLength);
    }
    const viewWithSlice = value;
    if (typeof viewWithSlice.slice === "function") {
      return viewWithSlice.slice();
    }
    const bufferClone = cloneValue(
      value.buffer,
      seen
    );
    return new value.constructor(
      bufferClone,
      value.byteOffset,
      value.length
    );
  }
  if (value instanceof ArrayBuffer) {
    return value.slice(0);
  }
  const proto = Object.getPrototypeOf(value);
  const result = proto ? Object.create(proto) : {};
  seen.set(value, result);
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor) continue;
    if ("value" in descriptor) {
      descriptor.value = cloneValue(descriptor.value, seen);
    }
    Object.defineProperty(result, key, descriptor);
  }
  return result;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/entity-membership-source.ts
var MEMBERSHIP_OPEN_ORDER = 2;
var MEMBERSHIP_CLOSE = 3;
var SOURCE = Symbol("SignalTree:EntityMembershipSource");
var HOLDS = /* @__PURE__ */ new WeakMap();
var noop = () => void 0;
function holdEntityMembershipDelivery(root) {
  const registry = getPositionRegistry(root);
  return registry && HOLDS.get(registry)?.() || noop;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/entity-projection-seed.ts
var SEED = Symbol("signaltree.entityProjectionSeed");
var LOCATION_BINDING = Symbol("signaltree.entityLocationBinding");
function getEntityLocationBinding(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[LOCATION_BINDING];
}
function getEntityProjectionSeed(node) {
  if (node === null || typeof node !== "object") return void 0;
  const produce = node[SEED];
  return typeof produce === "function" ? produce() : void 0;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/physical-rows.ts
var physicalRows = [];
var taps = { depth: 0 };
function openPhysicalRows(registry) {
  physicalRows.push([registry, taps.depth]);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/types.ts
var SignalTreeRollbackError = class _SignalTreeRollbackError extends Error {
  code = "SIGNALTREE_ROLLBACK_FAILED";
  /**
   * Non-enumerable when set, so structured logging cannot drag a live
   * transaction handle into a serialized error payload. Read it directly.
   */
  recovery;
  // NOT declared as a field. Whether `cause` exists on `Error` depends on the
  // lib target, and the workspace disagrees: the demo's compiler requires
  // `override` (TS4114) while core's rollup build rejects it as not present in
  // the base (TS4113). Assigning without declaring satisfies both.
  constructor(message = "SignalTree could not rollback the pending transaction", options) {
    super(message);
    this.name = "SignalTreeRollbackError";
    this.cause = options?.cause;
    Object.setPrototypeOf(this, _SignalTreeRollbackError.prototype);
  }
};

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree.ts
var isWritableCell = (v) => typeof v === "function" && "set" in v && typeof v.set === "function";
var readWritableCell = (cell) => "peek" in cell && typeof cell.peek === "function" ? cell.peek() : cell();
var ENTITY_ARRAY_MIN_LENGTH = 32;
var ENTITY_ARRAY_SAMPLE = 64;
var ENTITY_ID_KEYS = ["id", "_id", "uuid", "key"];
var ENTITY_ARRAY_WARNED = /* @__PURE__ */ new Set();
var ENTITY_ARRAY_WARN_CAP = 256;
var NODE_ACCESSOR_PEER2 = Symbol.for("SignalTree:NodeAccessorPeer");
function createTreeBuildPlan(requestedCapabilities, leafMetadataStorage) {
  const resolved = resolveTreeCapabilities(requestedCapabilities);
  return {
    requestedCapabilities: resolved.requestedCapabilities,
    capabilities: resolved.resolvedCapabilities,
    has(capability) {
      return resolved.resolvedCapabilities.includes(capability);
    },
    leafMetadataStorage
  };
}
function finalizeLeafSignal(leaf2, path, positionIds, buildPlan, captureRuntime, registry, address) {
  defineNodeAddress(leaf2, address);
  for (const position of positionIds ?? [])
    registry?.registerPositionAddress(position, address);
  if (buildPlan.has("position-topology") && registry) {
    definePositionRegistry(leaf2, registry);
  }
  if (buildPlan.has("mutation-capture")) {
    wrapOwnedWritableSignal(leaf2, {
      path,
      // `ownerPath: path` sat here until 15.0 (ME-B). The owner-address fact is
      // still installed on the leaf — it is now derived from `path` inside
      // owned-mutation rather than passed as a second, identical argument.
      positionIds,
      ownerId: registry?.id,
      metadataStorage: buildPlan.leafMetadataStorage,
      captureRuntime
    });
    return;
  }
  if (buildPlan.has("position-topology")) {
    defineOwnedPositionIds(leaf2, positionIds);
    defineOwnedOwnerId(leaf2, registry?.id);
  }
  if (registry) {
    definePositionRegistry(leaf2, registry);
    defineOwnedOwnerPath(leaf2, path);
    installDormantObservation(leaf2);
  }
}
function getEnhancerMeta(enhancer) {
  return enhancer[ENHANCER_META] ?? enhancer.metadata;
}
function buildTreePlan(enhancers, explicitCapabilities = []) {
  const requestedCapabilities = collectRequestedTreeCapabilities([
    ...enhancers.map((enhancer) => getEnhancerMeta(enhancer)),
    // An explicit request is treated as one more declaration, so it goes
    // through the same dependency resolution rather than bypassing it.
    { capabilities: [...explicitCapabilities] }
  ]);
  return createTreeBuildPlan(requestedCapabilities, "property");
}
function materializeTreeMarkers(tree, materializationContext, authority) {
  materializeMarkers(tree.$, void 0, [], materializationContext, authority);
  _recordTreeConstruction();
}
function isEntityMapMarker(value) {
  return Boolean(
    value && typeof value === "object" && value["__isEntityMap"] === true
  );
}
function createEqualityFn(useShallowComparison) {
  return useShallowComparison ? Object.is : deepEqual;
}
function makeNodeAccessor(store, ownerPath, positionIds, registry, locations) {
  const isRoot = ownerPath === "";
  const self = {};
  const applyGrouped = (run2) => {
    if (locations) locations.runInvalidationGroup(run2);
    else run2();
  };
  const accessor = {
    node(arg) {
      if (arguments.length === 0) {
        if (!isRoot && self.accessor !== void 0 && isAbsentMember(self.accessor)) {
          observeMembership(store);
          return void 0;
        }
        return materializeNode(store);
      }
      const absent = !isRoot && isAbsentMember(self.accessor);
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = absent ? void 0 : unwrap(store);
        updates = updater(current);
      }
      applyGrouped(() => {
        recursiveUpdate(store, updates, void 0, "");
        if (absent && updates && typeof updates === "object")
          reactivatePathOnWrite(self.accessor);
      });
    }
  }.node;
  self.accessor = accessor;
  accessor[CALLABLE_SIGNAL_SYMBOL] = true;
  Object.defineProperty(accessor, NODE_STORE_SYMBOL, {
    value: store,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(store, NODE_ACCESSOR_PEER2, {
    value: accessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  for (const key of Object.keys(store)) {
    Object.defineProperty(accessor, key, {
      value: store[key],
      enumerable: true,
      writable: true,
      configurable: true
    });
  }
  const address = getNodeAddress(store);
  if (address) defineNodeAddress(accessor, address);
  if (positionIds && positionIds.length > 0) {
    defineOwnedPositionIds(accessor, positionIds);
  }
  if (ownerPath !== void 0) {
    defineOwnedOwnerPath(accessor, ownerPath);
  }
  if (registry) {
    definePositionRegistry(accessor, registry);
    defineOwnedOwnerId(accessor, registry.id);
    definePositionRegistry(store, registry);
    defineOwnedOwnerId(store, registry.id);
  }
  if (locations) {
    bindLocationRuntime(accessor, locations);
    bindLocationRuntime(store, locations);
  }
  return accessor;
}
var MARKER_IN_ARRAY_WARNED = /* @__PURE__ */ new Set();
var looksLikeMarker = (item) => item !== null && typeof item === "object" && (isEntityMapMarker(item) || isRegisteredMarker(item));
function warnMarkerInContainer(key, value) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (MARKER_IN_ARRAY_WARNED.has(key)) return;
  let where;
  let container;
  if (Array.isArray(value)) {
    const limit = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
    for (let i = 0; i < limit; i++) {
      if (looksLikeMarker(value[i])) {
        where = `"${key}[${i}]"`;
        container = "an array. Array elements";
        break;
      }
    }
  } else if (value instanceof Map) {
    let i = 0;
    for (const [k, v] of value) {
      if (i++ >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(v)) {
        where = `"${key}" -> Map value at key ${JSON.stringify(String(k))}`;
        container = "a Map. Map values";
        break;
      }
    }
  } else if (value instanceof Set) {
    let i = 0;
    for (const member of value) {
      if (i >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(member)) {
        where = `"${key}" -> Set member #${i}`;
        container = "a Set. Set members";
        break;
      }
      i++;
    }
  }
  if (where === void 0 || container === void 0) return;
  MARKER_IN_ARRAY_WARNED.add(key);
  console.warn(
    `SignalTree: ${where} holds a MARKER inside ${container} are never traversed, so the marker is never materialised \u2014 it stays a raw object, it is not a signal, and writes to it are lost. Markers belong at object positions; for a keyed collection use entityMap({ selectId }). [ST2021]`
  );
}
function warnEntityArrayLeaf(key, value) {
  if (typeof ngDevMode !== "undefined" && !ngDevMode) return;
  if (value.length < ENTITY_ARRAY_MIN_LENGTH) return;
  const first = value[0];
  if (first === null || typeof first !== "object" || Array.isArray(first)) {
    return;
  }
  const idKey = ENTITY_ID_KEYS.find((candidate) => {
    const v = first[candidate];
    return typeof v === "string" || typeof v === "number";
  });
  if (!idKey) return;
  const sampleSize = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
  const seen = /* @__PURE__ */ new Set();
  for (let i = 0; i < sampleSize; i++) {
    const item = value[i];
    if (item === null || typeof item !== "object" || Array.isArray(item)) {
      return;
    }
    const id = item[idKey];
    if (typeof id !== "string" && typeof id !== "number") return;
    if (seen.has(id)) return;
    seen.add(id);
  }
  const seenKey = `${key}:${idKey}`;
  if (ENTITY_ARRAY_WARNED.has(seenKey)) return;
  if (ENTITY_ARRAY_WARNED.size >= ENTITY_ARRAY_WARN_CAP) return;
  ENTITY_ARRAY_WARNED.add(seenKey);
  console.warn(
    `SignalTree: "${key}" holds ${value.length} objects with a stable "${idKey}" \u2014 use entityMap({ selectId: (e) => e.${idKey} }). An array leaf rebuilds and re-compares the whole array on every update \u2014 two orders of magnitude at 50k. Read-only or replaced wholesale? Leave it plain; otherwise model it as an entityMap. [ST2018]`
  );
}
function warnDiscardedBranchWrite(path, value) {
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    console.error(
      `SignalTree: write to "${path}" DISCARDED \u2014 a branch cannot be replaced by a non-object value (received ${value === null ? "null" : typeof value}). Write the leaves, or use a marker if this position should hold a value. [ST2014]`
    );
  }
}
function warnMissingForward(method) {
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    console.error(
      `SignalTree: "${method}" could not be forwarded \u2014 an enhancer in the configured set returned a tree without it, so this call did NOTHING. An enhancer that builds a new tree object must copy own property DESCRIPTORS, not Object.assign, which skips non-enumerable methods. [ST2017]`
    );
  }
}
var warnedNoopPaths = /* @__PURE__ */ new Set();
var warnedNoopCopyPaths = /* @__PURE__ */ new Set();
function isLargeEnoughToMatter(value) {
  if (Array.isArray(value)) return value.length >= 32;
  if (value instanceof Map || value instanceof Set) return value.size >= 32;
  return Object.keys(value).length >= 32;
}
setMemberValueApplier(
  (parent, key, member, value) => {
    if (typeof member === "function") {
      member(value);
    }
    const woke = setMemberPresence(parent, key, "active");
    if (woke) publishMembershipChange(parent);
  }
);
var ordinaryMemberBuilders = /* @__PURE__ */ new WeakMap();
function ordinaryConstructionValue(value, key) {
  if (isEntityMapMarker(value) || isRegisteredMarker(value)) {
    throw new TypeError("SignalTree: marker definitions belong in initial state, not ordinary whole-value writes.");
  }
  if (isLeafDefinition(value)) {
    const inner = leafDefinitionValue(value);
    if (isEntityMapMarker(inner) || isRegisteredMarker(inner)) {
      throw new TypeError("SignalTree: leaf() cannot wrap a semantic marker.");
    }
    return leaf(inner);
  }
  if (value === null || typeof value !== "object") return leaf(value);
  if (typeof ngDevMode === "undefined" || ngDevMode) {
    if (!Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
      console.warn(
        `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
      );
    }
  }
  if (Array.isArray(value) || isBuiltInObject(value)) {
    warnMarkerInContainer(key, value);
    if (Array.isArray(value)) warnEntityArrayLeaf(key, value);
    return leaf(value);
  }
  const prepared = {};
  for (const [childKey, child] of Object.entries(value)) {
    if (childKey !== "__proto__") prepared[childKey] = ordinaryConstructionValue(child, childKey);
  }
  return prepared;
}
function prepareOrdinaryMembers(target, updates, whole) {
  const plans = /* @__PURE__ */ new Map();
  const visit = (target2, updates2, whole2) => {
    if (!updates2 || typeof updates2 !== "object") return;
    const store = isNodeAccessor(target2) ? target2[NODE_STORE_SYMBOL] : target2;
    const entries = Object.entries(updates2);
    const additions = /* @__PURE__ */ new Map();
    plans.set(store, { entries, additions });
    const build = whole2 ? ordinaryMemberBuilders.get(store) : void 0;
    for (const [key, value] of entries) {
      if (key === "__proto__") continue;
      if (build && !Object.prototype.hasOwnProperty.call(store, key)) {
        const prepared = ordinaryConstructionValue(value, key);
        additions.set(key, () => build(key, prepared));
      } else if (isNodeAccessor(store[key]) && value && typeof value === "object") {
        visit(store[key], value, true);
      }
    }
  };
  visit(target, updates, whole);
  return plans;
}
function recursiveUpdate(target, updates, out, pathPrefix = "", reconcileMembership = true, since = ++structuralWrites.stamp, prepared = prepareOrdinaryMembers(target, updates, reconcileMembership)) {
  if (!updates || typeof updates !== "object") return;
  beginStructuralWrite();
  let publishMembership;
  let applicationFailed = false;
  let applicationError;
  try {
    const targetObj = isNodeAccessor(target) ? target[NODE_STORE_SYMBOL] : target;
    const plan = prepared.get(targetObj);
    if (!plan) return;
    const { entries, additions } = plan;
    const branch = targetObj[NODE_ACCESSOR_PEER2] ?? targetObj;
    const dormant = hasDormantMembers(targetObj);
    publishMembership = reconcileMembership || dormant ? captureBranchMembershipIfObserved(
      targetObj[NODE_ACCESSOR_PEER2] ?? targetObj,
      updates,
      !reconcileMembership
    ) : void 0;
    const installed = dormant ? /* @__PURE__ */ new Set() : void 0;
    for (const [key, rawValue] of entries) {
      let value = rawValue;
      if (key === "__proto__") continue;
      const buildAddition = additions.get(key);
      if (buildAddition && !Object.prototype.hasOwnProperty.call(targetObj, key)) {
        const { child, responsibility } = buildAddition();
        inheritObservationForAddedMember(branch, child);
        installPreparedMember(branch, key, child, responsibility);
        publishMembershipChange(branch);
        installed?.add(key);
        out?.push(pathPrefix ? `${pathPrefix}.${key}` : key);
        continue;
      }
      const prop = Object.getOwnPropertyDescriptor(targetObj, key)?.value;
      const childPath = pathPrefix ? `${pathPrefix}.${key}` : key;
      if (prop === void 0) {
        if (typeof ngDevMode === "undefined" || ngDevMode) {
          console.error(
            `SignalTree: write to "${childPath}" DISCARDED \u2014 key is not in the tree's initial shape. [ST2010]`
          );
        }
        continue;
      }
      const ownHydrate = structuralWrites.own;
      structuralWrites.own = prop;
      let hydrated;
      try {
        hydrated = hydrateMarkerNode(prop, value, "restore");
      } finally {
        structuralWrites.own = ownHydrate;
      }
      if (hydrated) {
        if (out) out.push(childPath);
        installed?.add(key);
        continue;
      }
      if (isNodeAccessor(prop)) {
        if (typeof value === "function") {
          const updater = value;
          value = updater(isAbsentMember(prop) ? void 0 : unwrap(prop));
          const mergeable = isTraversableNode(value) && typeof value !== "function" && !isBuiltInObject(value) && !Array.isArray(value) && typeof value.then !== "function";
          if (!mergeable) {
            warnDiscardedBranchWrite(childPath, value);
            continue;
          }
        }
        if (typeof value === "function") {
          warnDiscardedBranchWrite(childPath, value);
        } else if (value && typeof value === "object") {
          recursiveUpdate(
            prop,
            value,
            out,
            childPath,
            true,
            since,
            prepared.has(
              prop[NODE_STORE_SYMBOL]
            ) ? prepared : prepareOrdinaryMembers(prop, value, true)
          );
          installed?.add(key);
        } else if (value === void 0) {
          continue;
        } else {
          warnDiscardedBranchWrite(childPath, value);
        }
      } else if (isWritableLocation(prop) || isWritableCell(prop)) {
        const sig = prop;
        const current = readWritableCell(sig);
        if (current === value && !isAbsentMember(sig)) {
          if ((typeof ngDevMode === "undefined" || ngDevMode) && value !== null && typeof value === "object" && !warnedNoopPaths.has(childPath)) {
            warnedNoopPaths.add(childPath);
            console.warn(
              `SignalTree: write at "${childPath}" was skipped \u2014 the value is reference-identical to the current value. If you mutated an object/array in place, create a NEW reference (spread/slice/map) so the change is observed. [ST2003]`
            );
          }
          continue;
        }
        const wasAbsent = out !== void 0 && isAbsentMember(sig);
        const ownWrite = structuralWrites.own;
        structuralWrites.own = sig;
        try {
          if (isWritableLocation(sig)) replaceLocation(sig, value);
          else sig.set(value);
        } finally {
          structuralWrites.own = ownWrite;
        }
        installed?.add(key);
        if (out) {
          if (wasAbsent || !Object.is(readWritableCell(sig), current))
            out.push(childPath);
        }
      }
    }
    const membershipChanged = [];
    const supplied = reconcileMembership || installed ? new Set(Object.keys(updates)) : void 0;
    if (supplied)
      for (const key of reconcileMembership ? Object.getOwnPropertyNames(targetObj) : supplied) {
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("membershipKeysVisited");
        }
        const descriptor = Object.getOwnPropertyDescriptor(targetObj, key);
        if (!descriptor || !("value" in descriptor)) continue;
        if (!supplied.has(key)) {
          if (descriptor.enumerable && // A write made while this whole value ran re-added it: it stays.
          !readdedDuringStructuralWrite(targetObj, key, since) && setMemberPresence(targetObj, key, "dormant")) {
            membershipChanged.push(key);
          }
        } else if (
          // Only a member whose supplied value was installed is re-added: a key
          // supplied as `undefined`, or with a value the loop discarded, would
          // otherwise come back with its retained storage. Measured before v16 8d:
          // `$({ a: undefined, count: 0 })` re-added an omitted `a` as `{ v: 1 }`.
          // "DORMANT STORAGE MUST NOT SUPPLY THE REACTIVATED VALUE" (case 18).
          !descriptor.enumerable && installed?.has(key) && setMemberPresence(targetObj, key, "active")
        ) {
          membershipChanged.push(key);
        }
      }
    if (membershipChanged.length > 0) {
      republishMembers(targetObj, membershipChanged);
    }
  } catch (error) {
    applicationFailed = true;
    applicationError = error;
  } finally {
    try {
      try {
        publishMembership?.();
      } catch (error) {
        if (!applicationFailed) {
          applicationFailed = true;
          applicationError = error;
        } else {
          reportContainedObserverError({ error, operation: "notify:subscriber" });
        }
      }
    } finally {
      endStructuralWrite();
    }
  }
  if (applicationFailed) throw applicationError;
}
function leafEqual(base, path) {
  return (a, b) => {
    const eq = base(a, b);
    if (eq && a !== b && a !== null && typeof a === "object" && isLargeEnoughToMatter(a) && !warnedNoopCopyPaths.has(path)) {
      warnedNoopCopyPaths.add(path);
      console.warn(
        `SignalTree: a write to "${path || "(root leaf)"}" changed NOTHING \u2014 the new value is a different object but deep-equals the current one, so the whole structure was compared and the write discarded. A re-fetched payload does this. Skip the write when the data is unchanged, or write the smaller changed leaf. [ST2027]`
      );
    }
    return eq;
  };
}
function materializeOrdinaryBranch(value, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, childPositionIds, childPath, address, preparedOrdinary = false) {
  const nested = createSignalStore(
    value,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    childPositionIds,
    childPath,
    address,
    preparedOrdinary
  );
  const accessor = makeNodeAccessor(
    nested,
    childPath,
    childPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(accessor, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(nested, scalarSlotRuntime);
  }
  return accessor;
}
function createSignalStore(obj, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, positionIds, path = "", address = [], preparedOrdinary = false) {
  for (const position of positionIds ?? []) {
    materializationContext.positionRegistry.registerPositionAddress(
      position,
      address
    );
  }
  const createLeafSignal = (value, leafPositionIds, equal) => {
    if (scalarSlotRuntime) {
      return scalarSlotRuntime.createLeaf(
        value,
        equal,
        leafPositionIds?.[0]
      );
    }
    return materializationContext.locationRuntime.createCell(value, equal);
  };
  if (obj === null || obj === void 0 || typeof obj !== "object") {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (Array.isArray(obj)) {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (isBuiltInObject(obj)) {
    const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  const store = {};
  defineNodeAddress(store, address);
  ordinaryMemberBuilders.set(store, (key, value) => {
    const prepared = createSignalStore(
      { [key]: value },
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      positionIds,
      path,
      address,
      true
    );
    const child = prepared[key];
    const branch = store[NODE_ACCESSOR_PEER2] ?? store;
    return { child, responsibility: captureRuntime.prepareMemberResponsibility?.(branch, key, child) };
  });
  for (const [key, definedValue] of Object.entries(
    obj
  )) {
    const childAddress = childAddressOf(address, key);
    const childPath = path ? `${path}.${key}` : key;
    const terminal = isLeafDefinition(definedValue);
    const value = terminal ? leafDefinitionValue(definedValue) : definedValue;
    if (!preparedOrdinary && terminal && (isEntityMapMarker(value) || isRegisteredMarker(value))) {
      throw new Error(
        `SignalTree: leaf() cannot wrap a semantic marker at "${childPath}".`
      );
    }
    let childPositionIds;
    const getChildPositionIds = () => {
      if (!materializationContext.positionTopologyEnabled) {
        return void 0;
      }
      return childPositionIds ??= [
        materializationContext.allocatePositionId(positionIds?.[0])
      ];
    };
    if (key === "__proto__") {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        console.error(
          `SignalTree: dropped a "__proto__" key from the initial state \u2014 it cannot be a state key. If this came from JSON.parse, the payload is attempting prototype pollution. [ST2016]`
        );
      }
      continue;
    }
    if (!preparedOrdinary && isEntityMapMarker(value)) {
      store[key] = value;
      continue;
    }
    if (!preparedOrdinary && isRegisteredMarker(value)) {
      store[key] = value;
      continue;
    }
    if (typeof ngDevMode === "undefined" || ngDevMode) {
      if (!preparedOrdinary && !terminal && value !== null && typeof value === "object" && !Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
        console.warn(
          `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
        );
      }
    }
    if (terminal || value === null || value === void 0 || typeof value !== "object") {
      const childPositionIds2 = getChildPositionIds();
      const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    if (Array.isArray(value) || isBuiltInObject(value)) {
      warnMarkerInContainer(key, value);
      if (Array.isArray(value)) {
        warnEntityArrayLeaf(key, value);
      }
      const childPositionIds2 = getChildPositionIds();
      const equal = typeof ngDevMode === "undefined" || ngDevMode ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    store[key] = materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      getChildPositionIds(),
      childPath,
      childAddress,
      preparedOrdinary
    );
  }
  markTreeStore(store);
  return store;
}
function create(initialState, config, materializationContext, buildPlan, captureRuntime = createMutationCaptureRuntime(), createScalarLeafRuntime = createTreeScalarLeafRuntime) {
  if (initialState === null || initialState === void 0) {
    throw new Error(SIGNAL_TREE_MESSAGES.NULL_OR_UNDEFINED);
  }
  const equalityFn = createEqualityFn(config.useShallowComparison ?? false);
  const scalarSlotRuntime = createScalarLeafRuntime(
    materializationContext.physicalCommitClock,
    materializationContext.locationRuntime
  );
  const materializeOrdinaryState = (value, path, parentPositionId, address) => {
    const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(parentPositionId)] : void 0;
    return materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      childPositionIds,
      path,
      address
    );
  };
  const constructionAuthority = {
    materialize: materializeOrdinaryState,
    bindMember: (ownerBranch) => {
      const ownerPositionId = getOwnedPositionIds(ownerBranch)?.[0];
      const ownerPath = getOwnedOwnerPath(ownerBranch) ?? "";
      const ownerAddress = getNodeAddress(ownerBranch);
      if (!ownerAddress)
        throw new Error("Missing dynamic branch construction address.");
      return (key, value) => {
        const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(ownerPositionId)] : void 0;
        const childPath = ownerPath ? `${ownerPath}.${key}` : key;
        return materializeOrdinaryBranch(
          value,
          equalityFn,
          materializationContext,
          buildPlan,
          captureRuntime,
          scalarSlotRuntime,
          childPositionIds,
          childPath,
          childAddressOf(ownerAddress, key)
        );
      };
    }
  };
  const rootPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId()] : void 0;
  const signalState = createSignalStore(
    initialState,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    rootPositionIds
  );
  const rootAccessor = makeNodeAccessor(
    signalState,
    "",
    rootPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  const tree = {};
  defineNodeAddress(tree, []);
  bindLocationRuntime(tree, materializationContext.locationRuntime);
  bindLocationRuntime(
    signalState,
    materializationContext.locationRuntime
  );
  bindLocationRuntime(
    rootAccessor,
    materializationContext.locationRuntime
  );
  tree[MUTATION_CAPTURE_RUNTIME] = captureRuntime;
  if (rootPositionIds) {
    defineOwnedPositionIds(tree, rootPositionIds);
    defineOwnedPositionIds(signalState, rootPositionIds);
    defineOwnedPositionIds(rootAccessor, rootPositionIds);
  }
  defineTreeCapabilities(tree, buildPlan.capabilities);
  if (buildPlan.has("mutation-capture")) {
    defineOwnedOwnerPath(tree, "");
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  if (materializationContext.positionTopologyEnabled) {
    definePositionRegistry(
      tree,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      rootAccessor,
      materializationContext.positionRegistry
    );
  }
  if (materializationContext.positionRegistry) {
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  defineRootTree(rootAccessor, {
    read: () => rootAccessor(),
    replace: (value) => rootAccessor(value),
    derive: (update) => rootAccessor(update)
  });
  if (materializationContext.physicalCommitClock) {
    definePhysicalCommitClock(
      tree,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      signalState,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      rootAccessor,
      materializationContext.physicalCommitClock
    );
  }
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(tree, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(signalState, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(rootAccessor, scalarSlotRuntime);
  }
  const cleanupFns = [];
  const destroyedSig = materializationContext.locationRuntime.createCell(false);
  Object.defineProperty(tree, "$", {
    value: rootAccessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "destroy", {
    value: function() {
      if (destroyedSig()) return;
      try {
        replaceLocation(destroyedSig, true);
      } finally {
        terminateOwnerInvalidation(tree);
        for (const fn of cleanupFns) {
          try {
            fn();
          } catch {
          }
        }
        cleanupFns.length = 0;
        releaseContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
      if (config.debugMode) {
        console.log(SIGNAL_TREE_MESSAGES.TREE_DESTROYED);
      }
    },
    enumerable: false,
    // Allow enhancers (like guardrails) to override/replace `destroy` at runtime.
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree, "destroyed", {
    value: destroyedSig.asReadonly(),
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "registerCleanup", {
    value: function(fn) {
      if (typeof fn === "function") {
        cleanupFns.push(fn);
      }
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree, "clearCache", {
    value: () => {
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree, "updateAndReport", {
    value: function(arg) {
      if (arguments.length === 0) return [];
      const out = [];
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = unwrap(signalState);
        updates = updater(current);
      }
      materializationContext.locationRuntime.runInvalidationGroup(() => {
        recursiveUpdate(signalState, updates, out, "", false);
      });
      return out;
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  return {
    tree,
    authority: constructionAuthority,
    activateReporting() {
      if (!readWritableCell(destroyedSig)) {
        registerContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
    }
  };
}
function applyEnhancers(tree, ordered) {
  let current = tree;
  for (const enhancer of ordered) {
    if (typeof enhancer !== "function") {
      throw new Error("Enhancer must be a function");
    }
    const result = enhancer(
      current
    );
    if (result !== current && isTraversableNode(result)) {
      current = result;
    }
  }
  return current;
}
function signalTreeImpl(initialState, config = {}, observation = NEUTRAL_OBSERVATION_ADAPTER, createScalarLeafRuntime = createTreeScalarLeafRuntime, createLocations = createLocationRuntime) {
  const declared = config.enhancers ?? [];
  const ordered = resolveEnhancerOrder(
    [...declared],
    /* @__PURE__ */ new Set(),
    Boolean(config.debugMode)
  );
  const buildPlan = buildTreePlan(ordered, config.capabilities);
  const physicalCommitClock = buildPlan.has("causal-runtime") ? createPhysicalCommitClock() : void 0;
  const captureRuntime = createMutationCaptureRuntime();
  const materializationContext = createMaterializationContext(
    buildPlan.has("position-topology"),
    (capability) => buildPlan.has(capability),
    physicalCommitClock,
    createLocations(observation)
  );
  materializationContext.mutationCaptureRuntime = captureRuntime;
  const constructed = create(
    initialState,
    config,
    materializationContext,
    buildPlan,
    captureRuntime,
    createScalarLeafRuntime
  );
  let tree = constructed.tree;
  const authority = constructed.authority;
  const hasEnhancers = ordered.length > 0;
  if (hasEnhancers) {
    materializeTreeMarkers(tree, materializationContext, authority);
    Object.defineProperty(
      tree.$,
      Symbol.for("SignalTree:SubjectPhysicalOwners"),
      {
        value: materializationContext.physicalOwners,
        enumerable: false,
        configurable: true
      }
    );
    tree = applyEnhancers(tree, ordered);
  }
  const configured = createConfiguredTree(
    tree,
    materializationContext,
    hasEnhancers,
    authority,
    config.derived
  );
  constructed.activateReporting();
  return configured;
}
function createConfiguredTree(baseTree, materializationContext, alreadyMaterialized = false, authority, derivedFactory) {
  let isFinalized = false;
  let markersMaterialized = alreadyMaterialized;
  const materializeOnly = () => {
    if (markersMaterialized) return;
    markersMaterialized = true;
    materializeMarkers(
      baseTree.$,
      void 0,
      [],
      materializationContext,
      authority
    );
    _recordTreeConstruction();
  };
  const finalize = () => {
    if (isFinalized) return;
    isFinalized = true;
    materializeOnly();
    if (derivedFactory) {
      applyDerivedFactory(
        baseTree.$,
        derivedFactory,
        materializationContext.locationRuntime
      );
    }
  };
  const rootAccessor = baseTree.$;
  Object.defineProperty(baseTree, "$", {
    get() {
      finalize();
      Object.defineProperty(baseTree, "$", {
        value: rootAccessor,
        enumerable: false,
        configurable: true
      });
      return rootAccessor;
    },
    enumerable: false,
    configurable: true
  });
  const updateAndReport = baseTree.updateAndReport?.bind(baseTree);
  Object.defineProperty(baseTree, "updateAndReport", {
    value: function(arg) {
      finalize();
      if (!updateAndReport) {
        warnMissingForward("updateAndReport");
        return [];
      }
      return updateAndReport(arg);
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  return baseTree;
}
var signalTree = signalTreeImpl;

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/restoration-eligibility.ts
function isMetaDesignated(meta) {
  return meta?.restorationDesignated === true;
}
function markMetaDesignated(meta) {
  const stamped = { restorationDesignated: true };
  if (meta) {
    for (const key of Reflect.ownKeys(meta)) {
      if (!Object.prototype.propertyIsEnumerable.call(meta, key)) continue;
      const value = Reflect.get(meta, key);
      if (value !== void 0) Reflect.set(stamped, key, value);
    }
  }
  return stamped;
}
var designated = false;
function isRestorationDesignated() {
  return designated;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/external.ts
function external(operation) {
  const ambient = getActiveWriteContext();
  const meta = { intent: "system" };
  if (ambient) {
    for (const [key, value] of Object.entries(ambient)) {
      if (value !== void 0) {
        meta[key] = value;
      }
    }
  }
  meta.origin = "external";
  meta.participation = "realized";
  const result = withWriteContext(meta, operation);
  if (typeof result?.then === "function") {
    throw new Error(
      "ST1035: an external-truth application must be synchronous. The classification is restored before the scope returns, so writes after an `await` inside it would be applied as authored work \u2014 the server value would become an undo step. Acquire first, then classify the synchronous write: `const rows = await api.getRows(); external(() => tree.$.rows.setAll(rows));`"
    );
  }
  return result;
}

// ../../../../private/tmp/link-responsibility-path/private.ts
var stamp = Symbol("research revision");
var sources = /* @__PURE__ */ new Map();
var outcomes = /* @__PURE__ */ new Map();
var listeners2 = /* @__PURE__ */ new Map();
var queued = /* @__PURE__ */ new Set();
var latest = /* @__PURE__ */ new Map();
var records = /* @__PURE__ */ new Map();
var completed = /* @__PURE__ */ new Map();
var visitedSources = 0;
var visitedOwners = 0;
var serial = 0;
var ingress;
var receipts = [];
var enabled = true;
function mode(v) {
  enabled = v;
}
function register(owner, source, token) {
  sources.set(owner, { source, token });
}
function transition(owner, fact) {
  if (owner === void 0) return;
  receipts.push({ event: "lifecycle", owner, ...fact });
  if (!["confirmed", "rolled-back", "abandoned"].includes(fact.kind)) return;
  let map = outcomes.get(owner);
  if (!map) outcomes.set(owner, map = /* @__PURE__ */ new Map());
  const old = map.get(fact.transactionId);
  if (old && old !== fact.kind) throw Error("terminal outcome reversed");
  map.set(fact.transactionId, fact.kind);
  if (!queued.has(owner)) {
    queued.add(owner);
    queueMicrotask(() => {
      queued.delete(owner);
      for (const set of [...listeners2.values()]) for (const cb of [...set]) cb();
    });
  }
}
function onEligibility(owner, cb) {
  let set = listeners2.get(owner);
  if (!set) listeners2.set(owner, set = /* @__PURE__ */ new Set());
  set.add(cb);
  return () => {
    set.delete(cb);
    if (!set.size) listeners2.delete(owner);
  };
}
function acquire(owner, position, work) {
  const prev = ingress;
  ingress = { owner, position, consumed: false };
  try {
    work();
  } finally {
    ingress = prev;
  }
}
function annotate(meta, owner, positions, authored, payload) {
  const key = owner !== void 0 && positions?.[0] !== void 0 ? `${owner}:${positions[0]}` : void 0;
  if (key) latest.delete(key);
  const clean = !!ingress && !ingress.consumed && owner === ingress.owner && positions?.[0] === ingress.position;
  if (clean && ingress) ingress.consumed = true;
  const entry = owner === void 0 ? void 0 : sources.get(owner);
  const captured = [];
  for (const [tree, { source }] of sources) {
    visitedSources++;
    for (const p of source.read().pending) {
      visitedOwners++;
      captured.push(Object.freeze({ owner: tree, id: p.transactionId }));
    }
  }
  const blockers = Object.freeze(captured);
  const attributed = meta?.transactionId;
  const attributionValid = attributed === void 0 || typeof attributed === "number" && !!entry && meta?.transactionOwner === entry.token && blockers.some((b) => b.owner === owner && b.id === attributed);
  const unknown = !clean && (!authored || meta?.origin !== void 0 || !entry || !attributionValid);
  const fact = Object.freeze({ revision: ++serial, clean, blockers, unknown });
  if (key) latest.set(key, fact);
  records.set(fact, Object.freeze({ fact, payload }));
  receipts.push({ event: "revision", owner, position: positions?.[0], ...fact, origin: meta?.origin, participation: meta?.participation, attributed });
  return { ...meta, [stamp]: fact };
}
function complete(meta, owner, positions) {
  const fact = evidence(meta);
  const receipt = fact && records.get(fact);
  if (owner !== void 0 && positions?.[0] !== void 0 && receipt) completed.set(`${owner}:${positions[0]}`, receipt);
}
function refresh(owner, position) {
  const r = completed.get(`${owner}:${position}`);
  return r && latest.get(`${owner}:${position}`) === r.fact ? r : void 0;
}
function evidence(meta) {
  return meta?.[stamp];
}
function allowed(fact, owner, position) {
  return !enabled || !!fact && latest.get(`${owner}:${position}`) === fact && (fact.clean || !fact.unknown && fact.blockers.every((b) => outcomes.get(b.owner)?.get(b.id) === "confirmed"));
}
function admit(original, fact, owner, position, r) {
  if (!enabled) {
    original(r);
    return true;
  }
  if (allowed(fact, owner, position)) {
    r.run();
    return true;
  }
  return false;
}
function dispose(_a, _b) {
}
function diagnostics() {
  return { sources: sources.size, outcomeTrees: outcomes.size, latest: latest.size, listeners: listeners2.size, records: records.size, completed: completed.size, visitedSources, visitedOwners };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/plain-branch-membership.ts
var MEMBERSHIP = Symbol("SignalTree:PlainBranchMembership");
function plainBranchMembershipChange(meta) {
  return meta?.[MEMBERSHIP];
}
function isCollectionMember(node) {
  if (!isTraversableNode(node)) return false;
  const binding = node.__prepareTransitionTarget;
  return binding !== void 0 && binding.owner === getOwnedPositionIds(node)?.[0];
}
function isRecordedMember(node) {
  return isNodeAccessor(node) || isWritableLocation(node) || isCollectionMember(node);
}
function capturePlainBranchMembership(branch, supplied, partial) {
  if (!hasPathObservers()) return void 0;
  const registry = getPositionRegistry(branch);
  const path = getOwnedOwnerPath(branch);
  if (!registry || path === void 0) return void 0;
  const storage = nodeStoreOf(branch) ?? branch;
  const keys = new Set(
    partial ? [...Object.keys(branch), ...Object.keys(supplied)] : Object.keys(supplied)
  );
  const before = /* @__PURE__ */ new Map();
  for (const key of Object.keys(supplied)) {
    if (key !== "__proto__" && !Object.prototype.hasOwnProperty.call(storage, key)) {
      before.set(key, { present: false });
    }
  }
  storedReads.depth++;
  try {
    for (const key of Object.getOwnPropertyNames(storage)) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("membershipKeysVisited");
      }
      const descriptor = Object.getOwnPropertyDescriptor(storage, key);
      if (!descriptor || !("value" in descriptor)) continue;
      const present = descriptor.enumerable === true;
      if (present === keys.has(key)) continue;
      if (!present && typeof descriptor.value !== "function" && !isCollectionMember(descriptor.value))
        continue;
      before.set(
        key,
        present ? {
          present: true,
          value: unwrapBranchForWriteCapture(descriptor.value)
        } : { present: false }
      );
    }
  } finally {
    storedReads.depth--;
  }
  if (before.size === 0) return void 0;
  const meta = getActiveWriteContext();
  return () => {
    const members = [];
    for (const [key, previous] of before) {
      const descriptor = Object.getOwnPropertyDescriptor(branch, key);
      const present = descriptor?.enumerable === true;
      if (present === previous.present) continue;
      if (previous.present) rememberHiddenRows(descriptor?.value);
      members.push({
        key,
        positionIds: getOwnedPositionIds(descriptor?.value),
        before: previous,
        after: present ? {
          present: true,
          value: unwrapBranchForWriteCapture(descriptor?.value)
        } : { present: false }
      });
    }
    if (members.length === 0) return;
    const notification = {
      ...meta,
      [MEMBERSHIP]: { kind: "plain-branch-membership", branch, members }
    };
    pathObservation().notify(
      path,
      void 0,
      void 0,
      path,
      void 0,
      getOwnedPositionIds(branch),
      notification,
      registry.id
    );
  };
}
function capturePathReAdd(path, outer) {
  if (!hasPathObservers()) return void 0;
  const publishers = [];
  for (let i = 0; i <= outer; i++) {
    const { parent, key } = path[i];
    publishers.push(
      capturePlainBranchMembership(parent, { [key]: true }, i === outer)
    );
  }
  return () => {
    for (const publish of publishers) publish?.();
  };
}
function applyPlainBranchMembership(previous, segments, change) {
  const apply = (value, depth) => {
    if (value === null || typeof value !== "object") return value;
    const current = value;
    const result = { ...current };
    if (depth < segments.length) {
      const key = segments[depth];
      if (!Object.prototype.hasOwnProperty.call(current, key)) return value;
      Object.defineProperty(result, key, {
        value: apply(current[key], depth + 1),
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      for (const member of change.members) {
        if (!member.after.present) {
          delete result[member.key];
        } else {
          Object.defineProperty(result, member.key, {
            value: member.after.value,
            enumerable: true,
            configurable: true,
            writable: true
          });
        }
      }
    }
    return result;
  };
  return apply(previous, 0);
}
var MEMBER_ADDRESSES = /* @__PURE__ */ new WeakMap();
function prepareNewMemberResponsibility(branch, key, node) {
  const registry = getPositionRegistry(branch);
  const position = getOwnedPositionIds(node)?.[0];
  const path = getOwnedOwnerPath(node);
  if (!registry || position === void 0 || path === void 0) return void 0;
  let addresses = MEMBER_ADDRESSES.get(registry);
  if (!addresses) {
    addresses = /* @__PURE__ */ new Map();
    MEMBER_ADDRESSES.set(registry, addresses);
  }
  const effect = {
    kind: "set",
    position,
    path,
    ownerPath: path,
    before: void 0,
    after: unwrapBranchForWriteCapture(node),
    plainBranchMembership: { before: false, after: true },
    mutationIntent: "replace"
  };
  return { effect, address: { map: addresses, key: position, value: { branch, key, node } } };
}
function plainBranchMembershipEffects(meta) {
  const change = plainBranchMembershipChange(meta);
  if (!change) return void 0;
  const registry = getPositionRegistry(change.branch);
  if (!registry) return [];
  let addresses = MEMBER_ADDRESSES.get(registry);
  if (!addresses) {
    addresses = /* @__PURE__ */ new Map();
    MEMBER_ADDRESSES.set(registry, addresses);
  }
  return change.members.flatMap((member) => {
    const position = member.positionIds?.[0];
    if (position === void 0) return [];
    const node = Object.getOwnPropertyDescriptor(
      change.branch,
      member.key
    )?.value;
    const path = getOwnedOwnerPath(node);
    if (path === void 0 || !isRecordedMember(node)) return [];
    addresses.set(position, { branch: change.branch, key: member.key, node });
    return [
      {
        kind: "set",
        position,
        path,
        ownerPath: path,
        before: member.before.present ? member.before.value : void 0,
        after: member.after.present ? member.after.value : void 0,
        plainBranchMembership: {
          before: member.before.present,
          after: member.after.present
        },
        mutationIntent: "replace"
      }
    ];
  });
}
function composePlainBranchMemberEffect(existing, incoming) {
  if (!existing.plainBranchMembership && !incoming.plainBranchMembership)
    return false;
  const before = existing.plainBranchMembership?.before ?? incoming.plainBranchMembership?.before ?? true;
  if (!existing.plainBranchMembership && incoming.plainBranchMembership?.before === false) {
    existing.before = incoming.before;
  }
  existing.after = incoming.after;
  existing.plainBranchMembership = {
    before,
    after: incoming.plainBranchMembership?.after ?? true
  };
  return true;
}
function plainBranchMemberEffectIsNoop(effect) {
  const before = effect.plainBranchMembership?.before ?? true;
  const after = effect.plainBranchMembership?.after ?? true;
  return before === after && (!before || effect.before === effect.after);
}
function settleTurnMemberEffects(root, turnEffects) {
  const effects = turnEffects;
  const registry = getPositionRegistry(root);
  const addresses = /* @__PURE__ */ new Map();
  const addressOf = (position) => {
    if (!addresses.has(position))
      addresses.set(position, registry?.addressFor(position));
    return addresses.get(position);
  };
  const relative = (outer, position) => {
    const address = addressOf(position);
    if (!address || address.length <= outer.length) return void 0;
    for (let i = 0; i < outer.length; i++)
      if (address[i] !== outer[i]) return void 0;
    return address.slice(outer.length);
  };
  const members = effects.some(
    (effect) => effect.kind === "set" && effect.plainBranchMembership
  );
  if (members && registry)
    effects.forEach((member, index) => {
      if (member.kind !== "set" || !member.plainBranchMembership) return;
      const at = addressOf(member.position);
      if (!at) return;
      if (member.plainBranchMembership.before && isPlainImage(member.before)) {
        let image;
        for (let j = 0; j < index; j++) {
          const earlier = effects[j];
          if (earlier.kind !== "set" || earlier.subject !== void 0) continue;
          const below = relative(at, earlier.position);
          if (!below) continue;
          image ??= cloneImage(member.before);
          placeInImage(
            image,
            below,
            earlier.plainBranchMembership?.before ?? true,
            earlier.before
          );
        }
        if (image) member.before = image;
      }
    });
  if (members)
    for (const member of effects) {
      if (member.kind !== "set" || !member.plainBranchMembership?.after)
        continue;
      const address = memberAddress(root, member.position);
      if (!address || !Object.getOwnPropertyDescriptor(address.branch, address.key)?.enumerable)
        continue;
      storedReads.depth++;
      try {
        member.after = unwrapBranchForWriteCapture(address.node);
      } finally {
        storedReads.depth--;
      }
    }
  const noop3 = (effect) => effect.kind === "set" && plainBranchMemberEffectIsNoop(effect) && (effect.fieldPresence?.before ?? true) === (effect.fieldPresence?.after ?? true);
  const kept = effects.filter(
    (effect) => !noop3(effect) || effect.plainBranchMembership?.before === false && registry !== void 0
  );
  return kept.filter((effect) => {
    if (!noop3(effect)) return true;
    const at = addressOf(effect.position);
    return !!at && kept.some(
      (other) => other !== effect && relative(at, other.position) !== void 0
    );
  });
}
function isPlainImage(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}
function cloneImage(value) {
  if (!isPlainImage(value)) return value;
  const copy = {};
  for (const key of Object.keys(value)) copy[key] = cloneImage(value[key]);
  return copy;
}
function placeInImage(image, path, present, value) {
  let level = image;
  for (let i = 0; i < path.length - 1; i++) {
    const next = level[path[i]];
    if (!isPlainImage(next)) return;
    level = next;
  }
  const key = path[path.length - 1];
  if (present) level[key] = cloneImage(value);
  else delete level[key];
}
function memberAddress(root, position) {
  const registry = getPositionRegistry(root);
  if (!registry) return void 0;
  const address = MEMBER_ADDRESSES.get(registry)?.get(position);
  if (!address || getPositionRegistry(address.branch) !== registry)
    return void 0;
  const descriptor = Object.getOwnPropertyDescriptor(
    address.branch,
    address.key
  );
  return descriptor?.value === address.node && descriptor.configurable === true && getOwnedPositionIds(address.node)?.[0] === position && isRecordedMember(address.node) ? address : void 0;
}
var OMITTED_ROWS = /* @__PURE__ */ new WeakMap();
function collectionRows(node) {
  const binding = node.__prepareTransitionTarget;
  return binding?.readSource().subjects.map(
    ({ subject, key, value }) => [subject, key, value]
  ) ?? [];
}
function rememberOmittedRows(node) {
  OMITTED_ROWS.set(node, collectionRows(node));
}
function collectionsWithin(member, visit) {
  if (isCollectionMember(member)) {
    visit(member);
    return;
  }
  if (!isNodeAccessor(member)) return;
  for (const key of Object.keys(member)) {
    const child = member[key];
    if (isCollectionMember(child) || isNodeAccessor(child))
      collectionsWithin(child, visit);
  }
}
function rememberHiddenRows(member) {
  collectionsWithin(member, rememberOmittedRows);
}
function omittedRowsChanged(node, touched, reordered) {
  const expected = OMITTED_ROWS.get(node);
  if (!expected) return false;
  const untouched = (rows) => {
    const kept = rows.filter(([subject]) => !touched.has(subject));
    return reordered ? [...kept].sort(([a], [b]) => String(a) < String(b) ? -1 : 1) : kept;
  };
  return !deepEqual(untouched(collectionRows(node)), untouched(expected));
}
function changedOmittedCollection(root, position, touched, reordered) {
  const address = memberAddress(root, position);
  if (!address || Object.getOwnPropertyDescriptor(address.branch, address.key)?.enumerable)
    return void 0;
  let changed;
  collectionsWithin(address.node, (node) => {
    const owner = getOwnedPositionIds(node)?.[0];
    if (changed === void 0 && omittedRowsChanged(node, touched(owner), reordered(owner)))
      changed = getOwnedOwnerPath(node) ?? String(owner);
  });
  return changed;
}
function refreshOmittedCollection(root, position) {
  if (!hidingMembers(root, position)?.length) return;
  const address = getPositionRegistry(root)?.addressFor(position);
  let node = root;
  for (const key of address ?? []) {
    if (!isTraversableNode(node)) return;
    node = Object.getOwnPropertyDescriptor(node, key)?.value;
  }
  if (isCollectionMember(node)) rememberOmittedRows(node);
}
function canRealizePlainBranchMember(root, position) {
  return memberAddress(root, position) !== void 0;
}
function hidingMembers(root, position) {
  const address = getPositionRegistry(root)?.addressFor(position);
  if (!address) return void 0;
  const hiding = [];
  let node = root;
  for (let i = 0; i < address.length; i++) {
    const descriptor = isTraversableNode(node) ? Object.getOwnPropertyDescriptor(node, address[i]) : void 0;
    if (!descriptor || !("value" in descriptor)) return void 0;
    node = descriptor.value;
    if (!descriptor.enumerable)
      hiding.push({
        position: getOwnedPositionIds(node)?.[0],
        path: getOwnedOwnerPath(node),
        node,
        below: address.slice(i + 1)
      });
  }
  return getOwnedPositionIds(node)?.includes(position) ? hiding : void 0;
}
function collectionBindingAt(root, position) {
  const address = getPositionRegistry(root)?.addressFor(position);
  if (!address) return void 0;
  let node = root;
  for (const key of address) {
    if (!isTraversableNode(node)) return void 0;
    node = Object.getOwnPropertyDescriptor(node, key)?.value;
  }
  const binding = node?.__prepareTransitionTarget;
  return binding?.owner === position ? binding : void 0;
}
function preparePlainBranchMembers(root, targets, scalarTargets) {
  const registry = getPositionRegistry(root);
  const runtime2 = getTreeScalarSlotRuntime(root);
  if (!registry || !runtime2)
    throw new Error("Plain branch target has no scalar runtime");
  const members = /* @__PURE__ */ new Map();
  const values = /* @__PURE__ */ new Map();
  const resolveSlot = (node) => {
    const position = getOwnedPositionIds(node)?.[0];
    const slot = position === void 0 ? void 0 : runtime2.resolveScalarSlot(position);
    if (position === void 0 || slot === void 0 || runtime2.resolveScalarLeaf(position) !== node)
      throw new Error("Plain branch target has no retained scalar slot");
    return { position, slot };
  };
  const stage = (address, present, value, turn) => {
    const { branch, key, node } = address;
    const descriptor = Object.getOwnPropertyDescriptor(branch, key);
    if (getPositionRegistry(branch) !== registry || descriptor?.value !== node || !descriptor.configurable)
      throw new Error("Plain branch target location is unavailable");
    const previous = members.get(node);
    members.set(node, {
      address,
      present,
      before: previous?.before ?? (descriptor.enumerable ? { present: true, value: unwrapBranchForWriteCapture(node) } : { present: false })
    });
    if (!present) return;
    if (isCollectionMember(node)) return;
    if (isWritableLocation(node)) {
      const { position, slot } = resolveSlot(node);
      values.set(slot, {
        node,
        position,
        before: values.get(slot)?.before ?? unwrapBranchForWriteCapture(node),
        after: value,
        turn
      });
      return;
    }
    if (!isNodeAccessor(node) || value === null || typeof value !== "object" || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
      throw new Error("Plain branch target requires a plain object");
    const supplied = new Set(Object.keys(value));
    for (const childKey of Object.getOwnPropertyNames(node)) {
      const child = Object.getOwnPropertyDescriptor(node, childKey)?.value;
      if (!isNodeAccessor(child) && !isWritableLocation(child)) {
        if (isTraversableNode(child)) supplied.delete(childKey);
        continue;
      }
      const childPresent = supplied.delete(childKey);
      const next = childPresent ? Object.getOwnPropertyDescriptor(value, childKey) : void 0;
      if (next && !("value" in next))
        throw new Error("Plain branch target cannot read an accessor");
      stage(
        { branch: node, key: childKey, node: child },
        childPresent,
        next?.value,
        turn
      );
    }
    if (supplied.size)
      throw new Error("Plain branch target contains an unavailable member");
  };
  for (const [position, target] of targets) {
    const address = memberAddress(root, position);
    if (!address)
      throw new Error("Plain branch member location is unavailable");
    stage(address, target.present, target.value, target.turn);
  }
  const staged = /* @__PURE__ */ new Map();
  for (const { position, turn } of values.values())
    if (turn !== void 0) staged.set(position, turn);
  for (const target of scalarTargets ?? []) {
    if (target.turn !== void 0 && (staged.get(target.owner) ?? target.turn) > target.turn)
      continue;
    const node = runtime2.resolveScalarLeaf(target.owner);
    if (!node) throw new Error("Plain branch scalar target is unavailable");
    const { slot, position } = resolveSlot(node);
    const previous = values.get(slot);
    values.set(slot, {
      node,
      position,
      before: previous ? previous.before : unwrapBranchForWriteCapture(node),
      after: target.after,
      turn: target.turn
    });
  }
  const frame = runtime2.beginFrame();
  for (const [slot, value] of values) frame.set(slot, value.after);
  const installFrame = scalarTargets === void 0 ? () => frame.commit({ advanceRevision: false, publish: false }) : frame.prepareCommit?.({ advanceRevision: false, publish: false });
  if (!installFrame)
    throw new Error("Plain branch scalar frame cannot be prepared");
  let result;
  let invalidated = false;
  let published = false;
  const changedSlots = /* @__PURE__ */ new Set();
  const changedBranches = /* @__PURE__ */ new Set();
  const changedBranchMembers = [];
  let changes = [];
  const captureChanges = () => {
    const byBranch = /* @__PURE__ */ new Map();
    for (const { address, present, before } of members.values()) {
      if (before.present === present) continue;
      let entries = byBranch.get(address.branch);
      if (!entries) byBranch.set(address.branch, entries = []);
      entries.push({
        key: address.key,
        positionIds: getOwnedPositionIds(address.node),
        before,
        after: present ? {
          present: true,
          value: unwrapBranchForWriteCapture(address.node)
        } : { present: false }
      });
    }
    changes = [...byBranch].map(([branch, members2]) => ({
      kind: "plain-branch-membership",
      branch,
      members: members2
    }));
  };
  const invalidate = () => {
    const installed = result;
    if (!installed)
      throw new Error("Plain branch target invalidated before installation");
    if (invalidated) return;
    invalidated = true;
    let failed = false;
    let firstError;
    const run2 = (fn) => {
      if (scalarTargets === void 0) {
        fn();
        return;
      }
      try {
        fn();
      } catch (error) {
        if (!failed) {
          failed = true;
          firstError = error;
        }
      }
    };
    withWriteContext(
      {
        ...getActiveWriteContext(),
        intent: "system",
        participation: "realized"
      },
      () => runtime2.runInvalidationGroup(() => {
        for (const branch of changedBranches)
          run2(() => publishMembershipChange(branch));
        for (const { branch, key, node } of changedBranchMembers) {
          run2(() => republishMembers(branch, [key]));
          run2(() => {
            if (!Object.getOwnPropertyDescriptor(branch, key)?.enumerable)
              rememberHiddenRows(node);
          });
        }
        run2(
          () => runtime2.publishPrepared({
            revision: installed.revision,
            changedSlots: [...changedSlots]
          })
        );
        if (failed) throw firstError;
      })
    );
  };
  return {
    staged,
    invalidate,
    install() {
      if (result) return;
      for (const { address } of members.values()) {
        const descriptor = Object.getOwnPropertyDescriptor(
          address.branch,
          address.key
        );
        if (descriptor?.value !== address.node || !descriptor.configurable) {
          frame.discard();
          throw new Error(
            "Plain branch target location changed before installation"
          );
        }
      }
      result = installFrame();
      for (const slot of result.changedSlots) changedSlots.add(slot);
      for (const { address, present } of members.values()) {
        if (setMemberPresence(
          address.branch,
          address.key,
          present ? "active" : "dormant"
        )) {
          changedBranches.add(address.branch);
          if (isWritableLocation(address.node))
            changedSlots.add(resolveSlot(address.node).slot);
          else changedBranchMembers.push(address);
        }
      }
      if (scalarTargets === void 0) captureChanges();
    },
    publish() {
      const installed = result;
      if (!installed)
        throw new Error("Plain branch target published before installation");
      if (published) return;
      published = true;
      const meta = {
        ...getActiveWriteContext(),
        intent: "system",
        participation: "realized"
      };
      withWriteContext(meta, () => {
        invalidate();
        if (scalarTargets !== void 0) captureChanges();
        for (const [slot, value] of values) {
          if (!installed.changedSlots.includes(slot)) continue;
          const path = getOwnedOwnerPath(value.node);
          if (path === void 0) continue;
          pathObservation().notify(
            path,
            value.after,
            value.before,
            path,
            void 0,
            [value.position],
            meta,
            registry.id
          );
        }
        for (const change of changes) {
          const path = getOwnedOwnerPath(change.branch);
          if (path === void 0) continue;
          const notification = {
            ...meta,
            [MEMBERSHIP]: change
          };
          pathObservation().notify(
            path,
            void 0,
            void 0,
            path,
            void 0,
            getOwnedPositionIds(change.branch),
            notification,
            registry.id
          );
        }
      });
    }
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/write-observation-scope.ts
var maxTokens = 8;
var active = /* @__PURE__ */ new Map();
var freeze = (tokens, includesUnscoped, omitted) => Object.freeze({
  tokens: Object.freeze(tokens),
  includesUnscoped,
  omitted
});
function currentWriteObservationScopes(ownerId) {
  return ownerId === void 0 ? void 0 : active.get(ownerId);
}
function mergeWriteObservationScopes(left, right) {
  if (!left && !right) return void 0;
  const tokens = [...left?.tokens ?? []];
  let omitted = left?.omitted === true || right?.omitted === true;
  for (const token of right?.tokens ?? []) {
    if (tokens.includes(token)) continue;
    if (tokens.length < maxTokens) tokens.push(token);
    else omitted = true;
  }
  return freeze(tokens, !left || !right || left.includesUnscoped || right.includesUnscoped, omitted);
}
function withoutWriteObservationScopes(deliver2) {
  if (active.size === 0) return deliver2();
  const previous = active;
  active = /* @__PURE__ */ new Map();
  try {
    return deliver2();
  } finally {
    active = previous;
  }
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/write-participation.ts
var getWriteParticipation = (meta) => meta?.participation ?? "authored";
var isInspectionWrite = (meta) => meta?.participation === "inspection";

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/path-notifier.ts
var isPlainRowRecord = (value) => {
  if (value === null || typeof value !== "object") return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === null || prototype === Object.prototype;
};
var changedSubjectFieldKeys = (before, after, subjectIds) => {
  if (subjectIds?.length !== 1 || !isPlainRowRecord(before) || !isPlainRowRecord(after)) {
    return void 0;
  }
  return [.../* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)])].filter(
    (key) => Object.prototype.hasOwnProperty.call(before, key) !== Object.prototype.hasOwnProperty.call(after, key) || !Object.is(before[key], after[key])
  );
};
var materializeDeliveryMeta = (meta) => {
  if (!meta?.structuralEffect) {
    return meta;
  }
  return {
    ...meta,
    structuralEffect: Object.freeze({ ...meta.structuralEffect })
  };
};
var PathNotifier = class _PathNotifier {
  static ownerBoundarySeparator = "\0";
  // Map of pattern -> Set of handlers
  subscribers = /* @__PURE__ */ new Map();
  // Batching state
  resetCallbacks = /* @__PURE__ */ new Set();
  batchingEnabled = true;
  batchIdentityMode = "path-position-subject";
  pendingFlush = false;
  pending = /* @__PURE__ */ new Map();
  pendingBeforeMembership = [];
  flushCallbacks = /* @__PURE__ */ new Set();
  /**
   * @internal Installed while a reversal or rollback applies
   * (`publishingExposedOnly`): true for a realized write to a location the
   * operation leaves absent, which is then not published. Path observers see
   * what the tree exposes, never retained storage (v15 c6258aab, v16 8g).
   */
  absentRealized;
  enqueueObservers = /* @__PURE__ */ new Map();
  /** @internal Owner-scoped evidence before batching can discard chronology. */
  observeEnqueue(ownerId, listener) {
    let listeners3 = this.enqueueObservers.get(ownerId);
    if (!listeners3) this.enqueueObservers.set(ownerId, listeners3 = /* @__PURE__ */ new Set());
    listeners3.add(listener);
    return () => {
      listeners3.delete(listener);
      if (listeners3.size === 0 && this.enqueueObservers.get(ownerId) === listeners3)
        this.enqueueObservers.delete(ownerId);
    };
  }
  constructor(options) {
    if (options && options.batching === false) this.batchingEnabled = false;
  }
  /**
   * Enable or disable batching at runtime (global opt-out)
   */
  setBatchingEnabled(enabled2) {
    this.batchingEnabled = enabled2;
  }
  isBatchingEnabled() {
    return this.batchingEnabled;
  }
  hasObservers() {
    return this.subscribers.size > 0 || this.flushCallbacks.size > 0;
  }
  /**
   * ⚠️ RETURNS VOID SINCE 15.0. It used to return `{ blocked, value }`, the
   * result protocol of the deleted delivery interceptors. The only producer —
   * `owned-mutation` — already discarded it, and no surviving caller consumed
   * it. Keeping the shape would have preserved archaeological evidence of a
   * retired mechanism as though it were a contract.
   */
  // ⚠️ `emitMutation(envelope)` WAS DELETED IN 15.0 — ME-B,
  // MUTATION-ENVELOPE-OWNERSHIP-0.
  //
  // It was a pure adapter: unpack a `MutationEnvelope` produced by exactly one
  // caller and immediately call `this.notify(...)` field-for-field. No decision
  // was made at that boundary — it joined path segments the same caller had
  // just split, and rewrapped a position id the same caller had just unwrapped.
  //
  //     ONE SEMANTIC PUBLICATION JOB, ONE PORT OPERATION.
  //
  // `owned-mutation` now calls `notify` through the port directly. Do not
  // reintroduce a parameter object BESIDE this protocol; that recreates the
  // dual-protocol problem this deletion removed. Replacing the positional
  // signature IN PLACE, derived from all producers and consumers, is admissible
  // representation cleanup — adding a second entry point is not.
  /** @internal Bench/test-only hook to isolate batching-key overhead. */
  setBatchIdentityModeForTesting(mode2 = "path-position-subject") {
    this.batchIdentityMode = mode2;
  }
  /**
   * Subscribe to mutations matching a path pattern
   * Returns unsubscribe function
   */
  subscribe(pattern, handler) {
    if (!this.subscribers.has(pattern)) {
      this.subscribers.set(pattern, /* @__PURE__ */ new Set());
    }
    const handlers = this.subscribers.get(pattern);
    if (!handlers) {
      return () => {
      };
    }
    handlers.add(handler);
    return () => {
      handlers.delete(handler);
      if (handlers.size === 0) {
        this.subscribers.delete(pattern);
      }
    };
  }
  /**
   * Notify all subscribers matching the path
   * When batching is enabled, notifications are queued and flushed at
   * the end of the current microtask (via queueMicrotask).
   */
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    const ambientMeta = metaOverride ?? getActiveWriteContext();
    if (this.absentRealized?.(positionIds, ambientMeta)) return;
    const metaBeforeOwner = isRestorationDesignated() ? markMetaDesignated(ambientMeta) : ambientMeta;
    let meta = ownerId === void 0 ? metaBeforeOwner : { ...metaBeforeOwner ?? {}, ownerId };
    meta = annotate(meta, ownerId ?? meta?.ownerId, positionIds, getWriteParticipation(meta) === "authored", value);
    const declaredScopes = currentWriteObservationScopes(ownerId);
    const origin = meta?.origin;
    const evidenceOwner = ownerId ?? meta?.ownerId;
    const evidenceListeners = evidenceOwner === void 0 ? void 0 : this.enqueueObservers.get(evidenceOwner);
    if (evidenceListeners?.size) {
      const snapshot = Object.freeze({
        path,
        newValue: value,
        oldValue: prev,
        ownerPath,
        origin,
        ownerId: evidenceOwner,
        meta: meta ? Object.freeze({ ...materializeDeliveryMeta(meta) }) : void 0,
        positionIds: positionIds ? [...positionIds] : void 0,
        subjectIds: subjectIds ? [...subjectIds] : void 0
      });
      if (snapshot.positionIds) Object.freeze(snapshot.positionIds);
      if (snapshot.subjectIds) Object.freeze(snapshot.subjectIds);
      for (const listener of [...evidenceListeners]) {
        try {
          withoutWriteObservationScopes(() => listener(snapshot));
        } catch (error) {
          try {
            console.error("SignalTree: enqueue observation failed.", error);
          } catch {
          }
        }
      }
    }
    const fieldKeys = changedSubjectFieldKeys(prev, value, subjectIds);
    const footprintKeys = subjectFieldFootprint ?? fieldKeys;
    const knownFootprint = subjectFieldFootprint === null ? null : footprintKeys === void 0 ? void 0 : Object.freeze([...footprintKeys]);
    if (!this.batchingEnabled) {
      const deliveryMeta = materializeDeliveryMeta(meta);
      return this._runNotify(
        path,
        value,
        prev,
        ownerPath,
        origin,
        subjectIds,
        positionIds,
        deliveryMeta,
        declaredScopes,
        ownerId,
        knownFootprint
      );
    }
    const entry = {
      path,
      newValue: value,
      oldValue: prev,
      ownerPath,
      origin,
      meta,
      declaredScopes,
      subjectId: subjectIds?.[0],
      positionId: positionIds?.[0],
      ownerId,
      subjectIds,
      positionIds,
      subjectFieldKeys: fieldKeys,
      subjectFieldFootprint: knownFootprint
    };
    this.enqueuePending(entry);
    if (!this.pendingFlush) {
      this.pendingFlush = true;
      queueMicrotask(() => this.flush());
    }
    return;
  }
  /**
   * Internal synchronous notification runner (subscribers)
   */
  _runNotify(path, value, prev, ownerPath, origin, subjectIds, positionIds, meta, declaredScopes, ownerId, subjectFieldFootprint, isolateSubscribers = false) {
    const transformed = value;
    for (const [pattern, handlers] of this.subscribers) {
      if (this.matches(pattern, path)) {
        for (const handler of handlers) {
          try {
            withoutWriteObservationScopes(
              () => handler(
                transformed,
                prev,
                path,
                ownerPath,
                origin,
                subjectIds,
                positionIds,
                meta,
                declaredScopes,
                ownerId,
                subjectFieldFootprint
              )
            );
          } catch (error) {
            if (!isolateSubscribers) throw error;
            reportContainedObserverError({
              error,
              operation: "notify:subscriber",
              // Entity and compensation writes name their tree in meta only.
              treeId: ownerId ?? meta?.ownerId,
              path
            });
          }
        }
      }
    }
    return;
  }
  /**
   * Flush pending batched notifications immediately.
   * This is re-entrant safe and will process notifications queued during
   * subscriber callbacks in subsequent rounds.
   */
  flush() {
    const toNotify = [
      ...this.pendingBeforeMembership,
      ...this.pending.values()
    ];
    this.pendingBeforeMembership = [];
    this.pending.clear();
    this.pendingFlush = false;
    for (const slot of toNotify) for (const entry of Array.isArray(slot) ? slot : [slot]) complete(entry.meta, entry.ownerId ?? entry.meta?.ownerId, entry.positionIds);
    for (const slot of toNotify) {
      const entries = Array.isArray(slot) ? slot : [slot];
      for (const entry of entries) {
        const isOwnerOnlyMarkerSignal = entry.ownerPath !== void 0 && entry.newValue === void 0 && entry.oldValue === void 0;
        const hasStructuralEffect = entry.meta?.structuralEffect !== void 0;
        if (entry.newValue === entry.oldValue && !isOwnerOnlyMarkerSignal && !hasStructuralEffect) {
          continue;
        }
        this._runNotify(
          entry.path,
          entry.newValue,
          entry.oldValue,
          entry.ownerPath,
          entry.origin,
          entry.subjectIds,
          entry.positionIds,
          materializeDeliveryMeta(entry.meta),
          entry.declaredScopes,
          entry.ownerId,
          entry.subjectFieldFootprint,
          true
        );
      }
    }
    for (const cb of Array.from(this.flushCallbacks)) {
      try {
        withoutWriteObservationScopes(cb);
      } catch {
      }
    }
  }
  /**
   * Force synchronous flush of pending notifications
   */
  flushSync() {
    while (this.hasPending() || this.pendingFlush) {
      if (this.pendingFlush && !this.hasPending()) {
        this.pendingFlush = false;
        break;
      }
      this.flush();
    }
  }
  /**
   * Subscribe to flush events (called after a flush completes)
   */
  onFlush(callback) {
    this.flushCallbacks.add(callback);
    return () => this.flushCallbacks.delete(callback);
  }
  /** Internal evidence only: never drains the queue or invokes observers.
   * Include net-equal entries: an ABA write still changed ownership.
   */
  readPending() {
    return [...this.pendingBeforeMembership, ...this.pending.values()].flatMap(
      (slot) => (Array.isArray(slot) ? slot : [slot]).map((entry) => ({
        ...entry,
        subjectFieldKeys: entry.subjectFieldKeys ? [...entry.subjectFieldKeys] : void 0
      }))
    );
  }
  /**
   * Check if there are pending notifications
   */
  hasPending() {
    return this.pending.size > 0 || this.pendingBeforeMembership.length > 0;
  }
  /**
   * Simple pattern matching
   * - 'users' matches exactly 'users'
   * - 'users.*' matches 'users.u1', 'users.u2', etc.
   * - '**' matches everything
   */
  matches(pattern, path) {
    if (pattern === "**") return true;
    if (pattern === path) return true;
    if (pattern.endsWith(".*")) {
      const prefix = pattern.slice(0, -2);
      return path.startsWith(prefix + ".");
    }
    return false;
  }
  enqueuePending(entry) {
    if (plainBranchMembershipChange(entry.meta)) {
      for (const slot of this.pending.values())
        this.pendingBeforeMembership.push(slot);
      this.pendingBeforeMembership.push(entry);
      this.pending.clear();
      return;
    }
    const path = entry.path;
    const existing = this.pending.get(path);
    if (!existing) {
      this.pending.set(path, entry);
      return;
    }
    if (this.batchIdentityMode === "path") {
      if (Array.isArray(existing)) {
        const tail = existing[existing.length - 1];
        if (this.hasSameSemanticIdentity(tail, entry)) {
          this.coalesceEntry(tail, entry);
          return;
        }
        existing.push(entry);
        return;
      }
      if (this.hasSameSemanticIdentity(existing, entry)) {
        this.coalesceEntry(existing, entry);
        return;
      }
      this.pending.set(path, [existing, entry]);
      return;
    }
    if (this.batchIdentityMode === "path-position-subject-composite") {
      this.enqueuePendingComposite(entry);
      return;
    }
    if (Array.isArray(existing)) {
      const tail = existing[existing.length - 1];
      if (this.hasSameSemanticIdentity(tail, entry)) {
        this.coalesceEntry(tail, entry);
        return;
      }
      existing.push(entry);
      return;
    }
    if (this.hasSameSemanticIdentity(existing, entry)) {
      this.coalesceEntry(existing, entry);
      return;
    }
    this.pending.set(path, [existing, entry]);
  }
  enqueuePendingComposite(entry) {
    const compositeKey = this.getCompositeBatchKey(entry);
    const existing = this.pending.get(compositeKey);
    if (!existing) {
      this.pending.set(compositeKey, entry);
      return;
    }
    const target = Array.isArray(existing) ? existing[0] : existing;
    this.coalesceEntry(target, entry);
  }
  hasSameSemanticIdentity(left, right) {
    if (this.crossesStructuralBoundary(left, right)) {
      return false;
    }
    if (this.crossesScalarIntentBoundary(left, right)) {
      return false;
    }
    if (this.crossesCausalModeBoundary(left, right)) {
      return false;
    }
    if ((left.ownerId ?? left.meta?.ownerId) !== (right.ownerId ?? right.meta?.ownerId)) {
      return false;
    }
    if (this.batchIdentityMode === "path-position") {
      return left.positionId === right.positionId;
    }
    return left.positionId === right.positionId && left.subjectId === right.subjectId;
  }
  crossesStructuralBoundary(left, right) {
    const leftEffect = left.meta?.structuralEffect;
    const rightEffect = right.meta?.structuralEffect;
    const leftStructural = leftEffect !== void 0;
    const rightStructural = rightEffect !== void 0;
    if (leftStructural !== rightStructural) {
      return true;
    }
    if (leftStructural && rightStructural && leftEffect.kind !== rightEffect.kind) {
      return true;
    }
    return false;
  }
  crossesScalarIntentBoundary(left, right) {
    const leftIntent = left.meta?.mutationIntent;
    const rightIntent = right.meta?.mutationIntent;
    return leftIntent !== void 0 && rightIntent !== void 0 && leftIntent !== rightIntent;
  }
  crossesCausalModeBoundary(left, right) {
    return getWriteParticipation(left.meta) !== getWriteParticipation(right.meta) || left.origin !== right.origin || left.meta?.transactionId !== right.meta?.transactionId || left.meta?.transactionOwner !== right.meta?.transactionOwner;
  }
  coalesceEntry(target, next) {
    target.subjectFieldFootprint = target.subjectFieldFootprint === void 0 || next.subjectFieldFootprint === void 0 ? void 0 : target.subjectFieldFootprint === null || next.subjectFieldFootprint === null ? null : Object.freeze([
      .../* @__PURE__ */ new Set([
        ...target.subjectFieldFootprint,
        ...next.subjectFieldFootprint
      ])
    ]);
    target.subjectFieldKeys = target.subjectFieldKeys !== void 0 && next.subjectFieldKeys !== void 0 ? [.../* @__PURE__ */ new Set([...target.subjectFieldKeys, ...next.subjectFieldKeys])] : void 0;
    target.declaredScopes = mergeWriteObservationScopes(
      target.declaredScopes,
      next.declaredScopes
    );
    target.newValue = next.newValue;
    target.ownerPath = next.ownerPath;
    target.origin = this.mergeOrigin(target.origin, next.origin);
    target.meta = this.mergeMeta(target.meta, next.meta);
    target.subjectId = next.subjectId;
    target.positionId = next.positionId;
    target.subjectIds = next.subjectIds;
    target.positionIds = next.positionIds;
  }
  mergeOrigin(left, right) {
    if (!left && !right) return void 0;
    if (left === right) return left;
    return "mixed";
  }
  mergeMeta(left, right) {
    if (!left && !right) {
      return void 0;
    }
    if (!left || !right) {
      return void 0;
    }
    if (left.origin !== right.origin) {
      return void 0;
    }
    if (left.transactionId !== right.transactionId || left.transactionOwner !== right.transactionOwner || left.mutationIntent !== right.mutationIntent || getWriteParticipation(left) !== getWriteParticipation(right)) {
      return void 0;
    }
    const merged = left.structuralEffect && !right.structuralEffect ? { ...right, structuralEffect: left.structuralEffect } : right;
    return isMetaDesignated(left) ? { ...merged, ...markMetaDesignated(void 0) } : merged;
  }
  getCompositeBatchKey(entry) {
    const positionKey = entry.positionIds?.join(",") ?? "";
    const subjectKey = entry.subjectIds?.join(",") ?? "";
    const participation = getWriteParticipation(entry.meta);
    return `${entry.path}${_PathNotifier.ownerBoundarySeparator}${positionKey}${_PathNotifier.ownerBoundarySeparator}${subjectKey}${_PathNotifier.ownerBoundarySeparator}${participation}`;
  }
  /**
   * Clear all subscribers
   */
  clear() {
    this.subscribers.clear();
    this.pending.clear();
    this.pendingBeforeMembership = [];
    this.pendingFlush = false;
  }
  /** Reset queued runtime state but preserve registered listeners. */
  onReset(callback) {
    this.resetCallbacks.add(callback);
    return () => this.resetCallbacks.delete(callback);
  }
  emitReset() {
    for (const cb of Array.from(this.resetCallbacks)) {
      try {
        withoutWriteObservationScopes(cb);
      } catch {
      }
    }
  }
  /**
   * Get count of active subscribers (for debugging)
   */
  getSubscriberCount() {
    let count = 0;
    for (const handlers of this.subscribers.values()) {
      count += handlers.size;
    }
    return count;
  }
};
var globalPathNotifier = null;
function getPathNotifier() {
  if (!globalPathNotifier) {
    globalPathNotifier = new PathNotifier();
  }
  installPathDeliveryRuntime(globalPathNotifier);
  installBranchMembershipCapture(
    capturePlainBranchMembership,
    capturePathReAdd
  );
  return globalPathNotifier;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/link-state-source.ts
var SLOTS = /* @__PURE__ */ new WeakMap();
function getLinkStateSlot(registry) {
  let slot = SLOTS.get(registry);
  if (!slot) SLOTS.set(registry, slot = { next: 1, links: /* @__PURE__ */ new Map() });
  return slot;
}
function registerLinkState(registry, source, path, endpoint, activity) {
  const slot = getLinkStateSlot(registry);
  const record = {
    id: slot.next++,
    source,
    path,
    endpoint,
    activity
  };
  slot.links.set(record.id, record);
  return (kind) => {
    if (!slot.links.has(record.id)) return;
    if (kind === null || kind === "disposed") slot.links.delete(record.id);
    if (kind !== null) slot.observer?.(record, kind);
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/source-mutation.ts
function applyAtRelativePath(previous, segments, value) {
  return setAtPath(previous, segments, value);
}
function relativeSourceAddress(source, address) {
  if (source.length > address.length) return void 0;
  if (!source.every((segment, index) => segment === address[index]))
    return void 0;
  return address.slice(source.length);
}
function setAtPath(node, segments, value) {
  if (segments.length === 0) return value;
  const [head, ...rest] = segments;
  const base = node ?? {};
  return { ...base, [head]: setAtPath(base[head], rest, value) };
}
function createEntityTopology(seed) {
  let order = [];
  const keys = /* @__PURE__ */ new Map();
  function reload(entries) {
    order = [];
    keys.clear();
    for (const e of entries) {
      order.push(e.subjectId);
      keys.set(e.subjectId, e.key);
    }
  }
  reload(seed);
  return {
    reload,
    reorder: (afterSubjects) => {
      order = [...afterSubjects];
    },
    keyOf: (subject) => keys.get(subject),
    has: (subject) => order.includes(subject),
    observe(effect) {
      if (effect.kind === "add") {
        if (order.includes(effect.subject)) return;
        if (effect.key !== void 0) keys.set(effect.subject, effect.key);
        if (effect.beforeSubject !== void 0) {
          const i = order.indexOf(effect.beforeSubject);
          if (i !== -1) return void order.splice(i + 1, 0, effect.subject);
        }
        if (effect.afterSubject !== void 0) {
          const i = order.indexOf(effect.afterSubject);
          if (i !== -1) return void order.splice(i, 0, effect.subject);
        }
        order.push(effect.subject);
        return;
      }
      if (effect.kind === "remove") {
        const i = order.indexOf(effect.subject);
        if (i !== -1) order.splice(i, 1);
        keys.delete(effect.subject);
        return;
      }
      if (effect.afterKey !== void 0)
        keys.set(effect.subject, effect.afterKey);
    },
    placement(subject, isIncluded) {
      const at = order.indexOf(subject);
      if (at !== -1) {
        for (let j = at - 1; j >= 0; j--) {
          if (isIncluded(order[j])) return { after: order[j] };
        }
        for (let j = at + 1; j < order.length; j++) {
          if (isIncluded(order[j])) return { before: order[j] };
        }
      }
      return "end";
    }
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/entity-egress-projection.ts
function projectEntityFields(previous, row, fields) {
  if (fields === null) return row;
  if (!fields?.length || !row || typeof row !== "object") return previous;
  const next = { ...previous };
  for (const key of fields) {
    if (Object.prototype.hasOwnProperty.call(row, key)) {
      Object.defineProperty(next, key, {
        value: row[key],
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else delete next[key];
  }
  return next;
}
function createEntityEgressProjection(seed) {
  let topology = createEntityTopology(seed);
  let order = [];
  const rows = /* @__PURE__ */ new Map();
  const keyOf = /* @__PURE__ */ new Map();
  function load(entries) {
    order = [];
    rows.clear();
    keyOf.clear();
    for (const e of entries) {
      order.push(e.subjectId);
      rows.set(e.subjectId, e.row);
      keyOf.set(e.subjectId, e.key);
    }
  }
  load(seed);
  const isEligible = (s) => rows.has(s);
  function place(subject) {
    if (order.includes(subject)) return;
    const at = topology.placement(subject, isEligible);
    if (at === "end") return void order.push(subject);
    if ("after" in at)
      return void order.splice(order.indexOf(at.after) + 1, 0, subject);
    order.splice(order.indexOf(at.before), 0, subject);
  }
  function remove(subject) {
    const i = order.indexOf(subject);
    if (i !== -1) order.splice(i, 1);
    rows.delete(subject);
    keyOf.delete(subject);
  }
  function reconcileAddress(key, incoming) {
    if (key === void 0) return;
    for (const [subject, held] of keyOf) {
      if (held !== key || subject === incoming) continue;
      if (!topology.has(subject)) remove(subject);
      return;
    }
  }
  return {
    value: () => order.map((s) => rows.get(s)),
    reorder(afterSubjects, inspection) {
      topology.reorder(afterSubjects);
      if (inspection) return false;
      const present = new Set(afterSubjects);
      const eligible = afterSubjects.filter(isEligible);
      let cursor = 0;
      let changed = false;
      order = order.map((subject) => {
        if (!present.has(subject)) return subject;
        const next = eligible[cursor++];
        if (next !== subject) changed = true;
        return next;
      });
      return changed;
    },
    reseed(entries) {
      topology = createEntityTopology(entries);
      load(entries);
    },
    apply(subjectId, row, effect, inspection, fields) {
      if (effect) topology.observe(effect);
      if (inspection) return false;
      if (effect?.kind === "add") {
        reconcileAddress(effect.key, effect.subject);
        place(effect.subject);
        rows.set(effect.subject, effect.value);
        if (effect.key !== void 0) keyOf.set(effect.subject, effect.key);
        return true;
      }
      if (effect?.kind === "remove") {
        if (!isEligible(effect.subject)) return false;
        remove(effect.subject);
        return true;
      }
      if (effect?.kind === "rekey") {
        if (!isEligible(effect.subject)) return false;
        if (effect.afterKey !== void 0)
          keyOf.set(effect.subject, effect.afterKey);
        return true;
      }
      if (subjectId === void 0) return false;
      if (isEligible(subjectId)) {
        const previous = rows.get(subjectId);
        const next = projectEntityFields(previous, row, fields);
        if (next === previous) return false;
        rows.set(subjectId, next);
        return true;
      }
      if (fields === void 0) return false;
      if (!isEligible(subjectId)) {
        if (!topology.has(subjectId)) return false;
        const k = topology.keyOf(subjectId);
        reconcileAddress(k, subjectId);
        place(subjectId);
        if (k !== void 0) keyOf.set(subjectId, k);
      }
      rows.set(subjectId, row);
      return true;
    }
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/commit-consequence.ts
var scopesByOwner = /* @__PURE__ */ new WeakMap();
var openScopesByKey = /* @__PURE__ */ new WeakMap();
var settleListenersByKey = /* @__PURE__ */ new WeakMap();
var heldByKey = /* @__PURE__ */ new WeakMap();
function resolveScopeKey(node) {
  if (node === void 0 || node === null) return void 0;
  const candidate = node;
  const registry = getPositionRegistry(candidate.$ ?? node) ?? getPositionRegistry(node);
  return registry ?? node;
}
function hasOpen(key) {
  const scopes = openScopesByKey.get(key);
  return scopes !== void 0 && scopes.size > 0;
}
function openCommitScope(owner, transactionId, tree) {
  let byId = scopesByOwner.get(owner);
  if (!byId) {
    byId = /* @__PURE__ */ new Map();
    scopesByOwner.set(owner, byId);
  }
  const key = resolveScopeKey(tree);
  byId.set(transactionId, { key, consequences: /* @__PURE__ */ new Map() });
  if (key) {
    let open = openScopesByKey.get(key);
    if (!open) {
      open = /* @__PURE__ */ new Set();
      openScopesByKey.set(key, open);
    }
    open.add(transactionId);
  }
}
function scopeOwns(scope, claimant) {
  if (!scope.key) return true;
  if (claimant === void 0) return false;
  return resolveScopeKey(claimant) === scope.key;
}
function deferCommitConsequence(owner, transactionId, key, fn, claimant) {
  const scope = scopesByOwner.get(owner)?.get(transactionId);
  if (!scope) return false;
  if (!scopeOwns(scope, claimant)) return false;
  scope.consequences.set(key, fn);
  return true;
}
function scheduleDurableConsequence(request) {
  const { claimant, key, run: run2 } = request;
  const meta = getActiveWriteContext();
  const owner = meta?.transactionOwner;
  const transactionId = meta?.transactionId;
  if (owner !== void 0 && typeof transactionId === "number" && deferCommitConsequence(owner, transactionId, key, run2, claimant)) {
    return;
  }
  const scopeKey = resolveScopeKey(claimant);
  if (scopeKey && hasOpen(scopeKey)) {
    let held = heldByKey.get(scopeKey);
    if (!held) {
      held = /* @__PURE__ */ new Map();
      heldByKey.set(scopeKey, held);
    }
    held.set(key, run2);
    return;
  }
  run2();
}
function settleCommitScope(owner, transactionId, outcome) {
  const byId = scopesByOwner.get(owner);
  const scope = byId?.get(transactionId);
  if (!byId || !scope) return;
  byId.delete(transactionId);
  if (byId.size === 0) scopesByOwner.delete(owner);
  const key = scope.key;
  if (key) {
    const open = openScopesByKey.get(key);
    open?.delete(transactionId);
    if (open && open.size === 0) openScopesByKey.delete(key);
  }
  let firstError;
  let failed = false;
  const capture = (error) => {
    if (!failed) {
      failed = true;
      firstError = error;
    }
  };
  const attempt = (fn) => {
    try {
      fn();
    } catch (error) {
      capture(error);
    }
  };
  if (outcome === "commit") {
    for (const consequence of scope.consequences.values()) attempt(consequence);
  }
  scope.consequences.clear();
  if (key && !hasOpen(key)) {
    const held = heldByKey.get(key);
    if (held) {
      heldByKey.delete(key);
      for (const consequence of held.values()) attempt(consequence);
      held.clear();
    }
    const listeners3 = settleListenersByKey.get(key);
    if (listeners3) {
      for (const listener of [...listeners3]) attempt(listener);
    }
  }
  if (failed) throw firstError;
}
function cancelCommitScopes(owner) {
  const scopes = scopesByOwner.get(owner);
  if (!scopes) return;
  scopesByOwner.delete(owner);
  for (const [id, scope] of scopes) {
    scope.consequences.clear();
    if (!scope.key) continue;
    const open = openScopesByKey.get(scope.key);
    open?.delete(id);
    if (open?.size === 0) openScopesByKey.delete(scope.key);
    heldByKey.delete(scope.key);
    settleListenersByKey.delete(scope.key);
  }
  scopes.clear();
}
function withdrawHeldConsequence(claimant, key) {
  const scopeKey = resolveScopeKey(claimant);
  if (scopeKey) heldByKey.get(scopeKey)?.delete(key);
}
function isCommitScopeOpen(owner, transactionId) {
  return scopesByOwner.get(owner)?.has(transactionId) === true;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/link.ts
function accessorsFor(x) {
  const node = x;
  const rootTree = getRootTree(x);
  if (rootTree) {
    return {
      read: () => rootTree.read(),
      write: (v) => rootTree.replace(v),
      collection: false
    };
  }
  if (isNodeAccessor(x)) {
    return {
      read: () => x(),
      write: (value) => x(value),
      collection: false
    };
  }
  const all = node.all;
  const setAll = node.setAll;
  if (typeof all === "function" && typeof setAll === "function") {
    return {
      read: () => all(),
      write: (v) => setAll(v),
      collection: true
    };
  }
  if (isWritableLocation(x)) {
    return {
      read: () => x(),
      write: (value) => replaceLocation(x, value),
      collection: false
    };
  }
  return {
    read: () => x(),
    write: (v) => x(v),
    collection: false
  };
}
function link(source, endpoint) {
  const x = source;
  const registry = getPositionRegistry(x);
  if (!registry) {
    throw new Error(
      "link: X must be an owned SignalTree location. A bare signal() or computed() has no owning tree, so there is nothing to settle against."
    );
  }
  if (!endpoint.get && !endpoint.set && !endpoint.subscribe) {
    throw new Error(
      "link: the endpoint must supply at least one of get, set or subscribe \u2014 a link with no direction synchronizes nothing."
    );
  }
  const { read: read2, write, collection } = accessorsFor(x);
  const entityLocation = getEntityLocationBinding(x);
  const sourceAddress = getNodeAddress(x);
  if (!entityLocation && sourceAddress === void 0) {
    throw new Error("link: the owned source has no structured address.");
  }
  const releaseObservation = acquireObservation(x);
  const ownerPath = getOwnedOwnerPath(x) ?? "";
  const notifier = getPathNotifier();
  let knownY;
  let disposed = false;
  let dirty = false;
  let chain = Promise.resolve();
  let inboundSeq = 0;
  let eligible = read2();
  let researchFact;
  const entityProjection = collection ? createEntityEgressProjection(getEntityProjectionSeed(x) ?? []) : void 0;
  const nestedCollections = /* @__PURE__ */ new Map();
  const collectionSources = /* @__PURE__ */ new Map();
  if (entityProjection) collectionSources.set(x, entityProjection);
  if (!collection && !entityLocation) {
    const discover = (node) => {
      if (!isTraversableNode(node)) return;
      const seed = getEntityProjectionSeed(node);
      if (seed) {
        const position = getOwnedPositionIds(node)?.[0];
        const address = position === void 0 ? void 0 : registry.addressFor(position);
        const relative = sourceAddress !== void 0 && address !== void 0 ? relativeSourceAddress(sourceAddress, address) : void 0;
        if (position === void 0 || relative === void 0) return;
        const projection = createEntityEgressProjection(seed);
        nestedCollections.set(position, {
          node,
          projection,
          relativeAddress: relative
        });
        collectionSources.set(node, projection);
        return;
      }
      for (const key of Object.keys(node)) {
        discover(node[key]);
      }
    };
    discover(x);
  }
  const advanceNested = (nested) => {
    eligible = applyAtRelativePath(eligible, nested.relativeAddress, {
      all: nested.projection.value()
    });
  };
  const held = /* @__PURE__ */ new Set();
  const consequenceKey = {};
  const sendConsequenceKey = {};
  const waitingSends = /* @__PURE__ */ new Set();
  const settlementWaiters = /* @__PURE__ */ new Set();
  const pendingOrders = /* @__PURE__ */ new Set();
  const retrievals = /* @__PURE__ */ new Set();
  let queued2 = 0;
  let sending = false;
  const observeLink = registerLinkState(
    registry,
    x,
    ownerPath,
    endpoint,
    () => [
      dirty,
      held.size > 0 || waitingSends.size > 0,
      queued2,
      sending,
      retrievals.size,
      disposed
    ]
  );
  const acquire2 = (value, seq) => {
    if (disposed || seq < inboundSeq) return;
    inboundSeq = seq;
    knownY = { value };
    eligible = value;
    acquire(registry.id, getOwnedPositionIds(x)?.[0] ?? -1, () => external(() => write(value)));
    if (entityProjection) {
      entityProjection.reseed(getEntityProjectionSeed(x) ?? []);
    }
  };
  const offSub = notifier.subscribe(
    "**",
    (v, prev, _path, _o, _origin, subjectIds, _pos, meta, _scopes, _owner, fields) => {
      if (disposed || !endpoint.set) return;
      const m = meta ?? {};
      if (m["ownerId"] !== registry.id) return;
      const membership = plainBranchMembershipChange(meta);
      if (membership) {
        if (entityLocation || isInspectionWrite(meta)) return;
        const address2 = getNodeAddress(membership.branch);
        const relative2 = sourceAddress !== void 0 && address2 !== void 0 ? relativeSourceAddress(sourceAddress, address2) : void 0;
        if (relative2 !== void 0) {
          eligible = applyPlainBranchMembership(eligible, relative2, membership);
        } else {
          const below = sourceAddress !== void 0 && address2 !== void 0 ? relativeSourceAddress(address2, sourceAddress) : void 0;
          const member = below?.length && membership.members.find(({ key }) => key === below[0]);
          if (!member || !below) return;
          let value = member.after.present ? member.after.value : void 0;
          for (const key of below.slice(1))
            value = value !== null && typeof value === "object" && Object.prototype.hasOwnProperty.call(value, key) ? value[key] : void 0;
          eligible = value;
          entityProjection?.reseed(getEntityProjectionSeed(x) ?? []);
        }
        for (const nested2 of nestedCollections.values()) {
          if (relative2 !== void 0 && !membership.members.some(
            ({ key }) => nested2.relativeAddress[relative2.length] === key && relative2.every(
              (step, at2) => nested2.relativeAddress[at2] === step
            )
          ))
            continue;
          nested2.projection.reseed(getEntityProjectionSeed(nested2.node) ?? []);
          let at = eligible;
          for (const key of nested2.relativeAddress.slice(0, -1))
            at = at !== null && typeof at === "object" ? at[key] : void 0;
          if (at !== null && typeof at === "object" && Object.prototype.hasOwnProperty.call(
            at,
            nested2.relativeAddress[nested2.relativeAddress.length - 1]
          ))
            advanceNested(nested2);
        }
        dirty = true;
        observeLink();
        return;
      }
      if (v === void 0 && prev === void 0) return;
      if (entityLocation) {
        if (_pos?.[0] !== entityLocation.owner || subjectIds?.[0] !== entityLocation.subjectId || isInspectionWrite(meta))
          return;
        const effect = meta?.structuralEffect;
        if (effect?.kind === "rekey") return;
        const removed = effect?.kind === "remove";
        const footprint = effect?.kind === "add" ? null : fields;
        if (!removed && footprint === void 0) return;
        if (entityLocation.fieldKey !== void 0) {
          if (!removed && footprint !== null && !footprint?.includes(entityLocation.fieldKey))
            return;
          eligible = v != null && Object.prototype.hasOwnProperty.call(v, entityLocation.fieldKey) ? v[entityLocation.fieldKey] : void 0;
        } else {
          const next = removed ? void 0 : projectEntityFields(eligible, v, footprint);
          if (next === eligible) return;
          eligible = next;
        }
        dirty = true;
        observeLink();
        return;
      }
      const position = _pos?.[0];
      const address = position === void 0 ? void 0 : registry.addressFor(position);
      const relative = sourceAddress !== void 0 && address !== void 0 ? relativeSourceAddress(sourceAddress, address) : void 0;
      if (relative === void 0) return;
      const inspection = isInspectionWrite(meta);
      const nested = position === void 0 ? void 0 : nestedCollections.get(position);
      if (nested) {
        const effect = meta?.["structuralEffect"];
        const advanced = nested.projection.apply(
          subjectIds?.[0],
          v,
          effect,
          inspection,
          fields
        );
        if (advanced) {
          advanceNested(nested);
          dirty = true;
          observeLink();
        }
        return;
      }
      if (entityProjection) {
        const effect = meta?.["structuralEffect"];
        const advanced = entityProjection.apply(
          subjectIds?.[0],
          v,
          effect,
          inspection,
          fields
        );
        if (advanced) {
          dirty = true;
          observeLink();
        }
        return;
      }
      if (inspection) return;
      researchFact = relative.length === 0 ? evidence(meta) : void 0;
      eligible = applyAtRelativePath(eligible, relative, v);
      dirty = true;
      observeLink();
    }
  );
  const researchHold = () => {
    if (held.size > 0 || disposed) return;
    let resolve;
    const promise = new Promise((r) => resolve = r);
    held.add({ promise, resolve });
  };
  const sendEligible = () => new Promise((resolve, reject) => {
    const cancel = () => {
      waitingSends.delete(cancel);
      resolve(false);
    };
    waitingSends.add(cancel);
    const attempt = () => {
      if (disposed) {
        cancel();
        return;
      }
      let synchronous = true;
      try {
        const researchTicket = researchFact;
        const now = entityProjection ? entityProjection.value() : eligible;
        if (knownY !== void 0 && deepEqual(now, knownY.value)) {
          cancel();
          return;
        }
        const researchAdmitted = admit(scheduleDurableConsequence, researchTicket, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, {
          claimant: x,
          key: sendConsequenceKey,
          run: () => {
            if (!synchronous) {
              queueMicrotask(attempt);
              return;
            }
            waitingSends.delete(cancel);
            sending = true;
            try {
              observeLink();
            } catch (error) {
              sending = false;
              throw error;
            }
            if (!disposed && !allowed(researchTicket, registry.id, getOwnedPositionIds(x)?.[0] ?? -1)) {
              sending = false;
              researchHold();
              cancel();
              return;
            }
            if (disposed) {
              sending = false;
              resolve(false);
              return;
            }
            try {
              Promise.resolve(endpoint.set?.(now)).then(
                () => {
                  sending = false;
                  knownY = { value: now };
                  resolve(true);
                },
                (error) => {
                  sending = false;
                  reject(error);
                }
              );
            } catch (error) {
              sending = false;
              reject(error);
            }
          }
        });
        if (!researchAdmitted) {
          researchHold();
          cancel();
        }
        if (waitingSends.has(cancel)) observeLink();
      } catch (error) {
        waitingSends.delete(cancel);
        reject(error);
      } finally {
        synchronous = false;
      }
    };
    attempt();
  });
  const flushOutbound = () => {
    if (disposed || !dirty) return;
    dirty = false;
    let entry = held.values().next().value;
    if (!entry) {
      let resolve;
      const promise = new Promise((r) => resolve = r);
      entry = { promise, resolve };
      held.add(entry);
    }
    const pending = entry;
    admit(scheduleDurableConsequence, researchFact, registry.id, getOwnedPositionIds(x)?.[0] ?? -1, {
      claimant: x,
      key: consequenceKey,
      run: () => {
        held.delete(pending);
        pending.resolve();
        if (disposed) return;
        queued2++;
        chain = chain.then(async () => {
          queued2--;
          try {
            for (; ; ) {
              if (disposed) return;
              if (!await sendEligible()) return;
            }
          } finally {
            observeLink();
          }
        }).catch((error) => {
          observeLink("send-failed");
          reportTreeError({
            error,
            operation: "link:set",
            treeId: registry.id,
            // ⚠️ `ownerPath` was already known here and previously dropped.
            // Location, never identity — two trees share this string.
            path: ownerPath === "" ? void 0 : ownerPath
          });
        });
        observeLink();
      }
    });
    observeLink();
  };
  const researchRefresh = () => {
    const receipt = refresh(registry.id, getOwnedPositionIds(x)?.[0] ?? -1);
    if (!receipt || receipt.fact === researchFact || !Object.is(receipt.payload, read2())) return;
    researchFact = receipt.fact;
    eligible = receipt.payload;
    dirty = true;
  };
  const offFlush = notifier.onFlush?.(() => {
    researchRefresh();
    flushOutbound();
  });
  const offResearchEligibility = onEligibility(registry.id, () => {
    if (!disposed) researchRefresh();
    if (disposed || held.size === 0 || !allowed(researchFact, registry.id, getOwnedPositionIds(x)?.[0] ?? -1)) return;
    dirty = true;
    flushOutbound();
  });
  const releaseOrders = [];
  for (const [node, projection] of collectionSources) {
    const capture = getMutationCaptureRuntime(node);
    if (!capture?.subscribeCollectionOrder) continue;
    const releaseCapture = capture.activateCapture();
    const offOrder = capture.subscribeCollectionOrder((order) => {
      if (disposed || order.owner !== getOwnedPositionIds(node)?.[0]) return;
      const inspection = isInspectionWrite(order.meta);
      let resolve;
      const promise = new Promise((r) => resolve = r);
      const pending = { promise, resolve };
      pendingOrders.add(pending);
      queueMicrotask(() => {
        try {
          if (disposed || !projection.reorder(order.afterSubjects, inspection))
            return;
          if (projection !== entityProjection) {
            const nested = nestedCollections.get(order.owner);
            if (nested) advanceNested(nested);
          }
          dirty = true;
          observeLink();
          flushOutbound();
        } finally {
          pendingOrders.delete(pending);
          pending.resolve();
        }
      });
    });
    releaseOrders.push(() => {
      offOrder();
      releaseCapture();
    });
  }
  let offSource;
  const dispose2 = () => {
    if (disposed) return;
    disposed = true;
    offResearchEligibility();
    dispose(consequenceKey, sendConsequenceKey);
    releaseObservation();
    offSub();
    offFlush?.();
    withdrawHeldConsequence(x, consequenceKey);
    withdrawHeldConsequence(x, sendConsequenceKey);
    for (const release of releaseOrders) release();
    for (const h of held) h.resolve();
    held.clear();
    for (const cancel of waitingSends) cancel();
    waitingSends.clear();
    for (const release of settlementWaiters) release();
    settlementWaiters.clear();
    for (const order of pendingOrders) order.resolve();
    pendingOrders.clear();
    for (const r of retrievals) r.resolve();
    retrievals.clear();
    observeLink("disposed");
    offSource?.();
  };
  try {
    offSource = endpoint.subscribe?.((v) => acquire2(v, ++inboundSeq));
  } catch (error) {
    observeLink(null);
    dispose2();
    throw error;
  }
  observeLink("created");
  return {
    async retrieve() {
      if (!endpoint.get) {
        throw new Error("link: endpoint supplies no get().");
      }
      const seq = ++inboundSeq;
      let resolve;
      const promise = new Promise((r) => resolve = r);
      const entry = { promise, resolve };
      retrievals.add(entry);
      observeLink();
      try {
        if (disposed) return;
        acquire2(await endpoint.get(), seq);
      } catch (error) {
        observeLink("retrieve-failed");
        throw error;
      } finally {
        retrievals.delete(entry);
        entry.resolve();
        observeLink();
      }
    },
    async settled() {
      for (; ; ) {
        if (disposed) return;
        if (retrievals.size > 0) {
          await Promise.race([...retrievals].map((r) => r.promise));
          continue;
        }
        const awaitedChain = chain;
        await new Promise((resolve, reject) => {
          const release = () => {
            settlementWaiters.delete(release);
            resolve();
          };
          settlementWaiters.add(release);
          void awaitedChain.then(release, (error) => {
            settlementWaiters.delete(release);
            reject(error);
          });
        });
        if (disposed) return;
        if (retrievals.size > 0) continue;
        if (pendingOrders.size > 0) {
          await Promise.race([...pendingOrders].map((order) => order.promise));
          continue;
        }
        if (chain !== awaitedChain) continue;
        if (held.size === 0) {
          if (!notifier.hasPending()) break;
          await new Promise((resolve) => {
            const off = notifier.onFlush(() => {
              off();
              resolve();
            });
          });
          continue;
        }
        await Promise.race([...held].map((h) => h.promise));
      }
    },
    dispose: dispose2
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/visit-tree.ts
function visitTree(root, visit, options = {}) {
  const maxDepth = options.maxDepth ?? 32;
  const skipKey = options.skipKey;
  const seen = /* @__PURE__ */ new WeakSet();
  const walk = (node, path, key, parent, depth) => {
    if (depth > maxDepth) return;
    if (!isTraversableNode(node)) return;
    if (seen.has(node)) return;
    seen.add(node);
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("treeVisits");
    }
    if (visit(node, path, key, parent) === false) return;
    let keys;
    try {
      keys = Object.keys(node);
    } catch {
      return;
    }
    for (const k of keys) {
      if (skipKey && skipKey(k)) continue;
      let child;
      try {
        child = node[k];
      } catch {
        continue;
      }
      if (!isTraversableNode(child)) continue;
      walk(child, path ? `${path}.${k}` : k, k, node, depth + 1);
    }
  };
  walk(root, "", null, null, 0);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/pending-rollback.ts
function rollbackPendingTurnAt(options) {
  const turn = options.store.getPendingTurn(options.turnId);
  if (!turn) {
    return { ok: false, refusal: { kind: "turn-evicted" } };
  }
  if (!turn.participants.every(
    (participant) => options.topology.contains(options.authority, participant)
  )) {
    return { ok: false, refusal: { kind: "outside-boundary" } };
  }
  if (hasLaterStructuralDependency(turn, options.store)) {
    return { ok: false, refusal: { kind: "dependency-conflict" } };
  }
  const effects = createPendingRollbackEffects(
    turn,
    options.realizationContext
  );
  const validationRefusal = options.port.validateEffects?.(effects);
  if (validationRefusal) {
    return { ok: false, refusal: validationRefusal };
  }
  const transition2 = options.store.prepareDiscardPendingTurn(turn.id);
  if (!transition2.ok) {
    return mapDiscardFailure(transition2);
  }
  options.port.applyAtomically(effects);
  const discardedTurn = options.store.commitPreparedDiscardPending(
    transition2.transition
  );
  const maintenanceObserver = options.onMaintenanceMayBeUseful ?? options.onPendingTurnDiscarded;
  const maintenanceErrorObserver = options.reportMaintenanceObserverError ?? options.reportDiscardObserverError;
  if (discardedTurn && maintenanceObserver) {
    try {
      maintenanceObserver(discardedTurn);
    } catch (error) {
      if (maintenanceErrorObserver) {
        maintenanceErrorObserver(error, discardedTurn);
      } else {
        queueMicrotask(() => {
          throw normalizeError(error);
        });
      }
    }
  }
  return { ok: true, turnId: turn.id };
}
function createPendingRollbackEffects(turn, realizationContext) {
  const dominantStructuralEffects = /* @__PURE__ */ new Map();
  for (const effect of turn.effects) {
    if (effect.subjectId !== void 0 && (effect.structural === "add" || effect.structural === "remove")) {
      const candidates = dominantStructuralEffects.get(effect.subjectId);
      if (candidates) candidates.push(effect);
      else dominantStructuralEffects.set(effect.subjectId, [effect]);
    }
  }
  const firstEffectIndexByOwner = /* @__PURE__ */ new Map();
  turn.effects.forEach((effect, index) => {
    const effectKey = rollbackAddressKey(effect);
    if (!firstEffectIndexByOwner.has(effectKey)) {
      firstEffectIndexByOwner.set(effectKey, index);
    }
  });
  return placeFieldReversalsWhileRowsExist(
    turn.effects.filter((effect, index) => {
      if (effect.subjectId !== void 0) {
        const dominantStructuralEffect = dominantStructuralEffects.get(effect.subjectId)?.find((candidate) => sameSubjectScope(candidate, effect));
        if (dominantStructuralEffect && (dominantStructuralEffect === effect || dominantStructuralEffect.structural === "add" || dominantStructuralEffect.owner !== effect.owner)) {
          return dominantStructuralEffect === effect;
        }
      }
      const effectKey = rollbackAddressKey(effect);
      return firstEffectIndexByOwner.get(effectKey) === index;
    }).map(
      (effect) => createPendingRollbackEffect(effect, turn.id, realizationContext)
    ).filter(
      (effect) => effect.plainBranchMembership !== void 0 && effect.plainBranchMembership.before !== effect.plainBranchMembership.after || effect.before !== effect.after || effect.fieldPresence !== void 0 && effect.fieldPresence.before !== effect.fieldPresence.after
    )
  );
}
function placeFieldReversalsWhileRowsExist(effects) {
  if (effects.length === 0) return effects;
  const segments = [];
  let segment;
  let previous;
  for (const effect of effects) {
    if (!segment || !Object.is(previous, effect.turn)) {
      segments.push(segment = []);
      previous = effect.turn;
    }
    segment.push(effect);
  }
  let changed = false;
  const result = [];
  for (const unit of segments) {
    const rows = /* @__PURE__ */ new Map();
    const row = (e) => (e.structural === "add" || e.structural === "remove") && e.subjectId !== void 0;
    const scope = (e) => rows.get(e.owner)?.get(e.subjectId);
    for (const e of unit)
      if (row(e)) {
        let owners = rows.get(e.owner);
        if (!owners) rows.set(e.owner, owners = /* @__PURE__ */ new Map());
        const existing = owners.get(e.subjectId);
        if (existing && existing.kind !== e.structural) existing.mixed = true;
        if (!existing)
          owners.set(e.subjectId, {
            kind: e.structural,
            fields: [],
            mixed: false
          });
      }
    for (const e of unit)
      if (e.structural === void 0 && e.subjectId !== void 0) {
        const entry = scope(e);
        if (entry && !entry.mixed) entry.fields.push(e);
      }
    const ordered = [];
    for (const e of unit) {
      const candidate = scope(e);
      const entry = candidate?.mixed ? void 0 : candidate;
      if (e.structural === void 0 && e.subjectId !== void 0 && entry)
        continue;
      if (row(e) && e.structural === "remove" && entry) {
        for (const field of entry.fields) ordered.push(field);
        entry.fields = [];
      }
      ordered.push(e);
      if (row(e) && e.structural === "add" && entry) {
        for (const field of entry.fields) ordered.push(field);
        entry.fields = [];
      }
    }
    changed ||= ordered.some((effect, index) => effect !== unit[index]);
    for (const effect of ordered) result.push(effect);
  }
  return changed ? result : effects;
}
function rollbackAddressKey(effect) {
  if (effect.plainBranchMembership !== void 0) {
    return `${String(effect.owner)}\0membership`;
  }
  if (effect.structural === "rekey" && effect.subjectId !== void 0) {
    return JSON.stringify([effect.owner, effect.subjectId, "rekey"]);
  }
  if (effect.subjectFieldSegments !== void 0) {
    return JSON.stringify([
      effect.owner,
      effect.subjectId,
      effect.subjectFieldSegments
    ]);
  }
  return hasInlineScopedLeafAddress(effect) ? `${String(effect.owner)}\0${effect.path}` : String(effect.owner);
}
function createPendingRollbackEffect(effect, turnId, realizationContext) {
  const structural = deriveCompensationStructuralEffect(effect.structural);
  if (effect.structural !== void 0) {
    return {
      owner: effect.owner,
      before: deriveStructuralRollbackBefore(effect),
      after: deriveStructuralRollbackAfter(effect),
      subjectId: effect.subjectId,
      subjectFieldSegments: effect.subjectFieldSegments,
      plainBranchMembership: effect.plainBranchMembership ? {
        before: effect.plainBranchMembership.after,
        after: effect.plainBranchMembership.before
      } : void 0,
      fieldPresence: effect.fieldPresence ? {
        before: effect.fieldPresence.after,
        after: effect.fieldPresence.before
      } : void 0,
      structural,
      structuralContext: effect.structuralContext
    };
  }
  if (effect.plainBranchMembership !== void 0 || hasInlineScopedLeafAddress(effect)) {
    return {
      owner: effect.owner,
      before: effect.after,
      after: effect.before,
      subjectId: effect.subjectId,
      subjectFieldSegments: effect.subjectFieldSegments,
      plainBranchMembership: effect.plainBranchMembership ? {
        before: effect.plainBranchMembership.after,
        after: effect.plainBranchMembership.before
      } : void 0,
      fieldPresence: effect.fieldPresence ? {
        before: effect.fieldPresence.after,
        after: effect.fieldPresence.before
      } : void 0,
      path: effect.path,
      ownerPath: effect.ownerPath,
      structural,
      structuralContext: effect.structuralContext
    };
  }
  return {
    owner: effect.owner,
    before: realizationContext.getCurrentValue(effect.owner),
    after: realizationContext.getValueWithoutPendingTurn(turnId, effect.owner),
    subjectId: effect.subjectId,
    subjectFieldSegments: effect.subjectFieldSegments,
    fieldPresence: effect.fieldPresence ? {
      before: effect.fieldPresence.after,
      after: effect.fieldPresence.before
    } : void 0,
    structural,
    structuralContext: effect.structuralContext
  };
}
function hasInlineScopedLeafAddress(effect) {
  if (effect.subjectFieldSegments !== void 0) return true;
  return effect.structural === void 0 && effect.path !== effect.ownerPath;
}
function deriveStructuralRollbackBefore(effect) {
  switch (effect.structural) {
    case "add":
    case "rekey":
      return effect.after;
    case "remove":
      return effect.after;
    default:
      return effect.before;
  }
}
function deriveStructuralRollbackAfter(effect) {
  switch (effect.structural) {
    case "add":
      return effect.before;
    case "remove":
    case "rekey":
      return effect.before;
    default:
      return effect.after;
  }
}
function hasLaterStructuralDependency(pendingTurn, store) {
  const laterTurns = [...store.getTurns(), ...store.getPendingTurns()].filter(
    (turn) => turn.id > pendingTurn.id
  );
  return pendingTurn.effects.some((pendingEffect) => {
    if (!pendingEffect.structural || !pendingEffect.subjectId) {
      return false;
    }
    if (pendingEffect.structural === "add") {
      return laterTurns.some(
        (turn) => turn.effects.some((effect) => sameSubjectScope(effect, pendingEffect))
      );
    }
    const restoredStructuralResource = getRestoredStructuralResource(pendingEffect);
    if (restoredStructuralResource !== void 0 && laterTurns.some(
      (turn) => turn.effects.some(
        (effect) => getAcquiredStructuralResource(effect) === restoredStructuralResource && sameStructuralScope(effect, pendingEffect)
      )
    )) {
      return true;
    }
    return laterTurns.some(
      (turn) => turn.effects.some(
        (effect) => effect.structural !== void 0 && sameSubjectScope(effect, pendingEffect)
      )
    );
  });
}
function sameSubjectScope(left, right) {
  if (left.subjectId !== right.subjectId) {
    return false;
  }
  const leftOwnerPath = left.ownerPath;
  const rightOwnerPath = right.ownerPath;
  return typeof leftOwnerPath === "string" && typeof rightOwnerPath === "string" ? leftOwnerPath === rightOwnerPath : true;
}
function sameStructuralScope(left, right) {
  const leftOwnerPath = left.ownerPath;
  const rightOwnerPath = right.ownerPath;
  return typeof leftOwnerPath === "string" && typeof rightOwnerPath === "string" ? leftOwnerPath === rightOwnerPath : left.owner === right.owner;
}
function getRestoredStructuralResource(effect) {
  switch (effect.structural) {
    case "remove":
    case "rekey":
      return effect.before;
    default:
      return void 0;
  }
}
function getAcquiredStructuralResource(effect) {
  switch (effect.structural) {
    case "add":
    case "rekey":
      return effect.after;
    default:
      return void 0;
  }
}
function deriveCompensationStructuralEffect(structural) {
  switch (structural) {
    case "add":
      return "remove";
    case "remove":
      return "add";
    case "rekey":
      return "rekey";
    default:
      return void 0;
  }
}
function mapDiscardFailure(result) {
  if (result.reason === "turn-evicted") {
    return { ok: false, refusal: { kind: "turn-evicted" } };
  }
  return { ok: false, refusal: { kind: "turn-evicted" } };
}
function normalizeError(error) {
  if (error instanceof Error) {
    return error;
  }
  return new Error(String(error));
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/exposed-publication.ts
function publishingExposedOnly(root, run2) {
  const notifier = getPathNotifier();
  const outer = notifier.absentRealized;
  notifier.absentRealized = (positionIds, meta) => meta?.participation === "realized" && positionIds?.[0] !== void 0 && !!hidingMembers(root, positionIds[0])?.length;
  try {
    return run2();
  } finally {
    notifier.absentRealized = outer;
  }
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/post-application-failure.ts
var AppliedDeliveryFailure = class {
  constructor(cause) {
    this.cause = cause;
  }
};
function applicationFailureCause(error) {
  return error instanceof AppliedDeliveryFailure ? error.cause : error;
}
function applyInInvalidationGroup(root, apply) {
  const locations = getLocationRuntime(root);
  let applied = false;
  try {
    const run2 = () => {
      apply();
      applied = true;
    };
    if (locations) locations.runInvalidationGroup(run2);
    else run2();
  } catch (error) {
    const cause = applicationFailureCause(error);
    throw applied ? new AppliedDeliveryFailure(cause) : cause;
  }
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/subject-restoration-claims.ts
function createSubjectRestorationClaims() {
  const byOwner = /* @__PURE__ */ new Map();
  const bySubject = /* @__PURE__ */ new Map();
  function addClaim(owner, subjectId) {
    let owners = bySubject.get(subjectId);
    if (!owners) {
      owners = /* @__PURE__ */ new Set();
      bySubject.set(subjectId, owners);
    }
    owners.add(owner);
  }
  function dropClaim(owner, subjectId) {
    const owners = bySubject.get(subjectId);
    if (!owners) {
      return false;
    }
    owners.delete(owner);
    if (owners.size > 0) {
      return false;
    }
    bySubject.delete(subjectId);
    return true;
  }
  return {
    retain(owner, subjects) {
      const next = new Set(subjects);
      const previous = byOwner.get(owner);
      const newlyUnowned = [];
      if (previous) {
        for (const subjectId of previous) {
          if (next.has(subjectId)) {
            continue;
          }
          if (dropClaim(owner, subjectId)) {
            newlyUnowned.push(subjectId);
          }
        }
      }
      if (next.size === 0) {
        byOwner.delete(owner);
        return newlyUnowned;
      }
      for (const subjectId of next) {
        addClaim(owner, subjectId);
      }
      byOwner.set(owner, next);
      return newlyUnowned;
    },
    release(owner) {
      const held = byOwner.get(owner);
      if (!held) {
        return [];
      }
      byOwner.delete(owner);
      const newlyUnowned = [];
      for (const subjectId of held) {
        if (dropClaim(owner, subjectId)) {
          newlyUnowned.push(subjectId);
        }
      }
      return newlyUnowned;
    },
    releaseAll() {
      const released = [...bySubject.keys()];
      byOwner.clear();
      bySubject.clear();
      return released;
    },
    isClaimed(subjectId) {
      return bySubject.has(subjectId);
    },
    ownersOf(subjectId) {
      const owners = bySubject.get(subjectId);
      return owners ? [...owners] : [];
    },
    claimedSubjects() {
      return [...bySubject.keys()];
    },
    snapshot() {
      return { owners: byOwner.size, claimedSubjects: bySubject.size };
    }
  };
}
var SUBJECT_RESTORATION_CLAIMS_SYMBOL = Symbol.for(
  "SignalTree:SubjectRestorationClaims"
);
function getOrCreateSubjectRestorationClaims(node) {
  const existing = getSubjectRestorationClaims(node);
  if (existing) {
    return existing;
  }
  const host = node?.$ ?? node;
  if (!isTraversableNode(host)) {
    return void 0;
  }
  const claims = createSubjectRestorationClaims();
  defineSubjectRestorationClaims(host, claims);
  return claims;
}
function defineSubjectRestorationClaims(node, claims) {
  Object.defineProperty(node, SUBJECT_RESTORATION_CLAIMS_SYMBOL, {
    value: claims,
    enumerable: false,
    configurable: true
  });
}
function getSubjectRestorationClaims(node) {
  return read(node) ?? read(node?.$);
}
function read(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[SUBJECT_RESTORATION_CLAIMS_SYMBOL];
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/intercept-leaf-signals.ts
function interceptLeafSignals(root, onWrite, options = {}) {
  const restorers = [];
  const maxDepth = options.maxDepth ?? 32;
  const withMutationIntent = (meta, mutationIntent) => ({
    ...meta ?? {},
    mutationIntent
  });
  const getOwnerPath = (node, path) => {
    return getOwnedOwnerPath(node) ?? path;
  };
  const getSubjectIds = (node) => {
    return getOwnedSubjectIds(node);
  };
  const getPositionIds = (node) => {
    return getOwnedPositionIds(node);
  };
  const wrapWritableSignal = (node, path, ownerPathOverride) => {
    const original = node;
    const originalSet = original.set.bind(original);
    const originalUpdate = original.update.bind(original);
    restorers.push(() => {
      original.set = originalSet;
      original.update = originalUpdate;
    });
    original.set = (value) => {
      const prev = original();
      originalSet(value);
      const next = original();
      const ownerPath = ownerPathOverride ?? getOwnerPath(node, path);
      const subjectIds = getSubjectIds(node);
      const positionIds = getPositionIds(node);
      if (next !== prev) {
        onWrite(
          path,
          next,
          prev,
          withMutationIntent(getActiveWriteContext(), "replace"),
          ownerPath,
          subjectIds,
          positionIds
        );
      }
    };
    original.update = (updater) => {
      const prev = original();
      originalUpdate(updater);
      const next = original();
      const ownerPath = ownerPathOverride ?? getOwnerPath(node, path);
      const subjectIds = getSubjectIds(node);
      const positionIds = getPositionIds(node);
      if (next !== prev) {
        onWrite(
          path,
          next,
          prev,
          withMutationIntent(getActiveWriteContext(), "derive"),
          ownerPath,
          subjectIds,
          positionIds
        );
      }
    };
  };
  const observeLocation = (node, path, ownerPathOverride, normal = true) => {
    const release = normal ? observeIntrinsicMutations(node, (mutation) => {
      if (!mutation.changed) return;
      onWrite(
        path,
        mutation.after,
        mutation.before,
        withMutationIntent(getActiveWriteContext(), mutation.intent),
        ownerPathOverride ?? getOwnerPath(node, path),
        getSubjectIds(node),
        getPositionIds(node)
      );
    }) : void 0;
    const terminalRecord = options.terminalRecord;
    if (terminalRecord) {
      const terminalRelease = prepareTerminalMutations(node, (mutation) => {
        if (!mutation.changed) return;
        return terminalRecord.call(options, path, mutation.after, mutation.before, withMutationIntent(getActiveWriteContext(), mutation.intent), ownerPathOverride ?? getOwnerPath(node, path), getSubjectIds(node), getPositionIds(node));
      });
      if (terminalRelease) restorers.push(terminalRelease);
    }
    const beforePublication = options.beforePublication;
    if (beforePublication) {
      const captureRelease = observeIntrinsicMutations(node, (mutation) => {
        if (!mutation.changed) return;
        beforePublication.call(
          options,
          path,
          mutation.after,
          mutation.before,
          withMutationIntent(getActiveWriteContext(), mutation.intent),
          ownerPathOverride ?? getOwnerPath(node, path),
          getSubjectIds(node),
          getPositionIds(node)
        );
      }, true);
      if (captureRelease) restorers.push(captureRelease);
    }
    if (release) restorers.push(release);
  };
  const wrapOwnedFieldAccessors = (node, basePath, ownerPath, seen = /* @__PURE__ */ new WeakSet()) => {
    if (!isTraversableNode(node)) {
      return;
    }
    const ref = node;
    if (seen.has(ref)) return;
    seen.add(ref);
    const isWritableSignal = typeof node === "function" && "set" in node && "update" in node && // eslint-disable-next-line @typescript-eslint/no-explicit-any
    typeof node.set === "function" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
    typeof node.update === "function";
    if (isWritableSignal) {
      wrapWritableSignal(node, basePath, ownerPath);
    }
    for (const key of Object.keys(node)) {
      const child = node[key];
      if (child !== null && typeof child === "object" && !(Array.isArray(child) || child instanceof Date || child instanceof Map || child instanceof Set)) {
        wrapOwnedFieldAccessors(child, `${basePath}.${key}`, ownerPath, seen);
      } else if (typeof child === "function") {
        wrapOwnedFieldAccessors(child, `${basePath}.${key}`, ownerPath, seen);
      }
    }
  };
  const wrapMutator = (target, method, path) => {
    if (typeof target[method] !== "function") return;
    const originalMethod = target[method].bind(target);
    restorers.push(() => {
      target[method] = originalMethod;
    });
    target[method] = (...args) => {
      const canSnapshotMutatorState = typeof target.__findKeyBySubjectId !== "function";
      const prevSnapshot = canSnapshotMutatorState ? snapshotMarkerNode(target)?.value : void 0;
      const result = originalMethod(...args);
      const nextSnapshot = canSnapshotMutatorState ? snapshotMarkerNode(target)?.value : void 0;
      onWrite(
        path,
        nextSnapshot,
        prevSnapshot,
        getActiveWriteContext(),
        path,
        getSubjectIds(target),
        getPositionIds(target)
      );
      return result;
    };
  };
  try {
    visitTree(
      root,
      (node, path) => {
        if (path === "") return true;
        if (isWritableLocation(node)) {
          if (!hasIntrinsicMutationEmitter(node) || options.beforePublication) {
            observeLocation(node, path, void 0, !hasIntrinsicMutationEmitter(node));
          }
          return false;
        }
        const isWritableSignal = typeof node === "function" && "set" in node && "update" in node && // eslint-disable-next-line @typescript-eslint/no-explicit-any
        typeof node.set === "function" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
        typeof node.update === "function";
        if (isWritableSignal) {
          const isEntityCollection = "add" in node || "remove" in node;
          if (isEntityCollection) return false;
          const hasOwnedMutationEmitter = hasIntrinsicMutationEmitter(node);
          if (hasOwnedMutationEmitter) {
            return false;
          }
          wrapWritableSignal(node, path);
          const proc2 = getNodeProcessor(node);
          if (proc2 && isTraversableNode(node)) {
            for (const method of ["clear", "reload", "reset", "refresh"]) {
              wrapMutator(node, method, path);
            }
          }
          return false;
        }
        const proc = getNodeProcessor(node);
        if (proc && hasIntrinsicMutationEmitter(node)) {
          return false;
        }
        if (proc && isTraversableNode(node)) {
          const marker = node;
          const MUTATORS = [
            "set",
            "patch",
            "setAll",
            "addOne",
            "addMany",
            "prependMany",
            "updateOne",
            "updateMany",
            "upsertOne",
            "upsertMany",
            "changeId",
            "removeOne",
            "removeMany",
            "clear",
            "setLoading",
            "setLoaded",
            "setError",
            "setNotLoaded",
            "start",
            "setSuccess",
            "succeed",
            "fail",
            "refresh",
            "rerun",
            "reset"
          ];
          for (const method of MUTATORS) {
            wrapMutator(marker, method, path);
          }
          const fields = marker.$;
          if (fields && isTraversableNode(fields)) {
            wrapOwnedFieldAccessors(fields, path, path);
          }
          return false;
        }
        if (typeof node === "object" && (Array.isArray(node) || node instanceof Date || node instanceof Map || node instanceof Set)) {
          return false;
        }
        return true;
      },
      { maxDepth }
    );
  } catch {
  }
  return () => {
    for (const restore of restorers) {
      try {
        restore();
      } catch {
      }
    }
    restorers.length = 0;
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/physical/prepare-structural-target.ts
function prepareStructuralTarget(sourceStates, sourceRevisions, subjects, order, orderFrontier) {
  const subjectIds = /* @__PURE__ */ new Map();
  const targetBySubject = /* @__PURE__ */ new Map();
  for (const subject of subjects) {
    if (targetBySubject.has(subject.subjectId) || subjectIds.has(subject.key)) {
      throw new Error("Structural target contains duplicate identity or key");
    }
    const current = sourceStates.get(subject.subjectId);
    if (!current || !current.active && !current.restoreAllowed) {
      throw new Error(
        `Subject ${subject.subjectId} cannot enter the structural target`
      );
    }
    targetBySubject.set(subject.subjectId, subject);
    subjectIds.set(subject.key, subject.subjectId);
  }
  if (order.length !== targetBySubject.size || new Set(order).size !== order.length || order.some((subjectId) => !targetBySubject.has(subjectId))) {
    throw new Error(
      "Structural target order does not match its active subjects"
    );
  }
  const subjectStates = new Map(sourceStates);
  const subjectRevisions = new Map(sourceRevisions);
  for (const [subjectId, current] of sourceStates) {
    const target = targetBySubject.get(subjectId);
    if (!target) {
      if (current.active) {
        subjectStates.set(subjectId, {
          active: false,
          restoreAllowed: current.restoreAllowed
        });
        subjectRevisions.set(
          subjectId,
          (sourceRevisions.get(subjectId) ?? 0) + 1
        );
      }
      continue;
    }
    if (!current.active || current.key !== target.key) {
      subjectRevisions.set(
        subjectId,
        (sourceRevisions.get(subjectId) ?? 0) + 1
      );
    }
    subjectStates.set(subjectId, {
      active: true,
      key: target.key,
      restoreAllowed: current.restoreAllowed
    });
  }
  const activeNodesByKey = /* @__PURE__ */ new Map();
  const activeNodesBySubject = /* @__PURE__ */ new Map();
  let activeHead;
  let activeTail;
  for (const subjectId of order) {
    const target = targetBySubject.get(subjectId);
    const node = {
      key: target.key,
      subjectId,
      prev: activeTail,
      next: void 0
    };
    if (activeTail) {
      activeTail.next = node;
    } else {
      activeHead = node;
    }
    activeTail = node;
    activeNodesByKey.set(node.key, node);
    activeNodesBySubject.set(node.subjectId, node);
  }
  return {
    subjectIds,
    subjectStates,
    subjectRevisions,
    activeNodesByKey,
    activeNodesBySubject,
    activeHead,
    activeTail,
    activeCount: order.length,
    orderFrontier
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/physical/prepare-entity-target.ts
function prepareEntityTransitionTarget(host, target) {
  const {
    positionId,
    structuralStore,
    valueStore,
    activeIdSignal,
    subjectEpochs,
    subjectStateSignals,
    advanceEpochHandle,
    updateSignals,
    physicalCommitClock,
    pathNotifier,
    basePath,
    getPositionIdsForNotify,
    createStructuralEffectMeta,
    ambientMeta,
    emitTap
  } = host;
  if (positionId === void 0 || target.owner !== positionId) {
    throw new Error(
      "Collection transition target owner does not match the binding"
    );
  }
  const beforeOrderFrontier = structuralStore.activeOrderFrontier();
  const currentSubjects = /* @__PURE__ */ new Map();
  const activeIdBefore = activeIdSignal();
  const activeSubjectBefore = activeIdBefore === void 0 ? void 0 : structuralStore.subjectIdForKey(activeIdBefore);
  for (const key of structuralStore.activeKeysSnapshot()) {
    const subjectId = structuralStore.subjectIdForKey(key);
    const value = subjectId === void 0 ? void 0 : valueStore.backingForSubject(subjectId);
    if (subjectId !== void 0 && value !== void 0) {
      currentSubjects.set(subjectId, { key, value });
    }
  }
  const beforeOrder = [...currentSubjects.keys()];
  const afterOrder = [...target.order];
  const preparedSubjects = target.subjects.map((subject) => {
    if (subject.value === null || typeof subject.value !== "object" || Array.isArray(subject.value)) {
      throw new Error(
        `Collection target subject ${subject.subject} has no entity value`
      );
    }
    return {
      subjectId: subject.subject,
      key: subject.key,
      value: deepClone(subject.value)
    };
  });
  const structuralTarget = structuralStore.prepareTarget(
    preparedSubjects,
    target.order,
    target.orderFrontier,
    prepareStructuralTarget
  );
  const valueTarget = valueStore.prepareTargetValues(preparedSubjects);
  const affectedSubjects = /* @__PURE__ */ new Set([
    ...currentSubjects.keys(),
    ...preparedSubjects.map(({ subjectId }) => subjectId)
  ]);
  const preparedBySubject = new Map(
    preparedSubjects.map((subject) => [subject.subjectId, subject])
  );
  const activeIdAfter = (activeSubjectBefore === void 0 ? void 0 : preparedBySubject.get(activeSubjectBefore)?.key) ?? activeIdBefore;
  const targetNeighborBySubject = new Map(
    target.order.map((subjectId, index) => [
      subjectId,
      {
        beforeSubject: target.order[index - 1],
        afterSubject: target.order[index + 1]
      }
    ])
  );
  const subjectChanges = [...affectedSubjects].map((subjectId) => {
    const before = currentSubjects.get(subjectId);
    const after = preparedBySubject.get(subjectId);
    return {
      subjectId,
      beforeKey: before?.key,
      afterKey: after?.key,
      beforeValue: before?.value,
      valueEpoch: subjectEpochs.get(subjectId),
      stateSignal: subjectStateSignals.get(subjectId)?.deref(),
      afterValue: after?.value,
      bindingChanged: !before || !after || before.key !== after.key,
      targetNeighbors: targetNeighborBySubject.get(subjectId)
    };
  });
  return {
    install() {
      const tap = host.membershipTap;
      tap?.(MEMBERSHIP_OPEN_ORDER);
      try {
        structuralStore.installPreparedTarget(structuralTarget);
        valueStore.installPreparedTargetValues(valueTarget);
        if (activeIdBefore !== activeIdAfter) {
          replaceLocation(activeIdSignal, activeIdAfter);
        }
      } finally {
        tap?.(MEMBERSHIP_CLOSE);
      }
    },
    publishOrder() {
      host.publishOrderChange(beforeOrder, afterOrder, beforeOrderFrontier, target.orderFrontier);
    },
    publish(options) {
      for (const publication of subjectChanges) {
        if (publication.valueEpoch) advanceEpochHandle(publication.valueEpoch);
        if (publication.bindingChanged) {
          if (publication.stateSignal) {
            deriveLocation(publication.stateSignal, (value) => value + 1);
          }
        }
      }
      updateSignals();
      if (options?.advancePhysicalRevision !== false) {
        physicalCommitClock?.advance();
      }
      for (const publication of subjectChanges) {
        const key = publication.afterKey ?? publication.beforeKey;
        if (key === void 0) {
          continue;
        }
        const structuralEffect = publication.beforeKey === void 0 ? {
          kind: "add",
          subject: publication.subjectId,
          key,
          value: publication.afterValue,
          ...publication.targetNeighbors
        } : publication.afterKey === void 0 ? {
          kind: "remove",
          subject: publication.subjectId,
          key,
          value: publication.beforeValue
        } : publication.beforeKey !== publication.afterKey ? {
          kind: "rekey",
          subject: publication.subjectId,
          beforeKey: publication.beforeKey,
          afterKey: publication.afterKey
        } : void 0;
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          publication.afterValue,
          publication.beforeValue,
          basePath,
          [publication.subjectId],
          getPositionIdsForNotify(),
          {
            ...structuralEffect ? createStructuralEffectMeta(structuralEffect) : ambientMeta(),
            // Replay publishes retained storage too. Apply the same exposed
            // path protocol as the ordinary realization adapter, without
            // changing the ambient context of subsequent application taps.
            intent: "system",
            participation: "realized"
          }
        );
        const { beforeValue, afterValue } = publication;
        const kind = structuralEffect?.kind;
        if (kind === "add") emitTap("onAdd", afterValue, key);
        else if (kind === "remove") emitTap("onRemove", key, beforeValue);
        else if (!kind && !deepEqual(beforeValue, afterValue))
          emitTap("onUpdate", key, afterValue, afterValue);
      }
    }
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/utilities/append-all.ts
function appendAll(target, items) {
  for (let i = 0; i < items.length; i++) target.push(items[i]);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/target-transition.ts
function prepareDeclarativeTransitionInstallation(target, bindings, scalarBinding, memberBinding2, completion) {
  const prepared = [];
  let scalars = target.scalars;
  if (target.plainBranchMembers?.size) {
    if (!memberBinding2)
      throw new Error(
        "Declarative transition has member targets but no member binding"
      );
    const members = memberBinding2.prepareTarget(target.plainBranchMembers);
    prepared.push(members);
    scalars = withoutSupersededScalars(
      target.scalars,
      target.scalarTurns,
      members.staged
    );
  }
  for (const [owner, collection] of target.collections) {
    const binding = bindings.get(owner);
    if (!binding || binding.owner !== owner) {
      throw new Error(
        `Declarative transition has no collection binding ${owner}`
      );
    }
    prepared.push(binding.prepareTarget(collection, prepareEntityTransitionTarget));
  }
  if (scalars.size > 0) {
    if (!scalarBinding) {
      throw new Error(
        "Declarative transition has scalar targets but no scalar binding"
      );
    }
    prepared.push(scalarBinding.prepareTarget(scalars));
  }
  return {
    install() {
      for (const collection of prepared) {
        collection.install();
      }
      completion?.onCommitted();
      let failed = false;
      let first;
      for (const collection of prepared) {
        try {
          collection.publishOrder?.();
        } catch (error) {
          if (!failed) {
            failed = true;
            first = error;
          }
        }
      }
      for (const collection of prepared) {
        try {
          collection.publish();
        } catch (error) {
          if (!failed) {
            failed = true;
            first = error;
          }
        }
      }
      if (failed) throw first;
    }
  };
}
function withoutSupersededScalars(scalars, scalarTurns, staged) {
  if (!scalarTurns?.size || !staged?.size) return scalars;
  let kept;
  for (const [owner, turn] of scalarTurns) {
    const stagedTurn = staged.get(owner);
    if (stagedTurn === void 0 || stagedTurn <= turn) continue;
    kept ??= new Map(scalars);
    kept.delete(owner);
  }
  return kept ?? scalars;
}
var CollectionOrderConflict = class extends Error {
  constructor(owner, reason, failure) {
    super(failure.message);
    this.owner = owner;
    this.reason = reason;
    this.name = "CollectionOrderConflict";
  }
};
var ORDER_FAILURES = [
  [
    "frontier does not match the transition endpoint",
    "the order change being reversed no longer applies to its current order"
  ],
  [
    "no live placement anchor",
    "a restored row's recorded neighbours are no longer in it"
  ],
  [
    "Collection order does not match active SubjectIds",
    "its reconstructed order and its rows disagree"
  ],
  ["contains an anchor cycle", "its rows' recorded neighbours form a cycle"],
  [
    "contains contradictory anchors",
    "its rows' recorded neighbours contradict each other"
  ]
];
function asOrderConflict(owner, failure) {
  if (!(failure instanceof Error) || failure instanceof CollectionOrderConflict)
    return failure;
  const known = ORDER_FAILURES.find(
    ([message]) => failure.message.includes(message)
  );
  return known ? new CollectionOrderConflict(owner, known[1], failure) : failure;
}
function requiresDeclarativeStructuralTarget(effects, readSource) {
  const structural = effects.filter(
    (effect) => effect.structural !== void 0
  );
  const occupiedKeyOf = (effect) => effect.structural === "add" || effect.structural === "rekey" ? effect.after : void 0;
  const occupying = /* @__PURE__ */ new Map();
  structural.forEach((effect, index) => {
    const key = occupiedKeyOf(effect);
    if (key === void 0) return;
    let byKey = occupying.get(effect.owner);
    if (!byKey) occupying.set(effect.owner, byKey = /* @__PURE__ */ new Map());
    const indices = byKey.get(key);
    if (indices) indices.push(index);
    else byKey.set(key, [index]);
  });
  const hasKeyHandoff = structural.some((vacating, vacatingIndex) => {
    const vacatedKey = vacating.structural === "remove" || vacating.structural === "rekey" ? vacating.before : void 0;
    if (vacatedKey === void 0) {
      return false;
    }
    const candidates = occupying.get(vacating.owner)?.get(vacatedKey);
    return candidates?.some(
      (occupyingIndex) => occupyingIndex !== vacatingIndex && Object.is(vacatedKey, occupiedKeyOf(structural[occupyingIndex]))
    ) ?? false;
  });
  if (hasKeyHandoff) {
    return true;
  }
  const additions = structural.filter(
    (effect) => effect.structural === "add" && typeof effect.subjectId === "number"
  );
  if (additions.length < 2) {
    const addition = additions[0];
    const context = addition?.structuralContext;
    if (readSource && (context?.kind === "remove" || context?.kind === "add") && (context.beforeSubject !== void 0 || context.afterSubject !== void 0)) {
      const source = readSource(addition.owner);
      return ![context.beforeSubject, context.afterSubject].some(
        (anchor) => anchor !== void 0 && source?.order.includes(anchor)
      );
    }
    return false;
  }
  const addedSubjects = /* @__PURE__ */ new Map();
  for (const addition of additions) {
    if (typeof addition.subjectId !== "number") continue;
    let turns = addedSubjects.get(addition.owner);
    if (!turns) addedSubjects.set(addition.owner, turns = /* @__PURE__ */ new Map());
    let subjects = turns.get(addition.turn);
    if (!subjects) turns.set(addition.turn, subjects = /* @__PURE__ */ new Set());
    subjects.add(addition.subjectId);
  }
  return additions.some((effect) => {
    const context = effect.structuralContext;
    if (context?.kind !== "add" && context?.kind !== "remove") {
      return false;
    }
    const subjects = addedSubjects.get(effect.owner)?.get(effect.turn);
    return context.beforeSubject !== void 0 && !subjects?.has(context.beforeSubject) || context.afterSubject !== void 0 && !subjects?.has(context.afterSubject);
  });
}
function deriveDeclarativeTransitionTarget(options) {
  const collections = /* @__PURE__ */ new Map();
  for (const source of options.collections) {
    if (collections.has(source.owner)) {
      throw new Error(`Duplicate collection transition owner ${source.owner}`);
    }
    assertUniqueSubjects(source.order);
    assertUniqueSubjects(source.subjects.map(({ subject }) => subject));
    const subjects = new Map(
      source.subjects.map((subject) => [subject.subject, { ...subject }])
    );
    try {
      assertCollectionOrderMatchesSubjects(source.order, subjects);
    } catch (failure) {
      throw asOrderConflict(source.owner, failure);
    }
    collections.set(source.owner, {
      subjects,
      order: [...source.order],
      sourceSubjects: new Set(subjects.keys())
    });
  }
  const scalars = /* @__PURE__ */ new Map();
  const scalarTurns = /* @__PURE__ */ new Map();
  const plainBranchMembers = /* @__PURE__ */ new Map();
  for (const effect of options.effects) {
    if (effect.plainBranchMembership) {
      plainBranchMembers.delete(effect.owner);
      plainBranchMembers.set(effect.owner, {
        present: effect.plainBranchMembership.after,
        value: effect.after,
        ...effect.turn === void 0 ? {} : { turn: effect.turn }
      });
      continue;
    }
    if (effect.structural === void 0) {
      applyValueEffect(collections, scalars, effect);
      if (typeof effect.subjectId !== "number" && effect.turn !== void 0)
        scalarTurns.set(effect.owner, effect.turn);
      continue;
    }
    try {
      applyStructuralEffect(collections, effect);
    } catch (failure) {
      throw asOrderConflict(effect.owner, failure);
    }
  }
  const orderDeltas = /* @__PURE__ */ new Map();
  for (const delta of options.orderDeltas ?? []) {
    if (orderDeltas.has(delta.owner)) {
      throw new Error(
        `Duplicate collection order delta for owner ${delta.owner}`
      );
    }
    orderDeltas.set(delta.owner, delta);
  }
  const targets = /* @__PURE__ */ new Map();
  for (const [owner, collection] of collections) {
    const delta = orderDeltas.get(owner);
    const orderEndpoint = options.orderEndpoints?.get(owner) ?? options.orderEndpoint ?? "after";
    let order;
    try {
      order = delta ? applyCollectionOrderDelta(
        collection.order,
        delta,
        orderEndpoint,
        options.collections.find((source) => source.owner === owner)?.orderFrontier
      ) : deriveStructuralTargetOrder(
        collection.order,
        collection.subjects,
        options.effects.filter((effect) => effect.owner === owner)
      );
      assertCollectionOrderMatchesSubjects(order, collection.subjects);
    } catch (failure) {
      throw asOrderConflict(owner, failure);
    }
    assertUniqueTargetKeys(collection.subjects);
    targets.set(owner, {
      owner,
      subjects: [...collection.subjects.values()].sort(
        (left, right) => left.subject - right.subject
      ),
      order,
      orderFrontier: delta ? orderEndpoint === "before" ? delta.beforeFrontier : delta.afterFrontier : options.collections.find((source) => source.owner === owner)?.orderFrontier === void 0 || sameSubjects(collection.sourceSubjects, collection.subjects) ? options.collections.find((source) => source.owner === owner)?.orderFrontier : {}
    });
  }
  for (const owner of orderDeltas.keys()) {
    if (!targets.has(owner)) {
      throw new Error(`Collection order delta has no owner ${owner}`);
    }
  }
  return {
    collections: targets,
    scalars,
    ...scalarTurns.size ? { scalarTurns } : {},
    ...plainBranchMembers.size ? { plainBranchMembers } : {}
  };
}
function deriveCollectionOrderDelta(owner, before, after, beforeFrontier, afterFrontier) {
  assertUniqueSubjects(before);
  assertUniqueSubjects(after);
  const beforeRank = indexSubjects(before);
  const afterRank = indexSubjects(after);
  const commonBefore = before.filter((subject) => afterRank.has(subject));
  const commonAfter = after.filter((subject) => beforeRank.has(subject));
  const backbone = lexicographicallySmallestCommonSubsequence(
    commonBefore,
    commonAfter
  );
  const backboneSubjects = new Set(backbone);
  const participants = /* @__PURE__ */ new Map();
  for (const [subject, rank] of beforeRank) {
    if (!backboneSubjects.has(subject)) {
      participants.set(subject, { subject, beforeRank: rank });
    }
  }
  for (const [subject, rank] of afterRank) {
    if (backboneSubjects.has(subject)) {
      continue;
    }
    participants.set(subject, {
      ...participants.get(subject),
      subject,
      afterRank: rank
    });
  }
  return {
    owner,
    beforeLength: before.length,
    afterLength: after.length,
    beforeFrontier,
    afterFrontier,
    participants: [...participants.values()].sort(
      (left, right) => left.subject - right.subject
    )
  };
}
function applyCollectionOrderDelta(current, delta, endpoint, currentFrontier) {
  assertUniqueSubjects(current);
  const sourceEndpoint = endpoint === "before" ? "after" : "before";
  const sourceLength = sourceEndpoint === "before" ? delta.beforeLength : delta.afterLength;
  const sourceFrontier = sourceEndpoint === "before" ? delta.beforeFrontier : delta.afterFrontier;
  if (current.length !== sourceLength || currentFrontier !== sourceFrontier) {
    throw frontierMismatch();
  }
  const currentRank = indexSubjects(current);
  for (const participant of delta.participants) {
    const expectedRank = rankAt(participant, sourceEndpoint);
    if (expectedRank === void 0 && currentRank.has(participant.subject) || expectedRank !== void 0 && current[expectedRank] !== participant.subject) {
      throw frontierMismatch();
    }
  }
  const participantSubjects = new Set(
    delta.participants.map(({ subject }) => subject)
  );
  const backbone = current.filter(
    (subject) => !participantSubjects.has(subject)
  );
  const targetLength = endpoint === "before" ? delta.beforeLength : delta.afterLength;
  const target = new Array(targetLength);
  for (const participant of delta.participants) {
    const rank = rankAt(participant, endpoint);
    if (rank === void 0) {
      continue;
    }
    if (rank < 0 || rank >= targetLength || target[rank] !== void 0) {
      throw frontierMismatch();
    }
    target[rank] = participant.subject;
  }
  let backboneIndex = 0;
  for (let rank = 0; rank < target.length; rank += 1) {
    if (target[rank] !== void 0) {
      continue;
    }
    const subject = backbone[backboneIndex];
    if (subject === void 0) {
      throw frontierMismatch();
    }
    target[rank] = subject;
    backboneIndex += 1;
  }
  if (backboneIndex !== backbone.length) {
    throw frontierMismatch();
  }
  return target;
}
function lexicographicallySmallestCommonSubsequence(before, after) {
  if (before.length === 0 || after.length === 0) {
    return [];
  }
  const afterRank = indexSubjects(after);
  const mappedRanks = before.map((subject) => afterRank.get(subject));
  const suffixLengths = longestIncreasingSuffixLengths(mappedRanks);
  let maximumLength = 0;
  for (const length of suffixLengths) {
    maximumLength = Math.max(maximumLength, length);
  }
  const candidatesByLength = /* @__PURE__ */ new Map();
  for (let index = 0; index < before.length; index += 1) {
    const length = suffixLengths[index];
    const candidates = candidatesByLength.get(length) ?? [];
    candidates.push(index);
    candidatesByLength.set(length, candidates);
  }
  for (const candidates of candidatesByLength.values()) {
    candidates.sort((left, right) => before[left] - before[right]);
  }
  const result = [];
  let previousBeforeIndex = -1;
  let previousAfterRank = -1;
  for (let remaining = maximumLength; remaining > 0; remaining -= 1) {
    const candidates = candidatesByLength.get(remaining) ?? [];
    const selected = candidates.find(
      (index) => index > previousBeforeIndex && mappedRanks[index] > previousAfterRank
    );
    if (selected === void 0) {
      throw new Error("Unable to derive a canonical collection order backbone");
    }
    result.push(before[selected]);
    previousBeforeIndex = selected;
    previousAfterRank = mappedRanks[selected];
  }
  return result;
}
function applyStructuralEffect(collections, effect) {
  const collection = collections.get(effect.owner);
  if (!collection || typeof effect.subjectId !== "number") {
    throw new Error(
      `Structural effect has no collection target ${effect.owner}`
    );
  }
  const subject = effect.subjectId;
  if (effect.structural === "add") {
    if (collection.subjects.has(subject)) {
      throw new Error(
        `Subject ${subject} is already active in owner ${effect.owner}`
      );
    }
    const key2 = effect.after;
    if (typeof key2 !== "string" && typeof key2 !== "number") {
      throw new Error(`Restored subject ${subject} has no target key`);
    }
    collection.subjects.set(subject, {
      subject,
      key: key2,
      value: structuralValue(effect)
    });
    return;
  }
  const existing = collection.subjects.get(subject);
  if (!existing) {
    throw new Error(
      `Subject ${subject} is not active in owner ${effect.owner}`
    );
  }
  if (effect.structural === "remove") {
    if (existing.key !== effect.before) {
      throw new Error(`Subject ${subject} is not at its expected source key`);
    }
    collection.subjects.delete(subject);
    return;
  }
  if (existing.key !== effect.before) {
    throw new Error(`Subject ${subject} is not at its expected source key`);
  }
  const key = effect.after;
  if (typeof key !== "string" && typeof key !== "number") {
    throw new Error(`Rekeyed subject ${subject} has no target key`);
  }
  collection.subjects.set(subject, { ...existing, key });
}
function deriveStructuralTargetOrder(sourceOrder, subjects, effects) {
  if (effects.some((effect) => effect.turn !== void 0))
    return replayStructuralOrderByTurn(sourceOrder, subjects, effects);
  return applyTurnOrder(
    [...sourceOrder],
    effects,
    (subject) => subjects.has(subject)
  ).filter((subject) => subjects.has(subject));
}
function replayStructuralOrderByTurn(sourceOrder, subjects, effects) {
  let order = [...sourceOrder];
  const turns = /* @__PURE__ */ new Map();
  for (const effect of effects) {
    if (effect.structural !== "add" && effect.structural !== "remove" || typeof effect.subjectId !== "number")
      continue;
    let turn = turns.get(effect.turn);
    if (!turn) turns.set(effect.turn, turn = []);
    turn.push(effect);
  }
  for (const turn of turns.values()) {
    const removed = netRemovals(turn);
    order = applyTurnOrder(
      order,
      turn,
      (subject) => !removed.has(subject)
    ).filter((subject) => !removed.has(subject));
  }
  return order.filter((subject) => subjects.has(subject));
}
function netRemovals(turn) {
  const removed = /* @__PURE__ */ new Set();
  for (const effect of turn) {
    const subject = effect.subjectId;
    if (effect.structural === "remove") removed.add(subject);
    else if (effect.structural === "add") removed.delete(subject);
  }
  return removed;
}
function applyTurnOrder(order, effects, survives) {
  const additions = effects.filter(
    (effect) => effect.structural === "add" && typeof effect.subjectId === "number"
  );
  const added = new Set(additions.map((effect) => effect.subjectId));
  const next = order.filter((subject) => !added.has(subject));
  placeAdditions(next, additions, survives);
  return next;
}
function placeAdditions(order, additions, survives) {
  const pending = [...additions];
  while (pending.length > 0) {
    const pendingSubjects = new Set(
      pending.map((effect2) => effect2.subjectId)
    );
    const waitsOnPending = (effect2) => {
      const context2 = effect2.structuralContext;
      return (context2?.kind === "add" || context2?.kind === "remove") && (context2.beforeSubject !== void 0 && pendingSubjects.has(context2.beforeSubject) || context2.afterSubject !== void 0 && pendingSubjects.has(context2.afterSubject));
    };
    const unblockedIndex = pending.findIndex(
      (effect2) => !waitsOnPending(effect2)
    );
    const readyIndex = unblockedIndex >= 0 ? unblockedIndex : pending.findIndex((effect2) => {
      const context2 = effect2.structuralContext;
      if (context2?.kind !== "add" && context2?.kind !== "remove") {
        return true;
      }
      const beforeLive = context2.beforeSubject !== void 0 && order.includes(context2.beforeSubject);
      const afterLive = context2.afterSubject !== void 0 && order.includes(context2.afterSubject);
      if (beforeLive || afterLive) {
        return true;
      }
      const hasNoAnchors = context2.beforeSubject === void 0 && context2.afterSubject === void 0;
      if (hasNoAnchors) {
        return true;
      }
      const anchorMayBecomeLive = context2.beforeSubject !== void 0 && pendingSubjects.has(context2.beforeSubject) || context2.afterSubject !== void 0 && pendingSubjects.has(context2.afterSubject);
      return !anchorMayBecomeLive;
    });
    if (readyIndex < 0) {
      if (!order.some(survives)) {
        appendAll(order, derivePendingAnchorOrder(pending));
        pending.length = 0;
        continue;
      }
      throw new Error("Collection structural target contains an anchor cycle");
    }
    const effect = pending.splice(readyIndex, 1)[0];
    const subject = effect.subjectId;
    const context = effect.structuralContext;
    const beforeSubject = context?.kind === "add" || context?.kind === "remove" ? context.beforeSubject : void 0;
    const afterSubject = context?.kind === "add" || context?.kind === "remove" ? context.afterSubject : void 0;
    const afterIndex = afterSubject === void 0 ? -1 : order.indexOf(afterSubject);
    const beforeIndex = beforeSubject === void 0 ? -1 : order.indexOf(beforeSubject);
    if (beforeIndex >= 0 && afterIndex >= 0 && beforeIndex >= afterIndex) {
      throw new Error(
        "Collection structural target contains contradictory anchors"
      );
    }
    if (afterIndex >= 0) {
      order.splice(afterIndex, 0, subject);
      continue;
    }
    if (beforeIndex >= 0) {
      order.splice(beforeIndex + 1, 0, subject);
      continue;
    }
    if (beforeSubject === void 0 && afterSubject === void 0) {
      order.push(subject);
      continue;
    }
    throw new Error(
      "Collection structural target has no live placement anchor"
    );
  }
}
function derivePendingAnchorOrder(effects) {
  const subjects = effects.map((effect) => effect.subjectId);
  const subjectSet = new Set(subjects);
  const outgoing = new Map(
    subjects.map((subject) => [subject, /* @__PURE__ */ new Set()])
  );
  const indegree = new Map(subjects.map((subject) => [subject, 0]));
  const addEdge = (before, after) => {
    const edges = outgoing.get(before);
    if (!edges || edges.has(after)) {
      return;
    }
    edges.add(after);
    indegree.set(after, (indegree.get(after) ?? 0) + 1);
  };
  for (const effect of effects) {
    const subject = effect.subjectId;
    const context = effect.structuralContext;
    if (context?.kind !== "add" && context?.kind !== "remove") {
      continue;
    }
    if (context.beforeSubject !== void 0 && subjectSet.has(context.beforeSubject)) {
      addEdge(context.beforeSubject, subject);
    }
    if (context.afterSubject !== void 0 && subjectSet.has(context.afterSubject)) {
      addEdge(subject, context.afterSubject);
    }
  }
  const sourceRank = new Map(
    subjects.map((subject, index) => [subject, index])
  );
  const ready = subjects.filter((subject) => indegree.get(subject) === 0);
  const result = [];
  while (ready.length > 0) {
    ready.sort(
      (left, right) => (sourceRank.get(left) ?? 0) - (sourceRank.get(right) ?? 0)
    );
    const subject = ready.shift();
    result.push(subject);
    for (const after of outgoing.get(subject) ?? []) {
      const nextIndegree = (indegree.get(after) ?? 0) - 1;
      indegree.set(after, nextIndegree);
      if (nextIndegree === 0) {
        ready.push(after);
      }
    }
  }
  if (result.length !== subjects.length) {
    throw new Error("Collection structural target contains an anchor cycle");
  }
  return result;
}
function applyValueEffect(collections, scalars, effect) {
  if (typeof effect.subjectId !== "number") {
    scalars.set(effect.owner, effect.after);
    return;
  }
  const collection = collections.get(effect.owner);
  const subject = collection?.subjects.get(effect.subjectId);
  if (!collection || !subject) {
    throw new Error(
      `Value effect has no active subject ${String(
        effect.subjectId
      )} in owner ${effect.owner}`
    );
  }
  const fieldPath = effect.subjectFieldSegments ?? deriveSubjectFieldPath(effect.path, effect.ownerPath);
  collection.subjects.set(effect.subjectId, {
    ...subject,
    value: fieldPath.length === 0 ? effect.after : effect.fieldPresence?.after === false ? removeValueAtPath(subject.value, fieldPath) : setValueAtPath(subject.value, fieldPath, effect.after)
  });
}
function removeValueAtPath(value, path) {
  if (path.length === 0 || !isRecord(value)) return value;
  const [head, ...rest] = path;
  if (!Object.prototype.hasOwnProperty.call(value, head)) return value;
  if (rest.length === 0) {
    const { [head]: _removed, ...remaining } = value;
    return remaining;
  }
  return { ...value, [head]: removeValueAtPath(value[head], rest) };
}
function deriveSubjectFieldPath(path, ownerPath) {
  if (!path || !ownerPath || path === ownerPath || !path.startsWith(`${ownerPath}.`)) {
    throw new Error("Subject value effect has no collection-relative address");
  }
  const relative = path.slice(ownerPath.length + 1);
  const [, ...fieldPath] = relative.split(".");
  return fieldPath;
}
function structuralValue(effect) {
  const context = effect.structuralContext;
  return context?.kind === "add" || context?.kind === "remove" ? context.value : void 0;
}
function setValueAtPath(value, path, replacement) {
  if (path.length === 0) {
    return replacement;
  }
  const [head, ...rest] = path;
  const record = isRecord(value) ? value : {};
  return {
    ...record,
    [head]: setValueAtPath(record[head], rest, replacement)
  };
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function assertCollectionOrderMatchesSubjects(order, subjects) {
  if (order.length !== subjects.size || order.some((subject) => !subjects.has(subject))) {
    throw new Error("Collection order does not match active SubjectIds");
  }
}
function assertUniqueTargetKeys(subjects) {
  const keys = [...subjects.values()].map(({ key }) => key);
  if (new Set(keys).size !== keys.length) {
    throw new Error("Collection transition target contains duplicate keys");
  }
}
function longestIncreasingSuffixLengths(values) {
  const tree = new FenwickMaximum(values.length);
  const lengths = new Array(values.length);
  for (let index = values.length - 1; index >= 0; index -= 1) {
    const reversedRank = values.length - values[index];
    const length = 1 + tree.query(reversedRank - 1);
    lengths[index] = length;
    tree.update(reversedRank, length);
  }
  return lengths;
}
var FenwickMaximum = class {
  values;
  constructor(size) {
    this.values = new Array(size + 1).fill(0);
  }
  update(index, value) {
    for (let cursor = index; cursor < this.values.length; cursor += cursor & -cursor) {
      this.values[cursor] = Math.max(this.values[cursor], value);
    }
  }
  query(index) {
    let maximum = 0;
    for (let cursor = index; cursor > 0; cursor -= cursor & -cursor) {
      maximum = Math.max(maximum, this.values[cursor]);
    }
    return maximum;
  }
};
function indexSubjects(subjects) {
  return new Map(subjects.map((subject, rank) => [subject, rank]));
}
function assertUniqueSubjects(subjects) {
  if (subjects.some((subject) => !Number.isSafeInteger(subject) || subject <= 0)) {
    throw new Error("Collection order contains an invalid SubjectId");
  }
  if (new Set(subjects).size !== subjects.length) {
    throw new Error("Collection order contains duplicate SubjectIds");
  }
}
function sameSubjects(left, right) {
  return left.size === right.size && [...left].every((subject) => right.has(subject));
}
function rankAt(participant, endpoint) {
  return endpoint === "before" ? participant.beforeRank : participant.afterRank;
}
function frontierMismatch() {
  return new Error(
    "collection order frontier does not match the transition endpoint"
  );
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/scoped-value-addressing.ts
function normalizeScopedValuePath(relativePath) {
  return relativePath === "values" ? "" : relativePath.startsWith("values.") ? relativePath.slice("values.".length) : relativePath;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter.ts
var TREE_REALIZATION_DESCRIPTORS = Symbol.for(
  "SignalTree:TreeRealizationDescriptors"
);
var TREE_REALIZATION_PORT = Symbol.for("SignalTree:TreeRealizationPort");
var PreparedRealizationContext = class {
  constructor(scopeOf) {
    this.scopeOf = scopeOf;
  }
  subjects = /* @__PURE__ */ new Map();
  occupancy = /* @__PURE__ */ new Map();
  setOccupancy(scope, key, state) {
    let entries = this.occupancy.get(scope);
    if (!entries) {
      entries = /* @__PURE__ */ new Map();
      this.occupancy.set(scope, entries);
    }
    entries.set(key, state);
  }
  subjectsIn(scope) {
    let subjects = this.subjects.get(scope);
    if (!subjects) {
      subjects = /* @__PURE__ */ new Map();
      this.subjects.set(scope, subjects);
    }
    return subjects;
  }
  rememberRestoredSubject(effect, subjectId, collectionPath, key, value) {
    const scope = this.scopeOf(effect);
    if (!scope) return;
    this.subjectsIn(scope).set(subjectId, {
      collectionPath,
      scope,
      subjectId,
      reachable: true,
      currentKey: key,
      value
    });
    this.setOccupancy(scope, key, subjectId);
  }
  rememberRekeyedSubject(effect, subjectId, key) {
    const existing = this.resolveSubject(effect, subjectId);
    if (!existing) {
      return;
    }
    this.setOccupancy(
      existing.scope,
      existing.currentKey,
      "vacant"
    );
    this.setOccupancy(existing.scope, key, subjectId);
    this.subjectsIn(existing.scope).set(subjectId, {
      ...existing,
      reachable: true,
      currentKey: key
    });
  }
  rememberRemovedSubject(effect, subjectId, collectionPath, key, value) {
    const scope = this.scopeOf(effect);
    if (!scope) return;
    const existing = this.subjectsIn(scope).get(subjectId);
    const currentValue = existing?.value ?? value;
    this.setOccupancy(scope, existing?.currentKey ?? key, "vacant");
    this.subjectsIn(scope).set(subjectId, {
      collectionPath,
      scope,
      subjectId,
      reachable: false,
      currentKey: void 0,
      value: currentValue
    });
  }
  resolveSubject(effect, subjectId) {
    const scope = this.scopeOf(effect);
    return scope === void 0 ? void 0 : this.subjects.get(scope)?.get(subjectId);
  }
  resolveOccupancy(scope, key) {
    return this.occupancy.get(scope)?.get(key);
  }
};
function isRealizationAttachmentHost(node) {
  return isTraversableNode(node) || typeof node === "function";
}
function rememberTreeRealizationDescriptor(options) {
  const owner = options.positionIds?.[0];
  if (owner === void 0) {
    return;
  }
  const existing = options.descriptors.get(owner);
  const structuralEffects = existing?.structuralEffects instanceof Map ? existing.structuralEffects : new Map(existing?.structuralEffects ?? []);
  const structuralEffectBySubject = existing?.structuralEffectBySubject instanceof Map ? existing.structuralEffectBySubject : new Map(existing?.structuralEffectBySubject ?? []);
  const subjectDescriptors = existing?.subjectDescriptors instanceof Map ? existing.subjectDescriptors : new Map(existing?.subjectDescriptors ?? []);
  if (options.meta?.structuralEffect) {
    structuralEffects.set(
      toStructuralEffectKey(options.meta.structuralEffect),
      options.meta.structuralEffect
    );
    if (options.meta.structuralEffect.kind === "add" || options.meta.structuralEffect.kind === "remove") {
      structuralEffectBySubject.set(
        String(options.meta.structuralEffect.subject),
        options.meta.structuralEffect
      );
    }
  }
  const subjectId = options.subjectIds?.[0];
  const ownerPath = options.ownerPath ?? options.path;
  const { collectionPath, fieldPathFromRow } = deriveRealizationAddress(
    options.path,
    ownerPath,
    subjectId,
    options.meta?.structuralEffect,
    options.registry?.collectionPathFor(owner)
  );
  if (typeof subjectId === "number") {
    const subjectKey = String(subjectId);
    const existingSubjectDescriptor = subjectDescriptors.get(subjectKey);
    if (!existingSubjectDescriptor || existingSubjectDescriptor.path !== options.path || existingSubjectDescriptor.ownerPath !== ownerPath || existingSubjectDescriptor.collectionPath !== collectionPath || existingSubjectDescriptor.fieldPathFromRow !== fieldPathFromRow) {
      subjectDescriptors.set(subjectKey, {
        path: options.path,
        ownerPath,
        collectionPath,
        fieldPathFromRow
      });
    }
  }
  const nextPath = existing?.path ?? options.path;
  const nextOwnerPath = existing?.ownerPath ?? ownerPath;
  const nextCollectionPath = existing?.collectionPath ?? collectionPath;
  const nextFieldPathFromRow = existing?.fieldPathFromRow ?? fieldPathFromRow;
  if (existing?.path === nextPath && existing?.ownerPath === nextOwnerPath && existing?.collectionPath === nextCollectionPath && existing?.fieldPathFromRow === nextFieldPathFromRow && existing?.structuralEffects === structuralEffects && existing?.structuralEffectBySubject === structuralEffectBySubject && existing?.subjectDescriptors === subjectDescriptors) {
    return;
  }
  options.descriptors.set(owner, {
    path: nextPath,
    ownerPath: nextOwnerPath,
    collectionPath: nextCollectionPath,
    fieldPathFromRow: nextFieldPathFromRow,
    structuralEffects,
    structuralEffectBySubject,
    subjectDescriptors
  });
}
function createTreeRealizationAdapter(options) {
  const scalarSlotRuntime = getTreeScalarSlotRuntime(options.tree) ?? getTreeScalarSlotRuntime(options.tree.$);
  const physicalCommitClock = getPhysicalCommitClock(options.tree) ?? getPhysicalCommitClock(options.tree.$);
  const structuralOwnerPaths = indexStructuralOwnerPaths(options.tree.$);
  return {
    validateEffects(effects) {
      const preparedContext = buildPreparedRealizationContext(
        options.tree,
        options.descriptors,
        structuralOwnerPaths,
        scalarSlotRuntime,
        effects
      );
      if (!preparedContext) {
        return { kind: "structural-drift" };
      }
      return void 0;
    },
    applyAtomically(effects) {
      const memberTargets = /* @__PURE__ */ new Map();
      const authoredValueEffects = [];
      for (const effect of effects) {
        if (effect.plainBranchMembership) {
          memberTargets.delete(effect.owner);
          memberTargets.set(effect.owner, {
            present: effect.plainBranchMembership.after,
            value: effect.after,
            ...effect.turn === void 0 ? {} : { turn: effect.turn }
          });
        } else {
          authoredValueEffects.push(effect);
        }
      }
      const members = memberTargets.size ? preparePlainBranchMembers(options.tree.$, memberTargets) : void 0;
      const staged = members?.staged;
      const valueEffects = staged?.size ? authoredValueEffects.filter(
        (effect) => effect.turn === void 0 || effect.structural !== void 0 || typeof effect.subjectId === "number" || (staged.get(effect.owner) ?? effect.turn) <= effect.turn
      ) : authoredValueEffects;
      const apply = () => {
        const heterogeneousFrame = valueEffects.length ? planHeterogeneousFrame(
          options.tree,
          options.descriptors,
          structuralOwnerPaths,
          scalarSlotRuntime,
          physicalCommitClock,
          valueEffects
        ) : void 0;
        let scalarFrame = !heterogeneousFrame && valueEffects.length ? planScalarFrame(
          options.tree,
          options.descriptors,
          structuralOwnerPaths,
          scalarSlotRuntime,
          valueEffects
        ) : void 0;
        let perEffect = heterogeneousFrame || scalarFrame ? [] : valueEffects;
        if (perEffect.length) {
          const slotScalars = valueEffects.filter(
            (effect) => effect.structural === void 0 && effect.subjectId === void 0 && effect.subjectFieldSegments === void 0 && !hasInlineScopedAddress(effect) && !hasInlineSubjectAddress(effect) && scalarSlotRuntime?.resolveScalarSlot(effect.owner) !== void 0
          );
          scalarFrame = slotScalars.length ? planScalarFrame(
            options.tree,
            options.descriptors,
            structuralOwnerPaths,
            scalarSlotRuntime,
            slotScalars
          ) : void 0;
          if (scalarFrame) {
            const framed = new Set(slotScalars);
            perEffect = valueEffects.filter((effect) => !framed.has(effect));
          }
        }
        members?.install();
        if (members && valueEffects.length === 0)
          physicalCommitClock?.advance();
        if (heterogeneousFrame) {
          heterogeneousFrame.commit();
        } else {
          scalarFrame?.commit();
          for (const effect of perEffect) {
            applyEffect(
              options.tree,
              options.descriptors,
              structuralOwnerPaths,
              scalarSlotRuntime,
              effect
            );
          }
        }
        members?.publish();
      };
      const releaseMembership = holdEntityMembershipDelivery(options.tree.$);
      try {
        applyInInvalidationGroup(options.tree.$, apply);
      } finally {
        releaseMembership();
      }
    }
  };
}
function defineTreeRealizationDescriptors(node, descriptors) {
  Object.defineProperty(node, TREE_REALIZATION_DESCRIPTORS, {
    value: descriptors,
    enumerable: false,
    configurable: true
  });
}
function getTreeRealizationDescriptors(node) {
  if (!isRealizationAttachmentHost(node)) {
    return void 0;
  }
  return node[TREE_REALIZATION_DESCRIPTORS];
}
function defineTreeRealizationPort(node, port) {
  Object.defineProperty(node, TREE_REALIZATION_PORT, {
    value: port,
    enumerable: false,
    configurable: true
  });
}
function getTreeRealizationPort(node) {
  if (!isRealizationAttachmentHost(node)) {
    return void 0;
  }
  return node[TREE_REALIZATION_PORT];
}
function preparePointRealization(tree, effects) {
  if (!effects.length || !effects.some((effect) => typeof effect.subjectId === "number")) return void 0;
  const descriptors = getTreeRealizationDescriptors(tree.$);
  const slots = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
  const clock = getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree);
  if (!descriptors || !slots || !clock) return void 0;
  const baseRevision = clock.revision();
  const owners = effects.some((effect) => effect.structural || effect.plainBranchMembership) ? indexStructuralOwnerPaths(tree.$) : indexPointOwnerPaths(tree.$, effects);
  const memberTargets = /* @__PURE__ */ new Map();
  for (const effect of effects) if (effect.plainBranchMembership) {
    memberTargets.delete(effect.owner);
    memberTargets.set(effect.owner, {
      present: effect.plainBranchMembership.after,
      value: effect.after,
      ...effect.turn === void 0 ? {} : { turn: effect.turn }
    });
  }
  if (effects.some((effect) => effect.structural)) {
    const scalarEffects2 = effects.filter((effect) => !effect.plainBranchMembership && !effect.structural && typeof effect.subjectId !== "number");
    const members2 = memberTargets.size ? preparePlainBranchMembers(tree.$, memberTargets, scalarEffects2) : void 0;
    const entityEffects = effects.filter((effect) => !effect.plainBranchMembership && (!members2 || effect.structural || typeof effect.subjectId === "number"));
    const heterogeneous = planHeterogeneousFrame(tree, descriptors, owners, slots, clock, entityEffects);
    if (!heterogeneous) return void 0;
    if (clock.revision() !== baseRevision) throw new Error("Point realization preparation reentered installation");
    let installed2 = false;
    return {
      install() {
        if (installed2 || clock.revision() !== baseRevision) throw new Error("Point realization base revision is stale");
        members2?.install();
        heterogeneous.install();
        installed2 = true;
      },
      publish() {
        if (!installed2) throw new Error("Point realization published before installation");
        let failed = false;
        let firstError;
        const run2 = (fn) => {
          try {
            fn();
          } catch (error) {
            if (!failed) {
              failed = true;
              firstError = error;
            }
          }
        };
        run2(() => heterogeneous.invalidate());
        if (members2) run2(() => members2.invalidate());
        if (members2) run2(() => members2.publish());
        run2(() => heterogeneous.publish());
        if (failed) throw firstError;
      }
    };
  }
  const rows = /* @__PURE__ */ new Map();
  const scalarEffects = [];
  const frame = slots.beginFrame();
  for (const effect of effects) {
    if (effect.plainBranchMembership) continue;
    if (typeof effect.subjectId !== "number") {
      if (effect.subjectFieldSegments !== void 0 || hasInlineScopedAddress(effect) || hasInlineSubjectAddress(effect)) return void 0;
      const slot = slots.resolveScalarSlot(effect.owner);
      if (slot === void 0) return void 0;
      frame.set(slot, effect.after);
      scalarEffects.push(effect);
      continue;
    }
    const descriptor = descriptors.get(effect.owner);
    const collection = resolveCollectionNode(tree, descriptor, owners, effect);
    if (!collection?.__preparePointValues) return void 0;
    const key = collection.__findKeyBySubjectId?.(effect.subjectId);
    if (key === void 0) return void 0;
    let bySubject = rows.get(collection);
    if (!bySubject) rows.set(collection, bySubject = /* @__PURE__ */ new Map());
    let row = bySubject.get(effect.subjectId);
    if (!row) {
      row = { subjectId: effect.subjectId, key, value: deepClone(snapshotCollectionEntityValue(collection, key)) };
      bySubject.set(effect.subjectId, row);
    }
    const path = resolveSubjectFieldPath(descriptor, effect, getPositionRegistry(tree.$));
    if (path === void 0) return void 0;
    if (path.length === 0) row.value = effect.after;
    else if (effect.fieldPresence?.after === false) row.value = withoutFieldAtSegments(row.value, path);
    else assignPreparedSubjectValue(row.value, path, effect.after);
  }
  const members = memberTargets.size ? preparePlainBranchMembers(tree.$, memberTargets, scalarEffects) : void 0;
  const collections = [...rows].map(([collection, subjects]) => {
    const prepare = collection.__preparePointValues;
    if (!prepare) throw new Error("Point realization preparation is unavailable");
    return prepare.call(collection, [...subjects.values()]);
  });
  if (!frame.prepareCommit) return void 0;
  const installScalars = members ? () => void 0 : frame.prepareCommit({ advanceRevision: false, publish: false });
  if (clock.revision() !== baseRevision) throw new Error("Point realization preparation reentered installation");
  let result;
  let installed = false;
  return {
    install() {
      if (installed || clock.revision() !== baseRevision) throw new Error("Point realization base revision is stale");
      if (members) members.install();
      else result = installScalars();
      for (const collection of collections) collection.install();
      clock.advance();
      installed = true;
    },
    publish() {
      const installedScalars = result;
      if (!installed || !members && !installedScalars) throw new Error("Point realization published before installation");
      let failed = false;
      let firstError;
      const run2 = (fn) => {
        try {
          fn();
        } catch (error) {
          if (!failed) {
            failed = true;
            firstError = error;
          }
        }
      };
      for (const collection of collections) run2(() => collection.invalidate());
      if (members) run2(() => members.invalidate());
      else if (installedScalars) run2(() => slots.publishPrepared(installedScalars));
      if (members) run2(() => members.publish());
      for (const collection of collections) run2(() => collection.publish());
      for (const effect of members ? [] : scalarEffects) run2(() => {
        const descriptor = descriptors.get(effect.owner);
        const path = resolveNotifyPath(tree, descriptor, owners, effect);
        if (path) getPathNotifier().notify(
          path,
          effect.after,
          effect.before,
          descriptor?.ownerPath ?? path,
          void 0,
          [effect.owner],
          { ...getActiveWriteContext() ?? {}, intent: "system", participation: "realized" }
        );
      });
      run2(() => markOwnerInvalidatedFrom(tree));
      if (failed) throw firstError;
    }
  };
}
function planHeterogeneousFrame(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, physicalCommitClock, effects) {
  if (effects.length === 0 || !effects.some(
    (effect) => effect.structural === "rekey" || effect.structural === "add" || effect.structural === "remove"
  ) || effects.some(
    (effect) => effect.structural && effect.structural !== "rekey" && effect.structural !== "add" && effect.structural !== "remove"
  )) {
    return void 0;
  }
  const scalarEffects = effects.filter((effect) => !effect.structural);
  const preparedContext = buildPreparedRealizationContext(
    tree,
    descriptors,
    structuralOwnerPaths,
    scalarSlotRuntime,
    effects
  );
  if (!preparedContext) {
    return void 0;
  }
  const removeKeysByEffect = /* @__PURE__ */ new Map();
  const planningPreparedContext = new PreparedRealizationContext(
    preparedSubjectScope(tree, descriptors, structuralOwnerPaths)
  );
  for (const effect of effects) {
    const removeEffect = effect.structural === "remove" && typeof effect.subjectId === "number" ? effect : void 0;
    if (removeEffect) {
      const descriptor = descriptors.get(effect.owner);
      const collectionNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        removeEffect
      );
      if (!collectionNode) {
        return void 0;
      }
      const effectiveRemoveKey = resolveEffectiveRemoveKey(
        collectionNode,
        planningPreparedContext,
        removeEffect
      );
      if (effectiveRemoveKey === void 0) {
        return void 0;
      }
      removeKeysByEffect.set(removeEffect, effectiveRemoveKey);
    }
    updatePreparedRealizationContext(
      tree,
      descriptors,
      structuralOwnerPaths,
      planningPreparedContext,
      effect
    );
  }
  const vacatingKeysByOwner = /* @__PURE__ */ new Map();
  for (const [removeEffect, removedKey] of removeKeysByEffect) {
    let keys = vacatingKeysByOwner.get(removeEffect.owner);
    if (!keys) {
      keys = /* @__PURE__ */ new Set();
      vacatingKeysByOwner.set(removeEffect.owner, keys);
    }
    keys.add(removedKey);
  }
  const preparedSubjectScalarEffects = scalarEffects.filter(
    (effect) => isPreparedSubjectScalarEffect(effect, preparedContext)
  );
  const framedScalarEffects = scalarEffects.filter(
    (effect) => !isPreparedSubjectScalarEffect(effect, preparedContext)
  );
  const rekeyEffects = effects.filter(
    (effect) => effect.structural === "rekey"
  );
  const removedScopes = new Set(
    effects.filter((effect) => effect.structural === "remove").map((effect) => rowScope(effect.owner, effect.subjectId))
  );
  const collectionNodesByOwner = /* @__PURE__ */ new Map();
  const restoreEffects = orderRestoresForPlacement(
    effects.filter(
      (effect) => effect.structural === "add" && typeof effect.subjectId === "number"
    ),
    (effect) => getStructuralAddEffect(descriptors.get(effect.owner), effect),
    (effect, subject) => {
      if (removedScopes.has(rowScope(effect.owner, subject))) return false;
      if (!collectionNodesByOwner.has(effect.owner)) {
        collectionNodesByOwner.set(
          effect.owner,
          resolveCollectionNode(
            tree,
            descriptors.get(effect.owner),
            structuralOwnerPaths,
            effect
          )
        );
      }
      return collectionNodesByOwner.get(effect.owner)?.__findKeyBySubjectId?.(subject) !== void 0;
    }
  );
  const baseRevision = scalarSlotRuntime?.revision();
  const scalarFrameRuntime = framedScalarEffects.length > 0 ? scalarSlotRuntime : void 0;
  const scalarFrame = framedScalarEffects.length > 0 ? scalarFrameRuntime?.beginFrame() : void 0;
  if (framedScalarEffects.length > 0 && (!scalarFrameRuntime || !scalarFrame)) {
    return void 0;
  }
  const resolvedScalarFrameRuntime = scalarFrameRuntime;
  const plannedRestores = [];
  const plannedFreshAdds = [];
  const plannedRekeys = [];
  const plannedRemoves = [];
  for (const effect of restoreEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    const structuralEffect = getStructuralAddEffect(descriptor, effect);
    const collectionPath = resolveCollectionPath(
      descriptor,
      structuralOwnerPaths,
      effect
    );
    const subjectInventory = collectionNode?.__inspectSubjectResources?.(
      effect.subjectId
    );
    const isFreshSubject = subjectInventory === void 0;
    if (!collectionNode || !structuralEffect || !collectionPath || (isFreshSubject ? typeof collectionNode.__planFreshAdd !== "function" : typeof collectionNode.__planRestore !== "function")) {
      scalarFrame?.discard();
      return void 0;
    }
    const preparedSubject = preparedContext.resolveSubject(
      effect,
      effect.subjectId
    );
    if (!preparedSubject) {
      scalarFrame?.discard();
      return void 0;
    }
    if (isFreshSubject) {
      const planFreshAdd = collectionNode.__planFreshAdd;
      if (typeof planFreshAdd !== "function") {
        scalarFrame?.discard();
        return void 0;
      }
      plannedFreshAdds.push({
        effect,
        plan: planFreshAdd(
          effect.after,
          preparedSubject.value,
          effect.subjectId
        )
      });
      continue;
    }
    const planRestore = collectionNode.__planRestore;
    if (typeof planRestore !== "function") {
      scalarFrame?.discard();
      return void 0;
    }
    plannedRestores.push({
      effect,
      plan: planRestore(
        effect.after,
        preparedSubject.value,
        effect.subjectId,
        structuralEffect.beforeSubject,
        structuralEffect.afterSubject,
        vacatingKeysByOwner.get(effect.owner)
      )
    });
  }
  for (const effect of framedScalarEffects) {
    if (!resolvedScalarFrameRuntime) {
      scalarFrame?.discard();
      return void 0;
    }
    const slotIndex = resolvedScalarFrameRuntime.resolveScalarSlot(
      effect.owner
    );
    if (slotIndex === void 0) {
      scalarFrame?.discard();
      return void 0;
    }
    scalarFrame?.set(slotIndex, effect.after);
  }
  for (const effect of rekeyEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    if (!collectionNode || typeof collectionNode.__planRekey !== "function" && typeof collectionNode.__planPreparedRekey !== "function") {
      scalarFrame?.discard();
      return void 0;
    }
    const preparedSubject = typeof effect.subjectId === "number" ? preparedContext.resolveSubject(effect, effect.subjectId) : void 0;
    const plan = preparedSubject && typeof collectionNode.__planPreparedRekey === "function" ? collectionNode.__planPreparedRekey(
      effect.before,
      effect.after,
      effect.subjectId,
      preparedSubject.value
    ) : typeof collectionNode.__planRekey === "function" ? collectionNode.__planRekey(
      effect.before,
      effect.after
    ) : void 0;
    if (!plan) {
      scalarFrame?.discard();
      return void 0;
    }
    plannedRekeys.push({
      effect,
      plan
    });
    if (typeof effect.subjectId === "number") {
      preparedContext.rememberRekeyedSubject(
        effect,
        effect.subjectId,
        effect.after
      );
    }
  }
  const removeEffects = effects.filter(
    (effect) => effect.structural === "remove" && typeof effect.subjectId === "number"
  );
  for (const effect of removeEffects) {
    const descriptor = descriptors.get(effect.owner);
    const collectionNode = resolveCollectionNode(
      tree,
      descriptor,
      structuralOwnerPaths,
      effect
    );
    if (!collectionNode || typeof collectionNode.__planRemove !== "function") {
      scalarFrame?.discard();
      return void 0;
    }
    const effectiveRemoveKey = removeKeysByEffect.get(effect);
    if (effectiveRemoveKey === void 0) {
      scalarFrame?.discard();
      return void 0;
    }
    plannedRemoves.push({
      effect,
      plan: collectionNode.__planRemove(effectiveRemoveKey, effect.subjectId)
    });
  }
  let scalarCommitResult;
  const install = () => {
    if (scalarFrame && physicalCommitClock && physicalCommitClock.revision() !== baseRevision) {
      throw new Error("Heterogeneous realization base revision is stale.");
    }
    scalarCommitResult = scalarFrame?.commit({
      advanceRevision: false,
      publish: false
    });
    for (const { plan } of plannedRemoves) {
      plan.commit({ advancePhysicalRevision: false });
    }
    for (const { plan } of plannedFreshAdds) {
      plan.commit({ advancePhysicalRevision: false });
    }
    for (const { plan } of plannedRestores) {
      plan.commit({ advancePhysicalRevision: false });
    }
    for (const { plan } of plannedRekeys) {
      plan.commit({ advancePhysicalRevision: false });
    }
    physicalCommitClock?.advance();
  };
  const invalidate = () => {
    if (scalarCommitResult && scalarSlotRuntime) {
      scalarSlotRuntime.publishPrepared(scalarCommitResult);
    }
  };
  const publish = () => {
    let failed = false;
    let firstError;
    const run2 = (fn) => {
      try {
        fn();
      } catch (error) {
        if (!failed) {
          failed = true;
          firstError = error;
        }
      }
    };
    for (const { plan } of plannedRemoves) {
      run2(() => plan.publish({
        ...getActiveWriteContext() ?? {},
        intent: "system",
        participation: "realized"
      }));
    }
    for (const { plan } of plannedRestores) {
      run2(() => plan.publish({
        ...getActiveWriteContext() ?? {},
        intent: "system",
        participation: "realized"
      }));
    }
    for (const { plan } of plannedFreshAdds) {
      run2(() => plan.publish({
        ...getActiveWriteContext() ?? {},
        intent: "system",
        participation: "realized"
      }));
    }
    for (const { plan } of plannedRekeys) {
      run2(() => plan.publish({
        ...getActiveWriteContext() ?? {},
        intent: "system",
        participation: "realized"
      }));
    }
    for (const effect of [
      ...preparedSubjectScalarEffects,
      ...framedScalarEffects
    ]) {
      const descriptor = descriptors.get(effect.owner);
      const notifyPath = resolveNotifyPath(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!notifyPath) {
        continue;
      }
      run2(() => getPathNotifier().notify(
        notifyPath,
        effect.after,
        effect.before,
        descriptor?.ownerPath ?? notifyPath,
        typeof effect.subjectId === "number" ? [effect.subjectId] : void 0,
        [effect.owner],
        {
          ...getActiveWriteContext() ?? {},
          intent: "system",
          participation: "realized"
        }
      ));
    }
    run2(() => markOwnerInvalidatedFrom(tree));
    if (failed) throw firstError;
  };
  return {
    install,
    invalidate,
    publish,
    commit() {
      const commitAndPublish = () => {
        install();
        invalidate();
        publish();
      };
      const locations = getLocationRuntime(tree.$);
      if (locations) locations.runInvalidationGroup(commitAndPublish);
      else if (scalarSlotRuntime) scalarSlotRuntime.runInvalidationGroup(commitAndPublish);
      else commitAndPublish();
    }
  };
}
function planScalarFrame(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effects) {
  void tree;
  void descriptors;
  void structuralOwnerPaths;
  if (effects.length === 0 || effects.some(
    (effect) => effect.structural || effect.subjectFieldSegments !== void 0 || hasInlineScopedAddress(effect) || hasInlineSubjectAddress(effect)
  )) {
    return void 0;
  }
  if (!scalarSlotRuntime) {
    return void 0;
  }
  const frame = scalarSlotRuntime.beginFrame();
  for (const effect of effects) {
    const slotIndex = scalarSlotRuntime.resolveScalarSlot(effect.owner);
    if (slotIndex === void 0) {
      return void 0;
    }
    frame.set(slotIndex, effect.after);
  }
  return {
    commit() {
      frame.commit();
      for (const effect of effects) {
        const descriptor = descriptors.get(effect.owner);
        const notifyPath = resolveNotifyPath(
          tree,
          descriptor,
          structuralOwnerPaths,
          effect
        );
        if (!notifyPath) {
          continue;
        }
        getPathNotifier().notify(
          notifyPath,
          effect.after,
          effect.before,
          descriptor?.ownerPath ?? notifyPath,
          typeof effect.subjectId === "number" ? [effect.subjectId] : void 0,
          [effect.owner],
          {
            ...getActiveWriteContext() ?? {},
            intent: "system",
            participation: "realized"
          }
        );
      }
    }
  };
}
function canApplyEffect(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effect, preparedContext) {
  if (effect.plainBranchMembership)
    return canRealizePlainBranchMember(tree.$, effect.owner);
  const descriptor = descriptors.get(effect.owner);
  if (!descriptor && !effect.structural && effect.subjectFieldSegments === void 0 && !scalarSlotRuntime?.resolveScalarLeaf(effect.owner) && !hasInlineSubjectAddress(effect) && !hasInlineScopedAddress(effect)) {
    return false;
  }
  if (!effect.structural) {
    if (canResolvePreparedSubjectTarget(
      descriptor,
      effect,
      preparedContext,
      getPositionRegistry(tree.$)
    )) {
      return true;
    }
    const target = resolveLiveScalarNode(
      tree,
      descriptor,
      scalarSlotRuntime,
      effect,
      structuralOwnerPaths
    );
    return isWritableLeaf(target) || isWritableEntityNode(target);
  }
  const ownerNode = resolveCollectionNode(
    tree,
    descriptor,
    structuralOwnerPaths,
    effect
  );
  if (!ownerNode) {
    return false;
  }
  const currentSubjectKey = typeof effect.subjectId === "number" ? resolvePreparedOrLiveSubjectKey(
    ownerNode,
    preparedContext,
    effect,
    effect.subjectId
  ) : void 0;
  const destinationOccupied = effect.structural === "rekey" || effect.structural === "add" ? isCollectionKeyOccupied(
    ownerNode,
    effect.after,
    preparedContext
  ) : false;
  switch (effect.structural) {
    case "remove": {
      const removeEffect = typeof effect.subjectId === "number" ? effect : void 0;
      return (removeEffect ? resolveEffectiveRemoveKey(
        ownerNode,
        preparedContext,
        removeEffect
      ) !== void 0 : hasCollectionKey(ownerNode, effect.before)) && (typeof effect.subjectId !== "number" || currentSubjectKey !== void 0);
    }
    case "rekey":
      return (typeof effect.subjectId === "number" ? currentSubjectKey === effect.before : hasCollectionKey(ownerNode, effect.before)) && (typeof effect.subjectId !== "number" || currentSubjectKey === effect.before) && !destinationOccupied;
    case "add": {
      if (typeof effect.subjectId !== "number" || typeof ownerNode.__restoreOne !== "function" || destinationOccupied || currentSubjectKey !== void 0) {
        return false;
      }
      return getStructuralAddEffect(descriptor, effect) !== void 0;
    }
  }
}
function applyEffect(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effect) {
  const descriptor = descriptors.get(effect.owner);
  if (!descriptor && !effect.structural && effect.subjectFieldSegments === void 0 && !scalarSlotRuntime?.resolveScalarLeaf(effect.owner) && !hasInlineSubjectAddress(effect) && !hasInlineScopedAddress(effect)) {
    throw new Error(
      `Missing live descriptor for owner ${String(effect.owner)}`
    );
  }
  withWriteContext(
    {
      ...getActiveWriteContext() ?? {},
      intent: "system",
      participation: "realized"
    },
    () => {
      if (!effect.structural && effect.fieldPresence?.after === false && typeof effect.subjectId === "number" && effect.subjectFieldSegments?.length) {
        const row = resolveCurrentSubjectTarget(
          tree,
          descriptor,
          effect.subjectId,
          { ...effect, subjectFieldSegments: [] },
          structuralOwnerPaths
        );
        if (isWritableEntityNode(row)) {
          const read2 = row;
          row(withoutFieldAtSegments(read2(), effect.subjectFieldSegments));
          return;
        }
      }
      if (!effect.structural) {
        const target = resolveLiveScalarNode(
          tree,
          descriptor,
          scalarSlotRuntime,
          effect,
          structuralOwnerPaths
        );
        if (isWritableLeaf(target)) {
          target.set(effect.after);
          return;
        }
        if (isWritableEntityNode(target)) {
          target(effect.after);
          return;
        }
        if (!isWritableLeaf(target)) {
          throw new Error(
            `Missing live leaf for owner ${String(effect.owner)}`
          );
        }
        return;
      }
      const ownerNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!ownerNode) {
        throw new Error(`Missing structural owner for ${String(effect.owner)}`);
      }
      switch (effect.structural) {
        case "rekey":
          ownerNode.changeId(
            effect.before,
            effect.after
          );
          return;
        case "remove": {
          const removeEffect = typeof effect.subjectId === "number" ? effect : void 0;
          const effectiveRemoveKey = removeEffect ? resolveEffectiveRemoveKey(ownerNode, void 0, removeEffect) : effect.before;
          if (effectiveRemoveKey === void 0) {
            throw new Error(
              `Missing live structural subject for owner ${String(
                effect.owner
              )}`
            );
          }
          ownerNode.removeOne(effectiveRemoveKey);
          return;
        }
        case "add": {
          const structuralEffect = getStructuralAddEffect(descriptor, effect);
          if (!structuralEffect) {
            throw new Error(
              `Missing structural restore metadata for owner ${String(
                effect.owner
              )}`
            );
          }
          ownerNode.__restoreOne?.(
            effect.after,
            structuralEffect.value,
            effect.subjectId,
            structuralEffect.beforeSubject,
            structuralEffect.afterSubject
          );
          return;
        }
      }
    }
  );
}
function resolveLiveScalarNode(tree, descriptor, scalarSlotRuntime, effect, structuralOwnerPaths) {
  if (typeof effect.subjectId === "number") {
    return resolveCurrentSubjectTarget(
      tree,
      descriptor,
      effect.subjectId,
      effect,
      structuralOwnerPaths
    );
  }
  if (hasInlineScopedAddress(effect)) {
    return resolveCurrentScopedTarget(tree, descriptor, effect);
  }
  const directLeaf = scalarSlotRuntime?.resolveScalarLeaf(effect.owner);
  if (directLeaf) {
    return directLeaf;
  }
  if (!descriptor?.path) {
    return void 0;
  }
  const pathNode = resolveNodeAtPath(
    tree.$,
    descriptor.path
  );
  return isWritableLeaf(pathNode) || isWritableEntityNode(pathNode) ? pathNode : void 0;
}
function canResolvePreparedSubjectTarget(descriptor, effect, preparedContext, registry) {
  if (typeof effect.subjectId !== "number") {
    return false;
  }
  const preparedSubject = preparedContext?.resolveSubject(
    effect,
    effect.subjectId
  );
  if (!preparedSubject) {
    return false;
  }
  if (!preparedSubject.reachable) {
    return false;
  }
  const fieldPathFromRow = resolveSubjectFieldPath(
    descriptor,
    effect,
    registry
  );
  if (!fieldPathFromRow) {
    return false;
  }
  const value = preparedSubject.value;
  return effect.fieldPresence?.after === true && fieldPathFromRow.length > 0 ? isTraversableNode(
    resolveNodeAtSegments(value, fieldPathFromRow.slice(0, -1))
  ) : resolveNodeAtSegments(value, fieldPathFromRow) !== void 0;
}
function resolveCollectionNode(tree, descriptor, structuralOwnerPaths, effect) {
  const owned = structuralOwnerPaths.nodes.get(effect.owner);
  if (owned) return owned;
  if (effect.subjectFieldSegments !== void 0) return void 0;
  const collectionPath = resolveCollectionPath(
    descriptor,
    structuralOwnerPaths,
    effect
  );
  if (collectionPath === void 0) {
    return void 0;
  }
  const node = resolveNodeAtPath(
    tree.$,
    collectionPath
  );
  return isCollectionNode(node) ? node : void 0;
}
function resolveCollectionPath(descriptor, structuralOwnerPaths, effect) {
  return descriptor?.collectionPath ?? (effect.structural ? descriptor?.ownerPath : void 0) ?? structuralOwnerPaths.get(effect.owner);
}
function isCollectionKeyOccupied(ownerNode, key, preparedContext) {
  const preparedOccupancy = preparedContext?.resolveOccupancy(ownerNode, key);
  if (preparedOccupancy === "vacant") {
    return false;
  }
  if (preparedOccupancy !== void 0) {
    return true;
  }
  return hasCollectionKey(ownerNode, key);
}
function resolvePreparedOrLiveSubjectKey(ownerNode, preparedContext, effect, subjectId) {
  const preparedSubject = preparedContext?.resolveSubject(effect, subjectId);
  if (preparedSubject) {
    return preparedSubject.currentKey;
  }
  return ownerNode.__findKeyBySubjectId?.(subjectId);
}
function resolveEffectiveRemoveKey(ownerNode, preparedContext, effect) {
  return resolvePreparedOrLiveSubjectKey(
    ownerNode,
    preparedContext,
    effect,
    effect.subjectId
  );
}
function snapshotCollectionEntityValue(collectionNode, key) {
  const rowNode = collectionNode.byIdOrFail(key);
  return typeof rowNode === "function" ? rowNode() : rowNode;
}
function updatePreparedRealizationContext(tree, descriptors, structuralOwnerPaths, preparedContext, effect) {
  if (typeof effect.subjectId === "number" && !effect.structural) {
    const descriptor2 = descriptors.get(effect.owner);
    const preparedSubject = preparedContext.resolveSubject(
      effect,
      effect.subjectId
    );
    const fieldPathFromRow = resolveSubjectFieldPath(
      descriptor2,
      effect,
      getPositionRegistry(tree.$)
    );
    if (preparedSubject && fieldPathFromRow?.length === 0) {
      preparedSubject.value = effect.after;
    } else if (preparedSubject && fieldPathFromRow && effect.fieldPresence?.after === false) {
      preparedSubject.value = withoutFieldAtSegments(
        preparedSubject.value,
        fieldPathFromRow
      );
    } else if (preparedSubject && fieldPathFromRow) {
      assignPreparedSubjectValue(
        preparedSubject.value,
        fieldPathFromRow,
        effect.after
      );
    }
    return;
  }
  if (typeof effect.subjectId !== "number" || !effect.structural) {
    return;
  }
  const descriptor = descriptors.get(effect.owner);
  switch (effect.structural) {
    case "add": {
      const collectionPath = resolveCollectionPath(
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionPath) {
        return;
      }
      const structuralEffect = getStructuralAddEffect(descriptor, effect);
      if (!structuralEffect) {
        return;
      }
      const preparedValue = deepClone(structuralEffect.value);
      preparedContext.rememberRestoredSubject(
        effect,
        effect.subjectId,
        collectionPath,
        effect.after,
        preparedValue
      );
      return;
    }
    case "rekey":
      preparedContext.rememberRekeyedSubject(
        effect,
        effect.subjectId,
        effect.after
      );
      return;
    case "remove": {
      const collectionPath = resolveCollectionPath(
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionPath) {
        return;
      }
      const collectionNode = resolveCollectionNode(
        tree,
        descriptor,
        structuralOwnerPaths,
        effect
      );
      if (!collectionNode) {
        return;
      }
      const removeEffect = effect;
      const effectiveRemoveKey = resolveEffectiveRemoveKey(
        collectionNode,
        preparedContext,
        removeEffect
      );
      if (effectiveRemoveKey === void 0) {
        return;
      }
      const liveValue = snapshotCollectionEntityValue(
        collectionNode,
        effectiveRemoveKey
      );
      if (liveValue === void 0) {
        return;
      }
      preparedContext.rememberRemovedSubject(
        effect,
        effect.subjectId,
        collectionPath,
        effectiveRemoveKey,
        liveValue
      );
      return;
    }
  }
}
function preparedSubjectScope(tree, descriptors, structuralOwnerPaths) {
  return (effect) => resolveCollectionNode(
    tree,
    descriptors.get(effect.owner),
    structuralOwnerPaths,
    effect
  );
}
function buildPreparedRealizationContext(tree, descriptors, structuralOwnerPaths, scalarSlotRuntime, effects) {
  const preparedContext = new PreparedRealizationContext(
    preparedSubjectScope(tree, descriptors, structuralOwnerPaths)
  );
  for (const effect of effects) {
    if (!canApplyEffect(
      tree,
      descriptors,
      structuralOwnerPaths,
      scalarSlotRuntime,
      effect,
      preparedContext
    )) {
      return void 0;
    }
    updatePreparedRealizationContext(
      tree,
      descriptors,
      structuralOwnerPaths,
      preparedContext,
      effect
    );
  }
  return preparedContext;
}
function resolveSubjectFieldPath(descriptor, effect, registry) {
  if (typeof effect.subjectId !== "number") return void 0;
  if (effect.subjectFieldSegments !== void 0) {
    return effect.subjectFieldSegments;
  }
  const legacy = deriveFieldPathFromEffect(effect, registry) ?? descriptor?.subjectDescriptors?.get(String(effect.subjectId))?.fieldPathFromRow ?? descriptor?.fieldPathFromRow;
  return legacy === void 0 ? void 0 : legacy === "" ? [] : legacy.split(".");
}
function assignPreparedSubjectValue(subjectValue, fieldPathFromRow, nextValue) {
  if (fieldPathFromRow.length === 0) {
    return;
  }
  if (!isTraversableNode(subjectValue)) {
    return;
  }
  const segments = fieldPathFromRow;
  let cursor = subjectValue;
  for (const segment of segments.slice(0, -1)) {
    if (!isTraversableNode(cursor)) {
      return;
    }
    cursor = cursor[segment];
  }
  const leafKey = segments.at(-1);
  if (leafKey === void 0 || !isTraversableNode(cursor)) {
    return;
  }
  cursor[leafKey] = nextValue;
}
function isPreparedSubjectScalarEffect(effect, preparedContext) {
  return typeof effect.subjectId === "number" && !effect.structural && preparedContext.resolveSubject(effect, effect.subjectId) !== void 0;
}
function indexPointOwnerPaths(root, effects) {
  const registry = getPositionRegistry(root);
  const owners = Object.assign(/* @__PURE__ */ new Map(), {
    nodes: /* @__PURE__ */ new Map()
  });
  for (const effect of effects) {
    if (typeof effect.subjectId !== "number" || owners.nodes.has(effect.owner)) continue;
    const address = registry?.addressFor(effect.owner);
    if (!address || address.length > 32) return indexStructuralOwnerPaths(root);
    let node = root;
    for (const key of address) {
      if (!isTraversableNode(node) || key === "set" || key === "update" || key.startsWith("_")) {
        return indexStructuralOwnerPaths(root);
      }
      const property = Object.getOwnPropertyDescriptor(node, key);
      if (!property?.enumerable || !("value" in property)) return indexStructuralOwnerPaths(root);
      node = property.value;
    }
    if (!isCollectionNode(node) || getOwnedPositionIds(node)?.[0] !== effect.owner) {
      return indexStructuralOwnerPaths(root);
    }
    const path = getOwnedOwnerPath(node);
    if (path === void 0) return indexStructuralOwnerPaths(root);
    owners.set(effect.owner, path);
    owners.nodes.set(effect.owner, node);
  }
  return owners;
}
function indexStructuralOwnerPaths(root) {
  const ownerPaths = Object.assign(/* @__PURE__ */ new Map(), {
    nodes: /* @__PURE__ */ new Map()
  });
  visitTree(
    root,
    (node) => {
      if (!isCollectionNode(node)) {
        return void 0;
      }
      const positionId = getOwnedPositionIds(node)?.[0];
      const ownerPath = getOwnedOwnerPath(node);
      if (positionId === void 0 || ownerPath === void 0) {
        return void 0;
      }
      ownerPaths.set(positionId, ownerPath);
      ownerPaths.nodes.set(positionId, node);
      return void 0;
    },
    {
      skipKey: (key) => key === "set" || key === "update" || key.startsWith("_")
    }
  );
  return ownerPaths;
}
function resolveCurrentSubjectTarget(tree, descriptor, subjectId, effect, structuralOwnerPaths) {
  if (effect.subjectFieldSegments !== void 0) {
    const collection = structuralOwnerPaths.nodes.get(effect.owner);
    const key = collection?.__findKeyBySubjectId?.(subjectId);
    if (!collection || key === void 0) return void 0;
    const row = collection.byIdOrFail(key);
    return resolveStructuredSubjectTarget(row, effect.subjectFieldSegments);
  }
  const registry = getPositionRegistry(tree.$);
  const inlineCollectionPath = deriveCollectionPathFromEffect(effect, registry);
  const inlineFieldPathFromRow = deriveFieldPathFromEffect(effect, registry);
  const subjectDescriptor = descriptor?.subjectDescriptors?.get(
    String(subjectId)
  );
  const collectionPath = inlineCollectionPath ?? subjectDescriptor?.collectionPath ?? descriptor?.collectionPath ?? (effect.structural ? descriptor?.ownerPath : void 0);
  if (!collectionPath && collectionPath !== "") {
    return void 0;
  }
  const collectionNode = resolveNodeAtPath(
    tree.$,
    collectionPath
  );
  if (!isCollectionNode(collectionNode)) {
    return void 0;
  }
  const currentKey = collectionNode.__findKeyBySubjectId?.(subjectId);
  if (currentKey === void 0) {
    return void 0;
  }
  const rowNode = collectionNode.byIdOrFail(currentKey);
  const fieldPathFromRow = inlineFieldPathFromRow ?? subjectDescriptor?.fieldPathFromRow ?? descriptor?.fieldPathFromRow;
  if (fieldPathFromRow === "") {
    return rowNode;
  }
  if (!fieldPathFromRow) {
    return void 0;
  }
  return resolveNodeAtPath(
    rowNode,
    fieldPathFromRow
  );
}
function resolveNotifyPath(tree, descriptor, structuralOwnerPaths, effect) {
  if (hasInlineScopedAddress(effect)) {
    return effect.path;
  }
  if (typeof effect.subjectId !== "number") {
    return descriptor?.path ?? effect.path;
  }
  if (effect.subjectFieldSegments !== void 0) {
    const collection = structuralOwnerPaths.nodes.get(effect.owner);
    const key = collection?.__findKeyBySubjectId?.(effect.subjectId);
    const path = structuralOwnerPaths.get(effect.owner);
    if (key === void 0 || path === void 0) return void 0;
    return [path, String(key), ...effect.subjectFieldSegments].join(".");
  }
  const registry = getPositionRegistry(tree.$);
  const inlineCollectionPath = deriveCollectionPathFromEffect(effect, registry);
  const inlineFieldPathFromRow = deriveFieldPathFromEffect(effect, registry);
  const collectionPath = inlineCollectionPath ?? descriptor?.subjectDescriptors?.get(String(effect.subjectId))?.collectionPath ?? descriptor?.collectionPath ?? structuralOwnerPaths.get(effect.owner);
  if (collectionPath === void 0) {
    return descriptor?.path;
  }
  const collectionNode = resolveNodeAtPath(
    tree.$,
    collectionPath
  );
  if (!isCollectionNode(collectionNode)) {
    return descriptor?.path;
  }
  const currentKey = collectionNode.__findKeyBySubjectId?.(effect.subjectId);
  if (currentKey === void 0) {
    return descriptor?.path;
  }
  const fieldPathFromRow = inlineFieldPathFromRow ?? descriptor?.subjectDescriptors?.get(String(effect.subjectId))?.fieldPathFromRow ?? descriptor?.fieldPathFromRow;
  const rowPath = `${collectionPath}.${String(currentKey)}`;
  if (fieldPathFromRow === "") {
    return rowPath;
  }
  return fieldPathFromRow ? `${rowPath}.${fieldPathFromRow}` : descriptor?.path;
}
function hasInlineSubjectAddress(effect) {
  return typeof effect.subjectId === "number" && typeof effect.path === "string" && typeof effect.ownerPath === "string";
}
function hasInlineScopedAddress(effect) {
  return typeof effect.path === "string" && typeof effect.ownerPath === "string" && effect.path !== effect.ownerPath;
}
function deriveCollectionPathFromEffect(effect, registry) {
  if (!hasInlineSubjectAddress(effect)) {
    return void 0;
  }
  return deriveRealizationAddress(
    effect.path,
    effect.ownerPath,
    effect.subjectId,
    void 0,
    registry?.collectionPathFor(effect.owner)
  ).collectionPath;
}
function deriveFieldPathFromEffect(effect, registry) {
  if (!hasInlineSubjectAddress(effect)) {
    return void 0;
  }
  return deriveRealizationAddress(
    effect.path,
    effect.ownerPath,
    effect.subjectId,
    void 0,
    registry?.collectionPathFor(effect.owner)
  ).fieldPathFromRow;
}
function resolveCurrentScopedTarget(tree, descriptor, effect) {
  const scopePath = effect.ownerPath ?? descriptor?.ownerPath;
  if (!scopePath) {
    return void 0;
  }
  const scopeNode = resolveNodeAtPath(
    tree.$,
    scopePath
  );
  if (scopeNode === void 0) {
    return void 0;
  }
  const relativePath = effect.path.startsWith(`${scopePath}.`) ? effect.path.slice(scopePath.length + 1) : "";
  const normalizedRelativePath = normalizeScopedValuePath(relativePath);
  if (normalizedRelativePath === "") {
    return scopeNode;
  }
  const scopedFieldTree = scopeNode && typeof scopeNode === "function" && "$" in scopeNode ? scopeNode.$ : void 0;
  if (isTraversableNode(scopedFieldTree)) {
    const scopedTarget = resolveNodeAtPath(
      scopedFieldTree,
      normalizedRelativePath
    );
    if (isWritableLeaf(scopedTarget) || isWritableEntityNode(scopedTarget)) {
      return scopedTarget;
    }
  }
  if (!isTraversableNode(scopeNode)) {
    return void 0;
  }
  return resolveNodeAtPath(
    scopeNode,
    normalizedRelativePath
  );
}
function withoutFieldAtSegments(value, segments) {
  if (segments.length === 0 || !isTraversableNode(value)) return value;
  const [head, ...tail] = segments;
  const record = value;
  if (!Object.prototype.hasOwnProperty.call(record, head)) return value;
  if (tail.length === 0) {
    const { [head]: _removed, ...rest } = record;
    return rest;
  }
  return { ...record, [head]: withoutFieldAtSegments(record[head], tail) };
}
function resolveNodeAtSegments(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (cursor === null || cursor === void 0) return void 0;
    cursor = cursor[segment];
  }
  return cursor;
}
function resolveStructuredSubjectTarget(row, segments) {
  if (segments.length === 0) return row;
  const direct = resolveNodeAtSegments(row, segments);
  if (isWritableLeaf(direct) || isWritableEntityNode(direct)) return direct;
  if (!isWritableEntityNode(row)) return void 0;
  const read2 = row;
  const parent = resolveNodeAtSegments(read2(), segments.slice(0, -1));
  if (!isTraversableNode(parent)) return void 0;
  return (value) => row(replaceValueAtSegments(read2(), segments, value));
}
function replaceValueAtSegments(value, segments, next) {
  if (segments.length === 0) return next;
  const [key, ...rest] = segments;
  const record = isTraversableNode(value) ? value : {};
  return { ...record, [key]: replaceValueAtSegments(record[key], rest, next) };
}
function resolveNodeAtPath(root, path) {
  if (path === "") {
    return root;
  }
  let cursor = root;
  for (const segment of path.split(".")) {
    if (cursor === null || cursor === void 0) {
      return void 0;
    }
    cursor = cursor[segment];
  }
  return cursor;
}
var rowScope = (owner, subject) => `${String(owner)}\0${String(subject)}`;
function orderRestoresForPlacement(restores, anchorsOf, isLive) {
  if (restores.length < 2) return [...restores];
  const pending = /* @__PURE__ */ new Map();
  for (const effect of restores) {
    pending.set(rowScope(effect.owner, effect.subjectId), effect);
  }
  const waiting = /* @__PURE__ */ new Map();
  const hasLiveAnchor = /* @__PURE__ */ new Set();
  const dependents = /* @__PURE__ */ new Map();
  const full = [];
  const partial = [];
  for (const effect of restores) {
    const anchors = anchorsOf(effect);
    let count = 0;
    for (const subject of [anchors?.beforeSubject, anchors?.afterSubject]) {
      if (subject === void 0) continue;
      const key = rowScope(effect.owner, subject);
      if (pending.has(key)) {
        count += 1;
        const list = dependents.get(key);
        if (list) list.push(effect);
        else dependents.set(key, [effect]);
      } else if (isLive(effect, subject)) {
        hasLiveAnchor.add(effect);
      }
    }
    waiting.set(effect, count);
    if (count === 0) full.push(effect);
    else if (hasLiveAnchor.has(effect)) partial.push(effect);
  }
  const placed = /* @__PURE__ */ new Set();
  const ordered = [];
  let fullHead = 0;
  let partialHead = 0;
  const isWaitingOn = (effect, subject) => {
    if (subject === void 0) return false;
    const anchor = pending.get(rowScope(effect.owner, subject));
    return anchor !== void 0 && !placed.has(anchor);
  };
  while (ordered.length < restores.length) {
    while (fullHead < full.length && placed.has(full[fullHead])) fullHead += 1;
    while (partialHead < partial.length && placed.has(partial[partialHead])) {
      partialHead += 1;
    }
    const next = fullHead < full.length ? full[fullHead++] : partialHead < partial.length ? partial[partialHead++] : restores.find(
      (effect) => !placed.has(effect) && !isWaitingOn(effect, anchorsOf(effect)?.beforeSubject)
    ) ?? restores.find((effect) => !placed.has(effect));
    placed.add(next);
    ordered.push(next);
    for (const dependent of dependents.get(
      rowScope(next.owner, next.subjectId)
    ) ?? []) {
      if (placed.has(dependent)) continue;
      const left = (waiting.get(dependent) ?? 1) - 1;
      waiting.set(dependent, left);
      hasLiveAnchor.add(dependent);
      if (left === 0) full.push(dependent);
      else partial.push(dependent);
    }
  }
  return ordered;
}
function getStructuralAddEffect(descriptor, effect) {
  if (effect.structural !== "add" || typeof effect.subjectId !== "number") {
    return void 0;
  }
  if (isStructuralEffect(effect.structuralContext)) {
    return effect.structuralContext.kind === "remove" || effect.structuralContext.kind === "add" ? effect.structuralContext : void 0;
  }
  const removeEffect = descriptor?.structuralEffects?.get(
    `remove:${String(effect.subjectId)}:${String(effect.after)}`
  );
  if (removeEffect?.kind === "remove") {
    return removeEffect;
  }
  const subjectEffect = descriptor?.structuralEffectBySubject?.get(
    String(effect.subjectId)
  );
  if (subjectEffect?.kind === "remove" || subjectEffect?.kind === "add") {
    return subjectEffect;
  }
  const addEffect = descriptor?.structuralEffects?.get(
    `add:${String(effect.subjectId)}:${String(effect.after)}`
  );
  return addEffect?.kind === "add" ? addEffect : void 0;
}
var WHOLE_SUBJECT = { kind: "whole" };
function deriveSubjectAddress(path, subjectId, structuralEffect, canonicalCollectionPath) {
  if (structuralEffect) {
    return void 0;
  }
  if (path === canonicalCollectionPath) {
    return void 0;
  }
  const prefix = `${canonicalCollectionPath}.`;
  if (!path.startsWith(prefix)) {
    return void 0;
  }
  const relative = path.slice(prefix.length);
  const firstDot = relative.indexOf(".");
  if (firstDot === -1) {
    return typeof subjectId === "number" ? WHOLE_SUBJECT : void 0;
  }
  const fieldPath = relative.slice(firstDot + 1);
  return fieldPath === "" ? void 0 : { kind: "field", path: fieldPath };
}
function encodeSubjectAddress(address) {
  if (!address) return void 0;
  return address.kind === "whole" ? "" : address.path;
}
function deriveCollectionPathLegacy(path, ownerPath, subjectId, structuralEffect) {
  if (structuralEffect) return ownerPath;
  if (path === ownerPath) {
    return ownerPath.includes(".") ? parentPath(ownerPath) : void 0;
  }
  if (!path.startsWith(`${ownerPath}.`)) return void 0;
  if (!ownerPath.includes(".")) return ownerPath;
  if (typeof subjectId !== "number") return void 0;
  return parentPath(ownerPath);
}
function deriveFieldPathFromRowLegacy(path, ownerPath, subjectId, structuralEffect) {
  if (structuralEffect) {
    return void 0;
  }
  if (path === ownerPath) {
    return "";
  }
  if (typeof subjectId !== "number" || !path.startsWith(`${ownerPath}.`)) {
    return void 0;
  }
  const relativePath = path.slice(ownerPath.length + 1);
  if (!ownerPath.includes(".")) {
    const firstDot = relativePath.indexOf(".");
    return firstDot === -1 ? "" : relativePath.slice(firstDot + 1);
  }
  return relativePath;
}
function deriveRealizationAddress(path, ownerPath, subjectId, structuralEffect, canonicalCollectionPath) {
  if (canonicalCollectionPath !== void 0) {
    return {
      collectionPath: canonicalCollectionPath,
      fieldPathFromRow: encodeSubjectAddress(
        deriveSubjectAddress(
          path,
          subjectId,
          structuralEffect,
          canonicalCollectionPath
        )
      )
    };
  }
  return {
    collectionPath: deriveCollectionPathLegacy(
      path,
      ownerPath,
      subjectId,
      structuralEffect
    ),
    fieldPathFromRow: deriveFieldPathFromRowLegacy(
      path,
      ownerPath,
      subjectId,
      structuralEffect
    )
  };
}
function parentPath(path) {
  const lastDot = path.lastIndexOf(".");
  return lastDot === -1 ? "" : path.slice(0, lastDot);
}
function forgetSubjectsInTreeRealizationDescriptors(descriptors, subjectIds) {
  if (subjectIds.length === 0 || descriptors.size === 0) {
    return;
  }
  const forgotten = new Set(subjectIds.map((id) => String(id)));
  for (const descriptor of descriptors.values()) {
    const bySubject = descriptor.structuralEffectBySubject;
    if (bySubject instanceof Map) {
      for (const key of forgotten) {
        bySubject.delete(key);
      }
    }
    const subjectDescriptors = descriptor.subjectDescriptors;
    if (subjectDescriptors instanceof Map) {
      for (const key of forgotten) {
        subjectDescriptors.delete(key);
      }
    }
    const effects = descriptor.structuralEffects;
    if (effects instanceof Map) {
      for (const key of [...effects.keys()]) {
        const firstColon = key.indexOf(":");
        if (firstColon === -1) {
          continue;
        }
        const secondColon = key.indexOf(":", firstColon + 1);
        const subject = key.slice(
          firstColon + 1,
          secondColon === -1 ? void 0 : secondColon
        );
        if (forgotten.has(subject)) {
          effects.delete(key);
        }
      }
    }
  }
}
function toStructuralEffectKey(effect) {
  switch (effect.kind) {
    case "add":
    case "remove":
      return `${effect.kind}:${String(effect.subject)}:${String(effect.key)}`;
    case "rekey":
      return `rekey:${String(effect.subject)}:${String(
        effect.beforeKey
      )}:${String(effect.afterKey)}`;
  }
}
function isWritableLeaf(value) {
  return Boolean(
    value && typeof value === "function" && "set" in value && typeof value.set === "function"
  );
}
function isWritableEntityNode(value) {
  return Boolean(
    value && typeof value === "function" && !("set" in value)
  );
}
function isStructuralEffect(value) {
  return Boolean(
    value && typeof value === "object" && "kind" in value && (value.kind === "add" || value.kind === "remove" || value.kind === "rekey")
  );
}
function isCollectionNode(value) {
  return Boolean(
    value && "byIdOrFail" in value && "changeId" in value && "removeOne" in value
  );
}
function hasCollectionKey(node, key) {
  try {
    node.byIdOrFail(key);
    return true;
  } catch {
    return false;
  }
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/transaction-lifecycle.ts
var TRANSACTION_LIFECYCLE = Symbol.for(
  "SignalTree:TransactionLifecycleChannel"
);
var TRANSACTION_LIFECYCLE_OWNER = Symbol.for(
  "SignalTree:TransactionLifecycleOwnerPresent"
);
function createChannel() {
  const listeners3 = /* @__PURE__ */ new Set();
  return {
    announce(event) {
      for (const listener of [...listeners3]) {
        try {
          listener(event);
        } catch {
        }
      }
    },
    subscribe(listener) {
      listeners3.add(listener);
      return () => {
        listeners3.delete(listener);
      };
    }
  };
}
function installTransactionLifecycleChannel(tree) {
  const host = tree;
  if (!host[TRANSACTION_LIFECYCLE_OWNER]) {
    Object.defineProperty(host, TRANSACTION_LIFECYCLE_OWNER, {
      value: true,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  const existing = host[TRANSACTION_LIFECYCLE];
  if (existing) {
    return existing;
  }
  const channel = createChannel();
  Object.defineProperty(host, TRANSACTION_LIFECYCLE, {
    value: channel,
    enumerable: false,
    writable: false,
    configurable: true
  });
  return channel;
}
function hasTransactionOwner(tree) {
  const host = tree;
  return !!host[TRANSACTION_LIFECYCLE_OWNER];
}
function tryGetTransactionLifecycleChannel(tree) {
  const host = tree;
  return host[TRANSACTION_LIFECYCLE];
}
function getTransactionLifecycleChannel(tree) {
  const channel = tryGetTransactionLifecycleChannel(tree);
  if (channel) {
    return channel;
  }
  if (hasTransactionOwner(tree)) {
    throw new Error(
      "ST1036: this tree has a transaction authority but no lifecycle channel could be resolved. The channel is installed by that owner on the tree's canonical host; failing to find one here means the install and the lookup disagree about that host, which would silently deliver no lifecycle events at all."
    );
  }
  throw new Error(
    "ST1036: this tree has no transaction capability, so it has no lifecycle channel. Add `transactions()` to the enhancers, or use `tryGetTransactionLifecycleChannel()` where absence is legitimate."
  );
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/transaction-lifecycle-source.ts
var SOURCES2 = /* @__PURE__ */ new WeakMap();
function defineTransactionLifecycleSource(registry, source) {
  SOURCES2.set(registry, source);
}
function getTransactionLifecycleSource(registry) {
  return SOURCES2.get(registry);
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/applied-turn-projection.ts
var AppliedTurnProjection = class {
  constructor(store) {
    this.store = store;
  }
  appliedTurnIds = [];
  redoTurnIds = [];
  admitConfirmed(turnId) {
    const turn = this.store.getTurn(turnId);
    if (!turn) {
      return { ok: false, reason: "turn-evicted" };
    }
    const transition2 = this.prepareAdmitConfirmedTurn({
      turnId,
      participants: turn.participants
    });
    this.commitPreparedAdmitConfirmed(transition2);
    return { ok: true };
  }
  prepareAdmitConfirmedTurn(turn) {
    return {
      turnId: turn.turnId,
      participants: [...turn.participants]
    };
  }
  commitPreparedAdmitConfirmed(transition2) {
    this.insertAppliedTurnCanonical(transition2.turnId);
    if (this.redoTurnIds.length > 0) {
      return this.invalidateOverlappingRedoTurns(transition2.participants);
    }
    return [];
  }
  prepareUnapplyConfirmedTurn(turnId) {
    const turn = this.store.getTurn(turnId);
    if (!turn) {
      return { ok: false, reason: "turn-evicted" };
    }
    const isApplied = this.appliedTurnIds.includes(turnId);
    const isParticipantFrontier = turn.participants.every(
      (participant) => this.getFrontier(participant) === turnId
    );
    if (!isApplied || !isParticipantFrontier) {
      return { ok: false, reason: "not-applied-frontier" };
    }
    return {
      ok: true,
      transition: { turnId }
    };
  }
  commitPreparedUnapply(transition2) {
    const { turnId } = transition2;
    this.removeAppliedTurn(turnId);
    this.redoTurnIds.unshift(turnId);
  }
  moveConfirmedTurnToRedo(turnId) {
    const prepared = this.prepareUnapplyConfirmedTurn(turnId);
    if (!prepared.ok) {
      return prepared;
    }
    this.commitPreparedUnapply(prepared.transition);
    return { ok: true };
  }
  prepareReapplyConfirmedTurn(turnId) {
    const turn = this.store.getTurn(turnId);
    if (!turn) {
      return { ok: false, reason: "turn-evicted" };
    }
    const isRedoable = this.redoTurnIds.includes(turnId);
    const restoresValidPrefix = turn.participants.every(
      (participant) => this.getFirstUnappliedTurnIdForPosition(participant) === turnId
    );
    if (!isRedoable || !restoresValidPrefix) {
      return { ok: false, reason: "not-redoable-next" };
    }
    return {
      ok: true,
      transition: { turnId }
    };
  }
  commitPreparedReapply(transition2) {
    const { turnId } = transition2;
    this.redoTurnIds.splice(this.redoTurnIds.indexOf(turnId), 1);
    this.insertAppliedTurnCanonical(turnId);
  }
  moveRedoTurnToApplied(turnId) {
    const prepared = this.prepareReapplyConfirmedTurn(turnId);
    if (!prepared.ok) {
      return prepared;
    }
    this.commitPreparedReapply(prepared.transition);
    return { ok: true };
  }
  getAppliedTurnIds() {
    return [...this.appliedTurnIds];
  }
  getRedoTurnIds() {
    return [...this.redoTurnIds];
  }
  forgetRetainedTurn(turnId) {
    const wasApplied = this.appliedTurnIds.includes(turnId);
    const wasRedoable = this.redoTurnIds.includes(turnId);
    if (wasApplied) {
      this.removeAppliedTurn(turnId);
    }
    if (wasRedoable) {
      this.redoTurnIds.splice(this.redoTurnIds.indexOf(turnId), 1);
    }
    return {
      wasApplied,
      wasRedoable
    };
  }
  getFrontier(positionId) {
    for (let index = this.appliedTurnIds.length - 1; index >= 0; index -= 1) {
      const turn = this.store.getTurn(this.appliedTurnIds[index]);
      if (turn?.participants.includes(positionId)) {
        return turn.id;
      }
    }
    return void 0;
  }
  inspect() {
    const frontiers = /* @__PURE__ */ new Map();
    for (const turnId of this.appliedTurnIds) {
      const turn = this.store.getTurn(turnId);
      if (!turn) {
        continue;
      }
      for (const participant of turn.participants) {
        frontiers.set(participant, turn.id);
      }
    }
    return {
      appliedTurnIds: [...this.appliedTurnIds],
      redoTurnIds: [...this.redoTurnIds],
      frontiers: Object.fromEntries(
        [...frontiers.entries()].map(([positionId, turnId]) => [
          String(positionId),
          turnId
        ])
      )
    };
  }
  removeAppliedTurn(turnId) {
    const index = this.appliedTurnIds.indexOf(turnId);
    if (index === -1) {
      return;
    }
    this.appliedTurnIds.splice(index, 1);
  }
  getFirstUnappliedTurnIdForPosition(positionId) {
    return this.store.getTurnIdsForPosition(positionId).find((turnId) => !this.appliedTurnIds.includes(turnId));
  }
  insertAppliedTurnCanonical(turnId) {
    if (this.appliedTurnIds.includes(turnId)) {
      return;
    }
    const insertionIndex = this.appliedTurnIds.findIndex(
      (appliedTurnId) => appliedTurnId > turnId
    );
    if (insertionIndex === -1) {
      this.appliedTurnIds.push(turnId);
      return;
    }
    this.appliedTurnIds.splice(insertionIndex, 0, turnId);
  }
  invalidateOverlappingRedoTurns(participants) {
    const participantSet = new Set(participants);
    const invalidatedTurnIds = this.redoTurnIds.filter((turnId) => {
      const turn = this.store.getTurn(turnId);
      if (!turn) {
        return true;
      }
      return turn.participants.some((participant) => participantSet.has(participant));
    });
    this.redoTurnIds.splice(
      0,
      this.redoTurnIds.length,
      ...this.redoTurnIds.filter((turnId) => {
        const turn = this.store.getTurn(turnId);
        if (!turn) {
          return false;
        }
        return !turn.participants.some(
          (participant) => participantSet.has(participant)
        );
      })
    );
    return invalidatedTurnIds;
  }
};

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/realization-context.ts
var ProjectionRealizationContextSource = class {
  constructor(options) {
    this.options = options;
    for (const [positionId, value] of options.baselineValues ?? []) {
      this.baselineValues.set(positionId, value);
    }
  }
  baselineValues = /* @__PURE__ */ new Map();
  forgottenConfirmedTurns = [];
  getCurrentValue(positionId) {
    return this.computeValues().get(positionId);
  }
  getValueWithoutConfirmedTurn(turnId, positionId) {
    return this.computeValues(turnId).get(positionId);
  }
  getValueWithoutPendingTurn(turnId, positionId) {
    return this.computeValues(void 0, turnId).get(positionId);
  }
  retainEvictedConfirmedTurn(turn) {
    const disposition = this.options.appliedTurns.forgetRetainedTurn(turn.id);
    if (!disposition.wasApplied && !disposition.wasRedoable) {
      return;
    }
    if (disposition.wasApplied) {
      for (const effect of turn.effects) {
        this.baselineValues.set(effect.owner, effect.after);
      }
    }
    this.forgottenConfirmedTurns.push(copyTurn(turn));
  }
  consumeForgottenConfirmedTurns() {
    const forgotten = this.forgottenConfirmedTurns.map(copyTurn);
    this.forgottenConfirmedTurns.length = 0;
    return forgotten;
  }
  computeValues(excludingConfirmedTurnId, excludingPendingTurnId) {
    const values = new Map(this.baselineValues);
    const activeConfirmedTurns = this.options.appliedTurns.getAppliedTurnIds().filter((turnId) => turnId !== excludingConfirmedTurnId).map((turnId) => this.options.store.getTurn(turnId)).filter((turn) => turn !== void 0);
    const activePendingTurns = this.options.store.getPendingTurns().filter((turn) => turn.id !== excludingPendingTurnId);
    const activeTurns = [...activeConfirmedTurns, ...activePendingTurns].sort(
      (left, right) => left.id - right.id
    );
    for (const turn of activeTurns) {
      for (const effect of turn.effects) {
        values.set(effect.owner, effect.after);
      }
    }
    for (const [positionId, value] of this.options.getOverlayValues?.() ?? []) {
      values.set(positionId, value);
    }
    return values;
  }
};
function createRealizationContextSource(options) {
  return new ProjectionRealizationContextSource(options);
}
function copyTurn(turn) {
  return {
    ...turn,
    effects: turn.effects.map((effect) => ({
      ...effect
    })),
    participants: [...turn.participants]
  };
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/turn-store.ts
var TurnStore = class {
  capacity;
  retainEvictedConfirmedTurn;
  onEvictConfirmedTurn;
  reportEvictionObserverError;
  confirmedTurns = /* @__PURE__ */ new Map();
  pendingTurns = /* @__PURE__ */ new Map();
  orderedConfirmedTurnIds = [];
  positionIndex = /* @__PURE__ */ new Map();
  constructor(options) {
    this.capacity = options?.capacity ?? Number.POSITIVE_INFINITY;
    this.retainEvictedConfirmedTurn = options?.retainEvictedConfirmedTurn;
    this.onEvictConfirmedTurn = options?.onEvictConfirmedTurn;
    this.reportEvictionObserverError = options?.reportEvictionObserverError;
  }
  admitConfirmed(turn) {
    this.assertTurnIdAvailable(turn.id);
    const canonicalTurn = {
      id: turn.id,
      effects: [...turn.effects],
      participants: this.deriveParticipants(turn.effects),
      state: "confirmed"
    };
    this.insertConfirmed(canonicalTurn);
    return canonicalTurn;
  }
  admitPending(turn) {
    this.assertTurnIdAvailable(turn.id);
    const pendingTurn = {
      id: turn.id,
      effects: [...turn.effects],
      participants: this.deriveParticipants(turn.effects),
      state: "pending"
    };
    this.pendingTurns.set(pendingTurn.id, pendingTurn);
    return pendingTurn;
  }
  confirmPending(turnId) {
    const prepared = this.prepareConfirmPendingTurn(turnId);
    if (!prepared.ok) {
      return void 0;
    }
    return this.commitPreparedConfirmPending(prepared.transition);
  }
  discardPending(turnId) {
    const pendingTurn = this.pendingTurns.get(turnId);
    if (!pendingTurn) {
      return void 0;
    }
    this.pendingTurns.delete(turnId);
    return pendingTurn;
  }
  prepareDiscardPendingTurn(turnId) {
    if (!this.pendingTurns.has(turnId)) {
      return { ok: false, reason: "turn-evicted" };
    }
    return {
      ok: true,
      transition: { turnId }
    };
  }
  prepareConfirmPendingTurn(turnId) {
    const pendingTurn = this.pendingTurns.get(turnId);
    if (!pendingTurn) {
      return { ok: false, reason: "turn-evicted" };
    }
    return {
      ok: true,
      transition: {
        turnId,
        pendingTurn: {
          ...pendingTurn,
          effects: [...pendingTurn.effects],
          participants: [...pendingTurn.participants]
        }
      }
    };
  }
  commitPreparedConfirmPending(transition2) {
    const pendingTurn = this.pendingTurns.get(transition2.turnId);
    if (!pendingTurn) {
      throw new Error(`Prepared pending turn ${transition2.turnId} no longer exists`);
    }
    this.assertTurnIdNotConfirmed(transition2.turnId);
    this.pendingTurns.delete(transition2.turnId);
    const confirmedTurn = {
      ...transition2.pendingTurn,
      effects: [...transition2.pendingTurn.effects],
      participants: [...transition2.pendingTurn.participants],
      state: "confirmed"
    };
    this.insertConfirmed(confirmedTurn);
    return confirmedTurn;
  }
  commitPreparedDiscardPending(transition2) {
    return this.discardPending(transition2.turnId);
  }
  hasPendingTurn(turnId) {
    return this.pendingTurns.has(turnId);
  }
  getTurn(turnId) {
    return this.confirmedTurns.get(turnId);
  }
  getTurns() {
    return this.orderedConfirmedTurnIds.map((turnId) => this.confirmedTurns.get(turnId)).filter((turn) => turn !== void 0);
  }
  getPendingTurn(turnId) {
    return this.pendingTurns.get(turnId);
  }
  getPendingTurns() {
    return [...this.pendingTurns.values()].sort((left, right) => left.id - right.id);
  }
  getPendingTurnIds() {
    return this.getPendingTurns().map(({ id }) => id);
  }
  getTurnIdsForPosition(positionId) {
    return [...this.positionIndex.get(positionId) ?? []];
  }
  getTurnsForPosition(positionId) {
    return this.getTurnIdsForPosition(positionId).map((turnId) => this.confirmedTurns.get(turnId)).filter((turn) => turn !== void 0);
  }
  getFrontier(positionId) {
    const turnIds = this.positionIndex.get(positionId);
    if (!turnIds || turnIds.length === 0) {
      return void 0;
    }
    return turnIds[turnIds.length - 1];
  }
  inspect() {
    const positionIndex = Object.fromEntries(
      [...this.positionIndex.entries()].map(([positionId, turnIds]) => [
        String(positionId),
        [...turnIds]
      ])
    );
    return {
      turnIds: [...this.orderedConfirmedTurnIds],
      positionIndex,
      frontiers: Object.fromEntries(
        Object.entries(positionIndex).map(([positionId, turnIds]) => [
          positionId,
          turnIds[turnIds.length - 1]
        ])
      )
    };
  }
  deriveParticipants(effects) {
    return [...new Set(effects.map(({ owner }) => owner))];
  }
  assertTurnIdAvailable(turnId) {
    if (this.confirmedTurns.has(turnId) || this.pendingTurns.has(turnId)) {
      throw new Error(`Turn ${turnId} already exists`);
    }
  }
  assertTurnIdNotConfirmed(turnId) {
    if (this.confirmedTurns.has(turnId)) {
      throw new Error(`Turn ${turnId} already exists`);
    }
  }
  insertConfirmed(turn) {
    this.assertTurnIdNotConfirmed(turn.id);
    this.confirmedTurns.set(turn.id, turn);
    const insertAt = this.orderedConfirmedTurnIds.findIndex(
      (candidateTurnId) => candidateTurnId > turn.id
    );
    if (insertAt === -1) {
      this.orderedConfirmedTurnIds.push(turn.id);
    } else {
      this.orderedConfirmedTurnIds.splice(insertAt, 0, turn.id);
    }
    for (const participant of turn.participants) {
      const turnIds = this.positionIndex.get(participant) ?? [];
      const participantInsertAt = turnIds.findIndex(
        (candidateTurnId) => candidateTurnId > turn.id
      );
      if (participantInsertAt === -1) {
        turnIds.push(turn.id);
      } else {
        turnIds.splice(participantInsertAt, 0, turn.id);
      }
      this.positionIndex.set(participant, turnIds);
    }
    this.enforceCapacity();
  }
  enforceCapacity() {
    while (this.orderedConfirmedTurnIds.length > this.capacity) {
      const evictedTurnId = this.orderedConfirmedTurnIds.shift();
      if (evictedTurnId === void 0) {
        return;
      }
      const evictedTurn = this.confirmedTurns.get(evictedTurnId);
      if (evictedTurn) {
        this.retainEvictedConfirmedTurn?.(evictedTurn);
        try {
          this.onEvictConfirmedTurn?.(evictedTurn);
        } catch (error) {
          this.reportObserverFailure(error, evictedTurn);
        }
      }
      this.confirmedTurns.delete(evictedTurnId);
      if (!evictedTurn) {
        continue;
      }
      for (const participant of evictedTurn.participants) {
        const turnIds = this.positionIndex.get(participant);
        if (!turnIds) {
          continue;
        }
        const nextTurnIds = turnIds.filter((turnId) => turnId !== evictedTurnId);
        if (nextTurnIds.length === 0) {
          this.positionIndex.delete(participant);
          continue;
        }
        this.positionIndex.set(participant, nextTurnIds);
      }
    }
  }
  reportObserverFailure(error, turn) {
    if (this.reportEvictionObserverError) {
      this.reportEvictionObserverError(error, turn);
      return;
    }
    queueMicrotask(() => {
      throw normalizeError2(error);
    });
  }
};
function normalizeError2(error) {
  if (error instanceof Error) {
    return error;
  }
  return new Error(String(error));
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions.ts
var INTERNAL_TRANSACTION_RUNTIME = Symbol(
  "signaltree:internal:transaction-runtime"
);
var PENDING_TURN_ID = Symbol("signaltree:internal:pending-turn-id");
var ROLLBACK_ERROR_MESSAGE = "SignalTree could not rollback the pending transaction";
var explainRollbackFailure = (cause) => {
  if (cause.kind === "later-confirmed-dependency") {
    const at = cause.conflictingTurnId === void 0 ? "later work" : `turn ${cause.conflictingTurnId}`;
    return `${ROLLBACK_ERROR_MESSAGE}: ${at} depends on state this rollback would invalidate, so reversing turn ${cause.pendingTurnId} is no longer safe [later-confirmed-dependency]`;
  }
  return `${ROLLBACK_ERROR_MESSAGE}: compensating turn ${cause.pendingTurnId} failed validation \u2014 ${cause.errorMessage} [effect-validation-failed]`;
};
var createRollbackError = (cause) => new SignalTreeRollbackError(explainRollbackFailure(cause), { cause });
function cloneTurnEffect(effect) {
  return effect.kind === "set" && effect.subjectFieldSegments ? { ...effect, subjectFieldSegments: [...effect.subjectFieldSegments] } : { ...effect };
}
function combineScalarMutationIntent(left, right) {
  if (left === "replace" || right === "replace") {
    return "replace";
  }
  if (left === "derive" || right === "derive") {
    return "derive";
  }
  return void 0;
}
function scalarRelation(left, right) {
  const a = left.subjectFieldSegments;
  const b = right.subjectFieldSegments;
  if (a && b) {
    const common = Math.min(a.length, b.length);
    for (let i = 0; i < common; i++) if (a[i] !== b[i]) return "disjoint";
    return a.length === b.length ? "same" : "overlap";
  }
  if (left.path === right.path) return "same";
  return left.path.startsWith(`${right.path}.`) || right.path.startsWith(`${left.path}.`) ? "overlap" : "disjoint";
}
function buildPendingRollbackPlan(pendingTurn, laterEffects, encloses) {
  if (!pendingTurn) {
    return { compensation: [] };
  }
  const pendingEffects = pendingTurn.__effects ?? [];
  const makeScalarKey = (effect) => JSON.stringify([
    effect.position,
    effect.subject,
    effect.subjectFieldSegments ?? effect.path
  ]);
  const supersededScalarKeys = new Set(
    laterEffects.map(({ effect }) => effect).filter((effect) => effect.kind === "set").map(makeScalarKey)
  );
  const classifyLaterOverlap = (effect) => {
    let superseded = false;
    for (const laterEntry of laterEffects) {
      const laterEffect = laterEntry.effect;
      if (laterEffect.position !== effect.position) {
        if (effect.plainBranchMembership?.before === false && effect.plainBranchMembership.after === true && encloses?.(effect.position, laterEffect.position)) {
          return {
            kind: "conflict",
            conflictingTurnId: laterEntry.turnId,
            conflictingEffect: laterEffect
          };
        }
        continue;
      }
      if (laterEffect.subject !== void 0 && effect.subject !== void 0 && laterEffect.subject !== effect.subject) {
        continue;
      }
      if (laterEffect.kind === "set" ? scalarRelation(effect, laterEffect) === "same" : laterEffect.path === effect.path) {
        if (laterEffect.kind !== "set") {
          return {
            kind: "conflict",
            conflictingTurnId: laterEntry.turnId,
            conflictingEffect: laterEffect
          };
        }
        if (laterEffect.mutationIntent === "replace") {
          if (supersededScalarKeys.has(makeScalarKey(effect))) {
            superseded = true;
            continue;
          }
        }
        return {
          kind: "conflict",
          conflictingTurnId: laterEntry.turnId,
          conflictingEffect: laterEffect
        };
      }
      if (laterEffect.kind === "set" ? scalarRelation(effect, laterEffect) === "overlap" : laterEffect.path.startsWith(`${effect.path}.`) || effect.path.startsWith(`${laterEffect.path}.`)) {
        return {
          kind: "conflict",
          conflictingTurnId: laterEntry.turnId,
          conflictingEffect: laterEffect
        };
      }
    }
    return superseded ? { kind: "superseded" } : { kind: "none" };
  };
  const hasSameSubjectDependency = (effect) => {
    for (const laterEntry of laterEffects) {
      const laterEffect = laterEntry.effect;
      if (laterEffect.ownerPath !== effect.ownerPath) {
        continue;
      }
      if (laterEffect.kind === "set") {
        if (laterEffect.subject === effect.subject && effect.kind !== "rekey") {
          return {
            conflictingTurnId: laterEntry.turnId,
            conflictingEffect: laterEffect
          };
        }
        continue;
      }
      if (laterEffect.subject === effect.subject) {
        return {
          conflictingTurnId: laterEntry.turnId,
          conflictingEffect: laterEffect
        };
      }
    }
    return void 0;
  };
  const classifyStructuralOverlap = (effect) => {
    if (effect.kind === "add" || effect.kind === "rekey") {
      let erased = false;
      for (const laterEntry of laterEffects) {
        const laterEffect = laterEntry.effect;
        if (laterEffect.ownerPath !== effect.ownerPath) {
          continue;
        }
        if (laterEffect.subject !== effect.subject) {
          continue;
        }
        erased = laterEffect.kind === "remove";
      }
      if (erased) {
        return { kind: "superseded" };
      }
    }
    if (effect.kind === "rekey") {
      let occupant;
      for (const laterEntry of laterEffects) {
        const later = laterEntry.effect;
        if (later.ownerPath !== effect.ownerPath) continue;
        if (later.kind === "add" && later.key === effect.beforeKey) {
          occupant = later.subject === effect.subject ? void 0 : laterEntry;
        } else if (later.kind === "remove" && later.key === effect.beforeKey) {
          occupant = void 0;
        } else if (later.kind === "rekey") {
          if (later.beforeKey === effect.beforeKey) occupant = void 0;
          if (later.afterKey === effect.beforeKey && later.subject !== effect.subject) {
            occupant = laterEntry;
          }
        }
      }
      if (occupant) {
        return {
          kind: "conflict",
          conflictingTurnId: occupant.turnId,
          conflictingEffect: occupant.effect
        };
      }
    }
    const dependency = hasSameSubjectDependency(effect);
    return dependency ? {
      kind: "conflict",
      conflictingTurnId: dependency.conflictingTurnId,
      conflictingEffect: dependency.conflictingEffect
    } : { kind: "none" };
  };
  const compensation = [];
  for (let i = pendingEffects.length - 1; i >= 0; i--) {
    const effect = pendingEffects[i];
    switch (effect.kind) {
      case "set": {
        const overlap = classifyLaterOverlap(effect);
        if (overlap.kind === "conflict") {
          return {
            conflict: {
              kind: "later-confirmed-dependency",
              pendingTurnId: pendingTurn.id,
              pendingEffect: effect,
              conflictingTurnId: overlap.conflictingTurnId,
              conflictingEffect: overlap.conflictingEffect
            }
          };
        }
        if (overlap.kind === "superseded") {
          continue;
        }
        compensation.push(effect);
        break;
      }
      case "add":
      case "remove":
      case "rekey": {
        const overlap = classifyStructuralOverlap(effect);
        if (overlap.kind === "conflict") {
          return {
            conflict: {
              kind: "later-confirmed-dependency",
              pendingTurnId: pendingTurn.id,
              pendingEffect: effect,
              conflictingTurnId: overlap.conflictingTurnId,
              conflictingEffect: overlap.conflictingEffect
            }
          };
        }
        if (overlap.kind === "superseded") {
          continue;
        }
        compensation.push(effect);
        break;
      }
    }
  }
  return { compensation };
}
var TransactionAuthority = class {
  /**
   * Restoration-claim hooks, injected because the authority has no tree.
   *
   * An UNSETTLED turn owns the subjects it retired: Phase 6B measured that
   * reclaiming one makes `rollback()` throw and loses the row permanently. The
   * claim exists for exactly that interval — optimistic mutation to settlement,
   * confirm or reject alike — so the bound is how many operations are
   * outstanding right now, never a configured depth.
   */
  constructor(retainPendingClaims = () => void 0, releasePendingClaims = () => void 0, encloses) {
    this.retainPendingClaims = retainPendingClaims;
    this.releasePendingClaims = releasePendingClaims;
    this.encloses = encloses;
  }
  confirmedTurns = [];
  /**
   * L15. Records kept purely as evidence, beyond what correctness requires.
   * 0 means correctness-only, which is the default.
   */
  historyRetain = 0;
  /**
   * Whether an explicit retention contract exists. Until one does, the ledger
   * is left exactly as it has always behaved: the reader-visible history
   * policy may not change silently, and `confirmedTurnReader` is a shipped
   * surface whose purpose is reading confirmed history.
   */
  /**
   * Set once any confirmed record has actually been dropped. The reader must
   * never infer truncation from id gaps — pending and rejected turns leave
   * gaps too — so this is the explicit metadata internals.ts asks for,
   * including the case where the whole window is gone.
   */
  evictedConfirmed = false;
  pendingTurns = /* @__PURE__ */ new Map();
  // How many pending turns wrote each position. Kept in step with
  // `pendingTurns` at its only three mutation sites, so asking whether a
  // settlement may forget a descriptor is O(1) rather than a rebuild of every
  // pending turn's positions (which made settling P overlapping turns O(P^2)).
  pendingPositionCounts = /* @__PURE__ */ new Map();
  nextTurnId = 1;
  queuedEvidence = /* @__PURE__ */ new Map();
  /**
   * TX-LEDGER C3 — later effects that are NOT authored turns.
   *
   * Rollback safety asks "has anything since relied on the structure I am about
   * to invalidate?". That question is about causal DEPENDENCE, not authorship,
   * and the old answer came only from `confirmedTurns` — which excludes
   * realizations by construction. So a server refresh landing on a speculative
   * row created no dependency and the rollback deleted the row the server had
   * just written to: RESTORE-P0 P0-C one layer up.
   *
   * Deliberately NOT a causal history:
   *
   *   recorded ONLY while a pending turn exists   nothing outstanding, nothing
   *                                               retained
   *   dropped when the last pending turn settles  no accumulation
   *   monotonic                                   a dependency latches; the
   *                                               later write being reversed by
   *                                               hand does not un-depend it
   *                                               (measured, case 4)
   *   sequence-scoped                             a turn only sees effects that
   *                                               landed after IT opened
   *
   * The sequence matters with two open transactions: an effect recorded before
   * the second opened is not "later" for the second, only for the first.
   */
  dependencyLedger = [];
  ledgerSeq = 0;
  pendingOpenedAtSeq = /* @__PURE__ */ new Map();
  buildTurn(subjectIds, positionIds, effects, baselineValues, reservedId) {
    if ((subjectIds?.length ?? 0) === 0 && (positionIds?.length ?? 0) === 0 && (effects?.length ?? 0) === 0) {
      return void 0;
    }
    return {
      id: reservedId ?? this.nextTurnId++,
      restorationSubjectIds: subjectIds ? [...subjectIds] : void 0,
      __positionIds: positionIds ? [...positionIds] : void 0,
      __effects: effects ? effects.map(cloneTurnEffect) : void 0,
      __baselineValues: baselineValues ? new Map(baselineValues) : void 0
    };
  }
  recordConfirmed(subjectIds, positionIds, effects) {
    const turn = this.buildTurn(subjectIds, positionIds, effects);
    if (!turn) {
      return void 0;
    }
    this.insertConfirmed(turn);
    this.releaseConfirmedBeyondObligation();
    return cloneTurnRecord(turn);
  }
  /**
   * Reserve a transaction's contribution order before anything can re-enter.
   *
   * The id used to be allocated at materialization, AFTER the post-callback
   * flush. A write made by an observer of the callback's own writes was then
   * recorded first, received the OLDER id, and was invisible to this turn's
   * rollback: `confirmedTurns.filter(t => t.id > pendingId)` excluded it, the
   * obligation bound could evict it, and an external write never entered the
   * dependency ledger because nothing was pending yet. Observed writes must
   * stay later than the transaction they observe.
   *
   * The placeholder owns no second ledger: its effects are a live view of the
   * open capture, so an older handle settled from inside this callback (or by
   * an observer before this handle exists) sees the writes captured so far.
   * `createPending` replaces it; `discardPending` releases it.
   */
  reservePending(bucket) {
    const id = this.nextTurnId++;
    this.pendingTurns.set(id, {
      id,
      get __effects() {
        return [
          ...bucket.effects.values(),
          ...bucket.entityFootprints.values()
        ];
      }
    });
    this.pendingOpenedAtSeq.set(id, this.ledgerSeq);
    return id;
  }
  createPending(reservedId, subjectIds, positionIds, effects, baselineValues) {
    const turn = this.buildTurn(
      subjectIds,
      positionIds,
      effects,
      baselineValues,
      reservedId
    );
    if (!turn) {
      this.discardPending(reservedId);
      return void 0;
    }
    this.pendingTurns.set(turn.id, turn);
    this.countPendingPositions(turn, 1);
    this.retainPendingClaims(turn.id, turn.restorationSubjectIds ?? []);
    return cloneTurnRecord(turn);
  }
  /**
   * Record a later effect for dependency purposes, whatever authored it.
   *
   * Returns immediately when nothing is pending, which is what keeps this a
   * projection rather than an inventory: with no outstanding rollback right
   * there is no question to answer and nothing is kept.
   *
   * @internal
   */
  observeLaterEffects(effects) {
    if (this.pendingTurns.size === 0 || effects.length === 0) {
      return;
    }
    this.ledgerSeq += 1;
    for (const effect of effects) {
      this.dependencyLedger.push({ seq: this.ledgerSeq, effect });
    }
  }
  /** Drop the ledger once no pending turn can ask about it. */
  releaseLedgerIfQuiet() {
    if (this.pendingTurns.size === 0) {
      this.dependencyLedger = [];
      this.ledgerSeq = 0;
      this.pendingOpenedAtSeq.clear();
    }
  }
  confirmPending(turnId) {
    const turn = this.pendingTurns.get(turnId);
    if (!turn) {
      return void 0;
    }
    this.pendingTurns.delete(turnId);
    this.countPendingPositions(turn, -1);
    this.pendingOpenedAtSeq.delete(turnId);
    this.queuedEvidence.delete(turnId);
    this.releasePendingClaims(turnId);
    this.insertConfirmed(turn);
    this.releaseLedgerIfQuiet();
    this.releaseConfirmedBeyondObligation();
    return cloneTurnRecord(turn);
  }
  discardPending(turnId) {
    const turn = this.pendingTurns.get(turnId);
    if (!turn) {
      return void 0;
    }
    this.pendingTurns.delete(turnId);
    this.countPendingPositions(turn, -1);
    this.pendingOpenedAtSeq.delete(turnId);
    this.queuedEvidence.delete(turnId);
    this.releasePendingClaims(turnId);
    this.releaseLedgerIfQuiet();
    this.releaseConfirmedBeyondObligation();
    return cloneTurnRecord(turn);
  }
  observeQueuedEffects(turnId, queued2) {
    if (!this.pendingTurns.has(turnId)) return;
    let retained = this.queuedEvidence.get(turnId);
    if (!retained && queued2.length) {
      retained = /* @__PURE__ */ new Map();
      this.queuedEvidence.set(turnId, retained);
    }
    for (const effect of queued2) {
      retained?.set(
        JSON.stringify([
          effect.kind,
          effect.position,
          effect.subject ?? null,
          effect.kind === "set" ? effect.subjectFieldSegments ?? effect.path : effect.path
        ]),
        effect
      );
    }
  }
  getPendingRollbackPlan(turnId, queued2 = []) {
    this.observeQueuedEffects(turnId, queued2);
    const pending = this.pendingTurns.get(turnId);
    const retained = this.queuedEvidence.get(turnId);
    for (const later of this.pendingTurns.values()) {
      if (later.id <= turnId) continue;
      for (const effect of pending?.__effects ?? []) {
        const overlap = later.__effects?.find(
          (candidate) => candidate.position === effect.position && (candidate.subject === void 0 || effect.subject === void 0 || candidate.subject === effect.subject) && (candidate.kind === "set" && effect.kind === "set" ? scalarRelation(candidate, effect) !== "disjoint" : candidate.path === effect.path || candidate.path.startsWith(`${effect.path}.`) || effect.path.startsWith(`${candidate.path}.`)) || // A later pending membership change of an enclosing member
          // captured this location in its own before-image just the same.
          // (v16 integration 8b.)
          candidate.kind === "set" && candidate.plainBranchMembership !== void 0 && this.encloses?.(candidate.position, effect.position) === true || effect.kind === "set" && effect.plainBranchMembership?.before === false && effect.plainBranchMembership.after === true && this.encloses?.(effect.position, candidate.position) === true
        );
        if (overlap)
          return {
            conflict: {
              kind: "later-confirmed-dependency",
              pendingTurnId: turnId,
              pendingEffect: effect,
              conflictingTurnId: later.id,
              conflictingEffect: overlap
            }
          };
        if (effect.kind === "rekey") {
          const occupant = later.__effects?.find(
            (candidate) => candidate.kind === "add" && candidate.ownerPath === effect.ownerPath && candidate.key === effect.beforeKey && candidate.subject !== effect.subject
          );
          if (occupant)
            return {
              conflict: {
                kind: "later-confirmed-dependency",
                pendingTurnId: turnId,
                pendingEffect: effect,
                conflictingTurnId: later.id,
                conflictingEffect: occupant
              }
            };
        }
      }
    }
    const authoredLater = this.confirmedTurns.filter((turn) => turn.id > turnId).flatMap(
      (turn) => (turn.__effects ?? []).map((effect) => ({ turnId: turn.id, effect }))
    );
    const openedAt = this.pendingOpenedAtSeq.get(turnId) ?? 0;
    const observedLater = this.dependencyLedger.filter((entry) => entry.seq > openedAt).map((entry) => ({
      entry: { turnId, effect: entry.effect },
      seq: entry.seq
    }));
    const ordered = [
      ...authoredLater.map((entry) => ({
        entry,
        seq: this.confirmedAtSeq.get(entry.turnId) ?? 0
      })),
      ...observedLater
    ].sort((a, b) => a.seq - b.seq).map((wrapped) => wrapped.entry);
    return buildPendingRollbackPlan(
      this.pendingTurns.get(turnId),
      [
        ...ordered,
        ...[...retained?.values() ?? []].map((effect) => ({
          turnId,
          effect
        }))
      ],
      this.encloses
    );
  }
  setHistoryRetention(retain) {
    this.historyRetain = Number.isFinite(retain) && retain > 0 ? retain : 0;
    this.releaseConfirmedBeyondObligation();
  }
  /**
   * L15: correctness retention follows live responsibility.
   *
   * `getPendingRollbackPlan` is the ONLY correctness consumer of this ledger,
   * and it selects `confirmedTurns.filter(t => t.id > pendingId)`. Turn ids are
   * monotonic, so a confirmed turn can only ever be needed by a pending turn
   * OLDER than itself. Once no such pending turn remains, the record can never
   * appear in any future plan, and keeping it is diagnostics, not correctness.
   * (A `hasConfirmedTurnAfter` reader existed alongside it with no call sites
   * anywhere and was deleted, so it imposes no obligation either.)
   *
   * This is not an arbitrary cap: the bound is derived from the obligation.
   * `historyRetain` is a SEPARATE, explicitly requested evidence facility
   * layered on top of it.
   */
  releaseConfirmedBeyondObligation() {
    if (this.confirmedTurns.length === 0) return;
    let minPending = Infinity;
    for (const id of this.pendingTurns.keys()) {
      if (id < minPending) minPending = id;
    }
    const required = (turn) => turn.id > minPending;
    const before = this.confirmedTurns.length;
    if (this.historyRetain <= 0) {
      this.confirmedTurns = this.confirmedTurns.filter(required);
      if (this.confirmedTurns.length < before) this.evictedConfirmed = true;
      this.forgetStampsOutside();
      return;
    }
    const keep = /* @__PURE__ */ new Set();
    for (const turn of this.confirmedTurns)
      if (required(turn)) keep.add(turn.id);
    for (const turn of this.confirmedTurns.slice(-this.historyRetain))
      keep.add(turn.id);
    this.confirmedTurns = this.confirmedTurns.filter((t) => keep.has(t.id));
    if (this.confirmedTurns.length < before) this.evictedConfirmed = true;
    this.forgetStampsOutside();
  }
  /**
   * `confirmedAtSeq` is CORRECTNESS state — `getPendingRollbackPlan` reads it
   * to order `authoredLater` — so L15 binds it exactly as it binds the records
   * themselves. Bounding the array while letting the stamps accumulate left
   * ~50 B per settled turn growing linearly forever while the ledger reported
   * zero retained records, which made "correctness-only retention" only half
   * true.
   */
  forgetStampsOutside() {
    if (this.confirmedAtSeq.size === 0) return;
    const live = new Set(this.confirmedTurns.map((turn) => turn.id));
    for (const id of this.confirmedAtSeq.keys()) {
      if (!live.has(id)) this.confirmedAtSeq.delete(id);
    }
  }
  /** Explicit retention metadata for the reader. Never inferred from ids. */
  getConfirmedRetention() {
    return {
      truncated: this.evictedConfirmed,
      firstAvailableTurnId: this.confirmedTurns[0]?.id
    };
  }
  releaseConfirmedTurnsOnDestroy() {
    this.confirmedAtSeq.clear();
    this.confirmedTurns = [];
  }
  getConfirmedTurnCount() {
    return this.confirmedTurns.length;
  }
  getPendingTurn(turnId) {
    return turnId === void 0 ? void 0 : this.pendingTurns.get(turnId);
  }
  getPendingTurnCount() {
    return this.pendingTurns.size;
  }
  getConfirmedTurnIds() {
    return this.confirmedTurns.map((turn) => turn.id);
  }
  getPendingTurnIds() {
    return [...this.pendingTurns.keys()].sort((left, right) => left - right);
  }
  /** Whether a still-pending turn wrote this position; its rollback needs the realization. */
  isPositionPending(position) {
    return this.pendingPositionCounts.has(position);
  }
  countPendingPositions(turn, delta) {
    for (const position of new Set(turn.__positionIds ?? [])) {
      const next = (this.pendingPositionCounts.get(position) ?? 0) + delta;
      if (next > 0) this.pendingPositionCounts.set(position, next);
      else this.pendingPositionCounts.delete(position);
    }
  }
  /**
   * @internal Raw retained records, for the `/internals` read seam.
   *
   *     A PROJECTION ON THIS CLASS CANNOT BE TREE-SHAKEN.
   *
   * ⚠️ This used to be `readConfirmedTurns()`, which built the whole
   * `ConfirmedTurnView` here. Class methods are retained whenever the class is
   * instantiated, and the transactions enhancer always instantiates this one —
   * so every consumer of `transactions()` paid for the projection whether or
   * not any tool ever read it. Measured: +489 B minified / +161 B gzip against
   * a 100 B budget.
   *
   * The projection now lives in `internals.ts` and is pulled in only by a build
   * that imports `@signal-tree/kernel/internals`. What remains here is the
   * narrow accessor that cannot live anywhere else.
   */
  getConfirmedTurnRecords() {
    return this.confirmedTurns;
  }
  /**
   * When each confirmed turn entered the ledger, on the SAME clock the
   * dependency ledger uses. Without this, later-effects can only be ordered
   * within their own source.
   */
  confirmedAtSeq = /* @__PURE__ */ new Map();
  insertConfirmed(turn) {
    this.ledgerSeq += 1;
    this.confirmedAtSeq.set(turn.id, this.ledgerSeq);
    const insertIndex = this.confirmedTurns.findIndex(
      (candidate) => candidate.id > turn.id
    );
    if (insertIndex === -1) {
      this.confirmedTurns.push(turn);
    } else {
      this.confirmedTurns.splice(insertIndex, 0, turn);
    }
  }
};
function cloneTurnRecord(turn) {
  return {
    ...turn,
    restorationSubjectIds: turn.restorationSubjectIds ? [...turn.restorationSubjectIds] : void 0,
    __positionIds: turn.__positionIds ? [...turn.__positionIds] : void 0,
    __effects: turn.__effects ? turn.__effects.map(cloneTurnEffect) : void 0,
    __baselineValues: turn.__baselineValues ? new Map(turn.__baselineValues) : void 0
  };
}
function createCaptureBucket() {
  return {
    entityFootprints: /* @__PURE__ */ new Map(),
    ownWriteSeq: /* @__PURE__ */ new Map(),
    ownerPaths: /* @__PURE__ */ new Set(),
    subjectIds: /* @__PURE__ */ new Set(),
    positionIds: /* @__PURE__ */ new Set(),
    baselineValues: /* @__PURE__ */ new Map(),
    effects: /* @__PURE__ */ new Map(),
    collectionOrders: /* @__PURE__ */ new Map()
  };
}
function getOrCreateInternalTransactionRuntime(tree) {
  const existing = tree[INTERNAL_TRANSACTION_RUNTIME];
  if (existing) {
    return existing;
  }
  const authority = new TransactionAuthority(
    (turnId, subjectIds) => {
      if (subjectIds.length === 0) {
        return;
      }
      getOrCreateSubjectRestorationClaims(tree)?.retain(
        `transaction:${turnId}`,
        subjectIds
      );
    },
    (turnId) => {
      getOrCreateSubjectRestorationClaims(tree)?.release(
        `transaction:${turnId}`
      );
    },
    // Structured addresses, never display paths: `outer` encloses `inner`
    // when its address is a strict prefix of inner's.
    (outer, inner) => {
      const registry = getPositionRegistry(tree.$);
      const prefix = registry?.addressFor(outer);
      const address = registry?.addressFor(inner);
      return !!prefix && !!address && prefix.length < address.length && prefix.every((key, index) => key === address[index]);
    }
  );
  const transactionOwnerToken = {};
  let nextTransactionId = 1;
  let destroyed = false;
  const isRestoring = false;
  let selfDirty = false;
  let unsubscribeFlush = null;
  let unsubscribeNotifications = null;
  let unsubscribeEnqueue = null;
  let unsubscribeReset = null;
  let unsubscribeCollectionOrders = null;
  let restoreLeafInterceptors = null;
  const pendingCapture = createCaptureBucket();
  const pendingTransactions = /* @__PURE__ */ new Map();
  const callbackExternalEffects = /* @__PURE__ */ new Map();
  let inspectionSeq = 0;
  let inspectionUnavailable = false;
  const inspectionWrites = /* @__PURE__ */ new Map();
  const inspectionTransactionByTurn = /* @__PURE__ */ new Map();
  let registerEnqueueObserver = null;
  let enqueueReleaseScheduled = false;
  const ensureEnqueueObserver = () => {
    if (!unsubscribeEnqueue && !destroyed) registerEnqueueObserver?.();
  };
  const releaseEnqueueObserverWhenIdle = () => {
    if (enqueueReleaseScheduled || !unsubscribeEnqueue) return;
    enqueueReleaseScheduled = true;
    queueMicrotask(() => {
      enqueueReleaseScheduled = false;
      if (authority.getPendingTurnCount() || pendingTransactions.size) return;
      unsubscribeEnqueue?.();
      unsubscribeEnqueue = null;
    });
  };
  const releaseInspectionIfQuiet = () => {
    if (authority.getPendingTurnCount() || pendingTransactions.size) return;
    inspectionWrites.clear();
    inspectionTransactionByTurn.clear();
    inspectionSeq = 0;
    inspectionUnavailable = false;
    releaseEnqueueObserverWhenIdle();
  };
  const pendingOrderDeltas = /* @__PURE__ */ new Map();
  const pendingCreatedListeners = /* @__PURE__ */ new Set();
  const pendingConfirmedListeners = /* @__PURE__ */ new Set();
  const pendingDiscardedListeners = /* @__PURE__ */ new Set();
  const lifecycleViews = /* @__PURE__ */ new Map();
  const lifecycleScopes = /* @__PURE__ */ new Set();
  const consequencesReleased = (transactionId) => lifecycleScopes.has(transactionId) && !isCommitScopeOpen(transactionOwnerToken, transactionId);
  let lifecycleSequence = 0;
  let lifecycleObserver;
  const lifecycleRegistry = getPositionRegistry(tree.$);
  if (lifecycleRegistry)
    defineTransactionLifecycleSource(lifecycleRegistry, {
      treeId: lifecycleRegistry.id,
      read: () => ({
        sequence: lifecycleSequence,
        pending: [...lifecycleViews.values()].map(
          ({ transactionId, phase }) => ({
            transactionId,
            phase,
            consequencesReleased: consequencesReleased(transactionId)
          })
        )
      }),
      attach: (observer) => {
        lifecycleObserver = observer;
      }
    });
  if (lifecycleRegistry) register(lifecycleRegistry.id, { read: () => ({ pending: [...lifecycleViews.values()] }) }, transactionOwnerToken);
  const publishLifecycle = (fact) => {
    transition(lifecycleRegistry?.id, fact);
    lifecycleSequence++;
    lifecycleObserver?.record(fact);
  };
  const holdLifecycle = () => lifecycleObserver?.hold();
  const retireLifecycleView = (transactionId) => {
    lifecycleViews.delete(transactionId);
    lifecycleScopes.delete(transactionId);
  };
  const abandonLifecycleView = (transactionId) => {
    if (!lifecycleViews.has(transactionId)) return;
    transition(lifecycleRegistry?.id, { kind: "abandoned", transactionId });
    retireLifecycleView(transactionId);
    lifecycleSequence++;
  };
  const publishRefusal = (transactionId, error) => publishLifecycle({ kind: "refused", transactionId, error });
  const realizationTree = tree;
  const treeWrapper = tree;
  const stateRoot = tree.$;
  const realizationDescriptors = getTreeRealizationDescriptors(stateRoot) ?? getTreeRealizationDescriptors(treeWrapper) ?? /* @__PURE__ */ new Map();
  defineTreeRealizationDescriptors(treeWrapper, realizationDescriptors);
  defineTreeRealizationDescriptors(stateRoot, realizationDescriptors);
  const realizationPort = getTreeRealizationPort(stateRoot) ?? getTreeRealizationPort(treeWrapper) ?? createTreeRealizationAdapter({
    tree: realizationTree,
    descriptors: realizationDescriptors
  });
  defineTreeRealizationPort(treeWrapper, realizationPort);
  defineTreeRealizationPort(stateRoot, realizationPort);
  let windowWriteSeq = 0;
  const lastWindowWriteSeq = /* @__PURE__ */ new Map();
  const lastWindowRowWriteSeq = /* @__PURE__ */ new Map();
  const windowKeys = (positionIds, subjectIds) => {
    const keys = [];
    for (const position of positionIds ?? []) {
      if (subjectIds && subjectIds.length > 0) {
        for (const subject of subjectIds) keys.push(`${position}:${subject}`);
      } else {
        keys.push(String(position));
      }
    }
    return keys;
  };
  const recordWindowWrite = (positionIds, subjectIds) => {
    const seq = ++windowWriteSeq;
    for (const key of windowKeys(positionIds, subjectIds)) {
      lastWindowWriteSeq.set(key, seq);
      const colon = key.indexOf(":");
      if (colon !== -1) {
        lastWindowRowWriteSeq.set(Number(key.slice(0, colon)), seq);
      }
    }
  };
  const writtenSinceBy = (bucket) => {
    for (const [key, own] of bucket.ownWriteSeq) {
      const colon = key.indexOf(":");
      const position = colon === -1 ? key : key.slice(0, colon);
      if ((lastWindowWriteSeq.get(key) ?? 0) > own) return true;
      if ((lastWindowWriteSeq.get(position) ?? 0) > own) return true;
      if (colon === -1 && (lastWindowRowWriteSeq.get(Number(position)) ?? 0) > own) {
        return true;
      }
    }
    return false;
  };
  const releaseWindowIfClosed = () => {
    if (pendingTransactions.size === 0) {
      lastWindowWriteSeq.clear();
      lastWindowRowWriteSeq.clear();
    }
  };
  const forgetUnclaimedDescriptorSubjects = (subjectIds, descriptorOwnersBefore, ownPositions = []) => {
    if (subjectIds.length === 0 && ownPositions.length === 0) return;
    const claims = getSubjectRestorationClaims(tree);
    const unclaimed = [...new Set(subjectIds)].filter((subjectId) => {
      if (claims?.isClaimed(subjectId)) return false;
      for (const bucket of pendingTransactions.values())
        if (bucket.subjectIds.has(subjectId)) return false;
      return true;
    });
    forgetSubjectsInTreeRealizationDescriptors(
      realizationDescriptors,
      unclaimed
    );
    const neededByPending = (owner) => {
      if (authority.isPositionPending(owner)) return true;
      for (const bucket of pendingTransactions.values())
        if (bucket.positionIds.has(owner)) return true;
      return false;
    };
    for (const owner of new Set(ownPositions)) {
      if (descriptorOwnersBefore?.has(owner)) {
        continue;
      }
      const descriptor = realizationDescriptors.get(owner);
      if (descriptor && (descriptor.subjectDescriptors?.size ?? 0) === 0 && (descriptor.structuralEffects?.size ?? 0) === 0 && (descriptor.structuralEffectBySubject?.size ?? 0) === 0 && !neededByPending(owner)) {
        realizationDescriptors.delete(owner);
      }
    }
  };
  const notifyListeners = (listeners3, turn) => {
    const payload = cloneTurnRecord(turn);
    for (const listener of listeners3) {
      try {
        listener(payload);
      } catch (error) {
        reportContainedObserverError({
          error,
          operation: "transaction:listener",
          treeId: getPositionRegistry(tree.$)?.id
        });
      }
    }
  };
  const drainCaptureBucket = (bucket) => {
    const ownerPaths = Array.from(bucket.ownerPaths).sort();
    bucket.ownerPaths.clear();
    bucket.ownWriteSeq.clear();
    bucket.entityFootprints.clear();
    const subjectIds = Array.from(bucket.subjectIds).sort((a, b) => a - b);
    bucket.subjectIds.clear();
    const positionIds = Array.from(bucket.positionIds).sort((a, b) => a - b);
    bucket.positionIds.clear();
    const baselineValues = new Map(bucket.baselineValues);
    bucket.baselineValues.clear();
    const effects = settleTurnMemberEffects(
      tree.$,
      Array.from(bucket.effects.values()).filter(Boolean).map(cloneTurnEffect)
    );
    bucket.effects.clear();
    const collectionOrders = Array.from(bucket.collectionOrders.values()).map(
      (order) => ({
        ...order,
        beforeSubjects: [...order.beforeSubjects],
        afterSubjects: [...order.afterSubjects]
      })
    );
    bucket.collectionOrders.clear();
    return {
      ownerPaths,
      subjectIds,
      positionIds,
      baselineValues,
      effects,
      collectionOrders
    };
  };
  const rememberBaselineValue = (bucket, effect) => {
    if (!bucket.baselineValues.has(effect.position)) {
      switch (effect.kind) {
        case "set":
          bucket.baselineValues.set(effect.position, effect.before);
          break;
        case "add":
          bucket.baselineValues.set(effect.position, void 0);
          break;
        case "remove":
          bucket.baselineValues.set(effect.position, effect.key);
          break;
        case "rekey":
          bucket.baselineValues.set(effect.position, effect.beforeKey);
          break;
      }
    }
  };
  const effectKey = (effect) => {
    switch (effect.kind) {
      case "set":
        return JSON.stringify([
          effect.kind,
          effect.position,
          effect.subject,
          effect.subjectFieldSegments ?? effect.path
        ]);
      // RESTORE-P0 P0-B: keyed by SUBJECT, deliberately without `kind`, so the
      // transaction's effects on one subject collide and can be composed into
      // the NET effect. With `kind` in the key, `rekey('a','a2')` and
      // `removeOne('a2')` occupied separate slots and rollback applied both
      // inverses, returning the row under the name it had been renamed TO.
      // Mirrors the same repair in restoration.ts.
      case "remove":
      case "add":
      case "rekey":
        return `structural\0${effect.ownerPath}\0${effect.position}\0${effect.subject}`;
    }
  };
  const enqueueEffect = (bucket, effectMap, effect) => {
    const key = effectKey(effect);
    const existing2 = effectMap.get(key);
    if (existing2) {
      if (existing2.kind === "set" && effect.kind === "set") {
        if (!composePlainBranchMemberEffect(existing2, effect)) {
          existing2.after = effect.after;
          const beforePresent = existing2.fieldPresence?.before ?? true;
          const afterPresent = effect.fieldPresence?.after ?? true;
          if (beforePresent && afterPresent) delete existing2.fieldPresence;
          else
            existing2.fieldPresence = {
              before: beforePresent,
              after: afterPresent
            };
        }
        existing2.mutationIntent = combineScalarMutationIntent(
          existing2.mutationIntent,
          effect.mutationIntent
        );
        if (effectMap === bucket.entityFootprints && plainBranchMemberEffectIsNoop(existing2) && (existing2.fieldPresence?.before ?? true) === (existing2.fieldPresence?.after ?? true)) {
          effectMap.delete(key);
        }
        return;
      }
      if (existing2.kind !== "set" && effect.kind !== "set") {
        if (existing2.kind === "add" && effect.kind === "remove") {
          effectMap.delete(key);
          return;
        }
        if (existing2.kind === "rekey" && effect.kind === "remove") {
          const composed = { ...effect, key: existing2.beforeKey };
          rememberBaselineValue(bucket, composed);
          effectMap.set(key, composed);
          return;
        }
        if (existing2.kind === "add" && effect.kind === "rekey") {
          existing2.key = effect.afterKey;
          return;
        }
        if (existing2.kind === "rekey" && effect.kind === "rekey") {
          if (existing2.beforeKey === effect.afterKey) {
            effectMap.delete(key);
            return;
          }
          existing2.afterKey = effect.afterKey;
          return;
        }
      }
      return;
    }
    if (effectMap !== bucket.entityFootprints) {
      rememberBaselineValue(bucket, effect);
    }
    effectMap.set(key, effect);
  };
  const buildTurnEffectFromStructural = (meta, ownerPath, path, positionIds, subjectIds) => {
    const position = positionIds?.[0];
    const subject = subjectIds?.[0];
    if (position === void 0 || subject === void 0) {
      return void 0;
    }
    const effect = meta?.structuralEffect;
    if (!effect || effect.subject !== subject) {
      return void 0;
    }
    return {
      ...effect,
      ownerPath,
      path,
      position
    };
  };
  const isPlainRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value) && !(value instanceof Date) && !(value instanceof Map) && !(value instanceof Set);
  const captureEffects = (bucket, effectMap, path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
    const membership = plainBranchMembershipEffects(meta);
    if (membership) {
      for (const effect of membership) {
        bucket.positionIds.add(effect.position);
        enqueueEffect(bucket, effectMap, effect);
      }
      return;
    }
    const structuralEffect = ownerPath ? buildTurnEffectFromStructural(
      meta,
      ownerPath,
      path,
      positionIds,
      subjectIds
    ) : void 0;
    if (structuralEffect) {
      enqueueEffect(bucket, effectMap, structuralEffect);
      return;
    }
    if (next === void 0 && prev === void 0) {
      return;
    }
    if (isPlainRecord(next) && isPlainRecord(prev) && !(!subjectIds?.length && positionIds?.[0] !== void 0 && (getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$))?.resolveScalarSlot(positionIds[0]) !== void 0)) {
      const position2 = positionIds?.[0];
      const subject = subjectIds?.[0];
      if (position2 === void 0) {
        return;
      }
      const keys = /* @__PURE__ */ new Set([...Object.keys(prev), ...Object.keys(next)]);
      for (const key of keys) {
        const before = prev[key];
        const after = next[key];
        const beforePresent = Object.prototype.hasOwnProperty.call(prev, key);
        const afterPresent = Object.prototype.hasOwnProperty.call(next, key);
        if (before === after && beforePresent === afterPresent) {
          continue;
        }
        enqueueEffect(bucket, effectMap, {
          kind: "set",
          path: `${path}.${key}`,
          ownerPath: ownerPath ?? path,
          position: position2,
          subject,
          subjectFieldSegments: subject === void 0 ? void 0 : [key],
          ...subject !== void 0 && !(beforePresent && afterPresent) ? { fieldPresence: { before: beforePresent, after: afterPresent } } : {},
          before,
          after,
          mutationIntent: meta?.mutationIntent
        });
      }
      return;
    }
    const position = positionIds?.[0];
    if (position === void 0 || prev === next) {
      return;
    }
    enqueueEffect(bucket, effectMap, {
      kind: "set",
      path,
      ownerPath: ownerPath ?? path,
      position,
      subject: subjectIds?.[0],
      before: prev,
      after: next,
      mutationIntent: meta?.mutationIntent
    });
  };
  const inspectPendingTurn = (turnId) => {
    if (inspectionUnavailable)
      throw new Error(
        "SignalTree: pending inspection unavailable because mutation chronology capture failed."
      );
    const turn = authority.getPendingTurn(turnId);
    if (!turn) return void 0;
    const effects = turn.__effects ?? [];
    const transactionId = inspectionTransactionByTurn.get(turnId);
    const own = inspectionWrites.get(transactionId);
    const later = /* @__PURE__ */ new Set();
    for (const effect of effects) {
      const authored = own?.get(effectKey(effect));
      if (!authored) {
        inspectionUnavailable = true;
        throw new Error(
          "SignalTree: pending inspection unavailable because an authored contribution has no mutation chronology."
        );
      }
      for (const [writer, writes] of inspectionWrites) {
        if (writer === transactionId) continue;
        for (const candidate of writes.values()) {
          if (candidate.seq <= authored.seq) continue;
          const other = candidate.effect;
          if (other.position !== effect.position || other.subject !== effect.subject)
            continue;
          if (effect.kind === "set") {
            if (other.kind === "remove" || other.kind === "set" && scalarRelation(other, effect) === "same")
              later.add(candidate);
          } else if (other.kind !== "set") later.add(candidate);
        }
      }
    }
    return {
      effects,
      laterEffects: [...later].sort((a, b) => a.seq - b.seq).map(({ effect }) => cloneTurnEffect(effect))
    };
  };
  const observeOpenEntityCapture = (transactionId, bucket) => getMutationCaptureRuntime(tree)?.subscribeCommittedEntity?.((capture) => {
    if (capture.meta?.origin === "transaction-rollback" || capture.meta?.origin === "restoration" || isInspectionWrite(capture.meta) || getWriteParticipation(capture.meta) === "realized" || resolveTransactionId(capture.meta) !== transactionId)
      return;
    for (const change of capture.changes) {
      bucket.subjectIds.add(change.subject);
      if (change.structural) {
        const effect = {
          kind: "set",
          position: capture.owner,
          ownerPath: capture.ownerPath,
          path: capture.ownerPath,
          subject: change.subject,
          subjectFieldSegments: [],
          before: change.before,
          after: change.after
        };
        bucket.entityFootprints.set(effectKey(effect), effect);
      } else {
        captureEffects(
          bucket,
          bucket.entityFootprints,
          capture.ownerPath,
          change.after,
          change.before,
          capture.meta,
          capture.ownerPath,
          [change.subject],
          [capture.owner]
        );
      }
    }
  });
  const installedOperations = /* @__PURE__ */ new Map();
  const expectedDispositions = /* @__PURE__ */ new Map();
  tree.registerCleanup(() => {
    installedOperations.clear();
    expectedDispositions.clear();
  });
  const sourceCaptureRuntime = getMutationCaptureRuntime(tree);
  if (sourceCaptureRuntime) {
    sourceCaptureRuntime.prepareMemberResponsibility = (branch, key, child) => {
      const meta = getActiveWriteContext();
      const id = resolveTransactionId(meta);
      if (id === void 0 || isRestoring || isInspectionWrite(meta) || getWriteParticipation(meta) === "realized" || meta?.origin === "restoration" || meta?.origin === "transaction-rollback") return;
      const prepared = prepareNewMemberResponsibility(branch, key, child);
      if (!prepared) return;
      const { effect, address } = prepared;
      const bucket = getTransactionBucket(id);
      const previous = installedOperations.get(id);
      const operation = {
        sequence: (previous?.sequence ?? -1) + 1,
        owner: effect.position,
        effects: [cloneTurnEffect(effect)],
        previous,
        owners: previous?.owners ?? /* @__PURE__ */ new Set()
      };
      return {
        writes: [
          address,
          { map: bucket.effects, key: effectKey(effect), value: effect },
          { map: bucket.baselineValues, key: effect.position, value: void 0 },
          { map: installedOperations, key: id, value: operation }
        ],
        adds: [
          { set: operation.owners, value: effect.position },
          { set: bucket.positionIds, value: effect.position },
          { set: bucket.ownerPaths, value: effect.ownerPath }
        ]
      };
    };
    sourceCaptureRuntime.prepareEntityResponsibility = (capture) => {
      const id = resolveTransactionId(capture.meta);
      if (id === void 0 || isRestoring || capture.meta?.origin === "transaction-rollback" || capture.meta?.origin === "restoration")
        return;
      const bucket = getTransactionBucket(id);
      const scratch = createCaptureBucket();
      const effects = [];
      for (const change of capture.changes) {
        const path = change.path;
        if (path === void 0)
          throw new Error("Entity responsibility has no mutation path");
        if (change.structuralRecord)
          effects.push({
            ...change.structuralRecord,
            position: capture.owner,
            ownerPath: capture.ownerPath,
            path
          });
        else if (!isPlainRecord(change.before) || !isPlainRecord(change.after)) {
          if (change.before !== change.after)
            effects.push({
              kind: "set",
              position: capture.owner,
              ownerPath: capture.ownerPath,
              path,
              subject: change.subject,
              before: change.before,
              after: change.after,
              mutationIntent: capture.meta?.mutationIntent
            });
        } else {
          const before = change.before, after = change.after;
          for (const key of /* @__PURE__ */ new Set([
            ...Object.keys(before),
            ...Object.keys(after)
          ])) {
            const beforeValue = before[key], afterValue = after[key];
            const beforePresent = Object.prototype.hasOwnProperty.call(
              before,
              key
            ), afterPresent = Object.prototype.hasOwnProperty.call(after, key);
            if (beforeValue === afterValue && beforePresent === afterPresent)
              continue;
            effects.push({
              kind: "set",
              position: capture.owner,
              ownerPath: capture.ownerPath,
              path: `${path}.${key}`,
              subject: change.subject,
              subjectFieldSegments: [key],
              before: beforeValue,
              after: afterValue,
              mutationIntent: capture.meta?.mutationIntent,
              ...!(beforePresent && afterPresent) ? {
                fieldPresence: {
                  before: beforePresent,
                  after: afterPresent
                }
              } : {}
            });
          }
        }
      }
      const touchedKeys = new Set(effects.map(effectKey));
      for (const key of touchedKeys) {
        const prior = bucket.effects.get(key);
        if (prior) scratch.effects.set(key, cloneTurnEffect(prior));
      }
      for (const effect of effects) {
        if (bucket.baselineValues.has(effect.position))
          scratch.baselineValues.set(
            effect.position,
            bucket.baselineValues.get(effect.position)
          );
      }
      for (const effect of effects)
        enqueueEffect(scratch, scratch.effects, cloneTurnEffect(effect));
      const previous = installedOperations.get(id);
      const operation = {
        sequence: (previous?.sequence ?? -1) + 1,
        structuralFrontier: capture.structuralFrontier,
        owner: capture.owner,
        effects,
        previous,
        owners: previous?.owners ?? /* @__PURE__ */ new Set()
      };
      const writes = [
        { map: installedOperations, key: id, value: operation }
      ];
      for (const key of touchedKeys)
        if (!scratch.effects.has(key))
          writes.push({ map: bucket.effects, key, value: void 0 });
      for (const [key, value] of scratch.effects)
        writes.push({ map: bucket.effects, key, value });
      for (const [key, value] of scratch.baselineValues)
        writes.push({ map: bucket.baselineValues, key, value });
      if (pendingTransactions.size > 0)
        for (const key of windowKeys(
          [capture.owner],
          capture.changes.map((c) => c.subject)
        ))
          writes.push({ map: bucket.ownWriteSeq, key, value: windowWriteSeq });
      return {
        writes,
        adds: [
          { set: operation.owners, value: capture.owner },
          { set: bucket.positionIds, value: capture.owner },
          { set: bucket.ownerPaths, value: capture.ownerPath },
          ...capture.changes.map((c) => ({
            set: bucket.subjectIds,
            value: c.subject
          }))
        ]
      };
    };
    tree.registerCleanup(() => {
      delete sourceCaptureRuntime.prepareEntityResponsibility;
      delete sourceCaptureRuntime.prepareMemberResponsibility;
    });
  }
  const foldOperationDisposition = (id) => {
    const newest = installedOperations.get(id);
    if (!newest) return [];
    const records2 = new Array(newest.sequence + 1);
    let record = newest;
    for (let i = records2.length - 1; i >= 0; i--) {
      if (!record || record.sequence !== i)
        throw new Error("Operation journal sequence gap");
      records2[i] = record;
      record = record.previous;
    }
    if (record) throw new Error("Operation journal sequence gap");
    const expected = createCaptureBucket();
    for (const operation of records2)
      for (const effect of operation.effects)
        enqueueEffect(expected, expected.effects, cloneTurnEffect(effect));
    return settleTurnMemberEffects(
      tree.$,
      [...expected.effects.values()].map(cloneTurnEffect)
    );
  };
  const validateOperationDisposition = (id, turnId) => {
    const folded = expectedDispositions.get(id);
    if (!folded?.length) return;
    const retained = authority.getPendingTurn(turnId)?.__effects ?? [];
    const indexed = new Map(
      retained.map((effect) => [effectKey(effect), effect])
    );
    for (const effect of folded) {
      const actual = indexed.get(effectKey(effect));
      const same = actual && actual.kind === effect.kind && [.../* @__PURE__ */ new Set([...Object.keys(effect), ...Object.keys(actual)])].every(
        (key) => {
          const expectedValue = effect[key];
          const actualValue = actual[key];
          const memberImage = (key === "before" || key === "after") && effect.kind === "set" && effect.plainBranchMembership !== void 0;
          return memberImage || key === "subjectFieldSegments" || key === "fieldPresence" || key === "plainBranchMembership" ? deepEqual(actualValue, expectedValue) : Object.is(actualValue, expectedValue);
        }
      );
      if (!same) {
        const refusal = createRollbackError({
          kind: "effect-validation-failed",
          pendingTurnId: turnId ?? id,
          compensation: [],
          errorMessage: "Installed operation lacks a matching settlement disposition"
        });
        publishRefusal(id, refusal);
        throw refusal;
      }
    }
  };
  const resolveOwnerPositionId = (ownerPath) => {
    if (!ownerPath) {
      return void 0;
    }
    const segments = ownerPath.split(".");
    let cursor = tree.$;
    for (const segment of segments) {
      if (!isTraversableNode(cursor)) {
        return void 0;
      }
      cursor = cursor[segment];
    }
    const resolved = cursor?.__positionIds?.[0];
    return typeof resolved === "number" ? resolved : void 0;
  };
  const captureIntoBucket = (bucket, path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
    const membership = plainBranchMembershipEffects(meta);
    const membershipTransaction = resolveTransactionId(meta);
    if (membership?.length && membershipTransaction !== void 0) {
      const previous = installedOperations.get(membershipTransaction);
      installedOperations.set(membershipTransaction, {
        sequence: (previous?.sequence ?? -1) + 1,
        owner: membership[0].position,
        effects: membership.map(cloneTurnEffect),
        previous,
        owners: previous?.owners ?? /* @__PURE__ */ new Set()
      });
    }
    if (membership) {
      for (const effect of membership) {
        bucket.positionIds.add(effect.position);
        bucket.ownerPaths.add(effect.ownerPath);
        if (pendingTransactions.size > 0) {
          for (const key of windowKeys([effect.position], void 0))
            bucket.ownWriteSeq.set(key, windowWriteSeq);
        }
        enqueueEffect(bucket, bucket.effects, effect);
      }
      return;
    }
    bucket.ownerPaths.add(ownerPath ?? path);
    for (const subjectId of subjectIds ?? []) {
      bucket.subjectIds.add(subjectId);
    }
    const resolvedPositionIds = positionIds && positionIds.length > 0 ? positionIds : (() => {
      const fallback = resolveOwnerPositionId(ownerPath);
      return fallback === void 0 ? [] : [fallback];
    })();
    for (const positionId of resolvedPositionIds) {
      bucket.positionIds.add(positionId);
    }
    if (pendingTransactions.size > 0) {
      for (const key of windowKeys(resolvedPositionIds, subjectIds)) {
        bucket.ownWriteSeq.set(key, windowWriteSeq);
      }
    }
    rememberTreeRealizationDescriptor({
      descriptors: realizationDescriptors,
      path,
      ownerPath,
      positionIds: resolvedPositionIds,
      subjectIds,
      meta,
      registry: getPositionRegistry(tree.$)
    });
    const recorded = resolveTransactionId(meta);
    if (recorded !== void 0 && subjectIds?.length && installedOperations.get(recorded)?.owners.has(resolvedPositionIds[0]))
      return;
    captureEffects(
      bucket,
      bucket.effects,
      path,
      next,
      prev,
      meta,
      ownerPath,
      subjectIds,
      resolvedPositionIds
    );
  };
  const recordConfirmedBucket = (bucket) => {
    const { subjectIds, positionIds, effects } = drainCaptureBucket(bucket);
    const turn = authority.recordConfirmed(
      subjectIds.length > 0 ? subjectIds : void 0,
      positionIds.length > 0 ? positionIds : void 0,
      effects.length > 0 ? effects : void 0
    );
    forgetUnclaimedDescriptorSubjects(subjectIds);
    return turn;
  };
  const getTransactionBucket = (transactionId) => {
    let bucket = pendingTransactions.get(transactionId);
    if (!bucket) {
      bucket = createCaptureBucket();
      pendingTransactions.set(transactionId, bucket);
    }
    return bucket;
  };
  const resolveTransactionId = (meta) => typeof meta?.transactionId === "number" && meta.transactionOwner === transactionOwnerToken ? meta.transactionId : void 0;
  unsubscribeCollectionOrders = getMutationCaptureRuntime(tree)?.subscribeCollectionOrder?.((capture) => {
    const transactionId = resolveTransactionId(capture.meta);
    if (transactionId === void 0) {
      return;
    }
    const bucket = getTransactionBucket(transactionId);
    const existing2 = bucket.collectionOrders.get(capture.owner);
    bucket.collectionOrders.set(capture.owner, {
      owner: capture.owner,
      ownerPath: capture.ownerPath,
      beforeSubjects: existing2?.beforeSubjects ?? [...capture.beforeSubjects],
      afterSubjects: [...capture.afterSubjects],
      beforeFrontier: existing2?.beforeFrontier ?? capture.beforeFrontier,
      afterFrontier: capture.afterFrontier
    });
    bucket.ownerPaths.add(capture.ownerPath);
    bucket.positionIds.add(capture.owner);
  }) ?? null;
  const materializePendingTransaction = (transactionId, reservedId) => {
    const bucket = pendingTransactions.get(transactionId);
    pendingTransactions.delete(transactionId);
    releaseWindowIfClosed();
    if (!bucket) {
      authority.discardPending(reservedId);
      return void 0;
    }
    const dispositions = foldOperationDisposition(transactionId);
    expectedDispositions.set(transactionId, dispositions);
    const {
      subjectIds,
      positionIds: capturedPositionIds,
      effects,
      baselineValues,
      collectionOrders
    } = drainCaptureBucket(bucket);
    const preparedOwners = installedOperations.get(transactionId)?.owners;
    const slots = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
    const netPositions = /* @__PURE__ */ new Set([
      ...effects.map((effect) => effect.position),
      ...dispositions.map((effect) => effect.position),
      ...collectionOrders.map((order) => order.owner)
    ]);
    const positionIds = capturedPositionIds.filter(
      (position) => !preparedOwners?.has(position) || slots?.resolveScalarSlot(position) === void 0 || netPositions.has(position)
    );
    const pending = authority.createPending(
      reservedId,
      subjectIds.length > 0 ? subjectIds : void 0,
      positionIds.length > 0 ? positionIds : void 0,
      effects.length > 0 ? effects : void 0,
      baselineValues.size > 0 ? baselineValues : void 0
    );
    const externalEffects = callbackExternalEffects.get(transactionId) ?? [];
    callbackExternalEffects.delete(transactionId);
    if (pending && externalEffects.length) {
      authority.observeQueuedEffects(
        pending.id,
        externalEffects.map(
          (effect) => effect.kind === "set" ? { ...effect, mutationIntent: "derive" } : effect
        )
      );
    }
    if (pending && collectionOrders.length > 0) {
      pendingOrderDeltas.set(
        pending.id,
        collectionOrders.map(
          (order) => deriveCollectionOrderDelta(
            order.owner,
            order.beforeSubjects,
            order.afterSubjects,
            order.beforeFrontier,
            order.afterFrontier
          )
        )
      );
    }
    return pending;
  };
  const toCausalEffect = (effect) => {
    switch (effect.kind) {
      case "set":
        return {
          owner: effect.position,
          before: effect.before,
          after: effect.after,
          subjectId: effect.subject,
          subjectFieldSegments: effect.subjectFieldSegments,
          plainBranchMembership: effect.plainBranchMembership,
          fieldPresence: effect.fieldPresence,
          path: effect.path,
          ownerPath: effect.ownerPath
        };
      case "add":
        return {
          owner: effect.position,
          before: void 0,
          after: effect.key,
          subjectId: effect.subject,
          path: effect.path,
          ownerPath: effect.ownerPath,
          structural: "add",
          structuralContext: {
            kind: "add",
            subject: effect.subject,
            key: effect.key,
            value: effect.value,
            beforeSubject: effect.beforeSubject,
            afterSubject: effect.afterSubject
          }
        };
      case "remove":
        return {
          owner: effect.position,
          before: effect.key,
          after: void 0,
          subjectId: effect.subject,
          path: effect.path,
          ownerPath: effect.ownerPath,
          structural: "remove",
          structuralContext: {
            kind: "remove",
            subject: effect.subject,
            key: effect.key,
            value: effect.value,
            beforeSubject: effect.beforeSubject,
            afterSubject: effect.afterSubject
          }
        };
      case "rekey":
        return {
          owner: effect.position,
          before: effect.beforeKey,
          after: effect.afterKey,
          subjectId: effect.subject,
          path: effect.path,
          ownerPath: effect.ownerPath,
          structural: "rekey",
          structuralContext: {
            kind: "rekey",
            subject: effect.subject,
            beforeKey: effect.beforeKey,
            afterKey: effect.afterKey
          }
        };
    }
  };
  const toRollbackEffect = (effect) => {
    const causal = toCausalEffect(effect);
    return {
      ...causal,
      before: causal.after,
      after: causal.before,
      plainBranchMembership: causal.plainBranchMembership ? {
        before: causal.plainBranchMembership.after,
        after: causal.plainBranchMembership.before
      } : void 0,
      fieldPresence: causal.fieldPresence ? {
        before: causal.fieldPresence.after,
        after: causal.fieldPresence.before
      } : void 0,
      structural: causal.structural === "add" ? "remove" : causal.structural === "remove" ? "add" : causal.structural
    };
  };
  const compensatedFrontiers = (transactionId, effects, orderDeltas) => {
    if (!expectedDispositions.has(transactionId)) return /* @__PURE__ */ new Map();
    const intervals = /* @__PURE__ */ new Map();
    for (let operation = installedOperations.get(transactionId); operation; operation = operation.previous) {
      const interval = operation.structuralFrontier;
      if (!interval || interval.before === interval.after) continue;
      const newer = intervals.get(operation.owner);
      if (newer) {
        newer.valid &&= interval.after === newer.before;
        newer.before = interval.before;
      } else intervals.set(operation.owner, { ...interval, valid: true });
    }
    const expectedByOwner = /* @__PURE__ */ new Map();
    const actualByOwner = /* @__PURE__ */ new Map();
    const group = (source, into) => {
      for (const effect of source) {
        if (effect.kind === "set") continue;
        let entries = into.get(effect.position);
        if (!entries) into.set(effect.position, entries = /* @__PURE__ */ new Map());
        entries.set(effectKey(effect), effect);
      }
    };
    group(expectedDispositions.get(transactionId) ?? [], expectedByOwner);
    group(effects, actualByOwner);
    const orderedOwners = new Set(orderDeltas.map((delta) => delta.owner));
    const result = /* @__PURE__ */ new Map();
    for (const [owner, interval] of intervals) {
      if (!interval.valid || orderedOwners.has(owner)) continue;
      const expected = expectedByOwner.get(owner);
      const actual = actualByOwner.get(owner);
      if ((expected?.size ?? 0) !== (actual?.size ?? 0)) continue;
      let complete2 = true;
      for (const [key, effect] of expected ?? []) {
        const candidate = actual?.get(key);
        if (!candidate || candidate.kind !== effect.kind || candidate.subject !== effect.subject || (effect.kind === "rekey" && candidate.kind === "rekey" ? effect.beforeKey !== candidate.beforeKey || effect.afterKey !== candidate.afterKey : effect.kind !== "set" && effect.kind !== "rekey" && candidate.kind !== "set" && candidate.kind !== "rekey" ? effect.key !== candidate.key : true)) {
          complete2 = false;
          break;
        }
      }
      if (!complete2) continue;
      const binding = collectionBindingAt(tree.$, owner);
      if (binding?.installCompensatedOrderFrontier && binding.readOrderFrontier?.() === interval.after)
        result.set(owner, { ...interval, binding });
    }
    return result;
  };
  const installPreparedCompensation = (point, frontiers, completion) => {
    if (completion) completion.selected = true;
    for (const interval of frontiers.values())
      if (interval.binding.readOrderFrontier?.() !== interval.after)
        throw new Error("Compensation structural frontier changed during preparation");
    const releaseMembership = holdEntityMembershipDelivery(tree.$);
    try {
      point?.install();
      for (const interval of frontiers.values())
        interval.binding.installCompensatedOrderFrontier?.(interval.before);
      if (!point && frontiers.size)
        (getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree))?.advance();
      if (completion) completion.committed = true;
      point?.publish();
    } finally {
      releaseMembership();
    }
  };
  const rollbackPendingTarget = (effects, orderDeltas, completion, frontiers) => {
    if (completion) completion.selected = true;
    const reversalEffects = placeFieldReversalsWhileRowsExist(effects);
    const notifier = getPathNotifier();
    const treeOwnerId = getPositionRegistry(tree.$)?.id;
    const bindings = /* @__PURE__ */ new Map();
    visitTree(tree.$, (node) => {
      const binding = node.__prepareTransitionTarget;
      if (binding) {
        bindings.set(binding.owner, binding);
      }
      return void 0;
    });
    const collectionOwners = /* @__PURE__ */ new Set([
      ...orderDeltas.map(({ owner }) => owner),
      ...reversalEffects.filter(({ subjectId }) => typeof subjectId === "number").map(({ owner }) => owner)
    ]);
    const collections = [...collectionOwners].map((owner) => {
      const binding = bindings.get(owner) ?? collectionBindingAt(tree.$, owner);
      if (binding) bindings.set(owner, binding);
      if (!binding) {
        throw new Error(
          `Transaction rollback has no collection binding ${owner}`
        );
      }
      return binding.readSource();
    });
    const derivedTarget = deriveDeclarativeTransitionTarget({
      collections,
      effects: reversalEffects,
      orderDeltas,
      orderEndpoint: "before"
    });
    const target = frontiers?.size ? {
      ...derivedTarget,
      collections: new Map([...derivedTarget.collections].map(([owner, collection]) => {
        const interval = frontiers.get(owner);
        return [owner, interval ? { ...collection, orderFrontier: interval.before } : collection];
      }))
    } : derivedTarget;
    const scalarSlotRuntime = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
    const scalarBinding = scalarSlotRuntime ? {
      prepareTarget(scalars) {
        const frame = scalarSlotRuntime.beginFrame();
        for (const [owner, value] of scalars) {
          const slot = scalarSlotRuntime.resolveScalarSlot(owner);
          if (slot === void 0) {
            frame.discard();
            throw new Error(
              `Transaction rollback has no scalar slot ${owner}`
            );
          }
          frame.set(slot, value);
        }
        const install = frame.prepareCommit ? frame.prepareCommit({
          advanceRevision: false,
          publish: false
        }) : () => frame.commit({ advanceRevision: false, publish: false });
        let result;
        return {
          install() {
            result = install();
          },
          publish() {
            if (!result) {
              throw new Error(
                "Transaction scalar published before installation"
              );
            }
            let failed = false;
            let first;
            try {
              scalarSlotRuntime.publishPrepared(result);
            } catch (error) {
              failed = true;
              first = error;
            }
            for (const effect of reversalEffects) {
              if (effect.subjectId !== void 0 || effect.plainBranchMembership || !scalars.has(effect.owner))
                continue;
              const descriptor = realizationDescriptors.get(effect.owner);
              const path = effect.path ?? descriptor?.ownerPath;
              if (!path) continue;
              try {
                notifier.notify(
                  path,
                  effect.after,
                  effect.before,
                  effect.ownerPath ?? descriptor?.ownerPath ?? path,
                  void 0,
                  [effect.owner],
                  {
                    ...getActiveWriteContext(),
                    intent: "system",
                    participation: "realized"
                  },
                  treeOwnerId
                );
              } catch (error) {
                if (!failed) {
                  failed = true;
                  first = error;
                }
              }
            }
            if (failed) throw first;
          }
        };
      }
    } : void 0;
    const prepared = prepareDeclarativeTransitionInstallation(
      target,
      bindings,
      scalarBinding,
      {
        prepareTarget: (members) => preparePlainBranchMembers(tree.$, members)
      },
      {
        onCommitted() {
          for (const [owner, interval] of frontiers ?? [])
            if (!target.collections.has(owner))
              interval.binding.installCompensatedOrderFrontier?.(interval.before);
          if (completion) completion.committed = true;
        }
      }
    );
    const apply = () => {
      for (const interval of frontiers?.values() ?? [])
        if (interval.binding.readOrderFrontier?.() !== interval.after)
          throw new Error("Compensation structural frontier changed during preparation");
      prepared.install();
    };
    const locations = getLocationRuntime(tree.$);
    const releaseMembership = holdEntityMembershipDelivery(tree.$);
    try {
      if (locations) {
        locations.runInvalidationGroup(apply);
      } else {
        apply();
      }
    } finally {
      releaseMembership();
    }
  };
  const applyRollbackCompensation = (transactionId, effects, baselineValues, orderDeltas = [], callbackError, owningTransactionId = transactionId, completion) => {
    const frontiers = compensatedFrontiers(owningTransactionId, effects, orderDeltas);
    if (effects.length === 0 && orderDeltas.length === 0 && frontiers.size === 0) {
      return;
    }
    const ownRows = /* @__PURE__ */ new Map();
    for (const effect of effects)
      if (effect.kind !== "set" || effect.subject !== void 0) {
        let rows = ownRows.get(effect.position);
        if (!rows) ownRows.set(effect.position, rows = /* @__PURE__ */ new Set());
        rows.add(effect.subject);
      }
    for (const effect of effects) {
      if (effect.kind !== "set" || effect.plainBranchMembership?.before !== true || effect.plainBranchMembership.after)
        continue;
      const changed = changedOmittedCollection(
        tree.$,
        effect.position,
        (owner) => ownRows.get(owner) ?? /* @__PURE__ */ new Set(),
        (owner) => orderDeltas.some((delta) => delta.owner === owner)
      );
      if (changed !== void 0)
        throw createRollbackError({
          kind: "effect-validation-failed",
          pendingTurnId: transactionId,
          compensation: effects,
          errorMessage: `the entity collection at '${changed}' was omitted and changed after that, so re-adding it would not restore it as it was`,
          callbackError
        });
    }
    const positionRegistry = getPositionRegistry(tree.$);
    const authorityPosition = getOwnedPositionIds(tree.$)?.[0];
    if (!positionRegistry || authorityPosition === void 0) {
      throw createRollbackError({
        kind: "effect-validation-failed",
        pendingTurnId: transactionId,
        compensation: effects,
        errorMessage: "Transaction rollback requires tree realization infrastructure",
        callbackError
      });
    }
    const store = new TurnStore();
    store.admitPending({
      id: transactionId,
      effects: effects.map(toCausalEffect)
    });
    const appliedTurns = new AppliedTurnProjection(store);
    const realizationContext = createRealizationContextSource({
      baselineValues,
      store,
      appliedTurns
    });
    beginStructuralWrite();
    openPhysicalRows(positionRegistry);
    let result;
    let failed = true;
    try {
      result = publishingExposedOnly(
        tree.$,
        () => withWriteContext(
          {
            origin: "transaction-rollback",
            transactionId: owningTransactionId,
            // NOT `transactionOwner`. Stamping it here makes
            // `activeTransactionContext()` report an open scope during the
            // compensation, which reopens the callback scope a rollback must leave
            // closed — `active-transaction-context.spec.ts` pins that. The join
            // restoration needs is carried by `origin` plus the corrected
            // `transactionId` instead.
            // OWNER-REPLAY-1, same shape as restoration's: stamped once on the wrap
            // that already surrounds the compensation, so every downstream meta
            // that spreads `getActiveWriteContext()` carries the namespace.
            ownerId: positionRegistry?.id
          },
          () => {
            if (effects.length === 0 && orderDeltas.length === 0) {
              installPreparedCompensation(void 0, frontiers, completion);
              return { ok: true };
            }
            if (orderDeltas.length > 0 || requiresDeclarativeStructuralTarget(
              effects.map(toRollbackEffect),
              (owner) => {
                let binding;
                visitTree(tree.$, (node) => {
                  const candidate = node.__prepareTransitionTarget;
                  if (candidate?.owner === owner) binding = candidate;
                  return void 0;
                });
                return binding?.readSource();
              }
            )) {
              rollbackPendingTarget(
                effects.map(toRollbackEffect),
                orderDeltas,
                completion,
                frontiers
              );
              return { ok: true };
            }
            return rollbackPendingTurnAt({
              authority: authorityPosition,
              turnId: transactionId,
              store,
              topology: positionRegistry,
              realizationContext,
              port: {
                validateEffects: (normalized) => realizationPort.validateEffects?.(normalized),
                applyAtomically(normalized) {
                  if (frontiers.size > 0 || normalized.some((e) => e.subjectId === void 0) && normalized.some((e) => e.subjectId !== void 0)) {
                    const point = preparePointRealization(
                      realizationTree,
                      normalized
                    );
                    if (point) {
                      installPreparedCompensation(point, frontiers, completion);
                    } else if (frontiers.size > 0 || normalized.some((effect) => effect.plainBranchMembership)) {
                      rollbackPendingTarget(
                        normalized,
                        orderDeltas,
                        completion,
                        frontiers
                      );
                    } else {
                      realizationPort.applyAtomically(normalized);
                    }
                  } else {
                    realizationPort.applyAtomically(normalized);
                  }
                }
              }
            });
          }
        )
      );
      failed = false;
    } finally {
      physicalRows.pop();
      endStructuralWrite(failed);
    }
    if (!result.ok) {
      throw createRollbackError({
        kind: "effect-validation-failed",
        pendingTurnId: transactionId,
        compensation: effects,
        errorMessage: `Transaction rollback refused: ${result.refusal.kind}`,
        cause: result.refusal,
        callbackError
      });
    }
    for (const effect of effects)
      if (effect.kind !== "set" || effect.subject !== void 0)
        refreshOmittedCollection(tree.$, effect.position);
    for (const delta of orderDeltas)
      refreshOmittedCollection(tree.$, delta.owner);
  };
  const rollbackPendingEffectsThroughRealizationPort = (transactionId, effects, baselineValues, orderDeltas = [], callbackError, owningTransactionId = transactionId, completion) => {
    applyRollbackCompensation(
      transactionId,
      effects,
      baselineValues,
      orderDeltas,
      callbackError,
      owningTransactionId,
      completion
    );
    markOwnerInvalidatedFrom(tree.$);
  };
  try {
    const notifier = getPathNotifier();
    if (notifier) {
      const treeOwnerId = getPositionRegistry(tree.$)?.id;
      if (treeOwnerId !== void 0) {
        registerEnqueueObserver = () => {
          unsubscribeEnqueue = notifier.observeEnqueue(treeOwnerId, (entry) => {
            if (destroyed || !authority.getPendingTurnCount() && !pendingTransactions.size)
              return;
            const meta = entry.meta;
            if (meta?.origin === "restoration" || meta?.origin === "transaction-rollback" || isInspectionWrite(meta))
              return;
            const realized = getWriteParticipation(meta) === "realized";
            if (!realized && typeof meta?.transactionId === "number" && meta.transactionOwner !== transactionOwnerToken)
              return;
            const writer = !realized && meta?.transactionOwner === transactionOwnerToken ? meta.transactionId : void 0;
            try {
              const probe = createCaptureBucket();
              captureEffects(
                probe,
                probe.effects,
                entry.path,
                entry.newValue,
                entry.oldValue,
                meta,
                entry.ownerPath,
                entry.subjectIds,
                entry.positionIds
              );
              const effects = drainCaptureBucket(probe).effects;
              if (!effects.length) return;
              const seq = ++inspectionSeq;
              let writes = inspectionWrites.get(writer);
              if (!writes) inspectionWrites.set(writer, writes = /* @__PURE__ */ new Map());
              for (const effect of effects) {
                const footprint = effect.kind === "set" ? { ...effect, before: void 0, after: void 0 } : effect.kind === "rekey" ? { ...effect } : { ...effect, value: void 0 };
                writes.set(effectKey(effect), { seq, effect: footprint });
              }
            } catch (error) {
              inspectionUnavailable = true;
              throw error;
            }
          });
        };
      }
      const subscribeCollectionNotifications = () => {
        unsubscribeNotifications?.();
        unsubscribeNotifications = notifier.subscribe(
          "**",
          (next, prev, path, ownerPath, origin, subjectIds, positionIds, meta) => {
            if (pendingTransactions.size > 0 && !isInspectionWrite(meta)) {
              const windowOwner = meta?.ownerId;
              if (windowOwner === void 0 || treeOwnerId === void 0 || windowOwner === treeOwnerId) {
                const membership = plainBranchMembershipChange(meta);
                recordWindowWrite(
                  membership ? membership.members.flatMap((member) => [
                    ...member.positionIds ?? []
                  ]) : positionIds,
                  subjectIds
                );
              }
            }
            if (origin === "restoration" || origin === "transaction-rollback") {
              return;
            }
            const writeOwnerId = meta?.ownerId;
            if (writeOwnerId !== void 0 && treeOwnerId !== void 0 && writeOwnerId !== treeOwnerId) {
              return;
            }
            if (isInspectionWrite(meta)) {
              return;
            }
            if (getWriteParticipation(meta) === "realized") {
              if (authority.getPendingTurnCount() > 0 || pendingTransactions.size > 0) {
                const probe = createCaptureBucket();
                captureIntoBucket(
                  probe,
                  path,
                  next,
                  prev,
                  meta,
                  ownerPath,
                  subjectIds,
                  positionIds
                );
                const effects = drainCaptureBucket(probe).effects;
                authority.observeLaterEffects(effects);
                for (const id of pendingTransactions.keys()) {
                  const prior = callbackExternalEffects.get(id) ?? [];
                  callbackExternalEffects.set(id, [...prior, ...effects]);
                }
              }
              return;
            }
            if (typeof meta?.transactionId === "number" && meta.transactionOwner !== transactionOwnerToken) {
              return;
            }
            const transactionId = resolveTransactionId(meta);
            if (transactionId !== void 0) {
              captureIntoBucket(
                getTransactionBucket(transactionId),
                path,
                next,
                prev,
                meta,
                ownerPath,
                subjectIds,
                positionIds
              );
              return;
            }
            selfDirty = true;
            captureIntoBucket(
              pendingCapture,
              path,
              next,
              prev,
              meta,
              ownerPath,
              subjectIds,
              positionIds
            );
          }
        );
      };
      subscribeCollectionNotifications();
      if (typeof notifier.onReset === "function") {
        unsubscribeReset = notifier.onReset(() => {
          subscribeCollectionNotifications();
        });
      }
      restoreLeafInterceptors = interceptLeafSignals(
        tree.$,
        (path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
          const effectiveMeta = meta ?? getActiveWriteContext();
          if (isRestoring) return;
          if (effectiveMeta?.origin === "restoration") {
            return;
          }
          if (isInspectionWrite(effectiveMeta) || getWriteParticipation(effectiveMeta) === "realized") {
            notifier.notify(
              path,
              next,
              prev,
              ownerPath,
              subjectIds,
              positionIds,
              effectiveMeta
            );
            return;
          }
          if (typeof effectiveMeta?.transactionId === "number" && effectiveMeta.transactionOwner !== transactionOwnerToken) {
            return;
          }
          notifier.notify(
            path,
            next,
            prev,
            ownerPath,
            subjectIds,
            positionIds,
            effectiveMeta,
            treeOwnerId
          );
        },
        {
          terminalRecord: (path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
            if (isRestoring || meta?.origin === "restoration" || isInspectionWrite(meta) || getWriteParticipation(meta) === "realized")
              return;
            if (meta?.transactionOwner !== transactionOwnerToken) return;
            const id = resolveTransactionId(meta), position = positionIds?.[0];
            if (id === void 0 || position === void 0 || subjectIds?.length || Object.is(prev, next))
              return;
            const slots = getTreeScalarSlotRuntime(tree) ?? getTreeScalarSlotRuntime(tree.$);
            if (slots?.resolveScalarSlot(position) === void 0) return;
            const bucket = getTransactionBucket(id);
            const effect = {
              kind: "set",
              path,
              ownerPath: ownerPath ?? path,
              position,
              before: prev,
              after: next,
              mutationIntent: meta?.mutationIntent
            };
            const key = effectKey(effect), old = bucket.effects.get(key);
            if (old && old.kind !== "set")
              throw new Error(
                "Terminal record conflicts with structural evidence"
              );
            const combined = old ? {
              ...old,
              after: next,
              mutationIntent: combineScalarMutationIntent(
                old.mutationIntent,
                effect.mutationIntent
              )
            } : effect;
            const previous = installedOperations.get(id);
            const operation = {
              sequence: (previous?.sequence ?? -1) + 1,
              owner: position,
              effects: [cloneTurnEffect(effect)],
              previous,
              owners: previous?.owners ?? /* @__PURE__ */ new Set()
            };
            const writes = [
              { map: bucket.effects, key, value: combined },
              { map: installedOperations, key: id, value: operation }
            ];
            if (!bucket.baselineValues.has(position))
              writes.push({
                map: bucket.baselineValues,
                key: position,
                value: prev
              });
            if (pendingTransactions.size > 0)
              for (const key2 of windowKeys([position], void 0))
                writes.push({
                  map: bucket.ownWriteSeq,
                  key: key2,
                  value: windowWriteSeq
                });
            return {
              writes,
              adds: [
                { set: operation.owners, value: position },
                { set: bucket.positionIds, value: position },
                { set: bucket.ownerPaths, value: ownerPath ?? path }
              ]
            };
          },
          beforePublication: (path, next, prev, meta, ownerPath, subjectIds, positionIds) => {
            const effectiveMeta = meta ?? getActiveWriteContext();
            if (isRestoring || effectiveMeta?.origin === "restoration" || isInspectionWrite(effectiveMeta) || getWriteParticipation(effectiveMeta) === "realized")
              return;
            if (typeof effectiveMeta?.transactionId === "number" && effectiveMeta.transactionOwner !== transactionOwnerToken)
              return;
            const transactionId = resolveTransactionId(effectiveMeta);
            if (transactionId !== void 0) {
              captureIntoBucket(
                getTransactionBucket(transactionId),
                path,
                next,
                prev,
                effectiveMeta,
                ownerPath,
                subjectIds,
                positionIds
              );
            } else {
              captureEffects(
                pendingCapture,
                pendingCapture.effects,
                path,
                next,
                prev,
                effectiveMeta,
                ownerPath,
                subjectIds,
                positionIds
              );
            }
          }
        }
      );
      if (typeof notifier.onFlush === "function") {
        unsubscribeFlush = notifier.onFlush(() => {
          if (isRestoring || !selfDirty) {
            return;
          }
          selfDirty = false;
          recordConfirmedBucket(pendingCapture);
        });
      }
    }
  } catch {
  }
  const readQueuedLaterEffects = () => {
    const ownerId = getPositionRegistry(tree.$)?.id;
    return (getPathNotifier()?.readPending() ?? []).flatMap(
      (entry) => {
        const meta = entry.meta;
        if ((entry.ownerId ?? meta?.ownerId) !== ownerId || meta?.origin === "restoration" || meta?.origin === "transaction-rollback" || isInspectionWrite(meta) || getWriteParticipation(meta) !== "realized" && meta?.transactionOwner === transactionOwnerToken && typeof meta.transactionId === "number")
          return [];
        const membership = plainBranchMembershipEffects(meta);
        if (membership) return [...membership];
        const position = entry.positionIds?.[0];
        if (position === void 0) return [];
        const structural = entry.ownerPath ? buildTurnEffectFromStructural(
          meta,
          entry.ownerPath,
          entry.path,
          entry.positionIds,
          entry.subjectIds
        ) : void 0;
        if (structural) return [structural];
        if (entry.subjectFieldKeys !== void 0 && entry.subjectIds?.length === 1) {
          const before = entry.oldValue;
          const after = entry.newValue;
          return entry.subjectFieldKeys.map((key) => ({
            kind: "set",
            position,
            path: `${entry.path}.${key}`,
            ownerPath: entry.ownerPath ?? entry.path,
            subject: entry.subjectIds?.[0],
            subjectFieldSegments: [key],
            fieldPresence: {
              before: Object.prototype.hasOwnProperty.call(before, key),
              after: Object.prototype.hasOwnProperty.call(after, key)
            },
            before: before[key],
            after: after[key],
            mutationIntent: "derive"
          }));
        }
        return [
          {
            kind: "set",
            position,
            path: entry.path,
            ownerPath: entry.ownerPath ?? entry.path,
            subject: entry.subjectIds?.[0],
            before: entry.oldValue,
            after: entry.newValue,
            mutationIntent: "derive"
          }
        ];
      }
    );
  };
  const decorateHandle = (pending, turnId) => {
    let settled;
    const read2 = () => {
      if (turnId === void 0) {
        return { changes: [] };
      }
      const raw = inspectPendingTurn(turnId);
      if (!raw) {
        return { changes: [] };
      }
      const registry = getPositionRegistry(tree.$);
      return {
        changes: raw.effects.map((effect) => ({
          path: effect.path,
          // The position address locates the OWNER (for an entity field that
          // is the collection); `subjectFieldSegments` is the producer-known
          // row-relative address. Appending it is what makes two fields of
          // one row distinguishable. The segments already existed and were
          // already authoritative — `scalarRelation` and `makeScalarKey`
          // key on them — so only the public projection was dropping them.
          address: (() => {
            const owner = registry?.addressFor(effect.position);
            if (!owner) return owner;
            const within = effect.kind === "set" ? effect.subjectFieldSegments : void 0;
            return within ? [...owner, ...within] : owner;
          })(),
          subject: "subject" in effect && typeof effect.subject === "number" ? effect.subject : void 0,
          status: classifyProposedEffect(effect, raw.laterEffects)
        }))
      };
    };
    const snapshot = () => {
      try {
        return read2();
      } catch {
        return void 0;
      }
    };
    const settlementWasTerminal = () => turnId !== void 0 && !authority.getPendingTurnIds().includes(turnId);
    return {
      inspect() {
        return settled ?? read2();
      },
      confirm() {
        const atSettlement = settled ?? snapshot();
        try {
          pending.confirm();
        } catch (error) {
          if (settlementWasTerminal()) settled = atSettlement;
          throw error;
        }
        settled = atSettlement;
      },
      rollback() {
        const atSettlement = settled ?? snapshot();
        try {
          pending.rollback();
        } catch (error) {
          if (settlementWasTerminal()) settled = atSettlement;
          throw error;
        }
        settled = atSettlement;
      }
    };
  };
  const runtime2 = {
    transaction(fn) {
      if (destroyed) throw new Error("Cannot transact on a destroyed tree");
      const activeMeta = getActiveWriteContext();
      const notifier = getPathNotifier();
      const captureRuntime = getMutationCaptureRuntime(tree);
      if (typeof activeMeta?.transactionId === "number") {
        throw new Error("Nested transaction is not supported");
      }
      const beforeOpen = readQueuedLaterEffects();
      for (const id of authority.getPendingTurnIds()) {
        authority.observeQueuedEffects(id, beforeOpen);
      }
      notifier?.flushSync();
      const transactionId = nextTransactionId++;
      const captureBucket = createCaptureBucket();
      pendingTransactions.set(transactionId, captureBucket);
      ensureEnqueueObserver();
      const lifecycleChannel = getTransactionLifecycleChannel(tree);
      const lifecycleView = { transactionId, phase: "opened" };
      lifecycleViews.set(transactionId, lifecycleView);
      let descriptorOwnersBefore;
      let releaseCapture;
      let releaseEntityCapture;
      let reservedTurnId;
      try {
        const releaseOpenedDelivery = holdLifecycle();
        publishLifecycle({ kind: "opened", transactionId });
        try {
          lifecycleChannel.announce({
            kind: "opened",
            owner: transactionOwnerToken,
            id: transactionId
          });
        } finally {
          releaseOpenedDelivery?.();
        }
        const afterOpened = readQueuedLaterEffects();
        for (const id of authority.getPendingTurnIds()) {
          authority.observeQueuedEffects(id, afterOpened);
        }
        notifier?.flushSync();
        openCommitScope(transactionOwnerToken, transactionId, tree);
        lifecycleScopes.add(transactionId);
        descriptorOwnersBefore = new Set(realizationDescriptors.keys());
        releaseCapture = captureRuntime?.activateCapture();
        releaseEntityCapture = observeOpenEntityCapture(
          transactionId,
          captureBucket
        );
        reservedTurnId = authority.reservePending(captureBucket);
      } catch (error) {
        abandonLifecycleView(transactionId);
        throw error;
      }
      let primaryError;
      let primaryFailed = false;
      let cleanupError;
      let cleanupFailed = false;
      const executeTransaction = () => {
        try {
          withWriteContext(
            {
              ...activeMeta ?? {},
              transactionId,
              transactionOwner: transactionOwnerToken
            },
            fn
          );
        } catch (error) {
          primaryFailed = true;
          primaryError = error;
        }
      };
      try {
        const locations = getLocationRuntime(tree.$);
        if (locations) locations.runInvalidationGroup(executeTransaction);
        else executeTransaction();
      } catch (error) {
        if (!primaryFailed) {
          cleanupFailed = true;
          cleanupError = error;
        }
      } finally {
        try {
          try {
            releaseEntityCapture?.();
          } finally {
            releaseCapture?.();
          }
        } catch (error) {
          if (primaryFailed || cleanupFailed)
            reportCleanupFailure(
              "transaction capture release after failure",
              error
            );
          else {
            cleanupFailed = true;
            cleanupError = error;
          }
        }
      }
      let pendingTurn;
      let autoRollbackUnsafe = false;
      let releaseStagedDelivery;
      try {
        const callbackQueuedEvidence = readQueuedLaterEffects();
        for (const id of authority.getPendingTurnIds()) {
          if (id !== reservedTurnId)
            authority.observeQueuedEffects(id, callbackQueuedEvidence);
        }
        if (callbackQueuedEvidence.length) {
          callbackExternalEffects.set(transactionId, [
            ...callbackExternalEffects.get(transactionId) ?? [],
            ...callbackQueuedEvidence
          ]);
        }
        if (!primaryFailed) {
          lifecycleView.phase = "staged";
          releaseStagedDelivery = holdLifecycle();
          publishLifecycle({ kind: "staged", transactionId });
          lifecycleChannel.announce({
            kind: "staged",
            owner: transactionOwnerToken,
            id: transactionId
          });
        }
        notifier?.flushSync();
        const openBucket = pendingTransactions.get(transactionId);
        autoRollbackUnsafe = cleanupFailed && !primaryFailed && openBucket !== void 0 && writtenSinceBy(openBucket);
        pendingTurn = materializePendingTransaction(
          transactionId,
          reservedTurnId
        );
      } catch (error) {
        installedOperations.delete(transactionId);
        expectedDispositions.delete(transactionId);
        pendingTransactions.delete(transactionId);
        callbackExternalEffects.delete(transactionId);
        releaseWindowIfClosed();
        authority.discardPending(reservedTurnId);
        abandonLifecycleView(transactionId);
        throw error;
      } finally {
        releaseStagedDelivery?.();
      }
      const pendingTurnId = pendingTurn?.id;
      if (pendingTurn) {
        inspectionTransactionByTurn.set(pendingTurn.id, transactionId);
        const keys = new Set((pendingTurn.__effects ?? []).map(effectKey));
        const writes = inspectionWrites.get(transactionId);
        for (const key of writes?.keys() ?? [])
          if (!keys.has(key)) writes?.delete(key);
        notifyListeners(pendingCreatedListeners, pendingTurn);
      } else {
        inspectionWrites.delete(transactionId);
      }
      releaseInspectionIfQuiet();
      let lifecycle = "pending";
      let settling = false;
      const handle = {
        [PENDING_TURN_ID]: pendingTurnId,
        confirm() {
          validateOperationDisposition(transactionId, pendingTurnId);
          const pendingTurn2 = authority.getPendingTurn(pendingTurnId);
          if (destroyed) throw new Error("Cannot settle a destroyed tree");
          if (settling)
            throw new Error("Transaction settlement is already in progress");
          if (lifecycle === "confirmed") {
            return;
          }
          if (lifecycle === "rejected") {
            throw new Error("Cannot confirm a rolled back transaction");
          }
          lifecycle = "confirmed";
          installedOperations.delete(transactionId);
          expectedDispositions.delete(transactionId);
          retireLifecycleView(transactionId);
          const releaseConfirmedDelivery = holdLifecycle();
          publishLifecycle({ kind: "confirmed", transactionId });
          try {
            lifecycleChannel.announce({
              kind: "confirmed",
              owner: transactionOwnerToken,
              id: transactionId
            });
            try {
              if (pendingTurnId !== void 0) {
                const confirmedTurn = authority.confirmPending(pendingTurnId);
                const accepted = inspectionWrites.get(transactionId);
                if (accepted) {
                  let settled = inspectionWrites.get(void 0);
                  if (!settled)
                    inspectionWrites.set(void 0, settled = /* @__PURE__ */ new Map());
                  for (const [key, write] of accepted) {
                    if ((settled.get(key)?.seq ?? -1) < write.seq)
                      settled.set(key, write);
                  }
                  inspectionWrites.delete(transactionId);
                }
                inspectionTransactionByTurn.delete(pendingTurnId);
                if (confirmedTurn) {
                  notifyListeners(pendingConfirmedListeners, confirmedTurn);
                }
              }
            } finally {
              if (pendingTurnId !== void 0) {
                pendingOrderDeltas.delete(pendingTurnId);
              }
              releaseInspectionIfQuiet();
              try {
                settleCommitScope(
                  transactionOwnerToken,
                  transactionId,
                  "commit"
                );
              } finally {
                forgetUnclaimedDescriptorSubjects(
                  pendingTurn2?.restorationSubjectIds ?? [],
                  descriptorOwnersBefore,
                  pendingTurn2?.__positionIds ?? []
                );
              }
            }
          } finally {
            releaseConfirmedDelivery?.();
          }
        },
        rollback() {
          validateOperationDisposition(transactionId, pendingTurnId);
          const pendingTurn2 = authority.getPendingTurn(pendingTurnId);
          if (destroyed) throw new Error("Cannot settle a destroyed tree");
          if (settling)
            throw new Error("Transaction settlement is already in progress");
          if (lifecycle === "rejected") return;
          if (lifecycle === "confirmed")
            throw new Error("Cannot rollback a confirmed transaction");
          const plan = pendingTurnId === void 0 ? { compensation: [] } : authority.getPendingRollbackPlan(
            pendingTurnId,
            readQueuedLaterEffects()
          );
          if ("conflict" in plan) {
            const refusal = createRollbackError(plan.conflict);
            publishRefusal(transactionId, refusal);
            throw refusal;
          }
          const compensation = plan.compensation;
          const orderDeltas = pendingTurnId === void 0 ? [] : pendingOrderDeltas.get(pendingTurnId) ?? [];
          let installed = false;
          const completion = { selected: false, committed: false };
          let observerFailed = false;
          let observerError;
          const clock = getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree);
          const revision = clock?.revision();
          let releaseRolledBackDelivery;
          settling = true;
          try {
            const apply = () => {
              rollbackPendingEffectsThroughRealizationPort(
                pendingTurnId ?? transactionId,
                [...compensation].reverse(),
                pendingTurn2?.__baselineValues ?? /* @__PURE__ */ new Map(),
                orderDeltas,
                primaryFailed ? primaryError : void 0,
                transactionId,
                completion
              );
              installed = true;
            };
            try {
              const locations = getLocationRuntime(tree.$);
              if (locations) locations.runInvalidationGroup(apply);
              else apply();
            } catch (error) {
              installed ||= completion.selected ? completion.committed : revision !== void 0 && clock?.revision() !== revision;
              if (!installed) {
                const refusal = error instanceof SignalTreeRollbackError ? error : createRollbackError({
                  kind: "effect-validation-failed",
                  pendingTurnId: pendingTurnId ?? transactionId,
                  compensation,
                  errorMessage: error instanceof Error ? error.message : "Unknown rollback validation failure",
                  cause: error,
                  callbackError: primaryFailed ? primaryError : void 0
                });
                publishRefusal(transactionId, refusal);
                throw refusal;
              }
              observerFailed = true;
              observerError = error;
            }
            lifecycle = "rejected";
            installedOperations.delete(transactionId);
            expectedDispositions.delete(transactionId);
            retireLifecycleView(transactionId);
            releaseRolledBackDelivery = holdLifecycle();
            publishLifecycle({ kind: "rolled-back", transactionId });
            inspectionWrites.delete(transactionId);
            if (pendingTurnId !== void 0)
              inspectionTransactionByTurn.delete(pendingTurnId);
            const discarded = pendingTurnId === void 0 ? void 0 : authority.discardPending(pendingTurnId);
            if (pendingTurnId !== void 0)
              pendingOrderDeltas.delete(pendingTurnId);
            releaseInspectionIfQuiet();
            lifecycleChannel.announce({
              kind: "rolled-back",
              owner: transactionOwnerToken,
              id: transactionId
            });
            try {
              if (discarded)
                notifyListeners(pendingDiscardedListeners, discarded);
            } finally {
              try {
                settleCommitScope(
                  transactionOwnerToken,
                  transactionId,
                  "discard"
                );
              } finally {
                forgetUnclaimedDescriptorSubjects(
                  pendingTurn2?.restorationSubjectIds ?? [],
                  descriptorOwnersBefore,
                  pendingTurn2?.__positionIds ?? []
                );
              }
            }
            if (observerFailed) throw applicationFailureCause(observerError);
          } finally {
            settling = false;
            releaseRolledBackDelivery?.();
          }
        }
      };
      if (primaryFailed || cleanupFailed) {
        try {
          if (autoRollbackUnsafe) {
            const refusal = createRollbackError({
              kind: "effect-validation-failed",
              pendingTurnId: pendingTurnId ?? transactionId,
              compensation: [],
              errorMessage: "Transaction rollback refused: a location it wrote was written again before the transaction returned"
            });
            publishRefusal(transactionId, refusal);
            throw refusal;
          }
          handle.rollback();
        } catch (rollbackError) {
          if (lifecycle !== "pending") {
            reportCleanupFailure(
              "rollback delivery after a failed transaction",
              rollbackError
            );
            throw primaryFailed ? primaryError : cleanupError;
          }
          if (!primaryFailed) {
            reportCleanupFailure(
              "a post-callback step whose rollback was then refused",
              cleanupError
            );
          }
          if (lifecycle === "pending" && !destroyed && typeof rollbackError === "object" && rollbackError !== null) {
            Object.defineProperty(rollbackError, "recovery", {
              value: {
                transaction: decorateHandle(handle, pendingTurnId),
                // Explicit: the callback may have thrown `undefined`.
                callbackFailed: primaryFailed,
                callbackError: primaryFailed ? primaryError : void 0
              },
              enumerable: false,
              configurable: true,
              writable: true
            });
          }
          throw rollbackError;
        }
        throw primaryFailed ? primaryError : cleanupError;
      }
      return decorateHandle(handle, pendingTurnId);
    },
    getConfirmedTurnRecords: () => authority.getConfirmedTurnRecords(),
    setHistoryRetention: (retain) => authority.setHistoryRetention(retain),
    getConfirmedRetention: () => authority.getConfirmedRetention(),
    describePendingTurn: inspectPendingTurn,
    getInspectionFootprintCountsForTesting: () => ({
      writers: inspectionWrites.size,
      footprints: [...inspectionWrites.values()].reduce(
        (count, writes) => count + writes.size,
        0
      )
    }),
    getConfirmedTurnCount: () => authority.getConfirmedTurnCount(),
    getPendingTurnCount: () => authority.getPendingTurnCount(),
    getConfirmedTurnIds: () => authority.getConfirmedTurnIds(),
    getPendingTurnIds: () => authority.getPendingTurnIds(),
    onPendingCreated(listener) {
      pendingCreatedListeners.add(listener);
      return () => pendingCreatedListeners.delete(listener);
    },
    onPendingConfirmed(listener) {
      pendingConfirmedListeners.add(listener);
      return () => pendingConfirmedListeners.delete(listener);
    },
    onPendingDiscarded(listener) {
      pendingDiscardedListeners.add(listener);
      return () => pendingDiscardedListeners.delete(listener);
    }
  };
  const reportCleanupFailure = (step, error) => {
    try {
      console.error(
        `SignalTree: transactions() cleanup failed during ${step}.`,
        error
      );
    } catch {
    }
  };
  if (typeof tree.registerCleanup === "function") {
    tree.registerCleanup(() => {
      destroyed = true;
      lifecycleViews.clear();
      lifecycleScopes.clear();
      authority.releaseConfirmedTurnsOnDestroy();
      cancelCommitScopes(transactionOwnerToken);
      for (const id of authority.getPendingTurnIds()) {
        const discarded = authority.discardPending(id);
        forgetUnclaimedDescriptorSubjects(
          discarded?.restorationSubjectIds ?? [],
          /* @__PURE__ */ new Set(),
          discarded?.__positionIds ?? []
        );
      }
      pendingTransactions.clear();
      lastWindowWriteSeq.clear();
      lastWindowRowWriteSeq.clear();
      callbackExternalEffects.clear();
      inspectionWrites.clear();
      inspectionTransactionByTurn.clear();
      unsubscribeEnqueue?.();
      unsubscribeEnqueue = null;
      pendingCreatedListeners.clear();
      pendingConfirmedListeners.clear();
      pendingDiscardedListeners.clear();
      drainCaptureBucket(pendingCapture);
      try {
        unsubscribeFlush?.();
      } catch (error) {
        reportCleanupFailure("flush unsubscription", error);
      }
      try {
        unsubscribeNotifications?.();
      } catch (error) {
        reportCleanupFailure("notification unsubscription", error);
      }
      try {
        unsubscribeReset?.();
      } catch (error) {
        reportCleanupFailure("reset unsubscription", error);
      }
      try {
        unsubscribeCollectionOrders?.();
      } catch (error) {
        reportCleanupFailure("collection-order unsubscription", error);
      }
      try {
        restoreLeafInterceptors?.();
      } catch (error) {
        reportCleanupFailure("leaf interceptor teardown", error);
      }
      unsubscribeFlush = null;
      unsubscribeNotifications = null;
      unsubscribeReset = null;
      unsubscribeCollectionOrders = null;
      restoreLeafInterceptors = null;
      pendingOrderDeltas.clear();
    });
  }
  tree[INTERNAL_TRANSACTION_RUNTIME] = runtime2;
  installTransactionLifecycleChannel(tree);
  return runtime2;
}
function classifyProposedEffect(effect, laterEffects) {
  if (effect.kind === "set") {
    const replaced = laterEffects.some(
      (later) => later.position === effect.position && (later.kind === "remove" && effect.subject !== void 0 && later.subject === effect.subject || later.kind === "set" && scalarRelation(later, effect) === "same" && (later.subject === void 0 || effect.subject === void 0 || later.subject === effect.subject))
    );
    return replaced ? "superseded" : "current";
  }
  let present = true;
  for (const later of laterEffects) {
    if (later.ownerPath !== effect.ownerPath) {
      continue;
    }
    if (later.subject !== effect.subject) {
      continue;
    }
    present = later.kind !== "remove";
  }
  return present ? "current" : "superseded";
}
function transactions(config) {
  const enhancerFn = (tree) => {
    const runtime2 = getOrCreateInternalTransactionRuntime(tree);
    if (config?.history) {
      runtime2.setHistoryRetention(config.history.retain);
    }
    const host = tree;
    host.transact = runtime2.transaction;
    tree["__transactions"] = {
      getConfirmedTurnCount: () => runtime2.getConfirmedTurnCount(),
      getPendingTurnCount: () => runtime2.getPendingTurnCount(),
      getConfirmedTurnIds: () => runtime2.getConfirmedTurnIds(),
      getPendingTurnIds: () => runtime2.getPendingTurnIds()
    };
    return tree;
  };
  const meta = {
    name: "transactions",
    provides: ["transactions"],
    capabilities: ["causal-runtime"]
  };
  enhancerFn.metadata = meta;
  enhancerFn[ENHANCER_META] = meta;
  return enhancerFn;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tooling-tree.ts
function isToolingTreeDestroyed(tree) {
  return tree.destroyed() === true;
}

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/confirmed-turn-view.ts
var StudioTreeDestroyedError = class extends Error {
  code = "STUDIO_TREE_DESTROYED";
  constructor() {
    super(
      "STUDIO_TREE_DESTROYED: this tree was destroyed; its retained transaction history is no longer readable. Empty history and a destroyed tree are different facts, so this refuses rather than returning an empty snapshot."
    );
    this.name = "StudioTreeDestroyedError";
  }
};

// ../../.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/transaction-lifecycle-view.ts
var states = /* @__PURE__ */ new WeakMap();
var noop2 = () => void 0;
var detach = (snapshot) => ({
  ...snapshot,
  pending: snapshot.pending.map((item) => ({ ...item }))
});
function snapshotOf(source) {
  const { sequence, pending } = source.read();
  return {
    treeId: source.treeId,
    sequence,
    pending: pending.map((item) => ({ ...item }))
  };
}
function reasonOf(error) {
  const kind = error instanceof SignalTreeRollbackError ? error.cause?.kind : void 0;
  return kind === "later-confirmed-dependency" ? kind : "effect-validation-failed";
}
function deliver(state) {
  if (state.delivering || state.holds > 0) return;
  state.delivering = true;
  try {
    for (let i = 0; i < state.deliveries.length; i++) {
      const { event, audience } = state.deliveries[i];
      for (const subscription of audience) {
        if (state.closed || !state.listeners.has(subscription)) continue;
        try {
          subscription.listener({ ...event, snapshot: detach(event.snapshot) });
        } catch {
        }
      }
    }
  } finally {
    state.deliveries.length = 0;
    state.delivering = false;
  }
}
function observe(source, state) {
  return {
    record(fact) {
      if (state.closed || state.listeners.size === 0) return;
      const snapshot = snapshotOf(source);
      let event;
      if (fact.kind === "refused") {
        const retained = snapshot.pending.find(
          (item) => item.transactionId === fact.transactionId
        );
        event = {
          kind: "refused",
          transactionId: fact.transactionId,
          reason: reasonOf(fact.error),
          pendingRetained: retained !== void 0,
          consequencesReleased: !!retained?.consequencesReleased,
          treeId: snapshot.treeId,
          sequence: snapshot.sequence,
          snapshot
        };
      } else {
        event = {
          kind: fact.kind,
          transactionId: fact.transactionId,
          treeId: snapshot.treeId,
          sequence: snapshot.sequence,
          snapshot
        };
      }
      state.deliveries.push({ event, audience: [...state.listeners] });
      deliver(state);
    },
    hold() {
      if (state.delivering) return noop2;
      state.holds++;
      let released = false;
      return () => {
        if (released) return;
        released = true;
        state.holds--;
        deliver(state);
      };
    }
  };
}
function transactionLifecycleReader(tree) {
  if (isToolingTreeDestroyed(tree)) throw new StudioTreeDestroyedError();
  const registry = getPositionRegistry(tree.$);
  const source = registry && getTransactionLifecycleSource(registry);
  if (!registry || !source) return void 0;
  let existing = states.get(registry);
  if (!existing) {
    const state2 = {
      closed: false,
      delivering: false,
      holds: 0,
      listeners: /* @__PURE__ */ new Set(),
      deliveries: []
    };
    existing = state2;
    states.set(registry, state2);
    source.attach(observe(source, state2));
    tree.registerCleanup(() => {
      state2.closed = true;
      state2.listeners.clear();
      state2.deliveries.length = 0;
    });
  }
  const state = existing;
  const assertLive = () => {
    if (state.closed || isToolingTreeDestroyed(tree))
      throw new StudioTreeDestroyedError();
  };
  return {
    snapshot() {
      assertLive();
      return snapshotOf(source);
    },
    subscribe(listener) {
      assertLive();
      const subscription = { listener };
      state.listeners.add(subscription);
      return () => {
        state.listeners.delete(subscription);
      };
    }
  };
}

// <stdin>
var tick = async () => {
  for (let i = 0; i < 100; i++) await Promise.resolve();
};
async function run() {
  mode(true);
  const results = [];
  for (const scenario of ["direct", "reactive", "two", "reject-new", "overwrite", "ABA", "opened", "reentry", "refusal", "realization", "foreign-attribution", "cross-tree"]) {
    const t = signalTree({ x: 0, y: 0, z: 0 }, { enhancers: [transactions()] });
    const sent = [];
    const out = link(t.$.y, { set: (v) => {
      sent.push(v);
    } });
    const reader = transactionLifecycleReader(t);
    const events = [];
    const offs = [];
    const checks = [];
    const eq = (actual, expected, name) => checks.push({ name, actual, expected, pass: JSON.stringify(actual) === JSON.stringify(expected) });
    let p, q;
    offs.push(reader.subscribe((e) => {
      events.push(e.kind);
      if (scenario === "opened" && e.kind === "opened") t.$.y(42);
    }));
    try {
      p = t.transact(() => t.$.x(7));
      if (scenario === "reactive") offs.push(getPathNotifier().subscribe("x", (v) => {
        if (v === 8) t.$.y(v);
      }));
      if (scenario === "two") q = t.transact(() => t.$.z(9));
      if (scenario === "reactive") t.$.x(8);
      else if (scenario !== "opened" && scenario !== "realization" && scenario !== "foreign-attribution" && scenario !== "cross-tree") t.$.y(42);
      if (scenario === "realization") withWriteContext({ participation: "realized", origin: "restoration" }, () => t.$.y(42));
      if (scenario === "foreign-attribution") withWriteContext({ transactionId: 1, transactionOwner: {} }, () => t.$.y(42));
      if (scenario === "cross-tree") {
        const other = signalTree({ x: 0 }, { enhancers: [transactions()] });
        const op = other.transact(() => other.$.x(7));
        p.confirm();
        t.$.y(other.$.x());
        await tick();
        results.push({ scenario, scopeLimit: true, sent: [...sent], sourcePending: op.status });
        out.dispose();
        op.rollback();
        other.destroy();
        continue;
      }
      await tick();
      eq([...sent], [], "held before captured confirmation");
      if (!q) q = t.transact(() => t.$.z(9));
      if (scenario === "overwrite" || scenario === "ABA") {
        t.$.y(99);
        if (scenario === "ABA") t.$.y(42);
      }
      if (scenario === "reentry") {
        let fired = false;
        const slot = getLinkStateSlot(getPositionRegistry(t.$.y));
        slot.observer = (r) => {
          if (r.endpoint.set && r.activity()[3] && !fired) {
            fired = true;
            t.$.y(99);
          }
        };
        offs.push(() => {
          slot.observer = void 0;
        });
      }
      if (scenario === "reject-new") {
        p.rollback();
        await tick();
        eq([...sent], [], "rejected ticket held");
        t.$.y(43);
        await tick();
        eq([...sent], [], "new window retains q");
        q.confirm();
        await tick();
        eq([...sent], [43], "new authored window releases");
      } else if (scenario === "refusal") {
        const r = t.transact(() => t.$.x(8));
        let error = "";
        try {
          p.rollback();
        } catch (e) {
          error = String(e);
        }
        await tick();
        eq([...sent], [], "refusal cannot release");
        checks.push({ name: "refusal witness", error, pass: !!error });
        r.rollback();
        p.confirm();
        await tick();
        eq([...sent], [42], "confirm after retry releases old revision");
      } else {
        p.confirm();
        await tick();
        const held = ["two", "overwrite", "ABA", "reentry", "realization", "foreign-attribution"].includes(scenario);
        eq([...sent], held ? [] : [scenario === "reactive" ? 8 : 42], "p confirmation while q pending");
        q.confirm();
        await tick();
        eq([...sent], ["realization", "foreign-attribution"].includes(scenario) ? [] : [scenario === "overwrite" || scenario === "reentry" ? 99 : scenario === "reactive" ? 8 : 42], "all captured owners confirm");
      }
      eq(events.includes("opened") && events.includes("confirmed"), true, "public lifecycle observer preserved");
      results.push({ scenario, sent: [...sent], checks, events });
    } catch (error) {
      results.push({ scenario, harnessError: String(error), sent, checks, events });
    } finally {
      for (const off of offs) off();
      out.dispose();
      t.destroy();
      await tick();
    }
  }
  results.push({ diagnostics: diagnostics(), receipts });
  return results;
}
export {
  run
};
