# Bounded responsibility observation experiment

Production baseline e488ca34. No runtime source, API, or budget edits.

Immutable scalar receipt binds payload, fact revision and exact (tree,position). Enqueue invalidates old ticket immediately. PathNotifier's captured batch marks exact entry receipt completed BEFORE subscriber delivery, including net-equal entries that skip user delivery. Link onFlush refreshes its projection and ticket together from a completed receipt only if it is still latest. Reentrant writes are uncompleted until the next batch; old tickets cannot send. Physical read equality is only a consistency guard, never responsibility identity.

Default batched scalar notifier only; batching-disabled, entities and native frameworks unqualified. Existing value suppression unchanged. Terminal outcome wake may refresh only completed receipts. Existing final reentry validation and serialized delivery preserved.

Conservative blockers include immutable (tree id, transaction id) for every pending owner in all registered transaction-enabled trees. Foreign confirmation wakes connections globally. Rejection/abandonment never counts as confirmation. New authored writes capture a new window under approved surviving-write semantics. Authoritative ingress retains its separately reviewed trust boundary. This is not arbitrary causality inference; outside-runtime values cannot be proven independent.

Cost: snapshot scans registered trees and their pending views per authored notification. Runtime Map retention is not qualified; no performance acceptance. Explicit disposal must detach listener; registry/terminal/latest evidence retention measured separately.

Acceptance: unchanged ABA and prior window checks; original delivery assertions preserved with previously authorized unknown-confirm expectation differences reported separately. Extra checks: no user ABA notification; same transaction ids across trees; foreign confirm/reject; reentrant ABA at flush; disposal; in-flight correction. One mechanism revision only, preserve first results. Stop on new concrete mechanism recurrence.
