# Completed-batch scalar responsibility transport

Baseline e488ca34e75a808f0f4dc26edfea5e7ea26fcaab. Private loader transformation only. Production source untouched; no API, budget or default policy change.

## Mechanism and first results

private.ts stores immutable exact scalar payload+ticket receipts and snapshots all registered transaction trees' pending owner IDs as namespaced pairs. Latest identity invalidates prior admission synchronously. Loader marks exact queued entry receipts completed before the captured notification batch invokes subscribers, including net-equal skipped entries. Link's existing flush callback refreshes payload+ticket together only if the completed receipt is still latest and physically equal. Physical read is a guard, never the projection source. Reentrant next-batch receipts invalidate old admission but cannot refresh before their own completion. Terminal foreign outcomes wake all connections; only confirmed captured owners discharge blockers.

First executed unchanged window: 46/46 assertions pass, including original ABA. Cross-tree witness now sends nothing while source owner is pending. first-window-{bundle,receipts,traces} and first-window.log preserved. No substantive first failure arose and no implementation repair followed these executions.

Historical unchanged targeted.ts:32 pass,2 fail on preserved unknown-confirm expectations (old assertions require no send and unresolved waiter; candidate correctly sends42 after captured confirmation and resolves waiter under the already approved window semantics). Neither assertion edited.

Extra first execution14/14. Final extra16/16 adds explicit next-batch event-order assertion and late foreign-owner noncontamination, no implementation change. First extra output retained; first-extra-bundle contains original extra source. Cases include ordinary subscriber ABA suppression, reentrant99/42, same numeric transaction IDs across two trees, foreign confirm wake, rejection/destruction no cleansing, fresh surviving overwrite. The mixed intent attempt passes but does not prove metadata-loss resistance for all intents: mutation path can replace requested intent. Not counted as complete metadata-producer audit.

Original unchanged witness retains known tree-destruction failure and subsequent destroyed-settlement error in both original scheduler-control and candidate. Original scheduler-control also retains rejected-copy failure; candidate holds that pre-rejection ticket. Authoritative ingress [42,7] and existing observer/enqueue reentry protections preserved. Connection disposal remains distinct from tree destruction.

## Scope and costs

Only scalar default batched notifier. Nonbatched paths, entity/branch projection, all native frameworks, allocation-fault atomicity, cross-package-instance/realm/cached hidden provenance and production installation unqualified. All-tree safety bound assumes complete registry of transaction-enabled trees in this instrumented runtime; it is NOT permission to release outside-runtime speculation. Ordinary writes during existing pending owners remain conservatively held, so full independent progress remains unmet.

Each capture scans every registered source and pending view. Final extra workload seven scenarios creates14 transaction-enabled trees and records30 notifications:232 registered-source visits,39 pending-owner visits. Post-teardown14 source closures,10 outcome maps,30 receipt records,20 latest entries and20 completed entries remain; eligibility listener maps0. This is explicit unreclaimed research metadata, NOT lifecycle/cost acceptance. No CPU/bundle/heap comparisons conducted. Final extra counts are workload totals, not constant-time claims.

Completion currently reads coalesced entry metadata. mergeMeta may drop inconsistent metadata; tested scalar producer scenarios passed. No unsupported synthetic mutation is proof of a production defect. Full producer coverage remains unqualified.

## Exact replay

Use Node24.15.0 and installed worktree esbuild/TypeScript. Loader guards substitution counts and saves original/loaded SHA256 of every bundled kernel file in receipts. Generic output files overwritten by replays; first-* and named-* preserve original evidence.

    ENTRY=window-unchanged.ts /Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node /private/tmp/link-responsibility-path/loader.mjs
    TARGETED=1 /Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node /private/tmp/link-responsibility-path/loader.mjs
    ENTRY=extra.ts /Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node /private/tmp/link-responsibility-path/loader.mjs
    /Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node /private/tmp/link-responsibility-path/loader.mjs
    /Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node /Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/node_modules/typescript/bin/tsc --strict --noEmit --target es2022 --module esnext --moduleResolution bundler --skipLibCheck /private/tmp/link-responsibility-path/private.ts

Strict private model typecheck passes. This is not kernel/spec typecheck or a broad suite run. SHA256SUMS freezes source/evidence; large bundle outputs may be archived compressed without changing their recorded uncompressed identity.
