import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
import {getPathNotifier} from './packages/kernel/src/lib/path-notifier';
import {getPositionRegistry} from './packages/kernel/src/lib/internals/position-registry';
import {getLinkStateSlot} from './packages/kernel/src/lib/internals/link-state-source';
import {transactionLifecycleReader} from './packages/kernel/src/lib/internals/transaction-lifecycle-view';
import * as research from 'research-private';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){research.mode(true);const results:unknown[]=[];
for(const scenario of ['direct','reactive','two','reject-new','overwrite','ABA','opened','reentry','refusal','realization','foreign-attribution','cross-tree']){
 const t=signalTree({x:0,y:0,z:0},{enhancers:[transactions()]});const sent:number[]=[];const out=link(t.$.y,{set:v=>{sent.push(v);}});const reader=transactionLifecycleReader(t)!;const events:string[]=[];const offs:(()=>void)[]=[];const checks:unknown[]=[];
 const eq=(actual:unknown,expected:unknown,name:string)=>checks.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
 let p:ReturnType<typeof t.transact>,q:ReturnType<typeof t.transact>|undefined;
 offs.push(reader.subscribe(e=>{events.push(e.kind);if(scenario==='opened'&&e.kind==='opened')t.$.y(42);}));
 try{
 p=t.transact(()=>t.$.x(7));
 if(scenario==='reactive')offs.push(getPathNotifier().subscribe('x',v=>{if(v===8)t.$.y(v as number);}));
 if(scenario==='two')q=t.transact(()=>t.$.z(9));
 if(scenario==='reactive')t.$.x(8);else if(scenario!=='opened'&&scenario!=='realization'&&scenario!=='foreign-attribution'&&scenario!=='cross-tree')t.$.y(42);
 if(scenario==='realization')withWriteContext({participation:'realized',origin:'restoration'},()=>t.$.y(42));
 if(scenario==='foreign-attribution')withWriteContext({transactionId:1,transactionOwner:{}},()=>t.$.y(42));
 if(scenario==='cross-tree'){const other=signalTree({x:0},{enhancers:[transactions()]});const op=other.transact(()=>other.$.x(7));p.confirm();t.$.y(other.$.x());await tick();results.push({scenario,scopeLimit:true,sent:[...sent],sourcePending:op.status});out.dispose();op.rollback();other.destroy();continue;}
 await tick();eq([...sent],[],'held before captured confirmation');
 if(!q)q=t.transact(()=>t.$.z(9));
 if(scenario==='overwrite'||scenario==='ABA'){t.$.y(99);if(scenario==='ABA')t.$.y(42);}
 if(scenario==='reentry'){let fired=false;const slot=getLinkStateSlot(getPositionRegistry(t.$.y)!);slot.observer=r=>{if(r.endpoint.set&&r.activity()[3]&&!fired){fired=true;t.$.y(99);}};offs.push(()=>{slot.observer=undefined;});}
 if(scenario==='reject-new'){p.rollback();await tick();eq([...sent],[],'rejected ticket held');t.$.y(43);await tick();eq([...sent],[],'new window retains q');q.confirm();await tick();eq([...sent],[43],'new authored window releases');}
 else if(scenario==='refusal'){const r=t.transact(()=>t.$.x(8));let error='';try{p.rollback();}catch(e){error=String(e);}await tick();eq([...sent],[],'refusal cannot release');checks.push({name:'refusal witness',error,pass:!!error});r.rollback();p.confirm();await tick();eq([...sent],[42],'confirm after retry releases old revision');}
 else {p.confirm();await tick();const held=['two','overwrite','ABA','reentry','realization','foreign-attribution'].includes(scenario);eq([...sent],held?[]:[scenario==='reactive'?8:42],'p confirmation while q pending');q.confirm();await tick();eq([...sent],['realization','foreign-attribution'].includes(scenario)?[]:[scenario==='overwrite'||scenario==='reentry'?99:scenario==='reactive'?8:42],'all captured owners confirm');}
 eq(events.includes('opened')&&events.includes('confirmed'),true,'public lifecycle observer preserved');results.push({scenario,sent:[...sent],checks,events});
 }catch(error){results.push({scenario,harnessError:String(error),sent,checks,events});}finally{for(const off of offs)off();out.dispose();t.destroy();await tick();}
}results.push({diagnostics:research.diagnostics(),receipts:research.receipts});return results;}
