# Independent premise review: responsibility observation separate from values

Reviewed checkout e488ca34e75a808f0f4dc26edfea5e7ea26fcaab. Source inspection only; no implementation replay yet. No production edits.

## Premises and narrow disposition

User's current frozen premise: “value equality does not imply unchanged publication responsibility.” Also: “Preserve ordinary value-notification suppression; do not force user-visible emissions just to wake Link.” The prior approved surviving-write decision permits new actual ordinary post-rejection writes; it does not retrospectively clear a rejected owner from an older ticket.

A separate private scalar responsibility transport is a legitimate bounded experiment. The existing notifier already observes enqueue evidence before coalescing; its flush intentionally skips net-equal entries. A ticket therefore must not depend exclusively on value delivery. This does not justify treating every ordinary write as independent or relaxing production's hold.

The proposed all-registered-tree pending-owner snapshot can conservatively cover cross-tree copies inside one fully instrumented runtime instance. It is not dependency inference, universal cross-runtime tracking, or immediate independence for an ordinary write authored while another transaction exists. It adds broader holds and requires global owner observation. Passing its controls must not close the general release requirement.

## Source evidence

- packages/kernel/src/lib/path-notifier.ts:271–336 obtains mutation metadata and immutable enqueue snapshots before queue coalescing; observation exceptions cannot veto installed mutation. Prior eligibility must be invalidated before fallible capture.
- path-notifier.ts:484–538 snapshots and clears pending entries, invokes ordinary subscribers, skips net-equal values at 502–510, then invokes flush callbacks. Reentrant writes are queued into a later batch while latest responsibility already changes.
- packages/kernel/src/lib/link.ts:335–344 explicitly rejects re-reading current state as the eligible projection: later inspection writes can contaminate it. Refresh must carry the exact authored scalar payload with its ticket, not adopt read() wholesale.
- link.ts:765–778 defines settled-turn outbound semantics; delivery is not allowed to publish arbitrary intermediate writes. Existing post-observer preflight checks in the research loader remain necessary after refresh.
- Prior owner-window PRIVATE/loader evidence keys outcomes by target tree and ID; extending only capture without foreign-owner wake and namespacing is incomplete.

## Required delivery boundary

Prefer completion tracking for exact entry tickets at the flush's toNotify snapshot, including entries subsequently suppressed for equality. Before ordinary subscriber delivery, mark those ticket identities as belonging to this completed batch; do not mark later reentrant receipts complete. At flush callback, promote the exact receipt payload and ticket together only if that completed ticket is still latest. A reentrant later receipt invalidates prior eligibility but waits for its own batch completion. Final endpoint preflight rechecks ticket identity again.

A read() comparison may act as a consistency guard but cannot manufacture evidence, replace the receipt payload, or substitute equality for ticket identity. Unknown inspection/realization tickets remain ineligible. Scalar receipts do not establish branch/entity snapshot coherence. The batching-disabled synchronous path needs its own completion rule or an explicit unqualified boundary.

## Minimum controls

1. Original ABA exactly preserved: 42 to99 to42 while P,Q pending; no added ordinary value emission, final ticket waits for both confirmations, then sends42.
2. Reentrant 99 to42 from ordinary notification during flush: prior ticket never sends and later ticket waits for next completed batch; verify endpoint sequence, not just final equality.
3. Sending-observer replacement, held-to-eligible replacement, independently queued and already-started requests: retain existing final revision checks and serialized corrective sends.
4. Known inspection/restoration-origin overwrite cannot make current read become eligible through refresh; prior ticket cannot silently authorize it.
5. Cross-tree copy with same numeric transaction IDs in different trees: confirm target owner alone does not discharge source owner. Foreign rejection holds old receipt; fresh post-rejection write follows approved semantics and captures remaining owners.
6. Foreign confirm wakes affected target Link; later unrelated tree owner does not retroactively enter an unchanged receipt. Capture whole namespaced owner set immutably.
7. Destroying or unregistering a source does not mean confirmation; missing outcome stays held. Explicit Link disposal removes responsibility/wake subscriptions and prevents later new calls; in-flight completion is separate.
8. Authoritative ingress still progresses under its actual tested boundary; ordinary callback copies must not inherit the ingress exemption.

## Coverage and stop boundary

A single module registry cannot observe another loaded package copy, worker, realm, or already-pending tree missed before instrumentation. Those inputs cannot be advertised as safe because the registered owner map happens to be empty. Document supported full-registry closure and preserve unknown/missing provenance conservatively. This review does not prescribe a new public option or claim enforcement outside the instrumented universe.

All-tree snapshot cost is proportional to registered/pending state, not sparse dependency work. No production performance or reclamation conclusion follows. Retained source closures are not reclaimed merely because listener cleanup succeeds.

Proceed only with the finite scalar experiment and unchanged controls. A new concrete mechanism failure should be preserved and reported, not repaired by widening eligibility, suppressing assertions, or expanding into a provenance graph.
