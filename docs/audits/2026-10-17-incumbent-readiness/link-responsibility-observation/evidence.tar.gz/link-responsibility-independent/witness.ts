import {signalTree,transactions,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
import * as research from 'research-private';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve();};
export async function run(){const results=[];for(const kind of ['transaction-ordinary','realized-ordinary']){
 const t=signalTree({x:0,y:0},{enhancers:[transactions()]});const sent:number[]=[];const out=link(t.$.y,{set:v=>{sent.push(v);}});
 const p=t.transact(()=>t.$.x(7));t.$.y(42);await tick();
 let q:any;
 if(kind==='transaction-ordinary')q=t.transact(()=>t.$.y(99));else withWriteContext({participation:'realized',origin:'restoration'},()=>t.$.y(99));
 t.$.y(42);await tick();p.confirm();if(q)q.confirm();await tick();
 results.push({kind,actual:sent,expected:[42],pass:JSON.stringify(sent)==='[42]',y:t.$.y(),owners:[p.status,q?.status]});out.dispose();t.destroy();await tick();
}return {results,receipts:research.receipts};}
