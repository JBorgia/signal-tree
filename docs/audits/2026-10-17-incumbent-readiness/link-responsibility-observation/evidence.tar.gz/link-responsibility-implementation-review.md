# Independent implementation review: responsibility transport

Reviewed /private/tmp/link-responsibility-path private.ts and loader.mjs against checkout e488ca34. No production edits or candidate repair. Independent runs saved under /private/tmp/link-responsibility-independent.

## Executed evidence

Replayed first-window-bundle.mjs: 46 asserted passes, 0 failures. Full JSON exactly equals first-window-traces.json.
Replayed first-extra-bundle.mjs: 14 asserted passes, 0 failures. Full JSON exactly equals first-extra-traces.json.

The extra ABA trace has one user y value event before the ABA and still one afterward, then sends42 after both captured owners confirm. Responsibility completion therefore does not force a user value event in this tested path. Foreign same-ID controls hold after target confirmation, release after foreign confirmation, and retain the old hold after foreign rejection/destruction. The reentrant ABA trace records the authored replacement followed by subsequent flushes before endpoint delivery.

I independently built two additional probes without modifying candidate code: transaction-authored99 then ordinary42, and realized/restoration99 then ordinary42 in the same batch, after an earlier held42. Both eventually send42 after captured owners confirm. Exact source, bundle, receipts and output are in the independent directory.

## Specific proposed failure not reproduced

The completion channel still relies on the coalesced entry metadata retaining its stamp. mergeMeta can discard incompatible metadata, but default enqueuePending calls hasSameSemanticIdentity, which calls crossesCausalModeBoundary. Different participation, origin, transaction ID or owner splits entries rather than merging them. This explains both passing independent probes. Do not report the hypothesized lost-stamp case as an established default runtime failure.

The experimental path-position-subject-composite batching mode bypasses those checks; it is not demonstrated supported by this candidate. Likewise batching-disabled notify bypasses flush completion. Keep those modes unqualified rather than extrapolating default-batching results.

## Source findings

- Each receipt stores an exact scalar payload and frozen fact. Link refresh adopts that payload and fact together. read() is only an Object.is consistency guard, not the projection source. This avoids the earlier proposed direct current-state adoption, but does not qualify branch/entity or native-computed behavior.
- Completion is recorded from the toNotify snapshot before subscriber callbacks and before equality suppression. A reentrant new latest receipt is not completed by this loop; refresh rejects the older completed receipt. Existing final send preflight still checks latest fact identity.
- Cross-tree blockers use frozen {owner,id} pairs; outcome lookup keeps the namespace. Foreign terminal transitions wake all registered listeners. Missing/destroyed outcomes are not converted to confirmation for existing receipts.
- Ordinary ingress callback work has no blanket clean flag; exact acquire exemption still consumes a matching source-position notification only. Prior ingress assumptions remain a separate boundary.
- Capture clears latest before allocating a new record. No staged allocation-fault run was added in this review; source inspection alone is not fault qualification.

## Limits and disposition

No new mechanism-level counterexample was found in the reviewed default-batched scalar controls. The original ABA failure is closed in this bounded experiment, and the same-runtime cross-tree witness is conservatively held.

This is not production Link acceptance. It is all-owner conservatism within one registered runtime, not inference that a write is independent of transactions already pending. Another module instance, worker or unregistered source is not covered. Each captured write traverses every registered source and all their pending views; sources, outcomes, receipts and completed indexes remain retained. Disposal removes wake listeners but does not establish metadata reclamation. No entity, adapter, artifact, CPU, or heap qualification was performed.

Recommended disposition: preserve this tested responsibility-transport result and state its narrow eligibility benefit. Do not claim the automatic independent-progress release requirement satisfied or infer broad safety/cost from the scalar passes.

Replay:
node --input-type=module -e 'const {run}=await import("/private/tmp/link-responsibility-path/first-window-bundle.mjs"); console.log(JSON.stringify(await run(),null,2))'
node --input-type=module -e 'const {run}=await import("/private/tmp/link-responsibility-path/first-extra-bundle.mjs"); console.log(JSON.stringify(await run(),null,2))'
node /private/tmp/link-responsibility-independent/loader.mjs
Use pinned Node24.15.0. The final command rebuilds only the independent two-probe harness against unchanged candidate helper/source transformations.

## Frozen final-extra addendum

Independently replayed final-extra-bundle.mjs with Node24.15.0. Full JSON exactly matches final-extra-traces.json: 16/16 assertions pass, including the added next-batch ordering and later foreign-owner independence checks. Original first-extra14/14 evidence remains unchanged. This adds assertions, not algorithm changes; the scope and acceptance limits above remain. Replay output saved as /private/tmp/link-responsibility-independent/final-extra-replay.json.
