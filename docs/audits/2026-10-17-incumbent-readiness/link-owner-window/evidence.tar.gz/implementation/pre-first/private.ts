// Private scalar research. Window evidence is not general causality.
export const stamp = Symbol('research revision');
type Outcome='confirmed'|'rolled-back'|'abandoned';
type Source={read():{pending:readonly {transactionId:number}[]}};
type Fact={readonly revision:number;readonly clean:boolean;readonly blockers:readonly number[];readonly unknown:boolean};
type Meta=Record<PropertyKey,unknown>;
const sources=new Map<number,{source:Source;token:object}>();
const outcomes=new Map<number,Map<number,Outcome>>();
const listeners=new Map<number,Set<()=>void>>();
const queued=new Set<number>();
const latest=new Map<string,Fact>();
let serial=0;let ingress:{owner:number;position:number;consumed:boolean}|undefined;
export const receipts:unknown[]=[];export let enabled=true;
export function mode(v:boolean):void{enabled=v;}
export function register(owner:number,source:Source,token:object):void{sources.set(owner,{source,token});}
export function transition(owner:number|undefined,fact:{kind:string;transactionId:number}):void{
 if(owner===undefined)return;
 receipts.push({event:'lifecycle',owner,...fact});
 if(!['confirmed','rolled-back','abandoned'].includes(fact.kind))return;
 let map=outcomes.get(owner);if(!map)outcomes.set(owner,map=new Map());
 const old=map.get(fact.transactionId);if(old&&old!==fact.kind)throw Error('terminal outcome reversed');
 map.set(fact.transactionId,fact.kind as Outcome);
 if(!queued.has(owner)){queued.add(owner);queueMicrotask(()=>{queued.delete(owner);for(const cb of [...(listeners.get(owner)??[])])cb();});}
}
export function onEligibility(owner:number,cb:()=>void):()=>void{let set=listeners.get(owner);if(!set)listeners.set(owner,set=new Set());set.add(cb);return()=>{set.delete(cb);if(!set.size)listeners.delete(owner);};}
export function acquire(owner:number,position:number,work:()=>void):void{const prev=ingress;ingress={owner,position,consumed:false};try{work();}finally{ingress=prev;}}
export function annotate(meta:Meta|undefined,owner:number|undefined,positions:number[]|undefined,authored:boolean):Meta{
 const key=owner!==undefined&&positions?.[0]!==undefined?`${owner}:${positions[0]}`:undefined;
 // Delete first so a supported capture failure cannot leave an older clean ticket.
 if(key)latest.delete(key);
 const clean=!!ingress&&!ingress.consumed&&owner===ingress.owner&&positions?.[0]===ingress.position;
 if(clean&&ingress)ingress.consumed=true;
 const entry=owner===undefined?undefined:sources.get(owner);
 const blockers=Object.freeze(entry?[...entry.source.read().pending.map(p=>p.transactionId)]:[]);
 const attributed=meta?.transactionId;
 const attributionValid=attributed===undefined || (typeof attributed==='number'&&!!entry&&meta?.transactionOwner===entry.token&&blockers.includes(attributed));
 const unknown=!clean&&(!authored||meta?.origin!==undefined||!entry||!attributionValid);
 const fact:Fact=Object.freeze({revision:++serial,clean,blockers,unknown});
 if(key)latest.set(key,fact);receipts.push({event:'revision',owner,position:positions?.[0],...fact,origin:meta?.origin,participation:meta?.participation,attributed});
 return {...meta,[stamp]:fact};
}
export function evidence(meta:unknown):Fact|undefined{return(meta as Meta|undefined)?.[stamp] as Fact|undefined;}
export function allowed(fact:Fact|undefined,owner:number,position:number):boolean{return !enabled||!!fact&&latest.get(`${owner}:${position}`)===fact&&(fact.clean||!fact.unknown&&fact.blockers.every(id=>outcomes.get(owner)?.get(id)==='confirmed'));}
type Request={claimant:unknown;key:object;run:()=>void};
export function admit(original:(r:Request)=>void,fact:Fact|undefined,owner:number,position:number,r:Request):boolean{if(!enabled){original(r);return true;}if(allowed(fact,owner,position)){r.run();return true;}return false;}
export function dispose(_a:object,_b:object):void{}
export function heldCount():number{return 0;}
export function diagnostics(){return{sources:sources.size,outcomeTrees:outcomes.size,latest:latest.size,listeners:listeners.size};}
