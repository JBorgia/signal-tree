import {signalTree,entityMap,transactions,link} from '@case/index';
import {withWriteContext} from '@case/lib/write-context';
import {EntityValueStore} from '@case/lib/physical/entity-value-store';
import {getPathNotifier} from '@case/lib/path-notifier';
const tick=async()=>{getPathNotifier().flushSync();for(let i=0;i<40;i++)await Promise.resolve();};
const rowsOut=[];
for(const operation of ['derive-change','derive-identity','replace-same','replace-then-identity','partial'] as const){
 const tree=signalTree({rows:entityMap<{id:string;x:number;y:number},string>()},{enhancers:[transactions()]});
 tree.$.rows.addOne({id:'r',x:0,y:0});await tick();const row=tree.$.rows.byIdOrFail('r');
 const sent:unknown[]=[];const c=link(tree.$.rows,{set:value=>{sent.push(structuredClone(value));}});
 const prepared:unknown[]=[];const notifications:unknown[]=[];let recording=false;
 const original=EntityValueStore.prototype.prepareValueTransition;
 EntityValueStore.prototype.prepareValueTransition=function(...args){const t=original.apply(this,args);if(recording)prepared.push(structuredClone({fields:args[2]??(args[2]===null?null:'unspecified'),...t}));return t;};
 const off=getPathNotifier().subscribe('**',(value,prev,path,_owner,_origin,_subject,_position,meta,_decl,_ownerId,fields)=>{if(recording&&path==='rows.r')notifications.push(structuredClone({value,prev,participation:meta?.participation,fields:fields??(fields===null?null:'unspecified')}));});
 try{
  withWriteContext({participation:'inspection'},()=>row.x(99));await tick();recording=true;
  const pending=tree.transact(()=>{
   if(operation==='derive-change')row(current=>({...current,y:2}));
   if(operation==='derive-identity')row(current=>current);
   if(operation==='replace-same')row(row());
   if(operation==='replace-then-identity'){row(row());row(current=>current);}
   if(operation==='partial')tree.$.rows.updateOne('r',{y:2});
  });
  await tick();const inspection=pending.inspect();const heldSent=structuredClone(sent);pending.confirm();await tick();await c.settled();
  rowsOut.push({operation,prepared,notifications,inspection,heldSent,sent,physical:row()});
 } finally{recording=false;off();EntityValueStore.prototype.prepareValueTransition=original;c.dispose();tree.destroy();}
}
console.log(JSON.stringify(rowsOut,null,2));
