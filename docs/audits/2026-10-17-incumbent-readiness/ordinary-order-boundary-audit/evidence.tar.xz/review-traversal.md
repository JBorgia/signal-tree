# Independent repeated traversal premise review

Read-only final-corrected native source October24; hashes in review-traversal-source.sha256. No worker verdict read, no runtime edits or measurements. Existing frozen raw counts remain six shared snapshots6N for existing-prefix P=O=N; source inspection explains which can be duplicates.

## Physical stage

entity-mutation-frame.ts193 snapshots physical base before moved prefix. Lines194–200 mutate private stage, then201 snapshots stage to supply ordinaryOrder. Lines203–208 can additionally apply finalOrder. Lines210–213 snapshot stage again for physical after capture.

For actual existing-key prepend path, finalFront is set and finalOrder is absent. No stage mutation occurs between201 and212, no user callback/getter/framework publication runs there, and snapshot returns frozen array of primitive lifetime IDs. Thus these two exact same-domain/same-stage-revision physical-after snapshots are duplicate. Reusing the201 prepared immutable sequence for orderEndpoints.after is semantically supported for this path. Any general reuse must invalidate if finalOrder changes stage; cannot reuse unconditionally across arbitrary frame combinations. This can be shared at common frame preparation, not a consumer-specific neighbor fix.

Physical base-before is distinct from physical after and necessary endpoint evidence for current delta contract; no claim it can be removed merely because only one row moved. Source's whole-order delta design is a separate potential optimization question.

## Ordinary stage

entity-signal.ts863–864 snapshots ordinary before, then processes changes through ordinary presence/key/displacement operations. Lines1046–1050 derive admitted domain and call orderDomain; EntityPlacementStage.orderDomain82 snapshots current staged ordinary order. Source1054 snapshots final ordinary after.

For existing-row overwrite prepend with no membership/key changes, staged ordinary order remains unchanged while values are prepared. Therefore before and orderDomain-current are the same **for that verified footprint**, while ordinary after is different. In generic compound setAll/add/remove/key displacement, intermediate staged order can differ; blindly reusing before is unsafe. A stage revision/cache or explicitly available current staged sequence could avoid repeated same-revision traversals while invalidating after any adjacency edit. That is a private pure preparation optimization hypothesis, not implemented/qualified here.

orderDomain computes a final current.map sequence and immediately passes it to order. Source then re-traverses after to obtain the same final sequence. Returning/reusing this already-prepared immutable final sequence could avoid that traversal independent of whether before changed, provided order validates/installs exactly that sequence and no subsequent mutation precedes capture. It does not remove the necessary O(N) order application updates under current full-domain representation.

No O/P sequence sharing is justified by equal sizes or matching keys: inspection divergence makes them genuinely different domains. Keep distinct endpoint/frontier evidence. No sharing across publication, callbacks, transforms or reentry; all proposed reuse above stays private synchronous preparation with revision-validity constraints.

## Comparator attribution

Preserved predecessor addManyInOrder snapshots StructuralStore before/after around prepend final movement; measured2N entries existing-key. Those represent different endpoints and are not same-revision duplicate snapshots. Sixth/tenth move to placement-stage representation adds explicit ordinary capture and some redundant traversals. Thus sixN versus twoN is not proof CPU triples, and all six cannot be dismissed as necessary distinct semantics either.

## Bounded conclusion

One exact duplicate physical-after traversal is source-proved for existing-prefix finalFront/no-finalOrder. Ordinary current-before reuse is footprint-dependent; ordinary final sequence reuse is plausible from already-prepared orderDomain output. These are reviewable allocation/traversal reductions within existing preparation, not authorization to alter order semantics or a performance acceptance claim. Retain raw counters and first source; rerun unchanged semantic controls and deterministic counters only if implementing a reduction.
