# Independent inspection chronology handoff review

Scope: source/preserved-log review of the authorized occupancy successor; no runtime edits and no fresh test execution. Candidate is an isolated directory, not a Git checkout. Read `docs/review-contract.md`, contributor contracts and independent review protocol. Source read identity: transactions.ts SHA256 afe478617d075b048a96ed82b5b9a84fa76b2b989a58bd11afdef0681a8afdb0; entity-signal.ts 0209436bdfac69ff02ead1affa6db2fcb82e5af0d3d07e72a962ba583de8c42b. Implementer may be editing concurrently; line references describe inspected source, not a frozen release identity.

## Established failure and contract

Preserved `capture-field-rebind-first.log` reports ordinary displacement/rebind losing the explicit 7->99 field reversal. `capture-field-rebind-after.log` reports the unchanged test failing earlier: `inspect()` says an authored contribution has no mutation chronology. These are existing run results, not executions by this reviewer.

`transactions.ts:1991-2035` requires a footprint for every net contribution and uses its sequence to classify subsequent foreign writes. `path-notifier-enqueue.spec.ts` asserts that a later ordinary overwrite makes inspection `superseded`, and a hostile chronology capture makes inspection unavailable rather than falsely confident. The comment at transactions.ts:1365 says: “Inspection owns local mutation chronology, not conservative rollback evidence.” Retain that separation.

The cause is concrete: `enqueueEffect` at 1761-1791 derives field differences when an ordinary add joins a prior removal. The terminal preparation uses the transaction bucket's prior occupancy. The enqueue observer at 3329-3344 creates a fresh bucket, so cannot reconstruct that derived field. Replaying notification payloads harder cannot recover missing interval context safely.

## Alternatives

A private value-free footprint handoff is feasible only if it also preserves the installation chronology of that exact operation. Assigning a new sequence at eventual enqueue is insufficient in the presence of pre-enqueue reentry. `EntityMutationFrame.commit` installs responsibility at 275 then invokes committed observers; `publishCommittedEntity` executes listeners synchronously. Native signal synchronization/publication also precedes some path notifications. A later write can therefore occur before the outer enqueue. A metadata-only solution must carry a reserved sequence/operation identity, ensure all operation entries share the intended sequence, and avoid overwriting a newer footprint with a delayed older entry. It must not attach the mutable transaction bucket or value-bearing effects to metadata.

B can use the existing terminal plan to install value-free chronology together with responsibility, before committed observers. No second authority or public API is necessary: it extends the existing inspection evidence store at an earlier, reliable boundary. Reserve the sequence after effect composition, footprint construction and any other potentially reentrant preparation. Failed preparation may consume a sequence number; gaps do not change comparisons. Nothing may install the footprint if installation is rejected.

The inspected frame route has a revision guard after responsibility preparation (`entity-signal.ts:945`) and an internal-only `prepareCommitInstructions()` before physical installation. The single-value route likewise checks revision before installing physical/ordinary state and terminal records (`1596-1601`). Source inspection reveals no user callback between these checks and record installation. This is feasibility evidence, not a fault/reentry test pass.

B is the narrower common mechanism **provided** these details hold:

- Install footprints only for this operation's actually authored/derived changes. Do not timestamp every accumulated effect in `scratch.effects`: that would falsely move older field writes forward when an unrelated key operation occurs.
- A field adopted through the current ordinary rebind is authored at that rebind. Do not retroactively assign the original removal's timestamp. Separately preserve a genuine earlier explicit field write's existing chronology if the current operation did not author it.
- The ordinary enqueue observer must not subsequently retimestamp the same prepared footprint. Either skip exactly the already-recorded footprint through private operation identity or limit terminal additions to derived footprints that the fresh probe demonstrably cannot produce. The latter requires coverage against duplicate/overlapping output; it is not safe merely because today's minimal example lacks overlap.
- Latest footprint per writer/location must remain latest by reserved sequence, not whichever delayed delivery happens last. A reserved older operation must never replace a later footprint.
- If a writer map does not exist, prepare its creation and entry installation without replacing a map populated by a reentrant later operation. In the inspected commit window no callbacks occur; reserve/attach after reentrant preparation. Do not clone and reinstall an entire map prefix.
- Keep the existing enqueue path for foreign/realized writes and nonprepared sources. Prepared-own chronology alone cannot classify later foreign writes.
- Footprints contain identifiers, address/field segments and primitive occupancy keys only; explicitly remove before/after/value payloads. Existing pending-closure, confirmation, rejection and tree-destruction cleanup remains responsible for retirement.

## Cheapest falsifiers (requested, not run here)

1. Unchanged root composition test: inspect succeeds, rollback restores 7, next transaction restores 7.
2. Rebind-derived field, followed by a foreign ordinary or realized field replacement: inspect reports superseded; older reserved evidence cannot overwrite it.
3. Pre-enqueue synchronous reentry through a committed observer: outer install -> foreign same-field write -> outer enqueue; inspect must retain authored order. This is a source-derived falsifier sequence, not a reproduced public failure in this review.
4. Existing field write, then unrelated rekey/rebind: do not move that field's chronology later unless this operation actually adopts a changed ordinary value.
5. Fault during preparation after sequence reservation: no installed responsibility/chronology, no payload retention; subsequent successful write remains inspectable.
6. Multiple rows in one frame and several notifier entries: coherent footprint coverage with no later entries retimestamping the operation. Cross-field writes and real same-field ABA distinguish observation from net authority.
7. Existing path-notifier enqueue chronology and hostile-capture tests unchanged, plus confirmation/rejection/destruction cleanup counts.

## Disposition

No blocker demonstrated to B under these constraints. A can also be made correct but plain footprints consumed at enqueue do not themselves establish authored order. Neither alternative earns correctness from size of the handoff. Prefer validating the paired terminal-record route because it already precedes the observable reentry boundary and needs no payload-bearing metadata. This recommendation is bounded inspection bookkeeping, not approval of occupancy successor integration or a claim that either implementation passed tests.
