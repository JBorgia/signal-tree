import {describe,expect,it} from 'vitest';
import {signalTree,entityMap,transactions} from '../index';
import {withWriteContext} from './write-context';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
const make=()=>signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
const inspection=(work:()=>void)=>withWriteContext({participation:'inspection'},work);
describe('occupancy successor composition contracts',()=>{
 it('preserves a nested field contribution when outer key occupancy returns to its start',async()=>{
  const t=make(),r=t.$.rows;try{
   r.setAll([{id:'a',n:7},{id:'b',n:8}]);await tick();const old=r.byIdOrFail('a');
   let inner:ReturnType<typeof t.transact>|undefined;
   const outer=t.transact(()=>{r.changeId('a','c');inner=t.transact(()=>old.n(9));r.changeId('c','a');});
   expect(old.n()).toBe(9);expect(r.byIdOrFail('a')).toBe(old);
   outer.rollback();expect(old.n()).toBe(9);expect(r.byIdOrFail('a')).toBe(old);
   expect(()=>inner!.inspect()).not.toThrow();inner!.rollback();expect(old.n()).toBe(7);
   expect(r.ids()).toEqual(['a','b']);expect(()=>outer.rollback()).not.toThrow();
  }finally{t.destroy();}
 });
 it('preserves the admitted same-lifetime displacement and rebind sequence',async()=>{
  const t=make(),r=t.$.rows;try{
   r.setAll([{id:'a',n:7},{id:'b',n:8}]);await tick();const a=r.byIdOrFail('a'),b=r.byIdOrFail('b');
   inspection(()=>r.changeId('a','c'));
   const p=t.transact(()=>{r.changeId('b','a');r.changeId('c','d');});
   expect(r.byIdOrFail('d')).toBe(a);expect(r.byIdOrFail('a')).toBe(b);
   expect(()=>p.inspect()).not.toThrow();p.rollback();expect(r.ids()).toEqual(['a','b']);
   expect(r.byIdOrFail('a')).toBe(a);expect(r.byIdOrFail('b')).toBe(b);
   const q=t.transact(()=>a.n(11));q.rollback();expect(a.n()).toBe(7);
  }finally{t.destroy();}
 });
 it('keeps distinct lifetimes distinct through repeated business-key reuse',async()=>{
  const t=make(),r=t.$.rows;try{
   r.addOne({id:'a',n:7});await tick();const old=r.byIdOrFail('a');let middle:typeof old|undefined;
   const p=t.transact(()=>{r.removeOne('a');r.addOne({id:'a',n:8});middle=r.byIdOrFail('a');r.removeOne('a');r.addOne({id:'a',n:9});});
   const fresh=r.byIdOrFail('a');expect(fresh).not.toBe(old);expect(fresh).not.toBe(middle);
   p.rollback();expect(r.byIdOrFail('a')).toBe(old);expect(old.n()).toBe(7);
   expect(middle!()).toBeUndefined();expect(fresh()).toBeUndefined();
  }finally{t.destroy();}
 });
});
