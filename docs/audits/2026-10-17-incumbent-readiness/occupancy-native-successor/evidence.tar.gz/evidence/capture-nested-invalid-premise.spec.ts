import { describe, expect, it } from 'vitest';
import { signalTree, entityMap, transactions } from '../../lib/index';
describe('occupancy capture with intervening nested authors', () => {
  it('does not require each owner to author an uninterrupted key sequence', () => {
    const tree = signalTree({ rows: entityMap<{id:string;n:number},string>({selectId:r=>r.id}) }, {enhancers:[transactions()]});
    try {
      const rows = tree.$.rows;
      rows.addOne({id:'a',n:7});
      let child: ReturnType<typeof tree.transact> | undefined;
      const outer = tree.transact(() => {
        rows.changeId('a','b');
        child = tree.transact(() => rows.changeId('b','c'));
        rows.changeId('c','d');
      });
      expect(rows.ids()).toEqual(['d']);
      expect(outer.inspect().changes.length).toBeGreaterThan(0);
      expect(child!.inspect().changes.length).toBeGreaterThan(0);
    } finally {tree.destroy();}
  });
});
