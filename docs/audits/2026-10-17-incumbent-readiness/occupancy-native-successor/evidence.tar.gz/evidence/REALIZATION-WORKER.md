# Native realization worker (2026-10-23)

## Changes

- `ordinary-realization.ts`: sparse ordered ordinary-to-physical key join. Original inverse effects remain separate; active inverse-add becomes physical transfer with distinct placement evidence. Missing physical removal is omitted only from physical list, not original ordinary list. Raw physical add validation remains strict.
- `tree-realization-adapter.ts`: private port preparation before validation, shared ordinary disposition installed after heterogeneous physical work; active relocation seeds indexed physical payload and carries placement into prepared rekey.
- `target-transition.ts`: physical state derives from lowered effects, placement uses original inverse addition facts.
- `transactions.ts`: rollback target derives physical plan before target validation; retains original ordinary inverses; preparation revision rechecked before installing any target. Sparse normalized inverse goes through explicit private preparation. Capture folding is another worker's changes.
- `prepare-entity-target.ts`: original ordinary effects prepare via shared collection disposition; physical target values remain separate; ordinary plan installs after physical target. Publication carries original ordinary changes.
- `entity-signal.ts`: only prepared-rekey placement and physical explicit-field realization additions owned here. Occupancy worker owns ordinary preparation and disposition methods.
- `entity-mutation-frame.ts`, `structural-store.ts`: active transfer can carry separate placement without remove/add lifecycle callbacks.
- `occupancy-successor-realization.spec.ts`: approved P99/O7 relocation then adopt99/reject7; multi-neighbor placement; preparation fault and reentry retry controls.

## Preserved first results

`realization-first.log`: 1/2 passed. Relocation preserved P99, subsequent adoption rollback lost lifetime (n undefined). Cause: new ordinary helper used original structuralContext.kind as inverse operation. Context intentionally retains original operation; actual inverse is ReversalEffect.structural/before/after. Occupancy worker corrected this shared interpretation; unchanged test 2/2 in realization-after-orientation.log.

`realization-preparation-first.log`: 3/4 passed. Target preparation reentry was not rejected because only structural frontier was checked, not physical prepared revision. Added shared target revision check (no partial install). Unchanged controls 4/4 in realization-preparation-after.log.

`realization-typecheck-first.log`: existing 11 TS4111 diagnostics in research semantics-authority/composition fixtures; no added source diagnostic in this run. Not a clean typecheck.

`realization-final.log` is the rerun after preserving original ordinary effects when a lowered point route falls back to target. Test result is read from that log, not inferred from previous run.

## Limits for independent review

These four native controls mostly exercise full-target handoff selected by structural order metadata. Sparse transfer/placement implementation exists, but not yet directly qualified across all mixed cases. Do not infer all original failures or composition matrix pass from this worker's controls.

Original ordinary array is linked to lowered physical array through private WeakMap evidence; filters at both current heterogeneous callers explicitly pass original ordinary effects. Any additional consumer filtering/rebuilding that array requires review. Physical structural operations and ordinary authority remain distinct.

Potential review target: heterogeneous publication currently attaches all original ordinary changes for a subject to each physical structural notification for that subject. Repeated operations on the same lifetime could publish duplicate ordinary descriptor groups; exact full-target route emits per lifetime once. Need unchanged composition controls before accepting this.

No broader suites, artifacts, GC or cost measurements. No integration disposition implied.

## Independent sparse placement finding and general correction

Independent unchanged `review/sparse-two.ts` showed two lowered active additions bypassed `orderRestoresForPlacement`: validation accepted, final physical order was B,C,A rather than A,B,C. The corresponding public full-target control passed. Original source/bundle/log remain unchanged.

Authorized correction groups every placement-bearing instruction (revival or active transfer) into one existing dependency resolver. `orderPhysicalPlacements` is used by validation and heterogeneous preparation; one placement plan sequence installs them, separate from plain rekeys. No writer-specific rule, new ordering semantics, lifecycle events or whole-target fallback was introduced.

Unchanged witness rebuilt separately to `review/sparse-two-corrected.mjs`: expected A,B,C with displays99/88, log `evidence/sparse-two-corrected.log`. `realization-mixed-placement.log`: 5/5 controls, including mixed inactive revival + active transfer, no synthetic transfer add/remove callback, callback snapshot complete, later ordinary adoption/rejection restores8. This does not prove all original gate controls.

Source-only review question remains whether a lowered physical-empty inverse reaches its ordinary disposition on the private adapter path. Full-target path explicitly keeps original inverse evidence; no public counterexample has been executed by this worker for the physical-empty case.
