# Independent follow-up: realized occupancy interference

October23, 2026. Requested after physical review; no runtime changes, no other reviewer verdict read. Reviewed source and first/diagnostic logs, then independently bundled and executed the candidate sequence and replayed the preserved baseline bundle. Identities in `review/capture-gap-identities.json`; exact candidate files in `review/capture-gap-source/`.

## Observed

Ordinary A@a7/B@b8. Inspection moves A to c. One transaction:

1. rekeys B b→a, displacing ordinary A;
2. realized/system field write A.n123;
3. authored A.n99;
4. authored rekey A c→d (then planned d→e).

Candidate fails construction at step4. Outer SignalTreeRollbackError has `recovery.callbackError` equal to Error('Discontinuous ordinary occupancy capture'). Baseline preserved bundle constructs, inspect succeeds and confirm succeeds. New independent outputs: `review/capture-gap.log`, `review/capture-gap-baseline-replay.log`.

## Premise

No allocation fault, malformed effect injection or monkeypatch. It uses the established internal inspection/realized write-context harness around native public row operations. `queued-inspection-review.spec.ts` already asserts chronology for realized writes inside authored transaction callbacks. This is a supported internal-boundary control, not yet a reproduced browser/Link/restoration public entrypoint. The source explicitly excludes realized/system work from transaction ownership; labeling it ordinary transaction work to make composition contiguous would violate that distinction.

## Causal divergence

`composeOccupancy` requires every later selected effect.before to equal previous selected afterKey. After the transaction displaces A, its bucket records A absent. The realized field write makes A exist ordinarily at c but correctly is not the transaction's authored occupancy. The later authored rekey enters preparation with before c. The bucket's selected endpoint remains absent, so the new continuity assertion throws before that rekey installs.

A transaction's own selected writes are not necessarily a contiguous current-state history. The endpoint composer lacks a boundary for other participating writes between them. This is not evidence that the field123 write should belong to the pending transaction or that its dependency may be erased. Catching the exception/resetting an endpoint would risk losing prior responsibility; merging the realized bind as owned would risk claiming independent truth.

## Disposition

The current selected-endpoint representation is incomplete for this existing chronology boundary. A repair would need explicit interference/span responsibility semantics across selected intervals, retaining what earlier authored work still owns and what independent admission changes. This review does not establish a sufficient replacement representation. Independent review and owner recurrence policy should classify whether that is further architectural work before implementation; no caller-specific patch was attempted.

The failed abort's later-confirmed-dependency is secondary to the unexpected construction exception, not proof that recovery refusal itself is wrong. I did not assert arbitrary rollback success in the presence of surviving realized dependency. The decisive unchanged expected capability is successful construction, accurate inspect and confirmation.

## Replay

From candidate directory:

```sh
node node_modules/esbuild/bin/esbuild ../review/capture-gap.ts --bundle --platform=node --format=esm --outfile=../review/capture-gap.mjs
node ../review/capture-gap.mjs
node ../evidence/capture-realized-gap-baseline.cjs
```

Run frozen bundles directly for exact-source replay. No broad suite, heap, framework or browser reproductions performed. First Nx assertions/logs remain unchanged.
