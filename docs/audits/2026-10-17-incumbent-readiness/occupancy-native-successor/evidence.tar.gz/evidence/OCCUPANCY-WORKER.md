# Ordinary occupancy admission / realization worker

Scope: isolated native successor only. Edited entity-signal.ts shared prepareOrdinaryTopology, added prepareOrdinaryRealization private handoff and per-step value transition fanout; physical topology storage primitive unchanged.

## Mechanism

Preparation reads sparse installed ordinary exceptions or native fallback. Explicit false shadows fallback. A per-attempt lifetime/key overlay supplies every source and destination lookup; a staged vacancy shadows installed index/native occupancy. Binding records displacement before assigning the lifetime; unbinding targets ordinary lifetime presence, not physical key occupant. No unrelated entity enumeration.

Indexes normalize only after complete physical frame installation. Membership agreement clears the topology exception; ordinary-present/physically-absent, ordinary-absent/physically-present and differently keyed states remain represented. Values remain the native value store's separate ordinary baseline.

Original O inverse effects feed prepareOrdinaryRealization; operation and key come from ReversalEffect.structural/before/after, not original structuralContext.kind. Context supplies retained value/placement. O values and topology are prepared independently of physical target values. The installer consumes prepared transitions without cloning/equality/user callbacks; no ordinary authority is inferred from physical rows. Active transfer preserves inspected payload unless explicit reversal edits supply fields. Original effects remain available to capture/inspection/publication.

The public updateMany API admits duplicate keys. Its frame has repeated value steps for a lifetime, and its notifications repeat that lifetime. A subject-only transition map repeated the aggregate list. Frame results now expose valueResultsByStep, and index-aligned updateMany publication selects the corresponding prepared step. UpsertMany and setAll deduplicate keys before frame creation. No global consumption marker or notification protocol change.

## Evidence

- occupancy-first.log: unsupported --runInBand command; no tests executed.
- occupancy-rekey-first.log: original rekey-vacancy regression unchanged, 1/1 pass.
- occupancy-topology.log: unchanged C1–C3, 3/3 pass.
- occupancy-steps-first.log and corrected-harness.log: initial diagnostic harness had wrong notifier parameter position and did not flush; [] is harness evidence, not runtime failure.
- occupancy-steps-delivery.log: valid diagnostic demonstrates paired 3 facts, rich 5 facts (A duplicated four times instead of twice). Original initial probe saved occupancy-steps-before-correction.ts.
- occupancy-steps-after-step.log: corrected runtime yields per-path coalesced A,A,B instead of authored cross-path A,B,A. The new probe's cross-path ordering expectation was stronger than the existing notifier contract, so it was corrected explicitly, preserving its original source/log. Final assertion compares full before/after facts in stable per-subject order, preserving count and per-subject chronology.
- occupancy-steps-final.log: corrected exact-once probe 1/1 pass with useful rollback assertion.
- First realization helper used structuralContext.kind as inverse operation; realization worker's first subsequent adoption failure caught it. Corrected to inverse effect direction. That worker owns first failure source/log and rerun.
- occupancy-types.log: 11 existing semantics fixture index-signature diagnostics plus one in-progress adapter context typo, none in this worker's changes. Later tsc log separate; no clean typecheck claimed.

All tests via NX_DAEMON=false corepack pnpm nx test kernel --testFile=<basename>. Node24.15.0, pinned pnpm10.17.0. Source was shared/actively edited by other workers during these focused runs; parent must freeze exact combined identity and re-run qualified gate. This report does not claim independent review, lifecycle collectibility, full gates, or integration acceptance.
