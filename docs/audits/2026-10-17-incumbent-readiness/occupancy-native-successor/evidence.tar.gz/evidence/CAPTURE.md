# Capture interval successor component (exploratory)

Owned files: transactions.ts fold/capture bookkeeping; occupancy-composition.ts;
occupancy-composition.spec.ts. Other workers may change the shared candidate;
these runs are exploratory, not final frozen qualification.

The helper stores original and final key occupancy independently from normalized
effects. A canceled endpoint remains in the interval map until drain, so later
operations cannot forget the interval baseline. Add/remove value and placement
contexts are retained explicitly; fields and explicit order remain their existing
separate channels. This adds no implicit value adoption to a key-only operation.

One helper is called by enqueueEffect for rich capture, paired scratch capture,
and journal refolding. Paired preparation copies only touched lifetime entries,
then installs the immutable new entries together with the prepared effect map.
Drain clears the interval map. No collection traversal or prior journal replay
was added to admission. No settlement authority or public export was added.

Preserved original extracted fold: 6 pass / 2 fail, capture-original-fold.log.
Command: node /private/tmp/occupancy-endpoint-feasibility/original/probes.mjs
These are original extracted tests, not native runtime regressions.

Nx helper first run: 8/8 pass, capture-helper-first.log.
Nx existing native controls: 3 files / 20 pass, capture-native-controls-first.log.
Commands (candidate cwd, NX_DAEMON=false):
  pnpm nx test kernel --testFile=packages/kernel/src/enhancers/transactions/occupancy-composition.spec.ts
  pnpm nx test kernel --testFile=packages/kernel/src/enhancers/transactions/rekey-occupancy-0.spec.ts --testFile=packages/kernel/src/enhancers/transactions/rekey-supersession-0.spec.ts --testFile=packages/kernel/src/lib/entity-semantic-composition-slice.spec.ts

Capture source snapshot: capture-first-source/. Original typecheck failed with
11 semantics fixture TS4111 diagnostics and stale absolute experimental imports
TS6059; see capture-typecheck-first.log. No success claim. Root normalized the
three stale imports afterward; source identity is different afterward.

An attempted nested-transaction exploratory test did not execute because its
import path was wrong (capture-nested-first.log; original spec retained). It is
also outside the current contract: direct nested transact is rejected by the
incumbent. Root preserves an actual nested-rejection control. Do not count this
attempt as either a native failure or a passing control; no nested API was added.

Remaining qualification: native corrected producers, physical realization,
useful rollback/inspection/publication, reentry, faults, refusal and final review.
The helper cannot infer field authorship from occupancy alone. Producer-supplied
set facts remain required when a value is actually authored.

## Explicit field rebind discriminator

Root's unchanged composition test4 reproduces remove(O A7), later necessary
existence adoption(add A99), later key rebind. Occupancy-only first successor:
3/4 native controls pass; rollback leaves99, expected7. Preserved
capture-field-rebind-first.log and capture-field-red-source/.

Authorized shared correction derives separate fields using existing captureEffects
from admitted ordinary removal/add images. Paired scratch lazily seeds touched
field effects from bucket.effects; no full map copy. Journal refold shares this
normalization. With this change unchanged native test fails earlier in inspect():
"authored contribution has no mutation chronology". Combined helper/native run:
11 pass / 1 fail, capture-field-rebind-after.log. Source retained separately in
capture-field-chronology-source/.

Cause: enqueue observation uses a fresh probe CaptureBucket per notification.
It cannot derive interval rebind fields because it has no earlier removal image.
The original operation notification contains structural addition, whereas the
interval normalizer now records scalar7→99. inspectPendingTurn correctly refuses
an effect absent from the observed chronology. No assertion or guard was weakened.
This is unresolved common capture/chronology work; no native acceptance claim.
Further changes paused pending root's scope/recurrence assessment. A stateful
inspection bucket retaining payload history would violate its explicit no-value-
snapshots contract; operation facts must be coherently supplied, not reconstructed
from displayed state or from whichever latest operation happens to be visible.

## Unselected chronology handoff draft

A minimal existing-TerminalRecordPlan draft paired value-free derived inspection
footprints with responsibility. The root hold arrived after its edit/test launch;
the addition was immediately removed from candidate, with exact draft saved as
capture-paired-chronology-draft.ts. The exploratory three-file run reported22/22
(capture-paired-chronology-first.log). That result does not select or qualify the
mechanism. Independent handoff review is pending; candidate remains at the
inspection-failing state. No producer interface or public API was changed.

## Selected handoff and independent-writer gap

Root selected the existing terminal-plan value-free companion after independent
handoff review. Implemented only operation-local derived fields, not every prior
scratch effect. Added latestRemoval context separately from original removal:
rebind field differences use the latest ordinary removal image so repeated
key-only operations do not re-author an earlier field change.

New controls plus unchanged composition/queued-inspection:16 pass/1 fail.
After-adoption external field + later key-only changes retains superseded status;
controlled failure after preparation installs no footprints and later transaction
inspection/rollback works. See capture-selected-chronology-first.log.

The remaining control exposes a real independent-writer gap:
O A@a7/B@b8; inspect A→c; own B→a (displaces ordinary A); realized external
A.n123 (adopts ordinary A@c); own A.n99; own c→d→e. The last own rekey fails
"Discontinuous ordinary occupancy capture": this owner's prior endpoint was
absent, but another writer restored occupancy before its next authored rekey.
Failed abort returns established rollback recovery rather than constructing the
otherwise supported transaction. Exact callback error trace is in
capture-selected-chronology-diagnostic.log. The test's original assertions are
restored unchanged; diagnostic print-only variant was temporary.

Frozen rejected slice2 comparator successfully constructs, inspects all current,
and confirms this sequence (capture-realized-gap-baseline.ts/cjs/log). Bundled
baseline SHA256:b190b34d71009945c31663d5617a6ed1f46f3ee5c19d4c4b3c15ad74725a1da5.
The native harness uses established internal realized/inspection contexts, not
browser end-to-end invocation or allocation fault injection. This is not the
invalid nested-transact premise. No continuity guard was weakened. Capture
component changes stopped pending root's recurrence disposition.
