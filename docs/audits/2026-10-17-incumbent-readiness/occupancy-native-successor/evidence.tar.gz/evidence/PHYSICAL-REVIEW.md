# Independent physical realization review — October 23, 2026

Reviewed readiness HEAD `8c8968f2e1d894464216e2c8256383600ddc5a1c`, candidate `/private/tmp/occupancy-native-successor/candidate`, against frozen `/private/tmp/semantic-transition-slice2/candidate`. No production edits. Candidate capture fold was being edited independently; review observations concern separately frozen physical files/bundles. Exact files and executable hashes: `review/physical-identities.json`; physical source snapshots: `review/physical-source/`.

Read review-contract, contributor-contracts, architecture review protocol and successor feasibility specification. Raw original rekey-vacancy and retention witness read unchanged. Their assertions were not edited. No other reviewer's verdict was supplied/read. Worker report was used for file identification, not accepted as evidence.

## Demonstrated gap: sparse transfers do not compose placement

`tree-realization-adapter.ts:1051` sends only structural adds to `orderRestoresForPlacement`. Lowering at `ordinary-realization.ts:39` converts inverse adds for already-active lifetimes to rekeys and retains placement evidence separately. Those transfers then execute in input order (`tree-realization-adapter.ts:1349`), after all restores; the placement dependency solver never sees them.

Executed `review/sparse-two.ts`: native ordinary initial [A,B,C]; inspection moves old A/B to aa/bb and displays [C,aa,bb], with physical values99/88. A coherent inverse placement unit asks old A at a before B and old B at b before C. Private native port prepares/validates successfully, applies and returns [b,c,a], rather than [a,b,c]. The first transfer puts A before B's *old* placement; moving B afterward leaves A behind. Output and assertion failure are preserved in `sparse-two.log`; bundle is frozen.

This is a direct private realization-port contract falsifier with manually supplied inverse facts, not proof that the public transaction route selects the failing sparse branch. Exact public-equivalent setup with fresh A/fresh B created in a transaction and rollback PASSES via full target: `public-two.ts`/`.log` gives [a,b,c], preserves physical99/88 and old lifetimes. Do not describe the private-port failure as a demonstrated public rollback regression.

The expected [a,b,c] follows the approved current-successor placement applied to a complete unit: B's successor C survives; A's successor is B in its restored placement. It is also corroborated by the public full-target control, not derived from arbitrary chronological replay.

## Bounded repair interpretation

This fits the authorized shared capture-and-realization scope. The existing helper is generic in subject-bearing effects; placement-bearing transfers and revivals must participate in a common owner/lifetime dependency plan. Sorting transfers separately from restores does not address mixed dependencies. A common final-unit placement preparation can keep existing successor semantics and indexed affected-lifetime work. This is a mechanism recommendation, not a verified patch. No public semantic/API change or second authority is indicated by this finding.

## Positive narrow controls

`review/sparse.ts`, executed directly through the native private adapter, has two cases. Single active relocation with separate placement preserves physical99/ordinary7; a subsequent explicit99 transaction rolls back7. Variant with explicit field inverse99→7 physically restores7 and subsequent adoption/rejection again returns7. Both preserve the held lifetime and expected [x,a,z]. No synthetic remove/add callback claim was asserted by these two controls.

The direct private test does not qualify capture admission, nested dependencies, public route selection or every production observer. The public-two test qualifies only its concrete transaction path with the established internal inspection harness, not browser/devtools transport.

## Source findings and not-run checks

- `StructuralStore.resolveSubjectRestorePlacement` calls `nodePrecedes`, a linked-node walk when both anchors exist. New `placeActiveSubject` inherits it. Unrelated-distance scaling was not measured here; do not call sparse settlement work qualified by these functional tests. Need fixed affected-unit/increasing unrelated-state work counts.
- Initial suspicion that missing anchors throw after transfer was not substantiated: absent anchors fall back; self-anchor/inactive-lifetime guards throw. No supported-input partial-install failure demonstrated by this review.
- Preparation fault/reentry, native observer coherence, callback absence, teardown and broader suites were not freshly run here. Existing worker results are not relabeled independent passes.
- Original rejected slice2 bundles were inspected but not redundantly rerun in this review. They remain frozen evidence; new sparse failure is separate.

## Replay

From candidate directory, Node24.15.0:

```sh
node node_modules/esbuild/bin/esbuild ../review/sparse.ts --bundle --platform=node --format=esm --outfile=../review/sparse.mjs
node ../review/sparse.mjs
node node_modules/esbuild/bin/esbuild ../review/sparse-two.ts --bundle --platform=node --format=esm --outfile=../review/sparse-two.mjs
node ../review/sparse-two.mjs
node node_modules/esbuild/bin/esbuild ../review/public-two.ts --bundle --platform=node --format=esm --outfile=../review/public-two.mjs
node ../review/public-two.mjs
```

For exact executed-source replay, run preserved bundles directly instead of rebuilding against later source. These are bounded standalone internal-port probes, not package suite claims; no bare Vitest was used.

Disposition: sparse physical composition is not qualified. The known single-transfer full-target success is insufficient; the common placement unit needs correction and unchanged sparse/mixed controls before recurrence clearance.

## Follow-up: common placement correction has a field-order regression

The implementer subsequently added `orderPhysicalPlacements`, invoked by validation and heterogeneous planning. It replaces placement-bearing slots in the effect array with dependency-sorted placement effects. The original sparse-two passes that draft, but a new direct-port falsifier fails:

- Native old A/B are inactive, C remains.
- Original authority/physical effect chronology is restore A (successor B), explicit A.n=17, restore B (successor C).
- Sorting only the placement slots produces restore B, field A, restore A.
- Validation returns structural-drift because A does not yet exist when the field inverse is checked.

`review/sparse-placement-field.ts` and its failed `.log`/bundle are preserved. The exact same source with the frozen pre-correction adapter passes [a,b,c] and A.n17. Comparator build script `review/build-pre-placement.cjs` overlays only the earlier adapter text through an esbuild onLoad hook; it does not edit runtime. Comparator `.mjs` and `-before.log` preserved. New adapter snapshot `review/placement-correction-tree-realization-adapter.ts`; final file hashes `review/final-review-identities.json`.

This is an independently executed regression at the private native adapter boundary. No public transaction producer selecting this exact sparse sequence was established. Unlike sparse-two's incorrect resulting order, the new result is atomic refusal before installation; physical rows remain [c]. It still rejects a previously accepted coherent effect unit, showing that shared placement ordering must not reorder authority/field chronology accidentally. No further repair attempted after root stopped the candidate.

Final disposition: candidate rejected in reviewed sparse scope; preserve both first failure and correction failure. Neither result invalidates slice1 or asserts that full-target public rollback is broken in these examples. No broader verification or acceptance inferred.
