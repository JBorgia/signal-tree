import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '../candidate/packages/kernel/src/index';
import {withWriteContext} from '../candidate/packages/kernel/src/lib/write-context';
import {getOwnedPositionIds,getOwnedSubjectIds} from '../candidate/packages/kernel/src/lib/internals/owned-mutation';
import {getTreeRealizationPort} from '../candidate/packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter';
const drain=async()=>{for(let i=0;i<60;i++)await Promise.resolve()};
for(const field of [false,true]){
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});const r=t.$.rows;
try{
r.setAll([{id:'x',n:1},{id:'a',n:7},{id:'z',n:2}]);await drain();
const old=r.byIdOrFail('a');const owner=getOwnedPositionIds(r)![0], subject=getOwnedSubjectIds(old.n)![0],x=getOwnedSubjectIds(r.byIdOrFail('x').n)![0],z=getOwnedSubjectIds(r.byIdOrFail('z').n)![0];
withWriteContext({participation:'inspection'},()=>{r.changeId('a','b');r.setAll([{id:'b',n:99},{id:'x',n:1},{id:'z',n:2}]);});
const port=getTreeRealizationPort(t)!;
const ordinary:any[]=[{owner,subjectId:subject,path:'rows.a',ownerPath:'rows',structural:'add',before:undefined,after:'a',structuralContext:{kind:'remove',subject,key:'a',value:{id:'a',n:7},beforeSubject:x,afterSubject:z}}];
if(field)ordinary.push({owner,subjectId:subject,path:'rows.a.n',ownerPath:'rows',subjectFieldSegments:['n'],before:99,after:7});
const effects=port.prepareOrdinaryEffects!(ordinary);const refused=port.validateEffects(effects);assert.equal(refused,undefined);
port.applyAtomically(effects); console.log(JSON.stringify({field,ids:r.ids(),value:old(),same:r.byIdOrFail('a')===old}));assert.deepEqual(r.ids(),['x','a','z']);assert.equal(old.n(),field?7:99);
const p=t.transact(()=>old.n(99));p.rollback(); console.log(JSON.stringify({field,postAdoptRollback:old()}));assert.equal(old.n(),7);
}catch(e){console.log(JSON.stringify({field,error:String(e),stack:(e as Error).stack,ids:r.ids(),rows:r.all()}));}finally{t.destroy();}}
