import {signalTree,entityMap,transactions} from '/private/tmp/occupancy-native-successor/candidate/packages/kernel/src/index';
import {withWriteContext} from '/private/tmp/occupancy-native-successor/candidate/packages/kernel/src/lib/write-context';
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});
const r=t.$.rows;
try {
 r.setAll([{id:'a',n:7},{id:'b',n:8}]);
 const a=r.byIdOrFail('a');
 withWriteContext({participation:'inspection'},()=>r.changeId('a','c'));
 const p=t.transact(()=>{
  r.changeId('b','a');
  withWriteContext({intent:'system',participation:'realized'},()=>a.n(123));
  a.n(99);r.changeId('c','d');r.changeId('d','e');
 });
 console.log(JSON.stringify({stage:'constructed',ids:r.ids(),n:a.n(),inspection:p.inspect()}));
 p.confirm(); console.log('confirmed');
} catch(e) {console.log('failure',e);console.log('callbackError', (e as any)?.recovery?.callbackError);process.exitCode=1;} finally {t.destroy();}
