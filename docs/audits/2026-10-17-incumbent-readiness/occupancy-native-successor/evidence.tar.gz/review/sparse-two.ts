import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '../candidate/packages/kernel/src/index';
import {withWriteContext} from '../candidate/packages/kernel/src/lib/write-context';
import {getOwnedPositionIds,getOwnedSubjectIds} from '../candidate/packages/kernel/src/lib/internals/owned-mutation';
import {getTreeRealizationPort} from '../candidate/packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter';
const t=signalTree({rows:entityMap<{id:string;n:number},string>()},{enhancers:[transactions()]});const r=t.$.rows;
try{
r.setAll([{id:'a',n:7},{id:'b',n:8},{id:'c',n:9}]);for(let i=0;i<60;i++)await Promise.resolve();
const a=r.byIdOrFail('a'),b=r.byIdOrFail('b'),c=r.byIdOrFail('c');const owner=getOwnedPositionIds(r)![0],as=getOwnedSubjectIds(a.n)![0],bs=getOwnedSubjectIds(b.n)![0],cs=getOwnedSubjectIds(c.n)![0];
withWriteContext({participation:'inspection'},()=>{r.changeId('a','aa');r.changeId('b','bb');r.setAll([{id:'c',n:9},{id:'aa',n:99},{id:'bb',n:88}]);});
const port=getTreeRealizationPort(t)!;
const ordinary:any[]=[{owner,subjectId:as,path:'rows.a',ownerPath:'rows',structural:'add',before:undefined,after:'a',structuralContext:{kind:'remove',subject:as,key:'a',value:{id:'a',n:7},afterSubject:bs}},{owner,subjectId:bs,path:'rows.b',ownerPath:'rows',structural:'add',before:undefined,after:'b',structuralContext:{kind:'remove',subject:bs,key:'b',value:{id:'b',n:8},beforeSubject:as,afterSubject:cs}}];
const effects=port.prepareOrdinaryEffects!(ordinary);const refused=port.validateEffects(effects);assert.equal(refused,undefined);port.applyAtomically(effects);
console.log(JSON.stringify({ids:r.ids(),rows:r.all()}));assert.deepEqual(r.ids(),['a','b','c']);
}catch(e){console.log(JSON.stringify({error:String(e),stack:(e as Error).stack,ids:r.ids(),rows:r.all()}));process.exitCode=1;}finally{t.destroy();}
