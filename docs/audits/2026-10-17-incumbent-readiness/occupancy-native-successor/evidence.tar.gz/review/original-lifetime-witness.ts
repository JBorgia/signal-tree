import assert from 'node:assert/strict';
import {signalTree,entityMap,transactions} from '/private/tmp/occupancy-native-successor/candidate/packages/kernel/src/index';
import {withWriteContext} from '/private/tmp/occupancy-native-successor/candidate/packages/kernel/src/lib/write-context';
const tick=async()=>{for(let i=0;i<100;i++)await Promise.resolve()};
const inspect=(f:()=>void)=>withWriteContext({participation:'inspection'},f);
const tests:Record<string,(t:any,r:any)=>Promise<void>>={
 'confirmed-C2-new-lifetime-survives-next-rollback':async(t,r)=>{const old=r.byIdOrFail('a');inspect(()=>r.removeOne('a'));const p=t.transact(()=>r.addOne({id:'a',n:99}));const fresh=r.byIdOrFail('a');p.confirm();const q=t.transact(()=>fresh.n(100));q.rollback();assert.equal(fresh.n(),99);assert.equal(old(),undefined);assert.equal(r.byIdOrFail('a'),fresh)},
 'multiple-inspection-lifetimes-key-reuse':async(t,r)=>{const old=r.byIdOrFail('a');let inspected:any;inspect(()=>{r.removeOne('a');r.addOne({id:'a',n:88});inspected=r.byIdOrFail('a');r.removeOne('a')});const p=t.transact(()=>r.addOne({id:'a',n:99}));const fresh=r.byIdOrFail('a');p.rollback();assert.equal(r.byIdOrFail('a'),old);assert.equal(old.n(),7);assert.equal(fresh(),undefined);assert.equal(inspected(),undefined)},
 'field-adoption-of-replacement-inspection-lifetime':async(t,r)=>{const old=r.byIdOrFail('a');inspect(()=>{r.removeOne('a');r.addOne({id:'a',n:88})});const fresh=r.byIdOrFail('a');const p=t.transact(()=>fresh.n(99));p.rollback();assert.equal(r.byIdOrFail('a'),old);assert.equal(old.n(),7);assert.equal(fresh(),undefined)},
 'rekeyed-inspection-occupant-key-reuse':async(t,r)=>{const old=r.byIdOrFail('a');inspect(()=>r.changeId('a','b'));const p=t.transact(()=>r.addOne({id:'a',n:99}));const fresh=r.byIdOrFail('a');p.rollback();assert.deepEqual(r.ids(),['a']);assert.equal(r.byIdOrFail('a'),old);assert.equal(old.n(),7);assert.equal(fresh(),undefined)},
};
for(const [name,work] of Object.entries(tests)){const t=signalTree({rows:entityMap<{id:string;n:number},string>({selectId:r=>r.id})},{enhancers:[transactions()]});const r=t.$.rows;r.addOne({id:'a',n:7});await tick();try{await work(t,r);console.log(JSON.stringify({name,pass:true}))}catch(e){console.log(JSON.stringify({name,pass:false,error:String(e),stack:(e as Error).stack,ids:r.ids(),rows:r.all()}))}finally{t.destroy()}}
