import {signalTree} from '/private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/signal-tree';
const tree=signalTree({fresh:0,trigger:[{x:0}]});
console.log('primed',JSON.stringify(tree.$()));
const seen:unknown[]=[];
tree.$({fresh:123,trigger:[{get x(){seen.push([tree.$.fresh(),tree.$().fresh]);return 1}}]});
console.log('inside-equality',JSON.stringify(seen));console.log('after',tree.$().fresh); tree.destroy();
