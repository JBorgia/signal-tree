// packages/kernel/src/lib/internals/error-reporter.ts
var listeners = /* @__PURE__ */ new Set();
function reportTreeError(event) {
  if (listeners.size === 0) return false;
  let received = false;
  for (const listener of listeners) {
    try {
      listener(event);
      received = true;
    } catch (err) {
      if (true) {
        safeConsoleError(
          "SignalTree: an onTreeError listener threw. The original error was still handled normally; this is the listener failing. [ST2025]",
          err
        );
      }
    }
  }
  return received;
}
function safeConsoleError(message, error) {
  try {
    if (error === void 0) console.error(message);
    else console.error(message, error);
  } catch {
  }
}
var CONTAINED_REPORT_BUDGET = 50;
var CONTAINED_REPORT_WINDOW_MS = 1e3;
var containedReportWindows = /* @__PURE__ */ new Map();
function registerContainedReportBudget(treeId) {
  containedReportWindows.set(treeId, null);
}
function takeContainedReportBudget(treeId) {
  let now = 0;
  try {
    now = Date.now();
  } catch {
  }
  const owner = containedReportWindows.has(treeId) ? treeId : void 0;
  let window2 = containedReportWindows.get(owner);
  if (!window2 || now - window2.start >= CONTAINED_REPORT_WINDOW_MS) {
    window2 = { start: now, count: 0 };
    containedReportWindows.set(owner, window2);
  }
  if (window2.count >= CONTAINED_REPORT_BUDGET) {
    if (window2.count === CONTAINED_REPORT_BUDGET && listeners.size > 0) {
      window2.count++;
      safeConsoleError(
        `SignalTree: more than ${CONTAINED_REPORT_BUDGET} contained observer errors for one tree within a second; further ones go to the console only, not onTreeError. [ST2034]`
      );
    }
    return false;
  }
  window2.count++;
  return true;
}
function reportContainedObserverError(event) {
  const { error, operation, treeId, path } = event;
  let received = false;
  if (treeId !== void 0) {
    if (takeContainedReportBudget(treeId)) {
      received = reportTreeError({
        error,
        operation,
        treeId,
        ...path === void 0 ? {} : { path }
      });
    }
  }
  if (received && false) {
    return;
  }
  safeConsoleError(
    operation === "notify:subscriber" ? `SignalTree: a write subscriber threw while observing '${path}'; delivery continued. [ST2034]` : "SignalTree: a transaction turn listener threw; the transaction continued. [ST2034]",
    error
  );
}
function releaseContainedReportBudget(treeId) {
  containedReportWindows.delete(treeId);
}

// packages/kernel/src/lib/internals/production-substrate-stats.ts
var PRODUCTION_SUBSTRATE_STATS_ENABLED = true;
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// packages/kernel/src/lib/internals/cell-identity.ts
var CELL_MARK = Symbol("SignalTree:Cell");
function markTreeCell(cell) {
  Object.defineProperty(cell, CELL_MARK, {
    value: true,
    enumerable: false,
    writable: false,
    configurable: true
  });
  return cell;
}
function isTreeCell(value) {
  return typeof value === "function" && value[CELL_MARK] === true;
}

// packages/kernel/src/lib/leaf.ts
var LEAF_DEFINITION = Symbol.for("SignalTree:LeafDefinition");
function leaf(value) {
  const definition = {};
  Object.defineProperty(definition, LEAF_DEFINITION, { value });
  return definition;
}
function isLeafDefinition(value) {
  return typeof value === "object" && value !== null && Object.prototype.hasOwnProperty.call(value, LEAF_DEFINITION) && Object.getOwnPropertyDescriptor(value, LEAF_DEFINITION)?.enumerable === false;
}
function leafDefinitionValue(definition) {
  return definition[LEAF_DEFINITION];
}

// packages/kernel/src/lib/internals/observation-adapter.ts
var NEUTRAL_OBSERVATION_ADAPTER = {
  createToken: () => ({
    observe: () => void 0,
    invalidate: () => void 0
  }),
  runInvalidationGroup: (run) => run()
};

// packages/kernel/src/lib/internals/intrinsic-mutation.ts
var SOURCES = /* @__PURE__ */ new WeakMap();
var SOURCE_ACCESSORS = {
  prepareTerminal: {
    get() {
      return this.terminalPreparer;
    }
  },
  terminal: {
    get() {
      return this.terminalRecord?.observer;
    }
  },
  capture: {
    get() {
      return this.captureRecord?.observer;
    }
  }
};
function compose(record) {
  const { observers } = record;
  if (observers === void 0 || observers.size === 0) {
    record.observer = void 0;
    return;
  }
  if (observers.size === 1) {
    const only = observers.values().next().value;
    record.observer = (mutation) => {
      try {
        only(mutation);
      } catch {
      }
    };
    return;
  }
  const snapshot = [...observers];
  record.observer = (mutation) => {
    for (const observer of snapshot) {
      try {
        observer(mutation);
      } catch {
      }
    }
  };
}
var UNOBSERVABLE_SOURCE = Object.freeze({
  observer: void 0
});
function registerIntrinsicMutationSource(node) {
  const record = { observers: void 0, observer: void 0 };
  Object.defineProperties(record, SOURCE_ACCESSORS);
  SOURCES.set(node, record);
  return record;
}
function observeIntrinsicMutations(node, observer, capture = false) {
  const source = SOURCES.get(node);
  if (!source) return void 0;
  const record = capture === "terminal" ? source.terminalRecord ??= { observers: void 0, observer: void 0 } : capture ? source.captureRecord ??= { observers: void 0, observer: void 0 } : source;
  const installed = observer;
  (record.observers ??= /* @__PURE__ */ new Set()).add(installed);
  compose(record);
  let active2 = true;
  return () => {
    if (!active2) return;
    active2 = false;
    record.observers?.delete(installed);
    compose(record);
  };
}

// packages/kernel/src/lib/internals/location-runtime.ts
var WRITABLE_LOCATION_BINDINGS = /* @__PURE__ */ new WeakMap();
var writableLocationBinding = (location) => {
  const binding = WRITABLE_LOCATION_BINDINGS.get(location);
  if (!binding) throw new Error("Expected a writable SignalTree location");
  return binding;
};
function isWritableLocation(value) {
  return WRITABLE_LOCATION_BINDINGS.has(value);
}
function writableLocationPublisher(value) {
  return WRITABLE_LOCATION_BINDINGS.get(value);
}
function replaceLocation(location, value) {
  writableLocationBinding(location).replace(value);
}
function deriveLocation(location, update) {
  writableLocationBinding(location).derive(update);
}
function registerWritableLocationBinding(binding) {
  WRITABLE_LOCATION_BINDINGS.set(
    binding.location,
    binding
  );
}
var activeConsumer;
var publicationDepth = 0;
var pendingConsumers = /* @__PURE__ */ new Set();
var dependencyFinalizer = new FinalizationRegistry((dependencies) => {
  for (const [node, edge] of dependencies) {
    node.consumers.delete(edge.reference);
  }
});
var flushConsumers = () => {
  const errors = [];
  while (pendingConsumers.size > 0) {
    const consumer = [...pendingConsumers].sort(
      (left, right) => left.level - right.level
    )[0];
    pendingConsumers.delete(consumer);
    try {
      consumer.settle();
    } catch (error) {
      errors.push(error);
    }
  }
  return errors;
};
var NO_LISTENERS = /* @__PURE__ */ new Set();
var notifyObservers = (token, listeners2) => {
  let failure;
  let hasFailure = false;
  try {
    token?.invalidate();
  } catch (error) {
    failure = error;
    hasFailure = true;
  }
  for (const listener of [...listeners2]) {
    try {
      listener();
    } catch {
    }
  }
  if (hasFailure) throw failure;
};
var trackDependency = (node, token) => {
  if (activeConsumer) {
    let edge = activeConsumer.dependencies.get(node);
    if (!edge) {
      const reference = new WeakRef(activeConsumer);
      edge = { reference, version: node.version };
      node.consumers.add(reference);
      activeConsumer.dependencies.set(node, edge);
    } else {
      edge.version = node.version;
    }
    activeConsumer.level = Math.max(activeConsumer.level, node.level + 1);
    return;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("publicationDependencyReads");
  }
  token().observe();
};
var notifyDependents = (node) => {
  for (const reference of node.consumers) {
    const consumer = reference.deref();
    if (consumer) consumer.invalidate();
    else node.consumers.delete(reference);
  }
};
var NODE_LOCATION_RUNTIMES = /* @__PURE__ */ new WeakMap();
function bindLocationRuntime(node, runtime2) {
  NODE_LOCATION_RUNTIMES.set(node, runtime2);
}
function getLocationRuntime(node) {
  return NODE_LOCATION_RUNTIMES.get(node);
}
function createLocationRuntime(realization) {
  const hasReactiveObservation = realization !== NEUTRAL_OBSERVATION_ADAPTER;
  let invalidationGroupDepth = 0;
  const groupedPublishers = /* @__PURE__ */ new Set();
  const deliver = (publishers) => {
    const errors = [];
    realization.runInvalidationGroup(() => {
      publicationDepth += 1;
      try {
        for (const publisher of publishers) {
          try {
            publisher.notify();
          } catch (error) {
            errors.push(error);
          }
        }
        if (publicationDepth === 1) errors.push(...flushConsumers());
      } finally {
        publicationDepth -= 1;
        if (publicationDepth === 0) pendingConsumers.clear();
      }
    });
    if (errors.length > 0) throw errors[0];
  };
  const publish = (publishers) => {
    if (invalidationGroupDepth > 0) {
      for (const publisher of publishers) groupedPublishers.add(publisher);
      return;
    }
    deliver(publishers);
  };
  const runInvalidationGroup = (run) => {
    let failure;
    let hasFailure = false;
    invalidationGroupDepth += 1;
    try {
      run();
    } catch (error) {
      failure = error;
      hasFailure = true;
    } finally {
      invalidationGroupDepth -= 1;
      if (invalidationGroupDepth === 0 && groupedPublishers.size > 0) {
        const publishers = [...groupedPublishers];
        groupedPublishers.clear();
        try {
          deliver(publishers);
        } catch (error) {
          if (!hasFailure) {
            failure = error;
            hasFailure = true;
          }
        }
      }
    }
    if (hasFailure) throw failure;
  };
  const createWritable = (read, write) => {
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const location = markTreeCell(function(value) {
      if (arguments.length === 0) {
        trackDependency(node, token);
        return read();
      }
      if (typeof value === "function") {
        binding.derive(value);
      } else if (isLeafDefinition(value)) {
        binding.replace(leafDefinitionValue(value));
      } else {
        binding.replace(value);
      }
      return void 0;
    });
    const mutationSource2 = registerIntrinsicMutationSource(
      location
    );
    const binding = {
      location,
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, listeners2);
      },
      replace: (next) => {
        const observer = mutationSource2.observer;
        const before = observer ? read(true) : void 0;
        const changed = write(next, "replace", () => mutationSource2.prepareTerminal?.({ intent: "replace", before, after: next, changed: true }));
        if (observer) {
          observer({
            intent: "replace",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (changed) publish([binding]);
      },
      derive: (update) => {
        const current = read();
        const before = mutationSource2.observer ? read(true) : current;
        const next = update(current);
        const changed = write(next, "derive", () => mutationSource2.prepareTerminal?.({ intent: "derive", before, after: next, changed: true }));
        const observer = mutationSource2.observer;
        if (observer) {
          observer({
            intent: "derive",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (changed) publish([binding]);
      }
    };
    registerWritableLocationBinding(binding);
    location.peek = () => read();
    location.subscribe = (listener) => {
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    location.asReadonly = () => location;
    return binding;
  };
  const createCell = (initial, equal = Object.is) => {
    let value = initial;
    const binding = createWritable(
      () => value,
      (next) => {
        if (equal(value, next)) return false;
        value = next;
        return true;
      }
    );
    return binding.location;
  };
  const createDerived = (compute) => {
    let initialized = false;
    let dirty = true;
    let computationFailed = false;
    let value;
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const token = () => observationToken ??= realization.createToken();
    const consumer = {
      dependencies: /* @__PURE__ */ new Map(),
      level: 1,
      invalidate: () => {
        if (dirty) {
          if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
            pendingConsumers.add(consumer);
          }
          return;
        }
        dirty = true;
        notifyDependents(node);
        if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
          pendingConsumers.add(consumer);
        }
      },
      settle: () => {
        if (!dirty) return;
        const previous = value;
        const wasInitialized = initialized;
        readCurrent();
        if (wasInitialized && !Object.is(previous, value)) {
          publisher.notify();
        }
      }
    };
    dependencyFinalizer.register(consumer, consumer.dependencies);
    const publisher = {
      notify: () => {
        notifyObservers(observationToken, listeners2);
      }
    };
    const readCurrent = () => {
      if (!dirty && initialized) return value;
      if (initialized && !computationFailed) {
        let changed = false;
        for (const [dependency, edge] of consumer.dependencies) {
          dependency.refresh();
          if (dependency.version !== edge.version) changed = true;
        }
        if (!changed) {
          dirty = false;
          return value;
        }
      }
      for (const [dependency, edge] of consumer.dependencies) {
        dependency.consumers.delete(edge.reference);
      }
      consumer.dependencies.clear();
      consumer.level = 1;
      const previous = value;
      const wasInitialized = initialized;
      const previousConsumer = activeConsumer;
      activeConsumer = consumer;
      try {
        value = compute();
        node.level = consumer.level;
        initialized = true;
        dirty = false;
        computationFailed = false;
        if (wasInitialized && !Object.is(previous, value)) {
          node.version += 1;
        }
        return value;
      } catch (error) {
        computationFailed = true;
        throw error;
      } finally {
        activeConsumer = previousConsumer;
      }
    };
    node.refresh = () => {
      if (dirty) readCurrent();
    };
    const location = markTreeCell((() => {
      const current = readCurrent();
      trackDependency(node, token);
      return current;
    }));
    location.peek = readCurrent;
    location.subscribe = (listener) => {
      readCurrent();
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    return location;
  };
  const createEpoch = () => {
    let observationToken;
    let version = 0;
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const publisher = {
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, NO_LISTENERS);
      }
    };
    const epoch = (() => {
      trackDependency(node, token);
      return version;
    });
    epoch.set = (next) => {
      if (next === version) return;
      version = next;
      publish([publisher]);
    };
    epoch.update = (fn) => epoch.set(fn(version));
    epoch.asReadonly = () => epoch;
    return epoch;
  };
  const advanceEpoch = (handle) => {
    handle.update((v) => v + 1);
  };
  return {
    createCell,
    createDerived,
    createWritable,
    createEpoch,
    advanceEpoch,
    publish,
    runInvalidationGroup
  };
}
var NEUTRAL_LOCATION_RUNTIME = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
);

// packages/kernel/src/lib/constants.ts
var DEV_MESSAGES = {
  NULL_OR_UNDEFINED: "null/undefined [ST1001]",
  TREE_DESTROYED: "destroyed [ST1012]",
  ENHANCER_CYCLE_DETECTED: "enhancer cycle [ST1024]"
  // ST1032 (LAZY_NOT_INJECTED) and ST1004 (LAZY_FALLBACK) were removed in 15.0
  // with the lazy feature. ST1032 in particular told users to import from
  // `@signal-tree/kernel/lazy`, a subpath withdrawn from the published surface —
  // a runtime diagnostic giving advice that could not be followed.
};
var PROD_MESSAGES = DEV_MESSAGES;
var _isProdByEnv = Boolean(
  typeof globalThis === "object" && globalThis !== null && "process" in globalThis && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  typeof globalThis.process === "object" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  "env" in globalThis.process && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  globalThis.process.env.NODE_ENV === "production"
);
var _isDev = true ? Boolean(true) : !_isProdByEnv;
var SIGNAL_TREE_MESSAGES = Object.freeze(
  _isDev ? DEV_MESSAGES : PROD_MESSAGES
);

// packages/kernel/src/lib/enhancer-types.ts
var ENHANCER_META = Symbol("signaltree:enhancer:meta");

// packages/kernel/src/enhancers/index.ts
function resolveEnhancerOrder(enhancers, availableCapabilities = /* @__PURE__ */ new Set(), debugMode = false) {
  const nodes = enhancers.map((e, idx) => ({
    fn: e,
    name: e.metadata && e.metadata.name ? String(e.metadata.name) : `enhancer#${idx}`,
    requires: new Set(e.metadata?.requires ?? []),
    provides: new Set(e.metadata?.provides ?? [])
  }));
  const provided = new Set(availableCapabilities);
  const nameCounts = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    for (const capability of node.provides) provided.add(capability);
    if (node.fn.metadata?.name) {
      nameCounts.set(node.name, (nameCounts.get(node.name) ?? 0) + 1);
    }
  }
  const problems = [];
  for (const node of nodes) {
    for (const capability of node.requires) {
      if (!provided.has(capability)) {
        problems.push(
          `  - ${node.fn.metadata?.name ? `"${node.name}"` : "an unnamed enhancer"} requires capability "${capability}", but no configured enhancer provides it.`
        );
      }
    }
  }
  for (const [name, count] of nameCounts) {
    if (count > 1) {
      problems.push(
        `  - enhancer "${name}" is configured ${count} times; each enhancer may appear once.`
      );
    }
  }
  if (problems.length > 0) {
    throw new Error(
      `SignalTree could not finalize the enhancer configuration:
${problems.join("\n")}`
    );
  }
  const adj = /* @__PURE__ */ new Map();
  const nameToNode = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    nameToNode.set(n.name, n);
    adj.set(n.name, /* @__PURE__ */ new Set());
  }
  for (const a of nodes) {
    for (const b of nodes) {
      if (a === b) continue;
      for (const req of b.requires) {
        if (availableCapabilities.has(req)) continue;
        if (a.provides.has(req)) {
          const set = adj.get(a.name);
          if (set) set.add(b.name);
        }
      }
    }
  }
  const inDegree = /* @__PURE__ */ new Map();
  for (const entry of adj.keys()) inDegree.set(entry, 0);
  for (const [, outs] of adj) {
    for (const to of outs) inDegree.set(to, (inDegree.get(to) || 0) + 1);
  }
  const queue = [];
  for (const [name, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(name);
  }
  const ordered = [];
  while (queue.length > 0) {
    const n = queue.shift();
    if (!n) break;
    ordered.push(n);
    const outs = adj.get(n);
    if (!outs) continue;
    for (const m of outs) {
      inDegree.set(m, (inDegree.get(m) || 0) - 1);
      if (inDegree.get(m) === 0) queue.push(m);
    }
  }
  if (ordered.length !== nodes.length) {
    if (debugMode) {
      console.warn(SIGNAL_TREE_MESSAGES.ENHANCER_CYCLE_DETECTED);
    }
    return enhancers;
  }
  return ordered.map((name) => {
    const n = nameToNode.get(name);
    return n ? n.fn : enhancers[0];
  });
}

// packages/kernel/src/lib/internals/node-shape.ts
function isTraversableNode(value) {
  return value != null && (typeof value === "object" || typeof value === "function");
}
var CALLABLE_SIGNAL_SYMBOL = Symbol.for("SignalTree:NodeAccessor");
var NODE_STORE_SYMBOL = Symbol.for("SignalTree:NodeStore");
function nodeStoreOf(node) {
  const store = node[NODE_STORE_SYMBOL];
  return store !== void 0 && store !== null ? store : void 0;
}
function snapshotNodeKey(node) {
  return nodeStoreOf(node) ?? node;
}
function isNodeAccessor(value) {
  return typeof value === "function" && value[CALLABLE_SIGNAL_SYMBOL] === true;
}

// packages/kernel/src/lib/internals/owned-metadata.ts
var OWNED_NODE_METADATA = /* @__PURE__ */ new WeakMap();
function getOwnedPositionIds(node) {
  if (isTraversableNode(node)) {
    const direct = node.__positionIds;
    if (direct) {
      return [...direct];
    }
    const sidecar = OWNED_NODE_METADATA.get(node)?.positionIds;
    return sidecar ? [...sidecar] : void 0;
  }
  return void 0;
}
function getOwnedOwnerPath(node) {
  if (isTraversableNode(node)) {
    const direct = node.__ownerPath;
    if (direct !== void 0) {
      return direct;
    }
    return OWNED_NODE_METADATA.get(node)?.ownerPath;
  }
  return void 0;
}

// packages/kernel/src/lib/internals/owner-invalidation-port.ts
var dispatch;
function markOwnerInvalidated(ownerId) {
  dispatch?.mark(ownerId);
}
function markOwnerInvalidatedFrom(owner) {
  dispatch?.markFrom(owner);
}
function terminateOwnerInvalidation(owner) {
  dispatch?.terminate(owner);
}

// packages/kernel/src/lib/internals/path-observation-port.ts
var runtime;
function installPathDeliveryRuntime(next) {
  runtime = next;
}
var branchMembershipCapture;
var pathReAddCapture;
function installBranchMembershipCapture(capture, pathReAdd) {
  branchMembershipCapture = capture;
  pathReAddCapture = pathReAdd;
}
function captureBranchMembershipIfObserved(branch, supplied, partial) {
  return branchMembershipCapture?.(branch, supplied, partial);
}
function capturePathReAddIfObserved(path, outer) {
  return pathReAddCapture?.(path, outer);
}
function hasPathObservers() {
  return runtime?.hasObservers() ?? false;
}
var PORT = {
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    runtime?.notify(
      path,
      value,
      prev,
      ownerPath,
      subjectIds,
      positionIds,
      metaOverride,
      ownerId,
      subjectFieldFootprint
    );
  }
};
function pathObservation() {
  return PORT;
}

// packages/kernel/src/lib/internals/snapshot-authority.ts
var MATERIALIZED = /* @__PURE__ */ new WeakMap();
var SNAPSHOT_PARENT = /* @__PURE__ */ new WeakMap();
var TREE_STORES = /* @__PURE__ */ new WeakSet();
var VOLATILE_SNAPSHOTS = /* @__PURE__ */ new WeakSet();
var MEMBERSHIP_REVISION = /* @__PURE__ */ new WeakMap();
function markTreeStore(store) {
  TREE_STORES.add(store);
}
function isSnapshotNode(node) {
  return TREE_STORES.has(node) || isNodeAccessor(node);
}
function bindSnapshotParent(node, parent) {
  SNAPSHOT_PARENT.set(
    snapshotNodeKey(node),
    new WeakRef(snapshotNodeKey(parent))
  );
}
function markSnapshotVolatile(node) {
  let current = snapshotNodeKey(node);
  while (current) {
    VOLATILE_SNAPSHOTS.add(current);
    current = SNAPSHOT_PARENT.get(current)?.deref();
  }
}
function membershipRevisionFor(key, locations) {
  let revision = MEMBERSHIP_REVISION.get(key);
  if (!revision) {
    revision = locations.createCell(0);
    MEMBERSHIP_REVISION.set(key, revision);
  }
  return revision;
}
function observeMembership(node) {
  membershipRevisionFor(
    snapshotNodeKey(node),
    getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME
  )();
}
function publishMembershipChange(node) {
  const key = snapshotNodeKey(node);
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  deriveLocation(membershipRevisionFor(key, locations), (value) => value + 1);
  markOwnerInvalidatedFrom(node);
}
function materializeSnapshotNode(node, build) {
  const key = snapshotNodeKey(node);
  if (VOLATILE_SNAPSHOTS.has(key)) return build();
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  let snapshot = MATERIALIZED.get(key);
  if (!snapshot) {
    const membershipRevision = membershipRevisionFor(key, locations);
    const read = () => {
      membershipRevision();
      const built = build();
      if (true) {
        if (built !== null && typeof built === "object") Object.freeze(built);
      }
      return built;
    };
    snapshot = { observe: locations.createDerived(read) };
    MATERIALIZED.set(key, snapshot);
  }
  return snapshot.observe();
}

// packages/kernel/src/lib/internals/tree-scalar-slot-port.ts
var TREE_SCALAR_SLOT_RUNTIME = Symbol.for("SignalTree:ScalarSlotRuntime");
function defineTreeScalarSlotRuntime(node, runtime2) {
  Object.defineProperty(node, TREE_SCALAR_SLOT_RUNTIME, {
    value: runtime2,
    enumerable: false,
    configurable: true
  });
}
function getTreeScalarSlotRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[TREE_SCALAR_SLOT_RUNTIME];
}

// packages/kernel/src/lib/internals/member-membership.ts
var DORMANT = Symbol.for("SignalTree:DormantMember");
var membershipEpoch = 1;
var omittedMembers = /* @__PURE__ */ new WeakMap();
var ABSENCE_CHECK_EVERY = 64;
var absenceChecks = 0;
var MEMBERSHIP_CHANGED = Symbol.for("SignalTree:MembershipChanged");
function membershipHook(node) {
  return node?.[MEMBERSHIP_CHANGED];
}
var NODE_ACCESSOR_PEER = Symbol.for("SignalTree:NodeAccessorPeer");
function isDormantMember(leaf2) {
  const binding = memberBinding(leaf2);
  if (binding === void 0) return false;
  const descriptor = Object.getOwnPropertyDescriptor(
    binding.parent,
    binding.key
  );
  return descriptor !== void 0 && descriptor.enumerable === false;
}
function memberBinding(leaf2) {
  if (!isTraversableNode(leaf2)) {
    return void 0;
  }
  return leaf2[DORMANT];
}
function reactivateOnWrite(leaf2) {
  const binding = memberBinding(leaf2);
  if (!binding) return false;
  return setMemberPresence(binding.parent, binding.key, "active");
}
function nodeOf(parent) {
  return parent[NODE_ACCESSOR_PEER] ?? parent;
}
function isAbsentMember(node) {
  const first = memberBinding(node);
  if (first === void 0) return false;
  if (first.epoch === membershipEpoch) {
    if (++absenceChecks % ABSENCE_CHECK_EVERY === 0 && walkAbsence(first) !== first.absent)
      throw new Error(
        "SignalTree internal: a cached absence answer disagrees with enumerability (membershipEpoch was not advanced)."
      );
    return first.absent;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  first.absent = walkAbsence(first);
  first.epoch = membershipEpoch;
  return first.absent;
}
function walkAbsence(first) {
  for (let binding = first; binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) return true;
  }
  return false;
}
var structuralWrites = {
  depth: 0,
  stamp: 0
};
function beginStructuralWrite() {
  structuralWrites.depth++;
}
function endStructuralWrite(failed) {
  if (--structuralWrites.depth) return;
  structuralWrites.readded = void 0;
  structuralWrites.end?.(failed);
}
function inStructuralWrite(node) {
  return node !== void 0 && structuralWrites.own === node;
}
function readdedDuringStructuralWrite(branch, key, since) {
  return (structuralWrites.readded?.get(nodeOf(branch))?.get(key) ?? 0) > since;
}
var storedReads = { depth: 0 };
function reactivatePathOnWrite(node) {
  if (!isAbsentMember(node)) return false;
  if (inStructuralWrite(node)) return reactivateOnWrite(node);
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  const path = [];
  let outer = -1;
  for (let binding = memberBinding(node); binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) outer = path.length;
    path.push(binding);
  }
  if (outer < 0) return false;
  const announce = capturePathReAddIfObserved(path, outer);
  for (let i = outer - 1; i >= 0; i--) {
    const { parent, key: kept } = path[i];
    for (const member of Object.keys(parent))
      if (member !== kept) setMemberPresence(parent, member, "dormant");
  }
  for (let i = outer; i >= 0; i--) {
    const { parent, key } = path[i];
    setMemberPresence(parent, key, "active");
    if (structuralWrites.depth) {
      const readded = structuralWrites.readded ??= /* @__PURE__ */ new Map();
      let keys = readded.get(parent);
      if (!keys) readded.set(parent, keys = /* @__PURE__ */ new Map());
      keys.set(key, ++structuralWrites.stamp);
    }
  }
  if (!isWritableLocation(node) || outer > 0)
    republishMembers(path[outer].parent, [path[outer].key]);
  announce?.();
  return true;
}
var ABSENCE = {
  // History capture reads what storage holds (`storedReads`).
  isAbsent: (node) => !storedReads.depth && isAbsentMember(node),
  reAdd: reactivatePathOnWrite
};
function republishMembers(parent, keys) {
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (!runtime2) return;
  const changedSlots = [];
  const unaddressedLeaves = [];
  const branches = [];
  const publish = (child) => {
    const positionId = getOwnedPositionIds(child)?.[0];
    const slot = positionId === void 0 ? void 0 : runtime2.resolveScalarSlot(positionId);
    if (slot !== void 0) return changedSlots.push(slot) > 0;
    const publisher = writableLocationPublisher(child);
    if (publisher) return unaddressedLeaves.push(publisher) > 0;
    membershipHook(child)?.();
    if (isNodeAccessor(child)) {
      branches.push(child);
      for (const key of Object.keys(child))
        publish(child[key]);
    }
    return false;
  };
  let tokenCarrying = 0;
  for (const key of keys)
    if (publish(parent[key])) tokenCarrying++;
  if (tokenCarrying < keys.length) {
    publishMembershipChange(parent);
  } else {
    markOwnerInvalidatedFrom(parent);
  }
  for (const branch of branches) publishMembershipChange(branch);
  if (changedSlots.length > 0) {
    runtime2.publishPrepared({ revision: runtime2.revision(), changedSlots });
  }
  if (unaddressedLeaves.length > 0) {
    (getLocationRuntime(parent) ?? NEUTRAL_LOCATION_RUNTIME).publish(
      unaddressedLeaves
    );
  }
}
function deactivateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === false) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: false });
  membershipEpoch++;
  markHasDormant(parent);
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (runtime2) {
    omittedMembers.set(runtime2, (omittedMembers.get(runtime2) ?? 0) + 1);
    runtime2.enableAbsence?.(ABSENCE);
  }
  const child = parent[key];
  if (isTraversableNode(child)) {
    linkMember(parent, key, child);
    linkDescendants(child);
  }
  return true;
}
function linkMember(parent, key, child) {
  membershipEpoch++;
  Object.defineProperty(child, DORMANT, {
    value: {
      parent: nodeOf(parent),
      key,
      epoch: 0,
      absent: false
    },
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function linkDescendants(node) {
  if (!isNodeAccessor(node)) return;
  for (const key of Object.getOwnPropertyNames(node)) {
    const child = Object.getOwnPropertyDescriptor(node, key)?.value;
    if (!isNodeAccessor(child) && !isWritableLocation(child) && !membershipHook(child) || memberBinding(child))
      continue;
    linkMember(node, key, child);
    linkDescendants(child);
  }
}
function linkAddedMember(branch, key, child) {
  if (!isTraversableNode(child) || !memberBinding(nodeOf(branch))) return;
  linkMember(branch, key, child);
  linkDescendants(child);
}
function activateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === true) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: true });
  membershipEpoch++;
  const runtime2 = getTreeScalarSlotRuntime(parent);
  const omitted = runtime2 ? omittedMembers.get(runtime2) : void 0;
  if (runtime2 && omitted !== void 0) {
    omittedMembers.set(runtime2, omitted - 1);
    if (omitted === 1) runtime2.disableAbsence?.();
  }
  return true;
}
var HAS_DORMANT = Symbol.for("SignalTree:HasDormantMembers");
function hasDormantMembers(parent) {
  return parent[HAS_DORMANT] === true;
}
function markHasDormant(parent) {
  if (hasDormantMembers(parent)) return;
  Object.defineProperty(parent, HAS_DORMANT, {
    value: true,
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function dormantKeys(parent) {
  return Object.getOwnPropertyNames(parent).filter((key) => {
    const d = Object.getOwnPropertyDescriptor(parent, key);
    return d !== void 0 && d.enumerable === false && "value" in d;
  });
}
function peerOf(branch) {
  const record = branch;
  const peer = record[NODE_STORE_SYMBOL] ?? record[NODE_ACCESSOR_PEER];
  return isTraversableNode(peer) && peer !== branch ? peer : void 0;
}
function setMemberPresence(branch, key, presence) {
  const apply = presence === "active" ? activateOne : deactivateOne;
  let changed = apply(branch, key);
  const peer = peerOf(branch);
  if (peer) changed = apply(peer, key) || changed;
  return changed;
}

// packages/kernel/src/lib/write-context.ts
var activeContext;
function withWriteContext(meta, fn) {
  const previous = activeContext;
  activeContext = meta;
  try {
    return fn();
  } finally {
    activeContext = previous;
  }
}
function getActiveWriteContext() {
  return activeContext;
}

// packages/kernel/src/lib/internals/owned-mutation.ts
function mergeOwnedNodeMetadata(node, patch) {
  const existing = OWNED_NODE_METADATA.get(node) ?? {};
  OWNED_NODE_METADATA.set(node, { ...existing, ...patch });
}
function defineOwnedPositionIds(node, positionIds, storage = "property") {
  if (!positionIds || positionIds.length === 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { positionIds: [...positionIds] });
    return;
  }
  Object.defineProperty(node, "__positionIds", {
    get: () => [...positionIds],
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerPath(node, ownerPath, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerPath });
    return;
  }
  Object.defineProperty(node, "__ownerPath", {
    value: ownerPath,
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerId(node, ownerId, storage = "property") {
  if (ownerId === void 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerId });
    return;
  }
  Object.defineProperty(node, "__ownerId", {
    value: ownerId,
    enumerable: false,
    configurable: true
  });
}
function defineIntrinsicMutationEmitter(node, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { emitsMutations: true });
    return;
  }
  Object.defineProperty(node, "__emitsMutations", {
    value: true,
    enumerable: false,
    configurable: true
  });
}
function emitOwnedMutation(options, before, after, mutationIntent) {
  markOwnerInvalidated(options.ownerId);
  const positionId = options.positionIds?.[0];
  if (positionId === void 0) {
    return;
  }
  if (!hasPathObservers()) {
    return;
  }
  pathObservation().notify(
    options.path,
    after,
    before,
    options.path,
    // subjectIds: this generic scalar route has no subject-identity producer
    // and must not acquire one. Entity/structural notification owns that fact.
    void 0,
    [positionId],
    {
      ...getActiveWriteContext() ?? {},
      mutationIntent
    },
    options.ownerId
  );
}
function wrapOwnedWritableSignal(leaf2, options, hooks = {}) {
  const metadataStorage = options.metadataStorage ?? "property";
  defineOwnedPositionIds(leaf2, options.positionIds, metadataStorage);
  defineOwnedOwnerId(leaf2, options.ownerId, metadataStorage);
  defineOwnedOwnerPath(leaf2, options.path, metadataStorage);
  defineIntrinsicMutationEmitter(leaf2, metadataStorage);
  const releaseIntrinsicObserver = observeIntrinsicMutations(
    leaf2,
    (mutation) => {
      if (mutation.changed) {
        emitOwnedMutation(
          options,
          mutation.before,
          mutation.after,
          mutation.intent
        );
      }
      if (mutation.intent === "replace") {
        hooks.afterSet?.(
          mutation.after,
          mutation.before,
          mutation.after,
          mutation.changed
        );
      } else {
        hooks.afterUpdate?.(
          mutation.before,
          mutation.after,
          mutation.changed
        );
      }
    }
  );
  if (!releaseIntrinsicObserver) {
    throw new Error("SignalTree location has no intrinsic mutation source");
  }
}

// packages/kernel/src/lib/internals/position-registry.ts
var POSITION_REGISTRY_SYMBOL = Symbol.for("SignalTree:PositionRegistry");
var nextRegistryId = 1;
var TreePositionRegistry = class {
  /**
   * ⚠️ THE ONE PLACE a counter value becomes a tree-namespace identity.
   *
   * Branding HERE rather than at each consumer means `registry.id` and
   * `ownerRegistry.id` are already `TreeId` everywhere downstream — no producer
   * has to independently assert that some number is a tree identity.
   */
  id = nextRegistryId++;
  nextPositionId = 1;
  parents = /* @__PURE__ */ new Map();
  addresses = /* @__PURE__ */ new Map();
  registerPositionAddress(position, address) {
    this.addresses.set(position, sealedAddress(address));
  }
  addressFor(position) {
    return this.addresses.get(position);
  }
  collectionPaths = /* @__PURE__ */ new Map();
  registerCollectionPath(position, path) {
    this.collectionPaths.set(position, path);
  }
  collectionPathFor(position) {
    return this.collectionPaths.get(position);
  }
  allocate(parent) {
    const positionId = this.nextPositionId++;
    this.parents.set(positionId, parent);
    return positionId;
  }
  parentOf(position) {
    return this.parents.get(position);
  }
  contains(authority, participant) {
    if (authority === participant) {
      return true;
    }
    const seen = /* @__PURE__ */ new Set();
    let current = participant;
    while (current !== void 0 && !seen.has(current)) {
      seen.add(current);
      const parent = this.parentOf(current);
      if (parent === authority) {
        return true;
      }
      current = parent;
    }
    return false;
  }
};
function createPositionRegistry() {
  return new TreePositionRegistry();
}
function definePositionRegistry(node, registry) {
  Object.defineProperty(node, POSITION_REGISTRY_SYMBOL, {
    value: registry,
    enumerable: false,
    configurable: true
  });
}
function getPositionRegistry(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[POSITION_REGISTRY_SYMBOL];
}
var nodeAddresses = /* @__PURE__ */ new WeakMap();
function sealedAddress(address) {
  return Object.isFrozen(address) ? address : Object.freeze(address.slice());
}
function childAddressOf(address, key) {
  return Object.freeze(address.concat(key));
}
function defineNodeAddress(node, address) {
  nodeAddresses.set(node, sealedAddress(address));
}
function getNodeAddress(node) {
  return isTraversableNode(node) ? nodeAddresses.get(node) : void 0;
}

// packages/kernel/src/lib/internals/runtime-tree-plan.ts
var RESTORATION_CAPABILITIES = [
  "causal-runtime",
  "temporal-snapshots"
];
function createRuntimeTreePlan(hasCapability) {
  return Object.freeze({
    hasCapability,
    hasRestorationAuthority: RESTORATION_CAPABILITIES.some(
      (capability) => hasCapability(capability)
    )
  });
}

// packages/kernel/src/lib/internals/materialize-markers.ts
function createMaterializationContext(positionTopologyEnabled = true, hasCapability = (capability) => capability === "position-topology" ? positionTopologyEnabled : true, physicalCommitClock, locationRuntime = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const positionRegistry = createPositionRegistry();
  return {
    locationRuntime,
    positionRegistry,
    positionTopologyEnabled,
    physicalCommitClock,
    hasCapability,
    runtimeTreePlan: createRuntimeTreePlan(hasCapability),
    allocatePositionId: (parentPositionId) => positionRegistry.allocate(parentPositionId),
    physicalOwners: []
  };
}
var PROCESSOR_STAMP = Symbol.for("SignalTree:MarkerProcessor");
function getNodeProcessor(node) {
  if (!isTraversableNode(node)) return void 0;
  return node[PROCESSOR_STAMP];
}
function snapshotMarkerNode(node, parent) {
  const proc = getNodeProcessor(node);
  if (!proc?.snapshot) return void 0;
  if (!isTraversableNode(node)) return { value: proc.snapshot(node) };
  if (parent) bindSnapshotParent(node, parent);
  if (!proc.cacheSnapshot) {
    markSnapshotVolatile(node);
    return { value: proc.snapshot(node) };
  }
  const snapshot = proc.snapshot;
  return materializeSnapshotNode(node, () => ({
    value: snapshot(node)
  }));
}
function hydrateMarkerNode(node, value, mode) {
  const proc = getNodeProcessor(node);
  if (!proc?.hydrate) return false;
  proc.hydrate(node, value, mode);
  return true;
}
var MARKER_PROCESSORS = [];
function isRegisteredMarker(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  if (Object.getOwnPropertySymbols(value).length === 0) {
    return false;
  }
  for (const processor of MARKER_PROCESSORS) {
    if (processor.check(value)) {
      return true;
    }
  }
  return false;
}
var warnedWriteOnly = /* @__PURE__ */ new WeakSet();
function warnWriteOnlyMarker(processor, node) {
  if (false) return;
  if (!processor.snapshot || processor.hydrate) return;
  if (typeof node === "function" && "set" in node && typeof node.set === "function") {
    return;
  }
  if (warnedWriteOnly.has(processor)) return;
  warnedWriteOnly.add(processor);
  console.warn(
    "SignalTree: a marker declares `snapshot` but no `hydrate`, and its node is not a writable signal. It will be captured by tree.$(), persistence(), devtools, audit and undo/redo \u2014 and every attempt to write it back is SILENTLY DISCARDED, so tree.$(tree.$()) loses its value. Add a `hydrate` hook, or mark it `transient: true` if it is genuinely not restorable. [ST2023]"
  );
}
var treesConstructedCount = 0;
function _recordTreeConstruction() {
  treesConstructedCount += 1;
}
var ORDINARY_STATE = Symbol.for("SignalTree:OrdinaryStateRequest");
var KEY_INDEX = Symbol.for("SignalTree:DynamicKeyIndex");
var MEMBER_MATERIALIZER = Symbol.for("SignalTree:MemberMaterializer");
function attachKeyIndex(branch) {
  const members = /* @__PURE__ */ new Map();
  for (const key of Object.keys(branch)) {
    members.set(key, branch[key]);
  }
  Object.defineProperty(branch, KEY_INDEX, {
    value: members,
    enumerable: false,
    configurable: true
  });
}
function installPreparedMember(branch, key, child, responsibility) {
  const define = (target) => {
    Object.defineProperty(target, key, {
      value: child,
      enumerable: true,
      writable: true,
      configurable: true
    });
  };
  define(branch);
  const backingStore = branch[NODE_STORE_SYMBOL];
  if (backingStore && backingStore !== branch) define(backingStore);
  if (responsibility) {
    for (const write of responsibility.writes) write.map.set(write.key, write.value);
    for (const add of responsibility.adds) add.set.add(add.value);
  }
  linkAddedMember(branch, key, child);
  branch[KEY_INDEX]?.set(
    key,
    child
  );
}
var applyMemberValue;
function setMemberValueApplier(fn) {
  applyMemberValue = fn;
}
function isOrdinaryStateRequest(v) {
  return isTraversableNode(v) && v[ORDINARY_STATE] === true;
}
function materializeKeyedAware(authority, request, path, parentPositionId, address) {
  const branch = authority.materialize(
    request.value,
    path,
    parentPositionId,
    address
  );
  if (request.keyedLookup && isTraversableNode(branch)) {
    attachKeyIndex(branch);
    Object.defineProperty(branch, MEMBER_MATERIALIZER, {
      value: authority.bindMember(branch),
      enumerable: false,
      configurable: true
    });
  }
  return branch;
}
function materializeMarkers(node, notifier, path = [], context = createMaterializationContext(), authority) {
  if (!isTraversableNode(node)) return;
  if (isTreeCell(node)) return;
  const isAccessor = typeof node === "function" && isNodeAccessor(node);
  if (typeof node === "function" && !isAccessor) return;
  const getNotifier = () => notifier ?? pathObservation();
  const keys = Object.keys(node);
  for (const key of keys) {
    const value = node[key];
    const currentPath = childAddressOf(path, key);
    const pathString = currentPath.join(".");
    let processed = false;
    for (const processor of MARKER_PROCESSORS) {
      if (processor.check(value)) {
        try {
          const parentPositionId = node.__positionIds?.[0];
          const produced = processor.create(
            value,
            getNotifier(),
            pathString,
            context,
            parentPositionId
          );
          const materialized = isOrdinaryStateRequest(produced) && authority ? materializeKeyedAware(
            authority,
            produced,
            pathString,
            parentPositionId,
            currentPath
          ) : produced;
          if (isTraversableNode(materialized)) {
            defineNodeAddress(materialized, currentPath);
            if (context.positionTopologyEnabled) {
              for (const position of getOwnedPositionIds(materialized) ?? []) {
                context.positionRegistry.registerPositionAddress(
                  position,
                  currentPath
                );
              }
            }
            bindLocationRuntime(
              materialized,
              context.locationRuntime
            );
            Object.defineProperty(materialized, PROCESSOR_STAMP, {
              value: processor,
              enumerable: false,
              writable: false,
              configurable: true
            });
          }
          if (true) {
            warnWriteOnlyMarker(processor, materialized);
          }
          node[key] = materialized;
          const backingStore = node[NODE_STORE_SYMBOL];
          if (backingStore && backingStore !== node) {
            backingStore[key] = materialized;
          }
          processed = true;
        } catch (err) {
          if (true) {
            console.error(
              `SignalTree: Failed to materialize marker at "${pathString}"`,
              err
            );
          }
        }
        break;
      }
    }
    if (!processed && value != null) {
      if (isNodeAccessor(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      } else if (typeof value === "object" && !Array.isArray(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      }
    }
  }
}

// packages/kernel/src/lib/internals/observation-substrate.ts
var OBSERVATION = /* @__PURE__ */ new WeakMap();
var BRANCH_SCOPES = /* @__PURE__ */ new WeakMap();
function inheritObservationForAddedMember(parent, child) {
  const scopes = BRANCH_SCOPES.get(nodeStoreOf(parent) ?? parent);
  if (!scopes) return;
  for (const scope of scopes) scope.visit(child);
}
function installDormantObservation(leaf2) {
  OBSERVATION.set(leaf2, {
    claims: 0,
    positionId: void 0,
    releaseMutationObserver: () => void 0
  });
}
function claimLeaf(node) {
  const state = OBSERVATION.get(node);
  if (!state) return void 0;
  const registry = getPositionRegistry(node);
  const ownerPath = getOwnedOwnerPath(node);
  if (!registry || ownerPath === void 0) return void 0;
  if (state.claims === 0) {
    if (state.positionId === void 0) {
      state.positionId = getOwnedPositionIds(node)?.[0] ?? registry.allocate();
      const address = getNodeAddress(node);
      if (address) registry.registerPositionAddress(state.positionId, address);
      defineOwnedPositionIds(node, [state.positionId]);
      defineOwnedOwnerId(node, registry.id);
    }
    const positionIds = [state.positionId];
    state.releaseMutationObserver = observeIntrinsicMutations(node, (mutation) => {
      if (!mutation.changed) return;
      emitOwnedMutation(
        { path: ownerPath, positionIds, ownerId: registry.id },
        mutation.before,
        mutation.after,
        mutation.intent
      );
    }) ?? (() => void 0);
  }
  state.claims++;
  let released = false;
  return () => {
    if (released) return;
    released = true;
    state.claims--;
    if (state.claims === 0) {
      state.releaseMutationObserver();
      state.releaseMutationObserver = () => void 0;
    }
  };
}
function acquireObservation(source) {
  const releases = [];
  const seen = /* @__PURE__ */ new Set();
  const branches = [];
  const scope = { visit: (node) => visit(node) };
  const visit = (candidate) => {
    if (!isTraversableNode(candidate)) return;
    const node = nodeStoreOf(candidate) ?? candidate;
    if (seen.has(node)) return;
    seen.add(node);
    const claim = claimLeaf(node);
    if (claim) {
      releases.push(claim);
      return;
    }
    let scopes = BRANCH_SCOPES.get(node);
    if (!scopes) {
      scopes = /* @__PURE__ */ new Set();
      BRANCH_SCOPES.set(node, scopes);
    }
    scopes.add(scope);
    branches.push(node);
    for (const key of Object.keys(node)) {
      visit(node[key]);
    }
    if (hasDormantMembers(node)) {
      for (const key of dormantKeys(node)) {
        const child = node[key];
        if (isDormantMember(child)) visit(child);
      }
    }
  };
  visit(source);
  let released = false;
  return () => {
    if (released) return;
    released = true;
    for (const branch of branches) {
      const scopes = BRANCH_SCOPES.get(branch);
      scopes?.delete(scope);
      if (scopes?.size === 0) BRANCH_SCOPES.delete(branch);
    }
    for (const release of releases) release();
    branches.length = 0;
    releases.length = 0;
    seen.clear();
  };
}

// packages/kernel/src/lib/internals/root-source.ts
var ROOT_AUTHORITIES = /* @__PURE__ */ new WeakMap();
function defineRootTree(rootAccessor, authority) {
  ROOT_AUTHORITIES.set(rootAccessor, authority);
}
function getRootTree(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return ROOT_AUTHORITIES.get(node);
}

// packages/kernel/src/lib/internals/utilities/deep-equal.ts
function deepEqual(a, b) {
  return equalsInner(a, b, 0, void 0);
}
var CYCLE_GUARD_DEPTH = 64;
function equalsInner(a, b, depth, seen) {
  if (a === b) return true;
  if (a == null || b == null) return a === b;
  const typeA = typeof a;
  const typeB = typeof b;
  if (typeA !== typeB) return false;
  if (typeA !== "object") return a !== a && b !== b;
  if (depth >= CYCLE_GUARD_DEPTH) {
    seen ??= /* @__PURE__ */ new WeakMap();
    if (seen.get(a) === b) return true;
    seen.set(a, b);
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    const bArr = b;
    for (let i = 0; i < a.length; i++) {
      const x = a[i];
      const y = bArr[i];
      if (x === y) continue;
      if (!equalsInner(x, y, depth + 1, seen)) return false;
    }
    return true;
  }
  if (Array.isArray(b)) return false;
  if (a instanceof Date && b instanceof Date) {
    try {
      const ta = a.getTime();
      const tb = b.getTime();
      return ta === tb || ta !== ta && tb !== tb;
    } catch {
      return false;
    }
  }
  if (a instanceof RegExp && b instanceof RegExp) {
    return a.source === b.source && a.flags === b.flags;
  }
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    for (const [key, value] of a) {
      if (!b.has(key) || !equalsInner(value, b.get(key), depth + 1, seen))
        return false;
    }
    return true;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    for (const value of a) {
      if (!b.has(value)) return false;
    }
    return true;
  }
  if (a instanceof Error && b instanceof Error) {
    if (a.name !== b.name || a.message !== b.message) return false;
  } else if (a instanceof Number && b instanceof Number || a instanceof String && b instanceof String || a instanceof Boolean && b instanceof Boolean) {
    const va = a.valueOf();
    const vb = b.valueOf();
    if (!(va === vb || va !== va && vb !== vb)) return false;
  }
  try {
    if (a.constructor !== b.constructor) {
      return false;
    }
  } catch {
    return false;
  }
  const objA = a;
  const objB = b;
  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  const hasOwn = Object.prototype.hasOwnProperty;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!hasOwn.call(objB, key)) return false;
    const x = objA[key];
    const y = objB[key];
    if (x === y) continue;
    if (!equalsInner(x, y, depth + 1, seen)) return false;
  }
  return true;
}

// packages/kernel/src/lib/internals/utilities/is-built-in-object.ts
function isBuiltInObject(value) {
  if (value === null || value === void 0) return false;
  if (value instanceof Date || value instanceof RegExp || typeof value === "function" || value instanceof Map || value instanceof Set || value instanceof WeakMap || value instanceof WeakSet || value instanceof ArrayBuffer || value instanceof DataView || value instanceof Error || value instanceof Promise) {
    return true;
  }
  if (value instanceof Int8Array || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Int16Array || value instanceof Uint16Array || value instanceof Int32Array || value instanceof Uint32Array || value instanceof Float32Array || value instanceof Float64Array || value instanceof BigInt64Array || value instanceof BigUint64Array) {
    return true;
  }
  if (typeof window !== "undefined") {
    if (value instanceof URL || value instanceof URLSearchParams || value instanceof FormData || value instanceof Blob || typeof File !== "undefined" && value instanceof File || typeof FileList !== "undefined" && value instanceof FileList || typeof Headers !== "undefined" && value instanceof Headers || typeof Request !== "undefined" && value instanceof Request || typeof Response !== "undefined" && value instanceof Response || typeof AbortController !== "undefined" && value instanceof AbortController || typeof AbortSignal !== "undefined" && value instanceof AbortSignal) {
      return true;
    }
  }
  try {
    const NodeBuffer = globalThis?.Buffer;
    if (NodeBuffer && value instanceof NodeBuffer) {
      return true;
    }
  } catch {
  }
  return false;
}

// packages/kernel/src/lib/utils.ts
var isReactiveStateValue = isTreeCell;
function warnUnwrapSkipped(key) {
  console.error(
    `SignalTree: "${key}" OMITTED from snapshot \u2014 value is a function that is neither signal nor node accessor. [ST2008]`
  );
}
function isMemoisable(node) {
  return isSnapshotNode(node);
}
function materializeNode(store) {
  if (!isMemoisable(store)) return unwrap(store);
  return materializeSnapshotNode(store, () => unwrap(store));
}
var DERIVED_STAMP = Symbol.for("SignalTree:Derived");
function stampDerived(sig) {
  if (typeof sig === "function") markTreeCell(sig);
  if (isTraversableNode(sig) && typeof sig.set !== "function") {
    Object.defineProperty(sig, DERIVED_STAMP, {
      value: true,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  return sig;
}
function unwrap(node) {
  if (node === null || node === void 0) {
    return node;
  }
  if (isNodeAccessor(node)) {
    const target = snapshotNodeKey(node);
    return isMemoisable(node) ? materializeSnapshotNode(node, () => buildFromStore(target)) : buildFromStore(target);
  }
  if (isReactiveStateValue(node)) {
    return node();
  }
  if (typeof node !== "object") {
    return node;
  }
  if (Array.isArray(node)) {
    return node;
  }
  if (isBuiltInObject(node)) {
    return node;
  }
  return buildFromStore(node);
}
function unwrapBranchForWriteCapture(node) {
  return isNodeAccessor(node) ? buildFromStore(snapshotNodeKey(node), true) : unwrap(node);
}
function buildFromStore(node, uncachedBranches = false) {
  const own = snapshotMarkerNode(node);
  if (own) return own.value;
  const result = {};
  if (hasDormantMembers(node)) {
    for (const key of dormantKeys(node)) {
      const dormant = node[key];
      if (typeof dormant === "function") dormant();
    }
  }
  for (const key in node) {
    if (!Object.prototype.hasOwnProperty.call(node, key)) continue;
    const value = node[key];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshot = snapshotMarkerNode(value, node);
    if (markerSnapshot) {
      result[key] = markerSnapshot.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (true) {
        warnUnwrapSkipped(key);
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      bindSnapshotParent(value, node);
      result[key] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[key] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[key] = unwrap(value);
    } else {
      result[key] = value;
    }
  }
  const symbols = Object.getOwnPropertySymbols(node);
  for (const sym of symbols) {
    if (typeof sym.description === "string" && sym.description.startsWith("SignalTree:")) {
      continue;
    }
    const value = node[sym];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshotSym = snapshotMarkerNode(value, node);
    if (markerSnapshotSym) {
      result[sym] = markerSnapshotSym.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (true) {
        warnUnwrapSkipped(String(sym));
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      result[sym] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[sym] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[sym] = unwrap(value);
    } else {
      result[sym] = value;
    }
  }
  return result;
}

// packages/kernel/src/lib/internals/mutation-capture-runtime.ts
var MUTATION_CAPTURE_RUNTIME = Symbol.for(
  "SignalTree:MutationCaptureRuntime"
);
function createMutationCaptureRuntime() {
  let activeCount = 0;
  const entityListeners = /* @__PURE__ */ new Set();
  const collectionOrderListeners = /* @__PURE__ */ new Set();
  return {
    hasCommittedEntityObservers() {
      return activeCount > 0 && entityListeners.size > 0;
    },
    publishCommittedEntity(capture) {
      if (activeCount === 0) return;
      for (const listener of [...entityListeners]) {
        try {
          listener(capture);
        } catch (error) {
          reportContainedObserverError({
            error,
            operation: "transaction:listener"
          });
        }
      }
    },
    subscribeCommittedEntity(listener) {
      entityListeners.add(listener);
      return () => {
        entityListeners.delete(listener);
      };
    },
    isCaptureActive() {
      return activeCount > 0;
    },
    activateCapture() {
      activeCount += 1;
      let released = false;
      return () => {
        if (released) {
          return;
        }
        released = true;
        activeCount = Math.max(0, activeCount - 1);
      };
    },
    publishCollectionOrder(capture) {
      if (activeCount === 0) {
        return;
      }
      for (const listener of [...collectionOrderListeners]) {
        listener(capture);
      }
    },
    subscribeCollectionOrder(listener) {
      collectionOrderListeners.add(listener);
      return () => collectionOrderListeners.delete(listener);
    }
  };
}
function getMutationCaptureRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[MUTATION_CAPTURE_RUNTIME];
}

// packages/kernel/src/lib/internals/tree-scalar-slot-runtime.ts
var ScalarSlotMutationFrameImpl = class {
  constructor(baseRevision, getCommittedRevision, readValue, commitValues, assertSlotIndex, prepareValues) {
    this.baseRevision = baseRevision;
    this.getCommittedRevision = getCommittedRevision;
    this.readValue = readValue;
    this.commitValues = commitValues;
    this.assertSlotIndex = assertSlotIndex;
    this.prepareValues = prepareValues;
  }
  staged = /* @__PURE__ */ new Map();
  closed = false;
  set(slotIndex, value) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    this.staged.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    const current = this.staged.has(slotIndex) ? this.staged.get(slotIndex) : this.readValue(slotIndex);
    this.staged.set(slotIndex, updater(current));
  }
  discard() {
    this.assertOpen();
    this.closed = true;
    this.staged.clear();
  }
  prepareCommit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) throw new Error("Stale scalar preparation");
    return this.prepareValues(this.staged, options);
  }
  commit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) {
      throw new Error("ScalarSlotMutationFrame base revision is stale.");
    }
    if (this.staged.size > 0) {
      return this.commitValues(this.staged, options);
    }
    return {
      revision: this.getCommittedRevision(),
      changedSlots: []
    };
  }
  assertOpen() {
    if (this.closed) {
      throw new Error("ScalarSlotMutationFrame is already closed.");
    }
  }
};
function createTreeScalarSlotRuntime(physicalCommitClock) {
  const values = [];
  const equalities = [];
  const slotByPositionId = /* @__PURE__ */ new Map();
  let revision = 0;
  const getCommittedRevision = () => physicalCommitClock?.revision() ?? revision;
  const advanceRevision = () => {
    const nextRevision = physicalCommitClock?.advance();
    if (nextRevision !== void 0) {
      return nextRevision;
    }
    revision += 1;
    return revision;
  };
  const assertSlotIndex = (slotIndex) => {
    if (!Number.isInteger(slotIndex) || slotIndex < 0 || slotIndex >= values.length) {
      throw new Error(`Scalar slot index ${slotIndex} is out of bounds.`);
    }
  };
  const collectSlotChanges = (staged) => {
    const changed = [];
    for (const [slotIndex, nextValue] of staged) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      if (!equalities[slotIndex](values[slotIndex], nextValue)) {
        changed.push({ slotIndex, nextValue });
      }
    }
    return changed;
  };
  const prepareSlots = (staged, options) => {
    const base = getCommittedRevision();
    const changed = collectSlotChanges(staged);
    if (getCommittedRevision() !== base) throw new Error("Reentrant scalar preparation");
    let used = false;
    return () => {
      if (used) throw new Error("Prepared scalar commit already used");
      if (getCommittedRevision() !== base) throw new Error("Stale prepared scalar commit");
      used = true;
      for (const { slotIndex, nextValue } of changed) {
        values[slotIndex] = nextValue;
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("slotWrites");
        }
      }
      const revision2 = changed.length && options?.advanceRevision !== false ? advanceRevision() : getCommittedRevision();
      if (changed.length && options?.advanceRevision !== false && PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return { revision: revision2, changedSlots: changed.map((x) => x.slotIndex) };
    };
  };
  const commitSlots = (staged, options) => {
    const changed = collectSlotChanges(staged);
    if (changed.length === 0) {
      return {
        revision: getCommittedRevision(),
        changedSlots: []
      };
    }
    for (const { slotIndex, nextValue } of changed) {
      values[slotIndex] = nextValue;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("slotWrites", changed.length);
    }
    const nextRevision = options?.advanceRevision === false ? getCommittedRevision() : advanceRevision();
    if (options?.advanceRevision !== false && PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("revisionIncrements");
    }
    return {
      revision: nextRevision,
      changedSlots: changed.map(({ slotIndex }) => slotIndex)
    };
  };
  const commitSlotValue = (slotIndex, nextValue, options) => {
    assertSlotIndex(slotIndex);
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("equalityChecks");
    }
    if (equalities[slotIndex](values[slotIndex], nextValue)) return false;
    values[slotIndex] = nextValue;
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("slotWrites");
    }
    if (options?.advanceRevision !== false) {
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
    }
    return true;
  };
  const commitSlot = (slotIndex, nextValue, options) => {
    const changed = commitSlotValue(slotIndex, nextValue, options);
    return changed ? { revision: getCommittedRevision(), changed: true, slot: slotIndex } : { revision: getCommittedRevision(), changed: false };
  };
  return {
    createSlot(initialValue, equal, positionId) {
      const slotIndex = values.length;
      values.push(initialValue);
      equalities.push(equal);
      if (positionId !== void 0) {
        slotByPositionId.set(positionId, slotIndex);
      }
      return slotIndex;
    },
    readSlot(slotIndex) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotReads");
      }
      return values[slotIndex];
    },
    commitRecorded(slotIndex, value, prepare) {
      assertSlotIndex(slotIndex);
      const base = getCommittedRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      const equal = equalities[slotIndex](values[slotIndex], value);
      if (getCommittedRevision() !== base) throw new Error("Scalar equality reentered physical installation");
      if (equal) return false;
      const plan = prepare?.();
      if (getCommittedRevision() !== base) throw new Error("Terminal preparation reentered physical installation");
      values[slotIndex] = value;
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotWrites");
      }
      if (plan) {
        for (let i = 0; i < plan.writes.length; i++) {
          const w = plan.writes[i];
          w.map.set(w.key, w.value);
        }
        for (let i = 0; i < plan.adds.length; i++) {
          const a = plan.adds[i];
          a.set.add(a.value);
        }
      }
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return true;
    },
    commitSlot(slotIndex, value) {
      return commitSlot(slotIndex, value);
    },
    commitSlotValue(slotIndex, value) {
      return commitSlotValue(slotIndex, value);
    },
    updateSlot(slotIndex, updater) {
      assertSlotIndex(slotIndex);
      return commitSlot(slotIndex, updater(values[slotIndex]));
    },
    beginFrame() {
      return new ScalarSlotMutationFrameImpl(
        getCommittedRevision(),
        getCommittedRevision,
        (slotIndex) => values[slotIndex],
        commitSlots,
        assertSlotIndex,
        prepareSlots
      );
    },
    resolveScalarSlot(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return slotByPositionId.get(positionId);
    },
    revision() {
      return getCommittedRevision();
    },
    slotCount() {
      return values.length;
    }
  };
}

// packages/kernel/src/lib/internals/tree-scalar-leaf-runtime.ts
var ScalarSlotPublication = class {
  constructor(locations) {
    this.locations = locations;
  }
  bindings = [];
  bind(slotIndex, binding) {
    this.bindings[slotIndex] = binding;
  }
  publish(result) {
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications", result.changedSlots.length);
    }
    const publishers = result.changedSlots.flatMap((slotIndex) => {
      const binding = this.bindings[slotIndex];
      return binding ? [binding] : [];
    });
    this.locations.publish(publishers);
  }
  prepareSlot(slotIndex, changed, force = false) {
    if (!changed && !force) {
      return false;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications");
    }
    return true;
  }
};
var ScalarSlotMutationFrameOrchestrator = class {
  constructor(frame, publication) {
    this.frame = frame;
    this.publication = publication;
  }
  set(slotIndex, value) {
    this.frame.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.frame.update(slotIndex, updater);
  }
  discard() {
    this.frame.discard();
  }
  prepareCommit(options) {
    const install = this.frame.prepareCommit({ advanceRevision: options?.advanceRevision });
    return () => {
      const result = install();
      if (options?.publish !== false) this.publication.publish(result);
      return result;
    };
  }
  commit(options) {
    const result = this.frame.commit({
      advanceRevision: options?.advanceRevision
    });
    if (options?.publish !== false) {
      this.publication.publish(result);
    }
    return result;
  }
};
function createScalarLeaf(kernel, publication, locations, slotIndex, liveness) {
  const holder = {};
  const read = (stored) => {
    if (!stored && liveness.absence?.isAbsent(holder.leaf)) {
      return void 0;
    }
    return kernel.readSlot(slotIndex);
  };
  const binding = locations.createWritable(read, (value, _intent, prepare) => {
    const changedValue = kernel.commitRecorded(slotIndex, value, prepare);
    const result = { changed: changedValue };
    const reAdded = liveness.absence?.reAdd(holder.leaf) === true;
    const changed = publication.prepareSlot(slotIndex, result.changed, reAdded);
    return changed;
  });
  const leaf2 = binding.location;
  holder.leaf = leaf2;
  return { leaf: leaf2, binding };
}
function createTreeScalarLeafRuntime(physicalCommitClock, locations = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const kernel = createTreeScalarSlotRuntime(physicalCommitClock);
  const publication = new ScalarSlotPublication(locations);
  const leafByPositionId = /* @__PURE__ */ new Map();
  const liveness = {};
  return {
    enableAbsence(absence) {
      liveness.absence = absence;
    },
    disableAbsence() {
      liveness.absence = void 0;
    },
    createLeaf(initialValue, equal, positionId) {
      const slotIndex = kernel.createSlot(initialValue, equal, positionId);
      const { leaf: leaf2, binding } = createScalarLeaf(
        kernel,
        publication,
        locations,
        slotIndex,
        liveness
      );
      publication.bind(slotIndex, binding);
      if (positionId !== void 0) {
        leafByPositionId.set(positionId, leaf2);
      }
      return leaf2;
    },
    beginFrame() {
      return new ScalarSlotMutationFrameOrchestrator(
        kernel.beginFrame(),
        publication
      );
    },
    runInvalidationGroup(run) {
      locations.runInvalidationGroup(run);
    },
    publishPrepared(result) {
      publication.publish(result);
    },
    resolveScalarSlot(positionId) {
      return kernel.resolveScalarSlot(positionId);
    },
    resolveScalarLeaf(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return leafByPositionId.get(positionId);
    },
    revision() {
      return kernel.revision();
    },
    slotCount() {
      return kernel.slotCount();
    }
  };
}

// packages/kernel/src/lib/internals/physical-commit-clock.ts
var PHYSICAL_COMMIT_CLOCK = Symbol.for("SignalTree:PhysicalCommitClock");
function createPhysicalCommitClock() {
  let revision = 0;
  return {
    revision() {
      return revision;
    },
    advance() {
      revision += 1;
      return revision;
    }
  };
}
function definePhysicalCommitClock(node, clock) {
  Object.defineProperty(node, PHYSICAL_COMMIT_CLOCK, {
    value: clock,
    enumerable: false,
    configurable: true
  });
}

// packages/kernel/src/lib/internals/tree-capabilities.ts
var TREE_CAPABILITY_ORDER = [
  "mutation-capture",
  "position-topology",
  "causal-runtime",
  "temporal-snapshots"
];
var TREE_CAPABILITY_DEPENDENCIES = {
  "mutation-capture": [],
  "position-topology": [],
  "causal-runtime": ["mutation-capture", "position-topology"],
  "temporal-snapshots": []
};
var canonicalizeCapabilities = (capabilities) => {
  const set = new Set(capabilities);
  return TREE_CAPABILITY_ORDER.filter((capability) => set.has(capability));
};
function collectRequestedTreeCapabilities(enhancerMeta) {
  const requested = /* @__PURE__ */ new Set();
  for (const meta of enhancerMeta) {
    for (const capability of meta?.capabilities ?? []) {
      requested.add(capability);
    }
  }
  return canonicalizeCapabilities(requested);
}
function resolveTreeCapabilities(requestedCapabilities) {
  assertTreeCapabilityGraphAcyclic();
  const requested = canonicalizeCapabilities(requestedCapabilities);
  const resolved = new Set(requested);
  const queue = [...requested];
  while (queue.length > 0) {
    const capability = queue.shift();
    if (!capability) {
      continue;
    }
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      if (resolved.has(dependency)) {
        continue;
      }
      resolved.add(dependency);
      queue.push(dependency);
    }
  }
  return {
    requestedCapabilities: requested,
    resolvedCapabilities: canonicalizeCapabilities(resolved)
  };
}
function assertTreeCapabilityGraphAcyclic() {
  const visiting = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new Set();
  const visit = (capability) => {
    if (visited.has(capability)) {
      return;
    }
    if (visiting.has(capability)) {
      throw new Error(
        `SignalTree: capability dependency cycle detected at "${capability}".`
      );
    }
    visiting.add(capability);
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      visit(dependency);
    }
    visiting.delete(capability);
    visited.add(capability);
  };
  for (const capability of TREE_CAPABILITY_ORDER) {
    visit(capability);
  }
}
var TREE_CAPABILITIES = Symbol.for("SignalTree:TreeCapabilities");
function defineTreeCapabilities(tree2, capabilities) {
  Object.defineProperty(tree2, TREE_CAPABILITIES, {
    value: capabilities,
    enumerable: false,
    configurable: true
  });
}

// packages/kernel/src/lib/internals/merge-derived.ts
function ensurePathAndGetTarget($, path) {
  if (!path) return $;
  const parts = path.split(".");
  let current = $;
  for (const part of parts) {
    if (!(part in current)) {
      current[part] = {};
    }
    current = current[part];
  }
  return current;
}
function mergeDerivedState($, derivedDef, path = "", locations) {
  if (!derivedDef || typeof derivedDef !== "object") {
    return;
  }
  for (const [key, value] of Object.entries(derivedDef)) {
    const currentPath = path ? `${path}.${key}` : key;
    if (typeof value === "function" && locations) {
      const target = ensurePathAndGetTarget($, path);
      if (key in target && true) {
        console.warn(
          `SignalTree: Derived location "${currentPath}" overwrites source state. Consider using a different key to avoid confusion.`
        );
      }
      target[key] = stampDerived(
        locations.createDerived(value)
      );
    } else if (typeof value === "object" && value !== null) {
      const target = ensurePathAndGetTarget($, path);
      if (!(key in target)) {
        target[key] = {};
      } else if (isTreeCell(target[key])) {
        throw new Error(
          `SignalTree: Cannot merge derived object into "${currentPath}" because source is a signal. Either make source an object or use a different key.`
        );
      }
      mergeDerivedState($, value, currentPath, locations);
    } else if (true) {
      console.warn(
        `[SignalTree] [ST2007] Derived "${currentPath}" dropped: the value could not be realized by this tree. Return a computation recipe, a value recognized by the package realization, or a nested object. See ST2007.`
      );
    }
  }
}
function applyDerivedFactory($, factory, locations) {
  mergeDerivedState($, factory($), "", locations);
}

// packages/kernel/src/lib/internals/entity-projection-seed.ts
var SEED = Symbol("signaltree.entityProjectionSeed");
var LOCATION_BINDING = Symbol("signaltree.entityLocationBinding");
function getEntityLocationBinding(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[LOCATION_BINDING];
}
function getEntityProjectionSeed(node) {
  if (node === null || typeof node !== "object") return void 0;
  const produce = node[SEED];
  return typeof produce === "function" ? produce() : void 0;
}

// packages/kernel/src/lib/signal-tree.ts
var isWritableCell = (v) => typeof v === "function" && "set" in v && typeof v.set === "function";
var readWritableCell = (cell) => "peek" in cell && typeof cell.peek === "function" ? cell.peek() : cell();
var ENTITY_ARRAY_MIN_LENGTH = 32;
var ENTITY_ARRAY_SAMPLE = 64;
var ENTITY_ID_KEYS = ["id", "_id", "uuid", "key"];
var ENTITY_ARRAY_WARNED = /* @__PURE__ */ new Set();
var ENTITY_ARRAY_WARN_CAP = 256;
var NODE_ACCESSOR_PEER2 = Symbol.for("SignalTree:NodeAccessorPeer");
function createTreeBuildPlan(requestedCapabilities, leafMetadataStorage) {
  const resolved = resolveTreeCapabilities(requestedCapabilities);
  return {
    requestedCapabilities: resolved.requestedCapabilities,
    capabilities: resolved.resolvedCapabilities,
    has(capability) {
      return resolved.resolvedCapabilities.includes(capability);
    },
    leafMetadataStorage
  };
}
function finalizeLeafSignal(leaf2, path, positionIds, buildPlan, captureRuntime, registry, address) {
  defineNodeAddress(leaf2, address);
  for (const position of positionIds ?? [])
    registry?.registerPositionAddress(position, address);
  if (buildPlan.has("position-topology") && registry) {
    definePositionRegistry(leaf2, registry);
  }
  if (buildPlan.has("mutation-capture")) {
    wrapOwnedWritableSignal(leaf2, {
      path,
      // `ownerPath: path` sat here until 15.0 (ME-B). The owner-address fact is
      // still installed on the leaf — it is now derived from `path` inside
      // owned-mutation rather than passed as a second, identical argument.
      positionIds,
      ownerId: registry?.id,
      metadataStorage: buildPlan.leafMetadataStorage,
      captureRuntime
    });
    return;
  }
  if (buildPlan.has("position-topology")) {
    defineOwnedPositionIds(leaf2, positionIds);
    defineOwnedOwnerId(leaf2, registry?.id);
  }
  if (registry) {
    definePositionRegistry(leaf2, registry);
    defineOwnedOwnerPath(leaf2, path);
    installDormantObservation(leaf2);
  }
}
function getEnhancerMeta(enhancer) {
  return enhancer[ENHANCER_META] ?? enhancer.metadata;
}
function buildTreePlan(enhancers, explicitCapabilities = []) {
  const requestedCapabilities = collectRequestedTreeCapabilities([
    ...enhancers.map((enhancer) => getEnhancerMeta(enhancer)),
    // An explicit request is treated as one more declaration, so it goes
    // through the same dependency resolution rather than bypassing it.
    { capabilities: [...explicitCapabilities] }
  ]);
  return createTreeBuildPlan(requestedCapabilities, "property");
}
function materializeTreeMarkers(tree2, materializationContext, authority) {
  materializeMarkers(tree2.$, void 0, [], materializationContext, authority);
  _recordTreeConstruction();
}
function isEntityMapMarker(value) {
  return Boolean(
    value && typeof value === "object" && value["__isEntityMap"] === true
  );
}
function createEqualityFn(useShallowComparison) {
  return useShallowComparison ? Object.is : deepEqual;
}
function makeNodeAccessor(store, ownerPath, positionIds, registry, locations) {
  const isRoot = ownerPath === "";
  const self = {};
  const applyGrouped = (run) => {
    if (locations) locations.runInvalidationGroup(run);
    else run();
  };
  const accessor = {
    node(arg) {
      if (arguments.length === 0) {
        if (!isRoot && self.accessor !== void 0 && isAbsentMember(self.accessor)) {
          observeMembership(store);
          return void 0;
        }
        return materializeNode(store);
      }
      const absent = !isRoot && isAbsentMember(self.accessor);
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = absent ? void 0 : unwrap(store);
        updates = updater(current);
      }
      applyGrouped(() => {
        recursiveUpdate(store, updates, void 0, "");
        if (absent && updates && typeof updates === "object")
          reactivatePathOnWrite(self.accessor);
      });
    }
  }.node;
  self.accessor = accessor;
  accessor[CALLABLE_SIGNAL_SYMBOL] = true;
  Object.defineProperty(accessor, NODE_STORE_SYMBOL, {
    value: store,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(store, NODE_ACCESSOR_PEER2, {
    value: accessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  for (const key of Object.keys(store)) {
    Object.defineProperty(accessor, key, {
      value: store[key],
      enumerable: true,
      writable: true,
      configurable: true
    });
  }
  const address = getNodeAddress(store);
  if (address) defineNodeAddress(accessor, address);
  if (positionIds && positionIds.length > 0) {
    defineOwnedPositionIds(accessor, positionIds);
  }
  if (ownerPath !== void 0) {
    defineOwnedOwnerPath(accessor, ownerPath);
  }
  if (registry) {
    definePositionRegistry(accessor, registry);
    defineOwnedOwnerId(accessor, registry.id);
    definePositionRegistry(store, registry);
    defineOwnedOwnerId(store, registry.id);
  }
  if (locations) {
    bindLocationRuntime(accessor, locations);
    bindLocationRuntime(store, locations);
  }
  return accessor;
}
var MARKER_IN_ARRAY_WARNED = /* @__PURE__ */ new Set();
var looksLikeMarker = (item) => item !== null && typeof item === "object" && (isEntityMapMarker(item) || isRegisteredMarker(item));
function warnMarkerInContainer(key, value) {
  if (false) return;
  if (MARKER_IN_ARRAY_WARNED.has(key)) return;
  let where;
  let container;
  if (Array.isArray(value)) {
    const limit = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
    for (let i = 0; i < limit; i++) {
      if (looksLikeMarker(value[i])) {
        where = `"${key}[${i}]"`;
        container = "an array. Array elements";
        break;
      }
    }
  } else if (value instanceof Map) {
    let i = 0;
    for (const [k, v] of value) {
      if (i++ >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(v)) {
        where = `"${key}" -> Map value at key ${JSON.stringify(String(k))}`;
        container = "a Map. Map values";
        break;
      }
    }
  } else if (value instanceof Set) {
    let i = 0;
    for (const member of value) {
      if (i >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(member)) {
        where = `"${key}" -> Set member #${i}`;
        container = "a Set. Set members";
        break;
      }
      i++;
    }
  }
  if (where === void 0 || container === void 0) return;
  MARKER_IN_ARRAY_WARNED.add(key);
  console.warn(
    `SignalTree: ${where} holds a MARKER inside ${container} are never traversed, so the marker is never materialised \u2014 it stays a raw object, it is not a signal, and writes to it are lost. Markers belong at object positions; for a keyed collection use entityMap({ selectId }). [ST2021]`
  );
}
function warnEntityArrayLeaf(key, value) {
  if (false) return;
  if (value.length < ENTITY_ARRAY_MIN_LENGTH) return;
  const first = value[0];
  if (first === null || typeof first !== "object" || Array.isArray(first)) {
    return;
  }
  const idKey = ENTITY_ID_KEYS.find((candidate) => {
    const v = first[candidate];
    return typeof v === "string" || typeof v === "number";
  });
  if (!idKey) return;
  const sampleSize = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
  const seen = /* @__PURE__ */ new Set();
  for (let i = 0; i < sampleSize; i++) {
    const item = value[i];
    if (item === null || typeof item !== "object" || Array.isArray(item)) {
      return;
    }
    const id = item[idKey];
    if (typeof id !== "string" && typeof id !== "number") return;
    if (seen.has(id)) return;
    seen.add(id);
  }
  const seenKey = `${key}:${idKey}`;
  if (ENTITY_ARRAY_WARNED.has(seenKey)) return;
  if (ENTITY_ARRAY_WARNED.size >= ENTITY_ARRAY_WARN_CAP) return;
  ENTITY_ARRAY_WARNED.add(seenKey);
  console.warn(
    `SignalTree: "${key}" holds ${value.length} objects with a stable "${idKey}" \u2014 use entityMap({ selectId: (e) => e.${idKey} }). An array leaf rebuilds and re-compares the whole array on every update \u2014 two orders of magnitude at 50k. Read-only or replaced wholesale? Leave it plain; otherwise model it as an entityMap. [ST2018]`
  );
}
function warnDiscardedBranchWrite(path, value) {
  if (true) {
    console.error(
      `SignalTree: write to "${path}" DISCARDED \u2014 a branch cannot be replaced by a non-object value (received ${value === null ? "null" : typeof value}). Write the leaves, or use a marker if this position should hold a value. [ST2014]`
    );
  }
}
function warnMissingForward(method) {
  if (true) {
    console.error(
      `SignalTree: "${method}" could not be forwarded \u2014 an enhancer in the configured set returned a tree without it, so this call did NOTHING. An enhancer that builds a new tree object must copy own property DESCRIPTORS, not Object.assign, which skips non-enumerable methods. [ST2017]`
    );
  }
}
var warnedNoopPaths = /* @__PURE__ */ new Set();
var warnedNoopCopyPaths = /* @__PURE__ */ new Set();
function isLargeEnoughToMatter(value) {
  if (Array.isArray(value)) return value.length >= 32;
  if (value instanceof Map || value instanceof Set) return value.size >= 32;
  return Object.keys(value).length >= 32;
}
setMemberValueApplier(
  (parent, key, member, value) => {
    if (typeof member === "function") {
      member(value);
    }
    const woke = setMemberPresence(parent, key, "active");
    if (woke) publishMembershipChange(parent);
  }
);
var ordinaryMemberBuilders = /* @__PURE__ */ new WeakMap();
function ordinaryConstructionValue(value, key) {
  if (isEntityMapMarker(value) || isRegisteredMarker(value)) {
    throw new TypeError("SignalTree: marker definitions belong in initial state, not ordinary whole-value writes.");
  }
  if (isLeafDefinition(value)) {
    const inner = leafDefinitionValue(value);
    if (isEntityMapMarker(inner) || isRegisteredMarker(inner)) {
      throw new TypeError("SignalTree: leaf() cannot wrap a semantic marker.");
    }
    return leaf(inner);
  }
  if (value === null || typeof value !== "object") return leaf(value);
  if (true) {
    if (!Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
      console.warn(
        `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
      );
    }
  }
  if (Array.isArray(value) || isBuiltInObject(value)) {
    warnMarkerInContainer(key, value);
    if (Array.isArray(value)) warnEntityArrayLeaf(key, value);
    return leaf(value);
  }
  const prepared = {};
  for (const [childKey, child] of Object.entries(value)) {
    if (childKey !== "__proto__") prepared[childKey] = ordinaryConstructionValue(child, childKey);
  }
  return prepared;
}
function prepareOrdinaryMembers(target, updates, whole) {
  const plans = /* @__PURE__ */ new Map();
  const visit = (target2, updates2, whole2) => {
    if (!updates2 || typeof updates2 !== "object") return;
    const store = isNodeAccessor(target2) ? target2[NODE_STORE_SYMBOL] : target2;
    const entries = Object.entries(updates2);
    const additions = /* @__PURE__ */ new Map();
    plans.set(store, { entries, additions });
    const build = whole2 ? ordinaryMemberBuilders.get(store) : void 0;
    for (const [key, value] of entries) {
      if (key === "__proto__") continue;
      if (build && !Object.prototype.hasOwnProperty.call(store, key)) {
        const prepared = ordinaryConstructionValue(value, key);
        additions.set(key, () => build(key, prepared));
      } else if (isNodeAccessor(store[key]) && value && typeof value === "object") {
        visit(store[key], value, true);
      }
    }
  };
  visit(target, updates, whole);
  return plans;
}
function recursiveUpdate(target, updates, out, pathPrefix = "", reconcileMembership = true, since = ++structuralWrites.stamp, prepared = prepareOrdinaryMembers(target, updates, reconcileMembership)) {
  if (!updates || typeof updates !== "object") return;
  beginStructuralWrite();
  let publishMembership;
  let applicationFailed = false;
  try {
    const targetObj = isNodeAccessor(target) ? target[NODE_STORE_SYMBOL] : target;
    const plan = prepared.get(targetObj);
    if (!plan) return;
    const { entries, additions } = plan;
    const branch = targetObj[NODE_ACCESSOR_PEER2] ?? targetObj;
    const dormant = hasDormantMembers(targetObj);
    publishMembership = reconcileMembership || dormant ? captureBranchMembershipIfObserved(
      targetObj[NODE_ACCESSOR_PEER2] ?? targetObj,
      updates,
      !reconcileMembership
    ) : void 0;
    const installed = dormant ? /* @__PURE__ */ new Set() : void 0;
    for (const [key, rawValue] of entries) {
      let value = rawValue;
      if (key === "__proto__") continue;
      if (additions.has(key) && !Object.prototype.hasOwnProperty.call(targetObj, key)) {
        const { child, responsibility } = additions.get(key)();
        inheritObservationForAddedMember(branch, child);
        installPreparedMember(branch, key, child, responsibility);
        publishMembershipChange(branch);
        installed?.add(key);
        out?.push(pathPrefix ? `${pathPrefix}.${key}` : key);
        continue;
      }
      const prop = Object.getOwnPropertyDescriptor(targetObj, key)?.value;
      const childPath = pathPrefix ? `${pathPrefix}.${key}` : key;
      if (prop === void 0) {
        if (true) {
          console.error(
            `SignalTree: write to "${childPath}" DISCARDED \u2014 key is not in the tree's initial shape. [ST2010]`
          );
        }
        continue;
      }
      const ownHydrate = structuralWrites.own;
      structuralWrites.own = prop;
      let hydrated;
      try {
        hydrated = hydrateMarkerNode(prop, value, "restore");
      } finally {
        structuralWrites.own = ownHydrate;
      }
      if (hydrated) {
        if (out) out.push(childPath);
        installed?.add(key);
        continue;
      }
      if (isNodeAccessor(prop)) {
        if (typeof value === "function") {
          const updater = value;
          value = updater(isAbsentMember(prop) ? void 0 : unwrap(prop));
          const mergeable = isTraversableNode(value) && typeof value !== "function" && !isBuiltInObject(value) && !Array.isArray(value) && typeof value.then !== "function";
          if (!mergeable) {
            warnDiscardedBranchWrite(childPath, value);
            continue;
          }
        }
        if (typeof value === "function") {
          warnDiscardedBranchWrite(childPath, value);
        } else if (value && typeof value === "object") {
          recursiveUpdate(
            prop,
            value,
            out,
            childPath,
            true,
            since,
            prepared.has(
              prop[NODE_STORE_SYMBOL]
            ) ? prepared : prepareOrdinaryMembers(prop, value, true)
          );
          installed?.add(key);
        } else if (value === void 0) {
          continue;
        } else {
          warnDiscardedBranchWrite(childPath, value);
        }
      } else if (isWritableLocation(prop) || isWritableCell(prop)) {
        const sig = prop;
        const current = readWritableCell(sig);
        if (current === value && !isAbsentMember(sig)) {
          if (value !== null && typeof value === "object" && !warnedNoopPaths.has(childPath)) {
            warnedNoopPaths.add(childPath);
            console.warn(
              `SignalTree: write at "${childPath}" was skipped \u2014 the value is reference-identical to the current value. If you mutated an object/array in place, create a NEW reference (spread/slice/map) so the change is observed. [ST2003]`
            );
          }
          continue;
        }
        const wasAbsent = out !== void 0 && isAbsentMember(sig);
        const ownWrite = structuralWrites.own;
        structuralWrites.own = sig;
        try {
          if (isWritableLocation(sig)) replaceLocation(sig, value);
          else sig.set(value);
        } finally {
          structuralWrites.own = ownWrite;
        }
        installed?.add(key);
        if (out) {
          if (wasAbsent || !Object.is(readWritableCell(sig), current))
            out.push(childPath);
        }
      }
    }
    const membershipChanged = [];
    const supplied = reconcileMembership || installed ? new Set(Object.keys(updates)) : void 0;
    if (supplied)
      for (const key of reconcileMembership ? Object.getOwnPropertyNames(targetObj) : supplied) {
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("membershipKeysVisited");
        }
        const descriptor = Object.getOwnPropertyDescriptor(targetObj, key);
        if (!descriptor || !("value" in descriptor)) continue;
        if (!supplied.has(key)) {
          if (descriptor.enumerable && // A write made while this whole value ran re-added it: it stays.
          !readdedDuringStructuralWrite(targetObj, key, since) && setMemberPresence(targetObj, key, "dormant")) {
            membershipChanged.push(key);
          }
        } else if (
          // Only a member whose supplied value was installed is re-added: a key
          // supplied as `undefined`, or with a value the loop discarded, would
          // otherwise come back with its retained storage. Measured before v16 8d:
          // `$({ a: undefined, count: 0 })` re-added an omitted `a` as `{ v: 1 }`.
          // "DORMANT STORAGE MUST NOT SUPPLY THE REACTIVATED VALUE" (case 18).
          !descriptor.enumerable && installed?.has(key) && setMemberPresence(targetObj, key, "active")
        ) {
          membershipChanged.push(key);
        }
      }
    if (membershipChanged.length > 0) {
      republishMembers(targetObj, membershipChanged);
    }
  } catch (error) {
    applicationFailed = true;
    throw error;
  } finally {
    try {
      try {
        publishMembership?.();
      } catch (error) {
        if (!applicationFailed) throw error;
        reportContainedObserverError({ error, operation: "membership:publication" });
      }
    } finally {
      endStructuralWrite();
    }
  }
}
function leafEqual(base, path) {
  return (a, b) => {
    const eq = base(a, b);
    if (eq && a !== b && a !== null && typeof a === "object" && isLargeEnoughToMatter(a) && !warnedNoopCopyPaths.has(path)) {
      warnedNoopCopyPaths.add(path);
      console.warn(
        `SignalTree: a write to "${path || "(root leaf)"}" changed NOTHING \u2014 the new value is a different object but deep-equals the current one, so the whole structure was compared and the write discarded. A re-fetched payload does this. Skip the write when the data is unchanged, or write the smaller changed leaf. [ST2027]`
      );
    }
    return eq;
  };
}
function materializeOrdinaryBranch(value, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, childPositionIds, childPath, address, preparedOrdinary = false) {
  const nested = createSignalStore(
    value,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    childPositionIds,
    childPath,
    address,
    preparedOrdinary
  );
  const accessor = makeNodeAccessor(
    nested,
    childPath,
    childPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(accessor, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(nested, scalarSlotRuntime);
  }
  return accessor;
}
function createSignalStore(obj, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, positionIds, path = "", address = [], preparedOrdinary = false) {
  for (const position of positionIds ?? []) {
    materializationContext.positionRegistry.registerPositionAddress(
      position,
      address
    );
  }
  const createLeafSignal = (value, leafPositionIds, equal) => {
    if (scalarSlotRuntime) {
      return scalarSlotRuntime.createLeaf(
        value,
        equal,
        leafPositionIds?.[0]
      );
    }
    return materializationContext.locationRuntime.createCell(value, equal);
  };
  if (obj === null || obj === void 0 || typeof obj !== "object") {
    const equal = true ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (Array.isArray(obj)) {
    const equal = true ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  if (isBuiltInObject(obj)) {
    const equal = true ? leafEqual(equalityFn, path) : equalityFn;
    const leaf2 = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf2,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf2;
  }
  const store = {};
  defineNodeAddress(store, address);
  ordinaryMemberBuilders.set(store, (key, value) => {
    const prepared = createSignalStore(
      { [key]: value },
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      positionIds,
      path,
      address,
      true
    );
    const child = prepared[key];
    const branch = store[NODE_ACCESSOR_PEER2] ?? store;
    return { child, responsibility: captureRuntime.prepareMemberResponsibility?.(branch, key, child) };
  });
  for (const [key, definedValue] of Object.entries(
    obj
  )) {
    const childAddress = childAddressOf(address, key);
    const childPath = path ? `${path}.${key}` : key;
    const terminal = isLeafDefinition(definedValue);
    const value = terminal ? leafDefinitionValue(definedValue) : definedValue;
    if (!preparedOrdinary && terminal && (isEntityMapMarker(value) || isRegisteredMarker(value))) {
      throw new Error(
        `SignalTree: leaf() cannot wrap a semantic marker at "${childPath}".`
      );
    }
    let childPositionIds;
    const getChildPositionIds = () => {
      if (!materializationContext.positionTopologyEnabled) {
        return void 0;
      }
      return childPositionIds ??= [
        materializationContext.allocatePositionId(positionIds?.[0])
      ];
    };
    if (key === "__proto__") {
      if (true) {
        console.error(
          `SignalTree: dropped a "__proto__" key from the initial state \u2014 it cannot be a state key. If this came from JSON.parse, the payload is attempting prototype pollution. [ST2016]`
        );
      }
      continue;
    }
    if (!preparedOrdinary && isEntityMapMarker(value)) {
      store[key] = value;
      continue;
    }
    if (!preparedOrdinary && isRegisteredMarker(value)) {
      store[key] = value;
      continue;
    }
    if (true) {
      if (!preparedOrdinary && !terminal && value !== null && typeof value === "object" && !Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
        console.warn(
          `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
        );
      }
    }
    if (terminal || value === null || value === void 0 || typeof value !== "object") {
      const childPositionIds2 = getChildPositionIds();
      const equal = true ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    if (Array.isArray(value) || isBuiltInObject(value)) {
      warnMarkerInContainer(key, value);
      if (Array.isArray(value)) {
        warnEntityArrayLeaf(key, value);
      }
      const childPositionIds2 = getChildPositionIds();
      const equal = true ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf2 = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf2,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf2;
      continue;
    }
    store[key] = materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      getChildPositionIds(),
      childPath,
      childAddress,
      preparedOrdinary
    );
  }
  markTreeStore(store);
  return store;
}
function create(initialState, config, materializationContext, buildPlan, captureRuntime = createMutationCaptureRuntime(), createScalarLeafRuntime = createTreeScalarLeafRuntime) {
  if (initialState === null || initialState === void 0) {
    throw new Error(SIGNAL_TREE_MESSAGES.NULL_OR_UNDEFINED);
  }
  const equalityFn = createEqualityFn(config.useShallowComparison ?? false);
  const scalarSlotRuntime = createScalarLeafRuntime(
    materializationContext.physicalCommitClock,
    materializationContext.locationRuntime
  );
  const materializeOrdinaryState = (value, path, parentPositionId, address) => {
    const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(parentPositionId)] : void 0;
    return materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      childPositionIds,
      path,
      address
    );
  };
  const constructionAuthority = {
    materialize: materializeOrdinaryState,
    bindMember: (ownerBranch) => {
      const ownerPositionId = getOwnedPositionIds(ownerBranch)?.[0];
      const ownerPath = getOwnedOwnerPath(ownerBranch) ?? "";
      const ownerAddress = getNodeAddress(ownerBranch);
      if (!ownerAddress)
        throw new Error("Missing dynamic branch construction address.");
      return (key, value) => {
        const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(ownerPositionId)] : void 0;
        const childPath = ownerPath ? `${ownerPath}.${key}` : key;
        return materializeOrdinaryBranch(
          value,
          equalityFn,
          materializationContext,
          buildPlan,
          captureRuntime,
          scalarSlotRuntime,
          childPositionIds,
          childPath,
          childAddressOf(ownerAddress, key)
        );
      };
    }
  };
  const rootPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId()] : void 0;
  const signalState = createSignalStore(
    initialState,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    rootPositionIds
  );
  const rootAccessor = makeNodeAccessor(
    signalState,
    "",
    rootPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  const tree2 = {};
  defineNodeAddress(tree2, []);
  bindLocationRuntime(tree2, materializationContext.locationRuntime);
  bindLocationRuntime(
    signalState,
    materializationContext.locationRuntime
  );
  bindLocationRuntime(
    rootAccessor,
    materializationContext.locationRuntime
  );
  tree2[MUTATION_CAPTURE_RUNTIME] = captureRuntime;
  if (rootPositionIds) {
    defineOwnedPositionIds(tree2, rootPositionIds);
    defineOwnedPositionIds(signalState, rootPositionIds);
    defineOwnedPositionIds(rootAccessor, rootPositionIds);
  }
  defineTreeCapabilities(tree2, buildPlan.capabilities);
  if (buildPlan.has("mutation-capture")) {
    defineOwnedOwnerPath(tree2, "");
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  if (materializationContext.positionTopologyEnabled) {
    definePositionRegistry(
      tree2,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      rootAccessor,
      materializationContext.positionRegistry
    );
  }
  if (materializationContext.positionRegistry) {
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  defineRootTree(rootAccessor, {
    read: () => rootAccessor(),
    replace: (value) => rootAccessor(value),
    derive: (update) => rootAccessor(update)
  });
  if (materializationContext.physicalCommitClock) {
    definePhysicalCommitClock(
      tree2,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      signalState,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      rootAccessor,
      materializationContext.physicalCommitClock
    );
  }
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(tree2, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(signalState, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(rootAccessor, scalarSlotRuntime);
  }
  const cleanupFns = [];
  const destroyedSig = materializationContext.locationRuntime.createCell(false);
  Object.defineProperty(tree2, "$", {
    value: rootAccessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree2, "destroy", {
    value: function() {
      if (destroyedSig()) return;
      try {
        replaceLocation(destroyedSig, true);
      } finally {
        terminateOwnerInvalidation(tree2);
        for (const fn of cleanupFns) {
          try {
            fn();
          } catch {
          }
        }
        cleanupFns.length = 0;
        releaseContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
      if (config.debugMode) {
        console.log(SIGNAL_TREE_MESSAGES.TREE_DESTROYED);
      }
    },
    enumerable: false,
    // Allow enhancers (like guardrails) to override/replace `destroy` at runtime.
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree2, "destroyed", {
    value: destroyedSig.asReadonly(),
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree2, "registerCleanup", {
    value: function(fn) {
      if (typeof fn === "function") {
        cleanupFns.push(fn);
      }
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree2, "clearCache", {
    value: () => {
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree2, "updateAndReport", {
    value: function(arg) {
      if (arguments.length === 0) return [];
      const out = [];
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = unwrap(signalState);
        updates = updater(current);
      }
      materializationContext.locationRuntime.runInvalidationGroup(() => {
        recursiveUpdate(signalState, updates, out, "", false);
      });
      return out;
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  return {
    tree: tree2,
    authority: constructionAuthority,
    activateReporting() {
      if (!readWritableCell(destroyedSig)) {
        registerContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
    }
  };
}
function applyEnhancers(tree2, ordered) {
  let current = tree2;
  for (const enhancer of ordered) {
    if (typeof enhancer !== "function") {
      throw new Error("Enhancer must be a function");
    }
    const result = enhancer(
      current
    );
    if (result !== current && isTraversableNode(result)) {
      current = result;
    }
  }
  return current;
}
function signalTreeImpl(initialState, config = {}, observation = NEUTRAL_OBSERVATION_ADAPTER, createScalarLeafRuntime = createTreeScalarLeafRuntime, createLocations = createLocationRuntime) {
  const declared = config.enhancers ?? [];
  const ordered = resolveEnhancerOrder(
    [...declared],
    /* @__PURE__ */ new Set(),
    Boolean(config.debugMode)
  );
  const buildPlan = buildTreePlan(ordered, config.capabilities);
  const physicalCommitClock = buildPlan.has("causal-runtime") ? createPhysicalCommitClock() : void 0;
  const captureRuntime = createMutationCaptureRuntime();
  const materializationContext = createMaterializationContext(
    buildPlan.has("position-topology"),
    (capability) => buildPlan.has(capability),
    physicalCommitClock,
    createLocations(observation)
  );
  materializationContext.mutationCaptureRuntime = captureRuntime;
  const constructed = create(
    initialState,
    config,
    materializationContext,
    buildPlan,
    captureRuntime,
    createScalarLeafRuntime
  );
  let tree2 = constructed.tree;
  const authority = constructed.authority;
  const hasEnhancers = ordered.length > 0;
  if (hasEnhancers) {
    materializeTreeMarkers(tree2, materializationContext, authority);
    Object.defineProperty(
      tree2.$,
      Symbol.for("SignalTree:SubjectPhysicalOwners"),
      {
        value: materializationContext.physicalOwners,
        enumerable: false,
        configurable: true
      }
    );
    tree2 = applyEnhancers(tree2, ordered);
  }
  const configured = createConfiguredTree(
    tree2,
    materializationContext,
    hasEnhancers,
    authority,
    config.derived
  );
  constructed.activateReporting();
  return configured;
}
function createConfiguredTree(baseTree, materializationContext, alreadyMaterialized = false, authority, derivedFactory) {
  let isFinalized = false;
  let markersMaterialized = alreadyMaterialized;
  const materializeOnly = () => {
    if (markersMaterialized) return;
    markersMaterialized = true;
    materializeMarkers(
      baseTree.$,
      void 0,
      [],
      materializationContext,
      authority
    );
    _recordTreeConstruction();
  };
  const finalize = () => {
    if (isFinalized) return;
    isFinalized = true;
    materializeOnly();
    if (derivedFactory) {
      applyDerivedFactory(
        baseTree.$,
        derivedFactory,
        materializationContext.locationRuntime
      );
    }
  };
  const rootAccessor = baseTree.$;
  Object.defineProperty(baseTree, "$", {
    get() {
      finalize();
      Object.defineProperty(baseTree, "$", {
        value: rootAccessor,
        enumerable: false,
        configurable: true
      });
      return rootAccessor;
    },
    enumerable: false,
    configurable: true
  });
  const updateAndReport = baseTree.updateAndReport?.bind(baseTree);
  Object.defineProperty(baseTree, "updateAndReport", {
    value: function(arg) {
      finalize();
      if (!updateAndReport) {
        warnMissingForward("updateAndReport");
        return [];
      }
      return updateAndReport(arg);
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  return baseTree;
}
var signalTree = signalTreeImpl;

// packages/kernel/src/lib/internals/plain-branch-membership.ts
var MEMBERSHIP = Symbol("SignalTree:PlainBranchMembership");
function plainBranchMembershipChange(meta) {
  return meta?.[MEMBERSHIP];
}
function isCollectionMember(node) {
  if (!isTraversableNode(node)) return false;
  const binding = node.__prepareTransitionTarget;
  return binding !== void 0 && binding.owner === getOwnedPositionIds(node)?.[0];
}
function capturePlainBranchMembership(branch, supplied, partial) {
  if (!hasPathObservers()) return void 0;
  const registry = getPositionRegistry(branch);
  const path = getOwnedOwnerPath(branch);
  if (!registry || path === void 0) return void 0;
  const storage = nodeStoreOf(branch) ?? branch;
  const keys = new Set(
    partial ? [...Object.keys(branch), ...Object.keys(supplied)] : Object.keys(supplied)
  );
  const before = /* @__PURE__ */ new Map();
  for (const key of Object.keys(supplied)) {
    if (key !== "__proto__" && !Object.prototype.hasOwnProperty.call(storage, key)) {
      before.set(key, { present: false });
    }
  }
  storedReads.depth++;
  try {
    for (const key of Object.getOwnPropertyNames(storage)) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("membershipKeysVisited");
      }
      const descriptor = Object.getOwnPropertyDescriptor(storage, key);
      if (!descriptor || !("value" in descriptor)) continue;
      const present = descriptor.enumerable === true;
      if (present === keys.has(key)) continue;
      if (!present && typeof descriptor.value !== "function" && !isCollectionMember(descriptor.value))
        continue;
      before.set(
        key,
        present ? {
          present: true,
          value: unwrapBranchForWriteCapture(descriptor.value)
        } : { present: false }
      );
    }
  } finally {
    storedReads.depth--;
  }
  if (before.size === 0) return void 0;
  const meta = getActiveWriteContext();
  return () => {
    const members = [];
    for (const [key, previous] of before) {
      const descriptor = Object.getOwnPropertyDescriptor(branch, key);
      const present = descriptor?.enumerable === true;
      if (present === previous.present) continue;
      if (previous.present) rememberHiddenRows(descriptor?.value);
      members.push({
        key,
        positionIds: getOwnedPositionIds(descriptor?.value),
        before: previous,
        after: present ? {
          present: true,
          value: unwrapBranchForWriteCapture(descriptor?.value)
        } : { present: false }
      });
    }
    if (members.length === 0) return;
    const notification = {
      ...meta,
      [MEMBERSHIP]: { kind: "plain-branch-membership", branch, members }
    };
    pathObservation().notify(
      path,
      void 0,
      void 0,
      path,
      void 0,
      getOwnedPositionIds(branch),
      notification,
      registry.id
    );
  };
}
function capturePathReAdd(path, outer) {
  if (!hasPathObservers()) return void 0;
  const publishers = [];
  for (let i = 0; i <= outer; i++) {
    const { parent, key } = path[i];
    publishers.push(
      capturePlainBranchMembership(parent, { [key]: true }, i === outer)
    );
  }
  return () => {
    for (const publish of publishers) publish?.();
  };
}
function applyPlainBranchMembership(previous, segments, change) {
  const apply = (value, depth) => {
    if (value === null || typeof value !== "object") return value;
    const current = value;
    const result = { ...current };
    if (depth < segments.length) {
      const key = segments[depth];
      if (!Object.prototype.hasOwnProperty.call(current, key)) return value;
      Object.defineProperty(result, key, {
        value: apply(current[key], depth + 1),
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      for (const member of change.members) {
        if (!member.after.present) {
          delete result[member.key];
        } else {
          Object.defineProperty(result, member.key, {
            value: member.after.value,
            enumerable: true,
            configurable: true,
            writable: true
          });
        }
      }
    }
    return result;
  };
  return apply(previous, 0);
}
var OMITTED_ROWS = /* @__PURE__ */ new WeakMap();
function collectionRows(node) {
  const binding = node.__prepareTransitionTarget;
  return binding?.readSource().subjects.map(
    ({ subject, key, value }) => [subject, key, value]
  ) ?? [];
}
function rememberOmittedRows(node) {
  OMITTED_ROWS.set(node, collectionRows(node));
}
function collectionsWithin(member, visit) {
  if (isCollectionMember(member)) {
    visit(member);
    return;
  }
  if (!isNodeAccessor(member)) return;
  for (const key of Object.keys(member)) {
    const child = member[key];
    if (isCollectionMember(child) || isNodeAccessor(child))
      collectionsWithin(child, visit);
  }
}
function rememberHiddenRows(member) {
  collectionsWithin(member, rememberOmittedRows);
}

// packages/kernel/src/lib/external.ts
function external(operation) {
  const ambient = getActiveWriteContext();
  const meta = { intent: "system" };
  if (ambient) {
    for (const [key, value] of Object.entries(ambient)) {
      if (value !== void 0) {
        meta[key] = value;
      }
    }
  }
  meta.origin = "external";
  meta.participation = "realized";
  const result = withWriteContext(meta, operation);
  if (typeof result?.then === "function") {
    throw new Error(
      "ST1035: an external-truth application must be synchronous. The classification is restored before the scope returns, so writes after an `await` inside it would be applied as authored work \u2014 the server value would become an undo step. Acquire first, then classify the synchronous write: `const rows = await api.getRows(); external(() => tree.$.rows.setAll(rows));`"
    );
  }
  return result;
}

// packages/kernel/src/lib/internals/write-observation-scope.ts
var maxTokens = 8;
var active = /* @__PURE__ */ new Map();
var freeze = (tokens, includesUnscoped, omitted) => Object.freeze({
  tokens: Object.freeze(tokens),
  includesUnscoped,
  omitted
});
function currentWriteObservationScopes(ownerId) {
  return ownerId === void 0 ? void 0 : active.get(ownerId);
}
function mergeWriteObservationScopes(left, right) {
  if (!left && !right) return void 0;
  const tokens = [...left?.tokens ?? []];
  let omitted = left?.omitted === true || right?.omitted === true;
  for (const token of right?.tokens ?? []) {
    if (tokens.includes(token)) continue;
    if (tokens.length < maxTokens) tokens.push(token);
    else omitted = true;
  }
  return freeze(tokens, !left || !right || left.includesUnscoped || right.includesUnscoped, omitted);
}
function withoutWriteObservationScopes(deliver) {
  if (active.size === 0) return deliver();
  const previous = active;
  active = /* @__PURE__ */ new Map();
  try {
    return deliver();
  } finally {
    active = previous;
  }
}

// packages/kernel/src/lib/internals/restoration-eligibility.ts
function isMetaDesignated(meta) {
  return meta?.restorationDesignated === true;
}
function markMetaDesignated(meta) {
  const stamped = { restorationDesignated: true };
  if (meta) {
    for (const key of Reflect.ownKeys(meta)) {
      if (!Object.prototype.propertyIsEnumerable.call(meta, key)) continue;
      const value = Reflect.get(meta, key);
      if (value !== void 0) Reflect.set(stamped, key, value);
    }
  }
  return stamped;
}
var designated = false;
function isRestorationDesignated() {
  return designated;
}

// packages/kernel/src/lib/write-participation.ts
var getWriteParticipation = (meta) => meta?.participation ?? "authored";
var isInspectionWrite = (meta) => meta?.participation === "inspection";

// packages/kernel/src/lib/path-notifier.ts
var isPlainRowRecord = (value) => {
  if (value === null || typeof value !== "object") return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === null || prototype === Object.prototype;
};
var changedSubjectFieldKeys = (before, after, subjectIds) => {
  if (subjectIds?.length !== 1 || !isPlainRowRecord(before) || !isPlainRowRecord(after)) {
    return void 0;
  }
  return [.../* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)])].filter(
    (key) => Object.prototype.hasOwnProperty.call(before, key) !== Object.prototype.hasOwnProperty.call(after, key) || !Object.is(before[key], after[key])
  );
};
var materializeDeliveryMeta = (meta) => {
  if (!meta?.structuralEffect) {
    return meta;
  }
  return {
    ...meta,
    structuralEffect: Object.freeze({ ...meta.structuralEffect })
  };
};
var PathNotifier = class _PathNotifier {
  static ownerBoundarySeparator = "\0";
  // Map of pattern -> Set of handlers
  subscribers = /* @__PURE__ */ new Map();
  // Batching state
  resetCallbacks = /* @__PURE__ */ new Set();
  batchingEnabled = true;
  batchIdentityMode = "path-position-subject";
  pendingFlush = false;
  pending = /* @__PURE__ */ new Map();
  pendingBeforeMembership = [];
  flushCallbacks = /* @__PURE__ */ new Set();
  /**
   * @internal Installed while a reversal or rollback applies
   * (`publishingExposedOnly`): true for a realized write to a location the
   * operation leaves absent, which is then not published. Path observers see
   * what the tree exposes, never retained storage (v15 c6258aab, v16 8g).
   */
  absentRealized;
  enqueueObservers = /* @__PURE__ */ new Map();
  /** @internal Owner-scoped evidence before batching can discard chronology. */
  observeEnqueue(ownerId, listener) {
    let listeners2 = this.enqueueObservers.get(ownerId);
    if (!listeners2) this.enqueueObservers.set(ownerId, listeners2 = /* @__PURE__ */ new Set());
    listeners2.add(listener);
    return () => {
      listeners2.delete(listener);
      if (listeners2.size === 0 && this.enqueueObservers.get(ownerId) === listeners2)
        this.enqueueObservers.delete(ownerId);
    };
  }
  constructor(options) {
    if (options && options.batching === false) this.batchingEnabled = false;
  }
  /**
   * Enable or disable batching at runtime (global opt-out)
   */
  setBatchingEnabled(enabled) {
    this.batchingEnabled = enabled;
  }
  isBatchingEnabled() {
    return this.batchingEnabled;
  }
  hasObservers() {
    return this.subscribers.size > 0 || this.flushCallbacks.size > 0;
  }
  /**
   * ⚠️ RETURNS VOID SINCE 15.0. It used to return `{ blocked, value }`, the
   * result protocol of the deleted delivery interceptors. The only producer —
   * `owned-mutation` — already discarded it, and no surviving caller consumed
   * it. Keeping the shape would have preserved archaeological evidence of a
   * retired mechanism as though it were a contract.
   */
  // ⚠️ `emitMutation(envelope)` WAS DELETED IN 15.0 — ME-B,
  // MUTATION-ENVELOPE-OWNERSHIP-0.
  //
  // It was a pure adapter: unpack a `MutationEnvelope` produced by exactly one
  // caller and immediately call `this.notify(...)` field-for-field. No decision
  // was made at that boundary — it joined path segments the same caller had
  // just split, and rewrapped a position id the same caller had just unwrapped.
  //
  //     ONE SEMANTIC PUBLICATION JOB, ONE PORT OPERATION.
  //
  // `owned-mutation` now calls `notify` through the port directly. Do not
  // reintroduce a parameter object BESIDE this protocol; that recreates the
  // dual-protocol problem this deletion removed. Replacing the positional
  // signature IN PLACE, derived from all producers and consumers, is admissible
  // representation cleanup — adding a second entry point is not.
  /** @internal Bench/test-only hook to isolate batching-key overhead. */
  setBatchIdentityModeForTesting(mode = "path-position-subject") {
    this.batchIdentityMode = mode;
  }
  /**
   * Subscribe to mutations matching a path pattern
   * Returns unsubscribe function
   */
  subscribe(pattern, handler) {
    if (!this.subscribers.has(pattern)) {
      this.subscribers.set(pattern, /* @__PURE__ */ new Set());
    }
    const handlers = this.subscribers.get(pattern);
    if (!handlers) {
      return () => {
      };
    }
    handlers.add(handler);
    return () => {
      handlers.delete(handler);
      if (handlers.size === 0) {
        this.subscribers.delete(pattern);
      }
    };
  }
  /**
   * Notify all subscribers matching the path
   * When batching is enabled, notifications are queued and flushed at
   * the end of the current microtask (via queueMicrotask).
   */
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    const ambientMeta = metaOverride ?? getActiveWriteContext();
    if (this.absentRealized?.(positionIds, ambientMeta)) return;
    const metaBeforeOwner = isRestorationDesignated() ? markMetaDesignated(ambientMeta) : ambientMeta;
    const meta = ownerId === void 0 ? metaBeforeOwner : { ...metaBeforeOwner ?? {}, ownerId };
    const declaredScopes = currentWriteObservationScopes(ownerId);
    const origin = meta?.origin;
    const evidenceOwner = ownerId ?? meta?.ownerId;
    const evidenceListeners = evidenceOwner === void 0 ? void 0 : this.enqueueObservers.get(evidenceOwner);
    if (evidenceListeners?.size) {
      const snapshot = Object.freeze({
        path,
        newValue: value,
        oldValue: prev,
        ownerPath,
        origin,
        ownerId: evidenceOwner,
        meta: meta ? Object.freeze({ ...materializeDeliveryMeta(meta) }) : void 0,
        positionIds: positionIds ? [...positionIds] : void 0,
        subjectIds: subjectIds ? [...subjectIds] : void 0
      });
      if (snapshot.positionIds) Object.freeze(snapshot.positionIds);
      if (snapshot.subjectIds) Object.freeze(snapshot.subjectIds);
      for (const listener of [...evidenceListeners]) {
        try {
          withoutWriteObservationScopes(() => listener(snapshot));
        } catch (error) {
          try {
            console.error("SignalTree: enqueue observation failed.", error);
          } catch {
          }
        }
      }
    }
    const fieldKeys = changedSubjectFieldKeys(prev, value, subjectIds);
    const footprintKeys = subjectFieldFootprint ?? fieldKeys;
    const knownFootprint = subjectFieldFootprint === null ? null : footprintKeys === void 0 ? void 0 : Object.freeze([...footprintKeys]);
    if (!this.batchingEnabled) {
      const deliveryMeta = materializeDeliveryMeta(meta);
      return this._runNotify(
        path,
        value,
        prev,
        ownerPath,
        origin,
        subjectIds,
        positionIds,
        deliveryMeta,
        declaredScopes,
        ownerId,
        knownFootprint
      );
    }
    const entry = {
      path,
      newValue: value,
      oldValue: prev,
      ownerPath,
      origin,
      meta,
      declaredScopes,
      subjectId: subjectIds?.[0],
      positionId: positionIds?.[0],
      ownerId,
      subjectIds,
      positionIds,
      subjectFieldKeys: fieldKeys,
      subjectFieldFootprint: knownFootprint
    };
    this.enqueuePending(entry);
    if (!this.pendingFlush) {
      this.pendingFlush = true;
      queueMicrotask(() => this.flush());
    }
    return;
  }
  /**
   * Internal synchronous notification runner (subscribers)
   */
  _runNotify(path, value, prev, ownerPath, origin, subjectIds, positionIds, meta, declaredScopes, ownerId, subjectFieldFootprint, isolateSubscribers = false) {
    const transformed = value;
    for (const [pattern, handlers] of this.subscribers) {
      if (this.matches(pattern, path)) {
        for (const handler of handlers) {
          try {
            withoutWriteObservationScopes(
              () => handler(
                transformed,
                prev,
                path,
                ownerPath,
                origin,
                subjectIds,
                positionIds,
                meta,
                declaredScopes,
                ownerId,
                subjectFieldFootprint
              )
            );
          } catch (error) {
            if (!isolateSubscribers) throw error;
            reportContainedObserverError({
              error,
              operation: "notify:subscriber",
              // Entity and compensation writes name their tree in meta only.
              treeId: ownerId ?? meta?.ownerId,
              path
            });
          }
        }
      }
    }
    return;
  }
  /**
   * Flush pending batched notifications immediately.
   * This is re-entrant safe and will process notifications queued during
   * subscriber callbacks in subsequent rounds.
   */
  flush() {
    const toNotify = [
      ...this.pendingBeforeMembership,
      ...this.pending.values()
    ];
    this.pendingBeforeMembership = [];
    this.pending.clear();
    this.pendingFlush = false;
    for (const slot of toNotify) {
      const entries = Array.isArray(slot) ? slot : [slot];
      for (const entry of entries) {
        const isOwnerOnlyMarkerSignal = entry.ownerPath !== void 0 && entry.newValue === void 0 && entry.oldValue === void 0;
        const hasStructuralEffect = entry.meta?.structuralEffect !== void 0;
        if (entry.newValue === entry.oldValue && !isOwnerOnlyMarkerSignal && !hasStructuralEffect) {
          continue;
        }
        this._runNotify(
          entry.path,
          entry.newValue,
          entry.oldValue,
          entry.ownerPath,
          entry.origin,
          entry.subjectIds,
          entry.positionIds,
          materializeDeliveryMeta(entry.meta),
          entry.declaredScopes,
          entry.ownerId,
          entry.subjectFieldFootprint,
          true
        );
      }
    }
    for (const cb of Array.from(this.flushCallbacks)) {
      try {
        withoutWriteObservationScopes(cb);
      } catch {
      }
    }
  }
  /**
   * Force synchronous flush of pending notifications
   */
  flushSync() {
    while (this.hasPending() || this.pendingFlush) {
      if (this.pendingFlush && !this.hasPending()) {
        this.pendingFlush = false;
        break;
      }
      this.flush();
    }
  }
  /**
   * Subscribe to flush events (called after a flush completes)
   */
  onFlush(callback) {
    this.flushCallbacks.add(callback);
    return () => this.flushCallbacks.delete(callback);
  }
  /** Internal evidence only: never drains the queue or invokes observers.
   * Include net-equal entries: an ABA write still changed ownership.
   */
  readPending() {
    return [...this.pendingBeforeMembership, ...this.pending.values()].flatMap(
      (slot) => (Array.isArray(slot) ? slot : [slot]).map((entry) => ({
        ...entry,
        subjectFieldKeys: entry.subjectFieldKeys ? [...entry.subjectFieldKeys] : void 0
      }))
    );
  }
  /**
   * Check if there are pending notifications
   */
  hasPending() {
    return this.pending.size > 0 || this.pendingBeforeMembership.length > 0;
  }
  /**
   * Simple pattern matching
   * - 'users' matches exactly 'users'
   * - 'users.*' matches 'users.u1', 'users.u2', etc.
   * - '**' matches everything
   */
  matches(pattern, path) {
    if (pattern === "**") return true;
    if (pattern === path) return true;
    if (pattern.endsWith(".*")) {
      const prefix = pattern.slice(0, -2);
      return path.startsWith(prefix + ".");
    }
    return false;
  }
  enqueuePending(entry) {
    if (plainBranchMembershipChange(entry.meta)) {
      for (const slot of this.pending.values())
        this.pendingBeforeMembership.push(slot);
      this.pendingBeforeMembership.push(entry);
      this.pending.clear();
      return;
    }
    const path = entry.path;
    const existing = this.pending.get(path);
    if (!existing) {
      this.pending.set(path, entry);
      return;
    }
    if (this.batchIdentityMode === "path") {
      if (Array.isArray(existing)) {
        const tail = existing[existing.length - 1];
        if (this.hasSameSemanticIdentity(tail, entry)) {
          this.coalesceEntry(tail, entry);
          return;
        }
        existing.push(entry);
        return;
      }
      if (this.hasSameSemanticIdentity(existing, entry)) {
        this.coalesceEntry(existing, entry);
        return;
      }
      this.pending.set(path, [existing, entry]);
      return;
    }
    if (this.batchIdentityMode === "path-position-subject-composite") {
      this.enqueuePendingComposite(entry);
      return;
    }
    if (Array.isArray(existing)) {
      const tail = existing[existing.length - 1];
      if (this.hasSameSemanticIdentity(tail, entry)) {
        this.coalesceEntry(tail, entry);
        return;
      }
      existing.push(entry);
      return;
    }
    if (this.hasSameSemanticIdentity(existing, entry)) {
      this.coalesceEntry(existing, entry);
      return;
    }
    this.pending.set(path, [existing, entry]);
  }
  enqueuePendingComposite(entry) {
    const compositeKey = this.getCompositeBatchKey(entry);
    const existing = this.pending.get(compositeKey);
    if (!existing) {
      this.pending.set(compositeKey, entry);
      return;
    }
    const target = Array.isArray(existing) ? existing[0] : existing;
    this.coalesceEntry(target, entry);
  }
  hasSameSemanticIdentity(left, right) {
    if (this.crossesStructuralBoundary(left, right)) {
      return false;
    }
    if (this.crossesScalarIntentBoundary(left, right)) {
      return false;
    }
    if (this.crossesCausalModeBoundary(left, right)) {
      return false;
    }
    if ((left.ownerId ?? left.meta?.ownerId) !== (right.ownerId ?? right.meta?.ownerId)) {
      return false;
    }
    if (this.batchIdentityMode === "path-position") {
      return left.positionId === right.positionId;
    }
    return left.positionId === right.positionId && left.subjectId === right.subjectId;
  }
  crossesStructuralBoundary(left, right) {
    const leftEffect = left.meta?.structuralEffect;
    const rightEffect = right.meta?.structuralEffect;
    const leftStructural = leftEffect !== void 0;
    const rightStructural = rightEffect !== void 0;
    if (leftStructural !== rightStructural) {
      return true;
    }
    if (leftStructural && rightStructural && leftEffect.kind !== rightEffect.kind) {
      return true;
    }
    return false;
  }
  crossesScalarIntentBoundary(left, right) {
    const leftIntent = left.meta?.mutationIntent;
    const rightIntent = right.meta?.mutationIntent;
    return leftIntent !== void 0 && rightIntent !== void 0 && leftIntent !== rightIntent;
  }
  crossesCausalModeBoundary(left, right) {
    return getWriteParticipation(left.meta) !== getWriteParticipation(right.meta) || left.origin !== right.origin || left.meta?.transactionId !== right.meta?.transactionId || left.meta?.transactionOwner !== right.meta?.transactionOwner;
  }
  coalesceEntry(target, next) {
    target.subjectFieldFootprint = target.subjectFieldFootprint === void 0 || next.subjectFieldFootprint === void 0 ? void 0 : target.subjectFieldFootprint === null || next.subjectFieldFootprint === null ? null : Object.freeze([
      .../* @__PURE__ */ new Set([
        ...target.subjectFieldFootprint,
        ...next.subjectFieldFootprint
      ])
    ]);
    target.subjectFieldKeys = target.subjectFieldKeys !== void 0 && next.subjectFieldKeys !== void 0 ? [.../* @__PURE__ */ new Set([...target.subjectFieldKeys, ...next.subjectFieldKeys])] : void 0;
    target.declaredScopes = mergeWriteObservationScopes(
      target.declaredScopes,
      next.declaredScopes
    );
    target.newValue = next.newValue;
    target.ownerPath = next.ownerPath;
    target.origin = this.mergeOrigin(target.origin, next.origin);
    target.meta = this.mergeMeta(target.meta, next.meta);
    target.subjectId = next.subjectId;
    target.positionId = next.positionId;
    target.subjectIds = next.subjectIds;
    target.positionIds = next.positionIds;
  }
  mergeOrigin(left, right) {
    if (!left && !right) return void 0;
    if (left === right) return left;
    return "mixed";
  }
  mergeMeta(left, right) {
    if (!left && !right) {
      return void 0;
    }
    if (!left || !right) {
      return void 0;
    }
    if (left.origin !== right.origin) {
      return void 0;
    }
    if (left.transactionId !== right.transactionId || left.transactionOwner !== right.transactionOwner || left.mutationIntent !== right.mutationIntent || getWriteParticipation(left) !== getWriteParticipation(right)) {
      return void 0;
    }
    const merged = left.structuralEffect && !right.structuralEffect ? { ...right, structuralEffect: left.structuralEffect } : right;
    return isMetaDesignated(left) ? { ...merged, ...markMetaDesignated(void 0) } : merged;
  }
  getCompositeBatchKey(entry) {
    const positionKey = entry.positionIds?.join(",") ?? "";
    const subjectKey = entry.subjectIds?.join(",") ?? "";
    const participation = getWriteParticipation(entry.meta);
    return `${entry.path}${_PathNotifier.ownerBoundarySeparator}${positionKey}${_PathNotifier.ownerBoundarySeparator}${subjectKey}${_PathNotifier.ownerBoundarySeparator}${participation}`;
  }
  /**
   * Clear all subscribers
   */
  clear() {
    this.subscribers.clear();
    this.pending.clear();
    this.pendingBeforeMembership = [];
    this.pendingFlush = false;
  }
  /** Reset queued runtime state but preserve registered listeners. */
  onReset(callback) {
    this.resetCallbacks.add(callback);
    return () => this.resetCallbacks.delete(callback);
  }
  emitReset() {
    for (const cb of Array.from(this.resetCallbacks)) {
      try {
        withoutWriteObservationScopes(cb);
      } catch {
      }
    }
  }
  /**
   * Get count of active subscribers (for debugging)
   */
  getSubscriberCount() {
    let count = 0;
    for (const handlers of this.subscribers.values()) {
      count += handlers.size;
    }
    return count;
  }
};
var globalPathNotifier = null;
function getPathNotifier() {
  if (!globalPathNotifier) {
    globalPathNotifier = new PathNotifier();
  }
  installPathDeliveryRuntime(globalPathNotifier);
  installBranchMembershipCapture(
    capturePlainBranchMembership,
    capturePathReAdd
  );
  return globalPathNotifier;
}

// packages/kernel/src/lib/internals/link-state-source.ts
var SLOTS = /* @__PURE__ */ new WeakMap();
function getLinkStateSlot(registry) {
  let slot = SLOTS.get(registry);
  if (!slot) SLOTS.set(registry, slot = { next: 1, links: /* @__PURE__ */ new Map() });
  return slot;
}
function registerLinkState(registry, source, path, endpoint, activity) {
  const slot = getLinkStateSlot(registry);
  const record = {
    id: slot.next++,
    source,
    path,
    endpoint,
    activity
  };
  slot.links.set(record.id, record);
  return (kind) => {
    if (!slot.links.has(record.id)) return;
    if (kind === null || kind === "disposed") slot.links.delete(record.id);
    if (kind !== null) slot.observer?.(record, kind);
  };
}

// packages/kernel/src/lib/internals/source-mutation.ts
function applyAtRelativePath(previous, segments, value) {
  return setAtPath(previous, segments, value);
}
function relativeSourceAddress(source, address) {
  if (source.length > address.length) return void 0;
  if (!source.every((segment, index) => segment === address[index]))
    return void 0;
  return address.slice(source.length);
}
function setAtPath(node, segments, value) {
  if (segments.length === 0) return value;
  const [head, ...rest] = segments;
  const base = node ?? {};
  return { ...base, [head]: setAtPath(base[head], rest, value) };
}
function createEntityTopology(seed) {
  let order = [];
  const keys = /* @__PURE__ */ new Map();
  function reload(entries) {
    order = [];
    keys.clear();
    for (const e of entries) {
      order.push(e.subjectId);
      keys.set(e.subjectId, e.key);
    }
  }
  reload(seed);
  return {
    reload,
    reorder: (afterSubjects) => {
      order = [...afterSubjects];
    },
    keyOf: (subject) => keys.get(subject),
    has: (subject) => order.includes(subject),
    observe(effect) {
      if (effect.kind === "add") {
        if (order.includes(effect.subject)) return;
        if (effect.key !== void 0) keys.set(effect.subject, effect.key);
        if (effect.beforeSubject !== void 0) {
          const i = order.indexOf(effect.beforeSubject);
          if (i !== -1) return void order.splice(i + 1, 0, effect.subject);
        }
        if (effect.afterSubject !== void 0) {
          const i = order.indexOf(effect.afterSubject);
          if (i !== -1) return void order.splice(i, 0, effect.subject);
        }
        order.push(effect.subject);
        return;
      }
      if (effect.kind === "remove") {
        const i = order.indexOf(effect.subject);
        if (i !== -1) order.splice(i, 1);
        keys.delete(effect.subject);
        return;
      }
      if (effect.afterKey !== void 0)
        keys.set(effect.subject, effect.afterKey);
    },
    placement(subject, isIncluded) {
      const at = order.indexOf(subject);
      if (at !== -1) {
        for (let j = at - 1; j >= 0; j--) {
          if (isIncluded(order[j])) return { after: order[j] };
        }
        for (let j = at + 1; j < order.length; j++) {
          if (isIncluded(order[j])) return { before: order[j] };
        }
      }
      return "end";
    }
  };
}

// packages/kernel/src/lib/internals/entity-egress-projection.ts
function projectEntityFields(previous, row, fields) {
  if (fields === null) return row;
  if (!fields?.length || !row || typeof row !== "object") return previous;
  const next = { ...previous };
  for (const key of fields) {
    if (Object.prototype.hasOwnProperty.call(row, key)) {
      Object.defineProperty(next, key, {
        value: row[key],
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else delete next[key];
  }
  return next;
}
function createEntityEgressProjection(seed) {
  let topology = createEntityTopology(seed);
  let order = [];
  const rows = /* @__PURE__ */ new Map();
  const keyOf = /* @__PURE__ */ new Map();
  function load(entries) {
    order = [];
    rows.clear();
    keyOf.clear();
    for (const e of entries) {
      order.push(e.subjectId);
      rows.set(e.subjectId, e.row);
      keyOf.set(e.subjectId, e.key);
    }
  }
  load(seed);
  const isEligible = (s) => rows.has(s);
  function place(subject) {
    if (order.includes(subject)) return;
    const at = topology.placement(subject, isEligible);
    if (at === "end") return void order.push(subject);
    if ("after" in at)
      return void order.splice(order.indexOf(at.after) + 1, 0, subject);
    order.splice(order.indexOf(at.before), 0, subject);
  }
  function remove(subject) {
    const i = order.indexOf(subject);
    if (i !== -1) order.splice(i, 1);
    rows.delete(subject);
    keyOf.delete(subject);
  }
  function reconcileAddress(key, incoming) {
    if (key === void 0) return;
    for (const [subject, held] of keyOf) {
      if (held !== key || subject === incoming) continue;
      if (!topology.has(subject)) remove(subject);
      return;
    }
  }
  return {
    value: () => order.map((s) => rows.get(s)),
    reorder(afterSubjects, inspection) {
      topology.reorder(afterSubjects);
      if (inspection) return false;
      const present = new Set(afterSubjects);
      const eligible = afterSubjects.filter(isEligible);
      let cursor = 0;
      let changed = false;
      order = order.map((subject) => {
        if (!present.has(subject)) return subject;
        const next = eligible[cursor++];
        if (next !== subject) changed = true;
        return next;
      });
      return changed;
    },
    reseed(entries) {
      topology = createEntityTopology(entries);
      load(entries);
    },
    apply(subjectId, row, effect, inspection, fields) {
      if (effect) topology.observe(effect);
      if (inspection) return false;
      if (effect?.kind === "add") {
        reconcileAddress(effect.key, effect.subject);
        place(effect.subject);
        rows.set(effect.subject, effect.value);
        if (effect.key !== void 0) keyOf.set(effect.subject, effect.key);
        return true;
      }
      if (effect?.kind === "remove") {
        if (!isEligible(effect.subject)) return false;
        remove(effect.subject);
        return true;
      }
      if (effect?.kind === "rekey") {
        if (!isEligible(effect.subject)) return false;
        if (effect.afterKey !== void 0)
          keyOf.set(effect.subject, effect.afterKey);
        return true;
      }
      if (subjectId === void 0) return false;
      if (isEligible(subjectId)) {
        const previous = rows.get(subjectId);
        const next = projectEntityFields(previous, row, fields);
        if (next === previous) return false;
        rows.set(subjectId, next);
        return true;
      }
      if (fields === void 0) return false;
      if (!isEligible(subjectId)) {
        if (!topology.has(subjectId)) return false;
        const k = topology.keyOf(subjectId);
        reconcileAddress(k, subjectId);
        place(subjectId);
        if (k !== void 0) keyOf.set(subjectId, k);
      }
      rows.set(subjectId, row);
      return true;
    }
  };
}

// packages/kernel/src/lib/internals/commit-consequence.ts
var scopesByOwner = /* @__PURE__ */ new WeakMap();
var openScopesByKey = /* @__PURE__ */ new WeakMap();
var heldByKey = /* @__PURE__ */ new WeakMap();
function resolveScopeKey(node) {
  if (node === void 0 || node === null) return void 0;
  const candidate = node;
  const registry = getPositionRegistry(candidate.$ ?? node) ?? getPositionRegistry(node);
  return registry ?? node;
}
function hasOpen(key) {
  const scopes = openScopesByKey.get(key);
  return scopes !== void 0 && scopes.size > 0;
}
function scopeOwns(scope, claimant) {
  if (!scope.key) return true;
  if (claimant === void 0) return false;
  return resolveScopeKey(claimant) === scope.key;
}
function deferCommitConsequence(owner, transactionId, key, fn, claimant) {
  const scope = scopesByOwner.get(owner)?.get(transactionId);
  if (!scope) return false;
  if (!scopeOwns(scope, claimant)) return false;
  scope.consequences.set(key, fn);
  return true;
}
function scheduleDurableConsequence(request) {
  const { claimant, key, run } = request;
  const meta = getActiveWriteContext();
  const owner = meta?.transactionOwner;
  const transactionId = meta?.transactionId;
  if (owner !== void 0 && typeof transactionId === "number" && deferCommitConsequence(owner, transactionId, key, run, claimant)) {
    return;
  }
  const scopeKey = resolveScopeKey(claimant);
  if (scopeKey && hasOpen(scopeKey)) {
    let held = heldByKey.get(scopeKey);
    if (!held) {
      held = /* @__PURE__ */ new Map();
      heldByKey.set(scopeKey, held);
    }
    held.set(key, run);
    return;
  }
  run();
}
function withdrawHeldConsequence(claimant, key) {
  const scopeKey = resolveScopeKey(claimant);
  if (scopeKey) heldByKey.get(scopeKey)?.delete(key);
}

// packages/kernel/src/lib/link.ts
function accessorsFor(x) {
  const node = x;
  const rootTree = getRootTree(x);
  if (rootTree) {
    return {
      read: () => rootTree.read(),
      write: (v) => rootTree.replace(v),
      collection: false
    };
  }
  if (isNodeAccessor(x)) {
    return {
      read: () => x(),
      write: (value) => x(value),
      collection: false
    };
  }
  const all = node.all;
  const setAll = node.setAll;
  if (typeof all === "function" && typeof setAll === "function") {
    return {
      read: () => all(),
      write: (v) => setAll(v),
      collection: true
    };
  }
  if (isWritableLocation(x)) {
    return {
      read: () => x(),
      write: (value) => replaceLocation(x, value),
      collection: false
    };
  }
  return {
    read: () => x(),
    write: (v) => x(v),
    collection: false
  };
}
function link(source, endpoint) {
  const x = source;
  const registry = getPositionRegistry(x);
  if (!registry) {
    throw new Error(
      "link: X must be an owned SignalTree location. A bare signal() or computed() has no owning tree, so there is nothing to settle against."
    );
  }
  if (!endpoint.get && !endpoint.set && !endpoint.subscribe) {
    throw new Error(
      "link: the endpoint must supply at least one of get, set or subscribe \u2014 a link with no direction synchronizes nothing."
    );
  }
  const { read, write, collection } = accessorsFor(x);
  const entityLocation = getEntityLocationBinding(x);
  const sourceAddress = getNodeAddress(x);
  if (!entityLocation && sourceAddress === void 0) {
    throw new Error("link: the owned source has no structured address.");
  }
  const releaseObservation = acquireObservation(x);
  const ownerPath = getOwnedOwnerPath(x) ?? "";
  const notifier = getPathNotifier();
  let knownY;
  let disposed = false;
  let dirty = false;
  let chain = Promise.resolve();
  let inboundSeq = 0;
  let eligible = read();
  const entityProjection = collection ? createEntityEgressProjection(getEntityProjectionSeed(x) ?? []) : void 0;
  const nestedCollections = /* @__PURE__ */ new Map();
  const collectionSources = /* @__PURE__ */ new Map();
  if (entityProjection) collectionSources.set(x, entityProjection);
  if (!collection && !entityLocation) {
    const discover = (node) => {
      if (!isTraversableNode(node)) return;
      const seed = getEntityProjectionSeed(node);
      if (seed) {
        const position = getOwnedPositionIds(node)?.[0];
        const address = position === void 0 ? void 0 : registry.addressFor(position);
        const relative = sourceAddress !== void 0 && address !== void 0 ? relativeSourceAddress(sourceAddress, address) : void 0;
        if (position === void 0 || relative === void 0) return;
        const projection = createEntityEgressProjection(seed);
        nestedCollections.set(position, {
          node,
          projection,
          relativeAddress: relative
        });
        collectionSources.set(node, projection);
        return;
      }
      for (const key of Object.keys(node)) {
        discover(node[key]);
      }
    };
    discover(x);
  }
  const advanceNested = (nested) => {
    eligible = applyAtRelativePath(eligible, nested.relativeAddress, {
      all: nested.projection.value()
    });
  };
  const held = /* @__PURE__ */ new Set();
  const consequenceKey = {};
  const sendConsequenceKey = {};
  const waitingSends = /* @__PURE__ */ new Set();
  const settlementWaiters = /* @__PURE__ */ new Set();
  const pendingOrders = /* @__PURE__ */ new Set();
  const retrievals = /* @__PURE__ */ new Set();
  let queued = 0;
  let sending = false;
  const observeLink = registerLinkState(
    registry,
    x,
    ownerPath,
    endpoint,
    () => [
      dirty,
      held.size > 0 || waitingSends.size > 0,
      queued,
      sending,
      retrievals.size,
      disposed
    ]
  );
  const acquire = (value, seq) => {
    if (disposed || seq < inboundSeq) return;
    inboundSeq = seq;
    knownY = { value };
    eligible = value;
    external(() => write(value));
    if (entityProjection) {
      entityProjection.reseed(getEntityProjectionSeed(x) ?? []);
    }
  };
  const offSub = notifier.subscribe(
    "**",
    (v, prev, _path, _o, _origin, subjectIds, _pos, meta, _scopes, _owner, fields) => {
      if (disposed || !endpoint.set) return;
      const m = meta ?? {};
      if (m["ownerId"] !== registry.id) return;
      const membership = plainBranchMembershipChange(meta);
      if (membership) {
        if (entityLocation || isInspectionWrite(meta)) return;
        const address2 = getNodeAddress(membership.branch);
        const relative2 = sourceAddress !== void 0 && address2 !== void 0 ? relativeSourceAddress(sourceAddress, address2) : void 0;
        if (relative2 !== void 0) {
          eligible = applyPlainBranchMembership(eligible, relative2, membership);
        } else {
          const below = sourceAddress !== void 0 && address2 !== void 0 ? relativeSourceAddress(address2, sourceAddress) : void 0;
          const member = below?.length && membership.members.find(({ key }) => key === below[0]);
          if (!member || !below) return;
          let value = member.after.present ? member.after.value : void 0;
          for (const key of below.slice(1))
            value = value !== null && typeof value === "object" && Object.prototype.hasOwnProperty.call(value, key) ? value[key] : void 0;
          eligible = value;
          entityProjection?.reseed(getEntityProjectionSeed(x) ?? []);
        }
        for (const nested2 of nestedCollections.values()) {
          if (relative2 !== void 0 && !membership.members.some(
            ({ key }) => nested2.relativeAddress[relative2.length] === key && relative2.every(
              (step, at2) => nested2.relativeAddress[at2] === step
            )
          ))
            continue;
          nested2.projection.reseed(getEntityProjectionSeed(nested2.node) ?? []);
          let at = eligible;
          for (const key of nested2.relativeAddress.slice(0, -1))
            at = at !== null && typeof at === "object" ? at[key] : void 0;
          if (at !== null && typeof at === "object" && Object.prototype.hasOwnProperty.call(
            at,
            nested2.relativeAddress[nested2.relativeAddress.length - 1]
          ))
            advanceNested(nested2);
        }
        dirty = true;
        observeLink();
        return;
      }
      if (v === void 0 && prev === void 0) return;
      if (entityLocation) {
        if (_pos?.[0] !== entityLocation.owner || subjectIds?.[0] !== entityLocation.subjectId || isInspectionWrite(meta))
          return;
        const effect = meta?.structuralEffect;
        if (effect?.kind === "rekey") return;
        const removed = effect?.kind === "remove";
        const footprint = effect?.kind === "add" ? null : fields;
        if (!removed && footprint === void 0) return;
        if (entityLocation.fieldKey !== void 0) {
          if (!removed && footprint !== null && !footprint?.includes(entityLocation.fieldKey))
            return;
          eligible = v != null && Object.prototype.hasOwnProperty.call(v, entityLocation.fieldKey) ? v[entityLocation.fieldKey] : void 0;
        } else {
          const next = removed ? void 0 : projectEntityFields(eligible, v, footprint);
          if (next === eligible) return;
          eligible = next;
        }
        dirty = true;
        observeLink();
        return;
      }
      const position = _pos?.[0];
      const address = position === void 0 ? void 0 : registry.addressFor(position);
      const relative = sourceAddress !== void 0 && address !== void 0 ? relativeSourceAddress(sourceAddress, address) : void 0;
      if (relative === void 0) return;
      const inspection = isInspectionWrite(meta);
      const nested = position === void 0 ? void 0 : nestedCollections.get(position);
      if (nested) {
        const effect = meta?.["structuralEffect"];
        const advanced = nested.projection.apply(
          subjectIds?.[0],
          v,
          effect,
          inspection,
          fields
        );
        if (advanced) {
          advanceNested(nested);
          dirty = true;
          observeLink();
        }
        return;
      }
      if (entityProjection) {
        const effect = meta?.["structuralEffect"];
        const advanced = entityProjection.apply(
          subjectIds?.[0],
          v,
          effect,
          inspection,
          fields
        );
        if (advanced) {
          dirty = true;
          observeLink();
        }
        return;
      }
      if (inspection) return;
      eligible = applyAtRelativePath(eligible, relative, v);
      dirty = true;
      observeLink();
    }
  );
  const sendEligible = () => new Promise((resolve, reject) => {
    const cancel = () => {
      waitingSends.delete(cancel);
      resolve(false);
    };
    waitingSends.add(cancel);
    const attempt = () => {
      if (disposed) {
        cancel();
        return;
      }
      let synchronous = true;
      try {
        const now = entityProjection ? entityProjection.value() : eligible;
        if (knownY !== void 0 && deepEqual(now, knownY.value)) {
          cancel();
          return;
        }
        scheduleDurableConsequence({
          claimant: x,
          key: sendConsequenceKey,
          run: () => {
            if (!synchronous) {
              queueMicrotask(attempt);
              return;
            }
            waitingSends.delete(cancel);
            sending = true;
            observeLink();
            if (disposed) {
              sending = false;
              resolve(false);
              return;
            }
            try {
              Promise.resolve(endpoint.set?.(now)).then(
                () => {
                  sending = false;
                  knownY = { value: now };
                  resolve(true);
                },
                (error) => {
                  sending = false;
                  reject(error);
                }
              );
            } catch (error) {
              sending = false;
              reject(error);
            }
          }
        });
        if (waitingSends.has(cancel)) observeLink();
      } catch (error) {
        waitingSends.delete(cancel);
        reject(error);
      } finally {
        synchronous = false;
      }
    };
    attempt();
  });
  const flushOutbound = () => {
    if (disposed || !dirty) return;
    dirty = false;
    let entry = held.values().next().value;
    if (!entry) {
      let resolve;
      const promise = new Promise((r) => resolve = r);
      entry = { promise, resolve };
      held.add(entry);
    }
    const pending = entry;
    scheduleDurableConsequence({
      claimant: x,
      key: consequenceKey,
      run: () => {
        held.delete(pending);
        pending.resolve();
        if (disposed) return;
        queued++;
        chain = chain.then(async () => {
          queued--;
          try {
            for (; ; ) {
              if (disposed) return;
              if (!await sendEligible()) return;
            }
          } finally {
            observeLink();
          }
        }).catch((error) => {
          observeLink("send-failed");
          reportTreeError({
            error,
            operation: "link:set",
            treeId: registry.id,
            // ⚠️ `ownerPath` was already known here and previously dropped.
            // Location, never identity — two trees share this string.
            path: ownerPath === "" ? void 0 : ownerPath
          });
        });
        observeLink();
      }
    });
    observeLink();
  };
  const offFlush = notifier.onFlush?.(flushOutbound);
  const releaseOrders = [];
  for (const [node, projection] of collectionSources) {
    const capture = getMutationCaptureRuntime(node);
    if (!capture?.subscribeCollectionOrder) continue;
    const releaseCapture = capture.activateCapture();
    const offOrder = capture.subscribeCollectionOrder((order) => {
      if (disposed || order.owner !== getOwnedPositionIds(node)?.[0]) return;
      const inspection = isInspectionWrite(order.meta);
      let resolve;
      const promise = new Promise((r) => resolve = r);
      const pending = { promise, resolve };
      pendingOrders.add(pending);
      queueMicrotask(() => {
        try {
          if (disposed || !projection.reorder(order.afterSubjects, inspection))
            return;
          if (projection !== entityProjection) {
            const nested = nestedCollections.get(order.owner);
            if (nested) advanceNested(nested);
          }
          dirty = true;
          observeLink();
          flushOutbound();
        } finally {
          pendingOrders.delete(pending);
          pending.resolve();
        }
      });
    });
    releaseOrders.push(() => {
      offOrder();
      releaseCapture();
    });
  }
  let offSource;
  const dispose = () => {
    if (disposed) return;
    disposed = true;
    releaseObservation();
    offSub();
    offFlush?.();
    withdrawHeldConsequence(x, consequenceKey);
    withdrawHeldConsequence(x, sendConsequenceKey);
    for (const release of releaseOrders) release();
    for (const h of held) h.resolve();
    held.clear();
    for (const cancel of waitingSends) cancel();
    waitingSends.clear();
    for (const release of settlementWaiters) release();
    settlementWaiters.clear();
    for (const order of pendingOrders) order.resolve();
    pendingOrders.clear();
    for (const r of retrievals) r.resolve();
    retrievals.clear();
    observeLink("disposed");
    offSource?.();
  };
  try {
    offSource = endpoint.subscribe?.((v) => acquire(v, ++inboundSeq));
  } catch (error) {
    observeLink(null);
    dispose();
    throw error;
  }
  observeLink("created");
  return {
    async retrieve() {
      if (!endpoint.get) {
        throw new Error("link: endpoint supplies no get().");
      }
      const seq = ++inboundSeq;
      let resolve;
      const promise = new Promise((r) => resolve = r);
      const entry = { promise, resolve };
      retrievals.add(entry);
      observeLink();
      try {
        if (disposed) return;
        acquire(await endpoint.get(), seq);
      } catch (error) {
        observeLink("retrieve-failed");
        throw error;
      } finally {
        retrievals.delete(entry);
        entry.resolve();
        observeLink();
      }
    },
    async settled() {
      for (; ; ) {
        if (disposed) return;
        if (retrievals.size > 0) {
          await Promise.race([...retrievals].map((r) => r.promise));
          continue;
        }
        const awaitedChain = chain;
        await new Promise((resolve, reject) => {
          const release = () => {
            settlementWaiters.delete(release);
            resolve();
          };
          settlementWaiters.add(release);
          void awaitedChain.then(release, (error) => {
            settlementWaiters.delete(release);
            reject(error);
          });
        });
        if (disposed) return;
        if (retrievals.size > 0) continue;
        if (pendingOrders.size > 0) {
          await Promise.race([...pendingOrders].map((order) => order.promise));
          continue;
        }
        if (chain !== awaitedChain) continue;
        if (held.size === 0) {
          if (!notifier.hasPending()) break;
          await new Promise((resolve) => {
            const off = notifier.onFlush(() => {
              off();
              resolve();
            });
          });
          continue;
        }
        await Promise.race([...held].map((h) => h.promise));
      }
    },
    dispose
  };
}

// ../../../../../../private/tmp/readiness-review-partial-link.ts
var tree = signalTree({ trigger: [{ x: 0 }] });
var sent = [];
var relationship = link(tree.$, { set: (value) => {
  sent.push(value);
} });
console.log("prime", JSON.stringify(tree.$()));
try {
  tree.$({ fresh: 123, trigger: [{ get x() {
    throw Error("equality failure");
  } }] });
} catch (e) {
  console.log(String(e));
}
console.log("held fresh", tree.$.fresh?.(), "snapshot", JSON.stringify(tree.$()), "keys", Object.keys(tree.$));
getPathNotifier().flushSync();
for (let i = 0; i < 12; i++) await Promise.resolve();
await relationship.settled();
console.log("sent", sent);
relationship.dispose();
tree.destroy();
