// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/production-substrate-stats.ts
var PRODUCTION_SUBSTRATE_STATS_ENABLED = true;
var activeStats;
function recordProductionSubstrateStat(counter, delta = 1) {
  if (!activeStats) {
    return;
  }
  activeStats[counter] += delta;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/cell-identity.ts
var CELL_MARK = Symbol("SignalTree:Cell");
function markTreeCell(cell) {
  Object.defineProperty(cell, CELL_MARK, {
    value: true,
    enumerable: false,
    writable: false,
    configurable: true
  });
  return cell;
}
function isTreeCell(value) {
  return typeof value === "function" && value[CELL_MARK] === true;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/leaf.ts
var LEAF_DEFINITION = Symbol.for("SignalTree:LeafDefinition");
function isLeafDefinition(value) {
  return typeof value === "object" && value !== null && Object.prototype.hasOwnProperty.call(value, LEAF_DEFINITION) && Object.getOwnPropertyDescriptor(value, LEAF_DEFINITION)?.enumerable === false;
}
function leafDefinitionValue(definition) {
  return definition[LEAF_DEFINITION];
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/observation-adapter.ts
var NEUTRAL_OBSERVATION_ADAPTER = {
  createToken: () => ({
    observe: () => void 0,
    invalidate: () => void 0
  }),
  runInvalidationGroup: (run) => run()
};

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/intrinsic-mutation.ts
var SOURCES = /* @__PURE__ */ new WeakMap();
var SOURCE_ACCESSORS = {
  prepareTerminal: {
    get() {
      return this.terminalPreparer;
    }
  },
  terminal: {
    get() {
      return this.terminalRecord?.observer;
    }
  },
  capture: {
    get() {
      return this.captureRecord?.observer;
    }
  }
};
function compose(record) {
  const { observers } = record;
  if (observers === void 0 || observers.size === 0) {
    record.observer = void 0;
    return;
  }
  if (observers.size === 1) {
    const only = observers.values().next().value;
    record.observer = (mutation) => {
      try {
        only(mutation);
      } catch {
      }
    };
    return;
  }
  const snapshot = [...observers];
  record.observer = (mutation) => {
    for (const observer of snapshot) {
      try {
        observer(mutation);
      } catch {
      }
    }
  };
}
var UNOBSERVABLE_SOURCE = Object.freeze({
  observer: void 0
});
function registerIntrinsicMutationSource(node) {
  const record = { observers: void 0, observer: void 0 };
  Object.defineProperties(record, SOURCE_ACCESSORS);
  SOURCES.set(node, record);
  return record;
}
function observeIntrinsicMutations(node, observer, capture = false) {
  const source = SOURCES.get(node);
  if (!source) return void 0;
  const record = capture === "terminal" ? source.terminalRecord ??= { observers: void 0, observer: void 0 } : capture ? source.captureRecord ??= { observers: void 0, observer: void 0 } : source;
  const installed = observer;
  (record.observers ??= /* @__PURE__ */ new Set()).add(installed);
  compose(record);
  let active = true;
  return () => {
    if (!active) return;
    active = false;
    record.observers?.delete(installed);
    compose(record);
  };
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/location-runtime.ts
var WRITABLE_LOCATION_BINDINGS = /* @__PURE__ */ new WeakMap();
var writableLocationBinding = (location) => {
  const binding = WRITABLE_LOCATION_BINDINGS.get(location);
  if (!binding) throw new Error("Expected a writable SignalTree location");
  return binding;
};
function isWritableLocation(value) {
  return WRITABLE_LOCATION_BINDINGS.has(value);
}
function writableLocationPublisher(value) {
  return WRITABLE_LOCATION_BINDINGS.get(value);
}
function replaceLocation(location, value) {
  writableLocationBinding(location).replace(value);
}
function deriveLocation(location, update) {
  writableLocationBinding(location).derive(update);
}
function registerWritableLocationBinding(binding) {
  WRITABLE_LOCATION_BINDINGS.set(
    binding.location,
    binding
  );
}
var activeConsumer;
var publicationDepth = 0;
var pendingConsumers = /* @__PURE__ */ new Set();
var dependencyFinalizer = new FinalizationRegistry((dependencies) => {
  for (const [node, edge] of dependencies) {
    node.consumers.delete(edge.reference);
  }
});
var flushConsumers = () => {
  const errors = [];
  while (pendingConsumers.size > 0) {
    const consumer = [...pendingConsumers].sort(
      (left, right) => left.level - right.level
    )[0];
    pendingConsumers.delete(consumer);
    try {
      consumer.settle();
    } catch (error) {
      errors.push(error);
    }
  }
  return errors;
};
var NO_LISTENERS = /* @__PURE__ */ new Set();
var notifyObservers = (token, listeners2) => {
  let failure;
  let hasFailure = false;
  try {
    token?.invalidate();
  } catch (error) {
    failure = error;
    hasFailure = true;
  }
  for (const listener of [...listeners2]) {
    try {
      listener();
    } catch {
    }
  }
  if (hasFailure) throw failure;
};
var trackDependency = (node, token) => {
  if (activeConsumer) {
    let edge = activeConsumer.dependencies.get(node);
    if (!edge) {
      const reference = new WeakRef(activeConsumer);
      edge = { reference, version: node.version };
      node.consumers.add(reference);
      activeConsumer.dependencies.set(node, edge);
    } else {
      edge.version = node.version;
    }
    activeConsumer.level = Math.max(activeConsumer.level, node.level + 1);
    return;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("publicationDependencyReads");
  }
  token().observe();
};
var notifyDependents = (node) => {
  for (const reference of node.consumers) {
    const consumer = reference.deref();
    if (consumer) consumer.invalidate();
    else node.consumers.delete(reference);
  }
};
var NODE_LOCATION_RUNTIMES = /* @__PURE__ */ new WeakMap();
function bindLocationRuntime(node, runtime2) {
  NODE_LOCATION_RUNTIMES.set(node, runtime2);
}
function getLocationRuntime(node) {
  return NODE_LOCATION_RUNTIMES.get(node);
}
function createLocationRuntime(realization) {
  const hasReactiveObservation = realization !== NEUTRAL_OBSERVATION_ADAPTER;
  let invalidationGroupDepth = 0;
  const groupedPublishers = /* @__PURE__ */ new Set();
  const deliver = (publishers) => {
    const errors = [];
    realization.runInvalidationGroup(() => {
      publicationDepth += 1;
      try {
        for (const publisher of publishers) {
          try {
            publisher.notify();
          } catch (error) {
            errors.push(error);
          }
        }
        if (publicationDepth === 1) errors.push(...flushConsumers());
      } finally {
        publicationDepth -= 1;
        if (publicationDepth === 0) pendingConsumers.clear();
      }
    });
    if (errors.length > 0) throw errors[0];
  };
  const publish = (publishers) => {
    if (invalidationGroupDepth > 0) {
      for (const publisher of publishers) groupedPublishers.add(publisher);
      return;
    }
    deliver(publishers);
  };
  const runInvalidationGroup = (run) => {
    let failure;
    let hasFailure = false;
    invalidationGroupDepth += 1;
    try {
      run();
    } catch (error) {
      failure = error;
      hasFailure = true;
    } finally {
      invalidationGroupDepth -= 1;
      if (invalidationGroupDepth === 0 && groupedPublishers.size > 0) {
        const publishers = [...groupedPublishers];
        groupedPublishers.clear();
        try {
          deliver(publishers);
        } catch (error) {
          if (!hasFailure) {
            failure = error;
            hasFailure = true;
          }
        }
      }
    }
    if (hasFailure) throw failure;
  };
  const createWritable = (read, write) => {
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const location = markTreeCell(function(value) {
      if (arguments.length === 0) {
        trackDependency(node, token);
        return read();
      }
      if (typeof value === "function") {
        binding.derive(value);
      } else if (isLeafDefinition(value)) {
        binding.replace(leafDefinitionValue(value));
      } else {
        binding.replace(value);
      }
      return void 0;
    });
    const mutationSource2 = registerIntrinsicMutationSource(
      location
    );
    const binding = {
      location,
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, listeners2);
      },
      replace: (next) => {
        const observer = mutationSource2.observer;
        const before = observer ? read(true) : void 0;
        const changed = write(next, "replace", () => mutationSource2.prepareTerminal?.({ intent: "replace", before, after: next, changed: true }));
        if (observer) {
          observer({
            intent: "replace",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (changed) publish([binding]);
      },
      derive: (update) => {
        const current = read();
        const before = mutationSource2.observer ? read(true) : current;
        const next = update(current);
        const changed = write(next, "derive", () => mutationSource2.prepareTerminal?.({ intent: "derive", before, after: next, changed: true }));
        const observer = mutationSource2.observer;
        if (observer) {
          observer({
            intent: "derive",
            before,
            after: changed ? next : before,
            changed
          });
        }
        if (changed) publish([binding]);
      }
    };
    registerWritableLocationBinding(binding);
    location.peek = () => read();
    location.subscribe = (listener) => {
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    location.asReadonly = () => location;
    return binding;
  };
  const createCell = (initial, equal = Object.is) => {
    let value = initial;
    const binding = createWritable(
      () => value,
      (next) => {
        if (equal(value, next)) return false;
        value = next;
        return true;
      }
    );
    return binding.location;
  };
  const createDerived = (compute) => {
    let initialized = false;
    let dirty = true;
    let computationFailed = false;
    let value;
    let observationToken;
    const listeners2 = /* @__PURE__ */ new Set();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const token = () => observationToken ??= realization.createToken();
    const consumer = {
      dependencies: /* @__PURE__ */ new Map(),
      level: 1,
      invalidate: () => {
        if (dirty) {
          if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
            pendingConsumers.add(consumer);
          }
          return;
        }
        dirty = true;
        notifyDependents(node);
        if (listeners2.size > 0 || hasReactiveObservation && observationToken) {
          pendingConsumers.add(consumer);
        }
      },
      settle: () => {
        if (!dirty) return;
        const previous = value;
        const wasInitialized = initialized;
        readCurrent();
        if (wasInitialized && !Object.is(previous, value)) {
          publisher.notify();
        }
      }
    };
    dependencyFinalizer.register(consumer, consumer.dependencies);
    const publisher = {
      notify: () => {
        notifyObservers(observationToken, listeners2);
      }
    };
    const readCurrent = () => {
      if (!dirty && initialized) return value;
      if (initialized && !computationFailed) {
        let changed = false;
        for (const [dependency, edge] of consumer.dependencies) {
          dependency.refresh();
          if (dependency.version !== edge.version) changed = true;
        }
        if (!changed) {
          dirty = false;
          return value;
        }
      }
      for (const [dependency, edge] of consumer.dependencies) {
        dependency.consumers.delete(edge.reference);
      }
      consumer.dependencies.clear();
      consumer.level = 1;
      const previous = value;
      const wasInitialized = initialized;
      const previousConsumer = activeConsumer;
      activeConsumer = consumer;
      try {
        value = compute();
        node.level = consumer.level;
        initialized = true;
        dirty = false;
        computationFailed = false;
        if (wasInitialized && !Object.is(previous, value)) {
          node.version += 1;
        }
        return value;
      } catch (error) {
        computationFailed = true;
        throw error;
      } finally {
        activeConsumer = previousConsumer;
      }
    };
    node.refresh = () => {
      if (dirty) readCurrent();
    };
    const location = markTreeCell((() => {
      const current = readCurrent();
      trackDependency(node, token);
      return current;
    }));
    location.peek = readCurrent;
    location.subscribe = (listener) => {
      readCurrent();
      listeners2.add(listener);
      return () => listeners2.delete(listener);
    };
    return location;
  };
  const createEpoch = () => {
    let observationToken;
    let version = 0;
    const token = () => observationToken ??= realization.createToken();
    const node = {
      consumers: /* @__PURE__ */ new Set(),
      level: 0,
      version: 0,
      refresh: () => void 0
    };
    const publisher = {
      notify: () => {
        node.version += 1;
        notifyDependents(node);
        notifyObservers(observationToken, NO_LISTENERS);
      }
    };
    const epoch = (() => {
      trackDependency(node, token);
      return version;
    });
    epoch.set = (next) => {
      if (next === version) return;
      version = next;
      publish([publisher]);
    };
    epoch.update = (fn) => epoch.set(fn(version));
    epoch.asReadonly = () => epoch;
    return epoch;
  };
  const advanceEpoch = (handle) => {
    handle.update((v) => v + 1);
  };
  return {
    createCell,
    createDerived,
    createWritable,
    createEpoch,
    advanceEpoch,
    publish,
    runInvalidationGroup
  };
}
var NEUTRAL_LOCATION_RUNTIME = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
);

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/constants.ts
var DEV_MESSAGES = {
  NULL_OR_UNDEFINED: "null/undefined [ST1001]",
  TREE_DESTROYED: "destroyed [ST1012]",
  ENHANCER_CYCLE_DETECTED: "enhancer cycle [ST1024]"
  // ST1032 (LAZY_NOT_INJECTED) and ST1004 (LAZY_FALLBACK) were removed in 15.0
  // with the lazy feature. ST1032 in particular told users to import from
  // `@signal-tree/kernel/lazy`, a subpath withdrawn from the published surface —
  // a runtime diagnostic giving advice that could not be followed.
};
var PROD_MESSAGES = DEV_MESSAGES;
var _isProdByEnv = Boolean(
  typeof globalThis === "object" && globalThis !== null && "process" in globalThis && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  typeof globalThis.process === "object" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  "env" in globalThis.process && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  globalThis.process.env.NODE_ENV === "production"
);
var _isDev = true ? Boolean(false) : !_isProdByEnv;
var SIGNAL_TREE_MESSAGES = Object.freeze(
  _isDev ? DEV_MESSAGES : PROD_MESSAGES
);

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/error-reporter.ts
var listeners = /* @__PURE__ */ new Set();
function reportTreeError(event) {
  if (listeners.size === 0) return false;
  let received = false;
  for (const listener of listeners) {
    try {
      listener(event);
      received = true;
    } catch (err) {
      if (false) {
        safeConsoleError(
          "SignalTree: an onTreeError listener threw. The original error was still handled normally; this is the listener failing. [ST2025]",
          err
        );
      }
    }
  }
  return received;
}
function safeConsoleError(message, error) {
  try {
    if (error === void 0) console.error(message);
    else console.error(message, error);
  } catch {
  }
}
var CONTAINED_REPORT_BUDGET = 50;
var CONTAINED_REPORT_WINDOW_MS = 1e3;
var containedReportWindows = /* @__PURE__ */ new Map();
function registerContainedReportBudget(treeId) {
  containedReportWindows.set(treeId, null);
}
function takeContainedReportBudget(treeId) {
  let now = 0;
  try {
    now = Date.now();
  } catch {
  }
  const owner = containedReportWindows.has(treeId) ? treeId : void 0;
  let window2 = containedReportWindows.get(owner);
  if (!window2 || now - window2.start >= CONTAINED_REPORT_WINDOW_MS) {
    window2 = { start: now, count: 0 };
    containedReportWindows.set(owner, window2);
  }
  if (window2.count >= CONTAINED_REPORT_BUDGET) {
    if (window2.count === CONTAINED_REPORT_BUDGET && listeners.size > 0) {
      window2.count++;
      safeConsoleError(
        `SignalTree: more than ${CONTAINED_REPORT_BUDGET} contained observer errors for one tree within a second; further ones go to the console only, not onTreeError. [ST2034]`
      );
    }
    return false;
  }
  window2.count++;
  return true;
}
function reportContainedObserverError(event) {
  const { error, operation, treeId, path } = event;
  let received = false;
  if (treeId !== void 0) {
    if (takeContainedReportBudget(treeId)) {
      received = reportTreeError({
        error,
        operation,
        treeId,
        ...path === void 0 ? {} : { path }
      });
    }
  }
  if (received && true) {
    return;
  }
  safeConsoleError(
    operation === "notify:subscriber" ? `SignalTree: a write subscriber threw while observing '${path}'; delivery continued. [ST2034]` : "SignalTree: a transaction turn listener threw; the transaction continued. [ST2034]",
    error
  );
}
function releaseContainedReportBudget(treeId) {
  containedReportWindows.delete(treeId);
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/enhancer-types.ts
var ENHANCER_META = Symbol("signaltree:enhancer:meta");

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/enhancers/index.ts
function resolveEnhancerOrder(enhancers, availableCapabilities = /* @__PURE__ */ new Set(), debugMode = false) {
  const nodes = enhancers.map((e, idx) => ({
    fn: e,
    name: e.metadata && e.metadata.name ? String(e.metadata.name) : `enhancer#${idx}`,
    requires: new Set(e.metadata?.requires ?? []),
    provides: new Set(e.metadata?.provides ?? [])
  }));
  const provided = new Set(availableCapabilities);
  const nameCounts = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    for (const capability of node.provides) provided.add(capability);
    if (node.fn.metadata?.name) {
      nameCounts.set(node.name, (nameCounts.get(node.name) ?? 0) + 1);
    }
  }
  const problems = [];
  for (const node of nodes) {
    for (const capability of node.requires) {
      if (!provided.has(capability)) {
        problems.push(
          `  - ${node.fn.metadata?.name ? `"${node.name}"` : "an unnamed enhancer"} requires capability "${capability}", but no configured enhancer provides it.`
        );
      }
    }
  }
  for (const [name, count] of nameCounts) {
    if (count > 1) {
      problems.push(
        `  - enhancer "${name}" is configured ${count} times; each enhancer may appear once.`
      );
    }
  }
  if (problems.length > 0) {
    throw new Error(
      `SignalTree could not finalize the enhancer configuration:
${problems.join("\n")}`
    );
  }
  const adj = /* @__PURE__ */ new Map();
  const nameToNode = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    nameToNode.set(n.name, n);
    adj.set(n.name, /* @__PURE__ */ new Set());
  }
  for (const a of nodes) {
    for (const b of nodes) {
      if (a === b) continue;
      for (const req of b.requires) {
        if (availableCapabilities.has(req)) continue;
        if (a.provides.has(req)) {
          const set = adj.get(a.name);
          if (set) set.add(b.name);
        }
      }
    }
  }
  const inDegree = /* @__PURE__ */ new Map();
  for (const entry of adj.keys()) inDegree.set(entry, 0);
  for (const [, outs] of adj) {
    for (const to of outs) inDegree.set(to, (inDegree.get(to) || 0) + 1);
  }
  const queue = [];
  for (const [name, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(name);
  }
  const ordered = [];
  while (queue.length > 0) {
    const n = queue.shift();
    if (!n) break;
    ordered.push(n);
    const outs = adj.get(n);
    if (!outs) continue;
    for (const m of outs) {
      inDegree.set(m, (inDegree.get(m) || 0) - 1);
      if (inDegree.get(m) === 0) queue.push(m);
    }
  }
  if (ordered.length !== nodes.length) {
    if (debugMode) {
      console.warn(SIGNAL_TREE_MESSAGES.ENHANCER_CYCLE_DETECTED);
    }
    return enhancers;
  }
  return ordered.map((name) => {
    const n = nameToNode.get(name);
    return n ? n.fn : enhancers[0];
  });
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/node-shape.ts
function isTraversableNode(value) {
  return value != null && (typeof value === "object" || typeof value === "function");
}
var CALLABLE_SIGNAL_SYMBOL = Symbol.for("SignalTree:NodeAccessor");
var NODE_STORE_SYMBOL = Symbol.for("SignalTree:NodeStore");
function nodeStoreOf(node) {
  const store = node[NODE_STORE_SYMBOL];
  return store !== void 0 && store !== null ? store : void 0;
}
function snapshotNodeKey(node) {
  return nodeStoreOf(node) ?? node;
}
function isNodeAccessor(value) {
  return typeof value === "function" && value[CALLABLE_SIGNAL_SYMBOL] === true;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/owned-metadata.ts
var OWNED_NODE_METADATA = /* @__PURE__ */ new WeakMap();
function getOwnedPositionIds(node) {
  if (isTraversableNode(node)) {
    const direct = node.__positionIds;
    if (direct) {
      return [...direct];
    }
    const sidecar = OWNED_NODE_METADATA.get(node)?.positionIds;
    return sidecar ? [...sidecar] : void 0;
  }
  return void 0;
}
function getOwnedOwnerPath(node) {
  if (isTraversableNode(node)) {
    const direct = node.__ownerPath;
    if (direct !== void 0) {
      return direct;
    }
    return OWNED_NODE_METADATA.get(node)?.ownerPath;
  }
  return void 0;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/owner-invalidation-port.ts
var dispatch;
function markOwnerInvalidated(ownerId) {
  dispatch?.mark(ownerId);
}
function markOwnerInvalidatedFrom(owner) {
  dispatch?.markFrom(owner);
}
function terminateOwnerInvalidation(owner) {
  dispatch?.terminate(owner);
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/path-observation-port.ts
var runtime;
var branchMembershipCapture;
var pathReAddCapture;
function captureBranchMembershipIfObserved(branch, supplied, partial) {
  return branchMembershipCapture?.(branch, supplied, partial);
}
function capturePathReAddIfObserved(path, outer) {
  return pathReAddCapture?.(path, outer);
}
function hasPathObservers() {
  return runtime?.hasObservers() ?? false;
}
var PORT = {
  notify(path, value, prev, ownerPath, subjectIds, positionIds, metaOverride, ownerId, subjectFieldFootprint) {
    runtime?.notify(
      path,
      value,
      prev,
      ownerPath,
      subjectIds,
      positionIds,
      metaOverride,
      ownerId,
      subjectFieldFootprint
    );
  }
};
function pathObservation() {
  return PORT;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/snapshot-authority.ts
var MATERIALIZED = /* @__PURE__ */ new WeakMap();
var SNAPSHOT_PARENT = /* @__PURE__ */ new WeakMap();
var TREE_STORES = /* @__PURE__ */ new WeakSet();
var VOLATILE_SNAPSHOTS = /* @__PURE__ */ new WeakSet();
var MEMBERSHIP_REVISION = /* @__PURE__ */ new WeakMap();
function markTreeStore(store) {
  TREE_STORES.add(store);
}
function isSnapshotNode(node) {
  return TREE_STORES.has(node) || isNodeAccessor(node);
}
function bindSnapshotParent(node, parent) {
  SNAPSHOT_PARENT.set(
    snapshotNodeKey(node),
    new WeakRef(snapshotNodeKey(parent))
  );
}
function markSnapshotVolatile(node) {
  let current = snapshotNodeKey(node);
  while (current) {
    VOLATILE_SNAPSHOTS.add(current);
    current = SNAPSHOT_PARENT.get(current)?.deref();
  }
}
function membershipRevisionFor(key, locations) {
  let revision = MEMBERSHIP_REVISION.get(key);
  if (!revision) {
    revision = locations.createCell(0);
    MEMBERSHIP_REVISION.set(key, revision);
  }
  return revision;
}
function observeMembership(node) {
  membershipRevisionFor(
    snapshotNodeKey(node),
    getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME
  )();
}
function publishMembershipChange(node) {
  const key = snapshotNodeKey(node);
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  deriveLocation(membershipRevisionFor(key, locations), (value) => value + 1);
  markOwnerInvalidatedFrom(node);
}
function materializeSnapshotNode(node, build) {
  const key = snapshotNodeKey(node);
  if (VOLATILE_SNAPSHOTS.has(key)) return build();
  const locations = getLocationRuntime(node) ?? NEUTRAL_LOCATION_RUNTIME;
  let snapshot = MATERIALIZED.get(key);
  if (!snapshot) {
    const membershipRevision = membershipRevisionFor(key, locations);
    const read = () => {
      membershipRevision();
      const built = build();
      if (false) {
        if (built !== null && typeof built === "object") Object.freeze(built);
      }
      return built;
    };
    snapshot = { observe: locations.createDerived(read) };
    MATERIALIZED.set(key, snapshot);
  }
  return snapshot.observe();
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/tree-scalar-slot-port.ts
var TREE_SCALAR_SLOT_RUNTIME = Symbol.for("SignalTree:ScalarSlotRuntime");
function defineTreeScalarSlotRuntime(node, runtime2) {
  Object.defineProperty(node, TREE_SCALAR_SLOT_RUNTIME, {
    value: runtime2,
    enumerable: false,
    configurable: true
  });
}
function getTreeScalarSlotRuntime(node) {
  if (!isTraversableNode(node)) {
    return void 0;
  }
  return node[TREE_SCALAR_SLOT_RUNTIME];
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/member-membership.ts
var DORMANT = Symbol.for("SignalTree:DormantMember");
var membershipEpoch = 1;
var omittedMembers = /* @__PURE__ */ new WeakMap();
var MEMBERSHIP_CHANGED = Symbol.for("SignalTree:MembershipChanged");
function membershipHook(node) {
  return node?.[MEMBERSHIP_CHANGED];
}
var NODE_ACCESSOR_PEER = Symbol.for("SignalTree:NodeAccessorPeer");
function memberBinding(leaf) {
  if (!isTraversableNode(leaf)) {
    return void 0;
  }
  return leaf[DORMANT];
}
function reactivateOnWrite(leaf) {
  const binding = memberBinding(leaf);
  if (!binding) return false;
  return setMemberPresence(binding.parent, binding.key, "active");
}
function nodeOf(parent) {
  return parent[NODE_ACCESSOR_PEER] ?? parent;
}
function isAbsentMember(node) {
  const first = memberBinding(node);
  if (first === void 0) return false;
  if (first.epoch === membershipEpoch) {
    if (false)
      throw new Error(
        "SignalTree internal: a cached absence answer disagrees with enumerability (membershipEpoch was not advanced)."
      );
    return first.absent;
  }
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  first.absent = walkAbsence(first);
  first.epoch = membershipEpoch;
  return first.absent;
}
function walkAbsence(first) {
  for (let binding = first; binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) return true;
  }
  return false;
}
var structuralWrites = {
  depth: 0,
  stamp: 0
};
function beginStructuralWrite() {
  structuralWrites.depth++;
}
function endStructuralWrite(failed) {
  if (--structuralWrites.depth) return;
  structuralWrites.readded = void 0;
  structuralWrites.end?.(failed);
}
function inStructuralWrite(node) {
  return node !== void 0 && structuralWrites.own === node;
}
function readdedDuringStructuralWrite(branch, key, since) {
  return (structuralWrites.readded?.get(nodeOf(branch))?.get(key) ?? 0) > since;
}
var storedReads = { depth: 0 };
function reactivatePathOnWrite(node) {
  if (!isAbsentMember(node)) return false;
  if (inStructuralWrite(node)) return reactivateOnWrite(node);
  if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
    recordProductionSubstrateStat("absenceWalks");
  }
  const path = [];
  let outer = -1;
  for (let binding = memberBinding(node); binding; binding = memberBinding(binding.parent)) {
    const descriptor = Object.getOwnPropertyDescriptor(
      binding.parent,
      binding.key
    );
    if (descriptor?.enumerable === false) outer = path.length;
    path.push(binding);
  }
  if (outer < 0) return false;
  const announce = capturePathReAddIfObserved(path, outer);
  for (let i = outer - 1; i >= 0; i--) {
    const { parent, key: kept } = path[i];
    for (const member of Object.keys(parent))
      if (member !== kept) setMemberPresence(parent, member, "dormant");
  }
  for (let i = outer; i >= 0; i--) {
    const { parent, key } = path[i];
    setMemberPresence(parent, key, "active");
    if (structuralWrites.depth) {
      const readded = structuralWrites.readded ??= /* @__PURE__ */ new Map();
      let keys = readded.get(parent);
      if (!keys) readded.set(parent, keys = /* @__PURE__ */ new Map());
      keys.set(key, ++structuralWrites.stamp);
    }
  }
  if (!isWritableLocation(node) || outer > 0)
    republishMembers(path[outer].parent, [path[outer].key]);
  announce?.();
  return true;
}
var ABSENCE = {
  // History capture reads what storage holds (`storedReads`).
  isAbsent: (node) => !storedReads.depth && isAbsentMember(node),
  reAdd: reactivatePathOnWrite
};
function republishMembers(parent, keys) {
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (!runtime2) return;
  const changedSlots = [];
  const unaddressedLeaves = [];
  const branches = [];
  const publish = (child) => {
    const positionId = getOwnedPositionIds(child)?.[0];
    const slot = positionId === void 0 ? void 0 : runtime2.resolveScalarSlot(positionId);
    if (slot !== void 0) return changedSlots.push(slot) > 0;
    const publisher = writableLocationPublisher(child);
    if (publisher) return unaddressedLeaves.push(publisher) > 0;
    membershipHook(child)?.();
    if (isNodeAccessor(child)) {
      branches.push(child);
      for (const key of Object.keys(child))
        publish(child[key]);
    }
    return false;
  };
  let tokenCarrying = 0;
  for (const key of keys)
    if (publish(parent[key])) tokenCarrying++;
  if (tokenCarrying < keys.length) {
    publishMembershipChange(parent);
  } else {
    markOwnerInvalidatedFrom(parent);
  }
  for (const branch of branches) publishMembershipChange(branch);
  if (changedSlots.length > 0) {
    runtime2.publishPrepared({ revision: runtime2.revision(), changedSlots });
  }
  if (unaddressedLeaves.length > 0) {
    (getLocationRuntime(parent) ?? NEUTRAL_LOCATION_RUNTIME).publish(
      unaddressedLeaves
    );
  }
}
function deactivateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === false) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: false });
  membershipEpoch++;
  markHasDormant(parent);
  const runtime2 = getTreeScalarSlotRuntime(parent);
  if (runtime2) {
    omittedMembers.set(runtime2, (omittedMembers.get(runtime2) ?? 0) + 1);
    runtime2.enableAbsence?.(ABSENCE);
  }
  const child = parent[key];
  if (isTraversableNode(child)) {
    linkMember(parent, key, child);
    linkDescendants(child);
  }
  return true;
}
function linkMember(parent, key, child) {
  membershipEpoch++;
  Object.defineProperty(child, DORMANT, {
    value: {
      parent: nodeOf(parent),
      key,
      epoch: 0,
      absent: false
    },
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function linkDescendants(node) {
  if (!isNodeAccessor(node)) return;
  for (const key of Object.getOwnPropertyNames(node)) {
    const child = Object.getOwnPropertyDescriptor(node, key)?.value;
    if (!isNodeAccessor(child) && !isWritableLocation(child) && !membershipHook(child) || memberBinding(child))
      continue;
    linkMember(node, key, child);
    linkDescendants(child);
  }
}
function activateOne(parent, key) {
  const descriptor = Object.getOwnPropertyDescriptor(parent, key);
  if (!descriptor || descriptor.enumerable === true) {
    return false;
  }
  if (!descriptor.configurable) {
    return false;
  }
  Object.defineProperty(parent, key, { ...descriptor, enumerable: true });
  membershipEpoch++;
  const runtime2 = getTreeScalarSlotRuntime(parent);
  const omitted = runtime2 ? omittedMembers.get(runtime2) : void 0;
  if (runtime2 && omitted !== void 0) {
    omittedMembers.set(runtime2, omitted - 1);
    if (omitted === 1) runtime2.disableAbsence?.();
  }
  return true;
}
var HAS_DORMANT = Symbol.for("SignalTree:HasDormantMembers");
function hasDormantMembers(parent) {
  return parent[HAS_DORMANT] === true;
}
function markHasDormant(parent) {
  if (hasDormantMembers(parent)) return;
  Object.defineProperty(parent, HAS_DORMANT, {
    value: true,
    enumerable: false,
    configurable: true,
    writable: true
  });
}
function dormantKeys(parent) {
  return Object.getOwnPropertyNames(parent).filter((key) => {
    const d = Object.getOwnPropertyDescriptor(parent, key);
    return d !== void 0 && d.enumerable === false && "value" in d;
  });
}
function peerOf(branch) {
  const record = branch;
  const peer = record[NODE_STORE_SYMBOL] ?? record[NODE_ACCESSOR_PEER];
  return isTraversableNode(peer) && peer !== branch ? peer : void 0;
}
function setMemberPresence(branch, key, presence) {
  const apply = presence === "active" ? activateOne : deactivateOne;
  let changed = apply(branch, key);
  const peer = peerOf(branch);
  if (peer) changed = apply(peer, key) || changed;
  return changed;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/write-context.ts
var activeContext;
function getActiveWriteContext() {
  return activeContext;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/owned-mutation.ts
function mergeOwnedNodeMetadata(node, patch) {
  const existing = OWNED_NODE_METADATA.get(node) ?? {};
  OWNED_NODE_METADATA.set(node, { ...existing, ...patch });
}
function defineOwnedPositionIds(node, positionIds, storage = "property") {
  if (!positionIds || positionIds.length === 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { positionIds: [...positionIds] });
    return;
  }
  Object.defineProperty(node, "__positionIds", {
    get: () => [...positionIds],
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerPath(node, ownerPath, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerPath });
    return;
  }
  Object.defineProperty(node, "__ownerPath", {
    value: ownerPath,
    enumerable: false,
    configurable: true
  });
}
function defineOwnedOwnerId(node, ownerId, storage = "property") {
  if (ownerId === void 0) {
    return;
  }
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { ownerId });
    return;
  }
  Object.defineProperty(node, "__ownerId", {
    value: ownerId,
    enumerable: false,
    configurable: true
  });
}
function defineIntrinsicMutationEmitter(node, storage = "property") {
  if (storage === "sidecar") {
    mergeOwnedNodeMetadata(node, { emitsMutations: true });
    return;
  }
  Object.defineProperty(node, "__emitsMutations", {
    value: true,
    enumerable: false,
    configurable: true
  });
}
function emitOwnedMutation(options, before, after, mutationIntent) {
  markOwnerInvalidated(options.ownerId);
  const positionId = options.positionIds?.[0];
  if (positionId === void 0) {
    return;
  }
  if (!hasPathObservers()) {
    return;
  }
  pathObservation().notify(
    options.path,
    after,
    before,
    options.path,
    // subjectIds: this generic scalar route has no subject-identity producer
    // and must not acquire one. Entity/structural notification owns that fact.
    void 0,
    [positionId],
    {
      ...getActiveWriteContext() ?? {},
      mutationIntent
    },
    options.ownerId
  );
}
function wrapOwnedWritableSignal(leaf, options, hooks = {}) {
  const metadataStorage = options.metadataStorage ?? "property";
  defineOwnedPositionIds(leaf, options.positionIds, metadataStorage);
  defineOwnedOwnerId(leaf, options.ownerId, metadataStorage);
  defineOwnedOwnerPath(leaf, options.path, metadataStorage);
  defineIntrinsicMutationEmitter(leaf, metadataStorage);
  const releaseIntrinsicObserver = observeIntrinsicMutations(
    leaf,
    (mutation) => {
      if (mutation.changed) {
        emitOwnedMutation(
          options,
          mutation.before,
          mutation.after,
          mutation.intent
        );
      }
      if (mutation.intent === "replace") {
        hooks.afterSet?.(
          mutation.after,
          mutation.before,
          mutation.after,
          mutation.changed
        );
      } else {
        hooks.afterUpdate?.(
          mutation.before,
          mutation.after,
          mutation.changed
        );
      }
    }
  );
  if (!releaseIntrinsicObserver) {
    throw new Error("SignalTree location has no intrinsic mutation source");
  }
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/position-registry.ts
var POSITION_REGISTRY_SYMBOL = Symbol.for("SignalTree:PositionRegistry");
var nextRegistryId = 1;
var TreePositionRegistry = class {
  /**
   * ⚠️ THE ONE PLACE a counter value becomes a tree-namespace identity.
   *
   * Branding HERE rather than at each consumer means `registry.id` and
   * `ownerRegistry.id` are already `TreeId` everywhere downstream — no producer
   * has to independently assert that some number is a tree identity.
   */
  id = nextRegistryId++;
  nextPositionId = 1;
  parents = /* @__PURE__ */ new Map();
  addresses = /* @__PURE__ */ new Map();
  registerPositionAddress(position, address) {
    this.addresses.set(position, sealedAddress(address));
  }
  addressFor(position) {
    return this.addresses.get(position);
  }
  collectionPaths = /* @__PURE__ */ new Map();
  registerCollectionPath(position, path) {
    this.collectionPaths.set(position, path);
  }
  collectionPathFor(position) {
    return this.collectionPaths.get(position);
  }
  allocate(parent) {
    const positionId = this.nextPositionId++;
    this.parents.set(positionId, parent);
    return positionId;
  }
  parentOf(position) {
    return this.parents.get(position);
  }
  contains(authority, participant) {
    if (authority === participant) {
      return true;
    }
    const seen2 = /* @__PURE__ */ new Set();
    let current = participant;
    while (current !== void 0 && !seen2.has(current)) {
      seen2.add(current);
      const parent = this.parentOf(current);
      if (parent === authority) {
        return true;
      }
      current = parent;
    }
    return false;
  }
};
function createPositionRegistry() {
  return new TreePositionRegistry();
}
function definePositionRegistry(node, registry) {
  Object.defineProperty(node, POSITION_REGISTRY_SYMBOL, {
    value: registry,
    enumerable: false,
    configurable: true
  });
}
var nodeAddresses = /* @__PURE__ */ new WeakMap();
function sealedAddress(address) {
  return Object.isFrozen(address) ? address : Object.freeze(address.slice());
}
function childAddressOf(address, key) {
  return Object.freeze(address.concat(key));
}
function defineNodeAddress(node, address) {
  nodeAddresses.set(node, sealedAddress(address));
}
function getNodeAddress(node) {
  return isTraversableNode(node) ? nodeAddresses.get(node) : void 0;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/runtime-tree-plan.ts
var RESTORATION_CAPABILITIES = [
  "causal-runtime",
  "temporal-snapshots"
];
function createRuntimeTreePlan(hasCapability) {
  return Object.freeze({
    hasCapability,
    hasRestorationAuthority: RESTORATION_CAPABILITIES.some(
      (capability) => hasCapability(capability)
    )
  });
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/materialize-markers.ts
function createMaterializationContext(positionTopologyEnabled = true, hasCapability = (capability) => capability === "position-topology" ? positionTopologyEnabled : true, physicalCommitClock, locationRuntime = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const positionRegistry = createPositionRegistry();
  return {
    locationRuntime,
    positionRegistry,
    positionTopologyEnabled,
    physicalCommitClock,
    hasCapability,
    runtimeTreePlan: createRuntimeTreePlan(hasCapability),
    allocatePositionId: (parentPositionId) => positionRegistry.allocate(parentPositionId),
    physicalOwners: []
  };
}
var PROCESSOR_STAMP = Symbol.for("SignalTree:MarkerProcessor");
function getNodeProcessor(node) {
  if (!isTraversableNode(node)) return void 0;
  return node[PROCESSOR_STAMP];
}
function snapshotMarkerNode(node, parent) {
  const proc = getNodeProcessor(node);
  if (!proc?.snapshot) return void 0;
  if (!isTraversableNode(node)) return { value: proc.snapshot(node) };
  if (parent) bindSnapshotParent(node, parent);
  if (!proc.cacheSnapshot) {
    markSnapshotVolatile(node);
    return { value: proc.snapshot(node) };
  }
  const snapshot = proc.snapshot;
  return materializeSnapshotNode(node, () => ({
    value: snapshot(node)
  }));
}
function hydrateMarkerNode(node, value, mode) {
  const proc = getNodeProcessor(node);
  if (!proc?.hydrate) return false;
  proc.hydrate(node, value, mode);
  return true;
}
var MARKER_PROCESSORS = [];
function isRegisteredMarker(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  if (Object.getOwnPropertySymbols(value).length === 0) {
    return false;
  }
  for (const processor of MARKER_PROCESSORS) {
    if (processor.check(value)) {
      return true;
    }
  }
  return false;
}
var treesConstructedCount = 0;
function _recordTreeConstruction() {
  treesConstructedCount += 1;
}
var ORDINARY_STATE = Symbol.for("SignalTree:OrdinaryStateRequest");
var KEY_INDEX = Symbol.for("SignalTree:DynamicKeyIndex");
var MEMBER_MATERIALIZER = Symbol.for("SignalTree:MemberMaterializer");
function attachKeyIndex(branch) {
  const members = /* @__PURE__ */ new Map();
  for (const key of Object.keys(branch)) {
    members.set(key, branch[key]);
  }
  Object.defineProperty(branch, KEY_INDEX, {
    value: members,
    enumerable: false,
    configurable: true
  });
}
var applyMemberValue;
function setMemberValueApplier(fn) {
  applyMemberValue = fn;
}
function isOrdinaryStateRequest(v) {
  return isTraversableNode(v) && v[ORDINARY_STATE] === true;
}
function materializeKeyedAware(authority, request, path, parentPositionId, address) {
  const branch = authority.materialize(
    request.value,
    path,
    parentPositionId,
    address
  );
  if (request.keyedLookup && isTraversableNode(branch)) {
    attachKeyIndex(branch);
    Object.defineProperty(branch, MEMBER_MATERIALIZER, {
      value: authority.bindMember(branch),
      enumerable: false,
      configurable: true
    });
  }
  return branch;
}
function materializeMarkers(node, notifier, path = [], context = createMaterializationContext(), authority) {
  if (!isTraversableNode(node)) return;
  if (isTreeCell(node)) return;
  const isAccessor = typeof node === "function" && isNodeAccessor(node);
  if (typeof node === "function" && !isAccessor) return;
  const getNotifier = () => notifier ?? pathObservation();
  const keys = Object.keys(node);
  for (const key of keys) {
    const value = node[key];
    const currentPath = childAddressOf(path, key);
    const pathString = currentPath.join(".");
    let processed = false;
    for (const processor of MARKER_PROCESSORS) {
      if (processor.check(value)) {
        try {
          const parentPositionId = node.__positionIds?.[0];
          const produced = processor.create(
            value,
            getNotifier(),
            pathString,
            context,
            parentPositionId
          );
          const materialized = isOrdinaryStateRequest(produced) && authority ? materializeKeyedAware(
            authority,
            produced,
            pathString,
            parentPositionId,
            currentPath
          ) : produced;
          if (isTraversableNode(materialized)) {
            defineNodeAddress(materialized, currentPath);
            if (context.positionTopologyEnabled) {
              for (const position of getOwnedPositionIds(materialized) ?? []) {
                context.positionRegistry.registerPositionAddress(
                  position,
                  currentPath
                );
              }
            }
            bindLocationRuntime(
              materialized,
              context.locationRuntime
            );
            Object.defineProperty(materialized, PROCESSOR_STAMP, {
              value: processor,
              enumerable: false,
              writable: false,
              configurable: true
            });
          }
          if (false) {
            warnWriteOnlyMarker(processor, materialized);
          }
          node[key] = materialized;
          const backingStore = node[NODE_STORE_SYMBOL];
          if (backingStore && backingStore !== node) {
            backingStore[key] = materialized;
          }
          processed = true;
        } catch (err) {
          if (false) {
            console.error(
              `SignalTree: Failed to materialize marker at "${pathString}"`,
              err
            );
          }
        }
        break;
      }
    }
    if (!processed && value != null) {
      if (isNodeAccessor(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      } else if (typeof value === "object" && !Array.isArray(value)) {
        materializeMarkers(value, notifier, currentPath, context, authority);
      }
    }
  }
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/observation-substrate.ts
var OBSERVATION = /* @__PURE__ */ new WeakMap();
function installDormantObservation(leaf) {
  OBSERVATION.set(leaf, {
    claims: 0,
    positionId: void 0,
    releaseMutationObserver: () => void 0
  });
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/root-source.ts
var ROOT_AUTHORITIES = /* @__PURE__ */ new WeakMap();
function defineRootTree(rootAccessor, authority) {
  ROOT_AUTHORITIES.set(rootAccessor, authority);
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/utilities/deep-equal.ts
function deepEqual(a, b) {
  return equalsInner(a, b, 0, void 0);
}
var CYCLE_GUARD_DEPTH = 64;
function equalsInner(a, b, depth, seen2) {
  if (a === b) return true;
  if (a == null || b == null) return a === b;
  const typeA = typeof a;
  const typeB = typeof b;
  if (typeA !== typeB) return false;
  if (typeA !== "object") return a !== a && b !== b;
  if (depth >= CYCLE_GUARD_DEPTH) {
    seen2 ??= /* @__PURE__ */ new WeakMap();
    if (seen2.get(a) === b) return true;
    seen2.set(a, b);
  }
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    const bArr = b;
    for (let i = 0; i < a.length; i++) {
      const x = a[i];
      const y = bArr[i];
      if (x === y) continue;
      if (!equalsInner(x, y, depth + 1, seen2)) return false;
    }
    return true;
  }
  if (Array.isArray(b)) return false;
  if (a instanceof Date && b instanceof Date) {
    try {
      const ta = a.getTime();
      const tb = b.getTime();
      return ta === tb || ta !== ta && tb !== tb;
    } catch {
      return false;
    }
  }
  if (a instanceof RegExp && b instanceof RegExp) {
    return a.source === b.source && a.flags === b.flags;
  }
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    for (const [key, value] of a) {
      if (!b.has(key) || !equalsInner(value, b.get(key), depth + 1, seen2))
        return false;
    }
    return true;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    for (const value of a) {
      if (!b.has(value)) return false;
    }
    return true;
  }
  if (a instanceof Error && b instanceof Error) {
    if (a.name !== b.name || a.message !== b.message) return false;
  } else if (a instanceof Number && b instanceof Number || a instanceof String && b instanceof String || a instanceof Boolean && b instanceof Boolean) {
    const va = a.valueOf();
    const vb = b.valueOf();
    if (!(va === vb || va !== va && vb !== vb)) return false;
  }
  try {
    if (a.constructor !== b.constructor) {
      return false;
    }
  } catch {
    return false;
  }
  const objA = a;
  const objB = b;
  const keysA = Object.keys(objA);
  const keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;
  const hasOwn = Object.prototype.hasOwnProperty;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!hasOwn.call(objB, key)) return false;
    const x = objA[key];
    const y = objB[key];
    if (x === y) continue;
    if (!equalsInner(x, y, depth + 1, seen2)) return false;
  }
  return true;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/utilities/is-built-in-object.ts
function isBuiltInObject(value) {
  if (value === null || value === void 0) return false;
  if (value instanceof Date || value instanceof RegExp || typeof value === "function" || value instanceof Map || value instanceof Set || value instanceof WeakMap || value instanceof WeakSet || value instanceof ArrayBuffer || value instanceof DataView || value instanceof Error || value instanceof Promise) {
    return true;
  }
  if (value instanceof Int8Array || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Int16Array || value instanceof Uint16Array || value instanceof Int32Array || value instanceof Uint32Array || value instanceof Float32Array || value instanceof Float64Array || value instanceof BigInt64Array || value instanceof BigUint64Array) {
    return true;
  }
  if (typeof window !== "undefined") {
    if (value instanceof URL || value instanceof URLSearchParams || value instanceof FormData || value instanceof Blob || typeof File !== "undefined" && value instanceof File || typeof FileList !== "undefined" && value instanceof FileList || typeof Headers !== "undefined" && value instanceof Headers || typeof Request !== "undefined" && value instanceof Request || typeof Response !== "undefined" && value instanceof Response || typeof AbortController !== "undefined" && value instanceof AbortController || typeof AbortSignal !== "undefined" && value instanceof AbortSignal) {
      return true;
    }
  }
  try {
    const NodeBuffer = globalThis?.Buffer;
    if (NodeBuffer && value instanceof NodeBuffer) {
      return true;
    }
  } catch {
  }
  return false;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/utils.ts
var isReactiveStateValue = isTreeCell;
function isMemoisable(node) {
  return isSnapshotNode(node);
}
function materializeNode(store) {
  if (!isMemoisable(store)) return unwrap(store);
  return materializeSnapshotNode(store, () => unwrap(store));
}
var DERIVED_STAMP = Symbol.for("SignalTree:Derived");
function stampDerived(sig) {
  if (typeof sig === "function") markTreeCell(sig);
  if (isTraversableNode(sig) && typeof sig.set !== "function") {
    Object.defineProperty(sig, DERIVED_STAMP, {
      value: true,
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  return sig;
}
function unwrap(node) {
  if (node === null || node === void 0) {
    return node;
  }
  if (isNodeAccessor(node)) {
    const target = snapshotNodeKey(node);
    return isMemoisable(node) ? materializeSnapshotNode(node, () => buildFromStore(target)) : buildFromStore(target);
  }
  if (isReactiveStateValue(node)) {
    return node();
  }
  if (typeof node !== "object") {
    return node;
  }
  if (Array.isArray(node)) {
    return node;
  }
  if (isBuiltInObject(node)) {
    return node;
  }
  return buildFromStore(node);
}
function unwrapBranchForWriteCapture(node) {
  return isNodeAccessor(node) ? buildFromStore(snapshotNodeKey(node), true) : unwrap(node);
}
function buildFromStore(node, uncachedBranches = false) {
  const own = snapshotMarkerNode(node);
  if (own) return own.value;
  const result = {};
  if (hasDormantMembers(node)) {
    for (const key of dormantKeys(node)) {
      const dormant = node[key];
      if (typeof dormant === "function") dormant();
    }
  }
  for (const key in node) {
    if (!Object.prototype.hasOwnProperty.call(node, key)) continue;
    const value = node[key];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshot = snapshotMarkerNode(value, node);
    if (markerSnapshot) {
      result[key] = markerSnapshot.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (false) {
        warnUnwrapSkipped(key);
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      bindSnapshotParent(value, node);
      result[key] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[key] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[key] = unwrap(value);
    } else {
      result[key] = value;
    }
  }
  const symbols = Object.getOwnPropertySymbols(node);
  for (const sym of symbols) {
    if (typeof sym.description === "string" && sym.description.startsWith("SignalTree:")) {
      continue;
    }
    const value = node[sym];
    if (value && (typeof value === "function" || typeof value === "object") && value[DERIVED_STAMP] === true) {
      continue;
    }
    const markerSnapshotSym = snapshotMarkerNode(value, node);
    if (markerSnapshotSym) {
      result[sym] = markerSnapshotSym.value;
      continue;
    }
    if (typeof value === "function" && !isNodeAccessor(value) && !isReactiveStateValue(value)) {
      if (false) {
        warnUnwrapSkipped(String(sym));
      }
      continue;
    }
    if (isNodeAccessor(value)) {
      result[sym] = uncachedBranches ? unwrapBranchForWriteCapture(value) : value();
    } else if (isReactiveStateValue(value)) {
      result[sym] = value();
    } else if (typeof value === "object" && value !== null && !Array.isArray(value) && !isBuiltInObject(value)) {
      result[sym] = unwrap(value);
    } else {
      result[sym] = value;
    }
  }
  return result;
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/mutation-capture-runtime.ts
var MUTATION_CAPTURE_RUNTIME = Symbol.for(
  "SignalTree:MutationCaptureRuntime"
);
function createMutationCaptureRuntime() {
  let activeCount = 0;
  const entityListeners = /* @__PURE__ */ new Set();
  const collectionOrderListeners = /* @__PURE__ */ new Set();
  return {
    hasCommittedEntityObservers() {
      return activeCount > 0 && entityListeners.size > 0;
    },
    publishCommittedEntity(capture) {
      if (activeCount === 0) return;
      for (const listener of [...entityListeners]) {
        try {
          listener(capture);
        } catch (error) {
          reportContainedObserverError({
            error,
            operation: "transaction:listener"
          });
        }
      }
    },
    subscribeCommittedEntity(listener) {
      entityListeners.add(listener);
      return () => {
        entityListeners.delete(listener);
      };
    },
    isCaptureActive() {
      return activeCount > 0;
    },
    activateCapture() {
      activeCount += 1;
      let released = false;
      return () => {
        if (released) {
          return;
        }
        released = true;
        activeCount = Math.max(0, activeCount - 1);
      };
    },
    publishCollectionOrder(capture) {
      if (activeCount === 0) {
        return;
      }
      for (const listener of [...collectionOrderListeners]) {
        listener(capture);
      }
    },
    subscribeCollectionOrder(listener) {
      collectionOrderListeners.add(listener);
      return () => collectionOrderListeners.delete(listener);
    }
  };
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/tree-scalar-slot-runtime.ts
var ScalarSlotMutationFrameImpl = class {
  constructor(baseRevision, getCommittedRevision, readValue, commitValues, assertSlotIndex, prepareValues) {
    this.baseRevision = baseRevision;
    this.getCommittedRevision = getCommittedRevision;
    this.readValue = readValue;
    this.commitValues = commitValues;
    this.assertSlotIndex = assertSlotIndex;
    this.prepareValues = prepareValues;
  }
  staged = /* @__PURE__ */ new Map();
  closed = false;
  set(slotIndex, value) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    this.staged.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.assertOpen();
    this.assertSlotIndex(slotIndex);
    const current = this.staged.has(slotIndex) ? this.staged.get(slotIndex) : this.readValue(slotIndex);
    this.staged.set(slotIndex, updater(current));
  }
  discard() {
    this.assertOpen();
    this.closed = true;
    this.staged.clear();
  }
  prepareCommit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) throw new Error("Stale scalar preparation");
    return this.prepareValues(this.staged, options);
  }
  commit(options) {
    this.assertOpen();
    this.closed = true;
    if (this.getCommittedRevision() !== this.baseRevision) {
      throw new Error("ScalarSlotMutationFrame base revision is stale.");
    }
    if (this.staged.size > 0) {
      return this.commitValues(this.staged, options);
    }
    return {
      revision: this.getCommittedRevision(),
      changedSlots: []
    };
  }
  assertOpen() {
    if (this.closed) {
      throw new Error("ScalarSlotMutationFrame is already closed.");
    }
  }
};
function createTreeScalarSlotRuntime(physicalCommitClock) {
  const values = [];
  const equalities = [];
  const slotByPositionId = /* @__PURE__ */ new Map();
  let revision = 0;
  const getCommittedRevision = () => physicalCommitClock?.revision() ?? revision;
  const advanceRevision = () => {
    const nextRevision = physicalCommitClock?.advance();
    if (nextRevision !== void 0) {
      return nextRevision;
    }
    revision += 1;
    return revision;
  };
  const assertSlotIndex = (slotIndex) => {
    if (!Number.isInteger(slotIndex) || slotIndex < 0 || slotIndex >= values.length) {
      throw new Error(`Scalar slot index ${slotIndex} is out of bounds.`);
    }
  };
  const collectSlotChanges = (staged) => {
    const changed = [];
    for (const [slotIndex, nextValue] of staged) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      if (!equalities[slotIndex](values[slotIndex], nextValue)) {
        changed.push({ slotIndex, nextValue });
      }
    }
    return changed;
  };
  const prepareSlots = (staged, options) => {
    const base = getCommittedRevision();
    const changed = collectSlotChanges(staged);
    if (getCommittedRevision() !== base) throw new Error("Reentrant scalar preparation");
    let used = false;
    return () => {
      if (used) throw new Error("Prepared scalar commit already used");
      if (getCommittedRevision() !== base) throw new Error("Stale prepared scalar commit");
      used = true;
      for (const { slotIndex, nextValue } of changed) {
        values[slotIndex] = nextValue;
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("slotWrites");
        }
      }
      const revision2 = changed.length && options?.advanceRevision !== false ? advanceRevision() : getCommittedRevision();
      if (changed.length && options?.advanceRevision !== false && PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return { revision: revision2, changedSlots: changed.map((x) => x.slotIndex) };
    };
  };
  const commitSlots = (staged, options) => {
    const changed = collectSlotChanges(staged);
    if (changed.length === 0) {
      return {
        revision: getCommittedRevision(),
        changedSlots: []
      };
    }
    for (const { slotIndex, nextValue } of changed) {
      values[slotIndex] = nextValue;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("slotWrites", changed.length);
    }
    const nextRevision = options?.advanceRevision === false ? getCommittedRevision() : advanceRevision();
    if (options?.advanceRevision !== false && PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("revisionIncrements");
    }
    return {
      revision: nextRevision,
      changedSlots: changed.map(({ slotIndex }) => slotIndex)
    };
  };
  const commitSlotValue = (slotIndex, nextValue, options) => {
    assertSlotIndex(slotIndex);
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("equalityChecks");
    }
    if (equalities[slotIndex](values[slotIndex], nextValue)) return false;
    values[slotIndex] = nextValue;
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("slotWrites");
    }
    if (options?.advanceRevision !== false) {
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
    }
    return true;
  };
  const commitSlot = (slotIndex, nextValue, options) => {
    const changed = commitSlotValue(slotIndex, nextValue, options);
    return changed ? { revision: getCommittedRevision(), changed: true, slot: slotIndex } : { revision: getCommittedRevision(), changed: false };
  };
  return {
    createSlot(initialValue, equal, positionId) {
      const slotIndex = values.length;
      values.push(initialValue);
      equalities.push(equal);
      if (positionId !== void 0) {
        slotByPositionId.set(positionId, slotIndex);
      }
      return slotIndex;
    },
    readSlot(slotIndex) {
      assertSlotIndex(slotIndex);
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotReads");
      }
      return values[slotIndex];
    },
    commitRecorded(slotIndex, value, prepare) {
      assertSlotIndex(slotIndex);
      const base = getCommittedRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("equalityChecks");
      }
      const equal = equalities[slotIndex](values[slotIndex], value);
      if (getCommittedRevision() !== base) throw new Error("Scalar equality reentered physical installation");
      if (equal) return false;
      const plan = prepare?.();
      if (getCommittedRevision() !== base) throw new Error("Terminal preparation reentered physical installation");
      values[slotIndex] = value;
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("slotWrites");
      }
      if (plan) {
        for (let i = 0; i < plan.writes.length; i++) {
          const w = plan.writes[i];
          w.map.set(w.key, w.value);
        }
        for (let i = 0; i < plan.adds.length; i++) {
          const a = plan.adds[i];
          a.set.add(a.value);
        }
      }
      advanceRevision();
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("revisionIncrements");
      }
      return true;
    },
    commitSlot(slotIndex, value) {
      return commitSlot(slotIndex, value);
    },
    commitSlotValue(slotIndex, value) {
      return commitSlotValue(slotIndex, value);
    },
    updateSlot(slotIndex, updater) {
      assertSlotIndex(slotIndex);
      return commitSlot(slotIndex, updater(values[slotIndex]));
    },
    beginFrame() {
      return new ScalarSlotMutationFrameImpl(
        getCommittedRevision(),
        getCommittedRevision,
        (slotIndex) => values[slotIndex],
        commitSlots,
        assertSlotIndex,
        prepareSlots
      );
    },
    resolveScalarSlot(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return slotByPositionId.get(positionId);
    },
    revision() {
      return getCommittedRevision();
    },
    slotCount() {
      return values.length;
    }
  };
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/tree-scalar-leaf-runtime.ts
var ScalarSlotPublication = class {
  constructor(locations) {
    this.locations = locations;
  }
  bindings = [];
  bind(slotIndex, binding) {
    this.bindings[slotIndex] = binding;
  }
  publish(result) {
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications", result.changedSlots.length);
    }
    const publishers = result.changedSlots.flatMap((slotIndex) => {
      const binding = this.bindings[slotIndex];
      return binding ? [binding] : [];
    });
    this.locations.publish(publishers);
  }
  prepareSlot(slotIndex, changed, force = false) {
    if (!changed && !force) {
      return false;
    }
    if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
      recordProductionSubstrateStat("publications");
    }
    return true;
  }
};
var ScalarSlotMutationFrameOrchestrator = class {
  constructor(frame, publication) {
    this.frame = frame;
    this.publication = publication;
  }
  set(slotIndex, value) {
    this.frame.set(slotIndex, value);
  }
  update(slotIndex, updater) {
    this.frame.update(slotIndex, updater);
  }
  discard() {
    this.frame.discard();
  }
  prepareCommit(options) {
    const install = this.frame.prepareCommit({ advanceRevision: options?.advanceRevision });
    return () => {
      const result = install();
      if (options?.publish !== false) this.publication.publish(result);
      return result;
    };
  }
  commit(options) {
    const result = this.frame.commit({
      advanceRevision: options?.advanceRevision
    });
    if (options?.publish !== false) {
      this.publication.publish(result);
    }
    return result;
  }
};
function createScalarLeaf(kernel, publication, locations, slotIndex, liveness) {
  const holder = {};
  const read = (stored) => {
    if (!stored && liveness.absence?.isAbsent(holder.leaf)) {
      return void 0;
    }
    return kernel.readSlot(slotIndex);
  };
  const binding = locations.createWritable(read, (value, _intent, prepare) => {
    const changedValue = kernel.commitRecorded(slotIndex, value, prepare);
    const result = { changed: changedValue };
    const reAdded = liveness.absence?.reAdd(holder.leaf) === true;
    const changed = publication.prepareSlot(slotIndex, result.changed, reAdded);
    return changed;
  });
  const leaf = binding.location;
  holder.leaf = leaf;
  return { leaf, binding };
}
function createTreeScalarLeafRuntime(physicalCommitClock, locations = createLocationRuntime(
  NEUTRAL_OBSERVATION_ADAPTER
)) {
  const kernel = createTreeScalarSlotRuntime(physicalCommitClock);
  const publication = new ScalarSlotPublication(locations);
  const leafByPositionId = /* @__PURE__ */ new Map();
  const liveness = {};
  return {
    enableAbsence(absence) {
      liveness.absence = absence;
    },
    disableAbsence() {
      liveness.absence = void 0;
    },
    createLeaf(initialValue, equal, positionId) {
      const slotIndex = kernel.createSlot(initialValue, equal, positionId);
      const { leaf, binding } = createScalarLeaf(
        kernel,
        publication,
        locations,
        slotIndex,
        liveness
      );
      publication.bind(slotIndex, binding);
      if (positionId !== void 0) {
        leafByPositionId.set(positionId, leaf);
      }
      return leaf;
    },
    beginFrame() {
      return new ScalarSlotMutationFrameOrchestrator(
        kernel.beginFrame(),
        publication
      );
    },
    runInvalidationGroup(run) {
      locations.runInvalidationGroup(run);
    },
    publishPrepared(result) {
      publication.publish(result);
    },
    resolveScalarSlot(positionId) {
      return kernel.resolveScalarSlot(positionId);
    },
    resolveScalarLeaf(positionId) {
      if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
        recordProductionSubstrateStat("positionResolutions");
      }
      return leafByPositionId.get(positionId);
    },
    revision() {
      return kernel.revision();
    },
    slotCount() {
      return kernel.slotCount();
    }
  };
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/physical-commit-clock.ts
var PHYSICAL_COMMIT_CLOCK = Symbol.for("SignalTree:PhysicalCommitClock");
function createPhysicalCommitClock() {
  let revision = 0;
  return {
    revision() {
      return revision;
    },
    advance() {
      revision += 1;
      return revision;
    }
  };
}
function definePhysicalCommitClock(node, clock) {
  Object.defineProperty(node, PHYSICAL_COMMIT_CLOCK, {
    value: clock,
    enumerable: false,
    configurable: true
  });
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/tree-capabilities.ts
var TREE_CAPABILITY_ORDER = [
  "mutation-capture",
  "position-topology",
  "causal-runtime",
  "temporal-snapshots"
];
var TREE_CAPABILITY_DEPENDENCIES = {
  "mutation-capture": [],
  "position-topology": [],
  "causal-runtime": ["mutation-capture", "position-topology"],
  "temporal-snapshots": []
};
var canonicalizeCapabilities = (capabilities) => {
  const set = new Set(capabilities);
  return TREE_CAPABILITY_ORDER.filter((capability) => set.has(capability));
};
function collectRequestedTreeCapabilities(enhancerMeta) {
  const requested = /* @__PURE__ */ new Set();
  for (const meta of enhancerMeta) {
    for (const capability of meta?.capabilities ?? []) {
      requested.add(capability);
    }
  }
  return canonicalizeCapabilities(requested);
}
function resolveTreeCapabilities(requestedCapabilities) {
  assertTreeCapabilityGraphAcyclic();
  const requested = canonicalizeCapabilities(requestedCapabilities);
  const resolved = new Set(requested);
  const queue = [...requested];
  while (queue.length > 0) {
    const capability = queue.shift();
    if (!capability) {
      continue;
    }
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      if (resolved.has(dependency)) {
        continue;
      }
      resolved.add(dependency);
      queue.push(dependency);
    }
  }
  return {
    requestedCapabilities: requested,
    resolvedCapabilities: canonicalizeCapabilities(resolved)
  };
}
function assertTreeCapabilityGraphAcyclic() {
  const visiting = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new Set();
  const visit = (capability) => {
    if (visited.has(capability)) {
      return;
    }
    if (visiting.has(capability)) {
      throw new Error(
        `SignalTree: capability dependency cycle detected at "${capability}".`
      );
    }
    visiting.add(capability);
    for (const dependency of TREE_CAPABILITY_DEPENDENCIES[capability]) {
      visit(dependency);
    }
    visiting.delete(capability);
    visited.add(capability);
  };
  for (const capability of TREE_CAPABILITY_ORDER) {
    visit(capability);
  }
}
var TREE_CAPABILITIES = Symbol.for("SignalTree:TreeCapabilities");
function defineTreeCapabilities(tree2, capabilities) {
  Object.defineProperty(tree2, TREE_CAPABILITIES, {
    value: capabilities,
    enumerable: false,
    configurable: true
  });
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/internals/merge-derived.ts
function ensurePathAndGetTarget($, path) {
  if (!path) return $;
  const parts = path.split(".");
  let current = $;
  for (const part of parts) {
    if (!(part in current)) {
      current[part] = {};
    }
    current = current[part];
  }
  return current;
}
function mergeDerivedState($, derivedDef, path = "", locations) {
  if (!derivedDef || typeof derivedDef !== "object") {
    return;
  }
  for (const [key, value] of Object.entries(derivedDef)) {
    const currentPath = path ? `${path}.${key}` : key;
    if (typeof value === "function" && locations) {
      const target = ensurePathAndGetTarget($, path);
      if (key in target && false) {
        console.warn(
          `SignalTree: Derived location "${currentPath}" overwrites source state. Consider using a different key to avoid confusion.`
        );
      }
      target[key] = stampDerived(
        locations.createDerived(value)
      );
    } else if (typeof value === "object" && value !== null) {
      const target = ensurePathAndGetTarget($, path);
      if (!(key in target)) {
        target[key] = {};
      } else if (isTreeCell(target[key])) {
        throw new Error(
          `SignalTree: Cannot merge derived object into "${currentPath}" because source is a signal. Either make source an object or use a different key.`
        );
      }
      mergeDerivedState($, value, currentPath, locations);
    } else if (false) {
      console.warn(
        `[SignalTree] [ST2007] Derived "${currentPath}" dropped: the value could not be realized by this tree. Return a computation recipe, a value recognized by the package realization, or a nested object. See ST2007.`
      );
    }
  }
}
function applyDerivedFactory($, factory, locations) {
  mergeDerivedState($, factory($), "", locations);
}

// ../../../../../../private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/signal-tree.ts
var isWritableCell = (v) => typeof v === "function" && "set" in v && typeof v.set === "function";
var readWritableCell = (cell) => "peek" in cell && typeof cell.peek === "function" ? cell.peek() : cell();
var ENTITY_ARRAY_MIN_LENGTH = 32;
var ENTITY_ARRAY_SAMPLE = 64;
var ENTITY_ID_KEYS = ["id", "_id", "uuid", "key"];
var ENTITY_ARRAY_WARNED = /* @__PURE__ */ new Set();
var ENTITY_ARRAY_WARN_CAP = 256;
var NODE_ACCESSOR_PEER2 = Symbol.for("SignalTree:NodeAccessorPeer");
function createTreeBuildPlan(requestedCapabilities, leafMetadataStorage) {
  const resolved = resolveTreeCapabilities(requestedCapabilities);
  return {
    requestedCapabilities: resolved.requestedCapabilities,
    capabilities: resolved.resolvedCapabilities,
    has(capability) {
      return resolved.resolvedCapabilities.includes(capability);
    },
    leafMetadataStorage
  };
}
function finalizeLeafSignal(leaf, path, positionIds, buildPlan, captureRuntime, registry, address) {
  defineNodeAddress(leaf, address);
  for (const position of positionIds ?? [])
    registry?.registerPositionAddress(position, address);
  if (buildPlan.has("position-topology") && registry) {
    definePositionRegistry(leaf, registry);
  }
  if (buildPlan.has("mutation-capture")) {
    wrapOwnedWritableSignal(leaf, {
      path,
      // `ownerPath: path` sat here until 15.0 (ME-B). The owner-address fact is
      // still installed on the leaf — it is now derived from `path` inside
      // owned-mutation rather than passed as a second, identical argument.
      positionIds,
      ownerId: registry?.id,
      metadataStorage: buildPlan.leafMetadataStorage,
      captureRuntime
    });
    return;
  }
  if (buildPlan.has("position-topology")) {
    defineOwnedPositionIds(leaf, positionIds);
    defineOwnedOwnerId(leaf, registry?.id);
  }
  if (registry) {
    definePositionRegistry(leaf, registry);
    defineOwnedOwnerPath(leaf, path);
    installDormantObservation(leaf);
  }
}
function getEnhancerMeta(enhancer) {
  return enhancer[ENHANCER_META] ?? enhancer.metadata;
}
function buildTreePlan(enhancers, explicitCapabilities = []) {
  const requestedCapabilities = collectRequestedTreeCapabilities([
    ...enhancers.map((enhancer) => getEnhancerMeta(enhancer)),
    // An explicit request is treated as one more declaration, so it goes
    // through the same dependency resolution rather than bypassing it.
    { capabilities: [...explicitCapabilities] }
  ]);
  return createTreeBuildPlan(requestedCapabilities, "property");
}
function materializeTreeMarkers(tree2, materializationContext, authority) {
  materializeMarkers(tree2.$, void 0, [], materializationContext, authority);
  _recordTreeConstruction();
}
function isEntityMapMarker(value) {
  return Boolean(
    value && typeof value === "object" && value["__isEntityMap"] === true
  );
}
function createEqualityFn(useShallowComparison) {
  return useShallowComparison ? Object.is : deepEqual;
}
function makeNodeAccessor(store, ownerPath, positionIds, registry, locations) {
  const isRoot = ownerPath === "";
  const self = {};
  const applyGrouped = (run) => {
    if (locations) locations.runInvalidationGroup(run);
    else run();
  };
  const accessor = {
    node(arg) {
      if (arguments.length === 0) {
        if (!isRoot && self.accessor !== void 0 && isAbsentMember(self.accessor)) {
          observeMembership(store);
          return void 0;
        }
        return materializeNode(store);
      }
      const absent = !isRoot && isAbsentMember(self.accessor);
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = absent ? void 0 : unwrap(store);
        updates = updater(current);
      }
      applyGrouped(() => {
        recursiveUpdate(store, updates, void 0, "");
        if (absent && updates && typeof updates === "object")
          reactivatePathOnWrite(self.accessor);
      });
    }
  }.node;
  self.accessor = accessor;
  accessor[CALLABLE_SIGNAL_SYMBOL] = true;
  Object.defineProperty(accessor, NODE_STORE_SYMBOL, {
    value: store,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(store, NODE_ACCESSOR_PEER2, {
    value: accessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  for (const key of Object.keys(store)) {
    Object.defineProperty(accessor, key, {
      value: store[key],
      enumerable: true,
      writable: true,
      configurable: true
    });
  }
  const address = getNodeAddress(store);
  if (address) defineNodeAddress(accessor, address);
  if (positionIds && positionIds.length > 0) {
    defineOwnedPositionIds(accessor, positionIds);
  }
  if (ownerPath !== void 0) {
    defineOwnedOwnerPath(accessor, ownerPath);
  }
  if (registry) {
    definePositionRegistry(accessor, registry);
    defineOwnedOwnerId(accessor, registry.id);
    definePositionRegistry(store, registry);
    defineOwnedOwnerId(store, registry.id);
  }
  if (locations) {
    bindLocationRuntime(accessor, locations);
    bindLocationRuntime(store, locations);
  }
  return accessor;
}
var MARKER_IN_ARRAY_WARNED = /* @__PURE__ */ new Set();
var looksLikeMarker = (item) => item !== null && typeof item === "object" && (isEntityMapMarker(item) || isRegisteredMarker(item));
function warnMarkerInContainer(key, value) {
  if (true) return;
  if (MARKER_IN_ARRAY_WARNED.has(key)) return;
  let where;
  let container;
  if (Array.isArray(value)) {
    const limit = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
    for (let i = 0; i < limit; i++) {
      if (looksLikeMarker(value[i])) {
        where = `"${key}[${i}]"`;
        container = "an array. Array elements";
        break;
      }
    }
  } else if (value instanceof Map) {
    let i = 0;
    for (const [k, v] of value) {
      if (i++ >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(v)) {
        where = `"${key}" -> Map value at key ${JSON.stringify(String(k))}`;
        container = "a Map. Map values";
        break;
      }
    }
  } else if (value instanceof Set) {
    let i = 0;
    for (const member of value) {
      if (i >= ENTITY_ARRAY_SAMPLE) break;
      if (looksLikeMarker(member)) {
        where = `"${key}" -> Set member #${i}`;
        container = "a Set. Set members";
        break;
      }
      i++;
    }
  }
  if (where === void 0 || container === void 0) return;
  MARKER_IN_ARRAY_WARNED.add(key);
  console.warn(
    `SignalTree: ${where} holds a MARKER inside ${container} are never traversed, so the marker is never materialised \u2014 it stays a raw object, it is not a signal, and writes to it are lost. Markers belong at object positions; for a keyed collection use entityMap({ selectId }). [ST2021]`
  );
}
function warnEntityArrayLeaf(key, value) {
  if (true) return;
  if (value.length < ENTITY_ARRAY_MIN_LENGTH) return;
  const first = value[0];
  if (first === null || typeof first !== "object" || Array.isArray(first)) {
    return;
  }
  const idKey = ENTITY_ID_KEYS.find((candidate) => {
    const v = first[candidate];
    return typeof v === "string" || typeof v === "number";
  });
  if (!idKey) return;
  const sampleSize = Math.min(value.length, ENTITY_ARRAY_SAMPLE);
  const seen2 = /* @__PURE__ */ new Set();
  for (let i = 0; i < sampleSize; i++) {
    const item = value[i];
    if (item === null || typeof item !== "object" || Array.isArray(item)) {
      return;
    }
    const id = item[idKey];
    if (typeof id !== "string" && typeof id !== "number") return;
    if (seen2.has(id)) return;
    seen2.add(id);
  }
  const seenKey = `${key}:${idKey}`;
  if (ENTITY_ARRAY_WARNED.has(seenKey)) return;
  if (ENTITY_ARRAY_WARNED.size >= ENTITY_ARRAY_WARN_CAP) return;
  ENTITY_ARRAY_WARNED.add(seenKey);
  console.warn(
    `SignalTree: "${key}" holds ${value.length} objects with a stable "${idKey}" \u2014 use entityMap({ selectId: (e) => e.${idKey} }). An array leaf rebuilds and re-compares the whole array on every update \u2014 two orders of magnitude at 50k. Read-only or replaced wholesale? Leave it plain; otherwise model it as an entityMap. [ST2018]`
  );
}
function warnDiscardedBranchWrite(path, value) {
  if (false) {
    console.error(
      `SignalTree: write to "${path}" DISCARDED \u2014 a branch cannot be replaced by a non-object value (received ${value === null ? "null" : typeof value}). Write the leaves, or use a marker if this position should hold a value. [ST2014]`
    );
  }
}
function warnMissingForward(method) {
  if (false) {
    console.error(
      `SignalTree: "${method}" could not be forwarded \u2014 an enhancer in the configured set returned a tree without it, so this call did NOTHING. An enhancer that builds a new tree object must copy own property DESCRIPTORS, not Object.assign, which skips non-enumerable methods. [ST2017]`
    );
  }
}
setMemberValueApplier(
  (parent, key, member, value) => {
    if (typeof member === "function") {
      member(value);
    }
    const woke = setMemberPresence(parent, key, "active");
    if (woke) publishMembershipChange(parent);
  }
);
function recursiveUpdate(target, updates, out, pathPrefix = "", reconcileMembership = true, since = ++structuralWrites.stamp) {
  if (!updates || typeof updates !== "object") return;
  beginStructuralWrite();
  try {
    const targetObj = isNodeAccessor(target) ? target : target;
    const dormant = hasDormantMembers(targetObj);
    const publishMembership = reconcileMembership || dormant ? captureBranchMembershipIfObserved(
      targetObj[NODE_ACCESSOR_PEER2] ?? targetObj,
      updates,
      !reconcileMembership
    ) : void 0;
    const installed = dormant ? /* @__PURE__ */ new Set() : void 0;
    for (const [key, rawValue] of Object.entries(
      updates
    )) {
      let value = rawValue;
      const prop = targetObj[key];
      const childPath = pathPrefix ? `${pathPrefix}.${key}` : key;
      if (prop === void 0) {
        if (false) {
          console.error(
            `SignalTree: write to "${childPath}" DISCARDED \u2014 key is not in the tree's initial shape. [ST2010]`
          );
        }
        continue;
      }
      const ownHydrate = structuralWrites.own;
      structuralWrites.own = prop;
      let hydrated;
      try {
        hydrated = hydrateMarkerNode(prop, value, "restore");
      } finally {
        structuralWrites.own = ownHydrate;
      }
      if (hydrated) {
        if (out) out.push(childPath);
        installed?.add(key);
        continue;
      }
      if (isNodeAccessor(prop)) {
        if (typeof value === "function") {
          const updater = value;
          value = updater(isAbsentMember(prop) ? void 0 : unwrap(prop));
          const mergeable = isTraversableNode(value) && typeof value !== "function" && !isBuiltInObject(value) && !Array.isArray(value) && typeof value.then !== "function";
          if (!mergeable) {
            warnDiscardedBranchWrite(childPath, value);
            continue;
          }
        }
        if (typeof value === "function") {
          warnDiscardedBranchWrite(childPath, value);
        } else if (value && typeof value === "object") {
          recursiveUpdate(prop, value, out, childPath, true, since);
          installed?.add(key);
        } else if (value === void 0) {
          continue;
        } else {
          warnDiscardedBranchWrite(childPath, value);
        }
      } else if (isWritableLocation(prop) || isWritableCell(prop)) {
        const sig = prop;
        const current = readWritableCell(sig);
        if (current === value && !isAbsentMember(sig)) {
          if (false) {
            warnedNoopPaths.add(childPath);
            console.warn(
              `SignalTree: write at "${childPath}" was skipped \u2014 the value is reference-identical to the current value. If you mutated an object/array in place, create a NEW reference (spread/slice/map) so the change is observed. [ST2003]`
            );
          }
          continue;
        }
        const wasAbsent = out !== void 0 && isAbsentMember(sig);
        const ownWrite = structuralWrites.own;
        structuralWrites.own = sig;
        try {
          if (isWritableLocation(sig)) replaceLocation(sig, value);
          else sig.set(value);
        } finally {
          structuralWrites.own = ownWrite;
        }
        installed?.add(key);
        if (out) {
          if (wasAbsent || !Object.is(readWritableCell(sig), current))
            out.push(childPath);
        }
      }
    }
    const membershipChanged = [];
    const supplied = reconcileMembership || installed ? new Set(Object.keys(updates)) : void 0;
    if (supplied)
      for (const key of reconcileMembership ? Object.getOwnPropertyNames(targetObj) : supplied) {
        if (PRODUCTION_SUBSTRATE_STATS_ENABLED) {
          recordProductionSubstrateStat("membershipKeysVisited");
        }
        const descriptor = Object.getOwnPropertyDescriptor(targetObj, key);
        if (!descriptor || !("value" in descriptor)) continue;
        if (!supplied.has(key)) {
          if (descriptor.enumerable && // A write made while this whole value ran re-added it: it stays.
          !readdedDuringStructuralWrite(targetObj, key, since) && setMemberPresence(targetObj, key, "dormant")) {
            membershipChanged.push(key);
          }
        } else if (
          // Only a member whose supplied value was installed is re-added: a key
          // supplied as `undefined`, or with a value the loop discarded, would
          // otherwise come back with its retained storage. Measured before v16 8d:
          // `$({ a: undefined, count: 0 })` re-added an omitted `a` as `{ v: 1 }`.
          // "DORMANT STORAGE MUST NOT SUPPLY THE REACTIVATED VALUE" (case 18).
          !descriptor.enumerable && installed?.has(key) && setMemberPresence(targetObj, key, "active")
        ) {
          membershipChanged.push(key);
        }
      }
    publishMembership?.();
    if (membershipChanged.length > 0) {
      republishMembers(targetObj, membershipChanged);
    }
  } finally {
    endStructuralWrite();
  }
}
function materializeOrdinaryBranch(value, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, childPositionIds, childPath, address) {
  const nested = createSignalStore(
    value,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    childPositionIds,
    childPath,
    address
  );
  const accessor = makeNodeAccessor(
    nested,
    childPath,
    childPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(accessor, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(nested, scalarSlotRuntime);
  }
  return accessor;
}
function createSignalStore(obj, equalityFn, materializationContext, buildPlan, captureRuntime, scalarSlotRuntime, positionIds, path = "", address = []) {
  for (const position of positionIds ?? []) {
    materializationContext.positionRegistry.registerPositionAddress(
      position,
      address
    );
  }
  const createLeafSignal = (value, leafPositionIds, equal) => {
    if (scalarSlotRuntime) {
      return scalarSlotRuntime.createLeaf(
        value,
        equal,
        leafPositionIds?.[0]
      );
    }
    return materializationContext.locationRuntime.createCell(value, equal);
  };
  if (obj === null || obj === void 0 || typeof obj !== "object") {
    const equal = false ? leafEqual(equalityFn, path) : equalityFn;
    const leaf = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf;
  }
  if (Array.isArray(obj)) {
    const equal = false ? leafEqual(equalityFn, path) : equalityFn;
    const leaf = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf;
  }
  if (isBuiltInObject(obj)) {
    const equal = false ? leafEqual(equalityFn, path) : equalityFn;
    const leaf = createLeafSignal(obj, positionIds, equal);
    finalizeLeafSignal(
      leaf,
      path,
      positionIds,
      buildPlan,
      captureRuntime,
      materializationContext.positionRegistry,
      address
    );
    return leaf;
  }
  const store = {};
  defineNodeAddress(store, address);
  for (const [key, definedValue] of Object.entries(
    obj
  )) {
    const childAddress = childAddressOf(address, key);
    const childPath = path ? `${path}.${key}` : key;
    const terminal = isLeafDefinition(definedValue);
    const value = terminal ? leafDefinitionValue(definedValue) : definedValue;
    if (terminal && (isEntityMapMarker(value) || isRegisteredMarker(value))) {
      throw new Error(
        `SignalTree: leaf() cannot wrap a semantic marker at "${childPath}".`
      );
    }
    let childPositionIds;
    const getChildPositionIds = () => {
      if (!materializationContext.positionTopologyEnabled) {
        return void 0;
      }
      return childPositionIds ??= [
        materializationContext.allocatePositionId(positionIds?.[0])
      ];
    };
    if (key === "__proto__") {
      if (false) {
        console.error(
          `SignalTree: dropped a "__proto__" key from the initial state \u2014 it cannot be a state key. If this came from JSON.parse, the payload is attempting prototype pollution. [ST2016]`
        );
      }
      continue;
    }
    if (isEntityMapMarker(value)) {
      store[key] = value;
      continue;
    }
    if (isRegisteredMarker(value)) {
      store[key] = value;
      continue;
    }
    if (false) {
      if (!terminal && value !== null && typeof value === "object" && !Array.isArray(value) && Object.getOwnPropertySymbols(value).length > 0) {
        console.warn(
          `SignalTree: Object at "${key}" has Symbol keys but doesn't match any registered marker processor. If this is a custom marker, ensure registerMarkerProcessor() is called BEFORE creating the tree.`
        );
      }
    }
    if (terminal || value === null || value === void 0 || typeof value !== "object") {
      const childPositionIds2 = getChildPositionIds();
      const equal = false ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf;
      continue;
    }
    if (Array.isArray(value) || isBuiltInObject(value)) {
      warnMarkerInContainer(key, value);
      if (Array.isArray(value)) {
        warnEntityArrayLeaf(key, value);
      }
      const childPositionIds2 = getChildPositionIds();
      const equal = false ? leafEqual(equalityFn, childPath) : equalityFn;
      const leaf = createLeafSignal(value, childPositionIds2, equal);
      finalizeLeafSignal(
        leaf,
        childPath,
        childPositionIds2,
        buildPlan,
        captureRuntime,
        materializationContext.positionRegistry,
        childAddress
      );
      store[key] = leaf;
      continue;
    }
    store[key] = materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      getChildPositionIds(),
      childPath,
      childAddress
    );
  }
  markTreeStore(store);
  return store;
}
function create(initialState, config, materializationContext, buildPlan, captureRuntime = createMutationCaptureRuntime(), createScalarLeafRuntime = createTreeScalarLeafRuntime) {
  if (initialState === null || initialState === void 0) {
    throw new Error(SIGNAL_TREE_MESSAGES.NULL_OR_UNDEFINED);
  }
  const equalityFn = createEqualityFn(config.useShallowComparison ?? false);
  const scalarSlotRuntime = createScalarLeafRuntime(
    materializationContext.physicalCommitClock,
    materializationContext.locationRuntime
  );
  const materializeOrdinaryState = (value, path, parentPositionId, address) => {
    const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(parentPositionId)] : void 0;
    return materializeOrdinaryBranch(
      value,
      equalityFn,
      materializationContext,
      buildPlan,
      captureRuntime,
      scalarSlotRuntime,
      childPositionIds,
      path,
      address
    );
  };
  const constructionAuthority = {
    materialize: materializeOrdinaryState,
    bindMember: (ownerBranch) => {
      const ownerPositionId = getOwnedPositionIds(ownerBranch)?.[0];
      const ownerPath = getOwnedOwnerPath(ownerBranch) ?? "";
      const ownerAddress = getNodeAddress(ownerBranch);
      if (!ownerAddress)
        throw new Error("Missing dynamic branch construction address.");
      return (key, value) => {
        const childPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId(ownerPositionId)] : void 0;
        const childPath = ownerPath ? `${ownerPath}.${key}` : key;
        return materializeOrdinaryBranch(
          value,
          equalityFn,
          materializationContext,
          buildPlan,
          captureRuntime,
          scalarSlotRuntime,
          childPositionIds,
          childPath,
          childAddressOf(ownerAddress, key)
        );
      };
    }
  };
  const rootPositionIds = materializationContext.positionTopologyEnabled ? [materializationContext.allocatePositionId()] : void 0;
  const signalState = createSignalStore(
    initialState,
    equalityFn,
    materializationContext,
    buildPlan,
    captureRuntime,
    scalarSlotRuntime,
    rootPositionIds
  );
  const rootAccessor = makeNodeAccessor(
    signalState,
    "",
    rootPositionIds,
    materializationContext.positionRegistry,
    materializationContext.locationRuntime
  );
  const tree2 = {};
  defineNodeAddress(tree2, []);
  bindLocationRuntime(tree2, materializationContext.locationRuntime);
  bindLocationRuntime(
    signalState,
    materializationContext.locationRuntime
  );
  bindLocationRuntime(
    rootAccessor,
    materializationContext.locationRuntime
  );
  tree2[MUTATION_CAPTURE_RUNTIME] = captureRuntime;
  if (rootPositionIds) {
    defineOwnedPositionIds(tree2, rootPositionIds);
    defineOwnedPositionIds(signalState, rootPositionIds);
    defineOwnedPositionIds(rootAccessor, rootPositionIds);
  }
  defineTreeCapabilities(tree2, buildPlan.capabilities);
  if (buildPlan.has("mutation-capture")) {
    defineOwnedOwnerPath(tree2, "");
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  if (materializationContext.positionTopologyEnabled) {
    definePositionRegistry(
      tree2,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    definePositionRegistry(
      rootAccessor,
      materializationContext.positionRegistry
    );
  }
  if (materializationContext.positionRegistry) {
    definePositionRegistry(
      signalState,
      materializationContext.positionRegistry
    );
    defineOwnedOwnerPath(signalState, "");
    defineOwnedOwnerPath(rootAccessor, "");
  }
  defineRootTree(rootAccessor, {
    read: () => rootAccessor(),
    replace: (value) => rootAccessor(value),
    derive: (update) => rootAccessor(update)
  });
  if (materializationContext.physicalCommitClock) {
    definePhysicalCommitClock(
      tree2,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      signalState,
      materializationContext.physicalCommitClock
    );
    definePhysicalCommitClock(
      rootAccessor,
      materializationContext.physicalCommitClock
    );
  }
  if (scalarSlotRuntime) {
    defineTreeScalarSlotRuntime(tree2, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(signalState, scalarSlotRuntime);
    defineTreeScalarSlotRuntime(rootAccessor, scalarSlotRuntime);
  }
  const cleanupFns = [];
  const destroyedSig = materializationContext.locationRuntime.createCell(false);
  Object.defineProperty(tree2, "$", {
    value: rootAccessor,
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree2, "destroy", {
    value: function() {
      if (destroyedSig()) return;
      try {
        replaceLocation(destroyedSig, true);
      } finally {
        terminateOwnerInvalidation(tree2);
        for (const fn of cleanupFns) {
          try {
            fn();
          } catch {
          }
        }
        cleanupFns.length = 0;
        releaseContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
      if (config.debugMode) {
        console.log(SIGNAL_TREE_MESSAGES.TREE_DESTROYED);
      }
    },
    enumerable: false,
    // Allow enhancers (like guardrails) to override/replace `destroy` at runtime.
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree2, "destroyed", {
    value: destroyedSig.asReadonly(),
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree2, "registerCleanup", {
    value: function(fn) {
      if (typeof fn === "function") {
        cleanupFns.push(fn);
      }
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  Object.defineProperty(tree2, "clearCache", {
    value: () => {
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  Object.defineProperty(tree2, "updateAndReport", {
    value: function(arg) {
      if (arguments.length === 0) return [];
      const out = [];
      let updates = arg;
      if (typeof arg === "function") {
        const updater = arg;
        const current = unwrap(signalState);
        updates = updater(current);
      }
      materializationContext.locationRuntime.runInvalidationGroup(() => {
        recursiveUpdate(signalState, updates, out, "", false);
      });
      return out;
    },
    enumerable: false,
    writable: true,
    configurable: true
  });
  return {
    tree: tree2,
    authority: constructionAuthority,
    activateReporting() {
      if (!readWritableCell(destroyedSig)) {
        registerContainedReportBudget(
          materializationContext.positionRegistry.id
        );
      }
    }
  };
}
function applyEnhancers(tree2, ordered) {
  let current = tree2;
  for (const enhancer of ordered) {
    if (typeof enhancer !== "function") {
      throw new Error("Enhancer must be a function");
    }
    const result = enhancer(
      current
    );
    if (result !== current && isTraversableNode(result)) {
      current = result;
    }
  }
  return current;
}
function signalTreeImpl(initialState, config = {}, observation = NEUTRAL_OBSERVATION_ADAPTER, createScalarLeafRuntime = createTreeScalarLeafRuntime, createLocations = createLocationRuntime) {
  const declared = config.enhancers ?? [];
  const ordered = resolveEnhancerOrder(
    [...declared],
    /* @__PURE__ */ new Set(),
    Boolean(config.debugMode)
  );
  const buildPlan = buildTreePlan(ordered, config.capabilities);
  const physicalCommitClock = buildPlan.has("causal-runtime") ? createPhysicalCommitClock() : void 0;
  const captureRuntime = createMutationCaptureRuntime();
  const materializationContext = createMaterializationContext(
    buildPlan.has("position-topology"),
    (capability) => buildPlan.has(capability),
    physicalCommitClock,
    createLocations(observation)
  );
  materializationContext.mutationCaptureRuntime = captureRuntime;
  const constructed = create(
    initialState,
    config,
    materializationContext,
    buildPlan,
    captureRuntime,
    createScalarLeafRuntime
  );
  let tree2 = constructed.tree;
  const authority = constructed.authority;
  const hasEnhancers = ordered.length > 0;
  if (hasEnhancers) {
    materializeTreeMarkers(tree2, materializationContext, authority);
    Object.defineProperty(
      tree2.$,
      Symbol.for("SignalTree:SubjectPhysicalOwners"),
      {
        value: materializationContext.physicalOwners,
        enumerable: false,
        configurable: true
      }
    );
    tree2 = applyEnhancers(tree2, ordered);
  }
  const configured = createConfiguredTree(
    tree2,
    materializationContext,
    hasEnhancers,
    authority,
    config.derived
  );
  constructed.activateReporting();
  return configured;
}
function createConfiguredTree(baseTree, materializationContext, alreadyMaterialized = false, authority, derivedFactory) {
  let isFinalized = false;
  let markersMaterialized = alreadyMaterialized;
  const materializeOnly = () => {
    if (markersMaterialized) return;
    markersMaterialized = true;
    materializeMarkers(
      baseTree.$,
      void 0,
      [],
      materializationContext,
      authority
    );
    _recordTreeConstruction();
  };
  const finalize = () => {
    if (isFinalized) return;
    isFinalized = true;
    materializeOnly();
    if (derivedFactory) {
      applyDerivedFactory(
        baseTree.$,
        derivedFactory,
        materializationContext.locationRuntime
      );
    }
  };
  const rootAccessor = baseTree.$;
  Object.defineProperty(baseTree, "$", {
    get() {
      finalize();
      Object.defineProperty(baseTree, "$", {
        value: rootAccessor,
        enumerable: false,
        configurable: true
      });
      return rootAccessor;
    },
    enumerable: false,
    configurable: true
  });
  const updateAndReport = baseTree.updateAndReport?.bind(baseTree);
  Object.defineProperty(baseTree, "updateAndReport", {
    value: function(arg) {
      finalize();
      if (!updateAndReport) {
        warnMissingForward("updateAndReport");
        return [];
      }
      return updateAndReport(arg);
    },
    enumerable: false,
    writable: false,
    configurable: true
  });
  return baseTree;
}
var signalTree = signalTreeImpl;

// ../../../../../../private/tmp/readiness-review-grouped-8d.ts
var tree = signalTree({ fresh: 0, trigger: [{ x: 0 }] });
console.log("primed", JSON.stringify(tree.$()));
var seen = [];
tree.$({ fresh: 123, trigger: [{ get x() {
  seen.push([tree.$.fresh(), tree.$().fresh]);
  return 1;
} }] });
console.log("inside-equality", JSON.stringify(seen));
console.log("after", tree.$().fresh);
tree.destroy();
