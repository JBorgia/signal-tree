import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
import {getTreeRealizationPort} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/causal-runtime/tree-realization-adapter';
const tree=signalTree({rows:{} as Record<string,number>},{enhancers:[transactions()]}); const port=getTreeRealizationPort(tree.$)!; const original=port.validateEffects; const failure=Object.freeze({failure:true}); let caught:any;
port.validateEffects=()=>({kind:'structural-drift'});
try{tree.transact(()=>{tree.$.rows({fresh:123});throw failure})}catch(e){caught=e}finally{port.validateEffects=original}
const held=tree.$.rows.fresh;
console.log('recovery identity',caught.recovery.callbackError===failure,'changes',caught.recovery.transaction.inspect().changes.length,'before',JSON.stringify(tree.$()));
caught.recovery.transaction.rollback();caught.recovery.transaction.rollback();console.log('after',JSON.stringify(tree.$()),'held',held());tree.destroy();
