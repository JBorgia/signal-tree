import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {link} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/link';
import {getPathNotifier} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/path-notifier';
const tree=signalTree<{trigger:{x:number}[];fresh?:number}>({trigger:[{x:0}]});
const sent:unknown[]=[]; const relationship=link(tree.$,{set:value=>{sent.push(value)}});
console.log('prime',JSON.stringify(tree.$()));
try{tree.$({fresh:123,trigger:[{get x():number{throw Error('equality failure')}}]});}catch(e){console.log(String(e))}
console.log('held fresh',tree.$.fresh?.(),'snapshot',JSON.stringify(tree.$()),'keys',Object.keys(tree.$));getPathNotifier().flushSync(); for(let i=0;i<12;i++)await Promise.resolve(); await relationship.settled(); console.log('sent',sent); relationship.dispose();tree.destroy();
