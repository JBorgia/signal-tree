import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
const tree=signalTree<{trigger:{x:number}[];fresh?:number}>({trigger:[{x:0}]});
console.log('prime',JSON.stringify(tree.$()));
try{tree.$({fresh:123,trigger:[{get x():number{throw Error('equality failure')}}]});}catch(e){console.log(String(e))}
console.log('held fresh',tree.$.fresh?.(),'snapshot',JSON.stringify(tree.$()),'keys',Object.keys(tree.$));tree.destroy();
