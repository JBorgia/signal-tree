import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
const tree=signalTree<{fresh?:number;trigger:{x:number}[]}>({trigger:[{x:0}]},{enhancers:[transactions()]});
const seen:unknown[]=[];
tree.$({fresh:123,trigger:[{get x(){const v=tree.$.fresh?.();seen.push(v);return v??0}}]});
console.log('equality getter observes',seen); console.log('fresh',tree.$.fresh?.()); tree.destroy();
