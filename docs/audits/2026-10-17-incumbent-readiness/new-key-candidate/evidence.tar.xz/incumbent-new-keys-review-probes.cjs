// First run: PATH=/private/tmp/st-b-qualification-20261016/bin:/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin:$PATH node < this-file
// cwd: /Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree
const esbuild = require('esbuild');
const code = `import { signalTree } from './packages/kernel/src/lib/signal-tree';
import { transactions } from './packages/kernel/src/enhancers/transactions/transactions';
const a = signalTree({}, { enhancers: [transactions()] });
const pending = a.transact(() => a.$({ name: 3 }));
console.log('name captured changes', pending.inspect().changes.length);
pending.rollback();
console.log('name after rollback', a.$());
a.destroy();
const b = signalTree({ trigger: { x: 0 } });
let held;
b.$({ trigger: () => { b.$({trigger: {x:0}, fresh:9}); held=b.$.fresh; return {x:1}; }, fresh:1 });
console.log('reentry retained identity', held === b.$.fresh, 'held', held(), 'current', b.$.fresh());
b.destroy();`;
const result = esbuild.buildSync({stdin:{contents:code,resolveDir:process.cwd(),loader:'ts'},bundle:true,platform:'node',format:'cjs',write:false});
new Function('require', result.outputFiles[0].text)(require);
