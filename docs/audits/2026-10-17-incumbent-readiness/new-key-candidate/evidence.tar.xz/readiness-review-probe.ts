import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
import {getTreeScalarSlotRuntime} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tree-scalar-slot-port';
const tree=signalTree({rows:{} as Record<string,unknown>},{enhancers:[transactions()]});
const slots=getTreeScalarSlotRuntime(tree.$);
console.log('slots?',slots?.slotCount());
for(let i=0;i<5;i++) { try {tree.$.rows({good:{payload:new Uint8Array(100000)},bad:{get n(){throw Error('bad')}}});} catch{} console.log('iteration',i,slots?.slotCount(),JSON.stringify(tree.$())); }
tree.destroy();
