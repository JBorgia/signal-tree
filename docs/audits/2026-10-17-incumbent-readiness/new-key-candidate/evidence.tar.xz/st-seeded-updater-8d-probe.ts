import { signalTree } from '/private/tmp/st-sparse-integration-baseline-8d220643/packages/kernel/src/lib/signal-tree';
const tree = signalTree({ trigger: { x: 0 }, fresh: 0 });
const initial = tree.$.fresh;
let held = initial;
try {
  tree.$({
    trigger: (() => {
      tree.$({ trigger: { x: 0 }, fresh: 9 });
      held = tree.$.fresh;
      console.log('inside', JSON.stringify(tree.$()), 'identityInitial', held === initial);
      return { x: 1 };
    }) as unknown as { x: number },
    fresh: 1,
  });
  console.log('final', JSON.stringify(tree.$()), 'identityHeld', tree.$.fresh === held, 'identityInitial', tree.$.fresh === initial);
  if (tree.$().fresh !== 1 || tree.$.fresh !== held || tree.$.fresh !== initial) throw new Error('baseline mismatch');
} finally { tree.destroy(); }
