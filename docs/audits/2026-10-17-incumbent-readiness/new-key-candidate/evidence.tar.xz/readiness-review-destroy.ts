import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
for (const enhancers of [[],[transactions()]]) {
const tree=signalTree({rows:{} as Record<string,unknown>},{enhancers}); tree.destroy();
try{tree.$.rows({b:{n:1}}); console.log('new write after destroy',JSON.stringify(tree.$()), tree.$.rows.b);}catch(e){console.log('reject',String(e))}
}
