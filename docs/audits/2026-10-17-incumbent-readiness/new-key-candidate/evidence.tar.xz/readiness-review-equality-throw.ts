import {signalTree} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/signal-tree';
import {transactions} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions';
import {getTreeScalarSlotRuntime} from '/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/lib/internals/tree-scalar-slot-port';
const tree=signalTree({trigger:[{x:0}]} as {trigger:{x:number}[];fresh?:Uint8Array},{enhancers:[transactions()]});
const slots=getTreeScalarSlotRuntime(tree.$)!;
console.log('initial',slots.slotCount());
for(let i=0;i<5;i++) {try { tree.$({trigger:[{get x(){throw Error('equality failure')}}],fresh:new Uint8Array(100000)}); } catch{} console.log(i,slots.slotCount(),JSON.stringify(tree.$()));}
tree.destroy();
