import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
const require = createRequire('/private/tmp/st-new-key-cost-20261018/shared/package.json');
const esbuild = require('esbuild');
const base = '/private/tmp/st-new-key-cost-20261018/shared/dist/packages';
const here = '/private/tmp/st-k2-vue-shape-20261018';
const result = await esbuild.build({ entryPoints: [here + '/fixture.ts'], outfile: here + '/fixture.mjs', bundle: true, platform: 'node', format: 'esm', metafile: true, nodePaths: ['/private/tmp/st-sparse-integration-baseline-8d220643/node_modules'], alias: { '@signal-tree/vue': base + '/vue/dist/index.js', '@signal-tree/kernel': base + '/kernel/dist/index.js', '@signal-tree/kernel/adapter': base + '/kernel/dist/adapter.js' } });
writeFileSync(here + '/metafile.json', JSON.stringify(result.metafile, null, 2));
