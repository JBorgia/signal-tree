# Zero-net structural compensation counterexample

Replay: `/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node /private/tmp/st-compound-review/zero-net-probe.mjs`.
Raw first result: zero-net-first.log. Each arm has a preserved executable bundle and complete kernel input SHA256 receipt (`zero-net-baseline-inputs.json`, `zero-net-candidate-inputs.json`). Runtime was not changed for this probe.

Sequence, using public API only:
1. Seed A,B,C; designate prepend(C), yielding C,A,B.
2. `transact(() => { addOne(temp); held=byIdOrFail(temp); removeOne(temp); })`.
3. Public inspection contains no changes. Rollback succeeds and becomes terminal. Held temp reads undefined.
4. Visible IDs remain C,A,B; earlier designated undo throws ST1034 frontier mismatch instead of restoring A,B,C.

Same result on preserved incumbent baseline and experimental candidate. No-blocker control succeeds. An independent ordinary add/remove ABA also refuses, demonstrating why value/order equality alone must not authorize frontier restoration.

Causal source evidence: candidate `compensatedFrontiers` requires nonempty expected structural dispositions. More decisively, `applyRollbackCompensation` returns immediately when effects and orderDeltas are empty, before consulting structural interval evidence. Successful terminal rollback then deletes installedOperations. The complete transaction did author two physical frontier changes, but net-effect normalization cancels its add/remove. The new interval evidence therefore remains unused and is retired without restoring its predecessor's applicable lineage.

Interpretation: under the required useful-retry contract, a complete rejected transaction with no surviving contribution and no foreign topology should not make the prior designated order permanently inapplicable. This is ownership-sensitive cancellation, not permission to identify independent ABA by visible equality. The held temporary lifetime must remain detached; restoring ordering lineage must never resurrect it. The existing same-flush descriptor-retention test independently establishes that canceled structural capture drops net effect records, but is not itself a full history-retry acceptance test.

Disposition: candidate passes the nine nonempty compensation controls, but does not establish complete structural-compensation lineage. This counterexample is in the same mechanism family. Do not describe the candidate as general compound-restoration repair. No patch was attempted for this finding.
