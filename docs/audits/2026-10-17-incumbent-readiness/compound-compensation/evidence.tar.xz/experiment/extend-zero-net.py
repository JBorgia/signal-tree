from pathlib import Path
import difflib,hashlib,json
p=Path('/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree/packages/kernel/src/enhancers/transactions/transactions.ts');old=p.read_text();s=old
changes=[]
def replace(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a[:90]);s=s.replace(a,b);changes.append(a)
replace('''    const intervals = new Map<number, { before: unknown; after: unknown; valid: boolean }>();''','''    // Missing responsibility is not equivalent to a known canceled contribution.
    if (!expectedDispositions.has(transactionId)) return new Map();
    const intervals = new Map<number, { before: unknown; after: unknown; valid: boolean }>();''')
replace('''      if (!expected?.size || expected.size !== actual?.size) continue;
      let complete = true;
      for (const [key, effect] of expected) {
        const candidate = actual.get(key);''','''      if ((expected?.size ?? 0) !== (actual?.size ?? 0)) continue;
      let complete = true;
      for (const [key, effect] of expected ?? []) {
        const candidate = actual?.get(key);''')
replace('''  const rollbackPendingTarget = (''','''  const installPreparedCompensation = (
    point: { install(): void; publish(): void } | undefined,
    frontiers: ReturnType<typeof compensatedFrontiers>,
    completion?: { selected: boolean; committed: boolean }
  ): void => {
    if (completion) completion.selected = true;
    for (const interval of frontiers.values())
      if (interval.binding.readOrderFrontier?.() !== interval.after)
        throw new Error('Compensation structural frontier changed during preparation');
    point?.install();
    for (const interval of frontiers.values())
      interval.binding.installCompensatedOrderFrontier?.(interval.before);
    // Interval-only compensation has no value frame to advance the revision.
    if (!point && frontiers.size)
      (getPhysicalCommitClock(tree.$) ?? getPhysicalCommitClock(tree))?.advance();
    if (completion) completion.committed = true;
    point?.publish();
  };

  const rollbackPendingTarget = (''')
replace('''        onCommitted() {
          if (completion) completion.committed = true;
        },''','''        onCommitted() {
          // A canceled structural owner has no row target, but its verified
          // lineage is part of this same installation, before any delivery.
          for (const [owner, interval] of frontiers ?? [])
            if (!target.collections.has(owner))
              interval.binding.installCompensatedOrderFrontier?.(interval.before);
          if (completion) completion.committed = true;
        },''')
replace('''    if (effects.length === 0 && orderDeltas.length === 0) {
      return;
    }''','''    const frontiers = compensatedFrontiers(owningTransactionId, effects, orderDeltas);
    if (effects.length === 0 && orderDeltas.length === 0 && frontiers.size === 0) {
      return;
    }''')
replace('''    const frontiers = compensatedFrontiers(owningTransactionId, effects, orderDeltas);
    const positionRegistry = getPositionRegistry(tree.$);''','''    const positionRegistry = getPositionRegistry(tree.$);''')
replace('''          () => {
            // Keep the baseline complete-target admission for structural''','''          () => {
            if (effects.length === 0 && orderDeltas.length === 0) {
              installPreparedCompensation(undefined, frontiers, completion);
              return { ok: true as const };
            }
            // Keep the baseline complete-target admission for structural''')
replace('''                      if (completion) completion.selected = true;
                      for (const interval of frontiers.values())
                        if (interval.binding.readOrderFrontier?.() !== interval.after)
                          throw new Error('Compensation structural frontier changed during preparation');
                      point.install();
                      for (const interval of frontiers.values())
                        interval.binding.installCompensatedOrderFrontier?.(interval.before);
                      if (completion) completion.committed = true;
                      point.publish();''','''                      installPreparedCompensation(point, frontiers, completion);''')
replace('''                    } else if (
                      normalized.some((effect) => effect.plainBranchMembership)
                    ) {''','''                    } else if (
                      frontiers.size > 0 ||
                      normalized.some((effect) => effect.plainBranchMembership)
                    ) {''')
out=Path('/private/tmp/st-compound-review');(out/'zero-net.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/packages/kernel/src/enhancers/transactions/transactions.ts',tofile='b/packages/kernel/src/enhancers/transactions/transactions.ts')))
(out/'zero-net-seams.json').write_text(json.dumps({'source_sha256':hashlib.sha256(old.encode()).hexdigest(),'unique_replacements':changes},indent=2));print(len(changes),'unique matches; no source writes')
