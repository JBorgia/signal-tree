import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const roots={baseline:'/private/tmp/st-unknown-access-candidate',candidate:'/Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree'};
for(const [arm,root]of Object.entries(roots)){
 const require=createRequire(root+'/package.json');const {build}=require('esbuild');const inputs={};
 const code=`
import {signalTree,entityMap,undoable,restoration,transactions} from './packages/kernel/src/index';
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
const results=[];
for(const variant of ['no-blocker','same-transaction-cancellation','independent-ABA']){
 const tree=signalTree({rows:entityMap<{id:string,n:number},string>({selectId:r=>r.id})},{enhancers:[transactions(),restoration()]});
 try{
  for(const [id,n]of [['a',1],['b',2],['c',3]] as const)tree.$.rows.addOne({id,n});await flush();
  undoable(()=>tree.$.rows.prependMany([{id:'c',n:3}],{mode:'overwrite'}));await flush();
  const before=tree.$.rows.ids();let held;let pending;let inspection;let rollbackError;let confirmationAfterRollback;
  if(variant==='same-transaction-cancellation'){
   pending=tree.transact(()=>{tree.$.rows.addOne({id:'temp',n:4});held=tree.$.rows.byIdOrFail('temp');tree.$.rows.removeOne('temp')});
   inspection=pending.inspect();try{pending.rollback()}catch(e){rollbackError=String(e)}await flush();
   try{pending.confirm()}catch(e){confirmationAfterRollback=String(e)}
  }else if(variant==='independent-ABA'){
   tree.$.rows.addOne({id:'temp',n:4});held=tree.$.rows.byIdOrFail('temp');tree.$.rows.removeOne('temp');await flush();
  }
  const afterRollback=tree.$.rows.ids();let undoError;try{tree.undo()}catch(e){undoError=String(e)}await flush();
  results.push({variant,before,afterRollback,inspection,rollbackError,confirmationAfterRollback,heldDetached:held?held()===undefined:undefined,undoError,afterUndo:tree.$.rows.ids(),canUndo:tree.canUndo(),canRedo:tree.canRedo()});
 }finally{tree.destroy()}
}
console.log(JSON.stringify({arm:${JSON.stringify(arm)},results},null,2));
`;
 const built=await build({stdin:{contents:code,resolveDir:root,loader:'ts'},absWorkingDir:root,bundle:true,write:false,platform:'node',format:'esm',target:'node24',plugins:[{name:'receipt',setup(b){b.onLoad({filter:/\/packages\/kernel\/src\/.*\.ts$/},({path})=>{const contents=readFileSync(path,'utf8');inputs[path.slice(root.length+1)]=createHash('sha256').update(contents).digest('hex');return{contents,loader:'ts'}})}}]});
 const path='/private/tmp/st-compound-review/zero-net-'+arm+'.mjs';writeFileSync(path,built.outputFiles[0].text);writeFileSync('/private/tmp/st-compound-review/zero-net-'+arm+'-inputs.json',JSON.stringify(inputs,null,2));await import(path);
}
