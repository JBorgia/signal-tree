# Final bounded compound compensation candidate

Base: fd3338719b5d694a234cc50f8de9a7c24b9257c1. No commits by this worker. Final source receipt: `final-zero-net-source.sha256` (six runtime files, three specs). Earlier nine-control checkpoint preserved separately in `nine-control-checkpoint/`, `final-source.sha256`, and `RESULT-nine-control-checkpoint.md`; its package/demo receipts do not qualify this later source.

Mechanism: structural frames prepare constant-size before/after frontier evidence, complete it before paired responsibility installs, and retain it in the existing operation journal. Complete compensation requires contiguous captured intervals, a known expected disposition (including known empty), exact indexed net structural coverage, no competing order delta, and current endpoint identity. Preparation is followed by an immediate preinstall recheck. Complete point/interval-only installation and complete declarative installation restore eligible lineage before callbacks and terminal consequences. No synthetic row effects or history entries are introduced.

The preserved zero-net falsifier exposed an admission omission in the first candidate: an empty net effect list bypassed installed interval evidence. The current revision admits interval-only units through the same installation/terminal pipeline. Mixed zero-net/nonempty owners participate in one prepared unit; eligible point-undefined cases use existing declarative preparation instead of silently dropping continuity. No row collection is read for a frontier-only owner.

Final focused evidence:
- `nine-controls-final.log`: 9 ordinary passes. Two removals, remove/add, failed target installation and useful retry, later independent field truth, topology ABA, replacement lifetime isolation, coherent callback reentry, preparation reentry, callback throw after installed compensation.
- `zero-net-nx-final.log`: 7 ordinary passes. Useful rejection/undo/redo with held temporary reference detached; no synthetic row/order notifications; zero-net confirmation does not recover rejected lineage; no-write transaction; independent ABA; frontier preinstall fault/retry; mixed zero-net/nonempty collection failure/retry; zero-net plus scalar compensation.
- `final-spec-types-after-lint.log`: strict three-spec compilation passes.
- `final-lint-after-fix.log`: changed-file lint passes, zero warnings/errors.
- Diff whitespace check passes.
- Original assertions retained in active replay (only public barrel alias changed to equivalent relative barrel for lint); `original-assertions-final.log` preserves its newly reached cursor mismatch. Byte-for-byte first fixture remains in `/private/tmp/st-restoration-interval-20261018/compound-compensation-retry-readiness.spec.ts`.

Original mismatch: undo restores exact seed rows and held references, then getCurrentIndex() is unchanged rather than index-1. Independent review identified preexisting causal undo versus snapshot navigation semantics (jump-undo-equivalence.spec.ts). Approval review rejected changing the original assertion; it remains unchanged. The 16 separate controls actually execute useful undo and redo without asserting an invented public return value or cursor movement.

First evidence preserved: baseline ST1034, first candidate cursor failure, zero-net failure on both baseline and first candidate, test-author mistakes (void return expectation and invented restoration position), all prototype patches and source receipts. Independent ordinary-drift baseline reproduces exact restored order z,a,d,w,c, preserving survivor order z,w,c.

Limits: this is not complete v16 readiness. R1/R2 explicit-order/structural endpoint composition remains open. Owners with explicit order deltas keep existing handling. Frames containing restore-subject are excluded because paired prepared responsibility lacks that full effect. No broad suite, release qualification or performance claim. Settlement added work is proportional to captured operation records and indexed touched effects, not a constant-time rollback claim.

Approval accounting: unreviewed broad script rejected before execution; reviewed exact patch normally applied afterward. Original assertion edit rejected before execution and not bypassed. Parent owns independent final review and broader disposition.
