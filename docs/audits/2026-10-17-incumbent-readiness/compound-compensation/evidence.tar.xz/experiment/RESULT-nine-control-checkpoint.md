# Bounded compound compensation candidate

Base: fd3338719b5d694a234cc50f8de9a7c24b9257c1, retaining the separate Link publication repair. No commits by this worker. Runtime + tests receipt: final-source.sha256.

Mechanism: each ordinary structural frame prepares one before/after frontier record, finalizes its endpoint before paired transaction responsibility installation, and retains it in the existing operation journal. Compensation folds contiguous per-owner intervals. Eligibility requires exact net structural coverage (indexed by effect key/kind/lifetime/key or rekey mapping), no explicit order delta for that owner, and current frontier identical to the captured endpoint. Both prepared target and point installation recheck after preparation and before any installation. The earlier token is installed with the complete compensation, before publication. Independent topology gaps/ABA invalidate eligibility; field-only work does not.

Per-frame storage is constant-size; no entity enumeration was added. Settlement traverses the transaction operation journal and groups expected/actual touched effects once. This is not a constant-time rollback claim. It does not compose R1/R2's explicit-order arrays with all structural turn endpoints.

Results:
- Original compound replay on baseline: 1 ordinary pass, 1 ST1034 frontier failure (baseline-nx.log).
- Candidate with exact original test: useful undo restores all seed values and held lifetimes, then reaches previously hidden getCurrentIndex()==index-1 assertion failure (candidate-first-nx.log). Original remains unchanged. Parent independently identified the established causal-undo versus snapshot-cursor distinction; approval reviewer rejected changing original assertion, so no such edit occurred.
- Separate final controls: 9 ordinary passes (controls-final-after-fallback.log): two removals; remove/add; preinstall failure and useful retry; later independent field truth; topology ABA; same-key replacement and held lifetime; callback reorder; preparation reentry; callback failure after installed compensation. Useful redo is actually executed.
- Focused strict typecheck for both specs passes (spec-types.json / spec-types.log).
- Diff whitespace check passes.

Preserved new-test mistakes: boolean expectation on public void undo/redo (controls-first.spec.ts/log), and invented placement z,w,c,a,d after moving predecessor z (controls-expanded-first.spec.ts/log). Independent unmodified runtime gives z,a,d,w,c after ordinary z-prepend and rollback (independent-placement-baseline.log), preserving survivor order z,w,c under current placement policy. Expanded candidate reentry control uses this exact order; first failure remains.

Limits: R1/R2 six desired assertions remain unchanged, not fixed by this patch. Explicit-order owners retain their existing order-delta path. Frames containing restore-subject are excluded because prepared transaction responsibility does not supply that effect. Generic point-undefined fallback retains existing behavior without claiming frontier continuity; declarative plain-member fallback now receives the verified frontier plan. No supported public counterexample requiring the generic fallback was established in this bounded pass, but its completeness is not proved. Zero-net structural transactions are not handled by the eligibility rule (requires a nonempty net structural disposition). No release qualification or performance claim.

Approval accounting: initial broad unreviewed script rejected before execution; exact /tmp proposal then independently reviewed, seam checked and normally approved/applied. Later active original assertion edit rejected before execution; not bypassed.
