# Bounded independent premises — restoration continuity and Link order

Review checkout: /Users/jonathanborgia/.codex/worktrees/v16-incumbent-readiness/signaltree.
Readiness evidence names runtime 16f85b6d2b46ac1404ef6b089a1e6a459c28cdc3; inspected checkout HEAD 117f0b5416fd06f59d7e6a754b0b9a9e60ca56a5. No runtime edits by reviewer.

## Exact premises

- docs/research/transaction-semantics-2/LAWS.md:181–189: “L13 — settlement publishes only coherent truth.” “Accept, reject, realization and failed settlement must not expose transient states that violate the semantic unit being settled.” The carrier observes published snapshots, not arbitrary reads inside ordinary grouped writes.
- packages/kernel/src/lib/write-participation.ts: compensation is participation realized, with origin transaction-rollback, and is not external truth. Last relevant file-history commit inspected: 8e87fd1d, “fix: preserve transaction provenance across rollback”.
- packages/kernel/src/enhancers/restoration/restoration.ts, compensationTransactionId commentary: “stamping `transactionOwner` on a compensation makes `activeTransactionContext()` report an open scope, reopening the callback scope a rollback must leave closed.”
- packages/kernel/README.md:471: “A refusal is atomic: it changes no state, retires nothing, and leaves the” pending authority available (see following lines).

## Raw evidence inspected

Read docs/audits/2026-10-17-incumbent-readiness/runtime-boundaries/README.md, LINK-TRACE.md and compound-compensation-retry-readiness.spec.ts.
Read archive members compensation-multi-v2.log and compensation-rule-v2-first.log from restoration-evidence.tar.xz; read link-order-trace.json from link-evidence.tar.xz.
Two-removal compensation uses installPreparedTarget; mixed remove/add uses tombstoneSubject plus restoreSubjectAtResolvedPlacement. Physical order and held identities return, while original history retry fails frontier validation. Topology ABA and new lifetime at the same key cannot justify restoring prior authority. Callback-authored order survives compensation.
Link trace shows forward order capture is consumed while pending; rollback installs reverse order and publishes row changes, but no reverse order capture reaches eligible projection. Extra flushing cannot invent this missing fact.

## Discriminating constraints

Restored lineage requires complete compensation-unit evidence, exact entry frontier, and no intervening surviving topology authority. Visible key/order equality is insufficient. Preserve ST1034 drift and pending-overlap checks, held lifetimes, retry, opposite-terminal refusal and later-field truth.
Link must publish SubjectId order through the existing channel, with inspection suppression, realized compensation provenance, and ordering before newer authored reentry and durable delivery. Do not reseed eligibility unconditionally from physical state.

## Interval proposal: pending inspection

A contiguous same-transaction before/after frontier interval can prove absence of intervening structural mutations. Endpoints alone do not prove the target compensates all structural effects in that interval. Inspect how complete coverage is established independently of transaction id or endpoint equality. Falsifiers: partial target of two removals; mixed remove/add with a surviving effect; same-key replacement lifetime; external or callback reorder between captured frames or after physical compensation; multi-collection settlement with one failing validation; repeated successful and failed retries.
No verdict on proposed implementation before code inspection.

## Proposal v3 source review

Reviewed /private/tmp/st-compound-review/proposal.patch after exact net structural eligibility was added. No concrete blocker to a bounded experimental test phase. Coverage checks compare expectedDispositions and compensation by structural count, effectKey, kind, subject and typed key mapping; restore-subject frames do not receive an interval certificate. Frontier identity is rechecked after preparation, immediately before either declarative or point installation.

This resolves the specific source-level eligibility concerns sufficiently to proceed to falsifiers; it is not production acceptance. Required discriminators remain original desired retry, mixed remove/add, structural supersession/subset, ABA/replaced lifetime, preparation reentry, later callback order, multi-target failure and useful retry. No runtime test of v3 performed by this reviewer at this checkpoint.
