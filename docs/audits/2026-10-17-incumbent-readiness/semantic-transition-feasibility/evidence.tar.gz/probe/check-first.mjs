import {readFileSync,writeFileSync} from 'node:fs';
const root='/private/tmp/semantic-transition-feasibility';const traces=JSON.parse(readFileSync(root+'/traces.json'));
const results=[];const check=(name,actual,expected)=>results.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
// Pure normalization over the observed prepared payload; it installs no state,
// emits no chronology and cannot grant publication/settlement authority.
const normalize=t=>t.trace.filter(e=>e.phase==='write'&&e.kind==='prepare').flatMap(e=>e.changes.flatMap(c=>c.fields.map(f=>({subject:c.subject,...f}))));
for(const [name,keys]of [['point',['n']],['point-adopt',['n']],['replace-adopt',['n']],['setAll-adopt',['n','m','n','m']],['reentry',['n','n']]]){
 const t=traces.find(t=>t.scenario===name);check(name+' prepared semantic field coverage',normalize(t).map(f=>f.key),keys);check(name+' rollback executes',t.rollbackError??null,null);
}
const set=traces.find(t=>t.scenario==='setAll-adopt');check('setAll chronology still fails (no repair)',String(set.inspectionError).includes('no mutation chronology'),true);
check('setAll existing notification omits adopted n',set.trace.filter(e=>e.phase==='write'&&e.kind==='enqueue').flatMap(e=>e.fields.map(f=>f.key)),['m','m']);
const order=traces.find(t=>t.scenario==='order');check('pure order has no value facts',normalize(order),[]);check('order must carry explicit topology evidence',order.trace.filter(e=>e.phase==='write'&&e.kind==='order').map(e=>[e.before,e.after]),[[[1,2],[2,1]]]);
const reentry=traces.find(t=>t.scenario==='reentry');check('reentry preserves separate authored operations',reentry.trace.filter(e=>e.phase==='write'&&e.kind==='prepare').map(e=>e.changes.map(c=>c.subject)),[[1],[2]]);
check('rollback distinct participation not new authored prepare',traces.flatMap(t=>t.trace.filter(e=>e.phase==='rollback'&&e.kind==='prepare')),[]);
writeFileSync(root+'/coverage-checks.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));if(results.some(r=>!r.pass))process.exitCode=1;
