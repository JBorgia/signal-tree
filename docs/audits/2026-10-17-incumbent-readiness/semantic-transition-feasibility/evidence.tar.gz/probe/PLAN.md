# Feasibility, not repair

Frozen source7a84ae39 and rejected entity overlayba21c351. No runtime patch.
Read-only trace instrumentation wraps existing responsibility preparation and
subscribes existing enqueue evidence/order capture. Plain fixtures only: snapshot
cloning does not execute application getters. Original prepare is called unchanged.

Cases: ordinary point, inspected point adoption, inspected replacement, inspected
setAll, explicit ordering, rollback, synchronous callback reentry. Compare semantic
before/after fields captured before install with notifier chronology and resulting
inspect. Record event order and physical/native publication independently. Pure
normalization derives candidate authored field facts from existing prepared captures;
it is a feasibility input-coverage test, NOT a functional repair or passing native
qualification. Ordering requires its explicit order evidence, not row diff guesses.

Stop before runtime implementation if existing prepared outputs omit necessary
facts or complete coverage requires changing multiple writer families and notifier
consumer semantics rather than a confined result handoff. Do not add another
notification protocol or historical-value authority. Preserve first failure.
