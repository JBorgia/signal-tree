import {signalTree,transactions,entityMap,link} from './packages/kernel/src/index';
import {withWriteContext} from './packages/kernel/src/lib/write-context';
import {getMutationCaptureRuntime} from './packages/kernel/src/lib/internals/mutation-capture-runtime';
import {getPositionRegistry} from './packages/kernel/src/lib/internals/position-registry';
import {getPathNotifier} from './packages/kernel/src/lib/path-notifier';
const tick=async()=>{for(let i=0;i<80;i++)await Promise.resolve();};
function fields(before:any,after:any){return [...new Set([...Object.keys(before??{}),...Object.keys(after??{})])].filter(k=>Object.hasOwn(before??{},k)!==Object.hasOwn(after??{},k)||!Object.is(before?.[k],after?.[k])).map(k=>({key:k,beforePresent:Object.hasOwn(before??{},k),afterPresent:Object.hasOwn(after??{},k),before:before?.[k],after:after?.[k]}));}
export async function run(){const output:any[]=[];
for(const scenario of ['point','point-adopt','replace-adopt','setAll-adopt','order','reentry']){
 const t=signalTree({rows:entityMap<{id:string;n:number;m?:number},string>({selectId:r=>r.id})},{enhancers:[transactions()]});const rows=t.$.rows;rows.setAll([{id:'a',n:7},{id:'b',n:8}]);await tick();const a=rows.byIdOrFail('a'),b=rows.byIdOrFail('b');
 if(scenario.includes('adopt')){withWriteContext({participation:'inspection'},()=>{a.n(99);b.n(88);});await tick();}
 const trace:any[]=[];let phase='write';let sequence=0;const clone=(x:any)=>structuredClone(x);const record=(kind:string,data:any)=>trace.push({seq:++sequence,phase,kind,...clone(data)});
 const runtime=getMutationCaptureRuntime(t)!;const original=runtime.prepareEntityResponsibility;runtime.prepareEntityResponsibility=c=>{record('prepare',{changes:c.changes.map(x=>({subject:x.subject,structural:x.structural,path:x.path,before:x.before,after:x.after,fields:fields(x.before,x.after)}))});return original?.(c);};
 const owner=getPositionRegistry(t)!.id;
 const off=getPathNotifier().observeEnqueue(owner,e=>record('enqueue',{path:e.path,subjects:e.subjectIds,participation:e.meta?.participation,origin:e.meta?.origin,fields:fields(e.oldValue,e.newValue),before:e.oldValue,after:e.newValue}));
 const offOrder=runtime.subscribeCollectionOrder?.(o=>record('order',{before:o.beforeSubjects,after:o.afterSubjects}));
 const c=link(rows,{set:v=>record('send',{value:v})});let offRow=()=>{};if(scenario==='reentry')offRow=a.n.subscribe(()=>{if(a.n()===9)b.n(10);});
 let p:any;let inspection:unknown,inspectionError:unknown,rollbackError:unknown;
 try{p=t.transact(()=>{if(scenario==='point')a.n(9);if(scenario==='point-adopt')a.n(99);if(scenario==='replace-adopt')rows.replaceOne('a',{id:'a',n:99});if(scenario==='setAll-adopt')rows.setAll([{id:'a',n:99,m:1},{id:'b',n:88,m:2}]);if(scenario==='order')rows.reorder(['b','a']);if(scenario==='reentry')a.n(9);});await tick();try{inspection=p.inspect();}catch(e){inspectionError=String(e);}phase='rollback';try{p.rollback();}catch(e){rollbackError=String(e);}await tick();output.push({scenario,trace,inspection,inspectionError,rollbackError,final:rows.all()});}finally{offRow();off();offOrder?.();runtime.prepareEntityResponsibility=original;c.dispose();t.destroy();await tick();}
}return output;}
