// Private scalar research. Window evidence is not general causality.
export const stamp = Symbol('research revision');
type Outcome='confirmed'|'rolled-back'|'abandoned';
type Source={read():{pending:readonly {transactionId:number}[]}};
type Blocker=Readonly<{owner:number;id:number}>;
type Fact={readonly revision:number;readonly clean:boolean;readonly blockers:readonly Blocker[];readonly unknown:boolean};
type Receipt=Readonly<{fact:Fact;payload:unknown}>;
type Meta=Record<PropertyKey,unknown>;
const sources=new Map<number,{source:Source;token:object}>();
const outcomes=new Map<number,Map<number,Outcome>>();
const listeners=new Map<number,Set<()=>void>>();
const queued=new Set<number>();
const latest=new Map<string,Fact>();
const records=new Map<Fact,Receipt>();
const completed=new Map<string,Receipt>();
let visitedSources=0,visitedOwners=0;
let serial=0;let ingress:{owner:number;position:number;consumed:boolean}|undefined;
export const receipts:unknown[]=[];export let enabled=true;
export function mode(v:boolean):void{enabled=v;}
export function register(owner:number,source:Source,token:object):void{sources.set(owner,{source,token});}
export function transition(owner:number|undefined,fact:{kind:string;transactionId:number}):void{
 if(owner===undefined)return;
 receipts.push({event:'lifecycle',owner,...fact});
 if(!['confirmed','rolled-back','abandoned'].includes(fact.kind))return;
 let map=outcomes.get(owner);if(!map)outcomes.set(owner,map=new Map());
 const old=map.get(fact.transactionId);if(old&&old!==fact.kind)throw Error('terminal outcome reversed');
 map.set(fact.transactionId,fact.kind as Outcome);
 if(!queued.has(owner)){queued.add(owner);queueMicrotask(()=>{queued.delete(owner);for(const set of [...listeners.values()])for(const cb of [...set])cb();});}
}
export function onEligibility(owner:number,cb:()=>void):()=>void{let set=listeners.get(owner);if(!set)listeners.set(owner,set=new Set());set.add(cb);return()=>{set.delete(cb);if(!set.size)listeners.delete(owner);};}
export function acquire(owner:number,position:number,work:()=>void):void{const prev=ingress;ingress={owner,position,consumed:false};try{work();}finally{ingress=prev;}}
export function annotate(meta:Meta|undefined,owner:number|undefined,positions:number[]|undefined,authored:boolean,payload:unknown):Meta{
 const key=owner!==undefined&&positions?.[0]!==undefined?`${owner}:${positions[0]}`:undefined;
 // Delete first so a supported capture failure cannot leave an older clean ticket.
 if(key)latest.delete(key);
 const clean=!!ingress&&!ingress.consumed&&owner===ingress.owner&&positions?.[0]===ingress.position;
 if(clean&&ingress)ingress.consumed=true;
 const entry=owner===undefined?undefined:sources.get(owner);
 const captured:Blocker[]=[];
 for(const [tree,{source}] of sources){visitedSources++;for(const p of source.read().pending){visitedOwners++;captured.push(Object.freeze({owner:tree,id:p.transactionId}));}}
 const blockers=Object.freeze(captured);
 const attributed=meta?.transactionId;
 const attributionValid=attributed===undefined || (typeof attributed==='number'&&!!entry&&meta?.transactionOwner===entry.token&&blockers.some(b=>b.owner===owner&&b.id===attributed));
 const unknown=!clean&&(!authored||meta?.origin!==undefined||!entry||!attributionValid);
 const fact:Fact=Object.freeze({revision:++serial,clean,blockers,unknown});
 attach(fact,owner,positions,meta);if(key)latest.set(key,fact);records.set(fact,Object.freeze({fact,payload}));receipts.push({event:'revision',owner,position:positions?.[0],...fact,origin:meta?.origin,participation:meta?.participation,attributed});
 return {...meta,[stamp]:fact};
}
export function complete(meta:unknown,owner:number|undefined,positions:number[]|undefined):void{const fact=evidence(meta);const receipt=fact&&records.get(fact);if(owner!==undefined&&positions?.[0]!==undefined&&receipt)completed.set(`${owner}:${positions[0]}`,receipt);}
export function refresh(owner:number,position:number):Receipt|undefined{const r=completed.get(`${owner}:${position}`);return r&&latest.get(`${owner}:${position}`)===r.fact?r:undefined;}
export function evidence(meta:unknown):Fact|undefined{return(meta as Meta|undefined)?.[stamp] as Fact|undefined;}
export function allowed(fact:Fact|undefined,owner:number,position:number,channel:object):boolean{return !enabled||!stack.length&&!!fact&&latest.get(`${owner}:${position}`)===fact&&(declarationAllowed(fact,channel)||fact.clean||!permissions.get(fact)?.has(channel)&&!fact.unknown&&fact.blockers.every(b=>outcomes.get(b.owner)?.get(b.id)==='confirmed'));}
type Request={claimant:unknown;key:object;run:()=>void};
export function admit(original:(r:Request)=>void,fact:Fact|undefined,owner:number,position:number,channel:object,r:Request):boolean{if(!enabled){original(r);return true;}if(allowed(fact,owner,position,channel)){r.run();return true;}return false;}
export function dispose(_a:object,_b:object):void{}
export function heldCount():number{return 0;}
export function diagnostics(){return{sources:sources.size,outcomeTrees:outcomes.size,latest:latest.size,listeners:listeners.size,records:records.size,completed:completed.size,visitedSources,visitedOwners};}

// Declaration ownership is publication-only; authentic transaction objects are keys.
type Declaration = {kind:'independent'|'dependent'|'unknown'; owners?:readonly object[]};
type Frame={channel:object;owner:number;position:number;blockers:Blocker[];unknown:boolean;invalid:boolean;facts:Fact[];receipt:{read():Readonly<Record<string,unknown>>};last?:Fact};
const authentic=new WeakMap<object,Blocker>();
const permissions=new WeakMap<Fact,Map<object,Frame>>();
const stack:Frame[]=[];
export class SignalTreePublicationError extends Error {
 readonly code='SIGNALTREE_PUBLICATION_DECLARATION_INVALID';
 constructor(readonly stage:'before-callback'|'after-callback',readonly reason:string,options?:ErrorOptions){super(`Declaration invalid: ${reason}; writes may remain`,options);}
}
export function enroll<T extends object>(handle:T,owner:number|undefined,id:number):T{if(owner!==undefined)authentic.set(handle,Object.freeze({owner,id}));return handle;}
function wake(){queueMicrotask(()=>{for(const set of [...listeners.values()])for(const cb of [...set])cb();});}
function declarationAllowed(fact:Fact,channel:object):boolean{
 const f=permissions.get(fact)?.get(channel);
 return !!f&&!stack.length&&!f.invalid&&!f.unknown&&f.blockers.every(b=>outcomes.get(b.owner)?.get(b.id)==='confirmed');
}
function attach(fact:Fact,owner:number|undefined,positions:number[]|undefined,meta:Meta|undefined):void{
 const all=stack.flatMap(f=>f.blockers);const unknown=stack.some(f=>f.unknown);
 for(const f of stack){
  if(f.owner!==owner||f.position!==positions?.[0])continue;
  f.last=fact;f.facts.push(fact);
  // Known transaction-authored attribution cannot be erased by a declaration.
  if(typeof meta?.transactionId==='number'&&!all.some(b=>b.owner===owner&&b.id===meta.transactionId))for(const frame of stack)frame.invalid=true;
  f.blockers=[...new Map([...f.blockers,...all].map(b=>[`${b.owner}:${b.id}`,b])).values()];
  f.unknown ||= unknown;
  let map=permissions.get(fact);if(!map)permissions.set(fact,map=new Map());map.set(f.channel,f);
 }
}
export function declare(channel:object,owner:number,position:number,input:unknown,work:()=>unknown,isDisposed:()=>boolean){
 let stage:'before-callback'|'after-callback'='before-callback';
 let callbackThrown=false;let callbackError:unknown;
 const frame:Frame={channel,owner,position,blockers:[],unknown:true,invalid:false,facts:[],receipt:{read:()=>Object.freeze(status())}};
 function status():Record<string,unknown>{
  if(stack.length)return {state:'validating'};
  if(isDisposed())return {state:'disposed'};
  if(!frame.last)return {state:'no-write'};
  if(latest.get(`${owner}:${position}`)!==frame.last)return {state:'superseded'};
  if(frame.invalid||frame.unknown)return {state:'conservative',reason:frame.invalid?'invalid-declaration':'unknown'};
  if(frame.blockers.some(b=>{const s=outcomes.get(b.owner)?.get(b.id);return s==='rolled-back'||s==='abandoned';}))return {state:'conservative',reason:'rejected-dependency'};
  return declarationAllowed(frame.last,channel)?{state:'eligible',basis:'declared'}:{state:'held',reason:'pending-dependency'};
 }
 stack.push(frame);
 try{
  if(isDisposed())throw new SignalTreePublicationError(stage,'disposed');
  if(!input||typeof input!=='object'||typeof work!=='function')throw new SignalTreePublicationError(stage,'malformed');
  const d=input as Declaration;const kind=d.kind;
  if(!['independent','dependent','unknown'].includes(kind))throw new SignalTreePublicationError(stage,'malformed');
  const blockers:Blocker[]=[];
  if(kind==='dependent'){
   const owners=d.owners;if(!Array.isArray(owners))throw new SignalTreePublicationError(stage,'malformed');
   for(const handle of owners){const b=handle&&typeof handle==='object'?authentic.get(handle):undefined;if(!b)throw new SignalTreePublicationError(stage,'unavailable-owner');const terminal=outcomes.get(b.owner)?.get(b.id);if(terminal==='rolled-back'||terminal==='abandoned')throw new SignalTreePublicationError(stage,'unavailable-owner');blockers.push(b);}
  }
  frame.blockers=blockers;frame.unknown=kind==='unknown';
  stage='after-callback';let result:unknown;
  try{result=work();}catch(e){callbackThrown=true;callbackError=e;}
  if(result!==null&&(typeof result==='object'||typeof result==='function')){if(typeof(result as {then?:unknown}).then==='function')throw new SignalTreePublicationError(stage,'async-callback');}
  if(frame.invalid)throw new SignalTreePublicationError(stage,'contradiction');
  if(callbackThrown)throw callbackError;
  return frame.receipt;
 }catch(error){for(const f of stack)f.invalid=true;if(callbackThrown)throw callbackError;if(error instanceof SignalTreePublicationError)throw error;throw new SignalTreePublicationError(stage,'validation-threw',{cause:error});}
 finally{stack.pop();wake();}
}
