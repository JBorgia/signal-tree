# Approved scalar native experiment

Owner approved the surface at247cfec70c87c591e69e87dc3ee514840dad3f61 for a
bounded native experiment, not production activation or release acceptance.
Runtime baseline remains87f6831fa60cafe87508f0ace84b7638698ca3b0.
Production checkout dirty AGENTS.md and measurement-contract.md preserved.
Private source-loader transformations only; exact original/loaded hashes required.

Native falsifiers, expected before root replay:
- Independent literal declaration sends while actual transaction remains pending.
- Declared pending dependency holds; confirmation releases useful work.
- Original/recovery/noop authentic handles map exact transaction identity; fakes fail.
- Unknown/observed contradiction doesn't enable early publication; known owner cannot
  be erased; callback return/input getters remain inside validation horizon.
- No-write scope cannot bless earlier unproven revision.
- Declaration on one connection doesn't authorize another connection at same source.
- Repeated writes/ABA and nested two-connection scope don't leak intermediate state.
- Rejection reevaluates coherent noninspection projection, not old captured ticket;
  fresh post-rejection ordinary write remains new truth; foreign pending still holds.
- Async continuation has no ambient certificate; disposed connection no send.
- Existing queue/inflight/observer reentry controls retain exact evidence/oracles;
  old permanent-confirmation-hold assertions remain historical contract mismatches.
- Hidden saved-value omission explicitly leaks or holds, never safety-pass count.

Authentic identity is a private handle-to-owner map, never calls inspect/confirm/
rollback to authenticate; no second settlement engine. No native computed freshness
promise. No entities/order/full frameworks/cost qualification in this slice.
One substantive mechanism failure freezes candidate for interpretation before any
broader work. Independent review claims must be checked against raw evidence.
