
      import { signalTree, entityMap } from "/private/tmp/st-new-key-cost-20261018/paired/dist/packages/kernel/dist/index.js";
      const t = signalTree({ count: 0, users: entityMap() });
      t.$.users.addOne({ id: 1, name: 'a' }); t.$.users.updateOne(1, { name: 'b' });
      globalThis.__sink = t.$.users.all();
    