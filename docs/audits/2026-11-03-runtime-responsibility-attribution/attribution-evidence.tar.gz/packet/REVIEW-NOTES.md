# Independent review record

Reviewer: existing gate_review agent. Source findings were supplied separately
from execution; main retained all authority and production writes.

Counter framing: reconcile original interval, preserve nested charges; zero
visits is not zero calls or zero CPU. Run planted7-charge control separately
because the original failing assertion prevents its later control from running.
Observer off/on equality and source/site ledger are required. Instrumented
timings cannot support runtime-cost claims.

Late-consumer premise: existing suites covered close cases, but no exact witness
for an ordinary write before the first Link during a foreign pending owner with
both confirmation and rollback separately. The public witness was added;
skipping only the earlier native preparation caused premature delivery in both.

Singleton reuse premise: the paired physical image is already detached before
ordinary processing. Exactly one admitted edit has one per-edit reader; field
overlays modify the detached image rather than installed maps/shared Views.
Missing pairs and multiple ordinary edits retain copies. No supported-path need
for the second copy was demonstrated. This is a narrow reuse premise, not timing,
heap, bound compliance or production-adoption authority.

Reviewer independently authored the six-cell reader fixture. Main executed it:
all6 pass. It checks paired singleton, missing pair and repeated edits with reuse
off/on; saved ordinary and physical readers remain stable before/after install,
a refused preparation and a later installed write. The reviewer did not execute
it and made no execution claim.

Held-source interpretation: retaining an internal source after tree destruction
keeps reachable state observable;2000 row maps is not a weak tree collection
failure or demonstrated leak. A30s tracing timeout accommodates tracing overhead
and grants no runtime acceptance.
