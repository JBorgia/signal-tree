import json,re,pathlib,collections
p=pathlib.Path(__file__).resolve().parent
raw=json.loads((p/'CHARGES.json').read_text());rows=next(r for r in raw['results'] if r['observe'])['buckets']
groups=[('write key enumeration',[0,54]),('physical value transition',[1]),('value equality',[2,3]),('ordinary topology',list(range(4,9))),('source footprint and packet construction',list(range(9,14))),('admission normalization',list(range(14,23))),('native preparation excluding row copies',[i for i in range(23,42) if i not in [26,28,30,32]]+[42]),('row map copies',[26,28,30,32]),('source composition',list(range(43,47))),('source finalization dispatch',[47]),('publication input capture',[48]),('location delivery',list(range(49,52))),('completion dispatch',[52]),('source completion',[53])]
indices=[i for _,ii in groups for i in ii];assert sorted(indices)==list(range(55))
lookup={i:g for g,ii in groups for i in ii};ledger=[]
for i,b in enumerate(rows):
 lines=b['stack'].splitlines();sites=[s.strip().replace('/Users/jonathanborgia/code/signaltree/.worktrees/v16-runtime-attribution/','') for s in lines if '/src/lib/' in s and 'attribution.spec' not in s]
 ledger.append({'id':i,'count':b['count'],'perUpdate':b['count']/200,'operation':lines[0],'responsibility':lookup[i],'site':sites[0],'callPath':sites,'necessity':'Observed incumbent operation; required responsibility does not prove this traversal representation necessary','removableWitness':i==32})
summary={g:sum(rows[i]['count'] for i in ii) for g,ii in groups};assert sum(summary.values())==13000
for r in raw['results']:
 assert r['total']==13000
 if r['observe']:assert sum(b['count'] for b in r['buckets'])==13000
out={'baselineCommit':'3eabc01ddab71f16b8def0172c43c344bfd08731','runtimeCommit':'fe18a8e1c1f3da42727341d6c6fa30a407c1461e','workload':'original counter interval;200 distinct updateOne writes;2-field rows;size2000/20000','summary':summary,'count':13000,'countPerUpdate':65,'unclassified':0,'nestedCharges':'Preserved original counter: iterator yield and Array.from output may both charge. Not CPU instructions. Empty iterations contribute zero.','ledger':ledger}
(p/'LEDGER.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(summary,indent=2))
