from pathlib import Path
import subprocess,tarfile,hashlib,json,io,shutil
p=Path(__file__).resolve().parent/'reviewer';p.mkdir(exist_ok=True);repo=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate')
exclude={'docs/audits/2026-11-03-progress-and-workflow/completion/qualification-evidence.tar.gz','docs/audits/2026-11-03-progress-and-workflow/completion/source-restoration-overrides.tar.gz','docs/audits/2026-11-03-progress-and-workflow/improvement/qualification-evidence.tar.gz'}
sha=lambda b:hashlib.sha256(b).hexdigest()
for label,rev in [('candidate','3eabc01ddab71f16b8def0172c43c344bfd08731'),('before','c2127a34b2fdd162ea1bd7bb2000f4815a2d8461')]:
 out=p/(label+'-source.tar.gz');entries=[]
 tree=subprocess.check_output(['git','ls-tree','-r','-z',rev],cwd=repo).split(b'\0');oids={}
 for row in tree:
  if not row:continue
  info,path=row.split(b'\t',1);mode,kind,oid=info.decode().split();oids[path.decode()]={'mode':mode,'gitObject':oid,'kind':kind}
 child=subprocess.Popen(['git','archive','--format=tar',rev],cwd=repo,stdout=subprocess.PIPE)
 with tarfile.open(fileobj=child.stdout,mode='r|') as source,tarfile.open(out,'w:gz') as dest:
  for item in source:
   if not item.isfile():
    if item.isdir():dest.addfile(item)
    else:raise RuntimeError('Unexpected archive type '+item.name)
    continue
   raw=source.extractfile(item).read();omitted=item.name in exclude or item.name.endswith(('.tar.gz','.tar.xz','.tar','.tgz','.zip','.pdf','.docx'))
   entry={'path':item.name,'sha256':sha(raw),'bytes':len(raw),**oids[item.name],'provided':not omitted};entries.append(entry)
   if entry['provided']:dest.addfile(item,io.BytesIO(raw))
  metadata={'sourceCommit':rev,'rootTree':subprocess.check_output(['git','rev-parse',rev+'^{tree}'],cwd=repo,text=True).strip(),'entries':entries,'omissionReason':'Historical compressed archives and binary PDF/DOCX references omitted with hashes; current qualification archive supplied separately. All source/build/test instructions retained. Historical archive-input gates may require omitted payloads.'}
  for name,raw in [('SNAPSHOT-MANIFEST.json',(json.dumps(metadata,indent=2)+'\n').encode()),('ORIGINAL-COMMIT.raw',subprocess.check_output(['git','cat-file','commit',rev],cwd=repo))]:
   item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;dest.addfile(item,io.BytesIO(raw))
 assert child.wait()==0
 print(label,out.stat().st_size,sha(out.read_bytes()))
shutil.copy2(repo/'docs/audits/2026-11-03-progress-and-workflow/improvement/qualification-evidence.tar.gz',p/'qualification-evidence.tar.gz')
(p/'README.md').write_text('''# Self-contained local review inputs\n\nThe configured origin is https://github.com/JBorgia/signal-tree.git. These checkpoints are local and have not been pushed. No network availability is claimed for this bundle.\n\ncandidate-source.tar.gz contains source/build/test instructions at original commit3eabc01dd (runtime fe18a8e1c). before-source.tar.gz is the c2127a34 comparison source. Dependencies, .git history and historical compressed archives and binary PDF/DOCX references are omitted; the exact current qualification-evidence.tar.gz is supplied separately, including before/final built artifact bytes and raw receipts. Every omission is explicit in the snapshot manifest.\n\nExtract each source archive to its own directory. SNAPSHOT-MANIFEST.json binds every provided file by SHA256 and original Git blob ID. ORIGINAL-COMMIT.raw preserves the original commit object; it is not a newly invented snapshot commit. File modes are preserved. Historical gates requiring omitted payloads cannot be replayed from these snapshots alone. Node24.15.0 and pnpm10.17.0 are pinned by .nvmrc/package.json. Use pnpm install --frozen-lockfile in an isolated directory, then Nx for tests. A source snapshot supplies no complete historical Git/tag context; gates that require that context cannot be inferred passed from the snapshot.\n\nThe candidate remains HOLD. No publication, activation, merge or production acceptance is authorized. See the supplied qualification report for scopes, first failures, costs and limits.\n''')
(p/'FILES.json').write_text(json.dumps({f.name:{'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(p.iterdir()) if f.is_file() and f.name!='FILES.json'},indent=2)+'\n')
