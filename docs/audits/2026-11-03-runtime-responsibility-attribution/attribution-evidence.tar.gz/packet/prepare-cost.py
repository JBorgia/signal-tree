from pathlib import Path
import json,hashlib,shutil,datetime
p=Path(__file__).resolve().parent/'cost';p.mkdir(exist_ok=False)
old=Path('/private/tmp/st-v16-improvement/cost-final');before=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate');after=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-runtime-attribution');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
shutil.copytree(old/'harness',p/'harness')
for n in ['campaign.py','analyze.py']:shutil.copy2(old/n,p/n)
roots={'retained':before,'selected':after};sources={};artifacts={}
for arm,root in roots.items():
 manifest=p/(arm.upper()+'-MANIFEST.json')
 if arm=='selected':shutil.copy2(p.parent/'MANIFEST.json',manifest)
 else:
  import subprocess
  names=subprocess.check_output(['git','ls-tree','-r','--name-only','-z','HEAD'],cwd=root).decode().strip('\0').split('\0');manifest.write_text(json.dumps({n:sha(root/n) for n in names},sort_keys=True,indent=2)+'\n')
 sources[arm]={'root':str(root),'manifest':str(manifest),'manifestSha256':sha(manifest)}
 entries={str(f.relative_to(root)):{'sha256':sha(f),'executable':f.stat().st_mode&0o111} for f in sorted((root/'dist/packages').rglob('*')) if f.is_file()}
 amap=p/(arm.upper()+'-ARTIFACTS.json');amap.write_text(json.dumps(entries,indent=2)+'\n');artifacts[arm]={'root':str(root),'manifest':str(amap),'manifestSha256':sha(amap),'files':len(entries)}
prior=json.loads((old/'BINDINGS.json').read_text());receipts={'retained':prior['buildReceipts']['selected'],'selected':{'command':str(p.parent/'runs/uninstrumented-five-build-corrected/COMMAND.json'),'result':str(p.parent/'runs/uninstrumented-five-build-corrected/RESULT.json')}}
for record in receipts.values():
 assert json.loads(Path(record['result']).read_text())['exit']==0
 for field in ['command','result']:record[field+'Sha256']=sha(Path(record[field]))
assert json.loads((old/'SELECTED-ARTIFACTS.json').read_text())==json.loads((p/'RETAINED-ARTIFACTS.json').read_text()),'frozen artifacts drift'
binding={'sources':sources,'artifacts':artifacts,'dependencies':prior['dependencies'],'buildReceipts':receipts,'beforeCommit':'3eabc01ddab71f16b8def0172c43c344bfd08731','afterCommit':'uncommitted experiment patch over3eabc;manifest bound','armLabels':{'retained':'frozen fe18 v16 runtime','selected':'one singleton detached physical-image reuse; uninstrumented'},'intent':'Finite attribution experiment; no adoption or cost waiver; dimensions independent'}
(p/'BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n');schedule=json.loads((old/'SCHEDULE.json').read_text())
for row in schedule:row['argv'][2]=str(p/'harness'/Path(row['argv'][2]).name);row['argv'][3]=str(roots[row['arm']]/'dist/packages/kernel/dist');row['cwd']=str(p/'harness')
(p/'SCHEDULE.json').write_text(json.dumps(schedule,indent=2)+'\n');reg=json.loads((old/'PREREGISTRATION.json').read_text());reg.update({'registeredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Single physical-image reuse compared with frozen fe18 runtime; no instruments, no broad architecture search; all dimensions separate','bindingsSha256':sha(p/'BINDINGS.json'),'scheduleSha256':sha(p/'SCHEDULE.json'),'runnerSha256':sha(p/'campaign.py'),'review':{'sourceOnly':'gate_review: detached singleton image can be reused; missing-pair and multi-edit retain copies;6cell independent fixture executed separately'},'exclusiveSlot':'Main owns sole heavy slot; no calibrated exclusive-core or host-contention claim'})
reg['analysisRules']['decision']='No numerical bound change, cost acceptance or production adoption; all dimensions evaluated separately.'
(p/'PREREGISTRATION.json').write_text(json.dumps(reg,indent=2)+'\n');print(str(p))
