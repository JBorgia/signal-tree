from pathlib import Path
import json,hashlib,tarfile,io
p=Path(__file__).resolve().parent;c=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-runtime-attribution');o=c/'docs/audits/2026-11-03-runtime-responsibility-attribution';entries={}
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.json','.md','.py','.cjs']:entries['packet/'+f.name]=f
for folder in ['manifests','cost']:
 for f in (p/folder).rglob('*'):
  if f.is_file():entries['packet/'+str(f.relative_to(p))]=f
for f in (p/'runs').rglob('*'):
 if f.is_file() and 'tmp' not in f.relative_to(p/'runs').parts:entries['packet/'+str(f.relative_to(p))]=f
for f in (c/'tools/runtime-responsibility-attribution').iterdir():entries['experiment/'+f.name]=f
expected=json.loads((p/'cost/SELECTED-ARTIFACTS.json').read_text())
for n,v in expected.items():
 f=c/n;assert hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256'];entries['prototype/'+n]=f
for f in o.iterdir():
 if f.is_file() and f.name not in ['attribution-evidence.tar.gz','EVIDENCE.json','REVIEW-BUNDLE.json']:entries['audit/'+f.name]=f
manifest={n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in sorted(entries.items())};out=o/'attribution-evidence.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,f in sorted(entries.items()):t.add(f,arcname=n,recursive=False)
 raw=(json.dumps(manifest,indent=2)+'\n').encode();item=tarfile.TarInfo('EVIDENCE-MANIFEST.json');item.size=len(raw);item.mode=0o644;t.addfile(item,io.BytesIO(raw))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getmembers())==len(manifest)+1
 for n,v in manifest.items():raw=t.extractfile(n).read();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
receipt={'file':out.name,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(manifest)+1,'memberHashesVerified':True,'prototypeArtifacts':len(expected),'frozenRuntimeAdoption':False}
(o/'EVIDENCE.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
