import hashlib, itertools, json, pathlib, platform, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
node,candidate=sys.argv[1:]
arms={'V':str(root/'package/dist'),'C':candidate}
schedule=[]
for mode,sizes in [('cpu',[0,100,1000]),('heap',[0,100,1000])]:
    for n in sizes:
        schedule.extend((mode,n,arm) for arm in 'VVVCCVVC')
schedule.extend((mode,n,arm) for mode,n in [('profile',100),('snapshot',0),('snapshot',1000)] for arm in 'VC')
schedule.extend([('pending',1000,'C')]*3)
def hashes():
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
            [root/'kernel.tgz',root/'measure.mjs',root/'heap-quiescence.mjs',pathlib.Path(__file__)]
            +[p for d in arms.values() for p in sorted(pathlib.Path(d).rglob('*')) if p.is_file()]}
before=hashes()
packet=root/'runs'
packet.mkdir()
(packet/'plan.json').write_text(json.dumps(dict(node=node,arms=arms,platform=platform.platform(),
    schedule=schedule,hashes=before,
    interpretation='First two V samples are A/A controls; next three pairs alternate. CPU phase probes descriptive; profiles and snapshots separate from headline metrics. No retries.'),
    indent=2))
for i,(mode,n,arm) in enumerate(schedule):
    prefix=packet/f'{i:02}-{mode}-{n}-{arm}'
    with prefix.with_suffix('.log').open('wb') as log:
        print(i,mode,n,arm,flush=True)
        subprocess.run([node,'--expose-gc','--max-old-space-size=768',str(root/'measure.mjs'),
                        arms[arm],mode,str(n),str(prefix)],stdout=log,stderr=subprocess.STDOUT,
                       timeout=75,check=True)
assert hashes()==before
(packet/'complete.json').write_text(json.dumps({'count':len(schedule),'inputDrift':False}))
