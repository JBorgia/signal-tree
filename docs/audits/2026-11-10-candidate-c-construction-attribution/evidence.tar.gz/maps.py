import collections as c,json,sys
from pathlib import Path
p=Path(sys.argv[1])
d=json.loads(p.read_text()); meta=d['snapshot']['meta']; n=d['nodes']; e=d['edges']; s=d['strings']
nf=meta['node_fields']; ef=meta['edge_fields']; ns=len(nf); es=len(ef)
ni={k:nf.index(k) for k in ('type','name','self_size','edge_count')}
ei={k:ef.index(k) for k in ('type','name_or_index','to_node')}
nt=meta['node_types'][ni['type']]; et=meta['edge_types'][ei['type']]
def node(i): return nt[n[i+ni['type']]],s[n[i+ni['name']]],n[i+ni['self_size']]
offsets=[0]
for i in range(0,len(n),ns): offsets.append(offsets[-1]+es*n[i+ni['edge_count']])
assert offsets[-1]==len(e)
def edges(i):
 off,end=offsets[i//ns:i//ns+2]
 for j in range(off,end,es):
  ty=et[e[j+ei['type']]]; name=e[j+ei['name_or_index']]
  yield ty,s[name] if ty not in ('element','hidden') else name,e[j+ei['to_node']]
def shape(i):
 return tuple(sorted(name for ty,name,j in edges(i) if ty=='property' and name!='__proto__'))
def map_data(i):
 table=next((j for t,k,j in edges(i) if t=='internal' and k=='table'),None)
 if table is None: return None,[]
 return table,[j for t,k,j in edges(table) if t=='internal' and k.isdecimal()]
name_refs=c.defaultdict(set)
for i in range(0,len(n),ns):
 ty,name,sz=node(i)
 if name=='system / Context' or name in ('EntityValueStore','EntityOrdinaryTopology','StructuralStore','EntityPublicationSource'):
  for t,k,j in edges(i):
   if t in ('context','property') and node(j)[:2]==('object','Map'):
    name_refs[j].add(k)
groups=c.defaultdict(lambda:[0,0,0])
matches={}
outer={}
requirements=c.defaultdict(set)
publication={("fields",),("views",),("members",),("visible",),("placements",),("placementViews",),("mappings",),("mappingViews",)}
for i in range(0,len(n),ns):
 if node(i)[:2]!=('object','Map'): continue
 table,entries=map_data(i)
 if table is None: continue
 tag=tuple(sorted(name_refs[i]))
 if not tag: continue
 group=groups[tag]
 group[0]+=1; group[1]+=node(i)[2]+node(table)[2]; group[2]+=len(entries)
 if tag in publication:
  ids=outer.setdefault(tag,set())
  ids.update((i,table))
  if tag in (('members',),('visible',),('placementViews',),('mappingViews',)):
   ids.update(j for j in entries if node(j)[:2]==('object','Object'))
 if tag in (('fields',),('views',)):
  for j in entries:
   if node(j)[:2]==('object','Map'):
    t0,items=map_data(j)
    assert t0 is not None
    matches.setdefault(tag,set()).update([j,t0,*[k for k in items if node(k)[:2]==('object','Object')]])
for tag,g in sorted(groups.items(),key=lambda kv:-kv[1][1])[:36]: print(tag,g)
assert not set.union(*outer.values()).intersection(set.union(*matches.values())) if matches else True
for tag,ids in outer.items():
 print('publication top-level and direct wrapper',tag,len(ids),sum(node(i)[2] for i in ids))
 if tag not in (('fields',),('views',),('placements',),('mappings',)):
  requirements[tag].update(j for i in ids for t,k,j in edges(i) if t=='property' and k=='requirement')
for tag,ids in matches.items():
 requirements[tag].update(j for i in ids for t,k,j in edges(i) if t=='property' and k=='requirement')
 print(tag,len(ids),sum(node(i)[2] for i in ids),c.Counter((node(i)[:2],shape(i) if node(i)[:2]==('object','Object') else ()) for i in ids))
if len(matches)==2: print('shared child nodes',len(set.intersection(*matches.values())))

if requirements:
 print('distinct requirement nodes per channel',[(tag,len(ids)) for tag,ids in requirements.items()])
 print('distinct requirement nodes across channels',len(set.union(*requirements.values())))
 all_ids=list(outer.values())+list(matches.values())
 print('unique publication self-size',sum(node(i)[2] for i in set.union(*all_ids)))
 assert len(set.union(*all_ids))==sum(map(len,all_ids))
