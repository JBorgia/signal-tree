import collections as c, json, pathlib, statistics as st, sys
root=pathlib.Path(sys.argv[1])
def read(p): return json.loads(p.read_text())
for mode in ('cpu','heap'):
 for size in (0,100,1000):
  paths=sorted(root.glob(f'*-{mode}-{size}-*.json'))
  print(mode,size)
  for arm, selected in [('AA',paths[:2]),('V',[p for p in paths[2:] if p.stem.endswith('-V')]),('C',[p for p in paths[2:] if p.stem.endswith('-C')])]:
   a=list(map(read,selected))
   if mode=='heap':
    row={'live-minus-base':[d['live']['heapUsed']-d['baseline']['heapUsed'] for d in a]}
   else:
    row={k:[d['phases'][k]['cpu']/1000 for d in a] for k in a[0]['phases']}
    row['totalSync']=[sum(d['syncCpu'].values())/1000 for d in a]
   print(arm,{k:(round(st.median(v),3),list(map(lambda x:round(x,3),v))) for k,v in row.items()})
for p in sorted(root.glob('*.cpuprofile')):
 d=read(p)
 nodes={n['id']:n for n in d['nodes']}
 parent={kid:n['id'] for n in d['nodes'] for kid in n.get('children',[])}
 def label(k):
  f=nodes[k]['callFrame']
  return f["functionName"],f['url'].split('/dist/')[-1],f['lineNumber']+1
 selftime=c.Counter(); frames=c.Counter(); groups=c.Counter()
 for sid,dt in zip(d['samples'],d['timeDeltas'],strict=True):
  selftime[label(sid)]+=dt
  path=[]; current=sid
  while current is not None:
   path.append(label(current)); current=parent.get(current)
  frames.update({item:dt for item in path})
  groups.update({f:dt for f in ('setAll','createEntitySignal','signalTree','destroy','prepareOrdinaryTopology','prepareEntityPublication','commitAndProjectEntityMutationFrame','prepareEntityMutationFrame','deepClone','prepareRichEntityMutationFrame') if any(x[0]==f for x in path)})
 print(p.name,'inclusive ms',[(k,round(v/1000,2)) for k,v in groups.most_common()])
 print('self ms',[(k,round(v/1000,2)) for k,v in selftime.most_common(20)])
 print('inclusive frames',[(k,round(v/1000,2)) for k,v in frames.most_common(35)])
def snapshot(p):
 d=read(p); meta=d['snapshot']['meta']; n=d['nodes']; e=d['edges']; s=d['strings']
 nf=meta['node_fields']; ef=meta['edge_fields']; ns=len(nf); es=len(ef)
 ni={k:nf.index(k) for k in ('type','name','self_size','edge_count')}
 ei={k:ef.index(k) for k in ('type','name_or_index','to_node')}
 nt=meta['node_types'][ni['type']]; et=meta['edge_types'][ei['type']]
 def node(i): return nt[n[i+ni['type']]],s[n[i+ni['name']]],n[i+ni['self_size']]
 counts=c.Counter(); sizes=c.Counter(); shapes=c.Counter(); properties=c.Counter(); offs=0
 for i in range(0,len(n),ns):
  ty,name,sz=node(i)
  key=(ty,name) if ty in ('object','closure','array','hidden') else (ty,'*')
  counts[key]+=1; sizes[key]+=sz
  end=offs+es*n[i+ni['edge_count']]
  if ty=='object' and name=='Object':
   shape=[]
   for j in range(offs,end,es):
    if et[e[j+ei['type']]]=='property':
     prop=s[e[j+ei['name_or_index']]]
     if prop!='__proto__': shape.append(prop)
   if shape: shapes[tuple(sorted(shape))]+=sz
  if ty=='object' and name in ('EntityValueStore','EntityOrdinaryTopology','StructuralStore','EntityPublicationSource'):
   for j in range(offs,end,es):
    if et[e[j+ei['type']]]=='property':
     prop=s[e[j+ei['name_or_index']]]; dest=node(e[j+ei['to_node']])
     properties[(name,prop,dest[0],dest[1])]+=1
  offs=end
 assert offs==len(e)
 return counts,sizes,shapes,properties
sp={}
for p in sorted(root.glob('*.heapsnapshot')):
 sp[p.stem.split('-snapshot-')[1]]=snapshot(p)
a,b,c0,d=[sp[k] for k in ('1000-C','0-C','1000-V','0-V')]
for k in (0,1,2):
 delta=a[k].copy(); delta.subtract(b[k]); delta.subtract(c0[k]); delta.update(d[k])
 print(('node counts','self sizes','object shape self sizes')[k],delta.total())
 print(delta.most_common(30))
 print(delta.most_common()[-8:])
print('candidate store edges:',a[3])
