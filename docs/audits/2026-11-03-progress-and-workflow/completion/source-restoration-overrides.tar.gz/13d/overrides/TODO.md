# TODO

Work that is decided and not yet done. **This is not an RFC list.**

## September 23 audit remediation — ACTIVE / RELEASE HELD

All reproduced security, correctness, composition, lifecycle and tooling findings
are tracked in [the remediation ledger](docs/audits/2026-09-23-remediation.md).
The September 23 prototype freeze is historical: subsequent owner-authorized
v16 experiments continue in the isolated integration worktree. Their execution
does not grant publication or disclosure authority. Use the current controller
and exact release-line evidence rather than this dated status for release decisions.


## Atomic installation/capture decision — CLOSED WITH COUNTEREXAMPLE

The [reviewed bounded probe](docs/research/atomic-installation-capture-0/README.md)
from `19a5bd03` falsifies mixed scalar/entity robustness under persistent internal
entity-recorder failure: rollback and retry succeed while the entity write
survives and pending authority is zero. Scalar controls and the candidate's mixed
publication repair pass, but do not establish complete responsibility capture.
First failures, exact research patch, replay harness and independent controls are
preserved. No public-input trigger is established; no runtime integration or
contract change is made. Order/frontier and release work remain separate.

The [boundary follow-up](docs/research/atomic-capture-boundary-0/README.md)
compares prepared capture, paired field records, and incomplete-capture recovery.
The field prototype still loses entity additions and changes inspection paths;
recovery misorders a failed write followed by a captured write. Reviewed first
failures and portable controls are preserved. No candidate qualifies for runtime
integration; no broad release suite was restarted.

The [operation-record follow-up](docs/research/operation-record-boundary-0/README.md)
inventories the explicit installation paths and tests one revised candidate.
Prepared structural/field records and a shared scalar/entity journal survive the
prior capture and inspection falsifiers. The expanded observer check exposes an
existing baseline/candidate stale `all()` projection during settlement despite
complete physical restoration. This remains red; no complete contract proof,
runtime integration, broader suites or timing-policy change is claimed.

## V16 native publication verification — ACTIVE

The isolated [native error recovery repair](docs/research/native-publication-error-recovery-0.md)
now preserves adapter bookkeeping and attempts queued sibling epochs after a
failure. Its package tests pass; this is not systemic or release completion.

- Keep unowned native-graph recovery and publication-certificate meaning under
  investigation; remote application is not proof of local UI recovery.
- Resolve the recorded package/demo size failures before release. They also
  reproduce on the unchanged base; no ceiling is waived or raised here.
- Reconcile this repair with the ownership candidate together with its tests.
- Resolve the independently reproduced inline scalar-publication failure:
  partial compensation must not retire authority on a revision change alone.
- Finish the [entity carry](docs/research/v16-entity-carry-validation-0.md): the
  original 47 expected failures now pass. The expanded planner carry is under
  full verification; preserve the first 25 integration regressions and their
  distinct semantic/counting diagnoses. Complete the order/frontier carry next.

## Studio commercial separation

Studio development and its complete implementation/evaluation ledger now live
in a separate private workspace. The September 11 owner decision supersedes
historical free-Studio sections below. Public library work keeps only the
existing observation/realization contracts and four framework/kernel packages.

## V15 pre-GA source hygiene

- Remove stale internal comments in `signal-tree.ts` that still teach the
  deleted builder, `.with()`, `.state`, or historical overload architecture.
  This is documentation/source hygiene only; do not reopen the one-way public
  construction surface while cleaning it.

## DEEP-TYPING-DEPTH-0 — CLOSED

- [x] `/deep-typing` accepts a user-selected depth from 1 through 40, generates
      the nested runtime shape, and verifies the deepest read, write, snapshot,
      and reset before replacing the previous tree.
- [x] `tools/generate-deep-typing-proofs.mjs` emits explicit initializer-
      inference fixtures for every offered depth. Strict typecheck fails unless
      each deepest leaf is exactly `WritableLeaf<DeepTypingStatus>`, never
      `any`, and the generated file matches the generator.
- [x] The page explains recursive mapped-type widening, `any`/`unknown` loss,
      TypeScript instantiation limits, and why runtime interaction is separate
      from compiler evidence. Claims remain bounded to generated fixtures.

## V15 pre-publish repository audit

Triage the 1,225-file full-tree audit before any next RC or GA publish. Audit
claims are hypotheses until reproduced against tracked source and built
artifacts. Do not turn repository tidiness into a release blocker without a
concrete shipping, build, API, documentation, or automation failure.

### Release-contract checks

- [x] **Phantom packages — fixed (`424c6ff3`).** Removed dead aliases for
      authoring/events/ng-forms and aligned release, validation, tree-shaking,
      import-scanning, and bundle paths with shared/kernel/angular/react.
- [x] **Package scopes — normalized.** Public packages use `@signal-tree/*`.
      The former private `@signaltree/shared` package had only kernel production
      consumers, so its live utilities and tests moved into kernel internals and
      its package, build, declaration-rewrite, and workspace plumbing were
      deleted. No public package or dependency edge replaces it.
- [x] **`core` -> `kernel` residue — fixed and gated (`424c6ff3`, `2fbd51b2`,
      `d32a1131`).** Live release/build/docs paths now use the v15 project and
      package names. Historical evidence is explicitly classified rather than
      rewritten as current guidance.
- [x] **Final executable rerun (`109595e6`).** Package discovery, builds,
      manifests, declarations, exports, tarballs, strict consumer typechecks,
      tree-shaking, and all ordinary/release-only gates pass: 69/69, zero
      known-red. Independent Gate F review found no blocker.

### Repository hygiene to disposition

- [x] **Tracked root artifacts — dispositioned (`fd153e9f`).** Removed the
      backup workspace file and tracked Playwright snapshots; retained
      `migrations.json` as Nx migration state. Generated local directories stay
      untracked.
- [x] **Documentation authority — fixed (`092db3c9`, `92a20af4`, `2fbd51b2`,
      `d32a1131`).** Added the repository map, refreshed the docs index and
      current v15 guidance, replaced the stale scripts index, and validated
      links. ADSP already has an index; loose historical buckets and `specs/`
      are classified evidence, so relocation is deferred.
- [x] **Shared shims and test declarations — fixed (`fd153e9f`, `92a20af4`).**
      Removed obsolete shared root shims and excluded
      `reactive-test-realization.ts` from production declarations. Package
      hygiene has killing fixtures for both regressions.
- [x] **Package scaffolding — accepted by role.** Public realizations and the
      neutral kernel need not have byte-identical config/test layouts. No build,
      lint, typecheck, or package failure was reproduced from their differences.
- [x] **Demo Jest — intentional.** `apps/demo/project.json` explicitly owns an
      `@nx/jest:jest` target while packages use Vitest; the demo spec documents
      that boundary. Migration is non-gating absent a failing workflow.
- [x] **Orientation candidates — sufficient.** `docs/ADSP/README.md` exists;
      `docs/repository-map.md` classifies `api/`, historical specs, scripts, and
      tools. No concrete contributor-routing failure justifies more indexes or
      a historical spec-prefix taxonomy before GA.
- [x] **Workspace policy/instructions — fixed (`fd153e9f`, `92a20af4`).**
      `.npmrc` is intentionally tracked and contains no credential; the dead
      ignore rule was removed. `.cursorrules` is now a pointer to canonical
      `AGENTS.md` instead of a divergent instruction fork.

### Deferred structural cleanup

- Grouping the flat `tools/` and `scripts/` families, defining their boundary,
  reorganizing hundreds of kernel specs, consolidating documentation buckets,
  and normalizing package directory templates are post-GA refactors by default.
  They may move onto the release path only when a current command, package,
  generated artifact, or contributor workflow is concretely broken.
- Any accepted move must update all command registries, Nx targets, CI/release
  scripts, documentation links, numeric-claim generator annotations, and
  self-tests in the same change. Do not perform a bulk directory shuffle before
  publish merely to improve aesthetics.

## CONSTRUCTION-DENSITY-0 — POST-GA / NON-GATING

Investigate scalar-tree construction density without attributing it to the root
accessor migration. Current generator evidence measures approximately
1,233-1,240 retained bytes per scalar leaf and about 150 ms to construct 100k
leaves; raw Angular signals in the same decomposition retain about 523 bytes
each. Determine where the additional roughly 700 B/leaf belongs before proposing
an optimization. This is non-blocking for root retirement and React selector
work; preserve behavior, public types, and construction-bound ownership.
Construction time is a regression ceiling, not an optimization target. Reopen
retained scalar density only from a specific newly attributed allocation or
ownership hypothesis, not from the headline bytes-per-leaf gap alone.

## DEMO-EVALUATION-0 — IMPLEMENTED LOCALLY 2026-09-17

- [x] Distill README/homepage to the value, one live example, fit/evidence, and setup.
- [x] Reuse the shared live-preview/source shell across active feature examples;
      preserve state when hiding source, support keyboard source tabs and copy.
- [x] Keep advanced navigation and diagnostic detail optional; include Vue setup.
- [x] Withdraw the separately introduced Node comparison and static chart claims.
      They measured different work from the runnable browser benchmarks and were
      incorrectly promoted as public comparison evidence.
- [x] Render butterfly comparisons directly from the existing browser benchmark
      results; simplify homepage, navigation, and why-use-it copy. Published
      after 168 demo tests, source typecheck, lint, production build, real browser
      runs, mobile checks, and 82 production route checks. Benchmark engine and
      workload timing code remain unchanged.
- [x] Validate examples, types, production build, documentation links, and mobile
      layouts. Automated/browser checks establish behavior, not comprehension.
- [ ] Run comprehension sessions with developers unfamiliar with SignalTree.
      Study tasks and recording sheet are prepared; no participant findings are
      claimed. This requires actual participants before it can be closed.

## LINK-PRODUCTION-PATH-0 — FIXED LOCALLY 2026-09-17

- [x] Preserve canonical nested ownership paths when development diagnostics
      are disabled. The live Link example exposed a production-only failure:
      nested edits were ignored by a branch link or projected at the wrong level
      by a root link, despite `settled()` returning.

Ordinary branch construction passed a development-only path into a constructor
that now also assigns semantic ownership addresses. Production erased parent
segments. All three ordinary-branch construction entrances now pass the
canonical path; diagnostic execution remains development-only.

[`link-production-path.spec.ts`](packages/kernel/src/lib/link-production-path.spec.ts)
pins nested egress, root snapshot shape, and unrelated sibling isolation in both
modes. The external-data demo also has a production-mode regression and separate
DOM-event-turn coverage. No endpoint value is manually patched by the demo.

## RESTORATION-ENTITY-SIBLING-EXTERNAL-0 — FIXED LOCALLY 2026-09-17

- [x] Characterize and resolve the entity-row restoration refusal after external
      truth changes a different field, without losing same-field protection.

Entity notifications publish whole rows. Treating the entire snapshot as
external truth incorrectly blocked undo of unchanged siblings; clearing that
snapshot after an authored sibling write could also erase a real conflict.
The guard now tracks changed fields per stable subject and uses the captured
realization address so a rekey round trip cannot lose protection.

Regression coverage in
[`p0c-row-divergence.spec.ts`](packages/kernel/src/enhancers/restoration/p0c-row-divergence.spec.ts)
checks direct entity-field writes and `updateOne()`, repeated undo/redo with
external sibling updates, atomic refusal when an edited field conflicts,
authored/restored siblings preserving a conflict, and undo after a rekey.
The homepage now demonstrates this sequence with an actual `entityMap`.

## RESTORATION-HOT-PATH-0

**CLOSED — one production defect removed; no retained-plan redesign earned.**
Reproduce with `node tools/bench-restoration-hot-path.mjs --production`.

Determine the irreducible recurring CPU cost of reversing one already-retained
scalar causal turn, and identify work performed during `undo()` that can be
prepaid when the designated turn is retained. This is a bounded, non-gating
internal investigation: the browser's 20-change totals are sub-millisecond,
quantized near its timer floor, and observed ranges can overlap. Do not change
the public benchmark cohort or replace the retained-turn representation before
attribution.

Use one production tree, one entity, one scalar field, 20 sequential designated
changes, then 20 sequential undos. Exclude structural mutation, external truth,
conflicting later work, rendering, and module/setup cost. Compare the same
already-known scalar reversal through the production realization port with the
full public `undo()` path; the direct arm is internal calibration, not a product
comparator.

Instrument and report high-resolution Node timings and counters for:

1. turn, position, frontier, and restoration-index lookup;
2. undo-closure and affected-position resolution;
3. reversal-effect materialization and refusal validation;
4. atomic reversal mutation;
5. causal/frontier bookkeeping and consistency checks;
6. observation invalidation and coherent publication;
7. redo/history cursor maintenance.

The first falsifier is duplicated planning. `undoAt()` currently resolves the
contained closure through `canUndoAt()`, resolves it again before selecting the
seed position, and `undoPosition()` resolves the closure again. Measure those
passes independently before changing them. Every arm must verify the value after
each undo, final seeded state, retained/redo position, stable entity identity,
and one coherent publication. Any proposed recording-time prepayment must report
its retained-byte and designation-time cost beside the recurring undo gain.

Result: root `tree.undo()` does not use scoped `undoAt()`. It resolves one
ordinary closure per undo. The scoped manager path resolves the contained
closure twice and an ordinary closure three times, but it is not the browser
workload and is a post-GA local-refactor candidate only.

The removable production cost was `assertTurnStatusConsistency()`: it scanned
every retained turn after every undo and redo. With 1,000 retained scalar turns,
the production batch measured about 119 ms while a reversible no-assertion arm
measured about 4 ms. The refined controls separate the manager effect pipeline
(about 1.9 ms) from precomputed physical application (about 1.1 ms). The
scan now follows the shared production policy: `ngDevMode` when defined, with
explicit `NODE_ENV=development`/`test` as the framework-neutral fallback.
Explicit development and test environments retain the invariant; production
and unknown browser environments skip it. A
rebuilt production runs measure about 4-6 ms for 1,000 undos. At the
browser-shaped 20 turns, production remains sub-millisecond and direct physical
application is roughly 46 us in one run. Every profiled arm performs exactly one
atomic realization application per turn. The remaining root overhead is only a
few microseconds per undo and does not earn a retained representation change
before GA.

## BUNDLE-REACHABILITY-0

**CLOSED — no accidental optional edge found.** Reproduce with
`node tools/bundle-reachability.mjs`.

The production audit measures 9.55 KB gzip bare, 21.49 KB with `entityMap`, and
28.11 KB with exercised restoration. `entityMap` adds its entity runtime,
structural/value stores, mutation frame, marker, projection seed, and structural
effect cloning. Restoration adds its manager, realization adapter, transition
planner, notifier/interceptor, restoration claims and reclamation, transaction
lifecycle, position traversal, and structural effect cloning.

`deep-clone` is not an accidental edge in either arm: `entityMap` snapshots
structural add/remove/rekey payloads, and restoration prepares structural values
for replay. Splitting scalar and structural restoration would be a packaging and
runtime redesign, not import cleanup. Correcting the generators to designate a
real turn puts restoration at about +18.6 KB over bare; the old arm called
`undo()` on empty history and understated the reachable feature. No module can
be removed without deleting a currently supported semantic job, so bundle
reachability closes with no production change. Current framework facade-only
costs remain small and are not optimization targets.

## RESTORATION-LIFETIME-0

**POST-GA, NON-PUBLIC, NON-GATING.** If performance work reopens, run a
long-duration production profile with 100k authored operations, a bounded
restoration window, periodic undo/redo, mixed scalar and structural changes, and
interspersed external realizations. Report CPU/op by time window, allocation/op,
GC, retained-heap slope, history/index cardinality, and coherent publication
cost. The governing question is whether recurring CPU and allocation remain
flat as lifetime operation count grows. This is not another public comparator
workload and does not block v15.

## BULK-POPULATION-0

**REGRESSION CEILING ONLY.** Current `entityMap.setAll(10k)` is about 23 ms after
the transient-facade defect was reduced from roughly 90 ms. Do not optimize this
path merely to improve construction. Reopen only for an algorithmic regression,
a repeated same-machine material regression without a recurring benefit, or a
pathological application startup falsifier. A slower `setAll` remains an
acceptable trade when it buys measured recurring speed, density, allocation,
GC, or restoration improvements.

## ATTRIBUTION-PULL-0

**AMENDED 2026-09-08 — DEMOTED FROM GATE TO MESSAGING RESEARCH.**
**No longer blocks `ATTRIBUTION-OWNER-0`.**

### Amendment record

The original preregistration below is preserved unedited. It is not overwritten
because changing a gate after seeing evidence is itself a fact a later reader
needs in order to judge whether the goalposts moved to reach a wanted
conclusion.

**What changed.** A market sweep of 2026 standards, regulation, enterprise
surveys, IAM products, and agent-authorization drafts found the underlying
enterprise requirement — agent identity, delegation, authorization, retained
evidence — already independently established, and being productized by Microsoft
Entra Agent ID, Okta, SailPoint, AWS AgentCore, OpenID AuthZEN, and an IETF
delegation-receipt draft.

**Why that retires the gate — and why it is NOT because "the need is
validated."** That external evidence validates the _adjacent commodity layer_,
not SignalTree's claim. Nothing in it concerns application-state causal
provenance. The correct reading is narrower and less flattering to the original
design:

```text
PULL-0 tested a proposition that was already known.
It would have produced a true but useless positive.
The genuine unknown is whether state-consequence provenance is DISTINCT
from what the commodity stack already delivers.
```

**Evidence caveats recorded deliberately.** The sweep is unverified from inside
this repository, and most survey sources sell the remedy — Deloitte, KPMG,
Grant Thornton and Schellman are governance-advisory firms; the CSA/Strata study
is vendor-sponsored. "90% have allocated AI-governance funding" is exactly the
class of stated-intent signal the original quality gate existed to filter, and
that funding flows to IAM vendors rather than to a state library. The
shipping-product and public-draft citations are stronger in kind than the
surveys and carry the commodity argument on their own.

**Superseded by** `STATE-CONSEQUENCE-VALUE-0` below.

### Current disposition

```text
ATTRIBUTION-PULL-0          DEMOTED — optional messaging/buyer-language research
ATTRIBUTION-OWNER-0         UNBLOCKED — feasibility spike may proceed
STATE-CONSEQUENCE-VALUE-0   OPEN — the real commercial falsifier
authoring surface           DO NOT REOPEN
```

The instrument is **not deleted**.
[`docs/research/attribution-pull-0/`](docs/research/attribution-pull-0/README.md)
— `frames.html` and the ten-beat timeline become the **SignalTree arm** of
`STATE-CONSEQUENCE-VALUE-0`. Reuse them; do not rebuild.

### Original preregistration — preserved as written

**OPEN — DEMAND FALSIFIER. RUN BEFORE ANY IMPLEMENTATION.**

Establish whether actor/delegation provenance is a real buyer need before
building any of it. Show the ordinary SignalTree causal explanation for a
consequential AI-controlled transaction with actor provenance **deliberately
absent**, and do not mention that it is missing. Observe whether evaluators
spontaneously ask who caused a transition, whether it was agent or user, under
whose authority the agent acted, who approved it, or whether the record can be
independently verified.

Segment the population. The signal differs, and so does its weight:

```text
ENGINEERING / SRE          "who or what actually caused this?"
                           "was that server truth or agent action?"

SECURITY / RISK / AUDIT    "which principal authorized that?"
                           "was the agent delegated?"
                           "can I prove who approved it?"
                           "can that record be independently verified?"
```

A dev audience structurally under-detects this: "who did this, under whose
authority" is a compliance question, not a debugging question. **No spontaneous
question from engineers is a weak negative. No spontaneous attribution or
delegation question from a risk/compliance evaluator, after watching a
consequential agent-driven transaction, is a much stronger negative.**

Reading:

```text
repeated unprompted asks        -> permission to spike ATTRIBUTION-OWNER-0
no asks                         -> do not build it yet
explicit indifference after
  the capability is explained   -> evidence against productization
```

Absence of asks is not deletion authority; latent needs exist and are not always
articulated. If a risk evaluator asks how they would know the agent really acted
under a named principal's authority, that validates not merely actor provenance
but the specific split between a presented credential and an operation receipt.

## ATTRIBUTION-OWNER-0

**RUN 2026-09-08.**

```text
A — REFUTED       synchronous scope attribution does not survive deferred
                  publication inside a transaction
B — LEADING       existing semantic facts appear sufficient; the generic
                  observation surface appears insufficient
C — NOT REFUTED   scope-token carriage, realization/derivedFrom and cross-tree
                  ownership are not yet discriminated

Next: MUTATION-OBSERVABILITY-0
```

Spike at `packages/kernel/src/lib/internals/provenance-spike.ts` (+ `.spec.ts`),
internal and unexported. **10 passed / 4 red of 14 written — and 14 is not 15.**

### Correction to the first report

The first pass blamed `interceptLeafSignals` and declared outcome B. **That was
a wrong-channel error, not a finding.** `PathNotifier` — already subscribed by
`transactions`, `restoration`, `link`, the diagnostic journal and the causal
realization adapter — _does_ observe transaction writes and delivers
`meta.transactionOwner`, so tree isolation is available. `interceptLeafSignals`
is the documented FALLBACK for direct leaf writes that never reach the notifier.
Switching channel turned case 3 green. **The composition-safe channel largely
already exists; building another observer would have been duplication.**

### What is actually missing

```text
1. REVERSAL IS SILENT
   a pending scalar rollback emits NOTHING through the notifier —
   state goes 0 -> 1 -> 0 with ONE event. onCommitScopesSettled also
   drops the commit/discard outcome. Cases 4, 6, 12 red.

2. DEFERRED PUBLICATION BREAKS SYNCHRONOUS ATTRIBUTION  <- discriminator
   a write inside a transaction body publishes AFTER settlement, when
   the synchronous scope has closed. Case 3 passes only because its
   scope WRAPS the transaction; case 10 — transaction wrapping two
   scopes — records nothing.
```

**Sub-prediction A is REFUTED with the current seam.** Not because the model
forbids multi-actor transactions, but because ambient synchronous attribution
cannot survive deferred publication.

### Why B vs C is genuinely open

Fixing (2) needs a scope token carried from write time to publication time.
`WriteMetadata` is a **closed union with no slot for one**, so an enhancer
cannot stash it. Whether that is publication of an existing fact (**B**) or a
new fact the kernel must retain (**C**) is precisely what
`MUTATION-OBSERVABILITY-0` must decide. **Do not assume B.**

### Recorded against myself

- Case 12 first passed **vacuously** — `[].every()` is `true` on an empty effect
  set. A non-vacuity guard was added and it correctly went red.
- `published` was implemented as `!Object.is(next, prev)` — manufacturing the
  publication fact this track had already ruled must never be inferred from
  value equality. Now `published: 'unknown'` with a separate `objectIsChanged`.
- **Two preregistered controls were never written**, and a classification was
  reported anyway: control **11** (one scope spanning two trees) and control
  **14** (realization/restoration `derivedFrom`).
- `participation` — the real authorship/realization axis — is never read.
  Classification comes only from `meta.origin`, so the four-way
  authored/external/realization/restoration model remains **unproven**.

### Consequence for STATE-CONSEQUENCE-VALUE-0

Its SignalTree arm cannot yet be built. **Do not run the comparison against
transaction-free trees** — that would delete attempted/committed/rolled-back,
which is part of what SignalTree claims to explain better, and would prove
differentiated causality by avoiding the hardest causal semantics. Derive the
seam first.

## MUTATION-OBSERVABILITY-0

**OPEN — successor to the observation half of `ATTRIBUTION-OWNER-0`.**

**Status amended 2026-09-22.** The hold recorded below — _"no further kernel
excavation until `STATE-CONSEQUENCE-VALUE-0` reports"_ — is **discharged**.
SCV-0 reported **CLOSED / DIFFERENTIATION NOT EARNED** on 2026-09-08, which
retires the forensic-attribution consumer this track was excavating for.

What remains open is re-justified, if at all, by `MULTI-WRITER-INTERACTION-0`
below — a **different product with a different falsifier**, not a rename of the
closed one. Only **MO-2 disposition isolation** is a live dependency of that
track. MO-1A, MO-1B and MO-3A are answered and **must not be re-derived**; see
that section's "Already answered" table.

Named without presupposing provenance ownership, because the seam may serve
other enhancers.

> Can the kernel expose its already-existing mutation and settlement facts
> through one composition-safe internal observation boundary, sufficient for
> provenance and potentially other enhancers, **without adding new state
> semantics**?

**Null:** every fact needed already exists; the defect is fragmented and
internal observability only.

**Inventory first.** `PathNotifier` already carries most of it and is already
the common subscriber channel. Do not build a second observer before proving
the existing one insufficient. `interceptLeafSignals` is not the baseline — it
is documented as missing array-valued leaves and writes past `maxDepth`, and as
closed to new consumers.

**Hard entry controls, carried over unrun from `ATTRIBUTION-OWNER-0`:**

```text
C11 — multi-tree transaction-owner isolation
C14 — realization/restoration causal derivation (derivedFrom, no actor inheritance)
```

If both pass on existing facts plus a generic observation seam, **B is earned**.
If either shows the kernel lacks a causal fact needed to state the truth,
**C fires.**

**Falsify across all mutation paths, not just scalar leaves:**

```text
plain scalar writes            batching
transactions                   restoration
transaction rollback           external realization
two simultaneous trees         entityMap scalar fields
structural entity mutations    array-valued leaves
depth > 32                     same-value / equality suppression
```

**Do not freeze the seam shape yet.** The two capabilities the spike suggests —
composition-safe mutation observation, and settlement outcome (`tree key`,
`transaction id`, `commit | discard`) — are hypotheses, not a design.

### The load-bearing question

> **Is the missing scope identity merely UNEXPOSED, or actually DESTROYED?**

Unexposed → **B**. Destroyed → **C**. `WriteMetadata` being a closed union must
NOT decide this by itself. The real question is whether _some existing stable
identity_ lets enhancer-owned state carry the fact across the
deferred-publication boundary. If yes, leave `WriteMetadata` alone.

### Three independent questions

```text
MO-1  MUTATION IDENTITY
      Can enhancer-owned state associate a synchronous provenance scope with a
      stable individual mutation/effect identity?

MO-2  SETTLEMENT
      Can existing transaction identity expose commit/discard so captured
      effects can be dispositioned truthfully?

MO-3A LOCAL DERIVATION
      When SignalTree ITSELF performs restoration / rollback / replay, does
      existing causal state identify the prior operation it derives from?

MO-3B DISTRIBUTED DERIVATION
      When external/server truth arrives, WHO OWNS the correlation between
      that realization and the earlier application operation?
```

### MO-3A — ANSWERED 2026-09-08. Splits, and does NOT fire C.

Inspected the restoration/rollback representations and probed a real undo.

**Transaction rollback — the referent EXISTS.** Compensation writes are stamped
`origin: 'transaction-rollback'` plus `transactionId`, and the DIAG-JOURNAL-1.1
comment states the split explicitly: origin says WHY the write exists,
`transactionId` says WHICH transaction it compensates. That is precisely the
causal referent provenance needs. **B — project it, change nothing.**

**Restoration / undo / redo — NO referent, and none is promised.** Measured:

```text
authored T1   meta keys: mutationIntent, ownerId, restorationDesignated
authored T2   meta keys: mutationIntent, ownerId, restorationDesignated
undo          meta keys: intent, origin, ownerId, participation
              origin = 'restoration', participation = 'realized', 2 -> 1
```

No turn id, no prior-effect id, no restored-from reference — exactly the
negative discriminator: `origin = restoration` and `path = x`, nothing more.

**This is outcome D, not C.** The kernel does not know "this is a restoration of
operation X" while discarding X. There is no X. `RestorationHistoryEntry<T>` is
literally `{ state: T }`; the manager holds only a positional `currentIndex`
into a truncatable array of STATES. Undo means "install the snapshot at index
N-1", not "invert operation X". The prior operation was never retained as an
entity, so nothing was discarded.

And it is **deliberate**: 15.0.0-rc.13 removed `timestamp`, `action` and
`payload` from `RestorationHistoryEntry`, recording that restoration history is
state-only and that labels, clocks and actors should be projected from
application context rather than retained as kernel restoration facts.

**Consequence for the record shape — a truthfulness constraint, not a gap.**

```text
derivedFrom IS legitimate for   transaction-rollback consequences
derivedFrom is NOT legitimate for restoration consequences
```

A restoration consequence may say _"this location was restored to a prior
recorded state."_ It may **not** say _"this derives from operation P17."_ The
absence is a FEATURE: it makes the audit lie identified early in this track —
a restoration implying its original author acted again — structurally
impossible. Do not invent `derivedFrom` for restoration merely because the
proposed record shape had the field. **Narrow the thesis instead.**

**MO-3B is an ownership question before it is a capability question.** For a
scope that proposes a reroute, waits on HTTP, and receives authoritative server
truth five seconds later, `R22 derives from P17` may not be a kernel fact at
all. If nobody transports that correlation across the network, the kernel cannot
infer it truthfully, and adding a kernel field would not help. Likely owners:
application request context, Relay, the backend adapter, an OTel trace context,
or the external provider claim.

```text
"the kernel does not know derivedFrom"   != Outcome C

C means: SignalTree OWNS a semantic relationship but discards a fact required
         to represent it truthfully.
NOT:     SignalTree never received the cross-system correlation at all.
```

### DISCOVERY CLOSED 2026-09-08

```text
Outcome A   REFUTED — existing observation surfaces alone are insufficient
Outcome B   LEADING VERY STRONGLY — every load-bearing fact found so far
            already exists, is a deliberate contraction, or belongs above
            the kernel
Outcome C   NO LOAD-BEARING CASE FOUND
```

Every hard case landed in one of three buckets, and none of them is a missing
kernel semantic:

```text
1. existing fact, merely not exposed
2. deliberate semantic contraction
3. correlation owned above the kernel
```

**Do not spend more effort proving B before testing whether the product
matters.** No further kernel excavation until `STATE-CONSEQUENCE-VALUE-0`
reports.

### The circular dependency, and its resolution

"Expose settlement outcome only once the moat is proven" does not work:
`STATE-CONSEQUENCE-VALUE-0` must test attempted / committed / rolled-back, and
the SignalTree arm cannot observe disposition without it.

**Resolution: a test-only settlement oracle, not a product API.** `confirm()` /
`rollback()` already exist at the application boundary on `PendingTransaction`,
so the research harness wraps `tree.transaction(...)` and feeds the outcome to
the provenance prototype. No public kernel API, no `/authoring`, no claim that
this is the eventual implementation. If the experiment loses, delete it.

**⚠ The oracle alone is NOT sufficient, and the arm must say so.** Measured: on
rollback the writes are never published at all — confirm publishes the net
effects, rollback publishes nothing. So the oracle can state _"transaction
⟨owner,id⟩ was discarded"_ while provenance holds **no effects to disposition**.
The harness can supply the attempted writes because it authors the scenario, but
then:

```text
HONESTY CONSTRAINT

The candidate arm must NOT present harness-supplied facts as
SignalTree-derived facts. Attempt-capture under rollback is the harness's
knowledge, not the kernel's. Label it, or the comparison is rigged the same
way the transaction-free escape hatch would have rigged it.
```

Only if the experiment wins decisively do we return and ask the real question:
what is the smallest legitimate way for a provenance companion to obtain
settlement outcome? **That is when the seam earns consideration — not before.**

```text
MO-1A distinct-location transaction effects
      B — existing identity sufficient (positions delivered, sidecar works)

MO-1B repeated same-location effects
      CLOSED — destroyed at capture BY DESIGN, and out of scope for the product

MO-2  settlement
      ATTRIBUTION ISOLATION = B (proven).
      DISPOSITION ISOLATION = still OPEN — untestable until settlement
      outcome is exposed, because rollback emits no event to cross with.

MO-3A local restoration/replay derivation
      ANSWERED — SPLITS. rollback = B (referent exists).
      restoration = D (no causal parent is promised). Does NOT fire C.

MO-3B distributed realization derivation
      OWNER QUESTION FIRST — probably transport/Relay/application, not kernel
```

Only after those does `ATTRIBUTION-OWNER-0` finally become B or C.

### MO-1 partial answer — inventory + probe, 2026-09-08

Per-effect shapes carry **no operation identity**:

```text
TurnEffectBase   { position, ownerPath, path }
CausalEffect     { owner: PositionId, before, after, subjectId?, structural? }
```

Identity is **locational, not per-operation**. Probed against a real transaction:

```text
distinct paths, one tx    a -> positions[2], b -> positions[3], txId 1
                          BOTH delivered  => sidecar keyed on
                          (transactionOwner, transactionId, positionId) WORKS

same path twice, one tx   a(8) then a(9) -> ONE event, prev:1 next:9
                          the intermediate 8 is GONE  => COALESCED
```

**So MO-1 splits, and the split is the B/C line:**

- **Distinct locations → B.** The association is merely unexposed. A sidecar on
  existing facts recovers it with no `WriteMetadata` change and no new kernel
  semantics.
- **Same location, two scopes, one transaction → C for that fact.** Writes
  inside a transaction are not delivered synchronously (that is what refuted
  sub-prediction A), so a sidecar never sees the individual writes — it sees one
  coalesced effect after both scopes closed. Which scope authored the surviving
  value is genuinely **destroyed**, not hidden.

### MO-1B — CLOSED. Destroyed by design, and correctly so.

The delivery probe above proved only that `PathNotifier` coalesces. It did NOT
prove destruction — the accumulator might have held both effects before
reducing. Inspected directly, it does not.

`enqueueEffect` keys scalar effects by `kind\0path\0position\0subject`, so two
writes to one path **collide by construction**, and on collision it mutates the
existing record in place:

```ts
if (existing.kind === 'set' && effect.kind === 'set') {
  existing.after = effect.after; // in place
  if (existing.before === existing.after) effectMap.delete(key); // round trip
  return; // -> no effect
}
```

No second record is ever created, not even transiently. A round-trip write
(`1 -> 8 -> 1`) produces **zero** effects. **The distinction is genuinely
destroyed at capture time, not merely unexposed.**

**But this is a feature, not a defect, and it must not be reopened.** The
composition is REQUIRED for correct rollback — the neighbouring `RESTORE-P0
P0-B` comment records that keying structural effects without collision made
rollback apply both inverses and restore a row under the name it had been
renamed TO. Preserving intermediates would conflict with a correctness
requirement the kernel already holds.

**And the product does not need it.** Two claims must stay separate:

```text
AUDIT OF ATTEMPTS            A attempted a=8, B attempted a=9
COMMITTED STATE CONSEQUENCE  the transaction changed a from 1 -> 9
```

SignalTree's thesis needs the second. Nothing yet shows it needs the first. A
generic trace system already records calls; **net application-state consequence
is the thing SignalTree may be uniquely able to explain**, and the coalescing
behaviour IS that semantics rather than an obstacle to it.

**Disposition: the same-path multi-scope attempt audit is OUT OF SCOPE for
state-consequence provenance.** Do not let an exotic multi-actor/same-field
transaction earn permanent kernel machinery unless `STATE-CONSEQUENCE-VALUE-0`
demonstrates it needs those semantics.

### MO-2 — PARTIAL, 2026-09-08. Attribution isolation earned; disposition not.

**The adversarial condition is real.** Measured: two independent trees EACH open
`transactionId: 1`. They are separated only by `ownerId` (1 vs 2) and distinct
`transactionOwner` objects.

```text
tree A   path a   txId 1   ownerId 1
tree B   path b   txId 1   ownerId 2
```

**The spike was written with the defect this control exists to catch** — its
sidecar keyed on `transactionId` ALONE, so one tree's rollback would have
reverted another tree's effects. It did not show, because rollback emits no
event at all: **the bug hid behind the silence.** Now keyed on
`(ownerId, transactionId)`, and both observation channels were collapsed onto
one `ingest()` so the keying cannot drift between them again — it already had.

```text
PROVEN     attribution isolates across a colliding transaction id, using
           facts the kernel already delivers -> B, no new semantics
NOT PROVEN rollback DISPOSITION isolation. Untestable today: there is no
           reversal event to cross trees with. Needs settlement outcome
           exposed before it can be falsified at all.
```

Do not read the green control as MO-2 closed. **Half of MO-2 is currently
unfalsifiable**, and that is itself the argument for exposing settlement
outcome — not to add a feature, but to make a correctness property testable.

### MO-2 — narrowed null

> **Rollback provenance requires settlement outcome, not necessarily
> rollback-write publication.**

Given captured effects plus `(transactionOwner, transactionId, 'commit' |
'discard')`, provenance can disposition the effects it already holds and set
`revertedBy: transaction:N`. A compensating write notification is only needed if
some independently meaningful consequence occurs that the original effects plus
disposition do not represent. **Do not add an event merely because the first
record representation expected one.**

### `published` is demoted

Load-bearing: `attempted`, `committed`, `rolled-back`, `realized/restored`.
Secondary: `published`. Whether a reactive notification was emitted may matter
for Studio debugging but is not obviously part of state-consequence provenance.
**Do not let proving `published` drag the architecture** unless
`STATE-CONSEQUENCE-VALUE-0` turns out to need it.

### Entry controls, sharpened

- **C11 — multi-tree isolation.** Verify the complete namespace, not merely that
  `transactionOwner` exists. Use the adversarial case: **tree A transactionId 1
  and tree B transactionId 1 must never collide** in provenance bookkeeping.
- **C14 — realization/restoration.** Does existing causal linkage suffice to say
  a later consequence derives from prior scope `P17` _without copying P17's
  actor/claim onto the later write_? If all that survives is
  `participation: realization` with no causal referent, `derivedFrom` may itself
  require a new retained fact — **C even if transaction provenance is fully
  solved by a sidecar.**

---

**Original unblocking rationale, retained:**

---

**Original unblocking rationale, retained:**

Unblocked as a **bounded, internal, deletable feasibility prerequisite** —
required to construct the SignalTree arm of `STATE-CONSEQUENCE-VALUE-0` — and
explicitly **not** because market demand passed a threshold. The market sweep
that retired the PULL-0 gate validated the adjacent IAM/accountability layer,
not this thesis. Feasibility is a question that had to be answered before any
provenance work regardless of what buyers say, and the answer is cheap and
reversible to obtain.

Prohibitions from the original preregistration all still hold: no public kernel
API additions, no reopening `/authoring`, no actor fields in `WriteMetadata`, no
async ambient context. Unblocked means the spike may be written, not that
anything may ship.

### The trust model shrinks — SignalTree consumes claims, it does not mint them

Recorded 2026-09-08, and it makes the spike smaller. Agent identity, delegated
authorization, on-behalf-of semantics, and signed authorization receipts are
being commoditized by Entra Agent ID, Okta, SailPoint, AWS AgentCore, OpenID
AuthZEN, and IETF delegation-receipt work. SignalTree must not reinvent any of
it.

```text
external identity provider          SignalTree
  agent identity                      provenance scope
  human delegation          ───►      committed / rolled-back consequences
  authorization                       causal linkage
  signed claim                        binding claim to state effect
```

The spike therefore carries the external claim as an **opaque value it never
interprets**:

```ts
interface ProvenanceScopeContext {
  scopeId: string;
  externalClaim?: unknown; // opaque provider-issued evidence
}
```

The concrete claim type is not SignalTree's problem unless later evidence earns
an adapter contract. This strengthens the null: a scope carrying an opaque blob
is far easier to keep out of the kernel than one modelling a trust system.

The `actor` / `onBehalfOf` / `authorization` fields described below remain the
right **vocabulary for the evidence record**, but they are now understood as
projections of an externally issued claim, not as facts SignalTree establishes.

### The original ownership question

Can trustworthy actor/delegation provenance be built without putting actor
machinery into the kernel?

The candidate answer is that a **provenance scope is an application-declared
semantic operation boundary, not a SignalTree causal turn.** The kernel keeps
physical mutation, authorship, publication, realization, and external
consequence exactly as they are. The scope only says: for the duration of this
synchronous frame, attribute qualifying effects to this provenance context.
That resolves the fact that ordinary writes have no universal authored-turn
identifier for provenance to decorate — `turnId` is private to the transactions
enhancer (`transactions.ts`), and outside a transaction a consequence runs
immediately in the caller's stack (`commit-consequence.ts`). The caller naming
the scope _is_ the boundary.

Four separate questions, four separate fields. Do not overload them:

```text
actor          who intentionally initiated this provenance operation
onBehalfOf     whose delegated authority the actor was exercising
authorization  what permission / approval / policy permitted it
origin         what semantic kind of transition this particular effect was
derivedFrom    which prior operation caused this consequence
```

`authorization`, never `authority` — the kernel already uses _authority_ for who
owns the decision or the truth, and a second meaning inside the same record
would collide.

Origin is **per effect**, actor is **per scope**. One scope can legitimately span
authored and external effects, so origin cannot live on the scope without
re-coupling two axes that are supposed to be orthogonal.

```ts
interface ProvenanceScope {
  scopeId: string;
  actor: ActorRef;
  onBehalfOf?: PrincipalRef;
  authorization?: AuthorizationRef;
  parentScopeId?: string; // nested scopes: inner wins, lineage retained
  attempts: ProvenanceAttempt[];
  effects: ProvenanceEffect[];
  summary: ProvenanceSummary; // derived convenience, never authoritative
}

interface ProvenanceEffect {
  path: string;
  origin: 'authored' | 'external' | 'realization' | 'restoration';
  derivedFrom?: string; // realization/restoration: point at the cause,
  // never inherit the original actor
  disposition: 'committed' | 'rolled-back';
  revertedBy?: string; // what caused the reversal — without this a
  // multi-scope transaction implicates the wrong
  // actor for a failure it did not own
  published: boolean;
  equalityBasis?: string; // publication is equality-gated; without the
  // compare verdict or a config fingerprint,
  // cross-deployment comparison is unsound
}

interface ProvenanceSummary {
  attempted: number;
  committed: number;
  rolledBack: number;
  published: number;
  classification: 'committed' | 'rolled-back' | 'partial' | 'no-published-state-effect' | 'failed';
}
```

`no-published-state-effect`, never `no-effect`. Semantic transitions may be
value-neutral, so "nothing published" must not be recorded as "nothing
happened." Individual effects are the evidence; the classification is
convenience.

Trust is two artifacts, not one. The client **presents** a claim; a trusted sink
**verifies** it and issues a receipt. Never let the claimant declare its own
assurance level.

```text
IDENTITY / DELEGATION CREDENTIAL   "agent-7 is authenticated and may act for Alice"
OPERATION RECEIPT                  "the sink observed scope P42 with these effects"
                                   scopeId + canonicalEffectsHash + assurance
                                   ideally the server issues the scopeId/nonce
```

A session-bound credential attests the _session_, not the operation; anything
holding it could attribute arbitrary operations to that actor. Binding the
receipt to the effect set is what makes `server-attested` mean something.

The control-mode coverage gap is **not** an actor claim. Count only authored
writes landing outside every provenance scope while a declared control session
is active — realizations, restorations, and background reconciliation must not
create noise. It says the cooperative protocol was not honoured, never that the
agent caused the write. Report it as _provenance coverage_, not compliance.

### Packaging is the real fork

The settlement primitives a provenance enhancer needs are internal only.
`onCommitScopesSettled` / `settleCommitScope` / `hasOpenCommitScope` are reached
by `transactions.ts` and `owner-invalidation.ts` and are exported from neither
`index.ts` nor `adapter.ts`; `index.ts` states outright that
`getActiveWriteContext` and `interceptLeafSignals` are not root app API.
`transactions()` can observe settlement only because it ships inside the kernel
package. So "no kernel change" is a property of **where the code lives**, not of
the semantics:

```text
(a) inside the kernel package    no public change, but actor vocabulary lands in the kernel
(b) companion package            requires a new enhancer-authoring seam
(c) unexported internal spike    no public change; decides (a) vs (b) with evidence
```

Take **(c)**. Do not reopen `/authoring` — it is recorded as STOPPED and
UNPROVEN pending derived external implementer needs, and this spike is exactly
the evidence that decision asked for.

### Preregistration

```yaml
id: ATTRIBUTION-OWNER-0
status: OPEN / UNBLOCKED 2026-09-08
blocked_on: none
required_by: STATE-CONSEQUENCE-VALUE-0 # the spike builds its SignalTree arm

question: >
  Can trustworthy actor/delegation provenance for SignalTree state effects be
  implemented entirely as an internal enhancer using existing kernel
  mutation/origin/commit-settlement machinery, without changing the public
  kernel contract?

null: >
  Provenance is not a kernel semantic authority. An enhancer-local synchronous
  provenance scope plus existing internal write/origin/settlement seams can
  observe attempts, committed effects, rollback, mixed origins, nesting, and
  derived consequences correctly.

prohibited_changes:
  - no public kernel API additions
  - no reopening /authoring
  - no actor fields in WriteMetadata
  - no provenance fields added to core mutation types
  - no async ambient provenance context # follows external()'s ST1035 ruling

falsifiers:
  - enhancer cannot distinguish committed from rolled-back effects
  - mixed authored/external effects cannot retain independent origins
  - provenance/external nesting order changes the resulting effect set
  - transaction boundaries cross provenance scopes in a way the model cannot
    represent truthfully
  - value-neutral / no-publication cases force false "no effect" claims
  - derived realization/restoration requires falsely inheriting the original actor
  - a reversal cannot be attributed to its cause, implicating the wrong actor
  - trusted sink cannot bind verified identity/delegation to the resulting
    scope/effect record

controls:
  - ordinary authored write
  - synchronous multi-write scope
  - transaction commit
  - transaction rollback
  - committed write plus rolled-back transaction => partial scope
  - scope that throws AFTER a write already committed => committed + failed
  - authored + external mixed-origin scope
  - provenance(external(write)) vs external(provenance(write)) # order-invariant
  - nested provenance scopes
  - two provenance scopes inside one transaction
  - scope spanning writes to two trees # settlement is tree-local
  - same-value write with no publication
  - realization/restoration derivedFrom case
  - control-mode authored write outside every provenance scope

sub_prediction:
  question: may one transaction contain multiple provenance scopes?
  predicted: >
    YES. A multi-agent atomic workflow is the enterprise case the demo exists to
    show, so prohibiting an actor change inside an open transaction forecloses
    the product. Stated as a prediction rather than an open menu so the spike
    can falsify it.

outcomes:
  A: >
    Internal enhancer is sufficient. Provenance ownership is outside the kernel.
    Use the evidence to decide whether a companion package deserves a narrow
    enhancer-authoring seam.
  B: >
    Semantics belong outside the kernel, but one or more internal facilities must
    become a narrowly defined authoring surface. Derive that surface from the
    spike rather than resurrecting /authoring wholesale.
  C: >
    Correct provenance requires a genuinely new kernel semantic fact. Reopen the
    kernel only for that demonstrated fact.
```

Only after `ATTRIBUTION-OWNER-0` and `STATE-CONSEQUENCE-VALUE-0` report should
anything decide whether `@signal-tree/provenance` exists, whether a narrow
enhancer-authoring seam deserves to exist, or whether this stays a demo idea.

## MULTI-WRITER-INTERACTION-0 — preregistered 2026-09-22

**OPEN.** The successor consumer for the still-open half of
`MUTATION-OBSERVABILITY-0`. It does **not** reopen `STATE-CONSEQUENCE-VALUE-0`.

### The distinction this track exists to hold

```text
CLOSED 2026-09-08     FORENSIC ATTRIBUTION
                      "prove who did what under what authority"
                      A competent IAM + OpenTelemetry + backend audit stack
                      reconstructs this with IDs and correlation.
                      DIFFERENTIATION NOT EARNED.

OPEN — this track     LIVE MULTI-WRITER INTERACTION CORRECTNESS
                      "an agent proposed changes to 7 fields across 3 entities;
                       show them, let a human accept or reject them as ONE
                       action, do not clobber concurrent user/server truth,
                       make the accepted action one reversible unit"
                      A state-semantics problem, not an audit problem.
```

The second question is not answered by any amount of identity, tracing or audit
infrastructure. That is the whole basis for reopening anything here, and it is a
different claim from the one that was killed — not the same claim renamed
because agents became fashionable.

### Hard non-goal — the falsifier for scope creep

> This track does not attempt to prove who performed an action, reconstruct
> authoritative delegation, replace IAM / OpenTelemetry / backend audit, or
> establish an evidentiary history. `STATE-CONSEQUENCE-VALUE-0` remains CLOSED.

Language is the detector, because this thesis died once already and the failure
mode is re-entry by vocabulary:

```text
BACK IN THE DEAD THESIS — STOP     PERMITTED REGISTER
"prove what the agent did"         "show what is proposed"
"compliance trail"                 "accept or reject as one operation"
"authoritative actor attribution"  "do not clobber newer truth"
"tamper-evident provenance"        "which current changes belong to this action"
```

Reopening the closed thesis requires new evidence attacking its **original
falsifier**, not a new application of the same capability.

### Already answered — do NOT re-derive

The 2026-09-08 discovery pass answered most of what a multi-writer track would
naively re-ask. Re-running it would burn the budget and risk contradicting a
recorded result.

| Question                                             | Recorded disposition                                                                                                                                                                                             | Consequence here                                                           |
| ---------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| Does mutation identity survive deferred publication? | **MO-1A = B.** Distinct locations: association merely unexposed; a sidecar keyed on `(transactionOwner, transactionId, positionId)` recovers it with no `WriteMetadata` change                                   | Settled. Not a prerequisite                                                |
| Same-path multi-scope attempt audit                  | **MO-1B = CLOSED.** Destroyed at capture — `enqueueEffect` keys by `kind\0path\0position\0subject` and mutates in place; a round trip yields **zero** effects. Required for correct rollback (`RESTORE-P0 P0-B`) | **Must not be reopened.** See below — this track _benefits_ from it        |
| Local restoration/rollback derivation                | **MO-3A ANSWERED.** rollback = B (referent exists: `origin:'transaction-rollback'` + `transactionId`); restoration = **D** — no causal parent is promised, deliberately (15.0.0-rc.13)                           | Settled. `derivedFrom` stays illegitimate for restoration                  |
| Should the kernel model actors?                      | Recorded 2026-09-08: **"SignalTree consumes claims, it does not mint them."** The scope carries `externalClaim?: unknown`, an opaque value it never interprets                                                   | Already binding. Adopt it; do not re-derive it                             |
| Can settlement describe disposition?                 | **MO-2 PARTIAL.** Attribution isolation = B (proven, keyed `(ownerId, transactionId)`). **Disposition isolation still OPEN** — untestable, because rollback emits no event to cross trees with                   | **The only live MO dependency.** Gates `WRITE-CONTEXT-0`, not `PROPOSAL-0` |
| Distributed realization derivation                   | **MO-3B** — an ownership question; likely transport / Relay / application, not kernel                                                                                                                            | Out of scope                                                               |

### Measured 2026-09-22 — speculative state is ALREADY live-readable

This removes what looked like the track's hardest dependency, so it is recorded
before any sub-track is defined.

```text
const pending = store.transaction(() => { store.$.count(1); });

store.$.count()           === 1     <- VISIBLE BEFORE confirm()
getPendingTurnCount()     === 1        the TURN is pending, the VALUE is not
getConfirmedTurnCount()   === 0
```

Source: `packages/kernel/src/enhancers/transactions/transactions.spec.ts`.
Rollback is implemented by **compensating writes**, which is only coherent if
the speculative value was applied in the first place.

**Two layers must not be conflated.** The recorded line _"on rollback the writes
are never published at all"_ describes the **effect-observation channel** that a
provenance sidecar consumes. It does **not** describe tree visibility. Reading it
as the latter produces the false conclusion that a reviewer cannot see a proposal
before accepting it.

```text
TREE VISIBILITY          speculative value readable during a pending turn   YES
EFFECT PUBLICATION       effects delivered to observers at settlement       DEFERRED
```

**Consequence:** the review-UI requirement — a human sees proposed state before
accepting — holds on existing behaviour. `PROPOSAL-0` is therefore **not** gated
on `MUTATION-OBSERVABILITY-0`. That is a correction to the sequencing this track
was proposed with.

### Why MO-1B's coalescing is an asset here, not an obstacle

The killed forensic product wanted the audit of attempts (_A tried 8, B tried
9_). This track wants the **net pending delta** — _what would change if I accept
this?_ Coalescing produces exactly that, and a round trip correctly contributing
nothing is the right answer for a review surface. The semantics that were merely
tolerable for the closed thesis are **correct** for this one.

### Sub-tracks

**Revised 2026-09-22 (second pass).** The first pass ordered these by track
number. It is reordered by **cheapest available falsifier**, which moved the
conflicting-rejection question to the front and un-serialized MO-2. See
"Ordering principle" below.

```text
PROPOSAL-REJECTION-0  RUN FIRST — existential falsifier for the whole track
                      Can a speculative transaction always be rejected without
                      silently retaining its proposed values or overwriting
                      newer truth?

REKEY-SUPERSESSION-0  TINY PREREQUISITE — blocks PROPOSAL-0
                      The one remaining known structural case. When newer
                      truth eliminated the subject a pending rekey created,
                      can the turn skip that compensation and reverse the
                      rest without resurrecting or retargeting an entity?

PROPOSAL-0            PHASE A (kernel) DONE — null survives, 10/10.
                      PHASE B (framework realization conformance) is a
                      MANDATORY release criterion, not follow-up.
                      Is propose/accept/reject a truthful NAME over existing
                      transaction semantics, or does it need new kernel rules?
                      No MO dependency — speculative state is already
                      live-readable, measured 2026-09-22.

MO-2                  INDEPENDENT — may run in parallel with PROPOSAL-0
                      Disposition isolation. The only unresolved
                      mutation-observability question. Gates WRITE-CONTEXT-0
                      ONLY; it does not gate PROPOSAL-0.

WRITE-CONTEXT-0       BLOCKED on MO-2 disposition isolation
                      Can an opaque, externally-owned context survive the
                      complete lifecycle including deferred publication?

AGENT-UX-REFERENCE-0  BLOCKED on PROPOSAL-0
                      Documentation/reference integration only. Ships no kernel.
```

#### Ordering principle

> **Research ordering follows the cheapest available falsifier, not
> architectural layering. Settled findings are inputs, not experiments to
> repeat.**

Two corrections this principle forced, both recorded so the reasoning survives:

- **`MUTATION-OBSERVABILITY-0` is not a prerequisite for `PROPOSAL-0`.** An
  earlier roadmap draft said observability must establish that mutation
  identity survives deferred publication before proposal work begins. That is
  stale: MO-1A is settled (**B** — recoverable via a sidecar keyed on
  `(transactionOwner, transactionId, positionId)`, no `WriteMetadata` change).
  What genuinely does not survive deferred publication is **ambient
  write-context attribution** (spike case 10), and that is a `WRITE-CONTEXT-0`
  problem. A review UI never needs it — the human reads proposed values off the
  tree directly. **Transaction identity and ambient write context are not the
  same question**, and coupling them made two independently falsifiable things
  serial for no reason.

- **MO-2 is not ordered before `PROPOSAL-0`.** It is roughly a day's work, but
  cost is not a dependency. It gates `WRITE-CONTEXT-0` and nothing else.

#### Baseline

```text
15.2.1 — COMPLETE. The frozen baseline for this track.
```

Published to npm for `@signal-tree/{kernel,angular,react,vue,solid}`, tagged
`v15.2.1` 2026-09-21. No commit since that tag touches `packages/`. **Do not
open work to "finish" or "stabilize" this release** — stale status language is
how a closed release gets reopened.

#### PROPOSAL-REJECTION-0

**CLOSED — PR-A confirmed and fixed, 2026-09-22.** Preregistered, run, and
dispositioned: a superseded structural effect no longer blocks rollback. Full
disposition and acceptance matrix below; the header said OPEN for a day after
the fix landed.

The product pitch is _"show provisional changes and safely reject them."_ If
rejection is not safe under the adversarial case, the pitch is false and no
amount of naming, context or reference UX repairs it. This is the cheapest
test that can kill the track, so it runs first.

**Observation pass RUN 2026-09-22.** Fixture:
`packages/kernel/src/enhancers/transactions/proposal-rejection-0.spec.ts`,
12 cases, all green. The fixture records measurements only; the disposition
argument lives here.

**Correction 1 — to the preregistration.** It was written from a source
reading that said any conflicting effect aborts the whole compensation list.
Measurement refuted that for scalars.

**Correction 2 — to the first reading of that measurement.** The first pass
described the split as _scalar vs structural_. That is a proxy. The axis the
existing rationale actually names is **whether newer truth DEPENDS on the
speculative fact, or has SUPERSEDED it** — and the two happen to coincide in
every case measured before the control below was added.

```text
SUPERSEDED                              DEPENDED-UPON
tx sets a = 1                           tx adds row A
later: a = 99                           later: server updates row A
the tx's contribution at `a` is         the tx's structural contribution is
already gone; compensating the          still required by newer truth;
turn's other locations COMPLETES        removing A would destroy it, and
the reversal                            compensating only the scalars would
                                        HALF-APPLY the turn
-> reject can succeed                   -> refusing is coherent
```

Refusal in the depended-upon column is not a defect. Partially reversing a
logical operation while reporting it as rejected is the partial-undo behaviour
this repo has repeatedly judged worse than an honest refusal.

**The discriminating control** (cases 11 and 12) therefore tests supersession
on the structural arm, where dependency and supersession finally come apart:

```text
initial     x = 0, y = 0, no row A
tx          x = 1, y = 2, rows.addOne('A')
later       rows.removeOne('A')        <- ERASES the tx's structural fact;
                                          nothing depends on it surviving
reject      throws later-confirmed-dependency
after       x = 1   y = 2   rows = []  <- x and y NEVER compensated
```

Identical for a realized remove and for an ordinary authored remove, so this is
not realization-specific handling.

**Measured summary:**

```text
later effect vs pending turn                    rejection behaviour
---------------------------------------------------------------------------
scalar set, later REPLACEMENT (auth/realized)   surgical compensation
structural add, later UPDATE of the subject     whole-turn refusal
structural add, later REMOVE of the subject     whole-turn refusal
```

**Mechanism, read from source.** `classifyLaterOverlap` distinguishes
supersession from conflict for scalars via `mutationIntent === 'replace'` plus
`supersededScalarKeys`. `hasSameSubjectDependency` returns a conflict for **any**
later same-subject effect — it never asks whether that effect depends on the
turn's structural fact or erases it. Its name states a dependency test; its
body implements a presence test.

**DISPOSITION: PR-A — CONFIRMED 2026-09-22.** The control was specified in
advance with two outcomes: reject succeeds and the scalars compensate
(structural machinery already distinguishes dependency from supersession ->
PR-C), or reject refuses with the scalars left dirty (classifier too coarse ->
PR-A). The measured result is the second. Newer truth had _erased_ the
speculative row rather than come to rely on it, so no "don't destroy newer
truth" rationale covers leaving `x` and `y` dirty — there is no newer truth at
`x` or `y` at all.

**The semantic rule the fix must satisfy:**

> **The axis is supersession vs dependency, not scalar vs structural.**

**PR-A is NOT a licence to partially roll back turns with real structural
dependencies.** It is narrower: `hasSameSubjectDependency` cannot distinguish

```text
newer truth that DEPENDS ON speculative structure   -> refusal stays correct
newer truth that SUPERSEDES/REMOVES it              -> rollback should complete
                                                       for the rest of the turn
```

The scalar path already draws this distinction; the structural path does not.
Half-applying a turn whose structural fact newer truth still needs remains the
partial-undo behaviour this repo judges worse than an honest refusal.

**Acceptance matrix for the fix:**

```text
tx adds A;      later UPDATES A        rollback -> REFUSE
tx adds A;      later REMOVES A        rollback -> SUCCEED for remaining effects
tx sets scalar; later REPLACES scalar  rollback -> preserve newer, compensate rest
unrelated later write                  rollback -> SUCCEED
```

**PR-A FIX LANDED 2026-09-22.** `classifyStructuralOverlap` in
`transactions.ts` gives the structural arm the supersession distinction the
scalar arm had. A pending `add` whose subject the later work ERASED is
superseded; anything that puts the subject back keeps refusing. Acceptance
suite is the same fixture, now 16 cases.

Mutation-checked rather than assumed green:

```text
always-supersede-a-pending-add        kills 4 cases, incl. 9 and 14   OK
widen supersession to pending remove  survives                        INERT
```

The second is inert, not a coverage hole: a later remove of an
already-removed subject is unreachable (the collection throws "Entity with id
... not found"), verified by probe.

**Two same-symptom gaps recorded, NOT fixed** — both verified identical with
and without the fix, so they are pre-existing:

```text
case 15  pending REMOVE, later re-add    refuses via effect-validation-failed
                                         newer truth preserved, scalar stranded
case 16  pending REKEY, later remove     refuses via later-confirmed-dependency
                                         structural fact gone, scalar stranded
```

Case 16 is the same rule PR-A just applied and would be consistent to fix.
It was left out because rekey rollback carries a documented repair history
(RESTORE-P0 P0-B, `d487a4ae`, pinned by `rekeyed-rollback-defect.spec.ts`), so
widening into it risks regressing a deliberate prior repair. **OPEN DECISION:**
extend PR-A to pending rekey, or ship the narrow fix and track case 16
separately.

Also corrected by measurement: case 13 (later remove then re-add) does not
refuse and must not — stable entity lifetime makes the re-added row a
DIFFERENT subject, so compensating the turn cannot reach it. The pre-PR-A
build refused there and stranded the scalar; the fix strictly improves it.

**Gate evidence for the PR-A fix, `ff864757`:** `gates --release` 81/81
passed, 0 failed, 0 known-red; `gates:self-test` 70/70 proven able to fail,
0 unproven, 0 blind, 0 errored. A transaction-classification change is exactly
where a mutation-tested gate can go blind while ordinary tests stay green, so
this was run before any follow-up work.

**Sequencing consequence.** `PROPOSAL-0` does NOT open yet. This lands first as
a standalone generic transaction correctness fix, in its own change, with:

- refusal preserved for the depends-on cases
- structural supersession no longer blocking rollback
- unrelated effects in the turn compensated
- entity lifetime semantics intact
- mutation/falsifier coverage proving the classifier distinguishes
  **dependency vs supersession**, not merely scalar vs structural
- full transaction, restoration and entity-lifetime suites run

**The existing rationale is serious and must be engaged, not assumed wrong.**
The code comment argues the `'commit'` settle is correct _because_ nothing was
compensated: the authored writes are still live and therefore _are_ the truth a
reader sees, so discarding would drop durable consequences for state the tree
is still displaying — the tree/storage divergence the commit boundary exists to
prevent. The "application refetch fallback" is a shipped, tested pattern, not
an oversight. **This track may well conclude the kernel is right and the
proposal thesis must adapt.**

> **Null:** current rejection semantics are correct as general transaction
> behaviour, and a truthful multi-writer review UX can be built on them with no
> proposal-specific rule.

Falsify across: human write during a proposal; server realization during a
proposal; same-location conflict; multi-location proposal; multi-entity
proposal; entity remove/re-add; conflict on one path of many.

**Dispositions — exactly one must be chosen before `PROPOSAL-0` opens.**
Labelled `PR-*` deliberately: these are NOT the A/B/C outcomes of the
`MULTI-WRITER-INTERACTION-0` preregistration further down, which mean
different things.

```text
PR-A  TRANSACTION CORRECTNESS DEFECT
   Rejection should compensate the non-conflicting effects and refuse only
   the conflicting ones, or should not settle unreverted work as 'commit'.
   -> Fix transaction semantics FIRST, generically, with no proposal branding.
      This is kernel work and gets its own release.

PR-B  SEMANTICS CORRECT, THESIS INCOMPATIBLE
   The behaviour is right for transactions but cannot carry a truthful review
   UX without a proposal-only exception.
   -> PROPOSAL-0's null is FALSIFIED. propose() is not sugar over transaction().
      Stop and re-scope the product claim before writing any API.

PR-C  MISREADING OF THE CONFLICT CASE
   The refusal contract is truthful and sufficient; a review UI is expected to
   catch, surface the conflict and reconcile.
   -> Pin the correct behaviour with a minimal test, document the contract,
      proceed to PROPOSAL-0 unchanged.
```

**Required regardless of disposition:** the refusal contract is currently
invisible to consumers. `SignalTreeRollbackError` and
`later-confirmed-dependency` appear only in `docs/architecture/**` and
`docs/audits/**` — both **ungated** for dead-API drift — and in no gated
user-facing document. `apps/demo` contains **zero** transaction usage.

Falsifiers for this track itself:

- a "fix" that makes rejection safe only when the transaction came from
  `propose()` — that is disposition B wearing disposition A's clothes
- partial compensation that leaves the tree and durable storage divergent —
  the exact failure the current `'commit'` settle exists to prevent
- reporting a conflict set that the application cannot act on (today only the
  first conflicting pair is named)

#### PROPOSAL-0

**BLOCKED on `PROPOSAL-REJECTION-0` reporting PR-A or PR-C.** If it reports
PR-B, this
section does not open — the null below is already falsified and the product
claim needs re-scoping first.

> **Null:** `propose()` / `accept()` / `reject()` can be implemented as a
> semantic facade over existing transaction behaviour, introducing **no new
> kernel state semantics**.

```text
propose()   ->  transaction()
accept()    ->  confirm()
reject()    ->  rollback()
```

Deliberately **provenance-neutral**. The application already knows it invoked an
agent and can render that itself. This track must not acquire an actor concept
to justify itself.

Try to kill the null across: multiple fields; multiple entities; remove/re-add;
server realization arriving _during_ a proposal; user write _during_ a proposal;
rejection; acceptance; later restoration; held references. **If any case needs
`propose()` to have a rule `transaction()` does not have, it is not DX sugar and
the null fails.**

Falsifiers:

- a proposal cannot be presented as one reviewable unit across several entities
- accepting is not one reversible unit in restoration history
- concurrent authoritative truth arriving mid-proposal is clobbered on accept,
  or silently discarded on reject
- rejecting leaves observable residue
- the API must special-case structural entity mutation to stay truthful

#### REKEY-SUPERSESSION-0

**CLOSED — rekey supersession fixed, 2026-09-22.** Was the last known
structural case deciding whether "reject the proposal" can truthfully mean
reject the _whole_ proposal. It no longer blocks `PROPOSAL-0`, which is
itself now implemented. Disposition below.

> **Question:** when newer truth has eliminated or superseded the subject/key
> state created by a pending rekey, can the transaction safely skip that
> structural compensation and reverse the rest of the turn **without
> resurrecting or retargeting an entity**?

Scope discipline: this is the last opportunistic transaction question. Once it
dispositions, stop hunting edge cases and enter the preregistered `PROPOSAL-0`
matrix.

**Why it is not merely tidy-up.** PR-A established the rule — _the axis is
supersession vs dependency, not scalar vs structural_. Case 16 is the same
defect class under that rule:

```text
initial     row A,  x = 0
tx          x = 1,  changeId A -> A2
later       remove A2
reject      currently REFUSES; x stranded at 1; row absent
```

The structural state the turn introduced is already gone. If `x` stays
speculative only because a later removal is classified as a dependency rather
than a supersession, PR-A's rule says that classification is wrong.

**Why it was not folded into `ff864757`.** Rekey rollback carries a documented
repair history — RESTORE-P0 P0-B, `d487a4ae`, pinned by
`rekeyed-rollback-defect.spec.ts`, whose own table records rekey+remove and
rekey+update as separately broken and separately repaired. Widening into a
deliberate prior repair inside a commit with a different preregistered target
is how a fixed bug returns.

**Case 15 is a CONTROL, not a second fix.** It strands the same scalar, and
that coincidence must not merge the two:

```text
case 15  pending REMOVE of A, later writer creates a new A
         rollback would restore the ORIGINAL A into a key newer truth occupies
         -> refusal is COHERENT. Whole-turn refusal leaves the unrelated scalar
            speculative, and that is the price of atomic rejection when the
            turn cannot be completely reversed.
         -> EXPECTED REFUSAL / CONTROL. Do not "fix".

case 16  pending REKEY, later writer eliminated the rekeyed subject
         nothing remains to resurrect or retarget
         -> UNRESOLVED SUPERSESSION QUESTION. This track.
```

**Minimum matrix — pin all five BEFORE changing rekey code:**

```text
1  tx changeId A->A2;  later update A2
   rollback -> REFUSE          newer truth depends on the surviving subject

2  tx changeId A->A2;  later remove A2
   rollback -> SUCCEED for unrelated tx effects; row remains absent

3  tx changeId A->A2;  later remove A2, then add a new A2
   rollback -> MUST NOT touch the new subject
   unrelated tx effects revert only if lifetime separation makes it safe

4  clean tx rekey, no later writer
   rollback -> restore original A     RESTORE-P0 behaviour UNCHANGED

5  tx rekey + another structural operation
   no regression of the rekey/remove repair
```

Case 3 is the discriminating one: v15 subject lifetime should make the
re-added business key a **different subject**, which turns an otherwise
ambiguous question into a testable one — exactly as it did for PR-A case 13.

**Falsifiers — any of these means stop and keep the refusal:**

- skipping the rekey compensation resurrects an entity, or retargets a held
  reference to a different subject
- case 4 changes in any way, i.e. the RESTORE-P0 repair regresses
- the fix needs a rule that applies only to rekey rather than following from
  the supersession/dependency axis
- case 3 lets compensation reach the newly created subject

**DISPOSITIONED AND FIXED 2026-09-22.** The matrix was pinned first
(`2eae8ef3`), then `classifyStructuralOverlap` was widened from `add` to
`add | rekey` — one clause, same rule.

One prediction was wrong before it ran, and narrowed the track:

```text
case 1  later UPDATE of the rekeyed subject   ALREADY SURGICAL, not a refusal
        `hasSameSubjectDependency` guards later `set` effects with
        `effect.kind !== 'rekey'`, deliberately: a rekey changes the KEY, a
        later set changes a FIELD. They do not contend. The rename reverses,
        the server's field value rides along with the subject.
```

So only case 2 was ever defective, and the fix moved exactly cases 2 and 3:

```text
case 2  later REMOVE          refuse, x stranded  ->  reverses, x = 0, row absent
case 3  later REMOVE + ADD    refuse, x stranded  ->  reverses, x = 0,
                                                      new subject UNTOUCHED
case 1, 4, 5                  unchanged
```

Case 3 resolved the way subject lifetime predicted: the re-added business key
is a different subject, so compensation cannot reach it and reversing the rest
is safe — the same mechanism that decided `proposal-rejection-0` case 13.

Mutation-checked:

```text
rekey always superseded (drop the erasure test)   kills 5, incl. RESTORE-P0
                                                  controls               OK
first-remove-wins instead of last-effect-wins     survives          UNOBSERVABLE
```

The second is recorded rather than papered over: stable entity lifetime means
a removed subject can never be referenced again, so the scan-to-end and a
break-on-first-remove are indistinguishable by any test. The scan is kept as
the form that stays correct if subject resurrection ever becomes
representable, and the code comment now says so instead of claiming the scan
is load-bearing.

**Case 15 stays an expected-refusal control**, unmoved. It strands the same
scalar for a different reason — compensating a pending remove restores the
ORIGINAL row into a key newer truth occupies — so refusing is coherent there.
Sharing a symptom was not allowed to merge the two.

**`PROPOSAL-0` is now unblocked.** Stop hunting transaction edge cases
opportunistically; enter the preregistered PROPOSAL-0 matrix.

#### PROPOSAL-0 — PHASE A (kernel) RUN 2026-09-22

**NULL SURVIVES at the kernel level.** Fixture:
`packages/kernel/src/enhancers/transactions/proposal-0-kernel.spec.ts`,
10 cases, green on the first run. **No case required a rule `transaction()`
does not already have**, so the mapping holds:

```text
propose -> transaction     accept -> confirm     reject -> rollback
```

Written entirely against the shipped primitives on purpose: if the matrix
passes without a facade, that IS the evidence a facade would add naming and
nothing else. No public API named.

Settled by this pass:

```text
A1  clean accept              speculative value readable pre-accept, survives
A2  clean reject              withdrawn through the same references
A3  multi-field               one unit on both accept and reject
A4  multi-entity              no partial settlement
A5  unrelated human edit      survives rejection
A6  server write then ACCEPT  see below — the product finding
A7  mixed scalar + structural coherent single turn
A8  remove/re-add lifetime    held reference does NOT retarget; the reused
                              business key is a different subject
A9  restoration               confirm alone adds NO undo step;
                              undoable(confirm) adds exactly one, and undo
                              reverses the turn as one unit
A10 two proposals at once     independent handles settle independently
```

**A10 was previously unpinned.** The data structures supported concurrent
pending turns (`pendingTurns` is a Map, `openScopesByKey` a Set) but no test
held two handles open and settled them separately. It is the review-UI
requirement — one proposal outstanding while the human keeps working — and it
now has a test.

**A6 is a product finding, not a defect.** Accepting a proposal whose location
newer truth already overwrote does **not** clobber that newer truth: the
server's value stands and the proposal's other locations commit.

```text
propose  name='FromAgent', priority=3
server   name='FromServer'
ACCEPT   -> name='FromServer', priority=3
```

Consistent with external-authority semantics and with the reject-side rule, so
the null holds. But it means **accept is not "apply everything I proposed"**,
and a review surface that says "Accepted" without showing which fields were
superseded would be lying to the user. That is a Phase B / AGENT-UX-REFERENCE-0
requirement, recorded here so it is not discovered late.

**One honest qualification on "just naming".** A9 shows that one-undo-unit
behaviour needs `undoable(() => transaction(...).confirm())`, not `confirm()`
alone. That is composition of two shipped primitives rather than a new
semantic, so the null stands — but a facade must DECIDE whether accepting
enrolls in restoration, and that decision is a public-surface question, not an
implementation detail. Carry it into the API-derivation step.

**Phase B is a MANDATORY release criterion, not follow-up.** The kernel owns
what proposal semantics mean; adapters prove each framework physically
realizes them. Do not duplicate this matrix four times — build one shared
realization contract every shipping adapter must pass:

```text
proposal-realization-conformance
  1  speculative value observable before settlement
  2  accept leaves the committed value visible through the SAME held
     framework references
  3  reject republishes the restored value through those same references
  4  mixed structural/scalar publishes coherently — no transient half-state
  5  remove/re-add does not retarget a held entity reference
```

Plus a per-framework mutation proof that the native carrier actually reruns:
Angular signal dependency, Vue ref/reader, React `useSyncExternalStore`
snapshot + subscription, Solid effect/accessor.

This also fixes the uneven-adapter problem properly. Angular has 29 specs,
Vue 6, React 2, Solid 1; the answer is a concrete contract every adapter
passes, not bulk-creating framework tests or asking a future adapter author to
guess which of Angular's 29 matter.

```text
PROPOSAL-0 kernel matrix   DONE — null survives
        -> derive smallest public API
        -> shared proposal-realization contract
        -> Angular / Vue / React / Solid
        -> packed-consumer proof
        -> only then ship
```

#### PROPOSAL-REVIEW-SURFACE-0 — RUN 2026-09-22, PASSES

> Can an application truthfully review a proposal WITHOUT being given the
> kernel's internal identity?

**Yes.** `packages/kernel/src/enhancers/transactions/proposal-review-surface-0.spec.ts`,
3 cases. Not "can the kernel tell the subjects apart" — INSPECTION-0 case 6
settled that it can and must. This asked whether the classification RESULT has
to carry the identity that produced it.

Measured effect shapes, which is what made the answer cheap:

```text
                proposal effect        later effects
A  update       add rows.A  subj 1     set rows.A.name  subj 1
B  remove+add   add rows.A  subj 1     remove rows.A subj 1, add rows.A subj 2
```

`path` for an entity effect already carries the business key (`rows.A`, not
`rows`), so it locates the row precisely. The ONLY public difference between A
and B is `status`; the discriminator (`subject` 1 vs 2) stays internal.

Case C is the proof: **identical path, identical visible value, different
status** — and status alone drives a different reviewer action set
(`accept|reject` vs `accept|reject|reconcile`).

**BOUNDARY ESTABLISHED:**

```text
internal   subject identity determines truth
public     path communicates location
           status communicates proposal ownership / currentness
```

**`kind` NOT included.** The review UI rendered correctly without it, so it
fails the "make the scenario prove the UI needs it" bar. Available internally
is not a reason to publish.

**One honest constraint on the shape.** `status: 'current'` on a structural
add means _the proposal's structural contribution still stands_, NOT _the
proposed value stands_. In case A the row still exists because of the proposal
while its contents are the server's. The rendering is truthful only because
the review surface also reads current values — which applications do anyway,
and which the test does through an ordinary tree read rather than through
`inspect()`. A UI that displayed status without the current value could
mislead. Carry this into AGENT-UX-REFERENCE-0 as a documentation requirement.

#### PROPOSAL-0 — PUBLIC SURFACE FROZEN (C-double-prime), IMPLEMENTED 2026-09-22

Every clause is backed by a measurement. **Amended during implementation:** C'
carried `accept({ undoable: true })`, and building it proved that option could
not exist as composition. Deleted outright rather than left as a placeholder,
so the public surface got SMALLER than the frozen design.

```ts
const proposal = store.proposal(() => {
  // synchronous writes
});

proposal.inspect();
// { changes: [ { path: 'rows.A', status: 'superseded' } ] }

const settled = proposal.accept(); // confirm semantics; returns the settlement
proposal.reject(); // rollback; MAY THROW a refusal
```

Restoration stays orthogonal and compositional — `undoable()` wraps the
proposal's WRITES, never the acceptance:

```ts
let proposal!: Proposal;
undoable(() => {
  proposal = store.proposal(() => applyResult(result));
});
// ...human reviews for as long as needed...
proposal.accept(); // one undo unit
```

```text
DECISION                         EVIDENCE
accept NEVER enrolls, and takes  `undoable()` designates the causal turn
no option to                     containing its WRITES. A proposal's writes
                                 happen at proposal() time, so wrapping
                                 confirm() alone designates NOTHING — measured
                                 0 entries, against 1 for wrapping the
                                 proposal. An accept-time flag could only work
                                 by retroactively designating a turn, which is
                                 the new-authority-rule stop condition.
designation survives the gap     wrapping the proposal and confirming three
                                 ticks later still yields exactly one undo
                                 unit, so the compositional form serves a real
                                 review delay
no Option B sugar yet            `proposal(fn, { undoable: true })` would work,
                                 but the composition is short and no consumer
                                 has asked. No API by analogy.
accept returns a snapshot        closes the inspect->accept race; measured not
                                 obviously expensive at the tested sizes
reject keeps THROWING            a refusal that can be ignored is worse than
                                 one that cannot; PROPOSAL-REJECTION-0
inspect() not superseded()       INSPECTION-0 case 3 shows a binary named for
                                 supersession is already too coarse; a
                                 {path,status} list extends without breaking
{ path, status }, no identity    PROPOSAL-REVIEW-SURFACE-0 case C
no `kind`                        the review UI did not need it
current inspection in OSS        an application cannot build a truthful review
                                 screen if the data to render it is paywalled
double settlement inherited      accept/reject repeat idempotently, cross
                                 transitions throw, and a REFUSED reject leaves
                                 the proposal still acceptable because the
                                 refusal precedes the lifecycle move. No
                                 proposal-only rule.
```

**IMPLEMENTED.** `proposal-facade-0.spec.ts`, 20 cases, including
raw/facade equivalence: `proposal+accept` and `transaction+confirm` reach
byte-identical state, as do `proposal+reject` and `transaction+rollback`. The
adversarial matrix was run against the raw primitives BEFORE the facade
existed, which is what makes "naming, not new semantics" evidenced.

Shipping coverage done: five types on the root barrel, API-SUMMARY updated,
kernel README section, CHANGELOG entry, `api-baseline` regenerated (five types
x five barrels, zero removals), and the packed-consumer fixture extended AND
mutation-checked — breaking the proposal block fails under both bundler and
node16 resolution.

**Phase B needs no export-plumbing work.** `api-baseline` showed the types
already reach all four adapter barrels by facade re-export, and `proposal()`
rides on the tree. Phase B is realization conformance only.

#### WRITE-CONTEXT-0

Only after MO-2 disposition isolation. The existing constraint is **binding
until disproven**: externally supplied identity/delegation stays outside the
kernel.

**Explicitly rejected as a kernel-owned schema:**

```ts
{
  actorKind: 'human' | 'agent' | 'system';
} // the kernel does not own the
// world's actor taxonomy
```

Entra, Okta, AuthZEN, application sessions, agent frameworks and delegation
chains already model identity. SignalTree carries an opaque claim:

```ts
withWriteContext({ source: claim, operation: token }, () => { ... });
```

SignalTree may guarantee only _"this opaque token accompanied these
consequences."_ It may never assert _"this token proves Alice authorized GPT-9
to do X."_ That sentence is the line back into the closed thesis.

Naming — `source` vs `actor` — is deferred until MO-2 reports. Do not let the
public spelling presuppose the answer.

### Preregistration

```yaml
id: MULTI-WRITER-INTERACTION-0
status: OPEN — preregistered 2026-09-22
supersedes: nothing
reopens: nothing
does_not_reopen: STATE-CONSEQUENCE-VALUE-0 # CLOSED 2026-09-08, stays closed

question: >
  Can SignalTree provide correct live application behaviour when multiple
  writers — human, agent, server, automation — propose, commit, reject,
  supersede and reverse shared state, expressed as ordinary state primitives
  rather than as an evidentiary system?

null: >
  Proposal/review is a truthful naming of existing transaction semantics.
  No new kernel state semantics, no actor model, no retained provenance fact.

prohibited_changes:
  - no actor/identity taxonomy in the kernel
  - no provenance fields added to core mutation types
  - no reopening MO-1B same-path attempt capture
  - no derivedFrom for restoration consequences
  - no claim that carrying a token establishes authority
  - no reopening /authoring

ordering_principle: >
  Research ordering follows the cheapest available falsifier, not
  architectural layering. Settled findings are inputs, not experiments to
  repeat.

baseline:
  15.2.1: COMPLETE — published for kernel + 4 adapters, tagged v15.2.1
    2026-09-21, no packages/ commit since. Not work. Do not reopen.

do_not_re_derive: # answered 2026-09-08; re-running risks contradicting a
  # recorded result. An older roadmap section is NOT
  # permission to reopen these.
  - MO-1A # mutation identity survives deferred publication = B (sidecar
    #   keyed on (transactionOwner, transactionId, positionId));
    #   settled, NOT a prerequisite for PROPOSAL-0
  - MO-1B # same-path multi-scope attempt capture destroyed at capture by
    #   enqueueEffect keying; REQUIRED for correct rollback
  - MO-3A # rollback = B; restoration = D, no causal parent promised;
    #   derivedFrom stays illegitimate for restoration
  - 'SignalTree consumes claims, it does not mint them'

sequencing: # revised 2026-09-22, second pass — by falsifier cost
  - PROPOSAL-REJECTION-0 first — existential falsifier; no API naming until
    it reports PR-A, PR-B or PR-C (that track's own disposition scheme —
    NOT the A/B/C outcomes of this preregistration below)
  - if PR-B — STOP. PROPOSAL-0's null is falsified; re-scope the claim
  - if PR-A — fix transaction rejection generically, its own release, no
    proposal branding, before PROPOSAL-0 opens
  - if PR-A or PR-C — PROPOSAL-0 and MO-2 may then run INDEPENDENTLY
  - MO-2 disposition isolation — gates WRITE-CONTEXT-0 ONLY, never PROPOSAL-0
  - WRITE-CONTEXT-0 — only after MO-2
  - AGENT-UX-REFERENCE-0 — reference integration only; blocked on PROPOSAL-0

superseded_sequencing: >
  The first-pass order (MUTATION-OBSERVABILITY-0 -> PROPOSAL-0 ->
  WRITE-CONTEXT-0) is STALE and must not be restored. It rested on the premise
  that mutation identity must be proven to survive deferred publication before
  proposal work — already answered by MO-1A. Transaction identity and ambient
  write-context attribution are different questions; only the latter is open.

outcomes:
  A: >
    Null holds. Proposal/review ships as ordinary state primitives on the
    existing transaction substrate. No kernel change.
  B: >
    Null holds for the API but settlement disposition must become observable
    for the lifecycle to be describable truthfully. Derive the narrowest seam.
  C: >
    Multi-writer correctness requires a genuinely new kernel semantic fact.
    Reopen the kernel only for that demonstrated fact.
```

## PUBLIC-API-GRAMMAR-0 — CLOSED, rename set applied in 16.0.0

**Record recovered 2026-09-23.** The full inventory was produced on branch
`grammar-rename-unapproved` and never reached `main`: `TODO.md` was reverted to
run `CAPABILITY-SURFACE-0` and the section went with it. Distilled here rather
than merged — that branch is now thousands of lines behind and merging it would
restore stale state to recover a record.

**Ordering note, settled after this was written.** This section originally
declared itself blocking on the grounds that no new public callable should ship
until the grammar reported. `CAPABILITY-SURFACE-0` then established that
PLACEMENT decides names, so the grammar was applied to the surface actually
kept: enhancer capabilities remain tree methods.

### The rule

> **Public callable names describe what calling them does. Public types and
> returned handles describe what they are. Factories name what they construct.
> Qualifiers describe the writes inside their scope.**

```text
COMMAND     changes state, settles, or ends a lifetime        VERB
            transact() propose() confirm() rollback() accept() reject()
            undo() redo() destroy() dispose() addOne() updateOne()

QUERY       observes, locates or describes; mutates nothing   NOUN / PREDICATE
            byId() all() canUndo() inspect() retrieve()

FACTORY     constructs or configures a thing                  CONCEPT NAME
            signalTree() entityMap() transactions() restoration()
            batching() devTools() leaf()

QUALIFIER   classifies the writes inside its callback         ADJECTIVE / DOMAIN
            undoable() external()

EVENT       registers a subscription                          on<Thing>
            onTreeError()
```

The categories exist to stop the rule degrading into "every function must be a
verb", which would produce a worse API. `byId()` is not a defect; it is a
query, and queries read as what they return.

**`undoable()` and `external()` are the load-bearing proof that this is a
system rather than a preference.** They are not commands — they classify the
enclosed writes, and adjective naming is how they say so:

```text
undoable(() => ...)     these writes are undoable
external(() => ...)     these writes are external truth
transact(() => ...)     transact these writes
propose(() => ...)      propose these writes
```

**Not Redux actions.** A method here is an action in the ordinary English
sense: calling it does something. No `Action` type, no dispatch, no serialized
command object, no reducer. Recorded because the word invites that misreading.

### The factory/operation pair is deliberate

```text
transactions()   plural noun, FACTORY   installs the capability
transact()       verb, COMMAND          performs the operation
```

### Adapters own almost no vocabulary

Everything else arrives by `export * from '@signal-tree/kernel'`. Angular adds
`defineStore()` (factory) and `toWritableSignal()` (query); React adds
`useSignalTree()`; Vue and Solid own nothing. **Consequence: the 16.0.0 blast
radius is almost entirely kernel** — the rename touched four packages'
re-exports and docs, not four packages' APIs.

### Final disposition of the rename set

```text
APPLIED   transaction() -> transact()   COMMAND named as a noun. Shipped in
                                        15.2.1, removed outright under the
                                        recorded one-time 16.0.0 reset.
APPLIED   proposal()    -> propose()    Same defect, never shipped.

REJECTED  empty -> isEmpty()            The audit called this "the worst single
                                        pairing". Use-site inspection refuted
                                        it: `empty` is not a method but a
                                        readonly reactive signal PROPERTY, in a
                                        block the source labels "Queries
                                        (readonly properties returning
                                        signals)" beside all/count/ids/asMap,
                                        with a documented v10.3 decision
                                        aligning bare-boolean accessors across
                                        status/form/asyncSource. It and
                                        `clear()` are not the same kind of
                                        callable.

KEPT      settled()                     Every use site is `await x.settled()`,
                                        which supplies the temporal reading.
                                        The boolean `settled()` that would have
                                        created a collision is on `status()`,
                                        which is not exported.
KEPT      tap()                         Takes a BAG of observers
                                        (onAdd/onUpdate/onRemove/onChange) and
                                        returns an unsubscribe; the `on` is
                                        already inside the payload, so forcing
                                        the method into `on<Thing>` would be
                                        wrong for a multi-handler registration.
KEPT      intercept()                   `InterceptContext` exposes `block()`
                                        and `transform()` applied synchronously
                                        — an operation, not a subscription.
KEPT      exportDebugSession()          Accurate; query-vs-command creates no
                                        naming defect.
```

Full reasoning: `docs/research/public-api-grammar-0-dispositions.md`.

### The proposed `api-grammar.yaml` is SUPERSEDED

This section proposed a hand-maintained `tools/api-grammar.yaml`, one row per
public callable, so the gate could ask "is every public callable deliberately
classified?" rather than parse English.

That question was right and the mechanism was replaced by something stronger:
**`tools/api-callable-baseline.json`, GENERATED from emitted `.d.ts` via the
TypeScript compiler API.** A hand-maintained inventory records what someone
remembered to add; a generated one cannot miss a member. It captures owner,
member kind and normalized signatures across functions, methods, callable
properties, callable types and constructable classes — 240 entries, 13/13
mutation-proven.

What it does NOT carry is the `category` field. Classification remains prose
here. If a future audit wants the category checkable, add it to the generated
baseline rather than reviving a parallel hand-maintained file.

## RETIRED-SUBJECT-SLOPE-STABILITY-0 — CLOSED 2026-09-23

**CLOSED — gross-retention gate validated on Linux.** The unreliable slope gate
was refuted and replaced by an absolute retained-heap ceiling, renamed
`retired-lifetime-gross-retention`, and validated on the release environment
(run `35886271808`, head SHA `f8f81505`, ubuntu-latest linux/x64: control
3.23-3.24 MB over 30 processes, retain=10000 mutation 82.75-82.76 MB over 10,
a 79.51 MB gap with no overlap). Full record:
[`docs/research/retired-subject-slope-stability-0.md`](docs/research/retired-subject-slope-stability-0.md).

The original finding, kept because it is the evidence:

**A release gate was unreliable on unmodified code.** Found while
clearing PROPOSAL-INSPECTION-0; the inspection work is exonerated and this is
pre-existing.

**Measured on clean `833e986e`, no working-tree changes**, sampling the gate's
own bench directly (`tools/bench-entity-churn-retention.mjs`, arm
`no-history-reads`):

```text
150 rounds, 12 samples
  3.23  3.24  3.23  15.22  15.22  15.22  15.22  3.23  15.22  3.24  3.23  3.23
  -> BIMODAL: 3.23 MB x7, 15.22 MB x5   (~42% in the high mode)

50 rounds, 10 samples
  4.1  4.1  8.1  4.1  2.1  4.11  4.1  8.1  4.1  4.1
  -> dominated by 4.1 MB
```

**Why the gate flips.** `check-retired-subject-slope.mjs` takes the MEDIAN OF
THREE isolated processes per endpoint (`SAMPLES_PER_POINT = 3`) against a
20 B/retired ceiling. Median-of-3 corrects one outlier in a unimodal
distribution — which is what its header claims it is for — but this
distribution is bimodal with roughly balanced modes, so the median simply
reports whichever mode drew two of three samples.

```text
150-arm median 15.22, 50-arm median 4.1   -> ~116 B/retired  FAIL
150-arm median  3.23                      -> negative growth PASS
```

With the high mode at ~42%, P(>=2 of 3 high) is about **38%**. So the gate
fails roughly two runs in five **on unmodified code**.

**Consequence that must not be softened.** A gate whose noise crosses its own
threshold provides no evidence, in either direction. Today's two 81/81
clearances were favourable draws on this gate, not demonstrations — the other
80 gates cleared those commits, this one did not contribute. Its `:self`
companion still passes, which is the trap: proving a checker can reject a
synthetic bad table says nothing about whether its input is stable enough to
classify.

**DO NOT raise the tolerance.** The header already warns the gate regressed
once when a step re-interned a forgotten subject by id; widening the ceiling
would delete exactly that detection. Prove a stable measurement first.

**The 12 MB gap is a lead, not noise.** 3.23 vs 15.22 MB is discrete and
clean, which suggests a bistable condition — a collection that either has or
has not run before the measurement, or a lazily allocated structure — rather
than scatter. Characterise the cause before touching sampling or thresholds;
raising `SAMPLES_PER_POINT` would only make the coin flip more expensive.

**Not blocking** the proposal track: the instability is in retention
measurement, unrelated to transaction classification, and reproduces without
any of that work present.

## DX-ROADMAP-0 — opened 2026-09-22

**A separate track. Ships no kernel, and is NOT scope inside `PROPOSAL-0`.**
Opened from a developer-experience audit of the shipped 15.2.1 surface. The
audit's recommendations are carried forward here; its numbers are not.

### What this audit is, and is not, evidence for

The audit scored seventeen areas to one decimal. **Those ratings are not
project facts and must not be cited as measurements.** Every one was derived
from reading the public API and the documentation — which is a review of the
DESIGN, not an observation of the EXPERIENCE. No external developer was
watched using SignalTree, and the file says so itself.

```text
EVIDENCE        the named findings below, each checkable against this repo
NOT EVIDENCE    "DX is 7.5/10", and every other score in that document
```

Recorded because this is the same failure the repository already guards
against elsewhere: a green-looking signal standing in for the thing it cannot
measure. The way to make a DX claim real is `## 32. Real external consumer
test`, not a re-scoring pass.

### The positioning claim — adopted

> SignalTree does not compete on **fewest concepts required to store a
> boolean**. It competes on **fewest concepts required to manage a complicated
> application correctly.**

This is the frame the architecture already implies, and it decides arguments
that otherwise recur forever. A comparison against a minimal store that counts
lines-to-first-write is measuring the contest SignalTree is not entering. It
also sets the bar for this track: the goal is to make existing correctness
DISCOVERABLE, not to shorten the shortest path.

Consistent with, and downstream of, `## PRODUCT DIRECTION` — _application
state that can explain itself_.

### Finding 1 — lifecycle ownership is uneven across adapters

Not the vague "`destroy()` is a footgun" complaint. `destroy()` is correct: a
live tree owns runtime resources. The gap is that **one** adapter owns it.

Checked against the implementations, not against the export lists — exporting
a hook does not prove the hook owns teardown, and the first draft of this
finding inferred exactly that about React.

```text
Angular  VERIFIED     defineStore() calls tree.destroy() from
                      inject(DestroyRef).onDestroy(), so component-provided
                      stores dispose with the component and root stores with
                      the app — packages/angular/src/lib/define-store.ts:164

React    MEASURED     useSignalTree() does NOT own teardown. It is an
                      observation hook over useSyncExternalStore: it takes an
                      already-created tree as `owner` and never calls
                      destroy() — packages/react/src/use-signal-tree.ts

Vue      NOT FOUND    no lifecycle-owning public helper; whether normal usage
                      can own destroy() is UNINVESTIGATED

Solid    NOT FOUND    same
```

`.destroy()` appears in no adapter source outside Angular's `DestroyRef`
callback. That is a measurement over the three adapter `src` trees, and it is
what turns "no obvious helper" into "no helper".

And the first-hour document teaches the manual path on the framework that
already owns it: `docs/why-signaltree.md` imports from `@signal-tree/angular`
and ends its "whole everyday surface" example with a bare `store.destroy()`.

### Finding 2 — the docs are becoming reliable; the repository is still large

Both halves are true and they are not in tension, because they describe
different sets.

```text
GATED      33 examples across 25 live documents typecheck against the API they
           teach — tools/check-documented-examples.mjs, exit 0, 2026-09-22.
           LIVE_DOCS is 12 entries.
UNGATED    docs/architecture/**, docs/research/**, docs/audits/**, ADSP, RFCs —
           by design. They record what was true at a point in time.
```

So "documentation is reliable" is a statement about the paved road, and
"documentation is overwhelming" is a statement about everything else. **The fix
is not deleting the engineering record.** It is making the public path small
enough that a newcomer never walks into the record by accident.

### Finding 3 — the proposal-vocabulary objection, and how it resolved

The audit challenged whether `proposal()` was a sixth vocabulary family over
machinery that already had one. Half of that survived contact with the
implementation, and the disposition lives in `PROPOSAL-0` above, not here:

```text
optimistic operation, no reviewer   transaction / confirm / rollback
reviewed operation                  proposal / inspect / accept / reject
```

`accept`/`reject` do duplicate `confirm`/`rollback`. `inspect()` does not
duplicate anything, and database-flavoured "transaction" is the wrong register
for a human-review workflow. The guardrail that keeps this from decaying into
two half-APIs is already recorded and already has a detector:

```text
Proposal must never gain a BEHAVIOUR PendingTransaction lacks
PendingTransaction must never gain inspect()
```

If either stops holding, the split reopens.

### STALE in the audit — do not carry forward

Its sketch of the proposal API included `p.accept({ undoable: true })`. That
option was **falsified during implementation**: `undoable()` designates the
causal turn containing its WRITES, a proposal's writes happen at `proposal()`
time, and an accept-time flag could only work by retroactively designating a
settled turn. See the C-double-prime decision table.

### The work

Ordered by how much of the newcomer path each item repairs, not by size.

```text
1  ONE canonical "build a real feature" tutorial
   Not API reference. One feature, end to end, in this order:
     scalar state -> entities -> external/server update ->
     optimistic transaction -> rollback -> undo
   It is the artifact the paved road points at. Everything else in the
   public path either leads to it or follows from it.

2  Goal-based recipe index, addressed by what the developer wants to DO
     edit a field                     manage records
     save optimistically              undo a user action
     apply server truth               sync with an endpoint
     handle a rollback refusal        review a proposed change
     tear down a store
   Indexed by goal, never by enhancer name. A developer who does not yet
   know that undo lives in restoration() cannot search for restoration().

3  Lifecycle ownership audit — Finding 1
     Angular   DOCUMENT the ownership defineStore() already has. Verified,
               so this item is writing, not investigation.
     React     DECIDE and state it: either a tree scoped to a component's
               lifetime gets an owning hook, or React usage is expected to
               create trees outside the component tree. useSignalTree()
               observes; it does not own, and the README does not say so.
     Vue       determine whether normal usage can own destroy(); if it can,
               ship the helper; if it cannot, say so loudly
     Solid     same
     docs      stop teaching bare destroy() in the first-hour document on a
               framework that owns it
   Deliverable is a per-adapter answer to one question: in ordinary usage,
   does the developer have to remember anything?

4  Finish the shared framework conformance contract
   Already required by PROPOSAL-0 Phase B. Listed here too because it is
   what makes "supported" mean something to a USER, independently of how
   many specs each adapter happens to carry (Angular 29, Vue 6, React 2,
   Solid 1). One contract every adapter passes.

5  Studio UX organised around questions, not architecture
     "Why is this value this?"        "What changed it?"
     "What would undo affect?"        "What was superseded?"
   `## PRODUCT DIRECTION` -> "Studio scope — brutally narrow" already frames
   the first question exactly this way; this item extends the same treatment
   to the other three. CONSTRAINT: each question must be answerable from
   facts the kernel already has. If one is not, that is a finding to record
   here — never a licence to add a kernel fact for a UI.

6  Freeze the public API
   After PROPOSAL-0 ships: no new public primitive until items 1-3 exist and
   a real external consumer has used them (`## 32. Real external consumer
   test`). The versioning policy is now good; the REPUTATION is not, and
   only boring compatibility repairs that.
```

### The stop condition this track exists to enforce

> **Do not answer an awkwardness with another primitive.**

The kernel has enough. The next DX gains come from recipes, discovery,
framework conformance, visual debugging and fewer decisions in the first-use
flow — not from more kernel concepts, more enhancer types, more public
metadata, more lifecycle statuses or more knobs. SignalTree's hidden
correctness (a held entity reference that does not retarget, an undo that
refuses rather than destroying newer truth, a rollback that will not
half-reverse) is ALREADY a DX advantage. It is just not discoverable yet, and
discoverability is a documentation and tooling problem.

### Relationship to the other open tracks

```text
PROPOSAL-0                       finish facade lifecycle, Phase B, ship
DX-ROADMAP-0                     post-Proposal; ships no kernel
RETIRED-SUBJECT-SLOPE-STABILITY-0  independent release-infrastructure repair
```

None of the three gates another.

## PRODUCT DIRECTION — set 2026-09-08

```text
SIGNALTREE 15          free/open state substrate
        |
STUDIO                 causal debugging / explanation   <- NEXT WEDGE
        |
RELAY                  only if distributed semantics prove independently valuable
```

**Studio serves adoption; it is not a separate product.** SignalTree adoption
is the goal, Studio is the means (spec §20.1) — it ships free, and no pricing
or team-service work starts while that is true.

**Not in parallel, but not a waterfall either.** Studio leads because the
adoption blocker it targets — a newcomer cannot explain why a value is what it
is — is upstream of docs and case studies: examples of a model people cannot
debug do not convert. Studio is built in slices (spec §8.5), and TRACK A work
folds in behind each slice that earns a GROW, using what that slice made
explicable.

```text
TRACK A  adoption      docs, examples, migration, real production users,
                       framework adapters, case studies
TRACK B  Studio         causal inspector, built in slices; each slice gated
                       on the STUDIO-VALUE-0 onboarding measure
```

Explicitly NOT building: provenance package, Audit, Verified Audit,
`/authoring` reopening, full Relay cloud.

The product statement is no longer "SignalTree manages state better", and
emphatically not "SignalTree proves what AI did". It is:

> **SignalTree is application state that can explain itself.**

Kernel gives the semantics. Studio explains them. Relay, if it earns its place,
preserves them across machines.

### Studio scope — brutally narrow

```text
Select a value -> WHY IS THIS VALUE HERE? -> originating operation, causal turn,
affected paths, authored vs external/restoration, transaction boundary, net
committed consequence, later overwrites, current causal chain
```

Not an observability suite, not AI governance, not an audit portal, not Merkle
proofs. Those were the distraction the provenance track already cost us.

### Three constraints Studio inherits — established, not speculative

**1. Restoration has NO causal parent, deliberately.** `ATTRIBUTION-OWNER-0`
MO-3A proved `RestorationHistoryEntry<T>` is `{ state: T }` and an undo carries
`origin: 'restoration'` with no turn id. So a Studio "why is this value here"
chain **cannot show restoration lineage**. It may say _"restored to a prior
recorded state"_; it may not say _"this reverts T81"_. The chain has a
documented hole exactly where undo/redo appears — design the UI around that
truthfully rather than discovering it mid-build.

**2. Studio inherits `MUTATION-OBSERVABILITY-0`.** Studio must observe
everything, and observation is composition-dependent: `PathNotifier` misses
direct leaf writes, `interceptLeafSignals` misses transacting trees and is
documented as missing array-valued leaves and writes past `maxDepth`. Cloud
infrastructure burden is low; **the observation-seam dependency is real** and is
the same open question the provenance spike hit.

**3. Studio has no action narrative to fall back on.** SignalTree has no
actions; causality here is structural, not narrated. Studio is therefore
plausibly **worse** at naive "what happened" and must earn its case on what
actually changed and what survived — the atomic net consequence, the
participation parcel, and the surviving responsibility of a partially
superseded consequence. Designing toward a narrative timeline would chase a
model SignalTree does not have.

## STUDIO-VALUE-0

**STATUS: OPEN — runs per slice, from S2 onward.**

**The measure is onboarding cost, because adoption is the goal:**

> Does a developer who does not know SignalTree reach a correct explanation of
> the frozen Cart 88213 incident faster WITH Studio than with SignalTree and
> no Studio?

Not against another framework's tooling, and not against an absolute bar.
Those are the right questions for something being priced; Studio ships free to
make the substrate adoptable. The control is what a developer adopting
SignalTree gets today: `devTools()`, `exportDebugSession()`, `audit`
metadata, logs, OTel, a debugger.

**"It helps adoption" is nearly unfalsifiable**, and this repo has closed two
investigations to stop exactly that reasoning. So the measure is a time,
against a control condition, on a fixed incident, with a real newcomer — and
the trap questions still count against the result.

> Can SignalTree causal state plus a minimal inspector explain an unfamiliar
> production-state bug **correctly, cheaply, and honestly** — including
> admitting what it cannot know?

Studio is scored against the frozen Cart 88213 incident and its eight
questions — measured against **the best alternative buildable on SignalTree
without Studio**: the currently shipped `devTools()` / `DevToolsDebugSession` surface plus ordinary
debugger/logging tools a developer already has for free. A standalone
`exportDebugSession()` export is not present; the evaluation kit records the verified baseline. Not against
another framework's tooling, which would anchor Studio's design to a model it
deliberately does not share.

**The moat rule (spec §22.5):** every load-bearing capability must rest on a
fact unreachable without the Phase 0 seam. Anything the shipped API already
gives away is a convenience feature — it may ship, but it cannot count toward
differentiation or justify pricing. If nothing load-bearing needs the seam,
the seam is not worth building and Studio is a free tool.

Fixture, questions and scoring:
[`docs/research/studio-value-0/README.md`](docs/research/studio-value-0/README.md)
Bar, budget and binding outcomes: spec §20.

```text
GROW   materially cuts a newcomer's time-to-correct-explanation vs no-Studio,
       with honest UNKNOWNs and honest composition refusals
                                              -> build the next slice
HOLD   no material delta on this slice's semantics
                                              -> stop; diagnose before
                                                 spending on the next slice
STOP   wrong explanation, a knowledge claim on Q4/Q7, or a silent partial
       answer on an unsupported composition   -> making adoption worse;
                                                 fix or abandon
```

**Two questions must be failed honestly.** Q4 (which intermediate writes did
not survive) is unanswerable — transactions coalesce same-location writes to
the net effect by design (MO-1B). Q7 (what restoration can tell us) has no
causal parent to report (MO-3A). Claiming knowledge on either counts AGAINST
the result.

**If Studio does not clear the bar, stop that too.**

**Built in slices, each one end to end.** The seam is committed but not a
single delivery — it grows one composition at a time (S1 transactions, S2
realization, S3 restoration, S4 the full matrix), and each slice ships seam +
causal core + a usable surface together.

**The growth discipline that keeps this honest:** every slice declares its
supported composition set and _refuses_ outside it. Studio says "I do not
observe this composition" rather than rendering a confident partial answer.
Growing observation slice-by-slice without that rule is precisely how
MUTATION-OBSERVABILITY-0 happened — PathNotifier and interceptLeafSignals were
each correct for the cases their author had in mind. The matrix widens; the
guessing does not. A silent partial answer is a STOP, not a rough edge: a
newcomer who trusts a confident wrong answer is worse off than one who got
nothing.

**A HOLD costs one slice, not the roadmap.** The next slice is built only after
the previous one returned GROW. Everything past the current slice is a
hypothesis about where confusion lives.

Status: backend fixture built and verified; seam S1 not started (first build
item); onboarding measure runs from S2.

## RELAY — separate thesis, argued on its own

Possibly the largest revenue ceiling, but audit/provenance may **no longer form
any part of the argument**. Relay earns itself only on distributed
application-state semantics: offline/reconnect, server realization, multi-client
coherence, cross-runtime state, reconciliation, semantic continuity across
machines.

> Does SignalTree preserve useful state semantics across runtime boundaries that
> a good sync system makes developers rebuild manually?

Needs its own adversarial landscape and control test against serious systems —
**not "WebSockets are hard".** If it wins, build it. If not, SignalTree is still
a very good state engine plus Studio.

## STATE-CONSEQUENCE-VALUE-0 — CLOSED 2026-09-08

**OUTCOME: DIFFERENTIATION NOT EARNED.**

```text
The strong conventional control reconstructed the consequential
application-state incident with high confidence using ordinary identity,
authorization, tracing, backend audit and client correlation.

SignalTree may make some relationships intrinsic rather than assembled, but
the experiment did not establish a capability gap large enough to justify a
provenance/audit product or any kernel / public-surface expansion.
```

### Evidence

Two blind investigations, same ten questions, investigator given no knowledge of
SignalTree or that anything was being compared.

```text
                        v1 (weak fixture)   v2 (repaired)
total joins                     31               43
ID-based                     9 (29%)         34 (79%)
inferential                     22                6
answered high-confidence      5/10             8/10
```

- **Q7 solved by ordinary instrumentation** — `serverRevision → appliedRevision`
  propagation resolved eight values by ID join. Timestamp guesswork in v1.
- **Q9 solved cleanly by `captureId`** — "was this restoration a fresh action?"
  answered by ID join alone.
- **Q6's residual gap is one explicit disposition field.**
- **Q8's residual gap is propagating the same revision/source id to browser B.**
- **Q3/Q4 gaps are agent prompt capture and policy text** — not state semantics.

That moves the claim from _"the conventional stack fundamentally lacks the
semantic model"_ to _"the conventional stack needs disciplined instrumentation
and some correlation work."_ Those are commercially very different claims, and
only the first was a business.

The preregistered rubric anticipated exactly this: ordinary instrumentation plus
cheap ID joins plus modest extra fields → **weak white space**.

### v3 was declined deliberately

Adding the browser-B revision stamp would probably turn Q8 green. Running v3
after knowing that would be testing whether we can construct a conventional
stack _badly enough_ for SignalTree to win. **That is not an experiment.**

### The explicit non-claim

> This does **not** show SignalTree's causal/state semantics have no value. It
> shows that **agent/application-state provenance is not presently justified as
> a differentiated commercial product.**

### What this saved

Months of Relay + provenance + agent-identity integration + Audit + Verified
Audit, built around a moat a competently instrumented enterprise stack
reproduces with IDs and logs. **A successful falsifier is worth what it prevents.**

### Surviving engineering findings — these are permanent

The business thesis failed. The architectural constraints did not:

```text
externally supplied identity/delegation stays OUTSIDE the kernel
transaction state consequence is NET EFFECT, not an audit of every attempt
same-location transactional coalescing is deliberate and correct
rollback already carries meaningful transaction correlation
restoration is deliberately state-based — never fake an originating actor
distributed causal correlation belongs to the transport/request context
(owner, transactionId) matters — transaction id alone is UNSAFE
observation channels have composition-dependent behaviour
```

### Spike disposition

`packages/kernel/src/lib/internals/provenance-spike.ts` stays **experiment
archaeology**. Do not turn it into product code. Once the surviving findings
above have permanent carriers, evaluate it under the ordinary consolidation
rule:

```text
the finding survives; the experiment implementation need not
```

**No `/authoring` resurrection. No settlement-outcome API because provenance
wanted one. No provenance package.**

### Redirect

Commercialization effort returns to areas with stronger evidence: the core state
architecture, causal debugging / Studio, and potentially Relay — where
distributed state _semantics themselves_, not audit metadata, would be the
differentiation.

---

**Original preregistration, retained:**

**OPEN — THE COMMERCIAL FALSIFIER. Supersedes `ATTRIBUTION-PULL-0` as the gate.**

Not "does anyone want provenance" — that is settled and largely commoditized.
The unresolved question is whether SignalTree's contribution is **distinct**:

> Does application-state consequence provenance add material explanatory and
> evidentiary value beyond a strong conventional stack?

### Control arm must be strong, not a strawman

The experiment is worthless against a naive comparison. The control is a
competent 2026 stack:

```text
CONTROL                              CANDIDATE
agent IAM / identity                 the same stack
+ delegated authorization / OBO      + SignalTree state-consequence provenance
+ OpenTelemetry agent & tool tracing
+ backend audit / event history
+ ordinary client state
```

Run both against the same incident — the `$375,000 Exception` is already
scripted for it.

### The questions both arms must answer

```text
Why is this application field this value now?
Who intentionally initiated the consequential operation?
Was the agent acting for someone?
What authorization permitted it?
Which state effects actually committed?
Which were rolled back?
What did the backend subsequently establish as truth?
Did another client author the resulting value, or merely realize it?
Did a later restoration represent a new human action?
Can all of that be connected without manually stitching four telemetry systems?
```

### Measured

```text
time to correct explanation
manual cross-system joins required
missing causal edges
wrong actor attribution
authored vs realized distinction preserved
committed vs rolled-back effects distinguished
ability to explain the current state value
later realizations/restorations traced without actor inheritance
application-specific instrumentation required
```

### Core falsifier

> If competent investigators reconstruct the same state-causal explanation from
> the control stack with comparable correctness, effort, and bespoke
> correlation, **SignalTree has not established differentiated value** and
> provenance returns to parked.

Harness design: [`docs/research/state-consequence-value-0/`](docs/research/state-consequence-value-0/README.md)

### The control must be built to win

A control arm built to lose proves nothing. **Whoever builds it is trying to make
it answer every question**, and if it succeeds that is a valuable result — it
means SignalTree should not build this and we saved the cost.

**Blocked:** nobody on this side can provision real Entra/Okta, and a SignalTree
author must not build the control arm alone. Either reproduce real OBO/OTel
artifact structure from published specification, or recruit someone who runs
that stack. Fidelity rule: every control artifact is generated to a published
spec, never invented; a disputed span field is resolved by the OTel
semantic-convention document, not by our judgement.

### Notes

The white-space claim behind this experiment — that no general-purpose layer
organizes evidence around the resulting application-state consequence — rests on
absence from a broad search, which is not a defensible universal negative. This
experiment exists precisely to test it rather than assume it.

Depends on `ATTRIBUTION-OWNER-0` for the candidate arm.
[`docs/research/attribution-pull-0/frames.html`](docs/research/attribution-pull-0/frames.html)
supplies the narrative shell for the SignalTree side.

## ENTITY-PHYSICAL-DENSITY-0 — CLOSED

The architecture-selection investigation is closed at `14302192`. Do not reopen
Map/object/slot/pool variants because 487 B/entity looks unattractive. Reopen
only with a materially new ownership or access hypothesis that represents a
currently repeated fact once per collection or derives it implicitly from an
existing authority. Any new candidate must beat the incumbent on retained bytes
without regressing point latency, lifecycle, identity, restoration, churn, or
GC.

Optimize representation under frozen semantics. ER-A membership, public API,
stable SubjectId behavior, held-reference correctness, rekey/remove/reactivation,
ordering, restoration, causal behavior, owner invalidation, and O(1) point
operations do not reopen. **Unify allocation, not authority:** StructuralStore
continues to own key, identity/lifetime, revision, and membership; EntityValueStore
continues to own value even if both address fields in one physical record.

1. **E0 — byte attribution.** Measure fixed and marginal retained bytes at
   0/1k/10k/100k for key-to-subject, lifetime, revision, active-by-key,
   active-by-subject, ordering, value storage, and fixed collection machinery.
   Explain at least 90-95% of the current marginal physical bytes before changing
   production representation.
2. **E1 — record consolidation prototype.** Compare the current stores with
   `key -> SubjectId` plus `SubjectId -> SubjectRecord`. Both active-node indexes
   must prove an independent algorithmic job. Preserve authority boundaries;
   no unowned mutable record bag.
3. **E2 — active/retired compaction.** Derive minimum facts for active,
   retired-unclaimed, retired-claimed, and held subjects under no restoration,
   bounded restoration, rekey history, and fresh occupation of an old key.
4. **E3 — segmented subject storage.** Compare consolidated numeric-key Map
   storage with monotonic-ID segments/slabs. No SubjectId reuse or generational
   identity change in this row; reclaim only whole segments proven disposable.
5. **E4 — ENTITY-REALIZATION-RETENTION-0.** Independently attribute the
   untouched -> realize-all -> release-all -> forced-GC residual. Canonical truth
   stays strong; unheld facades/cells/publication resources should be reclaimable
   where semantics permit; held facades remain durable and truthful.
6. **E5 — featured-memory decomposition.** Measure raw, batching, transactions,
   restoration-unused, restoration-designated at bounded history sizes,
   observation, realization, and combinations. Separate fixed/tree,
   live-subject, participating-subject, realized-subject, retained-turn, and
   history-entry slopes.
7. **SUBJECT-RECORD-PROMOTION-0.** Compare the E1/E2 consolidated
   `Map<SubjectId, SubjectRecord>` candidate with the split-authority incumbent
   and a normalized SubjectId-to-stable-slot rival. Run independently
   attributable stages: value plus structural revision colocation;
   `activeNodesBySubject` parity and removal; common-active lifecycle
   compression; then an independent decision on `activeNodesByKey`. Physical
   colocation does not transfer mutation authority: StructuralStore continues
   to own key, revision, lifecycle, membership, and ordering; EntityValueStore
   continues to own value. Prove shared reachability is equivalent before
   colocating facts with potentially different lifetimes. Do not fold
   restoration claims or realization cells into this row, and do not report a
   winning representation as architecturally necessary.

Every candidate runs add/update/replace/remove/reactivate/fresh-key-occupant/
rekey/order/held-GC/released-GC/undo-redo/rollback/external-ingress/
owner-invalidation controls. A semantic failure rejects the representation; it
does not reopen the law. This work is independent and does not block React or
root retirement absent a genuine package-boundary or semantic falsifier.

We do not write RFCs for our own work — we make the change. An RFC is what an
outside contributor writes to propose something, and `docs/rfcs/` is the archive
of decisions already taken, kept for the options that were REJECTED and why. If
you are about to create `docs/rfcs/00NN-my-idea.md` for something we decided
internally, put it here instead and go do it.

**Target release: 14.1.1, and it is a clean break.** Breaking changes are explicitly
acceptable on anything — decided 2026-08-10. Two consequences that change how items
below are written:

1. **Prefer deletion to deprecation.** A wrong API kept for one release cycle is a
   wrong API that gets copied into someone's codebase for one release cycle. Nothing
   here needs a `@deprecated` window.
2. **What still gates work is KNOWLEDGE, not compatibility.** The only reason to hold
   an item now is that we do not yet know the right shape — never that removing it
   would break someone. See the sequencing note at the end of item 2.

---

# RELEASE SCOPE — 14.1.1 is SCOPE A ONLY

**Decided 2026-08-11.** Two bodies of work have been running in one conversation and
they are at opposite ends. This section is the boundary; when in doubt about whether
something belongs in 14.1.1, it is the authority.

|                                |                                                                                               |
| ------------------------------ | --------------------------------------------------------------------------------------------- |
| **Scope A — the audit**        | retractions, naming, the defects found while auditing, gates. **~85% done. Ships as 14.1.1.** |
| **Scope B — the architecture** | position-attributed transactional history. **Not started.** 16.0.0+                           |

Why cut now rather than hold: holding a release for an unstarted six-phase build is the
14.0.0 mistake inverted. 14.0.0 shipped too early _while the audit was still producing
findings_; holding 14.1.1 for work that has not begun is the same error at the other
end. 6a is live data-loss in shipped 14.0.0 and its doc fix is done — users benefit now
rather than after Phase 6.

## IN 14.1.1

Everything already committed, plus:

- **`batchUpdate` deletion** — with the demo benchmark **re-run and compared**, not a
  green build. It is called behind a `typeof … === 'function'` guard with a silent
  fallback, so removal leaves the benchmark measuring a different path.
- **entityMap renames** — `byIdOrFail()`, `map()`.
- **`batch` vs `coalesce` documentation** — the mid-callback contract is undocumented on
  both sides.
- **6d input validation** — `maxHistorySize ≤ 1` silently disables undo. Cheap,
  contained, and a footgun. Needs an ST code.
- **Item 7** — parity framing removal.
- **Item 1c** — the `changeId` held-node diagnostic.
- **Capability matrix** (item 8) and **RFC 0008** (item 9).

## OUT of 14.1.1 — do not let these leak in

- **Everything in the architecture plan.** Turns, transactions, ownership positions,
  containment, the turn store, position indexes.
- **The `capacity` removal.** It is breaking and it belongs _with_ the turn store, not
  before it. Removing it early strands adopters twice.
- **6a's code fix.** It is gated on the representation decision; the doc fix has shipped.
  > **Boundary crossed (2026-08-11, audit note):** the working tree later landed the
  > form-notifier fix that makes global `restoration()` record direct `form()` writes,
  > and `docs/guides/time-travel-in-production.md` §2b, `packages/core/README.md` and
  > the 2026-08 audits were rewritten to say 6a is fixed. This contradicts the
  > "OUT of 14.1.1 — do not let these leak in" decision above. Noted here because the
  > boundary was recorded, not because the fix is wrong — it is verified working and
  > fully green. Open for the boundary decision; nothing reverted.
- **The MST / Yjs audit.** It blocks public uniqueness claims, not the release.

Mixing Scope B into this release makes it un-reviewable. That is the whole point of the
boundary.

## BLOCKS the cut

- **Tests for 6a–6d.** Six spec files exist under `enhancers/time-travel/`, and none
  pins the four documented defects. `tools/verify-history-defects.mjs` is a **provenance
  tool with deliberately inverted exit codes** — it goes red when a defect is FIXED — so
  it is not coverage. Documenting a data-loss defect with nothing that fails when it
  silently changes is exactly how the retracted claim survived on four surfaces.
- All gates green, tests green, changelog finalised, versions bumped.

## After the cut

Phase 0A and 0B from
[history-priority-hierarchy.md](docs/architecture/history-priority-hierarchy.md).
Both are small, both are falsifiable, and either can send the design back — which is why
they come before any of Scope B's implementation.

---

# PUBLISH-READY ROADMAP

This is the master checklist for "SignalTree is actually done and publish-ready",
not merely "the kernel architecture is complete". The first 3-4 items finish the
engineering redesign. Everything after that is what turns the repo into a library
that strangers can safely `npm install`.

## 1. Finish the last kernel architecture work — **SUPERSEDED. GATE A is SATISFIED.**

**Everything in this section is done.** The kernel was frozen at `4f7a2169`:
seven defects found and closed across three antagonistic audits plus one
verification, the defect curve running 3 -> 2 -> 1 -> 1 with the final one in a
caller rather than in the redesigned authority. The persistence invariants this
section was reaching for are now frozen in `RELEASE-1.0.md`, in a stronger form
than stated here — notably that the durability authority is tree-scoped and that
commit-ness is never inferred from the call stack.

Retained below as a record of what the freeze had to prove, NOT as open work.
The closing line "Freeze the kernel architecture once this passes" is what made
this file read as though the kernel were still open, months after it was not.

- Finish `stored()` / persistence consequence ordering.
- failed PREPARE -> zero persistence writes
- atomic multi-field/frame commit -> persistence sees only final coherent state
- undo/redo/rollback/realization persistence semantics pinned
- persistence failure semantics documented
- Add the final heterogeneous atomicity proof.
- scalar + structural change in same frame
- failure before commit leaves everything neutral
- success advances one physical revision
- PROJECT/PUBLISH/persistence happen only after coherent commit
- Run a fresh antagonistic audit of current HEAD.
- Revalidate old findings rather than trusting historical issue labels.
- Fix every remaining correctness violation.
- Fix every remaining accidental O(n) hot-path violation.
- Freeze the kernel architecture once this passes.

Exit condition: no known correctness redesign or semantic blocker remains.

## 2. Complete every public feature you intend to advertise

Make an explicit list of what SignalTree v1 actually promises.

At minimum, verify the production behavior of:

- scalar reads/writes
- nested object signals
- recursive typed facade
- entity collections
- add
- remove
- update
- rekey/change ID
- restore
- held entity facade behavior
- key reuse/new SubjectId behavior
- transactions
- explicit pending transaction rollback
- thrown transaction rollback
- confirmed undo
- redo
- pending rollback
- confirm/seal behavior
- history retention
- subject reclamation
- structural causal history
- Angular observation/publication
- zoneless/OnPush behavior if advertised
- `stored()` / persistence
- any forms integration you intend to publish
- any plugin/enhancer APIs you intend to support

Anything incomplete should either be finished or explicitly removed from the v1 public surface.

## 3. Freeze the public API

Before publishing, stop treating exported API shape as fluid.

Audit:

- package exports
- public types
- public interfaces
- enhancer APIs
- helper functions
- error classes
- public symbols/constants
- factory functions
- entity APIs
- history APIs
- transaction APIs
- persistence APIs

Then:

- remove accidental exports
- expose anything users genuinely need
- remove internal escape hatches
- mark internal/test-only APIs properly
- make names consistent
- remove obsolete compatibility APIs you don't intend to support
- ensure the public API doesn't expose `SlotIndex` or other physical implementation details
- ensure runtime identity abstractions remain properly separated
- generate an API surface snapshot so accidental future export changes become detectable in CI

## 4. Lock TypeScript DX

SignalTree's recursive typing is part of the product, so this deserves release-level testing.

Create compile-time tests for:

```typescript
tree.$.profile.name();
tree.$.profile.name.set('Jonathan');

tree.$.orders.byId(id).status();
tree.$.orders.byId(id).status.set('done');
```

And test that invalid operations fail compilation.

Cover:

- deeply nested objects
- arrays if supported
- entity collections
- optional fields
- nullable fields
- unions
- readonly values
- literal types
- generic state definitions
- nested collections if supported
- enhancer-composed tree types
- transaction APIs
- history APIs
- persistence APIs
- emitted `.d.ts` files from the actual published build

## 5. Define supported Angular / TypeScript / Node versions

You need an explicit compatibility matrix.

Decide what v1 supports for:

- Angular versions
- TypeScript versions
- Node versions
- RxJS versions if relevant
- zone.js / zoneless configurations
- ESM
- browsers

Then test those combinations in CI.

Don't let `peerDependencies` imply support you haven't actually tested.

## 6. Package-output audit

Test the actual package consumers will install, not just source code inside Nx.

For every published SignalTree package:

- run the production build
- inspect generated package directory
- inspect `package.json`
- inspect `exports`
- inspect `.d.ts`
- inspect ESM output
- make sure source/test files aren't unintentionally shipped
- make sure internal package paths aren't broken
- verify source maps if shipped
- check tree-shaking
- confirm `sideEffects` metadata is correct
- confirm Angular metadata is correct where needed
- make sure package-to-package imports resolve from built artifacts

Then do `npm pack` or equivalent and inspect the tarball.

## 7. Install the packed package into clean consumer applications

Do not release based only on monorepo tests.

Create clean smoke consumers that install the generated tarballs.

At least:

### Angular consumer

```text
new Angular app
-> install packed SignalTree package
-> build production
-> run simple SignalTree example
```

Test:

- normal component
- OnPush
- zoneless if supported
- computed/effect/template observation
- entity operations
- transactions/history
- production build

### TypeScript-only consumer

If the core package is meant to remain framework-neutral:

```text
plain TS project
-> install core package
-> construct tree
-> mutate/read
-> compile and run
```

This proves you haven't accidentally leaked Angular into the kernel.

## 8. Browser/runtime compatibility tests

If this is a browser library, test actual runtime behavior beyond Vitest.

At minimum:

- Chromium
- Firefox
- WebKit/Safari equivalent

Especially for:

- Angular publication
- persistence
- structured values
- scheduling/microtasks
- serialization if used

You don't necessarily need a giant E2E suite. A small release smoke suite is enough.

## 9. Complete the correctness suite

Before v1, make sure permanent tests cover the architectural invariants we've spent all this time establishing.

Especially:

```text
PositionId != SubjectId != SlotIndex != key/path
```

and:

```text
all fallible semantic work before PRIVATE COMMIT
```

and:

```text
one physical commit -> one revision
```

and:

```text
PROJECT never determines authority
```

and:

```text
realization does not create causal authorship
```

and:

```text
semantic refusal has no physical/public/persistence side effects
```

Include adversarial cases involving:

- key reuse
- remove->restore
- remove->fresh-add same key
- restore->rekey->scalar
- fresh-add->rekey->scalar
- multiple effects sharing causal owner PositionId
- transaction abort
- pending rollback
- confirmed undo/redo
- stale structural state
- occupied destination refusal
- reclamation
- history retention
- held facades
- projection failure seams
- equality throws
- preparation throws

## 10. Finish the permanent performance suite

You already have much of this.

Make sure the final benchmark gate covers:

```text
10
100
1,000
10,000
100,000
```

for the meaningful operations.

Permanent logical assertions should prove:

- scalar read O(1)
- scalar write O(1)
- value update O(1)
- add O(1)-shaped
- remove O(1)-shaped
- rekey O(1)-shaped
- restore O(1)-shaped
- frame O(k)
- zero unrelated projection visits
- zero unrelated structural visits
- no public fresh-add key-order copying
- appropriate bounded causal work

Heavy timing stays behind `ST_PERF`.

Also preserve a final baseline report for the release.

## 11. Production-bundle cleanliness

Verify the things used for proving performance do not leak into production.

Check that production output contains no:

- performance counters
- benchmark hooks
- test-only integrity methods if they aren't intended
- instrumentation strings
- debug assertions
- test injection seams
- accidental Angular TestBed code
- development logging

Run the existing stripping/instrumentation guard against final HEAD.

## 12. Memory / lifecycle testing

SignalTree has semantic lifetimes, shells, tombstones and retained values, so release testing should include memory behavior.

Test long-running sequences such as:

```text
add
remove
restore
remove
retire
add another subject
repeat thousands of times
```

Verify:

- retired backing can actually be reclaimed
- SubjectIds aren't incorrectly reused
- retained shells don't accidentally retain huge payload graphs
- history retention behaves as configured
- pending transactions don't leak indefinitely
- publication tokens don't accumulate
- descriptor maps don't grow without bound

You don't need perfect heap science, but you should run at least one sustained churn test.

## 13. Error model

Audit all errors users can actually receive.

Define/export meaningful error types for things such as:

- invalid transaction operations
- rollback failure
- structural drift
- illegal restore
- persistence error
- unsupported operation
- history exhaustion if applicable

Errors should:

- have stable names
- carry useful context
- not expose internal SlotIndexes unless intentionally diagnostic
- preserve `cause` appropriately
- distinguish semantic refusal from catastrophic invariant failure

Document which failures leave state unchanged and which occur after committed state.

## 14. Persistence contract

Beyond implementation, document what persistence actually guarantees.

Specify:

- when writes happen
- what is serialized
- atomicity expectations
- initialization/hydration behavior
- migration/version behavior
- error behavior
- asynchronous adapter behavior
- whether multiple rapid commits coalesce
- interaction with undo/redo
- interaction with realization
- whether persistence restoration creates history

Treat this as a real API contract, not an implementation detail.

## 15. SSR/hydration decision

For an Angular library in 2026, users will ask.

Either support SSR/hydration and test it, or explicitly document:

> SignalTree v1 does/does not support SSR/hydration.

If persistence touches browser globals, make sure imports don't explode under Node SSR merely from loading the package.

## 16. Security / dependency audit

Before publishing:

- dependency vulnerability audit
- eliminate unnecessary runtime dependencies
- check dependency licenses
- check transitive dependency exposure
- verify no secrets/test credentials exist
- scan package tarballs for accidental files
- verify generated sourcemaps don't contain anything sensitive
- inspect postinstall/preinstall scripts; ideally none
- inspect prototype/key handling around user-generated entity IDs where relevant

## 17. Licensing and ownership

Make sure the repository and package are legally publishable.

You need:

- `LICENSE`
- copyright attribution
- package `license`
- third-party notices if required
- dependency license review
- contributor/license policy if accepting outside contributions

## 18. Package metadata

Every published package should have polished metadata.

Check:

- `name`
- `version`
- `description`
- `keywords`
- `license`
- `author`
- repository URL
- homepage
- bugs URL
- `type`
- `exports`
- `types`
- peer dependencies
- engines
- side effects
- publish config
- files whitelist

No placeholder metadata.

## 19. Decide the package structure

Freeze what you're actually shipping.

For example:

```text
@signaltree/core
@signaltree/angular
@signaltree/forms
...
```

Avoid publishing packages merely because they happen to exist in the monorepo.

Define:

- which are public
- which are experimental
- which are private
- how versions relate
- whether packages version together

## 20. Versioning policy

Choose and document SemVer behavior.

For example:

```text
1.0.0
```

means public APIs are now subject to compatibility expectations.

Define what counts as:

- patch
- minor
- major

Especially for:

- inferred TypeScript types
- causal semantics
- persistence format
- enhancer APIs
- error types

## 21. Changelog

Create a useful `CHANGELOG.md`.

For the initial release, summarize major capabilities rather than dumping hundreds of internal commits.

Something like:

```text
SignalTree 1.0.0

- Recursive typed SignalTree facade
- Angular signal integration
- Entity collections
- Transactions
- Causal undo/redo
- Structural time travel
- Persistence
- O(1)-shaped local mutation kernel
...
```

## 22. Migration / compatibility guide

Even for a first public release, you have had major internal/API changes during development.

If anyone may be using an earlier SignalTree version, document:

- breaking API changes
- old -> new syntax
- transaction changes
- entity API changes
- persistence changes
- history semantics

If nobody external uses it yet, this can be very small.

## 23. README worthy of a stranger

The README needs to sell and teach SignalTree without this conversation.

It should answer:

1. What problem does SignalTree solve?
2. Why not plain Angular signals?
3. Why not NgRx / SignalStore / another state library?
4. What does the syntax look like?
5. How do I install it?
6. How do I create a tree?
7. How do entities work?
8. How do transactions work?
9. How does undo/redo work?
10. How does persistence work?
11. What Angular versions are supported?
12. What guarantees does the library provide?

The first example should probably be extremely small:

```typescript
const tree = signalTree({
  user: {
    name: 'Jonathan',
    age: 43,
  },
});

tree.$.user.name();
tree.$.user.name.set('Jon');
```

Then move into the advanced capabilities.

## 24. Full documentation site

For a serious public library, README alone isn't enough.

For signaltree.io, I'd want sections such as:

```text
Introduction
Installation
Quick Start
Core Concepts
Recursive Signals
Entities
Transactions
Undo / Redo
Causal History
Persistence
Angular Integration
Performance
API Reference
Architecture
Recipes
FAQ
Migration
```

Use the architecture sophistication as a selling point, but don't make users learn PositionId and SubjectId just to set a name.

## 25. API reference generation

Generate docs from the public API only.

Users need searchable documentation for:

- functions
- types
- configuration
- enhancers
- transaction objects
- entity methods
- time-travel methods
- persistence interfaces
- errors

Keep physical-kernel internals out of the normal API docs.

## 26. Examples

Have copy/paste examples for:

- basic nested state
- computed/effects
- entity CRUD
- transactions
- rollback
- undo/redo
- persistence
- Angular component
- OnPush
- zoneless
- forms if shipping
- async flows where appropriate

Ideally have at least one runnable example app.

## 27. A showcase/demo application

For SignalTree specifically, this matters.

Build a small but nontrivial application demonstrating:

```text
entities
nested state
transactions
undo/redo
persistence
Angular templates
```

A todo app is probably too trivial for what SignalTree does.

Something like an editable order/project interface with undo/history would communicate the value much better.

## 28. CI release gate

Your required checks before merging/releasing should include at least:

```text
test
build
lint
type tests
package smoke test
consumer installation test
production instrumentation guard
```

Optionally:

- browser E2E
- performance logical gate
- dependency audit

No release should depend on remembering to run these manually.

## 29. Release automation

Set up the actual publishing workflow.

Prefer an automated pipeline that:

```text
tag/version
-> clean checkout
-> install locked dependencies
-> test
-> build
-> lint
-> package
-> smoke install
-> publish
-> create GitHub release
```

Use npm trusted publishing/OIDC/provenance if the publishing setup supports it rather than a long-lived npm token.

## 30. Release provenance / supply-chain hygiene

For a modern npm package, ensure:

- lockfile committed
- deterministic builds as practical
- protected release branch/tag
- npm 2FA/trusted publishing
- provenance enabled
- CI-only publishing
- no local developer machine required to publish production releases

## 31. Release candidate

Do not jump immediately from development to `1.0.0`.

Publish something like:

```text
1.0.0-rc.1
```

Then:

- install it from npm into fresh projects
- use it yourself
- ask a few people to try it
- verify documentation against the actual package
- collect packaging/DX failures
- fix them

Release candidates are especially valuable for TypeScript libraries because package/export/type problems often appear only outside the monorepo.

## 32. Real external consumer test

Have at least one project that is not inside the SignalTree monorepo consume the release candidate.

That catches:

- undeclared dependencies
- bad exports
- path aliases
- missing files
- source-only imports
- Nx assumptions
- test-only dependencies accidentally required at runtime
- bad TypeScript declarations

This is one of the highest-value release checks.

## 33. Final public API review

After RC feedback:

- remove anything embarrassing or clearly wrong
- don't casually add more features
- decide what is experimental
- mark experimental features explicitly
- freeze v1 API

Then generate the final API snapshot.

## 34. Final release regression run

Immediately before `1.0.0`:

```text
clean clone
install
test
build
lint
type tests
package
external consumer smoke
browser smoke
production bundle audit
logical complexity gates
ST_PERF baseline
dependency/security audit
```

No dirty working tree.

No ignored failures.

No known flaky critical tests.

## 35. Publish `1.0.0`

Then:

- publish packages
- publish docs
- tag repository
- GitHub release
- changelog
- release notes
- verify npm pages
- install exact `1.0.0` into a clean project
- verify signaltree.io installation instructions actually work

## 36. Post-release operational readiness

"Done" also means knowing what happens when somebody reports a problem.

Have:

- GitHub issue templates
- bug report template
- reproduction instructions
- feature request policy
- security reporting contact/policy
- contribution guide
- code of conduct if accepting community contributions
- support/version policy

## Concrete sequence from here

**Release execution order is owned exclusively by
[`RELEASE-1.0.md`](RELEASE-1.0.md). Do not duplicate the sequence here.**

A 28-step sequence used to be copied into this section. It had already drifted
from the controller's copy — which is the whole argument against keeping two.
The controller carries the live sequence, the current phase, the gate model and
the stop conditions; this file carries backlog and context that the controller
does not own.

---

Ordered by what unblocks the most. Reasoning is compressed — the full derivation
is in the linked audits. What went wrong in 14.0.0, including what I broke myself,
is in [14.0.0-what-actually-happened.md](docs/audits/2026-08/14.0.0-what-actually-happened.md).

---

## ~~1. Move semantic history filtering from write-time to read-time~~ — DONE

Implemented. `shouldSkip` no longer runs in `addEntry`; entries are retained and
`undo()`/`redo()` skip via `skipsBackward()`/`skipsForward()`. The O(1) reference
dedup stays on the write path. 1,087 core tests pass, 32/32 gates.

**What still follows from it**, and is not done: labelling and coalescing are now
_possible_ — a complete history with changed-path metadata is what they need — but
neither is built. Both are now properties of the transaction handle (item 2), not
separate features, and **not** a `transaction(label, fn)` callback — that form is
falsified.

Original reasoning, kept because it is the argument for the next two:

### 1. Move semantic history filtering from write-time to read-time

**The change.** The write path keeps only the O(1) reference-identity dedup it
already has. Everything semantic — skip, group, label, coalesce — moves to read
time over a bounded buffer.

**Why.** `shouldSkip` currently runs on every recorded write and DISCARDS the entry
(`time-travel.ts`, the `return` after the comparator). Five problems, one cause:

1. **The cost is on the wrong operation.** Writes are the hot path — per keystroke,
   per telemetry frame. `undo()` is a human gesture. Recording an entry is O(depth)
   and effectively free since 13.5.0; the comparator is the expensive part. We pay
   O(state) per write to avoid something that costs almost nothing.
2. **It is irreversible.** A skipped entry never existed. A wrong predicate loses
   history permanently. Read-side filtering is a view: wrong filter, change it.
3. **One policy for every consumer.** An undo button, a devtools panel and an audit
   view must share one filter fixed at record time.
4. **It is a documented foot-gun.** "A careless comparator is an O(state) walk per
   write" stops being expressible if the comparator does not run per write.
5. **Coalescing is impossible save-side.** To merge keystrokes into a word you need
   a RUN of entries; at write N you cannot know N+1 is coming. The current shape
   forecloses it by construction.

**Also closes:** the no-label gap and the no-coalescing gap, which were filed as
separate features and are the same design error. `transaction(label, fn)` changes
shape too — with entries retained and labelled, grouping is a read concern.

**Watch:** retention. Keeping everything costs `entries x width`. `maxHistorySize`
bounds the count, ST2029's model says width dominates, and the structural dedup is
already free — so bound the buffer rather than destroying data to save memory
nobody has measured.

Derivation: [undo-business-and-ux-cases.md](docs/audits/2026-08/undo-business-and-ux-cases.md)

## ~~1b. `setOne()` / replace path~~ — DONE, shipped as `replaceOne`

Resolved and committed (`80f41e94`). The entity-node callable now REPLACES, and
`replaceOne(id, entity)` is public.

**The deciding argument was neither of the ones this item used to carry.** Not the
withdrawn `@signaltree/callable-syntax` analogy (that was a dev-only build transform for
leaf signals and has no bearing on merge-vs-replace), and not branch-callable
consistency. It is that **the updater form is unfixable under merge**: `node(cur => …)`
returns a full `E`, so a spread puts any dropped key straight back. Merge cannot host
that signature — either the callable replaces or `node(updater)` gets deleted.

**`setOne(entity)` was rejected on correctness, not style.** It would derive the key via
`selectId(entity)`, and `changeId` can leave `entity.id` disagreeing with the storage
key — a silent wrong-slot write. `replaceOne(id, entity)` takes the caller's id and
cannot drift. A test pins that drift so the reason outlives this note.

## 1c. A diagnostic for `changeId` + held nodes

`changeId` drops the old per-entity signal (`entity-signal.ts:768-770`) — correct,
and deliberately so — but nothing warns, and a held node just resolves `undefined`.
A long-lived `selectById(id)` closing over the old id breaks silently. Cheapest of
the v3 asks, and it protects "diagnostics with stable codes", which is one of the
six capabilities no competitor has.

## ~~2. Settle the history representation~~ — CLOSED BY V15 ARCHITECTURE

The declarative restoration architecture, completed-designated-turn history,
and lazy historical materialization are frozen. The material below is retained
as historical derivation evidence, not an open decision or implementation queue.

**The goal is
[history-the-greenfield-target.md](docs/architecture/history-the-greenfield-target.md):
history's unit is a named user action, declared at the call site, scoped to the state
it touches, attributed to whoever caused it.** Read that first — it says what we are
building and why, and it has a §6 acceptance list to verify against by outcome.

**Then read [2026-08-history-greenfield-spike.md](docs/research/2026-08-history-greenfield-spike.md)
before touching 2a-2c or 3.** Six candidate architectures with pros and cons; the
choice is not made yet, and this item is the decision, not an implementation.

**The adopter check has been run and it narrowed the field.** v3 ships 50-step undo to
production end users at the form layer and deliberately type-erases `restoration`, so the
target's architecture is already their shipped architecture. Two results that change
this item:

- **`act('label', fn)` is dead.** Callback scope is dynamic scope and does not survive
  `await`. MEASURED via `batch()`: 5 sync writes → 1 entry, 5 awaited → 2, a 12-way
  concurrent `mergeMap` fan-out → **12**. Every real bulk handler is the last shape.
  The replacement is a transaction **handle** (`tree.action(label)` → `commit()`/`abort()`),
  because a value closes over an async pipeline and a callback scope cannot.
- **Option F is eliminated.** An unrelated write can land between an action's open and
  commit, so an action entry cannot be a whole-tree snapshot — undo must revert only the
  action's paths. Action entries are **path-scoped deltas** necessarily, which rules out
  every whole-state option including fix-the-stack-in-place. This was the strongest
  cost-based counter-argument and the constraint removes it.

### The `tree.action()` prototype has been run — DONE 2026-08-10

Written against v3's three real handlers as they ship
(`packages/core-services-v2/src/lib/store-features/service-crud-ops.ts:344` `create$`,
`:434` `bulkPatch$`, and `packages/screens/src/lib/entity-table-buttons.component.ts:258`
`onArchiveToggle` → `setArchived$` at `:516`). Five results, and the first one
falsifies the obvious implementation.

**1. AMBIENT attribution is dead — the same way `act(label, fn)` was.** The cheapest
handle implementation says "while an action is open, writes belong to it". MEASURED:
two concurrent actions each captured **both** actions' paths.

```
a1 "Archive x" captured: ["entities.x","entities.y"]
a2 "Rename y"  captured: ["entities.x","entities.y"]   -> undoing the rename un-archives x
```

v3 really does run these concurrently — `bulkPatch$` and `onArchiveToggle` both fan
out, and a user can start one while another is in flight. So membership cannot be
inferred from wall-clock overlap. **Writes must be explicitly attributed, which means
the handle has to reach the call site.** Dynamic scope failed against `await`; ambient
scope fails against concurrency. Same lesson, one level up.

**2. The call sites that fight it, named.** `onArchiveToggle` fans out through
`store.activate$` / `deactivate$`, which are ALSO public single-record entry points a
component calls directly. So either those open their own action (and nest) or they
take one. **Nesting is forced by v3's structure, not a design choice** — and the
answer to "inner commits into outer or stands alone" is that the inner must join the
outer. Concretely the signature has to grow:
`activate$(id)` → `activate$(id, action?)`, threaded through
`mergeMap(id => action(id), CONCURRENCY)`. That is the cost, and it lands on every
store method a bulk handler composes.

**3. The leaf blind spot is `PathNotifier`'s, and SITING fixes it.** The prototype
captured 3 entity paths and **0 of 4** scalar writes — but it ran against a bare
`signalTree()`. Re-measured with the enhancer attached:

```
bare tree         captured: ["entities.e1"]                                        0/3 leaves
with restoration() captured: ["entities.e1","selectedIds","saveState","bulkCompleted"] 3/3 leaves
```

`time-travel.ts:638` installs `interceptLeafSignals` and calls `notifier.notify()`
itself at `:646`, so plain-leaf writes reach `PathNotifier` **only because
`restoration()` injects them**. Consequence: an action built as a standalone notifier
subscriber inherits the blind spot; one built **inside the time-travel enhancer gets
leaves for free**. That is an independent confirmation of the target doc's §4.5 siting,
arrived at from the opposite direction.

It still matters that leaves are in scope — `create$` deliberately carries selection
from the temp id to the server id, and an undo restoring the row without the selection
is wrong.

**4. Partial failure has no `commit()`/`abort()` answer.** MEASURED on
`onArchiveToggle` with 3 records, 1 failing: 2 succeeded, 1 failed and **already
self-reverted** via the handler's own `catchError`. The delta set is
`["entities.a","entities.b","entities.c","entities.b"]` — b's removal AND its restore.
`commit()` records a step whose undo re-removes a row the user can still see;
`abort()` would revert the two the server accepted. Neither describes the outcome.

**The fix is already written elsewhere in the library.** The action must record **net
change per path** — first `before`, last `after`, drop paths that round-trip. That is
exactly `PathNotifier.flush()`'s merge rule, which §1.3 measured as already correct
**within a turn**. The action needs the same rule **across turns**. It also fixes
result 5 for free.

⚠️ **The collapse predicate must be deep — but do NOT change `flush()`.**
`path-notifier.ts:198` is literally `if (newValue === oldValue) continue;`, and that
line must stay `===`. `flush()` runs on **every turn** over **every changed path**,
driven by `queueMicrotask` — putting a structural walk there is the same mistake as
write-time `shouldSkip`, which item 1 just finished moving off the hot path.

| runs                | when                      | over                 | predicate  |
| ------------------- | ------------------------- | -------------------- | ---------- |
| `flush()`           | every turn                | every changed path   | keep `===` |
| `commit()` collapse | per action, human-clicked | that action's deltas | deep       |

`commit()` is a person clicking Save; `flush()` is a keystroke. Same siting argument
as `shouldSkip`.

**Reuse `prunedEqual` (`utils.ts:118`) rather than inventing a predicate.** It is
reference-first (`if (a === b) return true`), treats arrays and built-ins as leaves
so it never walks them, and recurses only into plain objects. VERIFIED against the
exact case:

```
same reference    -> true   (fast path, no walk)
reconstructed obj -> true   <- collapses the phantom
genuinely changed -> false
```

It is honest about its cost: reference-first still pays the structural walk when
references differ, which is precisely when you have to look. What it buys is that
v3's capture-then-restore style hits the fast path — fast where it can be.

⚠️ **KNOWN HOLE — `prunedEqual` treats arrays as leaves, and for THIS use that is
not merely "conservative".** `utils.ts:130` returns `false` for two arrays with
differing references without comparing contents. Everywhere else in the library that
is the safe direction; here it means **failing to collapse**, so the phantom entry
survives — the exact defect the collapse exists to prevent. VERIFIED:
`prunedEqual([1,2,3], [1,2,3]) === false`.

Reachability, stated so nobody reads the table row as "safe":

- **Entity collections: probably not reachable.** They notify per-entity paths
  (`rows.<id>`), so the value at a path is an entity object, not the array.
- **A plain array leaf IS reachable**, directly. `tags: string[]` compensated by
  reconstruction (`tags.set([...original])` rather than `tags.set(original)`) leaves
  a phantom step.

So `prunedEqual` is the right base but not sufficient alone. Either special-case
array leaves in the collapse predicate, or accept the hole and document it — decide
deliberately, and do not let "arrays are leaves" pass review as an optimisation when
here it is a correctness gap.

**Cost bound to state while designing:** O(paths touched × value size), not O(state).
The per-path term is large when a path's value is a big array. `ST2027` already exists
for the deep-equal-different-reference class (~2.8 ms on a 50k array) if a diagnostic
is wanted rather than an unbounded walk.

The finding that motivates all of this — across turns a compensating write often
**reconstructs** the value rather than restoring the captured object, and reference
identity then fails to collapse it. MEASURED on the partial-failure shape:

| compensation style                         | net by `Object.is` | net by deep-equal |
| ------------------------------------------ | ------------------ | ----------------- |
| v3-faithful (restores the captured object) | `[a, c]` ✓         | `[a, c]` ✓        |
| reconstructs a fresh object                | `[a, **b**, c]` ✗  | `[a, c]` ✓        |

v3's own handlers capture `currentEntity` before mutating and restore that exact
object, so reference identity happens to work for them today — but it is one
refactor away from leaving a phantom entry for a row the user can still see. Specify
deep equality.

**5. `create$` records history the user never saw.** Server assigns a different id, so
the action contains `entities.temp-1` (add), `entities.temp-1` (remove),
`entities.srv-9` (add). Undo must not resurrect a temp id the server rejected. Net
collapse per result 4 nets the temp row to nothing.

**Also confirmed against a real shape rather than in theory:** a realtime server push
landing mid-action is captured inside the user's action
(`["entities.r1","entities.pushed-by-server"]`), so undoing "Archive r1" would delete a
row the user never touched. This is the §2 constraint that forces path-scoped deltas —
now reproduced on a handler that ships.

**What this does NOT change:** the transaction handle is still the right shape, and
`act(label, fn)` stays dead. What it changes is that the handle is **not ambient and
not free** — it has to be threaded through store method signatures, and it needs the
cross-turn merge rule before it can be correct under partial failure.

**Note on `abort()` — RETRACTED and re-tested.** An earlier draft of this item said
`abort()` duplicates `catchError`, would double-revert, and that the handle's value is
"labelling and grouping, not rollback". That read `abort()` as reverting **state**. It
does not: **`abort()` discards the recording; `catchError` reverts the state, exactly
as it already does.** They compose, and re-measured on `create$`'s error path:

```
state before = "existing", after = "existing"   (catchError reverted)
undo steps created by the action: 0
double-revert: NO — abort() touched no state
```

So `abort()` does the one thing `catchError` **structurally cannot**: express "this
action produced nothing the user should be able to undo." Keep it.

Two refinements from the same run:

- **Net collapse makes `abort()` belt-and-braces rather than load-bearing** for the
  total-failure case: the same failure committed by mistake also recorded 0 steps,
  because `temp-1` round-tripped and collapsed out. `abort()` still earns its place —
  it states the intent rather than relying on the arithmetic working out.
- **`abort()` is the WRONG call on partial failure.** With collapse, `commit()` on the
  2-of-3 archive records exactly the two the server accepted and drops the
  self-reverted one. `abort()` there would discard a real two-record change. So the
  handle needs no third outcome — `commit()` + net collapse covers partial failure,
  and `abort()` covers total failure.

### Sequencing: what gates on what

Breaking-change freedom removed every compatibility gate. What remains is knowledge, and
it splits three ways.

**Ships without the prototype — absence is safer than presence, or the defect is wrong
under every design:**

- Delete pause/resume/isRecordingPaused (above)
- Delete `__provisional`/`finalizeProvisional` (2b)
- Phantom entries + the `history` option collision (2a)
- Re-score the 32-case audit and the 11 workload verdicts (item 6)
- Delete the parity framing (item 7)

**Gated on the prototype, because we do not yet know the shape:**

- The representation itself, and nesting semantics
- **Authorship (item 3) — likely subsumed.** If a write outside any action is simply not
  in user history, authorship stops being a separate mechanism and becomes a property of
  having no action scope. Building a parallel `author` field first risks shipping two
  answers to one question. Hold until the prototype says.
- Whether read-time `shouldSkip` survives at all
- `insertAt` (2c) and the `changeId` remap event (item 1c): both are needed under every
  option, but their signatures may need to carry action identity. Existence is certain;
  shape is not.
- `maxHistorySize` → turn-bounded, which is undefinable until "turn" is

**Independent of all of it:** capability matrix (item 8) and RFC 0008 (item 9).

~~Re-verifying the spike's memory figures~~ — **DONE 2026-08-10, and the
load-bearing one stands.** Re-run from scratch against the built package with
`--expose-gc`, one process per arm:

- **Retention REPRODUCED.** Snapshot stack 0.594 / 4.089 / **19.979 MB** at
  1k / 10k / 50k against the reported 0.59 / 4.05 / 19.58 — within ~2%, and 3 reps
  at 50k identical to three decimals.

  ⚠️ **But the cost argument against Option F does NOT hold generally**, and an
  earlier draft of this item said it did. By the refinement below, a scalar/form
  editing workload beside a 50k collection retains ~0.45–0.9 MB — which is free.
  Memory eliminates Option F **only for collection-write-heavy workloads**. Those
  happen to be exactly the ones the fit page claims (drag boards, bulk CRUD,
  offline creates), so the practical conclusion survives — but the reason it
  survives is contingent, not general.

  **Which argument is load-bearing matters for anyone revisiting this.**
  Correctness carries every workload: an unrelated write landing between an
  action's open and commit forces path-scoped deltas regardless of memory. Memory
  does not. So if the correctness constraint is ever reopened, **memory is not
  available as a fallback justification** — at 0.30 MB (re-measured 2026-08-11;
  0.45 was itself a superseded reading) it isn't one.

- **`undo()` = O(state) REPRODUCED.** 436.67 µs at 50k against 434 µs reported,
  scaling 25.4 → 83.5 → 436.7 µs. There is no root pointer to swap; the snapshot
  model's one claimed advantage over a log does not exist here.
- **Entry-count trap REPRODUCED exactly** — 50,050 log entries at 50k rows, with
  bytes flat. Confirms that a log must be bounded by turns, never by entries.
- **REFINEMENT — `entries × width` is only paid by writes that TOUCH the wide
  collection.** 50 scalar writes beside an untouched 50k collection retain
  **0.896 MB**; 50 collection writes retain **19.98 MB**. Unchanged collections are
  shared by reference between entries. So 19.58 MB is a real **worst case, not a
  typical one**, and ST2029's wording describes a collection-write-heavy workload
  rather than history in general. Doesn't rescue Option F (dead on correctness) and
  doesn't change that `undo()` is O(state) — but the realistic mixed workload sits
  nearer 0.9 MB than 19.6 MB, and the cost argument should say so.

  ⚠️ **CORRECTED 2026-08-11 — "worst case" is exactly backwards, and 0.896 does not
  reproduce.** Re-run with `tools/bench-retention-arms.mjs` (baseline after seeding):
  the scalar arm is **0.298 MB** at 50k, not 0.896, and 0.896 has not reproduced
  under any baselining method (baselining _before_ seeding gives 7.62 MB, because
  then the collection is inside the arm). The reference-sharing insight stands — it
  is the durable finding — but 19.38 MB is a **floor, not a worst case**: one
  changed row and fifty different changed rows retain the same 19.38 MB, and
  changing all 50,000 retains **114.77 MB**. The real cost function has two terms,
  `entries × (width × ~8 B + changedRows × ~40 B)`, and the second was missing
  everywhere. The "sits nearer 0.9 than 19.6" conclusion survives in direction
  (mixed workloads are cheap) but the ceiling it implied was 5.9× too low.

- **Recording slope PARTIALLY reproduced.** Collection column reproduces in shape
  and within ~2× (31.8/66.9/255 → 18.8/49.8/215 µs per recorded entry). The scalar
  column does not: measured **flat** in collection width (10.8 → 11.3 µs) where the
  original rises 3× (23.1 → 70.7). The flat result is what the retention refinement
  predicts, so the two measurements corroborate each other. Do not quote 70.7 µs
  again without re-measuring.

Full write-up in
[the spike §1.7](docs/research/2026-08-history-greenfield-spike.md).

### DELETE `pauseRecording()` / `resumeRecording()` / `isRecordingPaused()`

**Not deprecate — delete, in 14.1.1.** This was previously written as blocked on the
transaction shipping first, on the grounds that removing a published API with no
replacement leaves callers stranded. That reasoning is void now that breaking changes
are acceptable, and it was the wrong trade anyway: the API is a **silent-data-loss
footgun**, so a deprecation window is a window in which more call sites acquire it.

Delete the three methods, the `pausedSignal`, the early return at `time-travel.ts:128`,
and lever 3 of `docs/guides/time-travel-in-production.md` (the pause + sealing-write
recipe). Nothing in `packages/*` or the demo depends on them, and v3 — the only known
adopter — deliberately type-erases `restoration` and does not use them.

**This can ship before the transaction exists.** Its absence is strictly safer than its
presence, so it is not gated on the replacement.

Not merely verbose — **unsafe**, and its own guide proves it. It cannot express "one
step", only "record nothing" (`time-travel.ts:128` is the whole implementation), so the
documented recipe needs a synthetic sealing write landing on an invented domain field,
and the entry is then identified by a timestamp rather than by the action. An earlier
revision of that guide shipped the destructive version without the seal.

And it is a **global** mode: MEASURED, an unrelated `tree.$.rev.set(999)` inside a paused
window was suppressed too. Correctness requires sole ownership of the tree for the
window's duration — which a synchronous `for` loop has and a multi-second `mergeMap`
over N requests does not.

The narrow shape where it is genuinely fine — synchronous, single-writer, quiescent app,
with a meaningful revision field to seal on — is an import script, not an interactive
bulk action. Which is to say it is dev behaviour that was documented as a production
lever.

Note for the RFC 0012 authors: §2 there calls pause "the imperative version: correct, and
it puts the burden on every call site." By this repo's own guide it is **not correct on
its own**. The burden is not verbosity, it is silent data loss.

[history-the-native-shape.md](docs/architecture/history-the-native-shape.md) argues
for one of the six (the path-diff log). Read it as an advocate, not as the plan — and
note the spike narrowed its central premise: `notify()` does **not** fire at every
write site (plain leaf writes reach it only via `interceptLeafSignals`, `status()`
never notifies, and a whole `form()` is a single path, so a path log has no in-form
field granularity).

Two things the spike established that any option must reckon with:

- **Restoring a snapshot is O(state), not O(1).** There is no root pointer to swap;
  `restoreState` is `this.tree(state)`, a full recursive write. The snapshot model's
  only claimed advantage over a log does not exist in SignalTree — measured 434 µs
  vs 1.08 µs for one undo step at 50k rows. Verify this before building on it; it
  inverts what every prior doc here assumed.
- **`changeId` notifies nothing** — it passes the same value as `value` and `prev`,
  so `flush()` drops it, and a naive log inverse therefore produces a duplicate row.
  Blocks any log-based option until fixed.

`notify(path, value, prev)` already exists at every write site
(`path-notifier.ts:113`, called from entity-signal, form, devtools), and
`updateAndReport()` already returns changed paths. So the library already produces
`{ path, before, after }` per write and `restoration()` throws it away to snapshot
the root instead — which is the only thing an immutable-root store CAN capture, and
we are not one.

On a diff log: labels are a field, grouping is a span id, coalescing is merging
adjacent same-path entries, per-entity undo and branch scoping are both a path-prefix
filter, authorship is a field, and collection recording is a subscription to a
notification that already fires. Nine problems, one decision.

Genuinely hard, and must be settled first: non-invertible writes (ST2028's class),
coalescing order correctness, path stability under `changeId` (ST2031's class),
retention of references into the shared graph, and pre- vs post-batch recording.

### 2a. Fix phantom undo steps on `entityMap({ history: false })`

**This item used to say "record collection mutations." That was wrong — see the
retraction in
[14.0.0-what-actually-happened.md](docs/audits/2026-08/14.0.0-what-actually-happened.md).**
Collection mutations record fine. `removeOne` → `undo()` brings the row back,
`setAll` reorder → `undo()` restores the ORDER, and 20 `updateOne` in one microtask
is one entry that one undo reverts. My "verified" evidence was a synchronous
assertion against a `queueMicrotask` flush: I read the counter and never called
`undo()`.

The real defect underneath it: a collection excluded with `history: false` still
produces history entries. Five excluded-only writes gave five entries and
`canUndo() === true`, and the undo changes nothing a user can see — a dead Ctrl+Z,
which is worse than no undo because it burns a step the user believes they spent.

**Fix the option, not just the symptom — breaking changes make the real fix available.**
The `history` option name carries **two opposite meanings** today:

| Marker        | `history` today      | Means                                           |
| ------------- | -------------------- | ----------------------------------------------- |
| `form()`      | `history: history()` | **Opt IN** to this form's own undo stack        |
| `entityMap()` | `history?: boolean`  | **Opt OUT** of the global `restoration()` stack |

One name, opt-in at one position and opt-out at another. Patching the phantom entry
leaves that collision in place, and the collision is the reason the phantom exists:
`false` means "do not put me in the snapshot" when what a caller wants is "I am not
part of undo at all." Under the target's §4.5 split, positional markers answer exactly
one question — **is this state eligible for history** — and both markers should express
it the same way.

Do this as one change with the phantom fix, since they are the same bug at two depths.

**Also now known, and it settles the question item 2 deferred:** granularity today is
**per microtask**, not per mutation and not per user turn. 20 writes with no `await`
between them collapse to one entry; the same 20 with an `await` make 20. So the
"decide per-mutation or per-turn" question has a third, undesigned answer already
shipping — and it means turn boundaries are decided by incidental `await` placement
in the caller. That is the thing to fix, and the transaction **handle** is how — not a
callback form, which is measured not to survive `await`. See the target doc §4.1.

**Constraint, already measured:** time travel, devtools and serialisation share one
snapshot path, memoised per node. A purpose-dependent snapshot cannot just branch —
the memo serves whichever purpose asked first. See
[0012 §3](docs/rfcs/0012-history-scoped-marker-capture.md).

### 2b. Delete the `__provisional` / `finalizeProvisional` machinery

`time-travel.ts:193-213` and `:308-323` implement a half-built coalescing scheme with
**no caller anywhere in `packages/*/src`**, and the comment at `:123` already admits
it went "gone rather than wired up." It is still filed as a gap elsewhere.

**Delete it, and do not wait for the transaction.** There was an argument for holding:
`finalizeProvisional(state)` is a deferred-entry-completion mechanism, which is what
`commit()` needs, so deleting it now means rebuilding something similar later. That
argument loses. It was built to coalesce rapid same-path updates against a snapshot
stack; `commit()` has to close a **path-scoped delta spanning concurrent writers**.
Resurrecting the first as the second would inherit assumptions that no longer hold, and
re-adding ~20 lines is cheaper than reasoning about which of them still apply.

Keep the design note, not the code: **deferred completion is a real requirement, and
this was a first attempt at it.**

### 2c. `insertAt` on collections

The one thing a value diff genuinely cannot recover: position. `removeOne` +
`addOne` puts the row back at the END (`a,c,d,b`), and the only position-preserving
workaround is `setAll`, which is O(N) to move one row — the anti-pattern verbatim.
Every undo shape in the spike needs this; it is not specific to a choice.

## 3. Authorship on a write

Mark a write as non-user so it stays out of the undo stack by construction, instead
of every call site remembering `pauseRecording()`. Then `@signaltree/realtime` and
`@signaltree/events` can do the right thing — neither uses pause today, and a
server push is currently user-undoable.

## ~~4. Reword two fit-page rows~~ — WITHDRAWN, the premise was false

Both rows were flagged because of the retracted collection-recording claim. Drag undo
**works**: `setAll` reorder `a,b,c` → `c,a,b` → `undo()` returns `a,b,c`, order
included, with no counter-bump workaround. Nothing to reword.

The one thing still worth saying on that page is scope — whole-tree undo can revert a
server push the user never made — but that is item 3, and it is a real limitation
rather than a wrong claim.

## ~~5. State the collection limitation on the npm README~~ — WITHDRAWN

There is no collection limitation to state. Retracted with item 4.

## 5b. Naming: finish the pass

[api-naming-audit.md](docs/audits/2026-08/api-naming-audit.md) — run against the BUILT
surface, since an `as any` attachment is invisible to a type-level read and one finding
is exactly that.

Done: `removeAll()` deleted (pure alias of `clear()`), and the `coalesce()`/`update()`
data-loss defect it surfaced.

Still to do, in order:

1. **DELETE `batchUpdate`** — it is a pure duplicate of the tree callable, not just a
   composition. Its body is `recursiveUpdate(signalState, arg)`, which is precisely what
   `tree(partial)` / `tree(updater)` already do; with `batching()` attached it adds a
   `batch()` wrap, so `tree.batchUpdate(x)` === `tree.batch(() => tree(x))`.

   **Hazard, handle before deleting:** the demo's `benchmarks.service.ts` calls it behind
   a `typeof … === 'function'` guard **with a silent fallback**, so removing the method
   leaves the benchmark running and measuring a different path. Re-run and compare that
   benchmark as part of the change — a green build will not catch it. Sites:
   `signal-tree.ts`, `batching.ts:63,381`, `builder-types.ts:105`,
   `packages/core/README.md:2136`, `ENHANCERS.md:28`, `callable-syntax-demo`, and the
   benchmark harness.

2. **Document `batch` vs `coalesce`.** Not duplicates — MEASURED, a mid-callback read
   inside `coalesce` sees the OLD value because `coalesce` defers the WRITE, while
   `batch` defers only notification. Neither docstring says so, and both currently imply
   the same end state reached two ways.
3. **`getRestorationHistory()` / `getCurrentIndex()`** — the only `get`-prefixed accessors in a
   library of bare nouns (`all()`, `count()`, `canUndo()`). Both move to the devtools
   surface anyway; rename once, there.
4. ~~**`resetRestorationHistory()` vs `clear()`**~~ — ANSWERED, no rename. MEASURED: after 3
   writes, `resetRestorationHistory()` left `n === 3`, `canUndo() === false`, and a following
   `undo()` left `n === 3`. It empties the stack and leaves state alone. The name is
   accurate; `clear()` would be ambiguous between the two operations.
5. **`byIdOrFail()`** — an `OrFail` suffix unique in the API, for a "strict variant"
   concept that recurs without it (`removeMany`, `addMany` both throw).
6. **`map()` on `entityMap`** — returns `ReadonlyMap`, but reads as a projection next to
   `all()`. `asMap()`/`byIdMap()`. The `WRONG_ENTITY_METHODS` table exists for this class
   of mistake already.
7. **`__timeTravel`** — enumerable on the public tree object, so serialisation, devtools
   and `{ ...tree }` all see it.

### Pass 2 — the other packages (done; findings below are the work left)

8. **`@signaltree/events` inverts Zod's naming, and re-exports Zod.** MEASURED:
   `validateEvent` THROWS, `parseEvent` returns a result — backwards from `parse` /
   `safeParse` in the library it ships as `z`. Rename: `parseEvent` throws,
   `safeParseEvent` returns, `isValidEvent` unchanged.
9. **`@signaltree/events` mixes `Id` and `Key`** for the same concept —
   `generateCorrelationId` AND `generateCorrelationKey` are both public, beside
   `generateEventId` and `generateIdempotencyKey`. Pick one suffix.
10. **`ConnectionState` is two different public types.** A union in
    `events/angular/websocket.service.ts:35`, an interface in `realtime/types.ts:22`.
    An app using both packages imports one name for two incompatible shapes. Realtime
    also has its own `ConnectionStatus` enum beside it.
11. **`packages/enterprise/` is dead** — one stray `signaltree.code-workspace`, no
    package.json, no source. `@signaltree/enterprise` was removed in 14.0.0. Delete the
    directory or move the workspace file to the repo root.

### Pass 3 — config and option keys (done; work left below)

12. **`treeName` is a legacy alias for `name`** — the source says so verbatim
    (`/** Alias for name (legacy support) */`) and `devtools-impl.ts:1096` resolves
    `name ?? treeName`. Same class as `removeAll` and `equal`. Delete it.
13. **`TreeConfig.enableTimeTravel` is DEAD** (`types.ts:489`) — zero consumers in
    `signal-tree.ts`. A second, LIVE `enableTimeTravel` exists on `DevToolsConfig`
    (`types.ts:997`, used at `devtools-impl.ts:666,705`). So the flag a user is most
    likely to reach for silently does nothing while the working one is elsewhere.
    Delete the dead one.
14. **`Config` vs `Options` has no rule** — 37 vs 19, no distinction. Proposed rule:
    `Config` for construction-time config of a long-lived thing, `Options` for per-call
    arguments. Several names already fit; the outliers are the rename.
15. **ng-forms has four overlapping form-config types** — `FormConfig`(core),
    `FormTreeOptions`, `AngularFormsConfig`, `SignalFormOptions` share `validators`,
    `asyncValidators`, `storage`, `debounceMs`, `destroyRef`, `fieldConfigs`,
    `conditionals`, `injector` in varying subsets. Structural, needs a design pass
    rather than a rename.

Pass 3 also confirmed two things already filed: `equal` appears as an option key in
THREE interfaces (which is why removing the export was right, not merely tidy), and
`history`'s opt-in/opt-out collision spans exactly two interfaces — so unifying it is
small.

### Still uncovered

- **Config/option key names**, systematically. Three surfaced incidentally and all
  three were problems (`history` opt-in/opt-out, `equal` colliding with an export,
  `batchUpdates` naming a flag that does not control `batchUpdate`). That hit rate
  argues for a dedicated pass.
- **Type/interface names** beyond the collisions above (~70 in `events` alone). One
  lead was chased and cleared — `ErrorClassification`/`ClassificationResult` are two
  real concepts, not a duplicate.

## ~~6. Re-score the 32-case time-travel audit~~ — DONE 2026-08-10

Both documents re-scored by outcome against the built package on `main`. Every
verdict now names the `undo()`/`redo()`/`jumpTo()` it called and the state
afterwards. Seven of 32 cases moved, **five of them downward**, plus workload
verdicts 2/4/5/6/8 in
[undo-business-and-ux-cases.md](docs/audits/2026-08/undo-business-and-ux-cases.md).
Method and results:
[time-travel-use-case-audit.md](docs/audits/2026-08/time-travel-use-case-audit.md).

Confirmed along the way, independently: collection mutations record, `undo()`
restores deletes, field edits and **order**, and 20 `updateOne` in one microtask is
one entry reverted by one undo. The retraction holds.

### 6a. NEW DEFECT — `restoration()` does not cover `form()` state

**The largest finding of the re-score, and it loses user data.** Form writes never
notify the history recorder.

- Form-only tree, 3 form writes: `getRestorationHistory()` is `["INIT"]`, `canUndo() === false`,
  `undo()` is a no-op. Identical writes to a plain leaf on the same-shaped tree give
  4 entries and a working undo.
- Mixed tree: a _later_ plain-leaf write snapshots the form's then-current values
  incidentally, so `undo()` on an unrelated field **rewinds the form to a stale
  value**. Measured: `plain='p1'; name='ada'; plain='p2'; name='ada l'` → one
  `undo()` → `plain='p1'` AND `name=''`. One Ctrl+Z on a neighbouring field wiped
  the form.

`form({ history: history() })` — the form's own scoped stack — works correctly.
This is why v3 does undo at the form layer and type-erases `restoration`: their
architecture was forced, not chosen.

Do not fix by making the snapshot walker descend into form markers — that
reproduces the whole-tree-snapshot problem item 2 already ruled out. This is
evidence FOR the path-scoped delta representation, and it belongs to that decision.
Until then, document scoped form history as the only correct mechanism.

### 6b. NEW DEFECT — `createAuditTracker` is a 100 ms polling sampler

`signalTree` exposes no `.subscribe`, so the tracker always takes its fallback
branch, `setInterval(handleChange, 100)` (`audit.js:41-49`). It samples rather than
trails. MEASURED: two writes inside one window log only the last; **a write and its
revert inside one window log nothing at all**.

Boundary measured: two writes 0/25/50 ms apart log **1** entry, 90 ms+ log 2. A
write followed by a revert to the original value logs **0** entries at 0 ms and
50 ms, and 2 at 120 ms — so below ~90 ms the trail has no record it happened.

That is acceptable for an undo stack and wrong for an audit trail, which is the
thing it is named for and recommended for in the regulated/healthcare workload.
Either drive it from `PathNotifier` (the notification already fires at every write
site) or delete it and document `createAuditCallback` / `getRestorationHistory()`, which are
exact. It also leaks its interval unless the returned stop function is wired to a
`DestroyRef`.

### 6c. NEW DEFECT — `undo()` after `deserialize()` reverts the restore

`deserialize()` is recorded as an ordinary `BATCH` entry (`["INIT"]` →
`["INIT","BATCH"]`), so `canUndo()` is `true` immediately after a restore and the
first `undo()` always discards it. Verified at the boundary, not from one data
point — with a payload restoring `n = 2`:

| target before restore  | entries | `canUndo` | after undo | after 2nd undo |
| ---------------------- | ------- | --------- | ---------- | -------------- |
| fresh                  | 2       | `true`    | `0`        | `0`            |
| 1 prior write (`7`)    | 3       | `true`    | `7`        | `0`            |
| 2 prior writes (`7,8`) | 4       | `true`    | `8`        | `7`            |
| 3 prior writes         | 5       | `true`    | `9`        | `8`            |

Where it lands varies; that it discards the restore does not.

**Severity correction on the first report:** it is **recoverable** — `canRedo()` is
`true` and `redo()` returns the restored value. This is an enabled undo button
whose first press does something the user cannot want, not data loss. Rank it below
6a and 6b accordingly.

Mitigation that works today: `deserialize()` **before** `.with(restoration({}))` →
`canUndo() === false` and `undo()` is a no-op, because the restored state becomes
`INIT`'s baseline and undo has no way past it.

⚠️ **That only covers SYNCHRONOUS hydration** — `localStorage`, a transferred SSR
blob, an embedded bootstrap. An app hydrating from an **async fetch** cannot
sequence it that way: the tree must exist before the response arrives, so the
enhancer is already attached and the restore lands as a recorded entry. So the doc
line closes the narrower half; the async half still needs a code answer (a
non-recording restore path, or authorship — item 3).

### 6d. `maxHistorySize` — it is a buffer length, not a step count

Bigger than first reported. Default is 50 (`time-travel.ts:80`,
`config.maxHistorySize ?? 50`) and the type declares no default, so "omit it for
unbounded history" is false. But the off-by-one is the part that affects everyone.
10 writes on a tree starting at `n = 0`:

| config     | entries | index  | undos spendable | note               |
| ---------- | ------- | ------ | --------------- | ------------------ |
| omitted    | 11      | 10     | 10              |                    |
| `0`        | 0       | **-1** | **0**           | undo disabled      |
| `1`        | 1       | 0      | **0**           | undo disabled      |
| `2`        | 2       | 1      | 1               |                    |
| `5`        | 5       | 4      | 4               |                    |
| `-1`       | 0       | **-1** | **0**           | undo disabled      |
| `NaN`      | 11      | 10     | 10              | silently unbounded |
| `Infinity` | 11      | 10     | 10              |                    |

1. **HEADLINE: any value ≤ 1 silently disables undo.** `0` reads as "no limit",
   `1` reads as "one step"; both give none. `-1` also drives `getCurrentIndex()`
   to `-1`, since the trim runs `currentIndex--` against an already-empty buffer.
   Fix with **input validation and a stable ST-code** — a silently dead undo
   button is the same failure class as the phantom step fixed in 2a.
2. **N entries yields N−1 undo steps**, because the oldest retained entry is a
   floor you land on rather than a step you spend.

   ⚠️ **The docs are NOT wrong and must not be renumbered.** An earlier draft of
   this item said "every doc sample is off by one". That was false. `types.ts:43`
   says "Maximum number of history **entries** to keep, `@default 50`" and
   `time-travel-in-production.md:95` says "20 writes against `maxHistorySize: 5`
   leaves a history of 5" — measured here as exactly 5 entries. Changing `50` to
   `51` would introduce a real error. **Document the conversion**; do not touch
   the numbers.

3. **`NaN` is silently unbounded** (`length > NaN` is never true). Narrower than
   1; cover it in the same validation guard.

**It is `??`, not `||`, and that decides the fix.** Under `|| 50` a `0` would
become `50` and undo would work; under `??` it is a genuine zero-length buffer that
shifts off every entry as it is pushed (`:233`). So **validate the input** — reject
`< 1` and non-finite — and do **not** change the `??`, which correctly
distinguishes "not supplied" from "supplied as 0".

**Scope:** every row of that table was executed at 10 writes on a single scalar
leaf. The conversion and the ≤ 1 result are arithmetic on buffer length and should
hold generally, but were not re-run across collection or form shapes.

### ~~6f-b. Does ST2029 fire on a collection that is never written?~~ — MOOT

ST2029 and the location-exclusion model it advised were retired from v15. The
material below is historical evidence only and must not drive new work.

Not a finding; not measured. The retention refinement showed that an untouched
collection is shared by reference between entries, so a wide-but-never-written
collection costs almost nothing. ST2029's message models retention as
`entries × width` and its text says "every write to those collections is
O(collection)".

If the **trigger** uses the same `entries × width` model rather than tracking
which collections were actually written, it will fire on a collection that is wide
and idle — a false positive that advises `recordHistory: false` on something
already free, and pushes users to exclude data from undo for no gain. Read the
trigger before rewording the message; whoever takes 6d owns this.

### 6g. Shipped `.d.ts` files carry no JSDoc

Found while checking whether `maxHistorySize`'s documented `@default 50` reaches
consumers. It does not. `removeComments: true` in `tsconfig.lib.prod.json` strips
every comment from declaration emit, so an IDE hover shows
`maxHistorySize?: number` with no description and no default. `core/src/lib/types.ts`
has 476 JSDoc lines; the shipped `types.d.ts` has 0.

All seven packages checked: **core, shared, ng-forms, guardrails, schema** set the
flag and ship 0 JSDoc lines; **events and realtime** do not and retain theirs. A
five-of-seven inconsistency rather than a policy, and the two that omit it show
the intended behaviour — so the fix is to drop the flag from the other five.

This is a discoverability defect out of proportion to its size: the library's
answer to "why would an agent reach for SignalTree" leans on the API being
self-describing, and today every hover in five of seven packages is bare.

**Needs its own gate — nothing existing catches it.** `bundle-budget` measures
built JS and does not look at `.d.ts` at all; `api-surface` compares symbol
inventories, not comments.

### 6g — FIXED 2026-08-11 (second attempt; the first was reverted)

**The root cause is that one config drives both emits.** `removeComments: true`
sat in the same `compilerOptions` as `declaration: true`, so it stripped `.d.ts`
and `.js` together. That is why dropping it fixed declarations and polluted the JS
in a single move.

**The fix: strip comments in the rollup output, not in the tsconfig.** A
`signaltree-strip-js-comments` plugin (`renderChunk`) in
`tools/build/create-rollup-config.mjs` removes comments from emitted JS, and
`removeComments` is gone from all five package tsconfigs so declarations keep their
JSDoc. Result: 0 comment-carrying JS files and fully documented `.d.ts` —
core 0 → 2,973 JSDoc lines shipped, 75% of source retained.

**Why this succeeded where the first attempt failed.** The first attempt stripped
JS in npm's `postbuild`, which held after `npm run build` and broke the moment
`verify-gates.mjs` built `dist/` with nx directly and skipped the hook. A rollup
plugin lives in the **build graph**, so every path that produces JS produces
stripped JS. The invariant stopped being build-path-dependent.

**A viability risk that turned out not to exist.** The concern was that
`compilationMode: "partial"` (set in four packages) means ngc emits Angular
declaration metadata a plain declaration pass would lose. MEASURED: **zero** `ɵ`
metadata in any shipped `.d.ts` and **zero** `ɵɵngDeclare*` in any built JS,
because every package builds with `@nx/rollup:rollup` — ngc never runs.
`compilationMode: "partial"` is **inert config in core, ng-forms, events and
realtime**, and declarations were already plain-TypeScript output. Worth deleting
or honouring deliberately; filed separately below.

**Gate: `declaration-docs` + `declaration-docs:self`, both mutation-proven.**
`tools/check-declaration-docs.mjs` compares source JSDoc blocks against shipped
`.d.ts` blocks per package. Two design points that each cost a cycle:

- The invariant is a **ratio, not "not zero"** — `stripInternal` removes whole
  declarations so no package ships 100% (measured 72%–98%); the floor is 50%.
- A `needsBuild` gate must mutate a **built** file, and the harness replaces only
  the **first** match. Mutating schema's tsconfig was reported BLIND (dist is built
  before the mutation lands); blinding one `/**` of guardrails' 106 was also blind.
  `generate: () => ''` on the built `.d.ts` is what works.

**Cost, recorded because no gate measures it** — five tarballs grow 11–36%:

| package    | before  | after   |
| ---------- | ------- | ------- |
| core       | 114,732 | 156,382 |
| shared     | 4,440   | 5,884   |
| ng-forms   | 26,403  | 32,138  |
| guardrails | 14,002  | 15,465  |
| schema     | 11,544  | 13,977  |
| events     | 55,209  | 55,209  |
| realtime   | 8,620   | 7,848   |

This is **install weight, not bundle weight**: consumers bundle these and their
minifier strips comments regardless, and `bundle-budget` is unchanged.

**Still open, both independent of 6g:**

- **`events` has its own `rollup.config.mjs`** and does not use the shared factory,
  so the strip plugin does not apply — 20 of its JS files still ship comments. Not
  a regression (it never set `removeComments`), but its tarball is the one that
  did not improve. Either adopt the shared factory or export the plugin to it.
- **`angular-compat` silently depends on built JS being comment-free.** It detects
  APIs with `text.includes(api)` over whole files
  (`check-angular-compat.mjs:113`), so a doc comment merely NAMING
  `@angular/forms/signals` reads as an import of it. It **fails closed** — it can
  produce a spurious red but never miss a real violation — so this is a latent trap
  rather than a correctness bug. Cheap fix: strip comments from the text before
  matching. The defect is the unstated coupling, not the detection direction.
- **`compilationMode: "partial"` is inert** in four packages (see above).

## 7. Delete the parity framing from time-travel guidance

Nothing in our docs should reason from what competitor libraries do. Their constraint was
snapshot cost per write, which 13.5.0 removed. That framing is how `pauseRecording`
arrived with a rationale that does not work.

`docs/guides/time-travel-in-production.md` also argues you can run `restoration()`
in production because recording is cheap. True and beside the point — whole-tree
undo reverts things the user never did. Rewrite around scoped, marker-declared
undo.

## 8. Capability matrix: two structural jobs

- **Split the grid** on the line already marked with †: architectural (a consumer
  cannot add it) versus convenience API (any library composes it). The unmarked
  rows are the real comparison.
- **Single-source it.** `docs/compare/capability-matrix.md` and the demo's typed
  `CapabilityRow[]` disagree by eight rows, and the demo openly declares the
  markdown stale. Generate the markdown from the typed data.

## 9. RFC 0008 needs an item-by-item check

[0008](docs/rfcs/0008-post-13.3-open-items.md) is the post-13.3 open-items list
from 2026-08-04; three releases have shipped since. Most is probably done, but
marking it executed without checking each item is how 0012 came to claim it had not
shipped when it had.

## 10. Planned-lifecycle marker classification before any more parity work

The construction substrate is now proven across the major writable families:

- plain writable state
- `status()`
- `stored()`
- `entityMap()`
- derived non-authoring semantics

Two consequences are decided.

**1. `plannedSignalTree().derived(...)` is builder debt, not runtime debt.**

Derived state is already semantically correct under the causal runtime: source
writes record one canonical effect/turn/frontier move, derived recomputation
records none, and undo restores the source while derived values come back only
through reactivity. What is still missing is the PLANNED construction surface.
The greenfield builder needs a configuration-phase `.derived(...)` that installs
derived computations before exposure while requesting NO causal capability.

**2. Do not auto-migrate the remaining markers. Classify them first.**

Use these buckets:

- **A. State authors** — authoritative application-state mutations. These need
  planned specialization and, when requested, the canonical mutation substrate.
- **B. Reactive consequences** — derived/validation/aggregate projections. These
  may need planned construction, but they must not author turns/frontiers/history.
- **C. Controllers/resources** — async orchestration, loaders, freshness,
  invalidation, external lifecycle. Decompose into state + consequence + control
  rather than preserving a monolithic legacy marker by default.

Current classification from the code as it exists:

- **`compared()`** — A scalar writable LEAF variant, not a new family. It only
  swaps leaf equality (`signal-tree.ts` intercepts it before marker processing),
  so it rides the plain writable substrate rather than demanding separate planned
  lifecycle work.
- **`form()`** — mixed legacy composite. `values` are authoritative domain
  state and causal candidates. `touched` is WRITTEN interaction state, but it
  is not a default causal-history participant under the greenfield model.
  `dirty`, `valid`, `errors`, `errorList` are reactive consequences; wizard,
  submit, persistence and the old history facade are controllers around that
  state. Keep it off the greenfield critical path — Angular Signal Forms is
  still the destination, so it should not shape the substrate.
- **`asyncSource()`** — controller/resource abstraction with authored visible
  data plus status (`loading`/`error`) around an external loader. It captures
  visible value for undo/restore but declines `rehydrate`, which is exactly the
  smell of a resource/controller split rather than a pure state family.
- **`asyncQuery()`** — controller/resource abstraction. Its `input` is authored
  state, but results/load/error are source-driven query lifecycle, and the marker
  snapshots value without restoring it. Treat it as orchestration around state,
  not as an automatic causal-state family.
- **`entityMap` loader surface** (`loader()` / `entity-loader.ts`) — controller
  attached to an already-proven state author. The collection rows remain bucket A;
  freshness, invalidation, persistence, and revalidation policy are bucket C.

After this classification pass, the next substrate gate is the mixed-family
falsifier, not more marker-by-marker parity. Use one turn spanning scalar,
`entityMap` rekey, `status()`, and `stored()`; require one PositionRegistry, one
capture runtime, one causal representation, no fake common owner, and no
family-specific branching in the rollback engine.

## 11. Producer/mutation substrate is strategically proven; stabilize before kernel work

The mixed-family success/refusal pair is the final producer-side falsifier.
Freeze these as established invariants and stop adding producer parity work.

Established invariants:

- Producers emit CANONICAL semantic effects, not feature-specific history
  records.
- One turn may span heterogeneous state families without introducing
  family-specific rollback semantics.
- Rollback removes only the rejected turn's surviving speculative
  contribution.
- Legitimate later writes survive.
- Structural dependency can make compensation unsafe, in which case rollback
  refuses atomically.
- Persistence follows surviving state; it is not an independent causal author.
- Subject identity, ownership identity, and physical path remain distinct.

Current proof status:

- capability planner — GREEN
- planned lifecycle — GREEN
- tree-local Position topology — GREEN
- plain producer — GREEN
- `status()` producer — GREEN
- `stored()` producer — GREEN
- `entityMap()` structural producer — GREEN
- derived non-authoring — GREEN
- mixed heterogeneous turn — GREEN
- surgical mixed rollback — GREEN
- unsafe mixed rollback refusal — GREEN
- family-independent rollback engine — GREEN

Next phase is STABILIZATION, not more producer work. Close it in roughly this
order:

1. Remove benchmark semantic switches from production paths; keep only one
   production topology/capture semantics.
2. Resolve the known full-suite failures, including the deferred scalar-frontier
   failure.
3. Get lint green.
4. Keep the corrected `maxHistorySize` meaning: capacity `N` retains `N`
   reversible turns and therefore up to `N` undo operations. Update docs,
   migration notes, and changelog rather than restoring the old `N-1` defect.
5. Replace silent cleanup `catch {}` paths with observable cleanup failure
   reporting that does not mask the primary operation failure.
6. Classify/fix the environment-specific stored test failures so the suite can
   go green.
7. Keep `plannedSignalTree().derived(...)` recorded as construction/API debt;
   it is not a blocker unless removing the legacy builder path requires it.

Only after that green checkpoint, design a greenfield `CausalRuntime` rather
than extracting pieces from `TimeTravelManager`. The frozen contract for that
next phase is [causal-runtime-contract.md](docs/architecture/causal-runtime-contract.md).

Kernel sketch to preserve:

- `CausalRuntime`
- `PositionRegistry`
- `TurnStore` — pending turns, confirmed turns, indexes, retention, redo
  truncation
- `Frontiers`
- `Attribution` — transaction/turn grouping
- `ReversalEngine` — historical undo, speculative rollback, supersession,
  dependency/conflict classification
- `Authority` — containment and prefix/frontier eligibility

Consumers/projections after the kernel:

- `transactions()` — speculative lifecycle projection
- scoped undo/redo — confirmed-turn reversal projection
- `restoration()` — causal projection plus separate temporal snapshot
  projection
- DevTools — inspection projection
- provenance — inspection/query projection

Preserve the semantic distinction between speculative rollback, historical
undo, and temporal rewind even if they share representation under the kernel.

## 12. Document composition patterns on top of the v15 kernel

Not a kernel-API proposal. A recurring question in consumer migrations
(TruckTrax v3's, most recently) is "how do I build staged editing / server
reconciliation / optimistic UI / a loading indicator on v15" when the answer
is "compose existing primitives," not "wait for a new marker." Some consumers
misread a deliberate retirement (`loader()`, `asyncSource()`, `stored()`,
`status()` — all closed, see `STORED-RETIRE-0`/`LOADER-RETIRE-0` and the
`status()` A3-0 disposition in `docs/architecture/v15-production-surface-audit.md`)
as a gap rather than a decided design.

**⚠️ CORRECTED after writing this item, before acting on it — read this first.**
[`docs/guides/composition-recipes.md`](docs/guides/composition-recipes.md)
already exists, is already titled "patterns that need no new API", and ALREADY
covers 3 of the topics below: a standard enhancer policy (§1), a reusable
entity-CRUD Ops base (§2), and a selection read-model (§3). Its provenance note
traces to the SAME real consumer this item's motivating discussion was about
(three apps, twelve admin domains — `docs/audits/2026-07/v3-consumer-reuse-audit.md`).
Do **not** create a new `docs/patterns/` directory — it would duplicate this
file. Add the genuinely new patterns (staged editing, server reconciliation,
one-shot vs. persistent loading, optimistic UI, causal explanation) as NEW
NUMBERED SECTIONS in `composition-recipes.md`, following its established
format (`## N. Title`, **The need:**, **The recipe**, code blocks, an
optional "Why this isn't in core" close) — not the PROBLEM/OWNS/COMPOSITION
template floated below, which was designed before this file was found. Treat
the template as source material for section CONTENT, not a file-structure
mandate.

**Also found while checking for overlap:** `docs/guides/persistence-guide.md`
is stale — four lines, says only "keep persistence in application-owned
services... through ordinary state or `entityMap()`", and never mentions
`link()` at all, despite `link()` being the kernel's own recorded successor
for the persistence half of `stored()`'s retirement (`STORED-RETIRE-0`'s
decomposition: state + `link()` + persistence policy). This is the same class
of doc-staleness already flagged for `migration-v14-v15.md` elsewhere in this
repo's history — fix it in the same pass as writing the new
`composition-recipes.md` sections, since the new "Persistence" section and
this file will otherwise say two different things.

**Design filter — apply this before adding anything else to the catalog below,
and before any future kernel API discussion prompted by an unmet pattern:**

> If an important application problem can be expressed cleanly from existing
> SignalTree semantics, document the composition before inventing a new API.
> A pattern should become a kernel capability only if repeated implementations
> reveal a semantic property that applications cannot safely own themselves.

This is the same ownership-ratchet logic that already closed `status()`/
`loader()`/`stored()` (ordinary state + Ops/endpoint + `external()`/`link()`),
generalized into a standing rule for the next ten patterns instead of
re-litigating it per-marker.

### Fixed page structure (every `docs/patterns/*.md` file)

```text
PROBLEM
WHAT SIGNALTREE OWNS
WHAT THE APPLICATION / ENDPOINT OWNS
COMPOSITION                    (plain before/after or layered diagram, no code)
WHY THE CAUSAL MODEL HELPS
WHAT SIGNALTREE DOES NOT GUARANTEE
COMPLETE EXECUTABLE EXAMPLE    (a real spec/demo citation — never invented code)
```

The last section is load-bearing: a pattern doc whose example doesn't run as
a real test is aspiration, not architecture evidence. Cite an existing spec
where one already demonstrates the shape; where none exists yet, that's its
own TODO item (add a real spec first), not a reason to write fabricated
example code.

### Catalog and disposition

| Pattern                           | Document?                         | New kernel API?                            |
| --------------------------------- | --------------------------------- | ------------------------------------------ |
| Staged/draft editing              | Yes — canonical                   | No                                         |
| Server reconciliation             | Yes — canonical                   | No                                         |
| One-shot async loading            | Yes — canonical                   | No                                         |
| Persistent remote relationship    | Yes — canonical                   | No (existing `link()`)                     |
| Persistence                       | Yes — canonical                   | No (existing `link()`)                     |
| Optimistic UI                     | Yes — canonical, worded carefully | No                                         |
| Human-readable causal explanation | Yes — canonical (projection)      | No (tooling, not kernel)                   |
| Agent/human attribution           | Experimental pattern only         | Not until attribution ownership is settled |
| Cross-tree atomic transactions    | No canonical claim yet            | Unproven                                   |
| Generic reconciliation framework  | No                                | No                                         |
| v14 compatibility layer           | Migration docs only               | No                                         |

### Per-pattern content notes

File names below (`staged-editing.md` etc.) are the ORIGINAL, now-superseded
plan — read them as "the staged-editing section", "the server-reconciliation
section", each landing as a new `## N.` section in `composition-recipes.md`
(current sections: 1 enhancer policy, 2 entity-CRUD Ops base, 3 selection
read-model — already written, do not duplicate). Everything else below
(anchors, wording cautions) still applies verbatim to the section content.

- **`staged-editing.md`** — canonical state → application-owned draft →
  validation/review/edits → one intentional commit into canonical state →
  optional restoration designation. SignalTree does not need to understand
  "draft" as a concept; it needs the eventual commit coherently classified
  (an authored turn) once it lands. Do **not** propose a `beginStage()`/session
  API — the entire point of the doc is that this is expressible today without
  one. Executable-example candidate: `transactions()`'s pending/confirm/
  rollback shape (`packages/kernel/src/enhancers/transactions/transactions.spec.ts`)
  demonstrates the "held, then one commit" half; the pure UI-level draft half
  (no kernel involvement until commit) is now proven by
  `packages/kernel/src/lib/staged-draft-editing-0.spec.ts` — zero tree
  writes/zero restoration growth while drafting, discard leaves history
  untouched, and a multi-field commit is exactly one restoration entry.
- **`server-reconciliation.md`** — remote/server truth → endpoint/domain
  reconciliation policy (server wins / client wins / merge / conflict
  detection / rebase / retry / staleness / auth — all application-owned) →
  accepted external truth → tree via `external()`/`link()`. SignalTree's only
  job: accepted truth is never confused with authored application work.
  Executable-example anchors: `packages/kernel/src/lib/internals/causal-runtime/pending-rollback-composition.spec.ts`
  and `structural-pending-rollback-composition.spec.ts` (rejection/rollback
  half), `link-persistence-conformance.spec.ts` (accepted-truth landing half).
- **`one-shot-loading.md`** vs **`persistent-remote-state.md`** — two
  separate recipes specifically so neither `loader()` nor `asyncSource()`
  reads as "missing" (both were deliberately retired with no replacement
  primitive — see `v15-production-surface-audit.md`'s final disposition
  ledger). One-shot: request → fetch → accepted external result → tree, no
  `link()` required merely because HTTP exists. Persistent: tree ↔ `link()` ↔
  endpoint ↔ HTTP/storage/websocket, with loading/error/freshness/retry/
  caching/SWR named explicitly as application/framework/endpoint policy unless
  they are themselves domain state. Executable-example anchors:
  `packages/kernel/src/lib/link-0-three-directions.spec.ts`,
  `link-1-relationship.spec.ts`.
- **`persistence.md`** — same `link()` shape as `persistent-remote-state.md`,
  endpoint = storage. Executable-example anchors (already exist, direct hit):
  `packages/kernel/src/enhancers/serialization/persistence-as-link-swap-0.spec.ts`,
  `packages/kernel/src/lib/link-persistence-conformance.spec.ts`,
  `persistence-decompose-0.spec.ts`.
- **`optimistic-update.md`** — word this carefully: teach the authority
  separation (user intent → authored local transition → external request →
  server acceptance/correction → external truth enters tree). Do **not**
  promise an "automatic optimistic rollback" primitive that doesn't exist —
  what happens on rejection is domain policy. `transactions()`'s own doc
  already says as much ("pending authority, not a synonym for retained undo
  history"); this page is the applied version of that warning.
- **`causal-explanation.md`** — compact causal facts → resolve stable
  identities → application/domain metadata → projector → human-readable
  sentence. Core teaching point, stated explicitly: human/AI-readable
  explanation is a PROJECTION of causal truth, not the kernel's physical
  storage model — the kernel does not store names, prose, timestamps, actors,
  or event objects internally. Defensive value: tells an AI reader not to
  assume that shape exists inside the kernel.

Deferred (record here, do not create files yet): `websocket-server-truth.md`
(experimental — SSE/WS-as-`link().subscribe` needs its own worked example
first), `agent-authored-work.md` / `collaborative-state.md` / `offline-editing.md`
(no canonical claim yet per the disposition table above).

### Sequencing

1. ~~Staged editing and server reconciliation sections first~~ — DONE
   (`72574f2c`, `6909e2b2`): `composition-recipes.md` §4 (optimistic writes +
   server reconciliation, anchored to `transactions.spec.ts`'s pinned
   rollback-isolation case) and §5 (staged/draft editing — no new API,
   explicitly declined a `beginStage()` session).
2. ~~Executable-example specs~~ — DONE. §4: already-pinned
   `transactions.spec.ts` case. §5's pure UI-level draft half: DONE
   (`packages/kernel/src/lib/staged-draft-editing-0.spec.ts`), and the
   section now cites it. Persistence: see below.
3. ~~Fix `persistence-guide.md`'s staleness~~ — DONE (`6909e2b2`): rewritten
   with the real `link()` decomposition and cited to
   `persistence-as-link-swap-0.spec.ts`/`link-persistence-conformance.spec.ts`/
   `persistence-decompose-0.spec.ts`.
4. ~~One-shot vs. persistent async acquisition~~ — DONE: `composition-recipes.md`
   §6 (one-shot loading, no `link()` needed) and §7 (persistent relationship
   via `link()`, all three PULL/PUSH-IN/PUSH-OUT directions), anchored to
   `link-0-three-directions.spec.ts`'s own design-provenance mapping (the
   literal table the four retired markers collapsed into) and
   `link-1-relationship.spec.ts`.
5. ~~Causal-explanation-as-projection~~ — DONE (`43994750`): §8, diffing
   consecutive `RestorationHistoryEntry.state` snapshots, cited to
   `restoration.spec.ts`. `undoable()` has no payload parameter — verified
   against `undoable.ts`/`restoration.ts` before writing the example, after an
   initial draft wrongly assumed one.
6. ~~Demo site linking~~ — DONE (`97a67f06`): both guides copied as
   `apps/demo` build assets and added to the Documentation page's existing
   package-README viewer. **Still open, deliberately deferred, not a doc-wiring
   fix**: `transactions()` (optimistic/reconciliation), staged/draft editing,
   and the causal-explanation pattern have no demo-app _component_ of their
   own — only `link()`/`external()` do, via `async-demo` and
   `restoration-demo`. Real new-component work; scope and schedule separately.

## 13. Re-wire `llms.txt` into the publish pipeline — precondition now met

`RELEASE-1.0.md` § "AI DISCOVERABILITY" deleted the old `apps/demo/public/llms.txt`
mid-v15 on purpose (`7696225d`): stale AI guidance teaching deleted APIs is
worse than none, so it was greenfielded only after the surviving public
surface freezes — an explicit `DEFERRED OBLIGATION`, not a permanent removal.
Phase 7's gate closed this session (`GATE F` satisfied, surface frozen) —
that precondition is now met.

A **new** `llms.txt` (repo root, not the old `apps/demo/public/` path) already
exists and is being kept current alongside real feature commits (edited
today). It is NOT wired to publish: `scripts/prepare-publish-artifacts.mjs`'s
`COPIES` array is deliberately `[]` (with a hard-fail guard specifically
written to catch a silent skip like the one that motivated this script in the
first place — see its own doc comment). Nothing currently copies the new
`llms.txt` into `dist/packages/kernel` before `npm pack`, and
`packages/kernel/package.json`'s `files` whitelist (`dist/**/*.js`,
`dist/**/*.d.ts`, `README.md`, `LICENSE`, `NOTICE`) has no entry for it
either — both need an entry, matching the old three-copies-of-a-conditional
shape this script replaced.

**Concrete motivating evidence, not hypothetical:** a consumer-migration
session (TruckTrax v3, this session) spent real time chasing a `computed()`
staleness bug that traced back to constructing the tree via
`@signal-tree/kernel`'s `signalTree()` instead of `@signal-tree/angular`'s —
exactly the fact `llms.txt` states and `packages/kernel/README.md` also
already states (line 6: "Angular applications should construct trees through
`@signal-tree/angular`"). The README fact WAS shipped and wasn't consulted
closely enough; `llms.txt` is written for exactly this retrieval-aware-agent
case and currently isn't shipped at all. Also worth deciding in the same
pass: should `docs/guides/composition-recipes.md`/`persistence-guide.md`
(TODO §12) ship the same way, or stay repo-only? They're a different class
(prose recipes, not a machine-oriented manifest) — needs its own call, not an
assumed "yes" just because `llms.txt` gets wired back up.

Do this as its own release-discipline slice per `AGENTS.md`'s normal
per-item procedure (characterize → smallest fix → focused validation via
`scripts/verify-publish-artifacts.mjs`/`node tools/verify-tarball-consumer.mjs`
→ one commit) — not folded into unrelated work, given `prepare-publish-artifacts.mjs`'s
own history of exactly that kind of change going unnoticed.

## 14. Pre-GA v15 closure: semantic discoverability and causal representation

`RELEASE-1.0.md` Phase 7 holds GA for these two bounded rows. RC9 verification
remains immutable evidence; neither row may add public API, causal facts,
compatibility layers, framework abstractions, speculative agent metadata, or
Studio/Relay concepts to the kernel.

### `AI-SEMANTIC-DISCOVERABILITY-0` — CLOSED

Close the shipped teaching surface before first GA from one canonical source
reachable through every primary package surface. It may be deterministically
copied/generated into package artifacts or reached through package READMEs, but
must not become three independently maintained `llms.txt` documents. Make the
root, kernel, Angular, and React READMEs teach the canonical model and facade
rule; complete composition, persistence/`link()`, and causal-explanation-as-
projection guidance; and prove packed documents and documented imports with
permanent gates. The demo tests teachability. TruckTrax tests that the prescribed
Angular composition is natural in a real consumer; it does not define kernel
semantics.

The canonical positioning must make all of the following unambiguous:

```text
IS:     framework-independent consequential application state, stable subject
      identity, authored versus external authority, coherent operation
      boundaries, causal/restoration semantics, and link-based relationships

IS NOT: primarily an undo library, event log, query library, sync engine, or
      persistence framework

Angular application             -> @signal-tree/angular
React application               -> @signal-tree/react
framework-neutral TypeScript    -> @signal-tree/kernel
```

The deterministic documentation assertions must reject these false readings:
SignalTree is primarily undo/history; `link()` is a generic internal linking
engine; persistence was removed entirely; every causal turn stores actor,
timestamp, or prose; all external writes are history; or framework applications
should mix kernel and adapter imports.

**Final disposition (Phase 7).** The root `llms.txt` is the sole canonical
semantic manifest and is deterministically copied into all three primary
tarballs. Each package README links its co-packed artifact. The permanent
`semantic-discoverability` gate and its self-test enforce canonical positioning,
facade imports, `link()`/persistence composition, external authority, causal
projection, package reachability, and the absence of stale v10-current guidance
contradictions. Packed-document/import/symbol checks, strict `bundler` and
`node16` consumers, demo test/build, V3's 79-project gate, and the exact
73/73 release matrix are green. Independent phase-boundary review found no
blocker. `AI-SEMANTIC-DISCOVERABILITY-0` is closed; Phase 7 is complete.

### `CAUSAL-REPRESENTATION-0`

**Property:** retain only authoritative causal facts, represented by their
lifetime and access pattern. Human and AI explanations are projections and must
not determine hot-kernel representation.

1. Inventory every FACT, not merely current object fields: its semantic job,
   authority, frequency, lifetime, required retention, derivability, and hot/cold
   access. Record every current carrier and every reader as **REACH**, **READ**,
   or **DISCRIMINATE**. A production reader proves that the fact is live; it does
   not freeze the current carrier. Classify each carrier as semantic,
   restoration-only, delivery-only, cold diagnostic/explanation projection, or
   duplicate authority.

`PositionId` is a **REQUIRED FACT** for restoration targeting, mutation
attribution, and authority. The current per-turn `__positionIds` array is
**NOT FROZEN**: determine whether each reader needs that retained array or
only position identity. Include write context, authored/external
classification, operation/turn identity, mutation intent, SubjectId,
PositionId, structural/entity facts, restoration claims/descriptors, retained
reversal facts, and the causal intersection of `link()`/external ingress.
Exclude observation, snapshot caching, framework realization, and ordinary
structural state unless they carry a causal fact. 2. Repair and mutation-prove `probe-restoration-required-set.mjs` before using it
as baseline evidence. Its fixture must distinguish ordinary undesignated
writes (zero retained restoration turns), one designated turn (one retained
turn), bounded designated turns (exactly `min(N, capacity)`), and external
realization (zero retained turns). It must fail if the fixture's intended
causal work is not retained. Until then, its count/size output is invalid for
representation comparison. 3. Establish the incumbent baseline under the frozen semantic interface. Cover
plain undesignated writes, external realization, designated scalar and
multi-scalar turns, entity mutation/rekey/omission/reactivation, mixed scalar
plus structural operations, retention 0/1/20/100, churn/eviction, undo/redo,
and one- and 100-turn projections. Measure write/operation/undo/projection
latency; bytes per retained turn and claim; high-water and post-GC memory;
observable allocation; and bundle delta. 4. First classify every production reader of retained `__ownerPaths`: whether it
needs stable identity/targeting, a human-readable projection, transient
operation routing, or an historical address after rekey/relocation. Current
location may not reconstruct a correct historical address. Only a proof that
later semantics can resolve the required address without the retained path
makes it a removal candidate. 5. Build small isolated alternatives only where the baseline exposes a plausible
duplication or allocation problem. Candidates share the same semantic
interface and may include compact headers with sparse pools, arenas/indexes,
or numeric carriers. No representation is preferred before measurement. 6. Replace the incumbent only for a material Pareto improvement: a density win
with under 5% hot-path regression, a hot-path win without meaningful density
loss, or a simultaneous gain. A 5-10% regression requires a substantial
density gain; above 10% rejects the candidate unless a frozen semantic law
requires it. "Current wins" is a successful closure result.

Hard controls remain: no restoration means zero restoration-specific subject
slope; configured but unused restoration adds no material subject slope; bounded
history scales with retained restorable work; rare semantics allocate rarely; and
no causal fact exists solely for a human or AI explanation.

#### Current characterization — owner-path carrier deleted

`PositionId` is a required semantic fact. Current restoration readers establish
that targeting, attribution, and authority need position identity; they do not
establish that `CanonicalTurn.__positionIds` is the final carrier, duplication
layout, or retained encoding. Classify the readers before proposing a replacement.

`probe-restoration-required-set.mjs` previously ran a 13-operation mixed script
without `undoable()` designation, then reported zero retained entries as if they
were retention evidence. It now uses 30 designated removals over ordinary seeded
state against 4/6/10/24-turn windows, asserts exact `min(turns, capacity)`
retention, and has explicit ordinary/designated/bounded/external self-controls.
The latest forced-GC oracle run found exact claim sets at every capacity: 4/4,
6/6, 10/10, and 24/24 named/required retired subjects, with correct full
undo/redo traversal. The release-only `restoration-required-set` gate is
mutation-proven by removing the fixture's designation and requiring the probe to
fail. The former mixed sequence throws `Collection structural target contains
contradictory anchors` when actually designated; it is a separate
causal-correctness candidate, not a representation baseline or a reason to
change the causal carrier.

`__ownerPaths` had no production semantic reader: it was retained turn metadata
written once and forwarded through restoration/transaction clones, while
per-effect `ownerPath` remains the distinct causal/reversal addressing fact.
The deletion prototype removed the retained field, all forwarding paths, and
inspection-only test assertions. Restoration, transaction, full kernel, retention
oracle, source typecheck, and packed-consumer checks stayed green. Across three
forced-GC runs of 5,000 independently flushed designated turns, median retained
heap fell from 19,399,224 B to 19,112,736 B: 286,488 B total, or 57.3 B per
retained turn. The kernel's restoration and transaction modules also fell by
754 B and 363 B respectively before compression. `__ownerPaths` is deleted;
the next carrier review is `HISTORY-PROJECTION-FIELDS-0` for `timestamp`,
`action`, `payload`, and `RestorationHistoryEntry` ownership.

`HISTORY-PROJECTION-FIELDS-0` is now closed by product authority. The public
`RestorationHistoryEntry` retains only its restorable `state`; `timestamp`,
human-facing `action`, and optional arbitrary `payload` are deleted alongside
`RestorationConfig.includePayload` and `actionNames`. Internal operation
classification and bounded observed-batch diagnostics remain separate from the
history contract. The type-level public-surface regression rejects all three
former fields and the removed configuration. In three forced-GC comparisons of
5,000 independently flushed designated turns, median retained heap fell from
19,112,896 B to 18,711,104 B: 401,792 B total, or 80.4 B per retained turn.
The restoration module fell another 956 B before compression. Human/AI history
explanation is application/projector/future-tooling work, not retained kernel
history data. `RestorationHistoryEntry` remains public because the state
snapshot has an established restoration-inspection job; its broader deletion is
not implied by this contraction.

`TURN-IDENTITY-0` is closed: `CanonicalTurn.__turnId` duplicated `id` exactly,
had no production reader beyond its declaration and construction, and is
deleted. Internal tests now retrieve canonical identity from `getTurns()` rather
than leaking it through the public history projection. The restoration suite
(106 tests) and source/contract typecheck pass. The accompanying carrier audit
classifies `restorationSubjectIds` as reclamation authority; `__positionIds` as
the index, containment, and prefix-frontier authority; `__effects` and
`__orderDeltas` as reversible facts; `historyIndex` as temporal ordering; and
`__eventOrdinal` as the historical-event retention boundary. Per-effect
`ownerPath` remains a reversal address, while capture-bucket `ownerPaths` has
only settlement-bounded diagnostic lifetime. `WRITE-METADATA-ANNOTATIONS-0`
then closed the only other simple carrier deletion: public ambient
`correlationId` and write-level `timestamp` had neither writers nor production
readers, while persisted audit/devtools clocks are separate facts and survive.
The type contract rejects both fields; the pinned source/contract typecheck
passes. No further retained-turn carrier deletion is justified before the
required baseline identifies a material allocation or density problem; packed
headers, sparse pools, and arenas remain alternatives, not a selected design.

`CAUSAL-REPRESENTATION-0` incumbent baseline is established at `5aa7b3f2`, not
yet a representation-selection result. `node --expose-gc
tools/bench-causal-representation.mjs --samples 5` runs the A0-A1, B0-B2,
C0-C5, D0-D4, E0-E3, and F0-F1 causal workloads. Each arm proves its semantic
postcondition, times its operation separately, then takes five quiesced
retained-heap measurements while holding 20 equivalent live trees and divides
the median by 20. Every measured tree releases after `destroy()`; high-water is
intentionally omitted because allocation is not retained heap. The exact run
at `04049e01` plus this uncommitted harness measured scalar capacity 0/1/20/100
at 26.5/30.1/41.0/96.8 KB per live tree. Matched D0 controls attribute 3.6 KB
for the first retained turn, then 723 B/turn at capacity 20 and 703 B/turn at
capacity 100. Churning 130 turns through a 20-turn window retains 11.8 KB more
than the steady 20-turn arm, despite the same 20 logical turns; that is an
unattributed retained capacity/index candidate, not evidence for an encoding.
One- and 100-turn public history projections measure 26.8 KB and 97.0 KB; the
100-turn scalar arm is 96.5 KB, so this fixture shows no material additional
retained projection/cache cost. Structural, entity mutation, rekey, omission,
reactivation, mixed, reversal, undo/redo, external, and scoped-containment arms
all complete and retain the expected turn/claim counts. `node
tools/size-report.mjs --json` measures the exercised production `restoration()`
bundle delta as +18.38 KB gzip over bare construction; the harness's 12,132 B
restoration-module gzip is only an artifact upper bound, not the consumer delta.
Validation: fresh `pnpm nx build kernel`, full five-sample baseline, restoration
suite 106/106, workspace typecheck, direct harness ESLint, and docs validation
pass. The kernel lint target remains independently red because its unchanged
package manifest omits `typescript` from `peerDependencies`.
Next, attribute the retained window and churn deltas separately to turn
header/index, position participation, subject claims, effects/order deltas,
reversal descriptors, history materialization, and Map/Set capacity before any
one-variable alternative is admitted.

#### `CAUSAL-REPRESENTATION-0 / ATTRIBUTION` — CLOSED: INCUMBENT SELECTED

Checkpoint: `71bf7246`. Validation: full five-sample attribution matrix,
restoration suite 106/106, workspace typecheck, direct harness ESLint, and docs
validation pass.

Questions:

```text
1. Which real retained owners account for the approximately 700 B scalar turn?
2. Why did a 20-turn window retain more after 130 turns of churn?
```

Measure one logical owner at a time through legitimate production workloads:
turn header/history bookkeeping; position participation and indexes; subject
claims; effects/reversal representation; order deltas; historical projection;
Map/Set backing capacity; and eviction/index residue. Do not construct a fake
surrogate, change production representation, or admit a packed/arena/slab
prototype until a dominant owner is proven.

`5aa7b3f2` plus the attribution controls identify the first two owners. D8
performs 20 designated scalar writes at capacity zero; D5 performs the identical
work at capacity 20. Their matched median is 14,869.6 B, or 743.5 B per
retained turn. D5 retains exactly 20 headers/history and turn-index entries, 20
effects, 20 positions/index references, and 20 historical events; it retains no
claims or order deltas. G0/G1 and G2/G3 repeat the same 20 scalar positions
with independent versus coalesced turn boundaries and their matched zero-history
controls. Holding 20 effects and 20 positions constant, 19 extra independent
turns cost 7,878.4 B, or 414.7 B each: a combined turn
header/history/index/event group, not an effect-only measurement.

`OBSERVED-BATCH-DIAGNOSTIC-RETENTION-0` is **CLOSED GREEN**. The only writer
ran after each capture-bucket flush; the only reader was one restoration spec
that already observes the published structural paths through `PathNotifier`.
`observedBatches`, its 1,000-entry cap, writer, reader, reset path, and stale
`ownerPaths` capture destructure are deleted from the shipped runtime. The spec
now asserts publication at its real observer boundary rather than reading a
per-tree circular diagnostic log. After a fresh kernel build, the exact
capacity-20 ladder at 20/40/130/1,000 writes retains 38.0/37.9/40.0/43.9 KB
per live tree. The quiesced ranges overlap, all arms retain exactly 20 history
entries, turn-index entries, effects, position references, and historical
events, and `hasObservedBatchLog` is false. The former 1,000-turn result was
156.4 KB with 1,000 diagnostic records. Retained cost now scales with the
bounded restorable window, not total past designated writes. This removes 437
raw and 144 gzip bytes from the restoration module; the separately measured
exercised `restoration()` feature delta falls from +18.38 KB to +18.26 KB gzip.
Implemented in `6ae10bd0` (`perf: remove retained restoration diagnostics`).
Validation: direct restoration suite 106/106; kernel suite 2,157 passed (3
expected failures, 13 skipped, 1 todo); focused ESLint; `npm run typecheck`;
fresh `pnpm nx build kernel`; five-sample 30-arm causal matrix; exercised
feature-size report; `npm run validate:docs`; and clean staged diff. Ownership
census/ledger regeneration removes the stale cap row. The ownership checker
still stops first at its unrelated census-family mutation proof (22 existing
public-symbol rows absent from ownership rows), not a stale diagnostic subject;
keep that infrastructure failure separate from this completed retention fix.

`TURN-BOUNDARY-GROUP-0` is **ACTIVE ATTRIBUTION, NO CARRIER SUBSTITUTION
AUTHORIZED**. Current reader classification: `history[]` owns bounded temporal
order and ordered public history projection; `turns: Map<TurnId, Turn>` owns
O(1) identity lookup used by status and scoped undo/redo closure resolution;
`historyIndex` is a derived/rebuilt performance index, not an independent causal
fact; `historicalEvents` owns reversal/gap facts used to materialize historical
states and cannot yet be derived solely from retained turn order and event
ordinal. Both `history[]` and `turns` therefore have distinct current jobs, but
that does not freeze two independent JS collections as their final encoding.
The next experiment may replace exactly one carrier only after its lookup and
history-order contracts are independently controlled; no packed/arena/slab or
multi-carrier rewrite is authorized.

`TURNS-MAP-READER-FREQUENCY-0` is **ACTIVE ATTRIBUTION, NO ALTERNATE CARRIER
AUTHORIZED**. `turns: Map<TurnId, CanonicalTurn>` is the bounded confirmed-turn
identity resolver, not an ordered traversal store: status, containment,
undo/redo closure expansion and sorting, scoped entry selection, global
undo/redo seed selection, and transition-effect application dereference it;
`getTurns()` is projection traversal and rebuild repopulates the index from
`history[]`. `pendingTurns` is a distinct pending-lifetime resolver. Test-only
production-substrate instrumentation records only confirmed-turn dereferences:
public undo-of-remove performs exactly six at every collection size, while a
100-turn `jumpTo(0)` performs exactly 199 (100 status reads plus 99 transition
effect reads). The lookup job and workload frequency are therefore real and
bounded by active navigation work. First attribute the Map's retained ownership
against these controls; admit one production-shaped alternate only if its
material density cost is proven without collapsing the independent ordered
`history[]` job. `LOOKUP-INSTRUMENTATION-NEUTRALITY` is proven before any
authoritative speed comparison: the stats call is a standalone expression that
the kernel Rollup plugin strips, and a fresh production artifact contains none
of `turnIndexLookups`, `recordProductionSubstrateStat`, or the former
`lookupTurn` wrapper. The separate requirements remain frozen: `history[]`
provides an ordered bounded sequence; identity-addressed turn resolution is a
different job. A future compact carrier may realize both physically, but must
not equate `TurnId` with current array position.

`TURNS-MAP-OWNERSHIP-ATTRIBUTION-0` is **CLOSED — RETAIN CURRENT MAP
CARRIER**. A disposable production-shaped candidate removed only the confirmed
`turns` Map and resolved its IDs from the same retained `history[]`; pending
turns, effects, historical events, position indexes, and frontier state stayed
unchanged. The full 2,158-pass kernel suite proved behavior before measurement.
Matched five-sample, 20-tree quiesced retained-heap controls measured 38,040.8
B/tree incumbent versus 37,064.8 B/tree candidate at 20 retained turns, and
85,214.8 B/tree versus 82,313.6 B/tree at 100: 976.0 B (48.8 B/turn) and
2,901.2 B (29.0 B/turn) respectively. Every held tree released after
`destroy()`. Because both carriers reference the exact same `CanonicalTurn`
objects from `history[]`, those objects are deliberately excluded from the
delta: it is Map/table/key/value-edge ownership only. The exclusive cost is
tens of bytes per retained turn, only about 7-12% of the roughly 415 B
independent turn-boundary group, and therefore not material. No Map carrier
prototype is authorized; keep `Map<TurnId, CanonicalTurn>` for its proven
identity lookup job. The disposable candidate also exposed one incidental
second job: after `history[]` mutates, `rebuildTurnIndexes()` needs the prior
confirmed-ID set to restore frontiers. The Map had supplied it only by
accident; reconstructing that bounded set from the pre-rebuild position indexes
kept all behavior green. Production readers prove a required job, not that the
current carrier intrinsically owns every incidental use.

`HISTORICAL-EVENT-OWNERSHIP-0` is **ACTIVE ATTRIBUTION, ONE CARRIER EXPERIMENT
AUTHORIZED**. `historicalEvents` holds ordered reversal/gap boundaries for
historical state materialization; the fact is independently required and is
not eligible for semantic deletion. Measure only its exclusive carriage by
co-locating each retained boundary event and its following gap events with the
retained turn that bounds them, preserving ordinal order, every effect and
order delta, and a distinct fallback for an event with no retained boundary.
The candidate must pass the full kernel suite, then use matched five-sample,
20-tree quiesced D5 (20-turn) and D3 (100-turn) heap controls. Exclude shared
effects, deltas, and turn objects from the result. Retain the incumbent and
stop if the exclusive carrier delta is not material; no turn-header or
arena/ring work is authorized by this row.

**CLOSED — RETAIN THE SEPARATE EVENT ARRAY.** The disposable candidate
co-located each boundary event and following gap events on the retained turn,
kept event ordinals/effects/order deltas unchanged, and used a distinct fallback
for unbound events. It passed the complete 2,158-test kernel suite. Matched
five-sample, 20-tree quiesced controls instead found the incumbent denser:
38,040.8 B/tree versus 39,477.2 B/tree at 20 turns, and 85,214.8 B/tree versus
93,159.6 B/tree at 100. The candidate cost an additional 1,436.4 B (71.8
B/turn) and 7,944.8 B (79.4 B/turn), respectively; all held trees released
after `destroy()`. This comparison retains the same event facts, effects,
deltas, and turn objects, so it attributes only their carrier layout. The
separate manager array is the lower-density representation under this real
workload; no more historical-event carrier variants are authorized.

`TURN-BOUNDARY-AGGREGATE-0` is **CLOSED — MATERIAL RESIDUAL, NO NEW CARRIER
SELECTED**. D8/D9 are matched zero-retention controls for 20/100 independently
designated scalar writes; D5/D3 retain those same 20/100 turns. Five-sample,
20-tree quiesced comparisons measured 23,197.2 B/tree D8 versus 38,040.8 B/tree
D5, a 14,843.6 B aggregate (742.2 B/retained turn), and 23,419.6 B/tree D9
versus 85,208.8 B/tree D3, a 61,789.2 B aggregate (617.9 B/retained turn). The
20-to-100 marginal retained boundary is 46,945.6 B across 80 turns, or 586.8
B/turn. Each zero-retention control proves zero retained turns, events,
indexes, effects, and order deltas; every held tree releases after `destroy()`.
This is deliberately an aggregate result, not field-size arithmetic: it covers
the `CanonicalTurn` object/header, `history[]` membership, necessary primitive
turn fields, effects, position participation/index references, and required
event boundaries as one real independent operation boundary. With Map exclusive
ownership only 29-49 B/turn and the separate event array already denser than
its candidate, no independent carrier dominates. The residual is material, but
an arena/ring/slab has not been selected or authorized; preserve stable `TurnId`
identity independent of any physical slot if an explicitly authorized compact
carrier experiment follows.

`COMPACT-TURN-STORE-0` is **AUTHORIZED — EXACTLY ONE DISPOSABLE PROTOTYPE**.
Replace only confirmed-turn header/order storage (`history[]` plus its
`TurnId -> CanonicalTurn` index) with a bounded slotted struct-of-arrays store:
primitive columns hold stable turn IDs, temporal order, and event ordinals;
reference columns retain the existing effects, positions, claims, order deltas,
and optional materialization state. Keep the identity lookup requirement,
separate `historicalEvents` array, existing effect/position/claim/delta
representations, and all causal facts. A physical slot is never a `TurnId` or
temporal order; eviction must not let a reused slot resolve an evicted ID.
Add a stale-slot falsifier. Before any production adoption, require the full
kernel suite; retained 20/100-turn D5/D3 and 20->100 marginal controls;
capacity-20 1,000-write eviction; structural/rekey/scoped undo-redo/history
projection; the six-lookup ordinary undo and 199-lookup temporal jump controls;
and production instrumentation absence. Accept only a minimum 100 B/retained
turn or 15% retained-history saving at 100 turns, with no meaningful navigation
regression beyond 5% unless the density win is substantially larger. Also
compare 20 effects in one turn against 20 effects in 20 turns: the independent
boundary gap must shrink materially. Otherwise close `TURN-BOUNDARY-GROUP-0`
with the incumbent and proceed directly to `AUXILIARY-RETENTION-SLOPE-0`; no
second carrier experiment is authorized.

**CLOSED — INCUMBENT WINS; NO SECOND CARRIER EXPERIMENT.** The one disposable
column-backed `CompactTurnStore` held primitive turn ID/order/event-ordinal
columns, existing reference facts in aligned columns, and stable `TurnId ->
slot` lookup. It retained the separate `historicalEvents` array and every
existing effect, claim, position, order-delta, and pending-turn representation.
The new capacity-one stale-slot law proved an evicted ID cannot resolve to a
reused physical slot; all 2,159 kernel tests then passed, and production output
contained no lookup-characterization counter. Five-sample, 20-tree D5/D3
controls measured 39,125.6 B/tree and 83,672.8 B/tree versus the incumbent's
38,040.8 B/tree and 85,208.8 B/tree: the 100-turn saving is only 1,536.0
B/tree (15.4 B/turn, 1.8%), far below both acceptance floors, while the
20-turn case costs 1,084.8 B/tree. Capacity-20 D7 churn saves 3,227.2 B/tree
but its operation median regresses from 6,881.750 us to 11,369.500 us (65%).
The required 20-effects comparison also worsens: one-turn G2 to 20-turn G0 is
7,019.2 B (369.4 B/additional boundary) incumbent versus 7,133.6 B (375.5
B) compact. H0/H1/H2 and E3 remained semantically green in the candidate, but
the density and churn failures are decisive. Retain the current object/array
carrier; `TURN-BOUNDARY-GROUP-0` is closed and compact arena/ring/slab work is
not authorized. Proceed to `AUXILIARY-RETENTION-SLOPE-0`.

History projection has no retained cache in the current implementation:
`getRestorationHistory()` materializes a transient projection and returns copied
entry objects with state by reference. F0/F1 remain latency controls; their
post-GC retained cost must not be attributed to a projection cache unless a
future measurement demonstrates a retained owner.

Pre-registered disposition: if removing or collapsing one derived accelerator
saves less than a material retained-heap amount, or causes more than a 5%
regression in restoration/navigation workloads, it remains intentionally
retained implementation state. `USED BY ALGORITHM` is not causal authority;
the objective is the best measured speed-and-density tradeoff, not maximum
normalization.

`HISTORY-INDEX-ATTRIBUTION-0` is **CLOSED — RETAINED DERIVED ACCELERATOR**.
`historyIndex` is rebuilt solely from `history[]` and holds no independent
causal fact. A disposable real-runtime candidate removed the stored per-turn
field, deriving temporal order through `history.indexOf(turn)` for scoped
closure selection, confirmed undo/redo selection, temporal restoration,
historical materialization, and `jumpTo`; it kept `history[]`, `turns`, and
`historicalEvents` unchanged. Kernel typecheck and 2,157-test suite passed
with the candidate. Matched five-sample D5/G0/H0/H1/H2/E3 controls found only
about 160 B saved for a 20-turn tree and 0.8-1.2 KB for 100 turns. The
decisive 15-sample H2 navigation rerun measured 126.333 us incumbent versus
124.917 us derived, a -1.1% difference within the noisy harness range. The
candidate has no material density win and no demonstrated navigation gain;
retain the O(1) stored index as intentional implementation state. H0-H2 now
permanently cover 100-turn undo, redo, and temporal jump paths; E3 remains the
scoped-containment control. This result does not promote `historyIndex` to
causal authority or freeze its physical carrier.

#### `AUXILIARY-RETENTION-SLOPE-0` — CLOSED: NO UNBOUNDED AUXILIARY SLOPE

**Property:** when retained causal work is bounded, no kernel-owned auxiliary
structure associated solely with that work may retain a material slope with
total past activity unless that history is an explicit semantic capability with
an independently stated contract. A bound unrelated to the semantic owner is
not sufficient evidence of a correct lifetime.

Inventory every long-lived kernel `Map`, `Set`, array, cache, registry, index,
and journal. For each record: semantic job (if any); growth axis (live subjects,
retained turns, current positions, observers, active links, or total past
activity); bound; eviction/reclamation trigger; `destroy()` release behavior;
production REACH/READ/DISCRIMINATE evidence; classification as authoritative
state, derived accelerator, diagnostics, or projection; and whether its
lifetime can be shorter than its current owner. Use existing ownership census
evidence where applicable; do not turn the inventory into a second registry.

Only a suspicious total-past-activity axis or an independent cap tied to a
different lifetime earns a targeted real-workload 20 -> 100 -> 1,000 quiesced
retained-heap falsifier. Diagnostics, tracing, devtools, mutation evidence,
and human/AI explanation data receive the same test: retain on demand or under
their own active capability, never merely because the causal manager lives.
Do not rewrite correctly bounded state, manufacture a broad benchmark, or
promote a derived index to semantic authority merely because an algorithm reads
it. This is the cross-kernel guardrail generalized from
`OBSERVED-BATCH-DIAGNOSTIC-RETENTION-0`.

**Closed provenance inventory.** `historicalEvents` is authoritative temporal
reconstruction state, with growth bounded by the oldest retained or pending
turn event ordinal; eviction calls `pruneHistoricalEventsBeforeOldestBoundary`,
redo truncation filters discarded events, and history reset clears it. Its
separate carrier already won `HISTORICAL-EVENT-OWNERSHIP-0`, so no duplicate
slope benchmark was justified. Global `PathNotifier` subscribers, flush
callbacks, and reset callbacks are scoped to their subscribing owner:
`restoration()` and `transactions()` unsubscribe every registration through
`tree.registerCleanup`, `devTools()` does the same through
`disconnectDevTools`, and explicit `link()` / diagnostic-journal resources own
their public `dispose()` handles. The composed cleanup characterization proves
that restoration + transactions + DevTools add three subscribers and return to
the prior global count after `tree.destroy()`. DevTools' global group and
connection registries delete both entries when the last registered tree leaves.
Other process-level diagnostics are either explicitly owner-disposed
(`onTreeError`), registration-time extension state (`MARKER_PROCESSORS`),
WeakMap metadata, or bounded (`ENTITY_ARRAY_WARNED`, cap 256). None grows with
past causal activity or outlives its stated owner, so the 20 -> 100 -> 1,000
heap falsifier did not apply. `OBSERVED-BATCH-DIAGNOSTIC-RETENTION-0` remains
the only identified auxiliary retention defect in this closure.

**Final disposition (`8aa9591d`).** The frozen causal interface now has a
measured incumbent selection: retain the current bounded object/array turn
carrier, confirmed-turn `Map`, stored `historyIndex`, and separate
`historicalEvents` array. The only unbounded sidecar was
`observedBatches`, which is deleted. No alternate carrier crossed the
pre-registered material density and hot-path thresholds: the one authorized
compact-store experiment saved only 15.4 B/turn at 100 turns, lost at 20 turns,
and regressed bounded churn by about 65%. The retention provenance audit found
no additional total-past-activity slope. `CAUSAL-REPRESENTATION-0` is closed;
the remaining Phase 7 hold is `AI-SEMANTIC-DISCOVERABILITY-0`.

#### `OWNERSHIP-CENSUS-GATE-0` — ACTIVE, SEPARATE PRE-GA GATE INFRASTRUCTURE

`node tools/check-kernel-ownership.mjs` currently stops in its census-family
mutation proof because 22 existing public-symbol rows have no ownership rows.
This did not falsify `OBSERVED-BATCH-DIAGNOSTIC-RETENTION-0`: regenerated census
and ledger evidence remove that deleted subject cleanly. Establish whether the
checker encodes a stale/incomplete census domain or those symbols require real
ownership declarations; repair the checker or ledger accordingly, then
mutation-prove the result. Do not manufacture classifications merely to satisfy
the mutation machinery, and do not mix this gate work with causal attribution
or `KERNEL-TYPESCRIPT-PEER-POLICY-0`.

#### `KERNEL-TYPESCRIPT-PEER-POLICY-0` — QUEUED, SEPARATE PACKAGE POLICY

`pnpm nx lint kernel` is red because dependency-check asserts that the kernel
package should list TypeScript in `peerDependencies`. First determine whether a
consumer actually requires a compatible TypeScript installation for the shipped
runtime and declaration contract to function. If not, repair the dependency
check policy or allowlist; `.d.ts` files alone do not create a runtime-neutral
peer dependency. If yes, prove the consumer requirement before changing the
published manifest. This row must not be mixed with causal attribution.

### Sequence

1. Finish immutable RC9 verification.
2. Complete `AI-SEMANTIC-DISCOVERABILITY-0`.
3. Complete `CAUSAL-REPRESENTATION-0`.
4. Run demo, TruckTrax, and existing semantic/performance/memory controls.
5. Freeze the selected representation, cut a final RC, and repeat strict real
   npm-consumer proof.
6. Request the explicit human decision to publish `15.0.0` GA.
