# Current work — incumbent v16 readiness

Updated October 25, 2026. Branch `codex/v16-incumbent-readiness`.
Baseline: `8d220643e0d4e34cbdbc6e55e6ef692b25d5e023`.
Accepted new-key runtime checkpoint: `9917c92fbbdc9dfdd14601f1f5fb7ce21799be71`.
Version **16.0.0-dev**. **Not release-ready; no final candidate freeze yet.**

## Scope and authority

Complete the finite incumbent release contract and its required verification.
No release, merge, push, activation, tag, publication or unrelated architecture
change. B's replacement track is closed at `17e1a76f` and is not a repair queue.
Original checkouts, rejected checkpoints and first-failure evidence are preserved.

Owner decisions:

- Ordinary whole-value writes may create supplied new keys. Internal inspection
  replay retains its separate unknown-key policy; stable v15 remains unchanged.
- Four new-key artifact ceilings are approved and verified. This is artifact-cost
  acceptance, not performance neutrality or release readiness.
- Owner-authorized string-Record migration: arbitrary direct access is unknown;
  known/hybrid children and whole-value writes retain their types. The reviewed
  type-only patch is applied. No lookup export or deferred-handle runtime is added.
  Other index-signature forms remain outside this bounded migration.
- Conditional Link progress may use explicit complete publication ownership
  declarations; the application owns hidden-input omissions. This approves the
  contract direction, not an API or implementation. Undeclared writes retain the
  conservative hold; conditional progress still requires implementation evidence.
- Documented newest-open-first settlement is v16 scope: atomic retryable refusal,
  retained authority, useful retry, truthful inspection/errors and independent
  progress remain required. Server reconciliation policy belongs to applications.
  Arbitrary-order surgical success and canonical authority projection remain
  preserved advanced capability targets, not claimed release capabilities.

## Current acceptance checklist

[Reconciliation and exact evidence](docs/audits/2026-10-17-incumbent-readiness/reconciliation/README.md)
are the current detailed disposition. The original
[inventory and row classification](docs/audits/2026-10-17-incumbent-readiness/README.md)
remain historical evidence at their stated source.

| Item | Status | Next acceptance requirement |
| --- | --- | --- |
| Whole-value new keys / capture | Complete for checkpoint | Preserve passing retention, reentry, recovery, inspection and four-framework controls |
| Artifact cost | Prior new-key cost approved; current two entity budgets fail | Current measured bytes need separate disposition; ceilings unchanged |
| String-Record direct access (K2 bounded migration) | Reviewed typing patch applied; source hashes match verified copy | Unknown arbitrary access, known/hybrid children and whole writes preserved; migration guidance saved; no lookup/deferred API implemented |
| Two composed-restoration failures | Repaired at `87f6831f`; reviewed and broader affected checks pass | Preserve first failures and controlled capture limitations; final release verification remains pending |
| Independent Link progression | Supported blocker; location-disjoint experiment `927ee0d8` rejected and reverted | Reactive copies need dependency evidence; safe gate retained; no new provenance architecture authorized |
| Stronger semantic matrix | Scope disposition recorded, not passed | Preserve 188 held / 68 violated / 168 unsupported record and test supported public contract separately |
| Final exact-SHA qualification | Not yet eligible | Close supported blockers, freeze source, then complete required verification |

## Isolated slice 5 qualification candidate

[Combined slice-4 evidence and independent review](docs/audits/2026-10-17-incumbent-readiness/slice4-combined-qualification/README.md)
qualify this isolated branch for full verification. Its runtime is experimental and
must not replace production 87f6831f without final acceptance. The source manifest
644c6c2c9d7b324d92f86128ecb4b44d6e762f97fccb708d5cf8db84d857a3ba
covers 809 TS/TSX files before an EOF whitespace correction (recorded separately).
Exact committed SHA and all full-check outputs are recorded in
/private/tmp/slice5-qualification. No activation, version or budget change.

Prior 78 native files: 1,060 passes / one preserved contract mismatch; additional
13 native files: 166 passes. Four frameworks: 274 passes, including eight new
declaration controls. The registered retention-gc gate passes. The 141 declaration
contract checks exclude the misuse demonstration. Original 32/34 verdicts retain
exact source/results and approved reconciliation. Retained/dropped receipt probes
collect 20/20 each with useful sends and a live control. These
bounded results do not substitute for full suites, artifacts or measured costs.

## Slice 3 realization qualification — bounded gate closes

[Source, preserved first failures and independent review](docs/audits/2026-10-17-incumbent-readiness/slice3-realization-qualification/README.md)
record the isolated restoration successor. The raw restoration route now carries the
existing paired ordinary/physical preparation through validation and installation.
The ordinary plan installs ordinary authority after physical installation, eliminating
the newly exposed duplicate backing writes without removing divergence or placement.

Final combined 78-file vector: 1,060 passes / one unchanged adjudicated contract
mismatch. Both original 130,000-row restoration controls pass; the first 2N versus N
value-store-write failure remains archived. Types/spec-types pass; three existing lint
warnings remain. Independent public mixed P99/O7 publication, array-identity and
backing-identity probes pass and were replayed by root. This is not CPU superiority.

805-file manifest 6a43358ddc287d4b58b56a0bd5aa83440e901817520ea6c64690196de5e4e648
identifies /private/tmp/restoration-install-successor/candidate. The finite slice-3
gate is reviewed; authorized combined slice-4 framework/declaration/lifecycle checks
continue. Production 87f6831f remains unchanged. Full verification, fresh artifacts,
collectibility and cost acceptance remain separate gates; no activation or release.

## Slice 2 prerequisite qualification — bounded gate closes

[Exact source, first failures and independent gate review](docs/audits/2026-10-17-incumbent-readiness/slice2-prerequisite-qualification/README.md)
record the isolated successor. Missing staged-writer, selection, lifetime, replay and
large-batch checks now execute. Final focused vector: 695 passes / 1 unchanged adjudicated
contract mismatch. Both original 130,000-row shards pass: 11 and 16. Earlier terminated
runs remain incomplete, not assertion failures. No workload/assertion/timeout weakened.

Separately preserved fixes remove first-marker lexical retention and three avoidable
preparation loops: staged-key lookup, sequential ordinary-anchor queries and repeated
pending-subject reconstruction. No new authority or public semantics. Final retained/
dropped-receipt controls collect 20/20 each with useful sends/live control; this is
bounded collectibility evidence. Types/spec-types pass; three existing lint warnings
remain, no new warnings. Earlier 4N versus 2N snapshot tradeoff remains unaccepted as
a production-cost conclusion.

Final 803-file manifest 67869b6525433a7ad5fceb88042cf25b50d2d90d045408a249b2f673aae3caf9
identifies /private/tmp/pending-set-candidate/candidate. Runtime remains experimental;
production 87f6831f unchanged. Independent review supports bounded slice 2 closure;
authorized slice 3 realization/hidden/retirement audit continues. Combined framework/
lifecycle qualification and full verification/artifact-cost acceptance remain gated.
B stays closed; no activation, public API expansion, ceiling change or release.

## Native Link address correction — isolated focused gate improves

[Exact trace, correction, controls and review](docs/audits/2026-10-17-incumbent-readiness/link-native-address/README.md)
close the eight inherited field-Link timeouts. Bare entity fields already carry native
collection position/lifetime/field identity; experimental Link instead bound position
-1 when optional capture metadata was absent. Reusing the native collection position
at all six publication sites restores the matching ticket and existing conservative
fallback. No owner registration, independence grant, flush or production activation.
This corrects the earlier provisional owner-initialization attribution below: the
fallback did run, but there was no matching ticket to authorize.

Combined focused result: **495 passes / 1 preserved contract-mismatch failure**, 496 cases
in 46 files. Final affected delivery checks: 72 passes (overlapping new 10); four facade
checks: 8 passes. Rebuilt unchanged declarations/lifecycle/projection:141 contract passes
plus 1 misuse demonstration, excluded from safety counts. Source typecheck, corrected
spec-types and changed-file lint pass. First failures and original assertions stay
archived. Independent ingress/pending isolation review and root replay pass.

Exact 798-file TS/TSX candidate manifest:
16d33224f969b9e284e61c8affbacd544d1ebfba6397ae69f9a3cb2030008935.
Only link.ts runtime and five new specs differ from the preceding isolated successor.
Production `87f6831f` remains unchanged. Remaining 4N versus 2N snapshot cost, collectibility,
structural/later-slice integration and artifact gates are not waived. No broad
qualification or release sign-off. Historical checkpoint reports below remain valid
at their source; their open Link counterexample is closed only in this new candidate.

## Derive and snapshot successor — bounded corrections survive; integration blocked

[Exact candidate, first failures, reviews and remaining public counterexample](docs/audits/2026-10-17-incumbent-readiness/derive-placement-successor/README.md)
record the isolated successor. Derive footprint now prepares inside the existing
revision guard and carries the same staged physical facts through installation,
capture and publication. Own-property/reference preservation closes the intermediate
staging regression. Explicit replacement adoption remains unchanged. The scoped W2
updater defect is corrected in this candidate; the original slice-1 blanket claim
is not retroactively reinstated.

Final focused union: **477 passes / 9 failures**, 486 cases in 45 files. One unchanged
combined replacement/no-op assertion retains its c0f55f0d contract-mismatch disposition;
eight field-Link omission timeouts reproduce on the predecessor. A minimal ordinary
field control without transactions physically becomes undefined and notifies, but
Link has unknown eligibility and does not settle; with transactions it sends and
settles. Owner initialization is the first discriminator; the exact fallback wait
still needs tracing. No transactions requirement or Link repair is selected.

All four original ordering failures and new derive/reentry/property controls pass.
Snapshot reuse measures **4N**, down from 6N; comparator remains 2N. This is snapshot
work, not CPU or aggregate cost acceptance. Final source manifest:
171d0220bc85054979e88fd11eceea74fc0904f29d4ce033777020ea9c232b9f.
The only delta after the combined run is new-test compatibility/lint correction;
that 14-case file reruns successfully. Typecheck and corrected spec-types pass;
changed-file lint has 0 errors / 3 existing warnings. Original assertions remain unchanged.

Runtime is archived in the experiment only. Production `87f6831f` and the readiness
runtime are unchanged; integration/later slices remain gated. No full qualification,
framework/artifact/cost acceptance, activation or budget change. The historical audit
below retains its exact checkpoint findings; this successor addresses only the
specified derive and duplicate-traversal defects. B stays closed.

## Boundary audit — slice-1 W2 acceptance narrowed; prepend duplication traced

[Exact-checkpoint replay, source trace and independent reviews](docs/audits/2026-10-17-incumbent-readiness/ordinary-order-boundary-audit/README.md)
qualify the earlier acceptance: **slice 1 does not satisfy its full W2 derive-footprint
and identity-updater no-op obligations**. Both are inside the approved existing-lifetime
scope, not deferred structural work. The recorded 143 passing cases and realization-edit
handoff remain finite valid evidence; the blanket acceptance does not.

The unchanged footprint fixture reproduces 13 passes / 2 failures on the exact
`91058393` source reconstruction. Derived y updates and identity updaters alone
incorrectly adopt inspected x99 because replaceOne loses the authored footprint
before value preparation; the notifier then derives fields from the incorrect
ordinary transition. A separate original assertion combines explicit replacement
with identity update and expects no send. That expectation conflicts with approved
same-display replacement adoption; preserve the original red as a test-contract
mismatch, alongside the genuine derive defect. The prior current-source 350/2 result
is unchanged, not rerun and not qualified by correcting that classification.

Prepend attribution independently reproduces 6N versus 2N snapshot entries at
N16/256/1024. Current has three physical and three ordinary walks. P-after is
snapshotted twice at the same private stage version; O-after rewalks an already
constructed permutation. O-before/O-current reuse is conditional on unchanged
placement. Distinct P/O authority and endpoint facts remain necessary. The entire
increase is not established as unavoidable; no optimization or CPU improvement is
claimed. No source, assertion, API or budget changed. Production remains `87f6831f`;
slice 2, integration and later slices remain gated. Historical sections below retain
their measured results; this audit supersedes their blanket slice-1 acceptance and
the classification of both original assertion failures as runtime defects.

## Indexed ordinary order — bounded experiment survives; integration remains blocked

[Exact source, unchanged failures, indexed workloads and independent reviews](docs/audits/2026-10-17-incumbent-readiness/ordinary-order-indexed/README.md)
record the owner-authorized indexed model and conditional native experiment.
Local agreement cleanup now processes changed slots; recovery records remain until
their last obligation ends. The model's unchanged 26 fixtures, supplemental work and
staggered/held-reference controls pass. Native source preserves ordinary placement
before inspection changes physical fallback; existing authority still selects
inverses. All four original compound/prepend failures pass unchanged, with useful
rejection, publication and subsequent-write checks.

The final focused union is **350 ordinary passes / 2 ordinary failures**, not wholly
green. Both updater/identical-replacement inspection-egress assertions fail on
the preserved predecessor. Their distinct runtime/test-contract dispositions are
now established by the boundary audit above. Root independently passes the
original 13 plus 2 owner preparation fault/reentry controls on the exact source.
Source/kernel typing and corrected spec-types pass; runtime lint has 0 errors and 4
inherited warnings. Original first failures and test-contract corrections remain
separate. Corrected source manifest is d13c33b1a515c65e4ca008df5caab0ac4976ed4db0cc166b922998fd2b7f6cb6;
its sole delta from the combined run is an erased test `this` annotation.

Costs remain explicit: fresh prepend avoids snapshots in the measured workload,
but moving one existing row expands from 2N comparator snapshot entries to 6N
shared physical/ordinary stage entries (3N each at equal-size domains). Indexed
local cleanup does not establish generally sparse settlement or better CPU/heap.
Full collectibility, framework/broad integration and artifacts are not qualified.

The bounded source-owner mechanism survives review; **slice 2 and integration do
not pass**. Keep the isolated source/evidence and production `87f6831f` unchanged.
Slice 1 (`91058393`) now has the W2 qualification stated above. Slices 3–5 remain
gated by unresolved supported-writer
failures and remaining qualification. No further repair is inferred from the
aggregate pass count. B remains closed; no API, activation, ceiling or release
change. The following source-design/representation sections retain their prior
checkpoint evidence; this section supersedes their unimplemented indexed-cleanup
status only within the measured/model and bounded native scope above.

## Ordinary-order lifecycle and source-owner design — reviewed; native gated

[Workloads, raw evidence and review](docs/audits/2026-10-17-incumbent-readiness/ordinary-order-source-design/README.md)
extend the frozen models without repeating the completed representation experiment.
Local order move/return keeps three sparse adjacency exceptions at N16/256/1024;
repeated cycles and staggered recovery/same-key held-reference controls pass within
the finite model. Full convergence scans/releases N. A separate partial-convergence
case proves the tested sparse drain scans 1,024 to retire four records; independent
replay agrees. Cleanup locality is therefore an unimplemented requirement, not a
claimed benefit already delivered. No CPU, heap, native or artifact result follows.

The [source-owner design](docs/audits/2026-10-17-incumbent-readiness/ordinary-order-source-design/SOURCE-OWNER-DESIGN.md)
assigns current ordinary placement to source-owned EntityOrdinaryTopology, keeps
payload/physical views separate and maps all six paths/eleven writer families.
Review exposed direct lifetime creation and point-value installation routes, now
explicitly classified. Complete final placement must precede capture; normalization
must follow affected slots, with separate indexed recovery obligations. Sparse is
the leading hypothesis; snapshot remains the reference. Neither is natively adopted.
All 770 frozen native source hashes and original four falsifiers remain unchanged.
The recurrence stop, slice-2 rejection and later-slice gates remain active.

## Ordinary-order representation check — complete; native remains paused

[Preregistration, frozen models, work/retention and independent review](docs/audits/2026-10-17-incumbent-readiness/ordinary-order-representation/README.md)
compare a retained ordinary snapshot with sparse lifetime/adjacency facts against
the compound ordinary-order leak and three prepend-redo failures. Both represent
the required facts in the finite models, using common prepared facts/inverse
consumers. Both require ordinary placement retained before physical inspection
changes and final compound placement specified before source capture.

The snapshot copies/retains complete ordinary order during divergence. Sparse
fixed-local capture avoids those copies, but its tested drain still scans all
current exceptions after full divergence (16/256/1024). No globally bounded drain,
native integration, GC, speed or artifact result follows. Models use trusted
lifetime commands and shared supplied physicalCAB realization; those limits are
explicit. No representation is selected as a native implementation.

Native source remains unchanged from rejected manifestd1ff7c33..., and production
87f6831f / accepted slice1 are unchanged. The bounded refusal-policy pass remains
separate. The recurrence stop and later-slice gates remain active. This finite
check does not authorize another native source-state migration or consumer patch.

## Latest successor — policy repaired; structural recurrence rejects integration

[Exact source, policy approval, first failures and independent adjudication](docs/audits/2026-10-17-incumbent-readiness/order-policy-recurrence/README.md)
preserve the October24 result. Owner approved atomic refusal of the interleaved
independent full-order case. Its bounded implementation passes12 new controls,
independent native replays and the239 prior focused controls; pending authority,
inspection, confirmation and callback-error recovery remain useful. No runtime
changes are integrated.

The combined successor is rejected at the existing recurrence stop: compound
inspection/setAll/rejection publishes inspected orderCAB as ordinary truth instead
ofABC. The independent trace locates contaminated ordinary neighbors before
inversion, and a permanent ordinary-only regression plus root replay fail. A
separate prepend source-placement mismatch also fails3 existing history redo
controls that production passes. The new physicalABC assertion is overstrong and
preserved separately; physicalCAB alone is not the established defect.

Current isolated transactions source is SHA2568ccc2ed77f5cb018fdaf596730223bb78f967bf948f58327304e9c9642e45ea9;
full final source manifest and reconstructible overlay are archived. Workspace
and configured spec types pass; no budgets changed. No full qualification/cost
run followed the recurrence. Production87f6831f, accepted slice1 and closedB
remain unchanged. Later slices remain gated. No automatic additional repair is
authorized by the passing order policy; the ordinary-placement representation
needs a reviewed completeness account before a successor.

## Prior successor record — decision subsequently resolved above

[Exact source, unchanged failures, review and replay](docs/audits/2026-10-17-incumbent-readiness/inverse-disposition-successor/README.md)
preserve the isolated successor. The frozen source passes 239 focused cases,
workspace types and configured spec types. Admission segments, authority-selected
inverse compilation and exact-record notification pairing repair the tested
capture, foreign-field and inverse-order failures. No runtime is integrated.

A genuine full-order compatibility question remains: initial ABC; own CBA,
independent realized BCA, own ACB; rejection returns ABC in both production and
candidate. Preserve current behavior, refuse atomically, or retain intermediate
BCA requires owner disposition. The proposed contrary assertion is not yet a
proven contract failure. Dependent order work pauses; later integration gates
remain closed. Production remains `87f6831f`, slice 1 retains its scoped validity,
and B remains closed. Full final suites, collectibility and fresh costs are not
qualified by this focused result. Original getter-premise failures and the
interrupted non-frozen broad run are separately retained, not counted as passes.

## Shared transition migration — rejected at covered S3 recurrence

[Execution, exact sources and independent review](docs/audits/2026-10-17-incumbent-readiness/semantic-transition-execution/README.md)
preserve the owner-authorized slices0–5 experiment. The candidate passes focused
adoption/inspection, publication, reentry and recovery controls, but mixed scalar/
entity rollback promotes an untouched inspected field into ordinary authority.
The next explicit adoption is then an empty transaction and rollback retains99
instead of ordinary7. Independent uninstrumented replay and Nx confirm the
counterexample; the entity-only control passes. This is the explicitly covered
minimal S3 path, so the owner-defined recurrence stop applies. No further repair,
later-slice qualification, broad suites or fresh cost measurements followed.

Production remains `87f6831f`; no runtime changes are integrated. Candidate source,
first failures, harness mismatches and19 changed/new TypeScript files are archived.
Eleven type diagnostics match a fresh incumbent control; this is not a clean
production typecheck. Entity collectibility remains separately unresolved. B stays
closed. A successor needs a concrete scope decision at the recorded boundary.

The owner also resolved structural adoption rejection: restore ordinary topology
within the authored footprint, leaving unrelated inspection untouched. Three new
assertions fail on unmigrated paths and remain acceptance baselines, not recurrence
failures. This policy approval does not accept the implementation.

The [authorized plan](docs/audits/2026-10-17-incumbent-readiness/semantic-transition-plan/README.md)
remains the historical scope record; its original pending-authorization language
predates the subsequent explicit owner approval.

## Slice2 execution — rejected at structural admission recurrence

[Exact source, failures, reviews and replay](docs/audits/2026-10-17-incumbent-readiness/semantic-transition-slice2/README.md)
preserve the isolated structural experiment. C1–C3 and focused compound controls
pass, but an independently reproduced rekey into an inspected vacancy loses the
prior ordinary destination: rollback succeeds with only B, while old A remains
absent. Root's asserting Nx reproduction fails. W5's transfer-key branch was
explicitly migrated; it omits destination displacement admitted by the add branch.
This repeats missing ordinary facts within the proposed shared admission mechanism.
Runtime work stopped under the recurrence condition; no local rekey patch followed.

Final candidate source manifest:
`6796adabea84c967b08784134772777dc238c086f8708cb9f33e480747aadb1a`.
Recorded runs include20 structural controls and73 prior/affected controls passing;
counts overlap with other runs and are not release qualification. A separate
inspection-rekey/key-reuse inverse safely refuses; cleanup concerns remain source
findings, not measured leaks. The record corrects an interim source-manifest timing
mismatch and preserves exact executable artifacts. Slice1 stays closed. Slices3–5,
full suites, collectibility and costs were not reached. Production stays87f6831f;
B stays closed, budgets unchanged, no integration/activation/publication.

## Slice2 prerequisites — ready for bounded preparation

The owner closed slice1 within its existing-lifetime scope. The
[prerequisite assessment and independent review](docs/audits/2026-10-17-incumbent-readiness/semantic-transition-slice2-prerequisites/README.md)
preserve checkpoint `91058393` and its exact isolated source. No tests were rerun.
The approved ordinary-topology rule governs the unchanged C1–C3 structural
failures; no new semantic decision blocks bounded slice2 preparation and tests.

Before runtime changes, map explicit physical/ordinary presence, lifetime, key,
order and consumer facts for W4–W8, including C1's structural adoption through a
field-write entrypoint. Prewrite missing composition/fault/reentry/refusal checks.
Slice2 acceptance includes the minimal structural inverse needed to reject its
own operations; it cannot defer that correctness gate or silently expand into
full-target restoration. Nested missing-parent authority remains conditional;
no supported reproduction currently makes it an entry blocker. Later slices,
integration, collectibility, costs and release qualification remain gated.

## Ordered realization successor — bounded handoff survives

[Successor evidence and replay](docs/audits/2026-10-17-incumbent-readiness/semantic-transition-successor/README.md)
record the subsequently authorized private handoff experiment. Ordered presence/value
edits now determine ordinary authority separately from the physical installation
target. The unchanged mixed/entity-only/second-transaction falsifier passes.
Independent review found preparation aliasing and duplicate getter evaluation;
both first failures are preserved, corrected and independently rechecked.

Final focused results:34/34 across six files; affected inspection/egress/recovery/
adapter controls109/109 across eight files; source typecheck passes. Candidate
package-TypeScript manifest fingerprint is
`47f5ee8aea90ffb2c9d6e89eb1e287e73b39c3eeab8f42ede9ea5b2fd125dfb7`.
Supplemental batch-publication assertions pass5/5 (overlapping cases). Independent
gate review finds the scoped existing-lifetime slice1 gate satisfied. This does
not qualify the entire migration or release.
Structural/full-target and nested missing-parent qualification remain open;
no later slices, activation, full suites or costs followed. Production remains
`87f6831f`; B stays closed and entity collectibility remains unresolved.

## Read-only realization boundary trace — historical checkpoint

[Boundary trace and independent review](docs/audits/2026-10-17-incumbent-readiness/semantic-transition-boundary/README.md)
locate the loss at the private point adapter: ordered reversal effects still name
the authorized field/presence, but the collection handoff carries only a physical
row. A private input-contract change could carry ordered realized edits beside
that target; no public framework SDK expansion is identified as necessary.
Nested missing-parent behavior and sibling structural/full-target reconstruction
remain explicit obligations, not inferred successes or newly reproduced failures.
No runtime/test changes or later slices were resumed; the rejected candidate and
its unchanged two-arm/second-transaction regression remain preserved.

## Shared semantic transition feasibility — scope decision before implementation

[Writer inventory, traces and independent premise review](docs/audits/2026-10-17-incumbent-readiness/semantic-transition-feasibility/README.md)
confirm that prepared value facts already contain the missing ordinary transition,
while caller-generated physical chronology omits it. Six traced scenarios and16
pure coverage checks establish input availability and distinct ordering/realized
participation; they do not qualify a repaired runtime.

A shared transient result is plausible, but requires a cross-cutting migration of
affected value producers and chronology consumers. Six installation paths and eleven
writer families need coverage/disposition, not necessarily redesign. Existing
physical notification semantics and the single notification protocol must remain.
The requested scope stop is reached before implementation; the record presents the
migration and explicit product-deferral alternative. No choice or activation is
silently made. Prior useful repairs and unresolved entity collectibility remain.

## Declared-Link bounded repairs — integration still rejected

[Separate corrections, combined focused qualification and independent review](docs/audits/2026-10-17-incumbent-readiness/link-bounded-repairs/README.md)
preserve projection identity and operation-lifecycle gains. Original entity payload,
scalar, composition, source guards, receipt/error and disposal controls pass in the
combined disposable candidate. Entity adoption remains blocked: `setAll()` captures
ordinary-before responsibility but publishes physical-before chronology, causing
`inspect()` to throw. Rollback restores ordinary rows and retry no-ops; this is not
claimed rollback corruption. The repeated publication/capture gap is frozen without
another caller-specific patch.

Explicit current metadata counters drain; the original retention verdict using
removed counter fields is excluded as vacuous. Retained scalar receipt GC passes;
entity graph collectibility remains unresolved (same observation without retained
receipts). Full suites, installed artifacts and costs remain gated. Production
runtime/safe hold, budgets and B closure are unchanged. No API activation or release.

## Declared-Link causal inventory — no repair yet

[Bounded causal inventory and independently reviewed plan](docs/audits/2026-10-17-incumbent-readiness/link-causal-inventory/README.md)
traces the frozen failures to lossy source/projection identity, missing entity
ordinary-truth adoption coverage, receipt/error lifecycle gaps and absent metadata
retirement. These are separate causes with shared internal boundaries, not one
proven universal fix. Existing native identity/preparation seams support a bounded
experiment; no new API or settlement authority is proposed. Unchanged falsifiers
and positive publication controls remain its acceptance gates. No runtime changes,
new test results, broad suites or cost measurements accompany this inventory.

## Declared-Link finite qualification — focused gate failed

[Exact failure ledger, controls, review and replay](docs/audits/2026-10-17-incumbent-readiness/link-declared-qualification/README.md)
qualifies frozen research inputs against source `568bdf69`. **Current candidate
rejected for integration**: accepted scalar entity-field links send undefined;
entity equal-inspection adoption is missing; helper refresh causes inspection-only
aggregate publication; receipt terminality, secondary error reporting, source
validation and post-drain metadata reclamation fail. Source/receipt stores each
grow by16 over8 fully settled/disposed/destroyed cross-tree cycles.

Native aggregate controls16/16 and actual restoration undo/redo remain passing.
Composition24/26 fails two assertions from one missing-report cause. Tree destruction
and explicit disposal retain their established distinction. Prior scalar adoption
results remain valid. Historical32/34 expectations are separately reconciled;
hidden-input omission stays misuse, not a safety pass.

Full suites, complete types/installed artifacts and fresh cost measurements were
not run because the focused entry gate failed. Production runtime and safe hold
remain unchanged. No repair, API acceptance, budget change or reopening of B.

## Equal inspected-value adoption — bounded candidate

[Native candidate, first failures, exact inputs and independent review](docs/audits/2026-10-17-incumbent-readiness/link-equal-adoption/README.md)
implements authorized scalar adoption in a disposable native overlay. Final
focused Nx: 96/96; targeted kernel typecheck passes. Independent facade cases:
16 direct and 24 native root/branch cases pass. Original 25 safety assertions,
13 prior controls and nested failure remain passing. Three prior no-adoption
expectations now differ under the owner's new rule; historical32/34 delivery
accounting remains separate. Raw original assertions are preserved.

First native compile/type failures and the unchanged P5 acquisition regression
are preserved. Root/branch authority admission fixes P5 without a Link-specific
exception or forcing value notifications. Production runtime remains unchanged;
this evidence does not qualify complete declarations, entity/removal/destruction
retention, performance/artifacts or release. No full qualification was run.

## Equal inspected-value adoption — owner decision

[Native/declaration boundary evidence and review](docs/audits/2026-10-17-incumbent-readiness/link-equal-write-boundary/README.md)
shows the prior native behavior: ordinary7, inspection99, equal ordinary99 emits
no contribution; an equal transaction rolls back leaving physical99 and eligible7.
Inspection context exit restores metadata only. Baseline and private candidate
agree; this was not a declaration-only regression.

The owner subsequently authorized v16 adoption: explicit ordinary99 adopts that
value, and transactional rejection restores both physical state and publication
authority7. Genuine ordinary99-to99 remains a no-op. This is a new explicit
compatibility decision, not a claim that the existing implementation meets it.
A bounded native implementation experiment is underway; production hold remains.

## Native declaration boundary correction — October 20

[Preserved correction, failures and review](docs/audits/2026-10-17-incumbent-readiness/link-native-boundaries/README.md)
records a private scalar experiment against `376129b5`. Original 25 safety
assertions, 13 prior controls, nested failure and 31 new assertions pass; root
added 13 controls pass. Misuse is separate. Historical delivery remains 32/34
under unchanged old permanent-hold assertions, with the approved post-confirmation
semantics documented separately. No production runtime change.

Independent review supports enclosing validation and ordinary-state participation
corrections. An ordinary setter equal to inspection-displayed state produces no
native revision: the prewritten publication expectation remains failed and the
API's equal-value-authorship promise is unqualified. Retention, scans, framework
and entity integration remain unqualified; no broad production acceptance.
Conservative production hold and current release blockers remain unchanged.

## October 19 reviewed checkpoint

[Runtime repair, rejected Link experiment and exact verification](docs/audits/2026-10-17-incumbent-readiness/remaining-runtime/README.md)
records runtime `87f6831fa60cafe87508f0ace84b7638698ca3b0`: kernel 5,837 ordinary
passes / five expected failures / 12 skips; frameworks 599 passes / three skips.
Source/spec types, affected lint and fresh package/demo builds pass. Two fresh
entity budgets fail. No full release-registry, mutation or installed-consumer
qualification is claimed. Earlier sections below retain their historical scope.

Independent review found no further bounded restoration blocker. The Link
experiment leaks pending values copied through reactive callbacks because
location-disjointness is not dependency independence. Safe gate restored at
`e9653a41`; original assertions and rejected source preserved. Closing this
supported requirement needs a scoped dependency-provenance design, not another
admission exception or transaction-ownership change. B remains closed.

## Bounded Link provenance experiment

[Preregistered experiment, failures and independent review](docs/audits/2026-10-17-incumbent-readiness/link-provenance-feasibility/README.md)
leaves production at the reviewed checkpoint. Initial model: 15 passes / three
new nested-dependency failures. Conservative frame composition: 17 passes / one
unchanged progress failure. No integrated candidate passed. An unchanged-kernel
probe records identical observed metadata for a deferred constant and captured
speculative value; the safe hold blocks both until confirmation. This is a bounded
observability result, not proof automatic provenance is universally impossible.
A real trusted-input/execution-boundary contract and native cache instrumentation
remain unresolved. No public boundary API, narrower scope or runtime change was
selected. The two entity budgets remain separate blockers; no release freeze.

## Comparative product research

[Three publication/visibility alternatives](docs/audits/2026-10-17-incumbent-readiness/link-product-comparison/README.md)
compares automatic tracking, explicit outbox responsibility and isolated review
with ordinary Link. Owner authorized comparison, not replacement or API selection.
Real-kernel application examples demonstrate bounded progress for explicit entries
and isolated review; intentional negative controls show that missing ownership or
premature draft copying still publishes speculation. Neither is a qualified
production replacement. Visibility models are distinguished, not ranked by fidelity
to current live proposals. Runtime costs remain unmeasured at equivalent capability.
Current safe hold, supported-progress blocker and artifact blockers remain intact.

## End-to-end workflow adoption evidence

[Ticket review and explicit command adoption](docs/audits/2026-10-17-incumbent-readiness/workflow-adoption/README.md)
now have independently replayed headless scenarios and strict application typechecks.
Review-before-save preserves concurrent edits and explicit conflicts with ordinary
Link. The command sample uses versioned tooling identity/lifecycle and remains
experimental: recovery adoption, retention and durability are unqualified. Negative
controls and first failures are preserved; line counts measure application burden,
not runtime cost. No package source changed. The owner declined the proposed
workflow-scoped relaxation: automatic independent progress remains required, without
a promise to infer arbitrary asynchronous causality. A bounded configurable-Link
comparison is authorized; no API or runtime change is selected. Both entity budgets
remain open.

## Configurable Link comparison completed

[Reviewed specification, bounded comparison and preserved failures](docs/audits/2026-10-17-incumbent-readiness/link-policy-comparison/README.md)
show useful scalar authoritative-ingress progress while unrelated work is pending.
The private bridge fails send-time reentry and held-send replacement; ordinary
unscoped writes remain held even after confirmation. Tree-destroy sends are also
observed in unchanged baseline code and require separate lifecycle adjudication.
Explicit ownership and manual scheduling are model-only; adversarial review exposes
mutable evidence and reversible terminal outcomes in that model. No public API or
production policy was selected. Automatic independent progress remains required
and unresolved; safe hold, optional adoption workflows, closed B and both entity
budget blockers remain unchanged. No broader suites or repeated cost campaign ran.

## Delivery/evidence follow-up completed

[Bounded state machine, controls and independent review](docs/audits/2026-10-17-incumbent-readiness/link-delivery-followup/README.md)
separate eligibility from delivery. The private revision passes 34 targeted delivery
assertions, including reentry, held-send replacement, serialized corrective delivery,
settlement visibility and observable errors. Immutable evidence/terminal outcomes
pass model adversarial controls; the original conflicting fixture and ticket-mutation
failure remain preserved. Ordinary direct writes still have unknown eligibility
after confirmation; this is not a missed wake-up. Tree-destruction behavior remains
separately unresolved. No production integration or public API is accepted. Automatic
independent progress and both entity budgets remain release blockers. Further scope
changes require owner decision; no new configuration or provenance expansion is selected.

## Eligibility boundary and destruction classified

[Minimal controls, source trace and independent review](docs/audits/2026-10-17-incumbent-readiness/link-eligibility-boundary/README.md)
distinguish complete owner-set resolution from missing provenance. All known possible
owners confirming can discharge a complete set; the private clean/unknown flag has
no such bookkeeping. Current pending snapshots cannot establish completeness for a
synchronous retained local from a previously rejected owner. Literal and retained
copies have identical observed metadata. Baseline publication follows its current
surviving-truth contract; stronger causal withholding requires an explicit product
boundary, not another delivery guard. No policy/API changes selected.

Destruction is now classified separately: established tests permit a pre-destroy
queued value to send. The earlier zero-send research oracle was stronger than that
contract. Started requests may complete; held settlement waiters remaining pending
until explicit Link.dispose() reproduce a previously documented lifecycle gap.
Tree destruction is not specified as connection disposal. Automatic progress and
artifact blockers remain open; no release qualification is inferred.

On October 19 the owner approved surviving-write semantics for the reproduced
post-rejection retained-local write: it authors new surviving application truth,
without inheriting the rejected causal origin. This closes that specific product
question only. It does not establish independence while other owners remain pending,
change the production hold, or approve the experimental delivery mechanism.

## Bounded owner-window eligibility rejected

[Private experiment and independent replay](docs/audits/2026-10-17-incumbent-readiness/link-owner-window/README.md)
demonstrate earlier revision progress after its captured owners confirm while a later
owner remains pending. The first implementation fails ABA: net-equal value publication
is deliberately suppressed, leaving Link on an older responsibility ticket than the
latest mutation evidence. Both owners confirm but the value never sends. Window
controls record 45 passes and one failure; cross-tree speculative copying remains an
explicit unsupported boundary. Historical delivery checks remain unchanged: 32 pass,
two old permanent-unknown expectations differ under the proposed eligibility behavior.
No repair followed the counterexample. Production hold, surviving-write semantics,
independent-progress requirement and separate artifact blockers remain unchanged.
No public API, broader qualification or replacement transport is selected.

## Responsibility observation correction remains private

[Bounded correction and independent review](docs/audits/2026-10-17-incumbent-readiness/link-responsibility-observation/README.md)
close the earlier ABA failure in the default-batched scalar experiment: 46 unchanged
owner-window and 16 added controls pass without extra value emissions. Same-runtime
cross-tree pending copies now remain held through namespaced owner evidence.
Historical delivery checks remain 32/34, with two preserved old eligibility oracles.
Global source scans and retained research metadata are explicit limitations. Immediate
independence from existing pending owners, framework/entity coverage and production
acceptance remain unproved. Production hold, surviving-write semantics, B closure
and the two entity-budget blockers remain unchanged.

## Immediate independence: observation mechanism insufficient

[Decisive paired replay and independent review](docs/audits/2026-10-17-incumbent-readiness/link-immediate-independence/README.md)
show literal ordinary y(7) remains held while x=7 is pending. A reactive y(x()) copy
also holds; both receive identical responsibility facts and send after confirmation.
The mechanism lacks consumed-source dependency evidence. Its ABA correction stands,
but scan optimization and retention work are not pursued for this failed eligibility
solution. Historical 32/34 confirmation expectations are explicitly reconciled without
editing originals or claiming another 34/34 run. Production hold and automatic
independent-progress blocker remain; no alternative API or architecture is selected.

## Input-boundary comparison awaits product selection

[Reviewed specification comparison](docs/audits/2026-10-17-incumbent-readiness/link-scope-comparison/README.md)
distinguishes tracked fresh reads from complete input evidence. Pre-scope values,
closures and native caches cannot become clean merely because a scope observed no
reads. Explicit publication ownership supplies application assertions, not automatic
proof. Conditional immediate progress needs a truthful complete-input contract;
no public API or requirement change is selected. Production hold and the blocker
remain. No new runtime experiment, lifecycle heuristic or B work was started.

## Conditional publication direction approved

[Owner decision and declaration contract draft](docs/audits/2026-10-17-incumbent-readiness/link-declared-contract/README.md)
record application responsibility for complete declarations. This answers the prior
comparison's direction question; API and implementation remain unapproved. Declaration
validation must cover the completed synchronous operation before early publication.
Publication dependencies do not assign compensation ownership. The older-receipt
rejection fallback remains an explicit compatibility obligation before implementation.
Production hold, closed B investigation and separate artifact blockers remain unchanged.

## Declaration rules exercised as a standalone specification

[Executable examples, first falsifier and independent review](docs/audits/2026-10-17-incumbent-readiness/link-declaration-examples/README.md)
cover rejection against surviving current projection, conservative retention after
late contradiction, and synchronous-only declarations. A returned then-getter exposed
validation reentry escaping the first scope; the unchanged falsifier passes after
keeping the scope through return-shape inspection. Original18 examples match, including
one explicitly leaking hidden-input negative control, plus four adversarial controls.
This is a single-destination model with supplied projection/outcome seams, not native
Link integration or API selection. The rejected-receipt rule is executable at that
boundary; production provision of the boundary remains unproved. Safe hold remains.

## Link-local API proposal awaits owner approval

[Concrete API comparison and independent review](docs/audits/2026-10-17-incumbent-readiness/link-api-proposal/README.md)
recommend a scalar connection-local synchronous declaration with independent,
dependent and unknown forms, plus an observable per-operation receipt. This is a
proposal, not a selected export or native implementation. Existing transaction handles
would be authenticated only as dependency identities, never invoked as settlement
authority. Nested validation/input-accessor gaps found in review are addressed in the
proposal. Type sketches pass; no runtime or framework qualification is claimed.
Production hold remains until an approved native experiment survives its controls.

## Approved scalar native experiment rejected

Owner approved the proposed surface at247cfec7 for the bounded native experiment,
not production activation or release acceptance. [Native result and two reproduced
safety blockers](docs/audits/2026-10-17-incumbent-readiness/link-declared-native/README.md)
demonstrate conditional independent scalar progress, authentic no-op identity and
connection isolation. After completing missing fallback, original25 ordinary assertions
pass; misuse is separate. Root controls add12/13, with inspection sending99 instead
of eligible7. Independent review also reproduces an inner connection sending after
outer validation fails. Both failures persist in frozen final source. No repair,
broader qualification or production integration follows. Missing full delivery,
recovery/reporter and framework evidence remains explicit; production hold is unchanged.

## Verified evidence and limits

- [Applied string-Record typing migration](docs/audits/2026-10-17-incumbent-readiness/unknown-dynamic-access/README.md)
  records exact destination hashes, reused verification, independent review and
  [consumer migration guidance](docs/guides/open-record-typing-v16.md).

- [Paired capture repair](docs/audits/2026-10-17-incumbent-readiness/paired-membership/README.md)
  preserves runtime `89bfca62` and evidence `96a54e6a`.
- [Artifact attribution](docs/audits/2026-10-17-incumbent-readiness/artifact-cost/README.md)
  identifies the separately verified helper optimization `9917c92f`.
- [Approved artifact decision and receipt](docs/audits/2026-10-17-incumbent-readiness/ARTIFACT-ACCEPTANCE.md)
  records ceilings implemented at `4dfc3576`; 248 identified artifact hashes
  remained unchanged. Prior failed budget runs are preserved, not relabelled.
- [Preregistered representative cost](docs/audits/2026-10-17-incumbent-readiness/representative-cost/README.md)
  leaves timing direction and large pending-owner attribution unresolved. Corrected
  cleanup supports sampled tree collectibility, not universal absence of leakage.
- Earlier focused reconciliation: restoration **71 ordinary passes / 6 expected
  failures**; unchanged Link cases **10 violated / 2 unsupported**. Vue shape
  counterexample strictly typechecks and its populated controls execute.
- [Exact baseline qualification](docs/research/v16-candidate-acceptance-0/RESULT.md)
  applies to `8d220643`, not a future runtime. Existing successful gate runs do not
  close current supported-behavior failures or certify another source/artifact.

## Final verification boundary

Once supported requirements are satisfied, obtain independent review and freeze
the final runtime/source. Run the required affected suites, runtime/spec types,
lint and documentation checks, then the complete release registry, mutation proofs,
fresh package/demo builds, installed-artifact consumers and framework/browser
checks against identified final source/artifacts. Rebuild after mutation tests.
Record ordinary passes, expected failures, skips and unexecuted checks separately.
Do not declare the stronger matrix fulfilled or add APIs merely to observe it.
Verification grants no publication authority.

### Preserved runtime counterexamples after typing migration

See the [separate boundary evidence](docs/audits/2026-10-17-incumbent-readiness/runtime-boundaries/README.md).
Compound rollback restores rows but history retry fails ST1034; the one-removal
repair is not general compensation support. The [bounded Link publication repair](docs/audits/2026-10-17-incumbent-readiness/link-order-repair/README.md)
now passes queued/in-flight and reentry controls with independent review. Original
Link failure remains archived. Compound restoration and independent Link progress
remain blockers; this is not final runtime qualification.

### Compound compensation candidate

[Candidate and preserved failures](docs/audits/2026-10-17-incumbent-readiness/compound-compensation/README.md):
complete compensated structural intervals, including known zero-net work, pass
16 focused controls and independent review. Final combined focused run has 44
ordinary passes; fresh type/spec/build/demo and unchanged budget gates pass.
On October 19 the owner authorized the specific invalid snapshot-index assertion
correction. The corrected regression passes 2/2 ordinary tests and spec-types;
runtime is unchanged and the original failures remain archived. The earlier
44-test run and fresh artifact results retain their original provenance. R1/R2
composition, broader Link progression and final qualification remain unresolved;
this is not release readiness.

## Ordinary occupancy account — successor remains gated

[Reviewed inventory, private-boundary audit and preserved replays](docs/audits/2026-10-17-incumbent-readiness/ordinary-occupancy-account/README.md)
separate ordinary inverse authority from physical realization. Both validation and
target construction need the same identity join before physical guards; an installer-only
change is insufficient. No runtime successor or later slices were started.
The owner resolved the active-old payload case: preserve inspected display99
while restoring ordinary7; explicit field reversals remain separate. The original
failures and remaining preparation gates are unchanged. Recurrence stop remains active.

## Occupancy successor feasibility — capture scope revised

[Specification, exact probes and independent review](docs/audits/2026-10-17-incumbent-readiness/occupancy-successor-feasibility/README.md)
show that chronological Bind/Unbind output cannot enter the unchanged incumbent
fold: same-lifetime removal/rebind loses the final ordinary binding. This is a
producer/consumer incompatibility, not a newly failed native rollback sequence.
An isolated endpoint encoder expresses the tested occupancy facts, with its own
payload-context first failure preserved. Native capture, nested obligations and
sparse transfer/placement remain unqualified. A successor needs coordinated
capture-interval composition and prevalidation realization, not an installer-only
fix. No runtime changed; recurrence stop and slices3–5 gates remain active.

## Coordinated occupancy successor — rejected

[Exact source, independent reviews and replay](docs/audits/2026-10-17-incumbent-readiness/occupancy-native-successor/README.md)
preserve the owner-authorized native experiment. Independent realized admission
between transaction-owned writes breaks the endpoint composer's continuity
assumption. Final frozen Nx control:2 pass/1 fail; comparator constructs, inspects
and confirms the identical sequence. This is an established internal participation
boundary, not a claimed public end-to-end trigger. Independent review and root
replay agree. A placement correction separately reorders restoration across a
dependent field operation and causes atomic refusal in the private adapter.

The successor is rejected under the recurrence condition. No guard weakening,
further repair, slices3–5, broad qualification or costs followed. Source manifest
is `9e4f72b0a3c83f3c60ba62ad35695c0f5ff41099060a65bf6271d8f736da5c54`.
Slice1 retains scoped validity; production remains87f6831f. B remains closed.
No activation, API change, budget increase, merge, push or publication occurred.
