#!/usr/bin/env node
/**
 * Release-delta claim coverage: every capability this release ADDS must appear
 * on every surface that claims to describe the library.
 *
 * ## Why this exists
 *
 * Every other gate in this repo is a NO-DANGLING-REFERENCE check. `readme-apis`
 * asserts that a symbol a README names exists. They all run in one direction:
 * claim -> API.
 *
 * The opposite direction was unguarded, and it is not symmetric. **A "we don't
 * have X" is a claim about ABSENCE, and you cannot grep for a symbol that is not
 * mentioned.** So thirty gates were structurally blind to it.
 *
 * What that cost, twice, in one release:
 *
 *   - `49dd9ffb` — "the AI-priming surfaces taught NONE of 14.0.0". `llms.txt`,
 *     `llms-full.txt`, the core README and the skill scored ZERO on prependOne,
 *     activeEntity, setActiveId, changeId, pauseRecording, shouldSkip,
 *     onTreeError, ST2025 and ST2026. Found by hand. The AI priming artifacts
 *     were later removed in 15.0 after their API guidance went stale, so this
 *     gate now tracks the surviving release claim surfaces.
 *   - `docs/compare/capability-matrix.md` still carried ❌ for FIVE capabilities
 *     the same release shipped, and was edited twice AFTER they landed. It was
 *     not in `49dd9ffb`'s hand-written surface list.
 *
 * Both are the same bug, and the second one proves the fix has to be structural:
 * a hand-maintained list of surfaces will miss a surface, and a hand-maintained
 * list of symbols will miss a symbol. **This derives both from the repo.**
 * Symbols come from a git diff of the published barrels; surfaces are declared
 * once below and each new one is swept automatically from then on.
 *
 * Note also what the git history does NOT give you: the matrix was edited after
 * the features shipped, so "flag docs nothing has touched in a while" would have
 * reported it as fresh. Age tracks staleness badly. Coverage tracks it exactly.
 *
 * ## What counts as covered
 *
 * A symbol is covered by a surface if its name appears in that surface's text.
 * That is deliberately weak — it proves the surface MENTIONS the capability, not
 * that it explains it well. A weak check that runs on every release beats a
 * strong one that runs when somebody remembers.
 *
 * Usage:
 *   node tools/check-release-claims.mjs                  # gate, exits 1 on a gap
 *   node tools/check-release-claims.mjs --base=v13.4.0   # diff from another tag
 *   node tools/check-release-claims.mjs --list           # show the delta, exit 0
 */
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import ts from 'typescript';

const ROOT = process.cwd();
const LIST_ONLY = process.argv.includes('--list');

function git(...args) {
  return execFileSync('git', args, { cwd: ROOT, encoding: 'utf8' });
}

/** File content at a revision, or null when the file did not exist there. */
function showAt(rev, relPath) {
  try {
    return execFileSync('git', ['show', `${rev}:${relPath}`], {
      cwd: ROOT,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    });
  } catch {
    return null;
  }
}

/** Compare stable v<major>.<minor>.<patch> tags without Git sort settings. */
function compareStableTags(left, right) {
  const leftParts = left.slice(1).split('.').map(Number);
  const rightParts = right.slice(1).split('.').map(Number);
  for (let index = 0; index < leftParts.length; index++) {
    const difference = rightParts[index] - leftParts[index];
    if (difference !== 0) return difference;
  }
  return 0;
}

/**
 * The release to diff against: the newest version tag that is NOT the version
 * currently in package.json. Derived rather than pinned, so this keeps working
 * across releases without anyone editing it.
 */
function resolveBase() {
  const explicit = process.argv.find((a) => a.startsWith('--base='));
  if (explicit) return explicit.slice(7);
  const current = JSON.parse(
    readFileSync(join(ROOT, 'package.json'), 'utf8')
  ).version;
  const tags = git('tag')
    .split('\n')
    .map((t) => t.trim())
    .filter((t) => /^v\d+\.\d+\.\d+/.test(t));

  /**
   * A STABLE release diffs against the last STABLE tag, not against its own
   * release candidate.
   *
   * The rule used to be "the highest tag that is not the current version",
   * which for 14.0.0 resolved to v14.0.0-rc.1. Everything in 14.0.0 had already
   * shipped in that rc, so the delta was empty and this gate — the only one that
   * runs API -> claim — covered NOTHING at the exact moment it mattered most.
   * `verify-gates --self-test` caught that honestly: it reported the gate BLIND
   * because deleting a shipped capability from the priming file no longer failed
   * it.
   *
   * The question a release gate should answer is "what reaches a user upgrading
   * from the last version they could install", so a stable release skips ALL
   * prereleases. A prerelease still diffs against whatever came before it,
   * including another prerelease, which is correct for an rc.
   *
   * THE 14.0.0 FIX WAS INCOMPLETE AND THE BUG RETURNED AT THE NEXT RELEASE. It
   * excluded only prereleases matching `v${current}-`, which handled 14.0.0 vs
   * v14.0.0-rc.1 and nothing else. For any later 14.x current the filter kept
   * `v14.0.0-rc.1`, and git's `--sort=-v:refname` ranks a prerelease ABOVE its
   * own stable release unless `versionsort.prereleaseSuffix` is configured — so
   * the base resolved to v14.0.0-rc.1 again and the delta was measured from the
   * rc rather than from the last installable version. `--self-test` reported the
   * gate BLIND, which is how this was found. Excluding every prerelease is
   * version-independent and cannot rot the same way.
   */
  const isPrerelease = /-/.test(current);
  const candidates = isPrerelease
    ? tags.filter((t) => t !== `v${current}`)
    : tags.filter((t) => t !== `v${current}` && !/-/.test(t));
  /**
   * ...AND THE BASE MUST BE ON THIS RELEASE LINE. Third correction here, and
   * the first that made this gate return a WRONG answer rather than a blind
   * one.
   *
   * The sort ranks tags across the WHOLE tag namespace, which is not the same
   * set as "releases this commit descends from". A repository carrying more
   * than one line — or a checkout that has fetched a second remote — therefore
   * resolves a base from a line this commit never touched. Measured while
   * preparing the 14.1.4 security patch: the base came out `v15.3.0`, the gate
   * diffed the 14.x API against the 15.x API, and it reported 405 "added"
   * symbols, every one an ordinary 14.x export that 15.x renamed or dropped.
   * Unsatisfiable by construction, and loud enough that it read as a real
   * finding.
   *
   * ANCESTRY is the version-independent form of the question already asked
   * above: "what reaches a user upgrading from the last version they could
   * install" means the last release THIS COMMIT DESCENDS FROM. On a single
   * linear line it selects exactly what the old rule selected, so nothing about
   * an ordinary release changes.
   */
  const base = candidates
    .sort(compareStableTags)
    .find((tag) => {
      try {
        git('merge-base', '--is-ancestor', tag, 'HEAD');
        return true;
      } catch {
        return false;
      }
    });
  if (!base) {
    console.error(
      'No prior version tag found to diff against.\n' +
        '  This gate diffs the public API against the last STABLE version tag,\n' +
        '  so it needs tags. In CI that means `fetch-depth: 0` and\n' +
        '  `fetch-tags: true` on actions/checkout — a shallow clone has none, and\n' +
        '  the failure then reproduces on no developer machine.\n' +
        '  The tag must also be an ANCESTOR of HEAD — a tag on another release\n' +
        '  line is not a base this commit can be a delta from.\n' +
        '  Locally: `git fetch --tags`. Or pass --base=<ref> explicitly.'
    );
    process.exit(1);
  }
  return base;
}

/** Published barrel SOURCES for a package, derived from its exports map. */
function barrelsFor(pkgDir) {
  const pkgJson = join(pkgDir, 'package.json');
  if (!existsSync(pkgJson)) return [];
  const { exports: map } = JSON.parse(readFileSync(pkgJson, 'utf8'));
  if (!map) return [];
  const out = new Set();
  for (const [subpath, entry] of Object.entries(map)) {
    const types = typeof entry === 'object' ? entry?.types : entry;
    if (typeof types !== 'string' || !types.endsWith('.d.ts')) continue;
    const sourceEntry =
      subpath === '.' ? 'index' : subpath.replace(/^\.\//, '');
    const src = [
      join(pkgDir, 'src', `${sourceEntry}.ts`),
      join(pkgDir, 'src', sourceEntry, 'index.ts'),
    ].find(existsSync);
    if (src) out.add(relative(ROOT, src));
  }
  return [...out];
}

/**
 * Exported names from one barrel at one revision, following `export *` into the
 * modules behind it. Named re-exports publish exactly the names they list, so
 * those are NOT followed — the same rule `api-surface.mjs` learned after
 * counting our internals against competitors' public APIs.
 */
/**
 * `typesOnly` harvests a module's exported TYPE names without its values.
 *
 * Needed because a NAMED re-export — `export { restoration } from './…'` — used
 * to note the value and stop. The module's config interface never entered the
 * public name set, so none of its members were ever diffed, even though every
 * option a user can pass to `restoration()` is public API by way of that
 * signature. Proven blind: a brand-new `RestorationConfig` member was invisible
 * and the gate still reported "0 uncovered".
 *
 * Harvested as kind `'type'`, which the coverage rules ignore, so this widens
 * MEMBER checking without demanding that type names themselves be documented.
 * It over-includes types a module exports but no signature uses — the safe
 * direction for a gate whose failure mode is a silent green.
 */
function symbolsAt(
  rev,
  relPath,
  seen = new Set(),
  out = new Map(),
  depth = 0,
  typesOnly = false
) {
  if (depth > 6 || seen.has(`${typesOnly ? 'T' : 'V'}${relPath}`)) return out;
  seen.add(`${typesOnly ? 'T' : 'V'}${relPath}`);
  const text = showAt(rev, relPath);
  if (text == null) return out;

  const sf = ts.createSourceFile(relPath, text, ts.ScriptTarget.Latest, true);

  const resolveSpecifier = (spec) => {
    const base = join(dirname(relPath), spec);
    for (const cand of [`${base}.ts`, join(base, 'index.ts')]) {
      const norm = relative(ROOT, resolve(ROOT, cand));
      if (showAt(rev, norm) != null) return norm;
    }
    return null;
  };

  const pkg = relPath.split('/')[1] ?? 'unknown';
  const note = (name, kind) => {
    if (typesOnly && kind !== 'type') return;
    // A name re-exported as a value anywhere wins: `export type { X }` in one
    // barrel and `export function X` in another must not downgrade to a type.
    if (kind === 'value' || !out.has(name)) out.set(name, { kind, pkg });
  };

  for (const st of sf.statements) {
    if (ts.isExportDeclaration(st)) {
      if (st.exportClause && ts.isNamedExports(st.exportClause)) {
        for (const el of st.exportClause.elements) {
          note(el.name.text, st.isTypeOnly || el.isTypeOnly ? 'type' : 'value');
        }
        // A named re-export publishes only those names — but a re-exported
        // FUNCTION drags its parameter and return types into the public surface
        // with it. Harvest the source module's types so their members are
        // diffed. Values are deliberately not harvested: they are genuinely
        // not exported by this barrel.
        if (st.moduleSpecifier) {
          const next = resolveSpecifier(st.moduleSpecifier.text);
          if (next) symbolsAt(rev, next, seen, out, depth + 1, true);
        }
      } else if (!st.exportClause && st.moduleSpecifier) {
        const next = resolveSpecifier(st.moduleSpecifier.text);
        if (next) symbolsAt(rev, next, seen, out, depth + 1, typesOnly);
      }
      continue;
    }
    const mods = ts.canHaveModifiers(st) ? ts.getModifiers(st) ?? [] : [];
    if (!mods.some((m) => m.kind === ts.SyntaxKind.ExportKeyword)) continue;
    const isType =
      ts.isTypeAliasDeclaration(st) || ts.isInterfaceDeclaration(st);
    if (ts.isVariableStatement(st)) {
      for (const d of st.declarationList.declarations) {
        if (ts.isIdentifier(d.name)) note(d.name.text, 'value');
      }
    } else if (st.name && ts.isIdentifier(st.name)) {
      note(st.name.text, isType ? 'type' : 'value');
    }
  }
  return out;
}

/**
 * Members of the PUBLIC interfaces, at a revision.
 *
 * Barrel exports alone are not the capability surface, and assuming they were
 * made the first version of this gate BLIND to the exact failure it was written
 * for: `prependOne`, `activeEntity`, `setActiveId`, `changeId`,
 * `pauseRecording` and `shouldSkip` are all METHODS on `EntitySignal` /
 * `RestorationMethods` / `RestorationConfig`. Not one is an exported symbol, so
 * not one appeared in the diff — the gate passed while its own target was
 * broken, and `--self-test` said so.
 *
 * So: resolve which exported names are interfaces, then diff their members too.
 */
function membersAt(rev, exportedNames) {
  const files = git('ls-tree', '-r', '--name-only', rev, 'packages/')
    .split('\n')
    .filter((f) => f.endsWith('.ts') && !f.includes('.spec.'));
  const members = new Map();
  for (const f of files) {
    const text = showAt(rev, f);
    if (!text || !text.includes('export interface')) continue;
    const sf = ts.createSourceFile(f, text, ts.ScriptTarget.Latest, true);
    const pkg = f.split('/')[1] ?? 'unknown';
    for (const st of sf.statements) {
      if (!ts.isInterfaceDeclaration(st)) continue;
      const mods = ts.canHaveModifiers(st) ? ts.getModifiers(st) ?? [] : [];
      if (!mods.some((m) => m.kind === ts.SyntaxKind.ExportKeyword)) continue;
      if (!exportedNames.has(st.name.text)) continue;
      for (const m of st.members) {
        if (!m.name || !ts.isIdentifier(m.name)) continue;
        // `__`-prefixed members are internal plumbing by convention.
        if (m.name.text.startsWith('__')) continue;
        if (!members.has(m.name.text)) {
          members.set(m.name.text, { kind: 'member', pkg, on: st.name.text });
        }
      }
    }
  }
  return members;
}

/** Diagnostic codes present in package sources at a revision. */
function codesAt(rev) {
  const files = git('ls-tree', '-r', '--name-only', rev, 'packages/')
    .split('\n')
    .filter((f) => f.endsWith('.ts') && !f.includes('.spec.'));
  const codes = new Set();
  for (const f of files) {
    const text = showAt(rev, f);
    if (!text) continue;
    for (const m of text.matchAll(/\[(ST\d{4})\]/g)) codes.add(m[1]);
  }
  return codes;
}

/**
 * The surfaces that CLAIM to describe the library. Adding one here puts it in
 * the sweep permanently — which is the whole point, since the failure that
 * prompted this gate was a surface missing from a hand-written list.
 *
 * `applies` keeps each surface honest about its own job: the error registry
 * indexes diagnostic codes and should not be failed for missing a type alias;
 * the demo demonstrates runtime API and should not be failed for a type either.
 */
const SURFACES = [
  {
    name: 'kernel README',
    files: ['packages/kernel/README.md'],
    applies: (r) =>
      !r.isCode &&
      (r.kind === 'value' || r.kind === 'member') &&
      r.pkg === 'kernel',
  },
  {
    name: 'error registry',
    files: ['docs/errors/README.md'],
    applies: (r) => r.isCode,
  },
  {
    // THE AI-PRIMING SURFACE, and the reason this gate exists at all — see the
    // `49dd9ffb` note in the header: llms.txt scored ZERO on 14.0.0's additions
    // while every claim->API gate stayed green. It was then NOT in this list on
    // the 15/16 line, so it drifted again: it said "the public v15 construction
    // model" on a 16.0.0-dev tree, described `transactions()`'s
    // pending/confirm/rollback lifecycle after the grammar became
    // `transact()` / `propose()`, claimed four packages when five ship, omitted
    // `@signal-tree/solid` entirely, and named 14.1.3 after 14.1.4 shipped.
    // Nothing caught any of it, because nothing was looking.
    //
    // Scoped to kernel VALUES only, deliberately. This is a 180-line
    // orientation document, not an API index: demanding every framework
    // re-export and every type produces the permanent noise the CHANGELOG note
    // below warns about, and a gate people learn to skim is worse than none.
    // What it must carry is the GRAMMAR a consumer writes.
    name: 'llms.txt',
    files: ['llms.txt'],
    applies: (r) =>
      !r.isCode &&
      (r.kind === 'value' || r.kind === 'member') &&
      r.pkg === 'kernel',
  },
  {
    name: 'CHANGELOG',
    files: ['CHANGELOG.md'],
    // Every new VALUE, across every package — a callable a consumer can now
    // write is a release note whether or not core shipped it. Types are
    // excluded on purpose: demanding a changelog line per interface produces
    // permanent noise, and a gate people learn to skim is worse than no gate.
    applies: (r) => r.kind === 'value' || r.kind === 'member',
  },
];

/**
 * Symbols that deliberately do not need to reach a surface, each with the reason
 * stated. An exemption is a DECISION, and a decision with no reason recorded is
 * indistinguishable from an oversight — which is the failure this gate exists to
 * catch, so it would be perverse to reintroduce it here.
 */
const EXEMPT = new Map(
  Object.entries({
    participation:
      'internal WriteMetadata replay discriminator; documented by causal-runtime architecture docs, not app-facing README/changelog',
    structuralEffect:
      'internal WriteMetadata structural replay payload; documented by causal-runtime architecture docs, not app-facing README/changelog',
    HydrateMode: 'authoring-only type; the modes are documented in prose',
    HydrateReason:
      'authoring-only type; reasons documented with onHydrateDecision',
    mutationIntent:
      'internal WriteMetadata rollback classifier; documented by causal-runtime architecture docs, not app-facing README/changelog',
    SerializedState: 'return type of an already-documented method',
    SerializationMethods:
      'method bag type; the methods are documented individually',
    PersistenceMethods:
      'method bag type; the methods are documented individually',
    transactionId:
      'internal WriteMetadata transaction token used by transactions()',
    getConfirmedRetention:
      '@internal member of InternalTransactionRuntime, not app-facing: supplies the explicit retention metadata the reader needs, because truncation must be asserted by the authority and never inferred from turn-id gaps. The public surface it feeds is confirmedTurnReader().readConfirmedTurns().retention, documented in the kernel README and the 15.3.0 CHANGELOG entry',
    setHistoryRetention:
      '@internal member of InternalTransactionRuntime, not app-facing: the documented public way to request diagnostic retention is the transactions({ history: { retain } }) option',
    transactionOwner:
      'internal WriteMetadata tree token used to isolate transactions()',
    addressFor:
      '@internal PositionRegistry member, not app-facing: resolves a PositionId to its typed segment address for link egress (link.ts). This is the L17 identity machinery that replaced string-path splitting; the public surfaces it serves are link() payloads and entity addressing, both documented',
    registerPositionAddress:
      '@internal PositionRegistry member, not app-facing: records a position\'s typed segment address at materialization (signal-tree.ts, entity-signal.ts). Same L17 machinery as addressFor',
    getInspectionFootprintCountsForTesting:
      '@internal test accessor, named so: exposes inspection writer/footprint counts so the retention of turn inspection state can be asserted without reaching into closure-local structures',
    getConfirmedRetention:
      '@internal member of InternalTransactionRuntime, not app-facing: supplies the explicit retention metadata internals.ts requires ("the authority must supply explicit retention metadata; never infer it from IDs"). The public surface it feeds is confirmedTurnReader().readConfirmedTurns().retention, and the behaviour change IS documented in the 16.0.0 CHANGELOG',
    setHistoryRetention:
      '@internal member of InternalTransactionRuntime, not app-facing: the public way to request diagnostic retention is the documented transactions({ history: { retain } }) option',
    describePendingTurn:
      "@internal member of InternalTransactionRuntime, not app-facing: returns UNCLASSIFIED raw material (a pending turn's effects and the later effects admitted against it) so PROPOSAL-INSPECTION-0 could prove the review classification derivable without inventing it in production first. The public surface it enabled is PendingTransaction.inspect(), which IS documented",
    // ── under active disposition in HIST-C2 step 7 ──────────────────────
    // These are declines WITH a stated deadline, not silent gaps. Each is a
    // real public config member today; each is slated to be deleted or
    // reconciled before 15.0 ships. If any of them survives to release, the
    // exemption is wrong and it must be documented instead.      'when the default flips. Implementation vocabulary; never a shipped option',
  })
);

// ── run ─────────────────────────────────────────────────────────────────────

const BASE = resolveBase();
const HEAD = 'HEAD';

const pkgDirs = git('ls-tree', '-d', '--name-only', HEAD, 'packages/')
  .split('\n')
  .map((d) => d.trim())
  .filter(Boolean);

const before = new Map();
const after = new Map();
let barrelCount = 0;
for (const dir of pkgDirs) {
  for (const barrel of barrelsFor(join(ROOT, dir))) {
    barrelCount++;
    for (const [k, v] of symbolsAt(BASE, barrel)) before.set(k, v);
    for (const [k, v] of symbolsAt(HEAD, barrel)) after.set(k, v);
  }
}

// Only interfaces public at BOTH revisions. A newly-EXPORTED interface would
// otherwise dump every field it has ever had into the delta as "new" — the
// members did not change, the type's visibility did, and the type name is
// already in the diff at the right granularity.
/**
 * Members are compared only for types present in BOTH revisions.
 *
 * For a type that is NEW this release every member is trivially new, so
 * enumerating them would bury the report — that part is deliberate. The
 * CONSEQUENCE was not: a member added to a newly-exported type stays invisible
 * for the whole release cycle, because the type sits outside `stableTypes`
 * until the next tag.
 *
 * Not hypothetical. `SerializationConfig` became exported in 14.0.0, so
 * `transfer` — a new public option, the flag deciding whether SSR payloads are
 * kept or thrown away — was added to it and reached ZERO priming surfaces while
 * this gate reported full coverage.
 *
 * The blind spot stays (the alternative is a flooded report) but it is now
 * PRINTED. A gate that cannot see something has to say so, or its green reads
 * as a stronger claim than it is.
 */
const stableTypes = new Set([...after.keys()].filter((n) => before.has(n)));
const newlyExportedTypes = [...after.keys()].filter(
  (n) => !before.has(n) && /^[A-Z]/.test(n)
);
const membersBefore = membersAt(BASE, stableTypes);
const membersAfter = membersAt(HEAD, stableTypes);

const codesBefore = codesAt(BASE);
const codesAfter = codesAt(HEAD);

const added = [
  ...[...after.entries()]
    .filter(([name]) => !before.has(name))
    .map(([name, meta]) => ({ name, ...meta, isCode: false })),
  ...[...membersAfter.entries()]
    .filter(([name]) => !membersBefore.has(name) && !after.has(name))
    .map(([name, meta]) => ({ name, ...meta, isCode: false })),
  ...[...codesAfter]
    .filter((c) => !codesBefore.has(c))
    .map((name) => ({ name, kind: 'value', pkg: 'core', isCode: true })),
].sort((a, b) => a.name.localeCompare(b.name));

/**
 * COVERAGE PROBE — how many things this gate is checking right now.
 *
 * The self-test harness mutates a gate's target and requires the gate to fail.
 * That premise silently assumes the gate HAS something to check. This one's
 * coverage set is "public symbols added since the last release", which is
 * legitimately EMPTY for a patch that adds no API — and then no mutation of a
 * claim surface can make it fail, so the harness reported it BLIND: "passed
 * while broken". Nothing was broken. There was nothing to break.
 *
 * Reporting the size lets the harness tell those apart. Deliberately the gate's
 * OWN count rather than a guess made by the harness, because only the gate
 * knows what it covers.
 */
if (process.argv.includes('--coverage-count')) {
  console.log(String(added.length));
  process.exit(0);
}

console.log(
  `\nRelease-delta claim coverage — ${BASE} -> ${HEAD}\n` +
    `${barrelCount} published barrels across ${pkgDirs.length} packages; ` +
    `${added.length} added symbol(s)/code(s).\n`
);

if (added.length === 0) {
  console.log('Nothing added since the base tag — nothing to claim.\n');
  process.exit(0);
}

const surfaceText = new Map();
for (const surface of SURFACES) {
  surfaceText.set(
    surface.name,
    surface.files
      .map((f) =>
        existsSync(join(ROOT, f)) ? readFileSync(join(ROOT, f), 'utf8') : ''
      )
      .join('\n')
  );
}

/**
 * Does this surface actually NAME the symbol, as a word?
 *
 * ⚠️ This was `text.includes(name)`, a bare substring test, and it silently
 * satisfied any symbol whose name is a PREFIX of a word already on the page.
 * Measured: `transact` was reported covered by llms.txt purely because the file
 * said `transactions()` — the very drift this gate was extended to catch would
 * have passed. `propose` / `proposal`, `link` / `linked`, `external` /
 * `externalise` are the same shape.
 *
 * A word boundary is the honest test. `\b` is wrong at both ends here because
 * these names appear as `tree.transact(fn)`, `` `transact()` `` and
 * `transact,` — so the boundary is "not a JS identifier character", which
 * treats `.`, `(`, backtick and punctuation as separators while still
 * rejecting `transactions`.
 */
const mentions = (text, name) =>
  new RegExp(
    `(^|[^A-Za-z0-9_$])${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Za-z0-9_$]|$)`
  ).test(text);

const gaps = [];
const rows = [];
for (const rec of added) {
  const missing = [];
  let applicable = 0;
  for (const surface of SURFACES) {
    if (!surface.applies(rec)) continue;
    applicable++;
    if (!mentions(surfaceText.get(surface.name), rec.name)) {
      missing.push(surface.name);
    }
  }
  const exemptReason = EXEMPT.get(rec.name);
  rows.push({ ...rec, missing, applicable, exemptReason });
  if (missing.length && !exemptReason) gaps.push(rec.name);
}

const covered = rows.filter((r) => !r.missing.length).length;
const exempted = rows.filter((r) => r.missing.length && r.exemptReason).length;

if (LIST_ONLY || gaps.length) {
  console.log('');
  for (const r of rows) {
    // `--list` is documented as "show the delta", so it shows every symbol in
    // it. It used to print only the gaps, which meant a fully-covered release
    // printed nothing at all — indistinguishable from an EMPTY delta, and an
    // empty delta is exactly the condition that makes this gate blind. Anyone
    // reaching for --list to find out what the release added got silence.
    if (!LIST_ONLY && !r.missing.length) continue;
    const tag = r.exemptReason
      ? 'exempt '
      : r.missing.length
      ? 'MISSING'
      : 'covered';
    const kind = r.isCode ? 'code' : r.kind;
    console.log(
      `  ${tag} ${r.name.padEnd(30)} ${`(${kind}, ${r.pkg})`.padEnd(18)} ${
        r.missing.join(', ') || `all ${r.applicable} surfaces`
      }`
    );
    if (r.exemptReason) console.log(`          └─ ${r.exemptReason}`);
  }
  console.log('');
}

// Report what was COVERED, not just that nothing failed — a gate that prints
// only "✅" is indistinguishable from a gate that checked nothing, which this
// repo has now been bitten by three separate times.
console.log(
  `  ${covered} covered on every applicable surface · ` +
    `${exempted} exempt with a stated reason · ${gaps.length} uncovered.\n`
);

if (LIST_ONLY) process.exit(0);

if (gaps.length) {
  console.log(
    '❌ A capability this release adds is missing from a surface that claims to\n' +
      '   describe the library. Add it there, or add it to EXEMPT in this file\n' +
      '   WITH A REASON — an undocumented decline is what this gate exists to catch.\n'
  );
  process.exit(1);
}

console.log(
  '✅ every added symbol reaches every surface that should carry it.\n'
);

// A gate that cannot see something has to say so, or its green is read as a
// stronger claim than it is. See the note on `stableTypes`.
if (newlyExportedTypes.length) {
  console.log(
    `   ⚠ NOT CHECKED: members of ${newlyExportedTypes.length} newly-exported ` +
      `type(s) —\n     ${newlyExportedTypes.slice(0, 8).join(', ')}` +
      `${newlyExportedTypes.length > 8 ? ', …' : ''}.\n` +
      `     A member added to a type that became exported THIS release is\n` +
      `     invisible to this gate until the next tag. Check those by hand:\n` +
      `     that is how \`SerializationConfig.transfer\` reached zero surfaces\n` +
      `     while this line said full coverage.\n`
  );
}
