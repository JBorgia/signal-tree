# Remaining original130k functional cases — passed under new operational envelope

Source: `/private/tmp/st-v16-integration-candidate`, exact manifest `8bd6920bb81f676466a1c7d12d61395766694d881fcf2aa8c2dcdd35b5dce670`. Main authorized this NEW finite packet after accepting the independent resource interpretation. It does not overwrite or retry within the stopped2GiB protocol. That first stop remains byte-identical.

The explicit graph precheck reused `/private/tmp/st-large-qualification/graph-original` for the exact candidate cwd; exit0, resolved kernel test target verified. No third cold graph copy, rebuild, task-result cache or passed-case replay was introduced. The nine small cases, four2048 screens and original130k membership pass were reused with identity-bound receipts in PREREGISTRATION.json.

| Remaining original case | Result | Fresh worker | Maximum sampled aggregate owned RSS bytes | Minimum sampled host free percentage |
| --- | --- | --- | --- | --- |
| replacement undo/redo | exit0, exactly1 selected pass |58618|2,795,274,240|32%|
| directed restoration jumps | exit0, exactly1 selected pass |59352|1,711,292,416|32%|
| truncated-history claim release | exit0, exactly1 selected pass |59649|1,904,017,408|33%|

Each was invoked once, sequentially, with original130k bodies/assertions and120s source timeouts. External360s invocation and180s structured-no-progress limits were unchanged. No heap flags, forced GC, profiler, runtime edits, timeout raises or further cap increases. Every result has zero source/dependency drift and no surviving owned processes.

The new sampled abort envelope was4,294,967,296 aggregate owned-process RSS bytes and a25% minimum on `memory_pressure -Q`. Neither tripped. Per-PID RSS, PID/PPID, birth, command, poll monotonic timestamps, and census/host-command latency are preserved at every sample in telemetry.jsonl; SUMMARY.json records extrema and validates aggregate sums. Full manifests were hashed only outside execution. Actual host total was34,359,738,368 bytes. The reported host percentage is not independently established available-byte headroom; summed RSS can double-count shared pages and sampling can miss peaks or overshoot before termination. These are operational guards, not release/library budgets or heap-cost evidence.

`I7-PARTITION.json` now binds all four original large obligations to passing disjoint receipts: membership under the earlier2GiB/12.5% envelope and these three under the new4GiB/25% envelope. The nine small cases remain separately passed; four2048 screens do not inflate original coverage. Do not rerun these merely to obtain whole-file totals. This functional qualification neither erases the preserved2GiB operational abort nor establishes acceptable memory cost, a leak diagnosis, OOM resolution or performance benefit.

Final verification: all3,127 candidate source hashes match; complete five-package artifact seal unchanged at `sha256-4e10ab551ba731818b9ab68941f7da013cd79c33920518c6eff2d8b501c8d012`; old2GiB STOP and new controller hashes unchanged. Final census across all worker packets:168 recorded owned processes, none surviving, all command receipts complete. No sessions remain running. Sole heavy slot retained and idle; no further campaign queued.

Separate unchanged limitation: the fresh integration bundle-budget gate still fails. The installed kernel and Angular I7 workflows both passed against the sealed artifacts; neither those passes nor these functional tests waive bundle budgets or grant release sign-off.
