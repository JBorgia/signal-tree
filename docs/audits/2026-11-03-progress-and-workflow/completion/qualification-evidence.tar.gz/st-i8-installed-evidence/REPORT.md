# I8 installed guidance qualification

Angular installed/AOT/runtime: exit 0, two runtime cases. Strict installed guidance Bundler and Node16: both exit 0. Exact argv, cwd and environment are in runs/*/COMMAND.json; first logs and results are preserved. No retries or first failures. Runtime evidence covers the standalone component class and Angular computed runtime, not browser bootstrap/DOM.

All 3127 source files and 193 built artifact files match the 8bd checkpoint. Both preservation archives were read back and their complete regular-file contents match their maps. Reviewed input and prior consumer evidence comparisons remain separately recorded. Proposed documentation is not yet part of the old package seal.
