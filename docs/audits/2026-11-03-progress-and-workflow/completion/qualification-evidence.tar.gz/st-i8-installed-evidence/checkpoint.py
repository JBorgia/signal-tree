from pathlib import Path
import json,hashlib,tarfile,datetime
p=Path(__file__).resolve().parent;c=Path('/private/tmp/st-v16-integration-candidate');q=Path('/private/tmp/st-v16-integration-evidence');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();m=json.loads((q/'MANIFEST.json').read_text());bad=[n for n,h in m.items() if not (c/n).is_file() or sha(c/n)!=h];assert not bad
with tarfile.open(p/'8bd-source.tar','x') as archive:
 for n in sorted(m):
  assert not (c/n).is_symlink();archive.add(c/n,arcname=n,recursive=False)
packages=json.loads((q/'BUILD-SEAL.json').read_text())['packages'];paths=[]
for name in packages:
 root=c/'dist/packages'/name;paths.extend([root]+sorted(root.rglob('*')))
assert all(not f.is_symlink() for f in paths)
artifacts={str(f.relative_to(c)):sha(f) for f in paths if f.is_file()};assert len(artifacts)==193
with tarfile.open(p/'8bd-built-packages.tar','x') as archive:
 for f in paths:archive.add(f,arcname=str(f.relative_to(c)),recursive=False)
(p/'ARTIFACT-HASHES.json').write_text(json.dumps(artifacts,indent=2)+'\n')
r={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':str(c),'manifestPath':str(q/'MANIFEST.json'),'manifestSha256':sha(q/'MANIFEST.json'),'sourceFiles':len(m),'sourceMismatches':bad,'buildReceipt':str(q/'BUILD-SEAL.json'),'buildReceiptSha256':sha(q/'BUILD-SEAL.json'),'artifactFiles':len(artifacts),'archives':{n:{'sha256':sha(p/n),'bytes':(p/n).stat().st_size} for n in ['8bd-source.tar','8bd-built-packages.tar']},'excludes':'No node_modules, Nx/npm caches, unrelated root files or proposed edits copied','originalCandidateUnmodified':True,'composition':'not started; awaiting exact reviewed allowlist'}
(p/'8BD-CHECKPOINT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
