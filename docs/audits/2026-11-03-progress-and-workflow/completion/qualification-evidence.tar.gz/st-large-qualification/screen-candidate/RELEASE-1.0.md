> **Historical ledger — October 1, 2026.** Use [RELEASE-CURRENT.md](RELEASE-CURRENT.md)
> for this checkout's active scope. Original evidence and anchors below are preserved;
> old phase labels, next-action lists and review choreography are historical.

# SignalTree 1.0 Release

Single source of truth for the remaining work between current HEAD and a
credible `1.0.0` release candidate.

This is the release controller, not the full historical backlog. Use it to
bound autonomous agent work, checkpoint decisions, and prevent context drift.

## Transaction failure policy alignment — September 28, 2026

Owner approved the v15 automatic-abort containment policy: when compensation
refuses before a handle can be returned, record surviving writes as committed,
retain eligible restoration history, release consequences, and throw the refusal.
The v16 target remains pending authority with a usable recovery handle; only an
explicit confirmation releases durable consequences.

Policy checkpoint `77946530` on `fix/d1-d2-forward-port` added this distinction.
A subsequent direct characterization corrected one statement: existing v15
explicit-handle refusal retains the handle **but releases consequences**. The
support policy now records that compatibility exception instead of claiming the
v16 target already holds. No explicit-rollback runtime change was made.

Implementation and tests remain in the separate `fix/15.3.1-link-rollback-and-strand`
worktree. Repair checkpoint `0faa878d` passed the recorded source and packed
checks. The owner then approved the five-byte excess: the bare production
ceiling is 10.26 KiB and the size gate passes. Exact-release verification and
publication remain outstanding. See that worktree's
`docs/audits/2026-09-28-v15-round4-followup.md` for the first reds and final checks.
No runtime forward-port, tag, push, or publication is implied by this policy update.

## Packed Angular AOT consumer release coverage — September 17, 2026

Owner authorized shipping the AOT fix and strengthening runtime consumer evidence.
A new isolated Angular CLI production app installs the actual kernel/Angular
packages, excludes the compiler from its browser bundle, exercises repeated
OnPush rendering, recreates a component owner and verifies root/component teardown.
The original runtime decorator must fail specifically with missing JIT/compiler
at bootstrap. CI now installs Chromium and uses Node 24.15.0, the supported Node
24 minimum required by installed Angular CLI 22.

V3 tracking coverage now includes incremental entity writes, captured leaf and
computed references, selected-ID reordering, selection subtree replacement and
snapshot restore. All 15 focused tests, test types, lint and formatting pass;
untracking the captured read makes exactly the three added cases fail. V3
checkpoint: `2479d61bb`. Studio preview was recovered by restarting its stale
server; 641 private tests pass and the browser records fixture writes without
errors. V3's explicit Studio command runs on port 4206 (`45dc17d80`).

Focused packed AOT self-test passes on Node 24.15.0. Explicit supplied tarballs
pass with SHA-512 installation and single-kernel resolution checks; incompatible
artifacts are rejected before installation. Independent review findings on
artifact identity and cleanup were fixed. The first canonical attempt passed 78/79 checks;
the sole failure was a new non-null assertion warning in the AOT fixture. An
explicit missing-store error replaces that assertion; no lint allowance changed.

Published 15.1.4 from signed tag `v15.1.4`, commit `0c41772a`. Canonical local
release passed 79/79 gates. Tagged Release run `35264201596` and Publish run
`35264248410` both passed all release gates and mutation proofs. All four registry
tarballs match the immutable candidate SHA-512 hashes. Those downloaded artifacts
pass production AOT bootstrap, repeated rendered writes, component recreation,
local/root teardown and compiler exclusion with no browser errors; all four also
pass strict Bundler/Node16 consumers and facade runtime identity checks.

Private Studio commit `e25f283` adopts public 15.1.4. Its full release verification
passes 641 tests, strict consumers, browser acceptance and artifact agreement.
The rebuilt preview records fixture writes without browser errors. GeoTrax with
published 15.1.4 passes its production build and all 15 focused tracking tests.
V3's temporary Angular patch is removed in favor of the published package. The
installed Chrome extension panel still requires a human reload/connection check;
browser automation cannot access chrome://extensions.

## Angular AOT store bootstrap — September 17, 2026

Fixed `defineStore` runtime DI registration after GeoTrax reproduced a missing
JIT compiler error during bootstrap. The local class now supplies its injectable
definition directly; store identity, local/root/platform scopes and injector-owned
teardown remain unchanged. The original runtime decorator fails the new fresh-Node
compiler-free fixture. The fixed source and built implementation pass, including
production mode. The fixture is now a mutation-proven fast gate.

Validation: Angular 123 passed / 3 skipped; Angular build and lint passed (eight
existing typing-fixture warnings); source/kernel typecheck passed; formatting and
59/59 fast gates passed. GeoTrax production build and browser sign-in passed with
zero console errors using a recorded pnpm patch (V3 commit `43b76d0a1`).
At that checkpoint this was an unreleased source fix. It subsequently shipped in
15.1.4 with the packed consumer evidence recorded above.

## Generic construction and terminal declarations — September 16, 2026

Implementation checkpoint: `5ce1458f` (typing-fixture lint follow-up `13dd2a2e`).
Published as `15.1.3` from signed tag `v15.1.3`, release commit `a05fe488`.

Publication verification: canonical preparation passed all 77 release gates.
Tagged [release CI](https://github.com/JBorgia/signal-tree/actions/runs/35158659963)
and sanctioned [npm CI](https://github.com/JBorgia/signal-tree/actions/runs/35158751705)
both passed their full matrices and gate mutation proofs. Kernel, Angular, React
and Vue resolve to `15.1.3` on npm's `latest` channel. All four downloaded tarball
SHA-512 values match the local immutable candidate; a fresh external consumer
passed runtime facade identity and strict bundler/node16 typechecking. Registry
metadata and tarballs initially lagged publication; verification was completed
only after all downloads became available.

Owner's inference concern was checked explicitly: exact entity, key, computed
slice, filter and derived return types remain inferred; an anti-`any` assertion
passes, and invalid keys, entity/filter writes and derived writes remain compile
errors. No `any` escape hatch or removal of recursive branch validation was used.

Owner identified that `EntityMapMarker<unknown, ...>` cannot accept real marker
configuration callbacks contravariantly. Construction now excludes the config
payload while retaining the opaque brand and runtime marker. Generic entity and
filter factories compile without casts or application constraints. Packed proof
caught a private-brand symbol missing from bundled adapter declarations; the
final formulation avoids referencing that private symbol across entry points.

Shared return types now preserve native leaf carriers for weak collections,
buffers, promises, typed functions and constructors, and unwrap optional/union
leaf definitions. Inline enhancer-plus-derived inference and explicit factory
generics are covered. Native Angular signals and Vue refs remain rejected unless
explicitly stored as data. Computed EntityMap slices reject native API names
before materialization; runtime parity tests keep the reserved names aligned.
This guard costs about 0.19KB compressed, measured by
`node tools/check-bundle-budget.mjs`; its explicit budget adjustment is recorded
beside the authoritative gate rather than hidden by a skipped check.

Validation: all four package test/build/lint targets passed (kernel 2305 passed,
7 expected failures, 13 skipped, one TODO; Angular 123 passed, 3 skipped;
React 9; Vue 33). Final collision parity test passed in the focused 16-test
marker suite. Source/kernel typing, spec-type ratchet (223 existing diagnostics,
none added), formatting, packed bundler/node16 consumers and 58/58 fast gates
passed. TruckTrax Geotrax's actual strict application compilation reproduces the
15.1.2 detached-slice failure and passes with rebuilt declarations (zero
diagnostics), using temporary compiler paths and one Angular peer; no V3 source
or dependency files were modified. Full release matrix remains mandatory before
tagging/publication. The first full attempt caught one type-fixture-only lint
warning (a store token used only in a type); returning that token from the proof
closed it. The full lint ratchet is green at its unchanged 19-warning baseline.

## Framework store ownership contracts — September 16, 2026

Implementation checkpoint: `e3ebcb91`. Published in `15.1.3`; see verification above.

Owner requested tighter framework-native lifetime and factory contracts, without
adding competing construction APIs. Angular `defineStore` now accepts only
object/function factory results, rejects primitives at runtime for JavaScript
callers, and preserves valid result identity. Cleanup invokes only callable
`destroy` methods with their receiver. Failures use Angular's default error
reporter: throwing aborts sibling cleanup, eager app-handler injection creates
cycles with diagnostic stores, and the owning injector is already destroyed
when teardown callbacks run. No custom handler is resolved during store creation.

The Angular recipe shares one writable owner with Ops and a non-owning readonly
`$` provider. The readonly token's limits apply to every consumer, not just
components. React documents externally owned application/request trees and
borrowed StrictMode consumers. Vue documents owned scopes and borrowed trees.
Focused tests prove these ownership boundaries; no new framework constructor or
kernel ownership mechanism was added.

Validation: Angular 121 passed (3 skipped), React 9 passed, Vue 31 passed;
framework package build/lint, source/kernel typing, spec-type ratchet (223
existing diagnostics, none added), packed consumers under bundler and node16,
58/58 fast gates, formatting, and independent review. Final reporter revision
was rebuilt and retested; final packed artifacts passed consumer checks.
No full release/benchmark matrix or npm publication was performed.

## Framework construction ownership — September 16, 2026

Implementation checkpoint: `6676f976`. Published as `15.1.2` from signed tag
`v15.1.2`, release commit `2efe0010`.

Publication verification: canonical local preparation and tagged CI passed all
77 release gates. GitHub release run
[35129289141](https://github.com/JBorgia/signal-tree/actions/runs/35129289141)
and sanctioned npm run
[35129444208](https://github.com/JBorgia/signal-tree/actions/runs/35129444208)
completed successfully, including gate mutation proofs. Kernel, Angular, React
and Vue all resolve to `15.1.2` on npm's `latest` channel, and all four downloaded
tarball SHA-512 values match the local immutable candidate. A fresh external
consumer passed runtime facade identity and strict bundler/node16 type checks.
Published-package probes passed Angular signal rejection, Vue ref/proxy rejection,
explicit reactive data identity and independent snapshots. Production demo build
passed. The first preparation run's sole failure was missing helper documentation;
that was corrected before the successful full run and signed tag.

Owner-requested protection rejects implicit external Angular signals and Vue
refs/proxies in construction topology. Diagnostics and native identity checks
belong to the framework facades. The adapter SDK's `isConstructionBranch` only
answers the kernel-owned topology question; no primitive-detection hook was
added to kernel construction or observation contracts. Existing native inputs
must not silently look tree-owned while their captured external writers bypass
causal turns and restoration (see the external-signal evidence in archived
RFC 0016). Explicit `leaf(existing)` remains external reactive data; a plain
value snapshot starts independent state. Arrays, built-ins and marker contents
remain opaque. React has no corresponding native signal primitive to reject.

Framework preparation reads branch properties once and retains symbol metadata
for kernel marker diagnostics. Type constraints reject known signals/refs while
preserving scalar/container generics, derived inference and enhancer additions.
Vue proxies need runtime checks; their structural types can look like plain data.
Checks cover initial construction only, not subsequent writes or foreign runtimes.

Validation: Angular 107 passed (3 skipped), Vue 28 passed, kernel 2300 passed
(7 expected failures, 13 skipped, one TODO), React 7 passed; all four package
build/lint targets; final edited-source lint clean; source/kernel typing and the
spec-type ratchet passed (223 existing diagnostics, none added). Packed consumers
passed runtime identity and bundler/node16 type checks. Fast gates passed 58/58,
including bundle budgets and API inventory. Final symbol-descriptor cleanup was
then rebuilt and retested in Angular/Vue. Independent review caught and closed
lost symbol diagnostics and overly strict generic scalar constraints. This is
not a full release or benchmark-matrix run.

## Development tooling follow-up — September 14, 2026

Implementation checkpoint: `eeb87868`.

Owner approved `withWriteObservationScope(ownerId, token, write)` on the existing
`@signal-tree/kernel/internals` tooling entrypoint. Declarations are captured at
notification creation, owner-qualified, immutable and bounded to eight tokens;
coalescing retains explicit unscoped/omitted flags independently of semantic
metadata. Subscriber and flush delivery suspend only diagnostic scopes. This
neither creates transactions nor changes their admission, partitions or rollback.
Mixed semantic metadata no longer erases the explicit observed tree namespace.
Private Studio owns labels, attempts, recording, transport and UI; none moved here.

Validation: 44 focused tests; full kernel suite 2300 passed, 7 expected failures,
13 skipped and one TODO; source/typing checks and scoped lint passed; kernel build,
production demo build and generated production/development bundle budgets passed.
The first sandboxed demo attempt exited without diagnostics; the escalated retry
passed. This is a local development API addition, not a registry release or tag.

## Current Phase

Current phase: `Phase 7 — COMPLETE / GA RELEASED`

`15.0.0` is **GA RELEASED / REGISTRY-VERIFIED** at `8418cd7d`. Canonical
preparation passed `76/76`, created the immutable four-package candidate, and
pushed a signed replacement `v15.0.0` tag whose peeled commit and candidate
manifest are identical. Tagged run `34001591297` first failed closed at `75/76`
because GitHub lacked the signed `v14.1.1` release-claims baseline and therefore
fell back to `v0.1.15`; release creation and npm publication were both skipped.
The original signed `v14.1.1` tag object was restored without moving it, its
incidental historical workflow `34002381375` was cancelled, and automatic
release-claim selection then passed `138/138` from `v14.1.1`.

Attempt 2 of tagged run `34001591297` passed the complete `76/76` release matrix,
all `65/65` mutation proofs, version claims, artifacts, packed consumer, and
changelog checks. It created a non-draft, non-prerelease GitHub release.
Sanctioned publisher run `34002838449` independently repeated the full matrix
and mutation proofs before publishing `kernel → angular → react → vue`. All four
npm SHA-512 values match the immutable candidate and every package's `latest`
dist-tag is `15.0.0`.

Fresh exact-version and unversioned README installs both passed kernel
transaction/restoration/Link/EntityMap semantics, Angular native signals, Vue
synchronous coherence, React selector updates, and React server rendering.
Registry-downloaded tarballs passed facade runtime identity and strict consumer
typecheck under `bundler` and `node16`. TruckTrax V3 commit `07c13fdb5` promotes
its registry catalog and lockfile from rc.16 to stable candidate-matching hashes;
frozen install and all five SignalTree consumer typechecks pass uncached.

`POST-GA-DOC-CURRENCY-0` is **CLOSED** at `aa15cc0c`. Final review found one
live AI instruction still selecting npm's superseded `rc` channel and one
symlink guide whose mechanical v15 rename had combined the new
`@signal-tree/kernel` identity with old `@signaltree/core@5.1.2`; that hybrid
never existed. Both installs now select stable current packages. The live
documentation gate enforces publishability, explicit semver inclusion, and the
current release-channel dist-tag, and its link/tag self-tests and registered
mutations all fail closed.

`GATE G` is **SATISFIED**.

`15.0.0-rc.16` is **PUBLISHED / REGISTRY-VERIFIED** at `959019d9`. The signed
tag passed the exact-tag `76/76` release matrix and `65/65` mutation proofs.
Registry packages `kernel → angular → react → vue` match the immutable candidate
SHA-512 values and npm's `rc` dist-tag. A clean external install passed packed
runtime identity, strict `bundler` / `node16` declarations, kernel
transaction/restoration/Link/EntityMap semantics, Angular native signals, Vue
coherent refs, React selector updates, and React server rendering.

`V3-BROWNFIELD-CONSUMER-0` is **CLOSED / GREEN** at TruckTrax V3 commit
`e6405f12b`. The clean `migration/signaltree-v15-greenfield` branch installs
registry rc.16 with candidate-matching lockfile integrities, removes obsolete
`NaturalValue` and Geotrax carrier casts, and uses truthful Angular-facing
`EntitySignal` contracts without compatibility shims. Uncached typecheck,
tests, and lint pass for `store`, `core-services-v2`, `geotrax`, `scaletrax`,
and `trucktrax-geo`; production builds pass for all three apps. Independent
consumer review found no masked SignalTree defect.

The human ruling authorized **GA**. Framework-native carriers,
facade-polymorphic consumers, registry integrity, packed consumers, V3
brownfield adoption, source closure, official publication, and clean stable
registry proof are all closed. No further architecture or performance work is
authorized absent a direct post-release falsifier.

`GA-PROMOTION-0` is **CLOSED** at `aff1a0fd`. Release preparation promotes
`15.0.0-rc.16` to `15.0.0`, explicitly reclassifies the dated changelog heading,
and changes the documentation label from `Current prerelease` to
`Current release`. Version/changelog self-tests, live claims, lint, focused
release gates, mutation proofs, and independent release review are green.

`UNIVERSAL-LOCATIONS-0` closed the kernel-authority question at `5efeb7f5`, but
its universal first-party leaf-identity conclusion is **SUPERSEDED** by
`FRAMEWORK-NATIVE-CARRIERS-0` at `7ab2e82d`. The kernel still owns canonical
values, equality, revisions, positions, EntityMap identity, causal turns,
transactions, restoration, grouped publication, snapshots, and explicit owner
teardown. Framework carriers perform dependency tracking and native API
realization only; they do not create another state authority.

`CALLABLE-LOCATIONS-0` is **CLOSED / NARROWED** at `81780c4e` and `7ab2e82d`.
Neutral kernel locations plus root and object branches retain one grammar:
`location()` reads, `location(value)` replaces, and `location(updater)` derives.
`leaf(value)` ends topology explicitly and disambiguates callable data. Angular
terminal and EntityMap leaves instead expose native `.set()` / `.update()`
methods; Vue leaves expose `.value`; React observes neutral locations through
`useSignalTree`.

`FRAMEWORK-NATIVE-CARRIERS-0` is **CLOSED IN SOURCE** at `7ab2e82d`. Angular
writable leaves are `WritableSignal<T>` and derived/query leaves are `Signal<T>`;
Vue writable leaves are `Ref<T>` and derived/query leaves are `ComputedRef<T>`;
React remains hook-native over neutral kernel locations. Writable and readonly
carrier algebras are separate, packed declarations compile under `bundler` and
`node16`, and the complete native realization runtimes are reachable only from
`@signal-tree/kernel/adapter`, so neutral consumers do not ship them.

`FRAMEWORK-NATIVE-CARRIER-AUDIT-0` is **CLOSED IN SOURCE** at `63900634`.
Synchronous Vue observers now see one coherent root, transaction, EntityMap, or
restoration state; grouped publication remains dependency-scoped, including a
100-derived unrelated-work control. Native Angular/Vue `link()` values and the
`AccessibleNode` / `EntitySignalWithSlices` aliases are truthful in packed
declarations, ordinary branches may still own `all` / `setAll` keys, and Vue's
type-only readonly view no longer promises an intrinsic `ComputedRef` runtime.

`FINAL-RC-VERSION-RESUME-0` is **CLOSED** at `8e84d0f1`. The superseded
pre-carrier `v15.0.0` tag remains immutable and was never published to npm, but
it left workspace manifests at `15.0.0`; the former `release:rc` derivation
would therefore have produced the wrong line, `15.0.1-rc.0`. Preparation now
uses authoritative remote tags, resumes the highest same-base RC as
`15.0.0-rc.13`, ignores local-only tags, and requires explicit dated changelog
reclassification. Derivation/changelog self-tests, script lint, publication
architecture and authorization gates, both mutation proofs, and independent
review are green.

`15.0.0-rc.13` is **IMMUTABLE / NOT PUBLISHED** at `4b3c114a`. Local release
preparation passed `74/74`, created four validated candidate tarballs in
`kernel -> angular -> react -> vue` order, and pushed a verified signed tag.
Tagged GitHub run `33986219645` passed the complete `74/74` production matrix,
then correctly blocked release creation at the mutation matrix: `59/63` proved,
while kernel-neutrality, C6 Angular realization, release claims, and declaration
docs used stale anchors and remained green under mutation. No GitHub release or
npm write occurred. The four proof repairs and the complete live docs/demo
currency pass earn RC14; rc.13 is not moved or reused.

This breaking architecture correction supersedes the former clean-clone
technical-readiness checkpoint. Current ordinary evidence is green under the
canonical Node `24.3.0` runtime in `.nvmrc`: strict source and public typecheck;
kernel `2,178` passing tests plus two expected failures; Angular `99` passing / `3`
skipped; React `7`; Vue `13`; demo `145` passing / `4` skipped; lint with zero
errors and no warning-budget growth; forced-GC retention; `57/57` fast gates and
`65/65` ordinary gates; `24/24` declared artifact entries; packed consumer
typecheck under `bundler` and `node16`; facade runtime identity; `34` current
architecture assets; production package and demo builds; numeric claims
`176/176`; and bundle budgets at `9.95/10.0 KB` bare and `22.01/22.1 KB`
EntityMap production gzip. Independent final review found no blocker.

The controlled `84837fb3` method-form versus callable-location benchmark used
mirrored persistent workers, 30 paired samples, five warmups, and an identical-
current A/A control. Read, derivation, and construction intervals cross zero and
support no change claim. Scalar replacement measured `+6.6%`, about `+4.1 ns`,
with a paired p10-p90 interval of `+3.4%` to `+9.9%`; the corresponding A/A
interval was `-4.3%` to `+0.1%`. Both arms are independently installed tarballs
pinned by commit and full SHA-256 in the tracked raw samples.

The Angular-specific native-carrier comparison uses the same mirrored,
operation-isolated protocol against packed artifacts. Native leaves improve
scalar read by `77.3%`, replacement by `33.3%`, derivation by `39.0%`, fan-out
by `27.3-37.0%`, and a depth-10 chain by `15.5%`; the diamond overlaps the A/A
control. Construction is inconclusive at 10 leaves and slower by `17.5%` at 100
and `30.8%` at 1,000. Forced-GC density remains `1,934 B/leaf` unobserved for
both designs; after 10,000 observed leaves the native carrier remains
`1,934 B/leaf` versus `2,005 B/leaf`, and every sampled tree/leaf collects after
`destroy()`. These measurements select Angular's carrier only; they make no Vue
or React performance claim.

The final RC matrix, official stable operation, registry proof, and V3 consumer
confirmation are complete. The explicitly authorized stale pre-carrier
`v15.0.0` tag was replaced only after confirming it had no GitHub release or npm
publication; the replacement tag, release, registry artifacts, and `latest`
dist-tags are bound to the verified GA source above.

`GATE F` was **SATISFIED** at `109595e6` for the superseded representation. Exact committed HEAD passed all 69
ordinary and release-only gates with zero known-red. The independent Gate F
review found no critical, major, or minor blocker. `15.0.0-rc.1` remains the
first published candidate; RC6 is published but superseded by the strict
framework declaration failure recorded below.

The prior Phase 7 technical-readiness checkpoint was **CLOSED** against
clean-clone commit `8d0108bc`:

```text
frozen-lockfile install       GREEN
release matrix               69 / 69 GREEN
gate mutation/self-tests     60 / 60 GREEN
unproven / blind / errored   0 / 0 / 0
known technical GA blockers  NONE
```

All 60 registered gate mutation/self-tests successfully demonstrated their
associated gates can fail; this is distinct from the 69 release gates. GA is
held for two bounded v15-closure rows recorded in `TODO.md`:
`AI-SEMANTIC-DISCOVERABILITY-0` and `CAUSAL-REPRESENTATION-0`. They may clarify
the shipped model and select its physical representation, but may not add public
APIs, causal facts, compatibility layers, framework abstractions, or speculative
agent metadata. RC9 verification remains immutable evidence; after both rows
close, publish one final RC and repeat the real npm-consumer proof before the
human GA disposition.

`15.0.0-rc.2` is **IMMUTABLE / NOT PUBLISHED** at `e58f9459`. Local preparation
passed 69/69 and produced a signed tag plus validated exact tarballs. Tagged CI
failed `test:all` twice while 68/69 other gates passed on the second run. The
same shallow tag checkout passed all five projects under Node 22 when run through
the root sequential `test:all` command. `RC2-TEST-ALL-CI-0` identified the
release-gate mismatch: its Nx aggregate omitted `--parallel=1`, unlike the root
authority, allowing all memory-heavy suites to contend on the GitHub runner.
The gate is now sequential and failed-gate stdout/stderr is preserved. This
release-system correction earns RC3; RC2 remains historical evidence and its
tag is not moved.

`15.0.0-rc.3` is **IMMUTABLE / NOT PUBLISHED** at `145ec3fa`. Local preparation
passed 69/69, but tagged CI run `33576006919` failed `kernel:test` while every
other project and 68/69 release gates passed. The kernel wrapper collapsed a
signal termination to exit 1 and the release harness retained too little output
to identify the signal after later project logs displaced it. Commit `a6c4e0cf`
bounds kernel Vitest to two CI workers, reports child-process startup and signal
failures, and retains 100 KB of failed-gate diagnostics. Under Node 22 with
`CI=true`, kernel passed 2,154 tests plus three expected failures, `test:all`
and its mutation proof passed, and the complete release matrix passed 69/69.
This release-system correction earns RC4; the RC3 tag is not moved.

`15.0.0-rc.4` is **IMMUTABLE / NOT PUBLISHED** at `2aee7f27`. Tagged CI run
`33577413658` proved the worker correction: the complete 69-gate release matrix,
including `kernel:test`, passed. The separate mutation matrix then reported
59/60 because the `release-claims` proof still removed a symbol outside its
moving RC3-to-RC4 delta. Commit `980d1933` gives mutation proofs an optional
proof-specific command and pins this proof to the RC1-to-v15 delta where
`runInvalidationGroup` is genuinely new. The production gate keeps its moving
base. Under Node 22, all 60 mutation proofs and all 69 release gates pass. This
release-system correction earns RC5; the RC4 tag is not moved.

`15.0.0-rc.5` is **IMMUTABLE / NOT PUBLISHED** at `73bbce0f`. Tagged CI run
`33579690478` passed the complete release workflow, including 69/69 release
gates and 60/60 mutation proofs. The subsequent canonical publish dispatch
`33580357302` was skipped before executing any step because `publish.yml`
guarded `JBorgia/signaltree` instead of the repository's actual
`JBorgia/signal-tree` name. Commit `f8a15e75` corrects and gates that repository
guard; its mutation proof recreates the exact skipped-job typo. Under Node 22,
all 60 mutation proofs and all 69 release gates pass. This deterministic
registry-path correction earns RC6; the RC5 tag is not moved.

`15.0.0-rc.6` is **PUBLISHED / SUPERSEDED** at `e720d509`. Tagged CI run
`33581113391` passed every release and mutation gate and created the GitHub
Release. A non-publishing dispatch canary proved `publish.yml` now admits the
canonical repository and rejects an invalid tag before checkout. Live publish
run `33583551981` then passed every safeguard through exact candidate creation
but npm rejected the first `@signal-tree/kernel` PUT until authenticated local
publication was authorized. The canonical publisher then published kernel,
Angular, and the new React package from the exact RC6 candidate. Kernel and
Angular registry SHA-512 integrities equal the candidate; React's package index
and public tarball exist, and the downloaded tarball is byte-identical while its
public metadata endpoint propagates.

The post-publish clean consumer produced a deterministic release falsifier:
Angular and React declarations retained extensionless relative imports, so
`skipLibCheck: false` consumers using `node16` or `nodenext` failed. The former
consumer gate packed only kernel and therefore could not see framework
declaration defects. Commit `c7f7c9d1` emits `.js` specifiers from Angular and
React source entry points, expands strict packed-consumer verification to all
three exact tarballs under both `bundler` and `node16`, and changes the gate
mutation to recreate the Angular carrier-import failure. Framework tests,
three-package dry-run publication, 60/60 mutation proofs, and 69/69 release
gates pass under Node 22. This declaration correction earns RC7; RC6 remains
immutable and published.

`15.0.0-rc.7` is **PUBLISHED / REGISTRY VERIFIED** at `e3fc10fb`. Tagged CI run
`33587339921` completed successfully with 69/69 release gates, 60/60 mutation
proofs, and no failed job step. The canonical publisher published kernel,
Angular, and React in release-plan order from the exact validated candidate.
For all three packages, npm `dist.integrity` equals the candidate SHA-512 and
the `rc` dist-tag points to `15.0.0-rc.7`. A clean external project installed
all three packages by registry version, compiled their public APIs under
`moduleResolution: node16` with `skipLibCheck: false`, imported every public
entry point, and exercised a kernel scalar write successfully. The temporary
npm configuration was removed. The live registry path and strict framework
declaration correction are closed; no technical GA blocker remains.

`DECLARATION-IDENTITY-0` is **CLOSED LOCALLY / REQUIRES RC9 REGISTRY AND
CONSUMER CONFIRMATION** at `9b955ffe`. A real V3 Scaletrax migration exposed a
second deterministic declaration defect in the already-published RC7 artifacts:
Rollup emitted `kernel/dist/index.d.ts` and `kernel/dist/adapter.d.ts` as
independent declaration bundles, each declaring `EntityMapMarker`'s private
`unique symbol`. `entityMap()` came from the root declaration while Angular's
carrier-bound factory consumed `TreeNodeOf` from the adapter declaration, so
the conditional could not recognize the marker and a strict consumer lost
`.all()` / `.setAll()` and entity-loader typing. Runtime semantics, public API
intent, and the source type algebra are unchanged. The kernel Rollup output
transform now parses `adapter.d.ts`, fails closed unless it finds exactly one
local marker brand and interface, removes only those duplicate declarations,
and imports the canonical marker from `./index.js`. The packed consumer gate
constructs `@signal-tree/angular`'s `signalTree` with `entityMap()` and proves
the native `.all` signal and `.setAll()` under both `bundler` and `node16`.
Local validation: kernel 2,154 passed; Angular 90 passed; workspace typecheck;
kernel lint; production package builds; artifact and hygiene checks; and packed
consumer typecheck under both resolutions. RC8 (`66a7484d`, signed tag
`v15.0.0-rc.8`) is immutable but unpublished: tagged CI passed its full 69-gate
set, then correctly failed its mutation proof because the declaration-docs
self-test still searched for the superseded `kernel: 248` baseline. The RC9
candidate updates that anchor to the canonical `243 -> 244` mutation. RC9
(`51b9837f`, signed tag `v15.0.0-rc.9`) is immutable but unpublished: its tagged
verification passed the full 69-gate set, while the independently dispatched
canonical publisher timed out this full-size logical-work control at Vitest's
default five seconds. The control remains logically green under CI settings and
now receives the same 20-second budget as the neighboring large-harness audits
at `be652320`. RC10 (`f12628c5`, signed tag `v15.0.0-rc.10`) is immutable but
unpublished: both its tag verification and publisher matrix passed, but npm
rejected the kernel PUT because per-package trusted-publishing setup is absent.
The canonical publisher now accepts GitHub's managed `NPM_TOKEN` fallback and a
mutation proof fails if that mapping is removed (`c2cdb26a`). This release-system
correction earns RC11. RC11 publication must confirm npm integrity equals the
candidate and V3 must compile Scaletrax against the exact registry artifacts
before this defect is fully closed.

`15.0.0-rc.11` is **IMMUTABLE / PARTIALLY PUBLISHED** at `e2c597789`. Tagged
verification passed the full release matrix. The canonical publisher proved the
managed-token fallback by publishing `@signal-tree/kernel@15.0.0-rc.11` with
provenance, then npm rejected Angular before its registry write because the
packed framework manifest omitted `repository.url`. Angular and React manifests
now carry the canonical repository URL and their package directories; the built
manifest gate rejects any missing or incompatible provenance identity. RC11
cannot be reused because kernel is already published. This provenance repair
earns RC12, whose tagged publisher must publish all three exact candidate
tarballs and whose registry integrities and V3 Scaletrax consumer proof close
`DECLARATION-IDENTITY-0`.

`ENTITY-PHYSICAL-DENSITY-0` is **CLOSED AS AN ARCHITECTURE-SELECTION
INVESTIGATION** at `14302192`. E0-E5 and the subject-record, stable-slot,
segmented, split-pool, checked-handle, and active-node-index rows have measured
dispositions. The incumbent representation remains because no tested candidate
improved density while preserving authority, independent lifetimes, hot-path
latency, churn, and GC laws. This is not a theoretical-minimum claim.

Future physical-density work is optional post-RC refinement. It must start from
a specific measured allocation and beat the RC baseline without changing
semantics or regressing point-operation latency, lifecycle correctness, churn,
or GC behavior. It neither reopens `GATE A` nor blocks `GATE F` or GA absent a
new deterministic release falsifier.

`GATE B` is **SATISFIED AGAIN** as of `cf008545` / `b957f604`. Deterministic
tarball/API evidence at `7c182798` / `ca8f6006` reopened the gate because
symbols with settled negative or unresolved dispositions were still present in
the publishable public surface. The blocked root symbols and unplaced subpaths
were removed, reviewer-found internal spec imports were repaired, and
`node tools/check-rc-public-dispositions.mjs` now passes.

`GATE A` is **SATISFIED**. The kernel is FROZEN as of `4f7a2169`.

`OWNER-INVALIDATION-0` is **CLOSED GREEN** at `cb2a276f`, under an explicitly
authorized frozen-kernel exception. `@signal-tree/kernel/adapter` exposes one
framework-neutral `observeOwnerInvalidation(owner, callback)` fact: the
callback carries no value, path, metadata, selector, framework concept, or
event cardinality. Multiple coherent public changes may coalesce into one later
request to reread canonical truth. Demand activation, membership omission and
equal-value reactivation, scalar/nested/entity/selection/derived/inspection/
restoration/batching truth, deferred transaction settlement, owner isolation,
independent idempotent cleanup, dormancy, and terminal destruction are pinned
by 21 direct law controls. The React 19 greenfield reference passes 14 behavior
controls using only the adapter primitive. Kernel 2,034 passed with three
expected failures; Angular 24 passed; typecheck, lint, preserve-modules builds,
API/spec baselines, bounded no-subscriber production-substrate comparison, and
the release ladder are green at 66/66 with zero known-red.

`CONSTRUCTION-BOUND-REALIZATION-0` is **CLOSED GREEN** at `23c6de5a`. Kernel and framework
factories bind immutable realization bundles at construction; neutral and
Angular trees coexist in N→A→N→A order with later lazy allocations; mutable
process-global realization installers are deleted. The kernel test target is
framework-free, and `ScalarLeafRealization.runInvalidationGroup()` supplies the
narrow mechanism required to prevent one atomic SignalTree operation from
exposing partial state through synchronous realizations. Kernel, Angular,
typecheck, lint, builds, package coexistence, independent review, and the
release ladder pass at 66/66 with zero known-red.

`SNAPSHOT-IDENTITY-CONTRACT-0` is **SIC-B / CLOSED GREEN** at `d8ad11da`. As an explicit
product-surface decision, the canonical whole-tree NaturalValue reader returns
the same root while committed truth is unchanged. SIC assigns no public callable
syntax to canonical materialization. Correctness does not depend on snapshot
identity, identity is never causal authority, and arbitrary unchanged descendants
carry no public `===` promise after a change. KSA's current incremental subtree
reuse remains an internal measured optimization.

`GREENFIELD-ROOT-ACCESSOR-SHAPE-0` is **CLOSED GREEN** at `1495f713`. The tree is a non-callable controller and `tree.$` is the callable
root state accessor with the same read / whole-value replace / updater grammar
as ordinary state nodes. It has no `.set()` or `.update()` methods. Framework adapters pair
`observeOwnerInvalidation(owner, callback)` with
`readCanonicalSnapshot(owner)`; neither operation revives an obsolete callable
controller shape. `CANONICAL-SNAPSHOT-HANDOFF-0` is closed at `3b572fe7`.
The root-controller blocker on `@signal-tree/react` is discharged; React work
may proceed when selected by the remaining Phase 5.5 sequence.

`SELECTOR-SNAPSHOT-COST-0` is **CLOSED / PROPERTY FROZEN** at `eea160b9`.
Measured cold whole-root materialization after one EntityMap mutation
was about 245 us at 10k rows and 2.2 ms at 50k, while an entity update plus
direct `byId()` reread was about 1.2-1.6 us. Therefore owner invalidation is only
the wake-up fact for React selectors: selector `getSnapshot` must reread the
selected location/value directly and must not be forced through whole-root
NaturalValue materialization. Whole-root consumers may still read the whole
root.

> **SHARED OWNER INVALIDATION DOES NOT IMPLY SHARED SNAPSHOT SCOPE.**

Semantic equality may suppress a rerender after the selected reread. This
freezes no hook name, selector API spelling, equality option spelling, cache API,
or new kernel port. The React public API remains open. The React reference
carries unrelated-owner-wake/no-rerender and selected-mutation/rerender controls
at `eea160b9`.

Measurement provenance: `node --expose-gc
scripts/benchmarks/data-model-profile.mjs entitymap` against the `1495f713`
root-retirement build. The generator reports both `tree.$()` after one
collection mutation and `updateOne + byId() read only` at 10k/50k rows in the
same process and fixture family; quote the shape and range, not a multiplier.
Validation: React reference 16/16, production reference build, both TypeScript
passes, numeric/link checks, independent review, and the full release ladder at
66/66 with zero known-red.

`REACT-API-DERIVATION-0` is **CLOSED GREEN** at `9b84c14e` and `dadf60fb`.
The derived package behavior is owner-bound subscription and cleanup,
synchronous selected canonical reads, Object.is-stable React snapshots while
selected truth is unchanged, explicit whole-root observation, and no mirrored
state authority. The selector input is the supplied owner's typed root accessor:
`(rootAccessor) => selectedValue`. This preserves direct location reads and gives
selector definitions an explicit, reusable, composable, framework-independent
input. A NaturalValue selector is rejected because supplying its argument after a
dirty owner invalidation forces the O(n) whole-root materialization forbidden by
`SELECTOR-SNAPSHOT-COST-0`. A zero-argument closure can still be composed by an
application, but does not survive as the package selector model because it binds
the definition to ambient tree identity and weakens reuse, isolated testing, and
future selector-level memoization. Cross-owner capture is possible under either
function spelling and did not decide the selector-input row. The target-state
product pass then froze one universal observation hook:
`useSignalTree(owner, selector)`, with whole-root expressed as `($) => $()`.
The initial package uses React's `Object.is` contract and exposes no custom
comparator, root alias, React realization, or public helper types. Owner changes
resubscribe, changing selectors are current, and SignalTree remains sole state
authority.

`dadf60fb` adds the publishable `@signal-tree/react` package and migrates the
greenfield reference off its local proof hook. Validation: React package 6/6,
reference 16/16, React 18/19 packed-consumer typecheck + bundle + runtime,
workspace build/test/lint/typecheck, API/barrel/package/manifests gates,
independent review, and **66/66 with zero known-red**. Still separate and open:
SSR/RSC/hydration, React Native validation, cross-component subscription sharing,
and first-party memoized selectors.

`ROOT-READ-COST-0` is **CLOSED A / NO REGRESSION**. The production Rollup build
was measured against a separately built `e243a569` pre-retirement artifact with
`tools/bench-root-read-cost.mjs`: 1,000,000 cached reads per arm, 15 measured
samples after warmup, rotated arm order. Direct canonical materialization was
43.93 ns/call (MAD 0.31), current `tree.$()` was 41.42 ns/call (MAD 0.47), and
historical `tree()` was 42.14 ns/call (MAD 0.32). The initial red exposed two
avoidable position-zero costs: a permanent lazy `$` getter and a descendant
dormancy lookup that root can never satisfy. Removing both restored the original
five-rebuild guard 5/5; the guard remains unchanged.

Configured-derived ownership remains unchanged by root retirement. A writable
carrier returned by `config.derived` remains writable structure under `$` but is
not mirrored into the backing source store and is absent from the NaturalValue
snapshot. Writability is not snapshot authority.

Restoration reentrancy is **SUPPORTED**, but the deleted scenario was not a
valid characterization: direct external `PathNotifier.notify(...)` injection is
internal delivery machinery, and one-microtask completion is not promised. The
replacement carrier starts with a real designated tree write, performs a
reentrant designated tree mutation from the subscriber, drains queued delivery
with `flushSync()`, and proves restoration records the final state.

Final root-retirement validation at `1495f713`: kernel 245 files / 1,983 passed
/ 3 expected failures / 13 skipped / 1 todo; Angular 90 passed / 3 skipped;
demo performance mode 114/114; both TypeScript passes; kernel lint; live README,
documented-import, documented-symbol, link, and numeric-claim checks; independent
adversarial review; and `NX_DAEMON=false NX_ISOLATE_PLUGINS=false npm run gates
-- --release` at **66/66, zero known-red**. A final search found no live public
tree call signature, `tree.bind`, callable enhancer wrapper, `originalTreeCall`,
or `copyTreeProperties`; surviving `tree()` text is confined to explicit negative
type controls, a historical A/B benchmark label, local non-SignalTree prototypes,
and clearly versioned historical migration/archive material.

Full performance audit after retirement used the repository generators, not
`artifacts/*.json`. Root read remained neutral (41.42 ns current `tree.$()` vs
42.14 ns historical `tree()`); unchanged 10k-leaf reads measured 0.250 us;
recursive root updates scaled 0.00281 ms at depth 5 to 0.01043 ms at depth 20;
bare package gzip was 9.50 KB against 9.7 KB and entityMap was 20.08 KB against
21 KB. Update cost stayed approximately flat with collection/state size, while
the known tradeoffs remained visible: a lean immutable entity store led the raw 10k collection workload
(1.35 ms vs SignalTree 19.51 ms), a cold whole-collection projection remained
O(collection), and featured retained heap reached 92.11 MB at 100k rows. Every
memory scenario was collectable; bounded history plateaued (1.2x growth across
16x rounds vs 13.7x control), retired-subject slope was unmeasurable, and live
reactive identity survived forced GC. No performance result reopens the frozen
root grammar.

`CONSTRUCTION-DENSITY-0` is queued as a non-blocking optimization investigation,
not attributed to root retirement: construction measured about 1,233-1,240
B/scalar leaf and about 150 ms at 100k leaves, versus roughly 523 B for a raw
Angular signal in the same decomposition. It does not block React, root
retirement, or the current release phase unless a later product budget says so.

`ENTITY-PHYSICAL-DENSITY-0 / E0` is **CLOSED EVIDENCE / BYTE ATTRIBUTION
FROZEN** at `82b487da`. `node --expose-gc
tools/bench-entity-physical-density.mjs` measures
three isolated, quiesced samples per arm at 0/1k/10k/100k and fails unless every
arm is collectable and synthetic/exclusive accounting closes within 90-110% of
production. The measured physical-store marginal slope is 394 B/entity:
72 payload, 36 subject-value index, 36 key-to-subject, 84 lifetime Map+record,
36 revision, 56 ordering node, 36 active-by-key, and 36 active-by-subject.
Exact-shape synthetic and exclusive accounting each close at 100% against both
`StructuralStore` (286 B/entity) and the combined physical stores. The familiar
10k point remains 4.35 MB / about 456 B/entity because point retention includes
capacity/fixed effects; at 100k production is 37.82 MB and the fitted slope is
393.9 B/entity. Do not restate the 10k point as the marginal physical floor.
Structural bookkeeping is 286 B/entity, about 72.5% of that marginal floor.

Validation disposition: focused E0 harness, attribution closure, lint budget,
numeric claims, links, diff integrity, and independent review are GREEN. The
post-commit full `npm run validate` is INCOMPLETE: its bundle-analysis phase
built only `shared`, then gate 10b found the expected kernel artifact absent.
The subsequent explicit `pnpm nx build kernel` plus
`node tools/check-bundle-budget.mjs` completed with exit 0. Do not record this
slice as a 66/66 full-pipeline pass; the failure is a pipeline prerequisite
issue, not an E0 product or bundle-budget failure.

Independent review found no E0 blocker. E1 is authorized only as an external
record-consolidation prototype under
[entity-physical-density.md](docs/architecture/entity-physical-density.md):
unify allocation, not authority; preserve every frozen entity law and O(1) point
operation; no SubjectId reuse, weak canonical truth, public API, or production
representation change. Revision and value-address Maps establish an immediate
72 B/entity consolidation target; the 129 B/live-subject ordering/index group
must prove whether two-hop record lookup preserves each index's O(1) job before
any index can be rejected.

`ENTITY-PHYSICAL-DENSITY-0 / E1` is **CLOSED EXTERNAL PROTOTYPE /
PRODUCTION NOT AUTHORIZED** at `1bc53ae8`. Its production control reproduces E0
at 394.0 B/entity. One mutable SubjectId-indexed record with both active indexes
retained measures 345.3 B/entity, a 48.7 B saving after record-layout cost.
Replacing either active index independently with O(1) record lookup measures
309.0 B/entity; replacing both measures 272.7 B/entity, a total 121.4 B saving.
Synthetic controls preserve linked-node identity, in-place value/revision
updates, retirement, held identity, fresh same-key occupation, reactivation,
missing lookup behavior, and forward/reverse ordering integrity. Three-sample
0/1k/10k/100k measurement, lint budget, and diff integrity are green.
Adversarial confirmation found the representation admissible but not necessary:
split stores remain coherent, and no production conclusion follows before
restoration placement, reorder/move/transfer, causal/external/owner integration,
facade GC, and hot-path latency survive direct controls.

`ENTITY-PHYSICAL-DENSITY-0 / E2` is **CLOSED EXTERNAL PROTOTYPE /
PRODUCTION NOT AUTHORIZED** at `e07ac9d3`. E1's 272.7 B/entity active control is
reproduced. Making active lifetime implicit lowers the common active slope to
256.6 B/entity, saving 16.1 B/entity; ordinary active mutation adds 0.0. A
strong exceptional lifetime Map+record costs 84.3 B/retired subject and is
absent from common active records. Reactivation's 38.5 B/entity difference from
pristine construction is almost entirely key-index Map churn (36.3 B/entity),
not retained exceptional state; the residual beyond that control is 2.2.
Stable/held identity, fresh same-key occupation, occupied-key restore rejection,
exact same-subject restoration, rekey and order integrity, constant-hop Map
paths, and collectability are controlled. The 294.3 B/claimed-subject arm is one
synthetic production-shaped claim graph, not a semantic minimum; E5 owns actual
optional-capability density. Independent review is clean. Production promotion
still requires an enforced active `restoreAllowed` invariant, intermediate
tombstone and mixed-population evidence, full restoration/causal integration,
and latency controls.

`ENTITY-PHYSICAL-DENSITY-0 / E3` is **CLOSED NEGATIVE EVIDENCE /
SEGMENTED CANDIDATES REJECTED** at `86b6aee7`. Against E2's complete compact
Map layout at 256.6 B/subject, chunked and sparse object segments measure
228.4 B dense and packed stable-handle segments measure 229.3 B: only a
27.4-28.3 B dense saving. At dispersed 10% occupancy after allocation and
retirement, Map measures 357.1 B/retained subject, chunked 364.9, sparse 365.6,
and packed 517.2. Sparse/packed variants reclaim empty clustered segments and
avoid high-water retention, but dispersed lookup/update and capacity-based
iteration regress; dense outer chunks retain a 72.6 B/subject high-water
penalty. The Map's direct-versus-retired sparse pair independently reproduces
the 36.3 B churn cost. All arms collect; SubjectIds remain safe-integer,
monotonic, non-reused, and directly addressed without a slot Map; stable record
and ordering-node identity survive. Independent review is clean. No variant
meets E3's combined material-density, bounded-sparsity, and latency condition,
so E2's compact SubjectId Map remains the best external candidate and no
production migration is authorized.

`ENTITY-REALIZATION-RETENTION-0 / E4` is **CLOSED ATTRIBUTION EVIDENCE /
PRODUCTION CHANGE NOT AUTHORIZED** at `6c8f9e44`. Production public EntityMap
slopes are 403.2 B/entity untouched, 759.5 after `byId()` and facade release,
1,115.9 after an actual node/field read and release, 2,981.0 while nodes are
held, and 3,337.5 while held fields are read. At 10k, untouched is 4.53 MB and
released `byId()` is 8.08 MB. Exhaustive facade WeakRefs prove released facades
collect while the tree remains live; inventory and matched arms attribute the
remaining slopes to a 356.3 B entity cell and a separately triggered 356.4 B
activation cell. Released facade/field graphs add approximately 0 B beyond
those cells; the held facade graph costs 2,221.6 B/held subject. Reacquisition
adds no positive slope and reads current truth. Every fit passes $R^2 >= 0.995$,
each returned owner collects, lint is green, and independent review is clean.
The forced-GC durability gate passes live invalidation, same-subject undo,
fresh-key isolation, and multiple-consumer laws. Naive weak cells remain
rejected; E4 attributes current ownership but authorizes no production retention
change. E5 restoration/history capability density remains a separate row.

`ENTITY-PHYSICAL-DENSITY-0 / E5` is **RED EVIDENCE / DIRECT FALSIFIERS
FOUND** at `bc6ab836`. Raw and causal-runtime-only both measure 403.2 B/live
subject, proving causal availability adds 0.0 subject slope. Restoration
configured with zero designated writes measures 840.2 B/live subject: a
437.0 B/live-subject failure, about 42 MB at 100k, with INIT history 1, claims 0,
and 100,000 subject descriptors plus 100,000 structural-effect-by-subject
entries. One thousand undesignated writes add -9.1 B/subject noise and no entry,
claim, or descriptor accumulation. Requested `maxHistorySize: 0` emits exact
ST2032 and falls back to 50; after 100 designated writes it retains 50 entries
and 50 claims, so zero completed-history retention is not expressible. Buffer
lengths 2/20/101 retain exact bounded cardinalities. Matched scalar histories
stay near the idle slope; entity turns add a composite collection-pointer,
effect, and claim cost of about 0.79-0.81 MB per added entry at 100k. Every fit,
cardinality, claim/history invariant, and post-destroy owner/registry collection
check passes. E5 is not closed green and authorizes no production change.

`RESTORATION-IDLE-DENSITY-0 / R0` is **CLOSED ATTRIBUTION / DESIGN ROW
OPEN** at `3013b735`. Extracted actual production descriptors plus INIT state
measure 437.2 B/subject against the 437.0 B restoration-over-causal delta,
closing at 100.0%. The graph is one materialized INIT entity snapshot, one
subject address descriptor Map, and one cloned add effect indexed by operation
and SubjectId per live subject. Standalone 80.0 / 116.3 / 304.7 B probes are
non-additive diagnostics; extracted production artifacts are authoritative.
Semantic necessity is unproven because inline effect addresses win and subject
descriptors are fallback machinery. The active design row is lazy acquisition
and release of subject-specific restoration representation under every frozen
undo/redo, structural, transaction, atomicity, and address-fallback law.

`ZERO-HISTORY-RETENTION-0` is **DECISION REQUIRED / NOT IMPLEMENTATION
AUTHORIZED**: current 0 -> 50 behavior is a measured contract falsifier, but the
target must decide INIT retention and buffer/cursor/reset/diagnostic semantics.

`REALIZATION-OWNERSHIP-0` is **QUEUED AFTER E5 FOLLOW-UPS**. Reactive cells may
be reclaimable only through explicit live-facade/cell/subscriber ownership; E4's
forced-GC durability, same-subject undo, fresh-key isolation, shared-consumer,
reacquisition, and repeated-cycle laws remain mandatory. Naive WeakRefs remain
rejected.

`RESTORATION-IDLE-DENSITY-0` and `ZERO-HISTORY-RETENTION-0` are **CLOSED
GREEN** at `ea521d7e`. E5's red baseline remains frozen evidence: configured
unused restoration was 840.2 B/live subject and 80.88 MB at 100k, with 100,000
eager descriptors/effects. Ownership-before-retention now stages turn facts
transiently and commits descriptors only for a non-empty, accepted, positive-
capacity designated turn. Net-zero/deduped turns, ordinary turns, rollback,
reset, destroy, and thrown transactions retain none; confirmed transaction
fallback facts survive only while restoration or transaction claims own them.
Positive-capacity construction primes snapshot invalidation without retaining an
INIT entry.

Post-fix E5: raw, causal-only, and configured-unused each measure 403.2 B/live
subject; configured-unused is 39.10 MB at 100k, recovering about 41.8 MB and
reducing restoration's idle subject slope to 0.0 B. One thousand undesignated
writes retain 0 entries / 0 claims / 0 descriptors. `maxHistorySize: 0` now
retains 0 / 0 / 0 after 100 designated writes; capacity 1 supports exactly one
undo/redo; positive N retains at most N completed designated turns. Capacities
2/20/100 retain exact entry/claim/descriptor cardinalities 2/20/100. R0 reports
0.0 B/subject live idle delta and 0.0 B extracted artifacts.

Validation: kernel 246 files / 1,992 passed / 3 expected failures / 13 skipped /
1 todo; both TypeScript passes; kernel lint/build; authoritative E5 and R0
memory gates; net-zero, rollback, reset-before-confirm, destroy-before-confirm,
throw-abort, transaction persistence, structural restoration, lazy claim
registry, and exact cleanup controls; independent review clean. No full release
66/66 claim is made because the previously recorded gate-10b pipeline
prerequisite issue remains separate. The retained-history scaling row below is
the historical preregistration that followed this checkpoint; its later
declarative-restoration and lazy-materialization closure is authoritative.
`REALIZATION-OWNERSHIP-0` is optional post-RC refinement, not a density or GA
gate.

`RESTORATION-ACTIVE-DENSITY-0` was **PRE-REGISTERED HERE / CLOSED BELOW**.
`ea521d7e` closes the _idle_ restoration slope only. E5's own matrix still shows _retained_
history scaling with collection width rather than with reversible work: at 100k
live subjects configured-unused is 39.10 MB, capacity 2 is 40.02 MB, capacity 20
is 53.81 MB, and capacity 100 is 114.91 MB, while 100 retained _scalar_ turns
over the same subtree stay at 40.14 MB. The entity-turn increment is about
771 KB/retained turn at capacity 20 and about 795 KB at capacity 100, for
workloads where each designated turn touches a tiny fraction of the 100,000-
subject collection: a suspected O(collection-size x retained-turns)
characteristic. Bounded cardinalities (2/2/2, 20/20/20, 100/100/100) are not the
same claim as bounded bytes, so "positive capacities retain only participating
subjects" is not yet demonstrated for entity turns.

Frozen target law (pre-experiment): retained restoration cost scales primarily
with retained causal work and the subjects and positions required to reverse
that work, not with unrelated live subjects. For a one-entity value change the
durable representation conceptually needs only TurnId, SubjectId, the prior
affected truth, causal metadata, and claim/ownership; a structural operation
adds only the placement or neighbour facts its reversal requires. A full-width
collection image must prove semantic necessity, not survive for reconstruction
convenience.

Pre-registered falsifier: at collection sizes 1k, 10k, and 100k, independently,
retain exactly one designated turn of each kind (one-field scalar change on one
existing entity, whole-entity replacement, add, remove, rekey, and
reorder/move) and compare configured restoration with zero history against
configured restoration plus that one retained turn, inventorying the retained
owners. The primary question is whether the incremental retained cost of one
one-subject turn grows materially with unrelated collection size; an
approximately 8 KB / 80 KB / 800 KB progression is a decisive O(N) result.
Attribution measures the actual retained owner before any optimization is
designed; the collection-width snapshot or projection is the suspect, not the
premise. No production change is authorized until the owner is attributed and
each redesign candidate passes the frozen undo/redo, structural, transaction,
atomicity, and address-fallback laws.

Automation and generated docs must assert the repaired result (403.2 B/live
subject, 0.0 B idle slope, and the `maxHistorySize` turn-capacity contract of
undefined -> 50, 0 -> none, 1 -> one undo/redo, N -> at most N completed
designated turns) as current expectations. E5's and R0's red tables, the
437.0 B slope, and the 0 -> 50 fallback are retained as historical defect
evidence only and must not be consumed by live gates.

`RESTORATION-ACTIVE-DENSITY-0 / A0` is **CLOSED OWNER ATTRIBUTION /
PRODUCTION REDESIGN NOT AUTHORIZED** at `93bd4d15`. One retained one-entity turn
over 1k/10k/100k subjects costs 69.6 / 137.2 / 840.1 KB. The retained entry has
one effect, one claim, and one position, but `state.rows.all` has collection
cardinality and is identical to the live canonical snapshot array. A matched
zero-history `tree.$()` materialization accounts for 34.1 / 107.0 / 820.2 KB;
at 100k only about 20 KB remains turn-specific. Whole replacement, add, remove,
and prepend reproduce 830-840 KB at 100k with 800-813 KB explained by canonical
materialization and exact one-subject claim cardinality.

Rekey is a separate direct falsifier: one effect/position retains 1k/10k/100k
claimed subjects and costs 275.6 KB / 2.48 MB / 22.62 MB. `setAll` leaves
collection-wide `lastSubjectIds`; `changeId` does not narrow it before mutation
capture. `RESTORATION-REKEY-CLAIM-WIDTH-0` and `RESTORATION-TURN-STATE-0` are
the next active subrows. The former owns claim precision at the producer; the
latter derives the minimum retained reversal representation and tests whether
effect-only turns are sufficient without forcing full-width canonical
materialization. `REALIZATION-OWNERSHIP-0` remains queued behind active
restoration density.

Live automation is current at `839d4133`: the shipped-API capacity gate asserts
omitted -> 50, 0 -> none, 1 -> one, and positive N -> at most N completed
designated turns. Historical E5/R0 red tables remain evidence only.

`RESTORATION-ACTIVE-DENSITY-0 / A0` attribution is **INDEPENDENTLY REPLICATED /
FROZEN**. A blind agent given only the raw 1k/10k/100k symptom magnitudes, and
walled off from the A0 harness and write-ups, reached the same two owners with
its own probes. One-field turn: the owner is `CanonicalTurn.state`, a full
materialized root snapshot built by `snapshotState(tree.$)` at settlement, whose
O(N) part is the collection projection array `state.<collection>.all`. A single
retained turn shares the live snapshot array, but 20 retained turns pin 20
distinct `.all` arrays (20/20 by `===`); retained cost is therefore
`entries x N` pointer slots at about 8 B each across four capacities and three
sizes, and the row objects stay structurally shared (1,019 distinct for 20
turns over 1,000 rows). An exhaustive own-property, symbol, descriptor, and
deep-subgraph scan of a retained entry finds zero function or accessor fields:
closure capture is falsified as the dominant O(N) retained-turn mechanism -- the
retained `CanonicalTurn` graph carries no function or accessor edges and the
~8 B/slot array term accounts for essentially the whole multiplicative slope,
though lexical environments elsewhere cannot be enumerated by reflection. Rekey:
`entry.restorationSubjectIds` is N-wide and feeds the `SubjectRestorationClaims`
`bySubject` / `byOwner` reverse index (one Map entry plus a one-element Set per
subject, about 241 B/subject, ~98% of the retained rekey cost). Cause confirmed
causally: `planRekey.commit()` and `planPreparedRekey.commit()` never call
`rememberSubjectIds()`, so the `lastSubjectIds` latch (`entity-signal.ts:462`)
stays at the prior wide write; `wrapMutator` reads it at
`intercept-leaf-signals.ts:208` and the precedence at `restoration.ts:660`
prefers that N-wide set over the correct one-element `effectSubjectIds`.
Interposing any narrow undesignated write before the rekey collapses claims
from N to 2 and retained bytes by 98% with the effect record byte-identical.

Disposition: `RESTORATION-REKEY-CLAIM-WIDTH-0` production fix is **AUTHORIZED AT
THE PRODUCER**. The ordinary and prepared/transactional rekey commit paths must
emit exactly the current rekeyed subject as last-write participation metadata;
the specific mechanism (the `lastSubjectIds` latch or a better one) is the
implementer's choice. The restoration subject/effect precedence at
`restoration.ts:660`, the claim registry, restoration-side filtering, and public
API are **not to be modified** -- the consumer is correctly trusting the
participation fact it was given, and its conservative breadth serves whole-turn
capture beyond rekey. Target: one rekey retains exactly one participating
SubjectId (exactly 1, not merely small; the residual 2 in the discriminator
experiment was the interposed narrow write plus the rekeyed subject, not the
intended end state). Two producer-level controls guard the metadata contract at
its owner: after `setAll(N) -> changeId(one)` and after an arbitrary prior
mutator `-> changeId(one)`, producer participation equals `[rekeyed SubjectId]`,
for both rekey paths. The restoration controls stand: held ref stays the same
logical subject; old key stops resolving; fresh old-key occupant gets a distinct
SubjectId; undo restores the old key; redo restores the new key;
ordering/position exact; transactional rekey atomic; rollback retains zero
claim; eviction releases the claim; one rekey at 1k/10k/100k retains exactly one
claim. `RESTORATION-TURN-STATE-0` then derives the minimum retained reversal
representation and tests whether effect-only turns satisfy every frozen
restoration operation including `jumpTo()` and historical-state exposure;
compact effects are the leading candidate, not the conclusion. Claim-registry
representation is not a detour -- once the producer says 1, the ~241 B/subject
registry cost is no longer pathological. `REALIZATION-OWNERSHIP-0` stays queued.

`RESTORATION-REKEY-CLAIM-WIDTH-0` is **CLOSED GREEN** at `1bd52ed0`
(primary N-wide defect) with residuals closed at `0e47de5c` (false
prepared-path coverage claim corrected in docs; live no-op
stale-participation defect fixed at both `from === to` branches).
`planRekey.commit()` and `planPreparedRekey.commit()` now set
`lastSubjectIds = [subjectId]`, the sole
production change; `restoration.ts:660`, the claim registry, restoration-side
filtering, and public API are untouched. `bench-restoration-active-density.mjs
--operation rekey` at 100k now reports `effects=1, claimedSubjects=1,
positions=1` and a one-turn increment of 70.6 / 138.2 / 841.7 KB at 1k/10k/100k,
matching an ordinary field turn -- the N-wide `restorationSubjectIds` and the
O(collection) `bySubject` / `byOwner` claim graph are eliminated, recovering
about 22.6 MB at 100k. The residual is the shared
`CanonicalTurn.state.<collection>.all` materialization, which belongs to
`RESTORATION-TURN-STATE-0`. `rekey-claim-width-0.spec.ts` pins the fix at the
producer (`__subjectIds` after `changeId`, ordinary and transactional paths)
and at the restoration outcome (one retained claim independent of collection
size, held identity across the rekey, undo/redo key restoration, order
preservation, rolled-back-transaction atomicity, eviction release, fresh
same-key occupant distinctness, no-op and rejected rekey latch behavior). The
redo path was traced and the first account of it was WRONG: a pure rekey
reversal replays through `__planRekey.commit()`, not the prepared planner --
instrumenting both across pure rekey undo/redo, composed turns, transactional
confirm/rollback, and multi-turn `jumpTo`, the prepared planner fired ZERO
times, because the prepared context only holds a subject an earlier
restore/add effect in the same batch introduced and capture-time coalescing
merges a same-subject rekey into the structural effect that preceded it.
`planPreparedRekey.commit()` is patched for sibling consistency and is
reachable only through a hand-composed realization batch; that route has no
direct spec yet. After redo settles, the retained turn's
`restorationSubjectIds` and the claim registry stay at one at N of
20/30/600/1,000. An interim draft assertion reading `80` after redo was a
broken test (it redid an unrelated bulk `setAll`, whose last-write latch
legitimately spans the collection), now replaced by one that redoes the rekey
turn itself. The no-op branch was a residual hazard found by review:
`wrapMutator` fires on every mutator call with no `next !== prev` guard, so a
no-op `changeId(k, k)` re-published the previous bulk write's participation
set into the capture bucket of a designated write sharing the tick (measured:
50 claims for a one-subject turn); both no-op branches now narrow the latch to
the addressed subject, and a rejected rekey throws before any frame commits.
Kernel 247 files / 2,002 passed / 3 expected failures / 13 skipped / 1 todo;
both TypeScript passes; kernel lint/build; the rekey arm of the A0 harness now
asserts the repaired one-claim cardinality.
`RESTORATION-TURN-STATE-0` is the active row; `REALIZATION-OWNERSHIP-0` stays
queued behind it.

`RESTORATION-TURN-STATE-0` is **PRE-REGISTERED / ACTIVE NEXT**. Known defect:
every retained restoration turn forces and pins
`CanonicalTurn.state = snapshotState(tree.$)` at settlement (`restoration.ts:618`,
stored `:650`); for an EntityMap that is a distinct collection-width
`state.<collection>.all` array per retained turn (A0: 20 turns pin 20 distinct
arrays; ~810 KB of an ~842 KB one-turn increment at 100k).
`restoreState(entry.state)` is called by undo (`:1319`), redo (`:1383`), and
`jumpTo` (`:1449`); the net-zero/dedup discriminator compares
`last.state === entry.state` / `deepEqual` (`:692`); and `state: T` is a
non-optional field of the public `RestorationHistoryEntry<T>` returned by the
public `getRestorationHistory()`.

Frozen law (this row): a retained restoration turn owns only the information
required to reverse and reapply that causal turn. Historical-state
materialization is a distinct semantic job and must not force every retained
turn to own a full-tree snapshot unless a direct semantic falsifier proves that
coupling necessary. Not frozen: effect-only representation, checkpoint cadence,
checkpoint plus replay, lazy historical materialization, and any public
history-state redesign -- each a candidate, compact effect/delta turns leading.

First action: a source inventory (not a benchmark) of every read, copy,
comparison, serialization, and public-type exposure of
`RestorationHistoryEntry.state`, tests and docs included, each classified as
semantic requirement, public contract, diagnostic convenience, or incumbent
implementation mechanism. It must resolve whether `.state` on
`getRestorationHistory()` is (A) a frozen promise that historical NaturalValue
is eagerly stored and always present, (B) a promise the API can provide it, or
(C) inherited implementation shape never intentionally frozen.

Second action: a blind semantic falsifier. The adversary independently
determines whether full `CanonicalTurn.state` snapshots are semantically
required, enumerates every production and public consumer of historical state,
derives the minimum information each frozen operation needs, and attempts to
construct a case where a turn-local delta/effect representation is insufficient
-- with attention to `jumpTo` (forward, backward, across an evicted-window
boundary), redo truncation and branching, transaction confirm/rollback/
atomicity, structural identity, address fallback, held references, and later
authoritative realization truth overwriting authored truth. It proposes no fix
until it can name the semantic information each operation requires.

Third action: choose the target-state representation from the combined evidence.

Mandatory proof set for any candidate: ordinary reversal (scalar, nested field,
whole-entity replacement, add, remove, rekey, reorder/prepend); identity and
address (held subject across remove/undo, fresh same-key occupant isolation,
address fallback, position restoration); causal composition (multiple writes to
one subject, multiple fields of one entity, mixed scalar plus entity turn,
net-zero composed turn, transaction confirm, transaction rollback, transaction
atomicity); temporal authority (undo, redo, redo truncation/branching, jumpTo
backward, jumpTo forward, jump across an evicted-window boundary, later
external/realization truth after authored work); lifecycle (eviction, reset,
destroy, descriptor/claim release). The later-realization-truth case is a killer
falsifier: a naive before/after delta must not restore stale authored truth over
later authoritative truth. EFFECT COALESCING is a mandatory falsifier leg: the
`0e47de5c` sweep proved same-subject structural effects coalesce at capture
time (a `changeId` followed by a `removeOne` of the same subject retains only
the remove effect), so the adversary must inspect whether the composed effect
graph retains ALL semantic information needed to reconstruct every supported
transition, or whether some is supplied only by `CanonicalTurn.state` —
"effects are compact" is not sufficient; the question is whether they are
COMPLETE. No representation or public-surface change is
authorized until the inventory and the falsifier are both in and a candidate has
passed the mandatory proof set. `REALIZATION-OWNERSHIP-0` stays queued behind it.

`PREPARED-REKEY-REACHABILITY` is **QUEUED (architecture cleanup, not blocking)**.
The `0e47de5c` public-route sweep measured zero calls to
`__planPreparedRekey` across pure rekey undo/redo, composed turns,
transactional confirm/rollback, and multi-turn `jumpTo`: the prepared
context only holds a subject an earlier restore/add effect in the same
batch introduced, and capture-time coalescing merges a same-subject rekey
into the structural effect that preceded it. Prove whether
`__planPreparedRekey` has a legitimate production semantic caller; if not,
delete it rather than preserving an unexercised intermediate mechanism. Do
not let this distract from `RESTORATION-TURN-STATE-0`.

`RESTORATION-REPLAY-PLANNER-0` is **CLOSED ARCHITECTURE / IMPLEMENTATION NOT
AUTHORIZED**. The incumbent restoration planner confuses causal transition
semantics with mutation execution sequence: it validates structural effects
against the pre-transition world, then replaces transition order with fixed
mutation-category plan and commit orders, while restore placement greedily
resolves anchors against whichever subjects happen to be live at that moment.
Minimized add/remove composition, dependent restore placement, chained rekeys,
vacated-key reuse, and key permutation cases reproduce the resulting refusal or
wrong-order behavior through the real realization primitives.

Historical turn order remains required to compose each subject's authored work
into its net transition. After that composition, turn order is not a substitute
for structural dependency or target reasoning. Sequential topological replay is
**REJECTED as the target architecture**: key permutations require observable
temporary keys or detach/attach machinery, and pure reorder has no existence or
key edge to sort. The greenfield target is one declarative transition:

```text
retained causal work, composed in causal order
    -> per affected collection owner:
         SubjectId -> active/inactive
         SubjectId -> target key
         SubjectId -> target value
         compact target order change
       plus affected scalar target values
    -> validate every target as a whole
    -> prepare immutable, non-throwing commit instructions for every target
    -> cross one atomic realization boundary only after all preparation succeeds
```

Identity is `(collection owner PositionId, SubjectId)`, never bare SubjectId:
independent collections allocate the same numeric SubjectIds. `ownerPath` and
structural `path` are addresses or diagnostics, not identity authority; a
composed key-swap effect was measured with stale `path: "rows.__tmp"` even
though neither endpoint target contains that key.

Independent transaction and multi-collection falsifiers found no need to replay
the original mutation sequence and no need for a full-tree snapshot. Prior and
next targets are derivable from retained membership, key, value, scalar, and
position facts. Transaction confirmation, speculative state, stale confirmation,
dependency refusal, held references, and collection-local key ownership remain
compatible with the target. Multi-collection atomicity requires global
preparation followed by a non-throwing installation phase; grouped notification
alone is insufficient, and install-then-rollback is rejected.

Current failures are incumbent defects, not target falsifiers. Prepared
realization context and pending rollback currently key some subject facts by
bare SubjectId, so cross-collection numeric collisions can overwrite or coalesce
unrelated effects. Current plan-all/commit-by-category replay also refuses
same-collection remove/add/rekey permutations whose complete target is valid.
No local repair of those mechanisms is authorized before the target planner is
prototyped.

`RESTORATION-POSITION-CAPTURE-0` is **OPEN P0 / ACTIVE NEXT WITHIN
RESTORATION-TURN-STATE-0**. A designated pure `setAll([a,b,c]) ->
setAll([c,b,a])` reorder emits no turn or structural effect; when a field write
causes the same authored operation to be admitted, only the field effect is
retained and undo leaves the reordered collection in place. The gap is effect
capture, not turn admission. Frozen law: a designated authored transition that
changes observable collection order retains positional causal information
sufficient to reverse and reapply that order while preserving SubjectId
identity. The representation must scale with positional work, not unrelated
collection width: compare moved-subject anchors, affected intervals, ordered
moved subsequences, and permutation deltas; a whole ordered SubjectId sequence
is admissible only when the authored positional work is itself O(N).

`STRUCTURAL-ADDRESS-AUTHORITY-0` is **QUEUED / NON-BLOCKING**. Structural
authority comes from collection owner, SubjectId, and transition facts. Decide
later whether structural `path` is deleted, diagnostic-only, or recomputed; do
not design the target planner around repairing a stale path.

`RESTORATION-POSITION-CAPTURE-0 / P0` has a **RED LAW CONTROL / CARRIER
DERIVED / PRODUCTION NOT AUTHORIZED**. The expected-failure control
`position-capture-0.spec.ts` proves the current pure-reorder operation creates no
history entry before testing undo or redo. The compact carrier is a canonical
backbone delta. Given before and after orders expressed as collection-scoped
SubjectIds, choose a deterministic maximum common subsequence as the implicit
stable backbone. Retain only subjects outside that backbone, each with optional
before and after absolute ranks, plus endpoint lengths and the collection owner.
Added subjects have only an after rank; removed subjects only a before rank;
rekeys preserve subject identity and require no position record unless moved.

The carrier reconstructs both exact endpoints by removing endpoint participants,
placing them at their retained ranks, and filling remaining ranks from the
backbone's current order. Exhaustive external derivation found no collision or
directional mismatch across partial permutations through five identities. A
one-item move retains one subject and two ranks; a rotation retains the smaller
moved side; arbitrary reversal or permutation is necessarily dense. This matches
the information bound: sparse k-subject positional work needs O(k log N) bits,
while an arbitrary permutation requires Theta(N log N) bits. Dense retention is
therefore admissible only for dense authored positional work.

Adversarial attack found one mandatory enrichment. The omitted backbone is exact
only at the transition's causal endpoint. An arbitrary later reorder can permute
that backbone, so applying an older sparse delta directly would be ambiguous.
Collection order must therefore be a first-class participant coordinate: later
order work is reversed first by ordinary frontier traversal or causes dependency
refusal. The carrier does not promise selective merge through an unrelated later
reorder. This is consistent with current frontier ownership; production must pin
it directly before promotion.

Canonical normalization uses a maximum common subsequence over unique SubjectIds,
implemented as an O(N log N) longest-increasing-subsequence problem after
coordinate compression. Ties require a stable total SubjectId order and select
the lexicographically smallest maximum subsequence so undo and redo choose the
same backbone. At turn sealing, normalize the first order directly to the final
order; do not concatenate mutation-level moves. The target-planner prototype must
consume this carrier together with membership/key/value targets before the red
law may be repaired.

This closure narrows, rather than completes, `RESTORATION-TURN-STATE-0`:
`CanonicalTurn.state` remains disqualified as causal authority, current compact
effects are complete for the causal work they represent, and represented causal
work is incomplete for pure reorder. Final retained representation and production
implementation remain blocked on compact positional capture and a target-planner
prototype proving transaction and multi-collection atomicity without per-turn
full snapshots. `REALIZATION-OWNERSHIP-0` remains queued.

`RESTORATION-TARGET-PROTOTYPE-0` is **PARTIALLY GREEN / CAPTURE INTEGRATION
OPEN** at `e49f3d19` and `e3dc446f`. `e49f3d19` adds a pure owner-scoped
compiler from reversal facts and compact order deltas to ephemeral collection
and scalar targets. It validates final membership, key uniqueness, values,
order, owner isolation, and collection-order frontier before changing physical
state. Key swaps compile as simultaneous SubjectId-to-key mappings with no
temporary key; fresh same-key occupants remain distinct; key-derived field
writes resolve through SubjectId; local failure leaves every source untouched.
All 4,225 pairs of partial permutations through four identities reconstruct both
endpoints exactly under authoritative frontier tokens.

`e3dc446f` adds the first production-shaped physical binding. `StructuralStore`
and `EntityValueStore` prepare complete replacement state off-store; prepared
values are detached from caller objects; assignment-only installation swaps the
prepared stores; SubjectId-keyed entity and activation cells publish only after
every collection installs. Aggregate preparation refuses before any install if
one owner fails and requires scalar targets to join the same boundary. Direct
reorder and key-swap controls preserve held facades and permit writes through a
held subject at its new key without ever creating a temporary public key.

`RESTORATION-POSITION-CAPTURE-0` is **CLOSED GREEN** at `0ff5d2db` for pure
same-membership reorder. EntityMap publishes exact before/after SubjectId order
and opaque physical order-frontier identity through a private capture channel.
Restoration and transactions coalesce first-before/latest-after per collection,
derive one backbone delta at settlement, and retain the collection owner as a
causal participant. Undo/redo and pending rollback compile order, entity-field,
and scalar facts into one aggregate target, prepare every collection and scalar
before installation, install all physical targets, then publish through grouped
invalidation.

The former expected-failure law is now green for pure reorder, reorder plus an
entity field, confirmed transaction reorder plus root scalar, explicit pending
rollback, thrown-callback rollback, held SubjectId continuity, and undo/redo
symmetry. A later realized reorder owns the physical frontier and causes ST1034
refusal without changing collection state or the history cursor. The frontier
token is owned by `StructuralStore`, captured at both mutation endpoints, read
live by the binding, and restored with the target endpoint; caller-injected
expected tokens are rejected as tautological validation.

Capture is deliberately restricted to same-membership reorder. Add/remove/rekey
continue through their established structural effects until the general target
planner migration closes A/B/C and X1/X2/X3 in production. This avoids creating
a second positional authority for membership changes and preserves existing
structural diagnostics and notification provenance. Existing authored EntityMap
mutations may continue using `EntityMutationFrame`; restoration must not preserve
two structural realization semantics after the remaining migration.

Validation through `e3dc446f`: target compiler 15 focused controls plus 4,225
endpoint pairs; physical binding reorder, key-swap, held-facade, detached-value,
all-owner preparation, install-before-publish, and scalar-boundary controls;
kernel 250 files / 2,025 passed / 4 expected failures / 13 skipped / 1 todo;
both TypeScript passes; kernel lint; independent review of changed files clean.
Validation at `0ff5d2db`: kernel 250 files / 2,031 passed / 3 expected failures /
13 skipped / 1 todo; both TypeScript passes; kernel lint; focused restoration,
transaction, atomicity, external-authority, diagnostic, and link-collection
families; independent adversarial review clean.

`RESTORATION-TURN-STATE-0` remains open. Every admitted reorder turn still owns
`CanonicalTurn.state`, so behavioral position closure does not itself improve
active-history density. Next: migrate the remaining structural target shapes,
then delete eager snapshot retention only after historical-state exposure and
`jumpTo()` are supplied without making snapshots causal authority. E5
remeasurement remains blocked until that deletion.

`RESTORATION-STRUCTURAL-TARGET-0` is **CLOSED GREEN FOR THE DISCOVERED
DEPENDENCY LANGUAGE** at `f2f34753` and `99c18b4f`. `f2f34753` routes
same-owner key handoffs and permutations through the declarative compiler:
X1 rekey plus fresh add into the vacated key, X2 remove plus rekey into the
vacated key, and X3 key permutation all pass undo/redo without temporary replay
keys. Held facades and active selection follow SubjectId, replay notifications
name only final keys, and both transaction rollback authorities scope subject
identity by collection owner rather than bare numeric SubjectId. Independent
clear/add/remove turns remain on the mature path until their migration is
semantically useful; the routing predicate is key dependency, not effect count.

`99c18b4f` closes multi-turn A/B/C. Turn order controls composition into one net
target; it is not used as target installation order. Cross-turn add/remove
collapses to net existence, dependent multi-add restore reconstructs exact
SubjectId order, and chained rekeys derive the historical mapping. `jumpTo()` no
longer mutates `CanonicalTurn.state`: it reconciles any prior temporal view by
effects, compiles all directed undo/redo work for the requested index into one
aggregate target, prepares every target before installation, and preserves the
confirmed frontier/status contract while exposing the requested temporal view.
A mixed-direction invalid-target control proves neither leg installs when any
leg refuses. Poisoning every retained `state` before case C does not affect the
restored keys or SubjectIds.

Validation: `f2f34753` kernel 251 files / 2,037 passed / 3 expected failures /
13 skipped / 1 todo; `99c18b4f` kernel 251 files / 2,041 passed with the same
expected-failure/skip/todo counts; both TypeScript passes, kernel lint, focused
transaction/frontier/diagnostic/identity suites, and independent adversarial
reviews are green.

`RESTORATION-TURN-STATE-0` is now **READY FOR RETAINED-STATE REMOVAL DESIGN**.
Undo, redo, transaction rollback, pure reorder, dependency-heavy structural
transitions, and temporal `jumpTo()` no longer require snapshots as causal
authority. Deletion is still blocked on the public `getRestorationHistory()`
`state` promise and any remaining diagnostic/dedupe readers. Inventory those
consumers, provide historical materialization without retaining one eager
full-tree snapshot per turn, then remove `CanonicalTurn.state` retention and run
the active-density/E5 gates. `REALIZATION-OWNERSHIP-0` remains queued.

`RESTORATION-HISTORICAL-MATERIALIZATION-0` is **CONTRACT RESOLVED / ORACLE
IMPLEMENTATION NEXT**. Public `RestorationHistoryEntry<T>.state: T` promises
exact historical state availability; no public type, test, or documentation
promises eager settlement-time storage. `CanonicalTurn<T>` inheriting the
public entry shape, constructor snapshot warming, snapshot-reference/deep-equal
dedupe, and internal snapshot undo/redo are incumbent mechanisms. Public
undo/redo and `jumpTo()` are effect/target based and case C stays green after
every retained `state` is poisoned.

Exact lazy materialization requires a compact event spine in addition to
admitted causal turns. Undesignated and externally realized writes between two
retained boundaries affect the later public state but not the earlier one; they
cannot be recovered from admitted turns alone. The spine records compact facts
for every committed historical event while at least one retained boundary needs
them, but creates no undo turn, frontier, claim, or `canUndo()` step for
undesignated/external work. Inspection and restoration-origin writes remain
views, not historical truth.

The detached synchronous materializer starts from current canonical truth and
owner-scoped collection targets, walks the compact spine backward, applies
scalar/structural/order facts to detached data only, and emits exact NaturalValue
states at retained boundary ordinals. It never invokes live mutation ports,
notifications, claims, or external-authority refusal. Eviction drops facts older
than the oldest retained boundary; branching drops the discarded branch while
preserving surviving gap events; reset/destroy clear the spine; zero capacity
allocates none. Dense external replacement remains legitimately dense, but its
facts are retained once between boundaries rather than as a full snapshot per
turn.

`RESTORATION-HISTORICAL-MATERIALIZATION-0`, `RESTORATION-TURN-STATE-0`, and
`RESTORATION-ACTIVE-DENSITY-0` are **CLOSED GREEN** through `62760a83` and
`a0bf5716`. The oracle-first sequence completed: exact detached reconstruction
is covered across scalar/entity/structural/transaction/gap/branch/reset/eviction
cases; public and internal history reads use reconstruction; snapshot dedupe and
warming are removed; and confirmed turns retain no strong `state`.

Final A0 at 100k reports a 32.3 KB compact one-turn increment, 813.6 KB matched
canonical materialization, and 847.0 KB caller-requested public-history output,
with effects / claims / positions fixed at 1 / 1 / 1. Final E5 reports 38.56 MB
for 100 retained entity turns over 100k live subjects, down from the historical
114.91 MB defect, with exact 100 / 100 / 100 turn, claim, and descriptor
cardinalities. All lifecycle collectability controls pass. Exact public `state`
remains synchronous and unchanged; its collection-width allocation occurs only
when the caller requests it.

`SUBJECT-RECORD-PROMOTION-0` is **PRODUCT OPTIMIZATION EXPERIMENT / ACTIVE
NEXT**. E0-E5 already attribute the physical, realization, and restoration
owners; do not open another attribution row. Compare the split-store incumbent,
one SubjectId-addressed record, and the normalized rival of one stable identity
slot plus separate authority-owned slot stores. Adversarial confirmation finds
no representation architecturally necessary: constant-hop access and duplicate
SubjectId-index removal do not select one, and shared reachability must be proven
before facts with potentially different lifetimes are colocated.

The record candidate colocates EntityValueStore-owned value with
StructuralStore-owned key, revision, active-node, and exceptional lifecycle
facts without transferring mutation authority. Promotion is staged: value plus
revision; active-by-subject parity and removal; common-active lifecycle
compression; then an independent active-by-key decision. Restoration claims and
realization cells are excluded. Each stage must preserve constant-hop access and
the frozen identity, order, restoration, transaction, external-authority,
held-facade, GC, and churn laws. The preregistered latency bands are <5%
acceptable, 5-10% requiring a material attributed density win, and >10%
rejected absent a separately frozen architecture requirement. The
evidence-backed density target is 256-300 B/entity; semantics, reachability, and
bounded high-water retention remain hard gates. A winner is an admissible
production representation, not a semantic requirement.

`PHYSICAL-TARGET-COMPOSITION-0` is **PREREQUISITE GREEN / INSTALLATION NEXT** at
`02d2055c`. Production inspection falsified naive shared-Map installation:
structural revisions and entity values are prepared independently, so two Map
replacements against one backing would permit the later installer to discard the
earlier authority's change. The layout-neutral composer now merges independent
revision and value contributions by SubjectId into deterministic frozen
envelopes, rejects duplicate same-authority facts and invalid identity/revision
input, and treats value payloads as opaque authority-prepared truth rather than
cloning them twice. Thirteen focused controls, kernel 253 files / 2,059 passed /
3 expected failures / 13 skipped / 1 todo, both TypeScript passes, and kernel
lint are green. No production representation changed. Object versus slot layout,
reachability equivalence, and atomic installation remain unresolved; the next
falsifier applies a composed same-subject revision-plus-value update through one
candidate physical install.

Candidate A's off-store application is **GREEN / PRODUCTION UNCHANGED** at
`a800e663`. `preparePhysicalSubjectTarget()` fully preflights composed updates,
preserves the other authority's fact for revision-only or value-only changes,
requires both facts for a new subject, rejects duplicate updates and
explicit-undefined bypasses, preserves untouched record identity, and produces
complete frozen object records in a copied target Map. The same-subject killer
case leaves revision 3 / old value live during preparation and exposes revision
4 / new value after one assignment. Eighteen focused controls, kernel 253 files
/ 2,064 passed / 3 expected failures / 13 skipped / 1 todo, both TypeScript
passes, and kernel lint are green. This is not production installation, a
density result, or a verdict over slot-indexed separation. Phase 1 remains open
for private EntityMap integration, one non-throwing prepared install, and the
preregistered memory/latency comparison.

The first Phase 1 density comparison is **CANDIDATE A REJECTED / CANDIDATE B
PROVISIONAL** at generator `e68b8c40`. Five isolated samples at
0/1k/10k/100k reproduce E0's value-plus-revision owner set: the split-Map
incumbent measures 144.7 B/entity against the 144 B calibration, one
SubjectId-to-object-record Map measures 148.4 B (+3.7), and one stable-slot
directory plus subject/revision/value columns measures 136.0 B (-8.7). Every
sample collects, and three- and five-sample rankings are identical. Object
colocation therefore loses this narrow density arm. Stable slots remain only a
provisional rival: the 8.7 B/entity saving has not passed update latency,
high-water churn, sparse retirement, reachability, or production integration.
This does not reopen E3, authorize segmented storage or slot reuse, or select
lifecycle, node, realization, or claim representation. The next discriminator
is latency and high-water behavior before any production wiring.

Prepared-target latency is **GREEN FOR BOTH CANDIDATES / STABLE SLOT REMAINS
PROVISIONAL** at `039173c3`. Validation now occurs once in a branded composed
authority envelope; destination consumers trust it, and full slot integrity is
an explicit diagnostic rather than an asymmetric timed O(N) scan. Nine isolated
samples for one revision-plus-value update at 100k measure 9.768 ms for the
two-Map incumbent, 4.328 ms for object records (-55.7%), and 4.605 ms for stable
slots (-52.9%). Candidate A remains rejected because its speed does not offset
its +3.7 B/entity density loss. Candidate B passes only the narrow dense-memory
and full-target preparation-latency arms: -8.7 B/entity and -52.9% latency. It
is not promoted. High-water churn remains blocked until the lifecycle stage
defines real retirement/deletion/reachability rules; inventing slot deletion in
Phase 1 would contaminate the value-plus-revision result. Production integration,
reachability, sparse retirement, and the full operation matrix remain open.

`SUBJECT-SLOT-REACHABILITY-0` is **CURRENT STABLE-SLOT CANDIDATE REJECTED** at
production-law checkpoint `026ab694` and generator `ee583ea7`. Production proves
the lifetime split directly: retired value backing may disappear while structural
lifetime/revision remains; only externally approved terminal retirement forgets
both. The frame now rejects active-subject lifetime forget during preparation.
The candidate models value release, structural-only revision updates, terminal
holes, monotonic fresh SubjectIds, and no slot reuse. At 100k with 90k values
released, five isolated samples retain 4.80 MB for incumbent Maps versus 6.46 MB
for slots. After four terminal-forget/fresh rounds, incumbent is 10.88 MB,
object records 11.22 MB, and slots 20.12 MB with 460,000 physical slots for
100,000 live subjects. Every owner collects; repaired measurements exclude
round temporaries, preserve in-place Map high-water behavior, aggregate peak
independently, and treat terminal eligibility as external. Candidate B's prior
-8.7 B/entity dense win is therefore not reachability-compatible; Candidate A
remains rejected. Authority composition survives. No slot reuse, generational
identity, split value directory, lifecycle packing, or production migration is
authorized by this negative result.

`SPLIT-POOL-PROMOTION-0` is **CARRIER COMPETITION PRE-REGISTERED / NO WINNER**.
The product property is independent physical lifetime for stable structural
identity and optional value backing. Adversarial confirmation establishes the
function but selects no carrier: incumbent authority Maps already provide it,
and a coherent rival uses authority-owned structural records with nullable,
freshness-checked handles into a general allocator. Compare that rival with a
SubjectId directory over separate structural/value pools; neither is the target
architecture. The directory and allocator are addressing machinery, never fact
authority. Every recycled physical address must reject stale handles, and value
backing plus its visible address must publish atomically after all expected
failure. SubjectIds remain monotonic and never reused. The first external
falsifier is release value / retain revision, recycle the physical value address
for a fresh SubjectId, reject stale access, reacquire value for the original
SubjectId, then terminally release both. Carrier survival requires a material
win in dense, 90%-value-release, and four-round terminal-forget workloads while
meeting existing latency, capacity, collectability, identity, restoration,
transaction, and GC gates. Production integration remains forbidden.

`PHYSICAL-VALUE-ADDRESS-0` is **FRESHNESS CONTRACT GREEN / CARRIER UNSELECTED**
at `98f78a88`. An external value-pool candidate component accepts branded
authority-prepared values, atomically prepares backing plus visible address,
releases backing independently, and reuses physical slots without reusing
SubjectIds. Handles carry SubjectId / slot / generation; both fresh-subject and
same-subject reuse reject stale handles, and `MAX_SAFE_INTEGER` generation
exhaustion refuses before IEEE-754 repetition. The directory has a runtime
immutable private-field view rather than a mutable Map exposed as ReadonlyMap.
Eight focused controls and kernel 254 files / 2,086 passed / 3 expected failures
/ 13 skipped / 1 todo, both TypeScript passes, lint, formatting, and independent
review are green. The concrete component owns a SubjectId-to-handle directory;
the checked-allocator rival may instead keep equivalent handles in
authority-owned structural records and reuse only the freshness/publication
contract. This does not select a carrier, place structural truth, authorize
production integration, or establish a density/latency win. Both carriers must
consume the same contract in the frozen workload comparison.

`SPLIT-POOL-PROMOTION-0` is **CLOSED NEGATIVE FOR BOTH PRE-REGISTERED
CARRIERS / INCUMBENT REMAINS** at `338aad21`. Five isolated collectable samples
compare off-store targets with identical identity/value cardinalities and the
same generation-checked reuse law. At 100k dense active subjects, incumbent
revision/value Maps retain 10.86 MB, directory split pools 18.10 MB, and checked
structural-record handles 18.41 MB. With 90% of values released while all
revisions remain, the result is 4.80 / 8.04 / 10.74 MB. After four terminal
forget/fresh rounds, it is 10.89 / 18.52 / 18.82 MB; both value pools keep
logical address units bounded at 100,000. Removing the pool directory does not
pay for per-structural-record object/handle overhead. Both candidates fail the
hard density gate before carrier latency matters, so no production integration
is authorized. `SUBJECT-RECORD-PROMOTION-0` is also closed negative across its
object-record and single-slot candidates. Incumbent authority Maps are the
current production winner, not an architectural necessity. Authority composition
and physical freshness/publication remain reusable green contracts; the
experimental carriers stay outside package entry points.

`ACTIVE-NODE-SUBJECT-INDEX-0` is **CLOSED NEGATIVE / INDEX RETAINED BY
MEASUREMENT** at shadow checkpoint `0d8a051b`, with final dual-index generator
`d6e3a294`. A guarded
derived route (`SubjectId -> lifetime active key -> activeNodesByKey -> node`)
preserves exact node identity across create, rekey, reorder, tombstone, fresh
same-key occupation, restore, and prepared-target installation. Exact E0-shaped
ablation saves 36.3 B/entity, reproducing the frozen index attribution. The final
interleaved 15-sample exact-checksum run measures 19.9 ns direct versus 32.5 ns
derived (+63.2%). The >10% hard threshold rejects removal despite the material
memory win. Full
kernel validation at the shadow checkpoint is 255 files / 2,092 passed / 3
expected failures / 13 skipped / 1 todo, with typecheck, lint, formatting, and
independent review green. `activeNodesBySubject` remains production state by
evidence, not semantic necessity; no removal is authorized.

`ACTIVE-NODE-KEY-INDEX-0` is likewise **CLOSED NEGATIVE / INDEX RETAINED BY
MEASUREMENT** at `d6e3a294`. The guarded inverse route (`key -> subjectIds ->
activeNodesBySubject -> node`) preserves exact identity across the same shadow
matrix and independently saves 36.3 B/entity. Its interleaved 15-sample timing is
23.2 ns direct versus 41.9 ns derived (+80.5%), with exact lookup checksums. Both
active-node indexes therefore earn their measured allocation under the current
point-operation latency contract. Neither result establishes semantic necessity
or global optimality; both reject deriving one permanent lookup direction through
the other. No production index removal is authorized.

`DERIVED-ONE-WAY-0` is **DOW-A / CLOSED GREEN** at `75c003c2`. A production
Angular consumer falsified the previous freeze by exposing multiple public
construction models and a staged-derived abstraction with no surviving user
job. The corrected surface has one constructor, `signalTree(initialState,
config?)`; one derived declaration, singular `config.derived`; and one state
facade, `tree.$`. The positional derived factory, fluent `.derived()`, public
builder, duplicate public `ISignalTree`, `DerivedOf`, `derivedFrom`, tier arrays,
and the internal derived queue/plural dispatcher are deleted. Dependencies among
derived values use ordinary local reactive composition inside the one factory.

`PRODUCTION-CONSUMER-0` is **CLOSED GREEN** at `75c003c2`. The demo application
constructs its real store through `@signal-tree/angular`, keeps the writable tree
private, exposes readonly `$`, and exercises nested state, entity collections,
derived values, and ops-driven writes. Validation: both TypeScript passes; kernel
2,011 passed / 3 expected failures / 16 skipped / 1 todo; Angular 24 passed; demo
110 passed / 4 skipped; kernel, Angular, and demo lint/build targets; packed
Angular 22 consumer typecheck; 16/16 production route smoke tests; API and spec
baseline checks; independent release review; and `npm run gates -- --release`
66/66 with zero known-red.

`RC-CANDIDATE-PREP-0` is **CLOSED GREEN** at candidate commit `4020b7dd`.
Current v15 guidance teaches only singular `config.derived`; historical material
remains historical; and the v14-to-v15 migration names the removed duplicate
construction forms. `15.0.0-rc.1` is normalized across the workspace and package
version authorities. A clean no-cache build produced the kernel and Angular
tarballs; direct inspection proved their exports, declarations, notices, package
hygiene, versions, and exact Angular-to-kernel candidate dependency. A fresh
Angular 22 consumer installed those exact tarballs, typechecked, bundled, and ran
the singular-derived/entity/readonly scenario. Publish artifacts, exports, built
manifests, production instrumentation stripping, and release claims pass;
`npm run gates -- --release` is 66/66 with zero known-red. Final independent
review found no blocker.

The package/build arrangement is accepted for greenfield v15: public `kernel`
then `angular`, private bundled `shared`, preserve-modules ESM Rollup, workspace
dependency ownership in source, exact runtime dependency resolution in built
manifests, and one self-validating ordered release set used by every publish
path. Empty legacy package directories are local cleanup only and do not enter
the project graph, manifests, build, or tarballs.

RC authorization was granted after this candidate checkpoint. RC1 is now live:
tag `v15.0.0-rc.1` points to candidate source `4020b7dd`; both public packages
were published from the exact validated tarballs; registry downloads were
byte-identical; normal npm install, strict typecheck, and runtime passed; and the
GitHub release is marked prerelease.

The two bounded post-RC findings are closed without reopening v15 semantics.
Angular's `sideEffects: false` finding was superseded by construction-bound
realization at `23c6de5a`: the package root now binds
`ANGULAR_TREE_REALIZATION` directly into its exported factory and performs no
runtime registration side effect. The manifest and its direct control therefore
remain correct. Emitted kernel JSDoc still taught deleted `.with()` construction;
`78ea2ff6` replaces that active guidance with the declarative enhancer-tuple
contract. The declaration-doc gate now discovers the actual non-private package
set, checks emitted declarations, and self-tests both stripped documentation and
the known retired-API guidance through the production predicates.

Post-`84d39ae8` type/surface closure is checkpointed at `1c021fb6`.
`READONLY-FOREIGN-REACTIVE-0` is **RF-A / CLOSED GREEN**: readonly projection
uses the existing callable grammar to distinguish zero-argument foreign readers
from SignalTree accessors with effective write parameters. Carrier propagation
remains **PCP-A / CLOSED / FROZEN** after release synchronization found and
closed one missing test row: derived-result projection now carries `C` through
`ProcessDerivedOf<T, C>`, and both package matrices assert the derived member
itself. Source typechecks, kernel/Angular tests and lints, package builds,
installed PCP/RF declaration controls and isolated packed runtime controls are
green. The authoritative public ledger is now kernel root 55, kernel adapter 24,
Angular 51. After synchronizing package names, demo consumers, live links and
self-test anchors, `npm run gates -- --release` passes 66/66.

`RC-HARNESS-2` is **CLOSED GREEN**. The product-defect hypothesis was refuted;
the benchmark now transpiles the real committed `restoration-eligibility` and
`path-observation-port` implementations instead of maintaining behavioral
stubs. Smoke and full 21-sample history-ownership runs exit 0.

Release-gate synchronization is checkpointed at `ca519588`. It repaired the
derived-result carrier gap, migrated live Angular demo consumers, removed the
retired persistence demo, regenerated the public API baseline, and retargeted
release tools and self-tests from deleted `core` paths to the kernel/Angular
split. Validation: `npm run typecheck`, kernel 2016 passed with 3 expected
failures, Angular 24 passed, demo 108 passed with 4 skipped, packed Angular
consumer typecheck, signal identity durability 4/4, and
`NX_DAEMON=false NX_ISOLATE_PLUGINS=false npm run gates -- --release` 66/66.

## V15 Public API Freeze — RE-AUTHORIZED

The V15 public API is **FROZEN AGAIN** at `75c003c2`. The prior freeze was
properly suspended by the `PRODUCTION-CONSUMER-0` counterexample and replaced by
the `DOW-A` singular construction model above. No public rename, removal,
signature reshape, new adapter contract or semantic API addition is permitted
unless another production consumer or release-blocking falsifier demonstrates
that this corrected contract cannot ship.

```text
public signature closure       GREEN / FROZEN
carrier propagation            GREEN / FROZEN
readonly foreign reactive      GREEN / FROZEN
kernel neutrality              GREEN / FROZEN
Angular realization            GREEN / FROZEN
RC harness 1/2/3               GREEN
final runtime                  GREEN
final memory / retention       GREEN
final restoration retention    GREEN
final shipping cost            GREEN
release gates                  66 / 66
regressions over budget        NONE
```

`FINAL-RELEASE-EVIDENCE-0` is **CLOSED GREEN**. Enforced shipping evidence:
bare production 9.07/9.7 KB, bare development 11.22/11.9 KB, EntityMap
production 19.50/21 KB, EntityMap development 22.11/23.7 KB; kernel tarball
193,607 bytes, Angular tarball 10,248 bytes, `kernel/adapter` 0.06 KB gzip and
the existing public-surface mix 33.74 KB gzip. These figures authorize no
optimization work.

`15.0.0-rc.1` is the published first release candidate. Candidate source remains
`4020b7dd`; later evidence and documentation commits do not change its artifact
authority.

### FROZEN — persistence invariants

Burden of proof is now reversed. Do NOT reopen kernel architecture to inspect
one more idea. Reopen only when a later release test produces a concrete,
deterministic counterexample to one of these:

1. The durability authority is TREE-SCOPED. Commit-ness is never inferred from
   the presence or absence of a transaction on the call stack.
2. Callers DESCRIBE durable consequences; the authority decides when they may
   execute. No caller determines commit-ness for itself.
3. Any unresolved scope on a tree holds that tree's durability.
4. Foreign-tree scopes never interfere.
5. Successful compensation DISCARDS speculative consequences.
6. Refused compensation FLUSHES surviving authoritative truth. "Nothing to
   reverse" is a trivially successful rollback, not a refusal.
7. Durable consequences resolve surviving truth at EXECUTION time, never a
   value captured when the write was authored.
8. Persistence settlement is distinct from causal confirmation.

Freeze evidence: seven defects found and closed across three antagonistic audits
plus one verification; the defect curve ran 3 → 2 → 1 → 1, and the final one was
in a caller, not in the redesigned authority. Ladder at `4f7a2169`: 1715 passed
/ 20 skipped / 1 todo / 0 failed, build and lint clean.

The agent may continuously consume unchecked work within the current phase.
The agent must stop at the phase boundary when the exit gate is satisfied or a
decision condition from `AGENTS.md` is reached.

Do not auto-transition into the next phase in the same session without an
explicit human checkpoint.

## Budget

- Rough execution budget: 30-60 agent-hours
- Rough review/decision budget: 8-15 human hours
- Rough calendar budget to `1.0.0-rc.1`: 3-7 focused days, then RC soak

The architecture work is now a minority of what remains. Packaging, public
API/type verification, docs, consumer testing, and release automation are the
bulk.

## Release Invariants

- SignalTree owns truth.
- Angular owns observation.
- Causal history owns meaning.
- `PositionId != SubjectId != SlotIndex != key/path`.
- All expected fallible semantic work precedes private commit.
- PRIVATE COMMIT consumes prepared instructions only.
- Atomicity is externally observable coherence, not a count of internal
  revision increments. Specifically:

  - physical revisions are monotonic implementation stamps, never transaction
    identities, and never rewind — compensation is itself a physical commit;
  - each actual private physical commit may advance the revision;
  - a semantic transaction may span more than one private substrate commit;
  - no observer, publication adapter, persistence consequence, or other
    external consumer may observe an intermediate heterogeneous state.

  "One physical commit = one shared revision bump" still holds. "One
  transaction = one physical commit = one revision bump" does not, and was
  never the contract. Proven at `e74e63d1`.

- PROJECT reflects committed truth; it never determines authority.
- Persistence is post-commit.
- **Durable storage never gets ahead of the tree's settled commit state.** One
  authority answers this for every durable consequence:

  - no open commit scope on this tree → durable consequences may run;
  - one or more open commit scopes → durable consequences wait;
  - scopes settle → persist current surviving truth.

  The gate is TREE-LOCAL: a transaction open on tree B never delays tree A.
  Commit-ness is NEVER inferred from where the JavaScript call happened —
  "outside a transaction callback" is not the same as "this tree has no
  speculative state". Callers describe a consequence; they do not decide when it
  runs.

- A rollback REFUSAL is not a rollback success and not a transaction abort. The
  reversal attempt failed; nothing was compensated; the authored effects remain
  the live authoritative state, so their deferred consequences flush. Durable
  truth must never be made to disagree with live truth in order to honour a
  reversal that did not happen.
- A speculative transaction may defer a consequence only when ownership of the
  mutated node by that transaction's tree is POSITIVELY established. Ambiguous
  attribution must never suppress a committed consequence. (The write context is
  ambient; presence of a transaction is not evidence that a write is speculative
  under it. Pinned by `stored-commit-ordering.spec.ts` "does not absorb a write
  into a FOREIGN tree transaction scope".)
- Scope settlement is lifecycle cleanup and must occur even when compensation
  refuses or throws. Semantic failure may propagate; consequence infrastructure
  must never remain wedged. (Pinned by `persistence-commit-ordering.spec.ts`
  "is not wedged forever when compensation refuses".)
- Local scalar/structural operations must not scale with unrelated `n`.

## Two Independent Work Lanes

The remaining work runs in two lanes. Neither lane may silently redefine the
other, and neither is a universal blocker on the other.

```text
RELEASE LANE
  Gate B work proceeds independently toward a trustworthy public
  declaration/package surface.

DERIVATION LANE
  Architecture audits proceed in bounded evidence-only slices, so long as
  they change no production semantics and contaminate no Gate B artifact.
```

**A derivation blocks Gate B in exactly one case:** it produces a concrete,
deterministic counterexample to a public contract Gate B is about to freeze.
Interest, elegance, or an attractive unfilled cell in RFC 0016 is not that case.

**And the reverse, which is the easier mistake to make:** Gate-B mechanics are
not evidence that an architectural function survives. A symbol appearing in a
clean declaration artifact, a green packed gate, a passing API baseline — none
of these earn a function, an owner, or a lowering. They establish only that the
current surface is accurately represented.

The dependency edges are specific, not blanket:

- Tier 2 concepts do NOT wait on MUT-3 to have their function derived — Rule 0k
  says so explicitly, and "almost everything waits on MUT-3" must not become a
  universal blocker.
- Causal machinery — history, undo/redo/rollback, transactions, devtools capture,
  batching where publication semantics intersect — DOES wait on MUT.
- Package verdicts (Tier 4) wait on their semantic owners being known.
- Gate B waits on the declaration artifact, not on architecture.

RFC 0016 is the ledger for the derivation lane; this file remains the controller
for execution sequencing. **Do not record execution sequencing in RFC 0016, and
do not promote RFC 0016 content into this file** — the RFC is CANDIDATE, and a
candidate that gets cited from the controller becomes indistinguishable from a
frozen result within one session.

There is no "architecture design" work item. There are independent derivations
that gradually fill RFC 0016. Architecture is earned when those rows converge —
and a repeated shape in CURRENT FORM is not convergence.

## RULE 0j-2 DELETION-CONTAMINATION CHECK — **all three CONTAMINATE. Delete before the next derivations.**

Frozen deletions: `status` (S1), `asyncSource` and `asyncQuery` (A1). The
question Rule 0j-2 asks is not whether they can be deleted, but whether any
REMAINING derivation's evidence surface can observe them.

**Answer: yes, and it hits the next four queued derivations.**

```text
BLAST RADIUS
  Status        17 files · 152 refs
  AsyncSource    9 files ·  85 refs
  AsyncQuery    10 files ·  85 refs

CONTAMINATED EVIDENCE SURFACES, by queued derivation
  lib/readonly.ts                  23 refs   <- the readonly/reader-allowlist row
  internals/materialize-markers.ts 10 refs   <- marker materialization
  enhancers/serialization.ts        5 refs   <- serialization row
  markers/entity-map.ts             3 refs   <- the entityMap derivation
  markers/entity-loader.ts          2 refs   <- the parked cache disposition
  markers/stored.ts                 0 refs   <- stored() is CLEAN
```

`readonly.ts` is the clearest case: it imports `StatusSignal`,
`AsyncSourceSignal` and `AsyncQuerySignal` and defines a reader allowlist for
each. Deriving what `asReadonly` is FOR, while three of its allowlist rows exist
to serve deleted concepts, would measure machinery whose only purpose is already
gone. Same for marker materialization and the serialization snapshot surface.

**`stored.ts` is clean (0 refs)**, which is a useful surprise: the hydration
derivation is NOT blocked by these three, contrary to the expectation that
`status`'s hydrate participation would contaminate it. `status` participates in
hydration through the generic marker machinery, not through `stored` itself.

### Required order

```text
1  STATUS-DEL / ASYNC-DEL   physical deletion, one marker per commit
2  entityMap derivation
3  close the parked entity-loader cache disposition
4  inbound hydration / reconstruction derivation
5  map onto stored()
6  linked
7  serialization / readonly / diagnostics
```

**This is unlike `.with()`**, whose physical cut remains BLOCKED: its surviving
realization, planning and type-contribution functions still need a construction
destination, and deleting it first would strand them. These three strand nothing
— their functions were found to belong to the application, the Angular reactive
layer, the store and `derived`, all of which already exist.

## STATUS-DEL — ATTEMPTED, PRODUCTION CUT COMPLETE, **NOT COMMITTED**

The production surface was removed cleanly and the working tree was then RESTORED
to HEAD. The cut survives as a patch:
`scratchpad/STATUS-DEL-production.patch` (1374 lines, 8 files, 1223 deletions).
Stopped rather than half-finished, because the remaining work is an order of
magnitude larger than the production surface suggested and needs judgement per
file.

### The blast radius was INFLATED, by a vocabulary collision

```text
CLAIMED   Status  17 files · 152 refs
ACTUAL     8 production files with a real marker dependency
```

`enhancers/time-travel/time-travel.ts` accounted for 7 of the 17 files with
`getTurnStatus` / `assertTurnStatusConsistency` — CAUSAL TURN status, nothing to
do with the marker. `utils.ts`, `signal-tree.ts`, `materialize-markers.ts` and
`serialization.ts` were PROSE ONLY, naming `status()` as an example in comments;
the dynamic processor registry means there is no hard import.

**Third vocabulary collision this session**, and the first to inflate rather than
deflate. It extends Methodology Rule 2 into its general form:

> **A lexical hit is neither evidence of presence nor evidence of dependency.**

The same failure has now occurred in both directions:

```text
runId          expected vocabulary MISSED real behaviour   -> false negative
getTurnStatus  shared vocabulary COUNTED unrelated code    -> false positive
```

So the standard for a deletion blast radius is: **enumerate lexical candidates ->
inspect semantic dependency -> count only resolved dependencies.** The original
17-file / 152-reference figure stays in this record precisely because its
correction demonstrates that a raw grep total is not an architectural metric.

### The production cut, verified

```text
DELETED    markers/status.ts · markers/status.contract.ts · markers/status.spec.ts
EDITED     types.ts (import + 3 TreeNode branches)
           readonly.ts (import, STATUS_READERS, ReadonlyStatusSignal, dispatch)
           markers/index.ts · index.ts · authoring.ts (exports)
           LoadingState — status-only, removed with it
```

### What stopped it — and it is a real finding

**`status()` HAS CONSUMERS.** S1 never measured them; only `asyncSource` and
`asyncQuery` consumption was measured (both zero). Measured now:

```text
demo consumers          3 files genuinely construct status() markers
                        markers-demo · time-travel-demo · marker-zoo
                        (most other demo hits are store fields or component
                        signals named `status` — the collision again)

core spec references    24 files · 145 refs
```

**The spec references are the real problem, and deleting them would destroy
surviving coverage.** Most use `status()` as a convenient MARKER FIXTURE to
exercise generic machinery that survives — rehydration, marker materialization,
serialization traversal, walker conformance, SSR transfer, causal capture. Those
tests are not about `status`; they are about mechanisms with other users. They
must be MIGRATED to another marker, not removed, or the deletion silently takes
generic coverage with it.

That is the "PRESERVE generic infrastructure that still has surviving users"
boundary, and it is where the judgement per file lives.

### Sequence for the next attempt

### CLASS 3 GATE TABLE

**The withdrawal is PER TEST CASE, not per file.** Most of these files carry
`entityMap` cases beside their `status` case — `marker-roundtrip` has both
_"entityMap: entities survive"_ and _"status: Loaded survives"_; `ssr-transfer`
carries an entityMap collection; `hydrate-decisions` covers a loader-backed
entityMap. Those cases are untouched. Only the status specimen withdraws.

| Spec                      | Function actually under test                              | Function status                                          | Evidence role       | STATUS-DEL action                                                      |
| ------------------------- | --------------------------------------------------------- | -------------------------------------------------------- | ------------------- | ---------------------------------------------------------------------- |
| `rehydration`             | generic marker reconstruction                             | **UNPROVEN**                                             | regression          | withdraw status cases; defer replacement                               |
| `marker-roundtrip`        | snapshot → reconstruction                                 | **UNPROVEN**                                             | regression          | withdraw the `status:` case; entityMap case stands                     |
| `marker-materialization`  | registered marker realization                             | **UNPROVEN**                                             | regression          | withdraw status cases                                                  |
| `hydrate-decisions`       | hydrate decision reporting                                | **UNPROVEN**                                             | regression          | withdraw status cases; asyncSource cases go with ASYNC-DEL             |
| `marker-serialization`    | marker external representation                            | **UNPROVEN**                                             | regression          | withdraw status cases                                                  |
| `ssr-transfer`            | transfer representation                                   | **UNPROVEN** (RFC 0014 exists, not derived here)         | regression          | withdraw status case; entityMap case stands                            |
| `lazy-markers`            | lazy realization                                          | **UNPROVEN**                                             | regression          | withdraw status case                                                   |
| `traversal-diagnostics`   | traversal over markers                                    | **UNPROVEN**                                             | regression          | withdraw status case                                                   |
| `rehydrate-ownership`     | ownership across rehydrate                                | **UNPROVEN**                                             | regression          | withdraw status case                                                   |
| `legacy-payload`          | legacy payload handling                                   | **UNPROVEN**                                             | regression          | withdraw status cases                                                  |
| `intercept-leaf-signals`  | owner paths for built-in markers                          | **UNPROVEN**                                             | regression          | withdraw status case                                                   |
| `devtools`                | marker mutator notification                               | **UNPROVEN**                                             | regression          | withdraw status case                                                   |
| `transactions`            | marker source-signal rollback via the generic causal path | kernel **FROZEN**; marker participation **UNPROVEN**     | mixed               | withdraw the marker case — frozen transaction coverage lives elsewhere |
| `greenfield-transactions` | heterogeneous write capture through the frozen kernel     | kernel **FROZEN**; marker as one write-kind **UNPROVEN** | mixed               | withdraw the marker write-kind; keep the kernel assertions             |
| `undo-redo`               | marker source-signal owned turns; restore-vs-rehydrate    | **UNPROVEN**                                             | regression          | withdraw both status cases                                             |
| `persistence`             | save/load of a tree                                       | persistence **FROZEN**                                   | regression          | status is fixture furniture — use plain state or drop from the fixture |
| `planned-signal-tree`     | pre-exposure planning                                     | function **SURVIVED**; public constructor **REJECTED**   | mixed               | keep only assertions belonging to the earned planning function         |
| `write-only-marker`       | —                                                         | —                                                        | test infrastructure | remove the unused import                                               |
| `time-travel:3305`        | status promise-vocabulary aliases                         | **REJECTED**                                             | legacy contract     | **DELETE with the feature** (Class 1)                                  |

**Every UNPROVEN row is regression coverage.** Not one of them is an
architectural falsifier for a frozen claim, so by the premise above none has a
survival entitlement, and none may force a fixture into existence.

`planned-signal-tree` and the two transaction specs are the only mixed rows —
each protects something genuinely earned alongside its marker specimen, so the
earned assertions stay and only the specimen withdraws.

#### MIXED-ROW GUARD — DISCHARGED. Both frozen theorems keep independent specimens

A regression test has no survival entitlement, but **a frozen theorem still
does.** So each mixed row was checked for whether the earned property retains
coverage after the specimen withdraws. It does, in both cases, without moving
anything onto another marker.

**`transactions.spec` — the frozen property is "rollback works without
feature-specific logic".** The test immediately following the status one is
_"rolls back pending stored writes and restores persisted state"_ — the same
property, a different specimen, already present. Alongside it:

```text
"rolls back a pending optimistic transaction without reverting later …"
"aborts a thrown transaction callback by undoing only transaction writes"
"aborts a mixed structural thrown rollback through the realization port"
"throws rollback error with preserved callback failure when realization …"
```

Five independent specimens remain. Nothing frozen is lost, and critically the
status case is not MIGRATED to `stored()` — an independent `stored()` case
already exists on its own merits.

**`greenfield-transactions.spec` — the frozen property is heterogeneous-write
participation.** Its fixture carries FOUR write kinds:

```text
profile      plain nested state
users        entityMap structural
request      status marker        <- withdraws
preference   stored marker
```

Removing one leaves three genuinely distinct kinds — plain, structural, and a
marker. Heterogeneity is still exercised, so the falsifier survives the
withdrawal rather than needing reconstruction.

**`planned-signal-tree`** keeps only assertions that falsify the earned
pre-exposure planning function; anything asserting the rejected separate public
constructor goes.

#### Recorded obligation

```text
COVERAGE WITHDRAWN WITH STATUS-DEL

reason        the test required a REJECTED public feature as its only specimen
subject       generic marker machinery — UNPROVEN, neither deleted nor
              preserved architecturally by this action
obligation    the generic-marker functional derivation must independently decide
              whether replacement coverage is warranted, and in what form
production    UNCHANGED — no generic mechanism is deleted by withdrawing a test
```

### THE CYCLE WAS FALSE — Rule 0l applies to TESTS

I framed this as _"STATUS-DEL is blocked on the marker derivation."_ **Wrong.**
The status-dependent REGRESSION TESTS are blocked on it; STATUS-DEL is not.

The missing premise:

> **Current regression coverage is non-semantic unless the function it protects
> has independently earned survival.**

And Rule 0l, extended to tests:

> **A legacy test may identify a function worth examining; it may not force
> preservation of the fixture, mechanism, or ontology it happened to use.**

An UNPROVEN mechanism does not gain the right to keep a REJECTED feature alive
merely because its regression tests chose that feature as their specimen. The
inverse order would be worse than untidy — it would run the marker derivation
while the dead `status` mechanism still participates in the machinery under
measurement, which is exactly what Rule 0j-2 exists to prevent.

```text
WRONG A   replace status with stored()      manufactures stored ownership
WRONG B   build a TestMarker                manufactures marker ontology
WRONG C   keep status until the derivation  contaminates the derivation
CLEAN     withdraw the status-dependent case, leave generic PRODUCTION
          machinery untouched, derive the generic function against a
          status-free surface, then restore only earned coverage
```

That is subtraction-only applied to tests. Withdrawing this coverage is not
"silently losing tests" — it is **deliberately withdrawing evidence whose fixture
is no longer admissible**, with the obligation recorded.

### PRECISION — withdrawing tests authorizes NO production deletion

```text
DELETE      status implementation · public surface · status-specific typing
            status-specific tests
WITHDRAW    generic tests whose ONLY fixture was status, where the function
            under test is UNPROVEN
LEAVE       marker registry · hydrate hooks · materialization · owner-path
            support — every generic production mechanism, UNCHANGED
```

Removing a test does not derive its subject. The generic machinery is deleted
only if its own function fails its own derivation.

### REVISED QUEUE

```text
1  Class 3 table: function / status / evidence role / action
2  STATUS-DEL — feature, Class 1, and the withdrawals; production machinery
   untouched
3  full gates + independent residue verification
4  DERIVE GENERIC MARKER FUNCTIONS IMMEDIATELY, against a status-free surface
5  per surviving function: add a capability-minimal falsifier
6  per rejected function: delete the corresponding generic machinery
7  remeasure the asyncSource / asyncQuery surfaces from the new HEAD
8  entityMap · hydration · serialization · readonly
```

Step 4 is deliberately immediate: the withdrawals create a documented coverage
gap, and the derivation that resolves it should not queue behind anything else.

### CLASSIFICATION CORRECTED — **Class 2 is EMPTY.** Nearly all of STATUS-DEL is Class 3

The two-question check overturned my own classification on every ambiguous row,
and then on every row I had assigned to Class 2. Test NAMES were decisive:

```text
transactions.spec
  "rolls back pending status source-signal writes WITHOUT STATUS-SPECIFIC LOGIC"
  -> the test exists to prove the GENERIC rollback path works. status is the
     marker instance, not the subject.

intercept-leaf-signals.spec
  "reports owner paths for BUILT-IN MARKERS at their owning positions"
  -> generic marker owner-path machinery.

greenfield-transactions.spec
  "captures HETEROGENEOUS real writes on one draft"
  -> status supplies one of the heterogeneous write kinds: a marker source
     signal.

undo-redo.spec
  "an in-process undo keeps LOADING" — about restore-vs-rehydrate differing for
  in-flight state, i.e. the marker's HYDRATE semantics
  "undoes direct status source-signal writes AS ONE OWNED TURN"
  -> generic marker-ownership machinery.

devtools.spec
  "sends updates when MARKER MUTATORS emit owner-only notifications"
  -> generic marker mutator machinery. I had called this Class 2.

time-travel.spec:3305
  "records history for status PROMISE-VOCABULARY ALIASES"
  -> the subject IS status's `start()`/`fail()` aliases, which S1 already
     identified as documented DX for AI agents. CLASS 1, delete with the feature.
```

**Revised classification:**

```text
CLASS 1   status-specific coverage           delete WITH the production cut
CLASS 2   ordinary writable state            EMPTY
CLASS 3   generic marker machinery           essentially everything else
```

#### Why this matters more than a re-labelling

`status()` was not chosen by those tests because it was convenient writable
state. It was chosen because it is **a marker with source signals, hydrate hooks
and mutators** — precisely the surface generic marker machinery needs to be
exercised against. The tests are already doing the right thing; they just picked
a public feature as the specimen.

So nearly ALL of STATUS-DEL falls into the one category where a careless fixture
choice manufactures future evidence. The strengthened rule is not a refinement
here — it is the whole job.

And the survival question now bites hard, because the machinery these specs
exercise is **marker machinery itself**: source-signal ownership, owner-path
reporting, hydrate/restore/rehydrate distinction, mutator notification,
heterogeneous write capture. Whether the MARKER CONCEPT survives 15.0 is not
settled anywhere in this RFC. Migrating thirteen-plus specs onto a hand-built
test marker would quietly assert that it does.

**Consequence:** the Class 3 survival table is not optional bookkeeping before
the edits. It is the gate. Several rows may resolve to _"do not migrate; this
coverage belongs to a derivation that has not run."_

### FIXTURE RULE, STRENGTHENED — capability-minimal per falsifier

> **Test fixtures are capability-minimal PER FALSIFIER, not merely
> public-feature-neutral.**

"A marker with hydrate/snapshot hooks and nothing else" is still too broad. One
shared test marker carrying marker + hydrate + snapshot + capabilities + lazy
behaviour would replace _"status accidentally sponsors generic machinery"_ with
_"TestMarker accidentally asserts all generic machinery belongs together"_ — the
test equivalent of inventing an architecture envelope before the functions earn
one.

```text
needs materialization      -> local materializable marker
needs snapshot             -> local snapshot marker
needs hydrate + snapshot   -> local roundtrip marker
needs write-only behaviour -> local write-only marker
```

Consolidate two fixtures only AFTER measurement proves they require the same
semantic contract.

### AND: "generic machinery" is NOT automatically SURVIVING machinery

This is the larger correction. I described the Class 3 specs as exercising
"surviving mechanisms". **That is not proven for every row.** Several are
themselves in or adjacent to the unaudited matrix — marker hydration,
materialization, serialization, legacy payload, hydrate decisions, SSR transfer,
lazy markers, and `plannedSignalTree`, whose separate public constructor has
already been found to have no earned survival.

So each Class 3 spec needs TWO questions, not one:

```text
1  what function is status() a fixture FOR?
2  has THAT FUNCTION independently earned survival?

  FROZEN / SURVIVING   preserve coverage with the minimum local fixture
  UNPROVEN             do NOT migrate merely to make STATUS-DEL green
  REJECTED             delete the test with the rejected function
```

Otherwise STATUS-DEL manufactures future evidence not through `stored()`, but by
**preserving generic infrastructure whose own survival has not been earned.**

Where coverage must be kept while its architecture is still open, the fixture
comment must say so in as many words:

> _This fixture preserves current implementation coverage. It is not survival
> evidence._

### TEST-EVIDENCE TAXONOMY — worth keeping beyond STATUS-DEL

```text
ARCHITECTURAL FALSIFIER   proves or refutes an architectural claim
REGRESSION COVERAGE       protects current behaviour; confers NO survival
LEGACY CONTRACT TEST      protects an already-rejected mechanism -> delete with it
TEST INFRASTRUCTURE       enables another test; confers NO ontology
```

A surprisingly large part of STATUS-DEL is really about **not misreading
regression coverage as architectural evidence.**

### ORDERING CORRECTION — Class 1 deletions go WITH the production cut

My step order was wrong. Deleting `status.spec.ts` before `status.ts` would leave
a live feature untested for the duration. The correct order:

**DECIDED: TWO COMMITS.** The "one atomic commit" rule was too coarse. The
atomic unit is the LIVE FEATURE plus the tests whose SUBJECT is that feature —
the withdrawn Class 3 regression cases are not part of it.

```text
COMMIT 1 — EVIDENCE WITHDRAWAL
  withdraw   status-dependent cases whose subject is UNPROVEN generic machinery
  trim       mixed rows, only where the frozen theorem is independently covered
  migrate    genuinely incidental fixture furniture (persistence)
  UNTOUCHED  status.ts · contract · exports · StatusSignal · LoadingState ·
             status.spec.ts · status-specific typing rows · status-focused demos

  -> run the suite. This proves removing inadmissible regression evidence did
     not weaken independently earned coverage — something a single commit cannot
     show.

COMMIT 2 — STATUS-DEL
  delete     implementation · contract · exports · types · readonly
             specialization · LoadingState · Class 1 tests · status-specific
             typing rows · status-focused demos
  UNTOUCHED  generic marker production machinery
```

This does not reintroduce the atomicity problem. The bad split would be _delete
tests, then delete implementation_, leaving a live feature without its own
contract coverage. Here the status-SPECIFIC coverage stays with the feature until
Commit 2; Commit 1 removes only cases already classified as UNPROVEN-subject,
rejected-fixture, regression-role.

**HARD CONDITION: no architectural derivation between the two commits.** The
intermediate HEAD still contains the dead status production mechanism, so it is
NOT a valid evidence surface for the marker, entityMap, hydration, serialization
or readonly derivations. Rule 0j-2 governs the gap between the commits exactly as
it governs the gap before them.

All fixture migration happens while everything still works; the deletion is then
a single reviewable step rather than a red-tree scramble.

### STEP 1 COMPLETE — spec classification, and the count collapsed AGAIN

Measured by SEMANTIC DEPENDENCY (imports the marker), not by lexical hit.

**`time-travel.spec.ts` has ONE real marker usage, not 44.** Its other 44 hits are
`entity.status()` — an ordinary string field on entity records holding `'idle'`,
`'queued'`, `'busy'`. **Fourth vocabulary collision this session**, and it removes
the single largest file from the migration.

```text
CLAIMED   24 spec files · 145 refs
ACTUAL    20 spec files importing the marker + 3 typing specs
          and the largest of them needs a ONE-LINE change
```

#### CLASS 1 — `status` IS the subject -> DELETE the coverage

```text
markers/status.spec.ts                    83   the whole file
readonly.typing.spec.ts                        ReadonlyStatusSignal rows
markers/marker-resolution.typing.spec.ts       StatusSignal resolution rows
signal-tree-type-matrix.typing.spec.ts         StatusSignal matrix rows
```

Note the FORM-DEL lesson recurs: `readonly.typing.spec.ts` produced four
`Expect<false>` failures when the type vanished, because deleting a type INVERTS
its negative assertions. Those rows are not independent defects.

#### CLASS 2 — ordinary STATE behaviour -> plain store state, no marker

The test needs something writable that changes; a marker was incidental.

```text
time-travel.spec.ts:3306      1   `{ load: status<string>() }` — one line
undo-redo.spec.ts             6
greenfield-transactions.spec.ts 5
transactions.spec.ts          4
intercept-leaf-signals.spec.ts 1
devtools.spec.ts              1
```

#### CLASS 3 — generic MARKER machinery -> test-only minimal marker

These are the ones that matter, and the ones that must NOT default to `stored()`.
Each tests a surviving mechanism, using `status()` only because it was a
convenient marker to hand.

```text
rehydration.spec.ts          20   marker hydration
planned-signal-tree.spec.ts  11   marker + capability planning
marker-serialization.spec.ts  7   marker serialization
marker-roundtrip.spec.ts      6   snapshot/restore roundtrip
hydrate-decisions.spec.ts     6   hydrate decision reporting
marker-materialization.spec.ts 4  materialization under nesting
legacy-payload.spec.ts        3
ssr-transfer.spec.ts          2   SSR transfer of marker state
rehydrate-ownership.spec.ts   2
persistence.spec.ts           2
traversal-diagnostics.spec.ts 1
lazy-markers.spec.ts          1   lazy materialization
write-only-marker.spec.ts     -   imports only
```

Thirteen files, and the fixture they need is a marker with hydrate/snapshot hooks
and nothing else — which is precisely the point. A test-only marker implementing
ONLY those hooks proves the generic mechanism independently of any public
feature's ontology, and cannot later be mistaken for evidence that a shipped
marker was required.

### MIGRATE FUNCTIONS, NOT MARKERS — the fixture rule

**Defaulting the 24 specs to `stored()` would be the colocation error in test
form.** `stored()` is clean of dead-marker references, which does not make it the
correct replacement fixture. Rewire generic tests onto it and `stored()` becomes
the accidental sponsor of generic marker infrastructure — so when its own
derivation runs, tests will appear to demonstrate demand that exists only because
we put it there.

```text
BAD
  generic rehydration test uses status()
    -> status deleted -> now uses stored()
    -> `stored` looks necessary to generic rehydration

BETTER
  generic rehydration test uses an explicit TEST-ONLY hydratable marker
    -> proves the generic mechanism independently of public feature ontology
```

For each spec, ask **what property `status()` was exercising**, then preserve it
with the minimum fixture that expresses it:

```text
1  status-SPECIFIC behaviour        DELETE the assertion
     ReadonlyStatusSignal, status predicates, status hydration values,
     public LoadingState
2  ordinary STATE behaviour         use ordinary store state
     a time-travel or transaction test needing only something writable does not
     need a marker at all
3  generic MARKER behaviour         use a test-only minimal marker implementing
     ONLY the hooks that test requires — labelled unmistakably as test
     infrastructure, not architectural evidence
4  another feature is the real SUBJECT   use that feature, because the test is
     genuinely about it — never because it is convenient
```

Keep those fixtures local or narrowly scoped at first. Do NOT invent one grand
`TestMarker` abstraction up front; consolidate only if the same capability
recurs. Some of the generic marker machinery is itself still an unaudited
evidence surface, and today's migration choice must not manufacture tomorrow's
survival proof.

### Sequence

```text
1  classify all 24 specs by the FUNCTION their status() fixture exercises
2  delete status-specific coverage
3  replace ordinary-state fixtures with ordinary state
4  replace genuinely generic marker fixtures with the smallest test-only marker
5  demos: REMOVE where status IS the subject (markers-demo section, marker-zoo
   entry); for time-travel-demo's `job`, ask what time travel actually needs —
   if merely a changing value, plain store truth is the cleaner replacement
6  RE-EXECUTE the eight-file production deletion from HEAD, using the recorded
   surface as a checklist — do NOT treat the scratchpad patch as authoritative
7  typecheck · RAW VITEST full suite · lint · declaration closure · packed
   consumer (public exports change)
8  independent read-only residue check
9  inspect every remaining lexical hit SEMANTICALLY
10 commit STATUS-DEL alone, then REMEASURE the async contamination surface from
   the new HEAD — subtraction is not linear
```

**Do not apply the production patch first.** It breaks 24 specs and 3 demo files
simultaneously, which converts a reviewable migration into a red-tree scramble.

## Test-executor operability — capture raw Vitest on the FIRST failure

`nx test core` wraps Vitest and **discards its output on failure**: a failing run
produces a ~28-line log with no failing test name, no assertion, no stack. That
has now cost twice — once requiring an assertion to be deliberately inverted just
to prove a suite was executing at all, and once losing the identity of a real
failure permanently.

> **On the next `core:test` failure, reproduce through raw Vitest BEFORE rerunning
> anything.** Repetition destroys the failing state and converts a debuggable
> defect into an irrecoverable anecdote.

```bash
cd packages/core && npx vitest run                      # full, with real output
cd packages/core && npx vitest run <path-to-spec>       # one file
```

### Standing record — one unexplained suite failure

```text
one full-suite failure, immediately after adding a falsifier spec
  failure identity UNRECOVERABLE through the nx wrapper

afterwards
  8/8 isolated passes · 4/4 full-suite passes · 1 clean baseline with the
  spec stashed
```

**Supported conclusion:** there is one unexplained historical suite failure, and
no causal attribution to that spec is supported. NOT "the spec caused it", and
NOT "the suite is definitely healthy". Nx's flaky-task banner now persists from
that single event.

This is an infrastructure finding. It neither weakens nor strengthens any
architectural claim, and it is recorded here rather than in RFC 0016 because the
architecture RFC does not need executor-operability details.

## RELEASE-PROCESS DEFECTS — found while sizing the 14.x interceptor patch

Discovered by asking a narrow question (is 14.1.2 published?) and checking the
registry rather than git. **git tags are not the record of what shipped.**

### The ledger

```text
npm @signaltree/core
  versions   ... 14.0.0-rc.1, 14.1.1, 14.1.2          latest = 14.1.2
  time       also lists 14.0.0 and 14.1.0 — ABSENT from `versions`,
             so both were published and then UNPUBLISHED
  14.1.2     published 2026-08-17T21:39Z

git
  tags       only v14.0.0-rc.1 and v14.1.1 exist. NO v14.1.2.
  main       9 commits past v14.1.1, ALL dated 2026-08-11, all docs.
             packages/*/package.json still read 14.1.1 — the 14.1.2 bump was
             NEVER COMMITTED anywhere, on any branch.
```

### What 14.1.2 actually is

Reconstructed from the published tarball:

```text
contains dist/lib/markers/status.js        -> pre-STATUS-DEL
contains ST2031 in entity-signal.js        -> BEFORE b47598a1 (2026-08-13)
package.json "license": "Apache-2.0"       -> AFTER e1617fb1 (2026-08-11 11:40)
README says Apache-2.0                     -> same
```

`e1617fb1` — _"license: relicense from BUSL-1.1 to Apache-2.0"_ — exists **only on
`history/gate1-frontier-cutover`**. It is not on `main`.

So **14.1.2 was published from the 15 development branch**, from a working-tree
state roughly 2026-08-11 to 08-13, six days before the publish, with an
uncommitted version bump. Not from `main`, not from a release branch, not from
any tagged commit.

### The blocking issue: the repo and the registry disagree on the LICENSE

```text
v14.1.1 tag      BUSL-1.1   (README + root LICENSE)
main             BUSL-1.1   (README + root LICENSE)
this branch      Apache-2.0 (root LICENSE)
published 14.1.2 Apache-2.0 (package.json "license", README)
                 and NO LICENSE FILE IN THE TARBALL AT ALL
```

Tarball root contains only: `dist`, `llms-full.txt`, `llms.txt`, `package.json`,
`README.md`, `skills`, `src`.

A consumer reading GitHub sees BUSL-1.1 — commercial use permitted, converts to
MIT on 2028-09-05. A consumer reading npm sees Apache-2.0 with an explicit patent
grant. **These are materially different grants**, and the Apache-2.0 relicense
lives only on an unmerged development branch.

**This blocks the 14.1.3 publish, not the fix.** Cutting 14.1.3 from `main` would
ship BUSL-1.1 to consumers who currently hold Apache-2.0 — a license regression,
and not a decision an implementer should make silently. The code change is
identical on either base.

### Required decisions (owner: repository owner)

```text
1  Which license is authoritative for the 14.x line?
2  If Apache-2.0: merge/cherry-pick e1617fb1 to main BEFORE cutting 14.1.3, so
   the mainline matches the registry.
3  Ship a LICENSE file in the package `files` list. A package declaring
   Apache-2.0 with no LICENSE text is a compliance gap regardless of which
   license wins.
4  Retro-tag 14.1.2? Its exact source state is not identifiable from any commit
   (uncommitted bump, mixed working tree). A tag would be a guess — recommend
   NOT fabricating one, and instead recording this ledger as the provenance.
```

### Process fixes to carry into 1.0

```text
- publish ONLY from a tagged commit on main or a release branch
- commit the version bump; fail the publish if git is dirty or untagged
- include LICENSE in `files`
- verify the published tarball after publish (npm pack + diff against the tag)
```

## RULE 0p — NULL ADMISSIBILITY (same level as the zero-legacy rule)

> **A null must falsify an INDEPENDENTLY EARNED contract. It may not define that
> contract by the distinctions it chooses to preserve.**

This is not test guidance. It determines whether an experiment is
**architecturally admissible at all**. An inadmissible experiment produces
evidence that cannot be used, however green it runs.

### The ordering this rule imposes

```text
candidate function
      v
independent contract
      v
OPPOSITE contract
      v
PREMISE ATTACK
      v
ONLY THEN null construction
      v
measurement
      v
PREMISE ATTACK on the interpretation
      v
architectural conclusion
```

The audit stops being _"build a null and see whether it works"_ and becomes
_"first prove there is something legitimate for a null to falsify."_ That is the
guard whose absence explains nearly every error below.

### Why this exists

Every significant error in the frontier/collections derivations had one shape: the
incumbent _mechanism_ was removed while one of its semantic _assumptions_ stayed
embedded in the null. The null came back green because it was built to answer a
question whose answer it already partly encoded.

```text
P3          assumed undo must produce A            -> invented contract
tap         sampled after every mutation           -> STRONGER observation than any
                                                      real consumer
stored      used TestBed.tick()                    -> WEAKER durability timing than
                                                      the incumbent it judged
rekey       remove+add                             -> answered a weaker identity
                                                      question
E2          `current === after`                    -> value equality substituted
                                                      for authorship
E2-S        "held reference must revive"           -> incumbent handle semantics
                                                      became the requirement
E2-S0       retargeting called "wrong-row"         -> reference semantics became
                                                      the requirement
E2-S00      object-reference compare               -> identity reappeared INSIDE
                                                      the identity-free null
computed    framework realization                  -> leaked into kernel evidence
```

Executable falsifiers reliably catch _"the implementation doesn't do what we
thought."_ They cannot catch _"we never established it should do what the test
asserts."_

## PRE-REGISTRATION — complete BEFORE any null is implemented

```text
FUNCTION                 stated without incumbent nouns
INDEPENDENT CONTRACT     what must be POSSIBLE — not what currently happens
OPPOSITE CONTRACT        <-- LOAD-BEARING
                         the strongest plausible alternative, stated FAIRLY,
                         and why it is invalid.
                         NO ANSWER => STOP. Nothing legitimate to falsify.
HIDDEN DISTINCTIONS      does the claim depend on any of:
                           value vs identity        history vs current state
                           address vs identity      author vs value
                           lifetime vs key          timing
                           observation frequency    framework behaviour
                           mutable vs immutable representation
NULL PERMISSIONS         what information may the null use?
FORBIDDEN INFORMATION    what would smuggle the incumbent back in?
FAILURE CONDITION        what exact result kills the null?
SURVIVAL CONDITION       what exact result earns the FUNCTION — not merely
                         reproduces current behaviour?
```

**Worked example.** For E2-S00:

```text
PROPOSED   a retained lookup must not retarget after key reuse
OPPOSITE   a lookup IS an address, and therefore SHOULD retarget
WHY IS THE OPPOSITE IMPOSSIBLE?   ... no answer available
```

No answer, so there was nothing to falsify. Implementation should never have
started.

## NEUTRAL LANGUAGE — mandatory until the contract earns itself

Much of the contamination entered through **names, not code**. Each of these
labelled a result before the contract had earned the classification.

```text
FORBIDDEN before the function survives
  wrong · correct · original subject · alias · owner · stale
  should preserve · must survive · destroyed · surviving contribution

PREFER
  the current occupant changed
  a previously acquired observation now returns X
  value before / value after
  the key was reused
  the implementation distinguishes A from B
```

After the contract survives, semantic language becomes legitimate.

## COMMIT DISCIPLINE

```text
MEASUREMENTS      may commit freely
INTERPRETATIONS   may NOT commit until the premise attack closes
VOCABULARY        measurement commits must use OBSERVATION-ONLY language
```

Without the third clause, _"measurements commit freely"_ recreates the exact
contamination channel that `wrong-row read` travelled through. A conclusion one
level too strong survives long enough for the next derivation to inherit it, and
the corrective commit arrives after the damage. The cost of a high commit rate is
not the commits — it is the vocabulary they publish.

## COMMAND VERDICT GATE

```text
If a required gate returns NON-ZERO:

  architectural conclusion commit = FORBIDDEN

until exactly one is true:

  1  the defect is reproduced and fixed
  2  the failure is classified as a test/infrastructure fault, WITH EVIDENCE
  3  a rerun succeeds AND the original failure is explicitly recorded as
     UNRESOLVED / NON-REPRODUCIBLE

A later green result does NOT turn an earlier red verdict green.
```

### COMMAND VERDICT GATE — first recorded application (against this session)

```text
COMMAND   npx vitest run --root packages/core
RESULT    exit=1
ACTION    an architectural conclusion was committed anyway  (74261e62)
RERUN     exit=0 — 174 files passed | 2 skipped, 1776 tests passed
```

```text
DISPOSITION 3
  the original failure is recorded as UNRESOLVED / NON-REPRODUCIBLE
```

The failure was **unresolved at the decision boundary**. It is NOT recorded as
"transient therefore harmless": no defect was reproduced, no evidence classified it
as an infrastructure fault, and the later green run does not retroactively make the
earlier decision valid. This is the violation that motivated the gate, kept as its
first entry.

## THE HOSTILE MATRIX IS A CHALLENGE MATRIX, NOT A CONTRACT GENERATOR

```text
SAME VALUE / DIFFERENT CAUSE          ABA
DIFFERENT VALUE / SAME IDENTITY       ordinary update
SAME KEY / DIFFERENT MEMBERSHIP       remove + reuse
DIFFERENT KEY / SAME MEMBERSHIP       only if rekey independently survives
SAME FINAL STATE / DIFFERENT HISTORY  add/remove, round-trip mutation
NESTED PATH                            siblings preserved
ASYNC INTERLEAVING                     begins, state changes, resumes
FRAMEWORK-FREE                         no framework realization in a semantic test
INCUMBENT-FREE                         no entityMap / SubjectId / effect vocabulary
```

Per case, exactly one disposition:

```text
APPLICABLE      execute it
NOT APPLICABLE  state which independently earned contract makes it irrelevant
NOT CLEARED     leave open
FORBIDDEN       adding the property to the contract merely because the matrix
                contains it
```

Otherwise the testing framework manufactures semantics — solving the old problem
by requiring every candidate to satisfy nine properties it never promised.

### EMPTY LOWER RUNGS ARE NOT A DEFECT

```text
If a candidate depends on a behaviour NOT PRESENT in the frozen premises, do not
use measurement or repository archaeology to supply it FOR THAT CANDIDATE.
Close or park the row.

If a row's independently frozen premises ARE sufficient to decide the function, it
MAY be reasoned abstractly WITHOUT measuring current behaviour.
Rungs 1 and 2 are NOT prerequisites for a function verdict.
```

A rung-3 verdict reached on sufficient premises is legitimate with rungs 1 and 2
empty. What is illegitimate is **filling a premise gap with measurement.**

Recorded because an interpretation reviewer once explained a row's undecidability as
_"rung 3 entered with 1 and 2 empty — that is out of order"_, and the author adopted
it and generalized it to four unopened rows. That framing implies measurement would
have decided the row, which is the same "provisional against measurement" error
already struck elsewhere, returning in ladder clothing. **The ladder describes what
evidence supports what claim. It does not require a row to produce evidence it does
not need.**

## EVIDENCE LADDER — and a single experiment advances it by ONE STEP ONLY

```text
1  MEASURED CURRENT BEHAVIOUR
        v   requires observation only
2  AN ALTERNATIVE MODEL REPRODUCES / DIFFERS
        v   requires a PREMISE ATTACK
3  THE FUNCTION IS REQUIRED
        v   requires a representation-null comparison
4  A REPRESENTATION PROPERTY IS REQUIRED
        v   requires competing realizations
5  A PARTICULAR CARRIER SURVIVES
```

_"A held reference revives after undo"_ earns **step 1**. Nothing more. The
one-step limit is stronger than "no finding skips more than one step", because a
sufficiently seductive test will otherwise produce
`measurement -> therefore the function survives -> therefore SubjectId` inside a
single interpretation.

## THREE PASSES, FORMALLY SEPARATED

```text
AUTHOR PASS          pre-register · implement · measure · state a NARROW finding
PREMISE ATTACK       attack the FUNCTION and the OPPOSITE CONTRACT, before any
                     architectural conclusion.
                     FORBIDDEN from discussing how to implement the candidate.
                     Its only question: WHY DOES THIS FUNCTION NEED TO EXIST?
REPRESENTATION ATTACK   only after the function survives
```

The premise attack's implementation ban is what preserves Rule 0j's subtraction
discipline: a reviewer who starts designing the mechanism has already granted it.

**Structural limit, recorded plainly.** One agent deriving the requirement,
designing the null, implementing it, debugging it, interpreting it and writing the
verdict is prone to confirmation bias whatever the discipline. Once the words
_"wrong-row read"_ are written, the classification precedes the contract. **A
checklist cannot make an author independent of their own framing** — the controller
can only make the omission visible. An empty OPPOSITE CONTRACT field is therefore
a stop condition, not a note.

## DELEGATION POLICY — independence is the point, not headcount

The old rule was _"only use subagents when explicitly requested."_ Replaced:

> **Use subagents whenever epistemic independence materially improves the
> decision. Keep writes and final architectural authority centralized.**

Antagonistic review is **automatic at row boundaries**. It is not something to ask
permission for each time.

### Differentiated packets — the load-bearing part

Five agents that all see _"I think SubjectId is necessary because key reuse causes
wrong-row aliasing"_ are not five reviews. They are one frame, five times. What
buys independence is giving them **deliberately different information and
incentives**:

```text
AGENT A — FUNCTION KILLER
  gets   frozen premises + candidate function ONLY
  job    show this function should not exist
  default disposition: NOTHING SURVIVES

AGENT B — ABSENCE ARCHITECT
  gets   the same material
  job    give the strongest coherent architecture in which the function is ABSENT

AGENT C — NULL BREAKER
  gets   the earned contract + the proposed null ONLY
  job    find where the null is weaker than, stronger than, or different from the
         contract — or smuggles information in
         (timing · identity · observation frequency · framework · incumbent leaks)

AGENT D — INTERPRETATION REVIEWER
  gets   pre-registration + raw command output ONLY. NOT the author's conclusion.
  job    state the MAXIMUM conclusion the evidence supports
```

**Contextual independence is achieved by withholding, not by adding.** A packet
carrying the author's rationale inherits the author's premise and the gate is
wasted.

### Competing hypotheses in parallel, then arbitration

For an uncertain row, fork the positions instead of inventing one and then trying
to disprove yourself:

```text
H0  NOTHING is needed
H1  keyed address semantics suffice
H2  stable incarnation identity is required
H3  the function belongs OUTSIDE SignalTree
```

One agent argues each from the same frozen premises. The primary agent
**arbitrates**. That is a healthier role separation than deriver-and-self-critic,
which is what produced this session's error run.

### Where NOT to delegate

Not for a grep, a test run, a mechanical refactor, a lint failure, or an obvious
measurement — that produces prose without epistemic value. Delegate when the
question contains:

```text
must exist · owns · identity · semantic · minimum · equivalent
replace · delete · survives · architecture
```

Those are exactly the decisions where a framing error is expensive.

### Reviewers may review each other, bounded

For the highest-cost closures:

```text
Deriver -> Antagonist finding -> Deriver response -> a SECOND antagonist sees BOTH
```

**Only new evidence extends the loop.** Restating a position does not.

### Subagents do not write architecture

They return bounded findings and nothing else:

```text
CLAIM
CLASS                      MEASURABLE · DERIVABLE · POLICY · FROZEN · OUT-OF-ROW
WHY
FALSIFIER
SEVERITY
WHAT THIS DOES NOT ESTABLISH
```

The primary agent owns synthesis and commits. Otherwise competing architectural
truths accumulate in the repo and the ledger stops being a single record.

## THE THREE GUIDELINE GAPS THAT PERMITTED THE E4 SYNTHESIS ERRORS

Recorded because the corrections alone would not prevent a recurrence. Each gap is
stated with the failure it allowed.

### GAP 1 — Gate 2 was routed only after a MEASUREMENT

The protocol flow read:

```text
... null pre-registration -> experiment -> RAW ARTIFACT -> GATE 2 -> conclusion
```

E4-G produced **no experiment** — Gate 1 forbade construction. So the flow appeared
to terminate before Gate 2, and skipping it looked compliant. It was not: the row
still produced a **synthesis**, and that synthesis is where every overclaim entered.

```text
CORRECTED ROUTING — Gate 2 applies to a SYNTHESIS, not to a measurement.

Any row that produces a written conclusion passes Gate 2, including:
  a row closed NOT ESTABLISHED with no experiment
  a row closed by measurement
  a row closed by arbitration

THE RAW MATERIAL for Gate 2 is whatever the row actually produced:
  reviewer reports, or the measurement artifact, or both.
  NEVER the author's synthesis.

A row that reaches NULL FORBIDDEN is NOT exempt. It is the case most in need of
review, because there is no measurement to discipline the prose.
```

### GAP 2 — nothing required the row CLOSED to be the row OPENED

E4/U5b was a broad transaction-semantics row. The packet tested concealment,
conclusion modes and nesting. The closure was then written against the broad name.
No rule forbade the rename.

```text
SCOPE INVARIANCE — the row closed MUST be the row opened.

At closure, restate the pre-registered question VERBATIM and answer only it.
If the packet tested a narrower question than the row name, the row is RENAMED to
what was tested and the original row REMAINS OPEN with its untested contracts
enumerated.

A closure may never be broader than its packet. Widening is a NEW row.
```

### GAP 3 — an absence architecture's PARTS were treated as findings

Reviewer B's job is to exhibit a coherent world without the candidate. Nothing said
what weight the components of that world carry. So `turn-coalesced notification`,
invented because B needed _something_ in that slot, was recorded as a "surviving
container obligation."

```text
AN ABSENCE ARCHITECTURE IS AN EXISTENCE PROOF, NOT A DESIGN.

Its function: to show the candidate is not necessary.
Its parts carry NO derivation weight. Each is a DEFERRED CANDIDATE that must pass
its own row — premise attack included — before it is anything.

Specifically FORBIDDEN: recording a component as "surviving", "earned", "derived",
or "the answer" because the absence architect required it to build a coherent
world. That inverts the reviewer's role from killing into designing, which Rule 0j
forbids: kill first, derive later.

The same applies symmetrically to the function killer: its supporting arguments are
not theorems. See the DO NOT INFER precedent.
```

### CLOSURE CHECKLIST — run before writing any row conclusion

```text
[ ] restate the pre-registered question VERBATIM
[ ] is the conclusion answering exactly that question, no wider?     (GAP 2)
[ ] list every claim in the conclusion. For each: which reviewer output or
    measurement supports it, quoted?
[ ] does any claim rest on a component of an absence architecture?   (GAP 3)
    -> demote to DEFERRED CANDIDATE
[ ] does any claim promote a reviewer's supporting argument to a theorem?
    -> demote, per DO NOT INFER
[ ] how many evidence-ladder steps does the conclusion advance?      (must be <= 1)
[ ] has GATE 2 seen the raw material without this synthesis?         (GAP 1)
```

The checklist is not a substitute for Gate 2. It is what makes Gate 2's job small.

### TWO RULES THIS ROW EARNED

```text
NO BORROWED RUNGS
  If rung 1 (measured behaviour) is NOT ENTERED, rung 2 (alternative model
  comparison) is NOT ENTERED either — an analytical equivalence witness cannot
  occupy a rung defined by comparison against measurement.
  An analytical witness is PRESENT but OUTSIDE the ladder.
  "Rung N at best, on borrowed footing" is FORBIDDEN phrasing: it is an escape
  hatch around the no-skipping rule.

UNDERDETERMINED IS A TERMINAL STATE, NOT A WORK ORDER
  When the premises do not decide a candidate:
    -> CLOSE the row
    -> record a PARKED REOPENING CONDITION
    -> STOP

  FORBIDDEN: going on to establish the missing premises so the candidate becomes
  testable. Each missing premise is itself a CANDIDATE FACT, and some are
  candidate FUNCTIONS. Adopting one because it makes another row testable is
  replacement-after-deletion in a new form.

  MISSING FACTS ARE NOT AUTOMATICALLY MISSING REQUIREMENTS. Premise silence may
  be correct, because the function may not independently arise.

  A falsifier produced by a closed row is a REOPENING CONDITION, never a queue.

  AND: do not benchmark a mechanism with no architectural standing. Measuring it
  lends it gravity through sunk effort. A cost becomes owed only when a SURVIVING
  function forces a decision between two representations.
```

### GATE 2 IS NOT EXEMPT FROM THE RULES IT ENFORCES

```text
Gate 2 may produce REOPENING CONDITIONS.
Gate 2 may NOT create follow-up work whose ONLY purpose is to make a CLOSED
CANDIDATE DECIDABLE.
```

Observed once, on its second application: the reviewer correctly detected that the
premises did not decide a candidate, and then wrote _"two obligations follow"_ —
including a cheap check to run and a question to settle. Both existed only to make
the closed candidate decidable. That is the transition the underdetermined-is-
terminal rule forbids, committed by the gate that enforces it.

**A reviewer's strongest alternative interpretation is EVIDENCE ABOUT THE ROW, not
a work order.**

### THE NULL COMES AFTER BOTH GATES

```text
Gate 1 kills it           -> Gate 2 BOUNDS the interpretation -> close
Gate 1 finds a contract   -> Gate 2 CONFIRMS that inference   -> only THEN
                             preregister a null
```

Gate 1 can establish that a candidate deserves testing. Gate 2 must first verify
the survival interpretation has not itself jumped a premise. **A row does not need
an experiment — reaching the correct disposition is the success criterion.**

### THE SINGLE INVARIANT ALL GATES SERVE

Adding a new mechanism at each newly discovered boundary leak does not converge:
each is compliant with its own letter and leaks where it does not reach.

> **Every stage is subordinate to the same burden rules. No reviewer, gate,
> experiment, absence witness, or synthesis has authority to manufacture the
> premise needed by the next stage.**

That covers premise attack, null construction, interpretation review and closure
with one rule instead of four, and it is what every observed failure violated.

### THE OPPOSITE CONTRACT MUST NOT STIPULATE AN ANSWER

```text
A pre-registered OPPOSITE CONTRACT may not contain a clause that DECIDES a
question the row might need to decide.
```

Observed on U5b-A. The opposite contract was written as _"the grouping premise
governs only confirmed reversal granularity"_ — which handed the null the answer to
precisely the question a reviewer then identified as undecided by the premises. Any
closure leaning on the null's wording was leaning on a stipulation, and the phrase
had to be recorded as **the author's wording, not a finding.**

```text
BEFORE OPENING A ROW, check the opposite contract for:
  clauses beginning "only" / "merely" / "nothing but"
  any clause that ASSERTS the scope of a frozen premise rather than CITING it
  any clause that would be a FINDING if a reviewer produced it
```

A stipulation inside the instrument is indistinguishable from a result once the row
closes. This is a defect of the INSTRUMENT, and it is the author's, not a
reviewer's.

## MANDATORY INDEPENDENT REVIEW — two gates, not optional tools

> **No architectural null may run without an independent PREMISE ATTACK, and no
> architectural conclusion may land without an independent INTERPRETATION ATTACK.**

This is part of the evidence standard, not process overhead. The standing
"no subagents unless asked" restriction is **lifted for read-only antagonistic
architectural review** and for nothing else.

```text
candidate row
      v
PREMISE REVIEWER  (Reviewer A — FUNCTION KILLER)
      v
BLOCKER? -- yes --> resolve / mark UNPROVEN / abandon the row
      v no
null pre-registration
      v
experiment
      v
RAW ARTIFACT  (command · exit status · output)
      v
RESULT REVIEWER  (Reviewer B — NULL BREAKER)
      v
BLOCKER? -- yes --> resolve BEFORE any conclusion
      v no
architectural conclusion
```

**A row that reaches NULL CONSTRUCTION FORBIDDEN does NOT exit this flow.** It skips
the experiment and goes straight to GATE 2 with the reviewer reports as its raw
material. Gate 2 gates the SYNTHESIS, not the measurement.

### GATE 1 — premise review. The reviewer MAY REJECT THE FUNCTION ITSELF.

Handing over "the function statement and the proposed contract" already smuggles
the first premise in. The packet carries frozen premises plus a clearly marked
_candidate_:

```text
ZERO STATE
  known surviving invariants: ...

CANDIDATE FUNCTION — UNPROVEN
  ...

PROPOSED CONTRACT — UNPROVEN
  ...

Attack in order:
  1  Why must this FUNCTION exist at all?
  2  What becomes impossible if it does not?
  3  Can surviving primitives already provide the capability?
  4  State the strongest coherent OPPOSITE CONTRACT.
  5  What assumption is embedded in the proposed wording?
  6  What information would a null be FORBIDDEN to use?
  7  Is there actually an earned contract available to falsify?

If function survival is not established:
  STOP — NULL CONSTRUCTION FORBIDDEN.
```

### GATE 2 — interpretation review. Raw evidence only, never the conclusion.

```text
RAW MEASUREMENT      command · exit status · output/artifact
PREREGISTERED CLAIM  ...

Ask:
  1  What was actually measured?
  2  Did the null use information FORBIDDEN by pre-registration?
  3  Did framework / current-implementation / legacy semantics leak in?
  4  Does the result advance: current behaviour · model equivalence ·
     function survival · representation necessity · current-representation
     survival?
  5  Is the proposed conclusion more than ONE evidence step beyond the result?
  6  State the strongest ALTERNATIVE interpretation.
```

### The reviewer gets LESS context, not more

Contextual independence is achievable even within one model family — by
withholding. **Excluded from a premise packet:**

```text
the expected outcome            the author's rationale
the proposed replacement design v14 mechanisms
current representation details, unless genuinely necessary
loaded vocabulary — "wrong", "alias", "restore original", "stale", "owner"
```

Only frozen architecture and the candidate question go in. A premise packet
contaminated with the author's reasoning inherits the author's premise, which
defeats the gate.

### Two roles, deliberately different failure modes

```text
REVIEWER A — FUNCTION KILLER
  Default disposition: NOTHING SURVIVES.
  Job: show the candidate function is unnecessary.

REVIEWER B — NULL BREAKER
  Assume the function survived.
  Job: show the null is weaker than, or different from, the contract — or that it
  smuggles information in.
```

Merging these into "review this" makes it easy for both to be missed. **Neither
reviewer proposes the replacement architecture** — that is Rule 0j: kill first,
derive later. A reviewer who starts designing the mechanism has already granted it.

### A BLOCKER CANNOT BE DISMISSED BY DISAGREEMENT

A `BLOCKS-CLOSE` finding closes only through the existing classification, never by
the author explaining why they disagree:

```text
MEASURABLE     one experiment settles it
DERIVABLE      attack the premise / the inference
POLICY         explicit arbitration
FROZEN         a deterministic falsifier is required
OUT-OF-ROW     PARK
```

### Row wording must not arrive pre-shaped

_"Does `structural` need more than canonical truth?"_ is already
representation-shaped — it names the incumbent's field. Start one level up:

```text
What independently surviving function, if any, requires information that cannot
be reconstructed from canonical truth at confirmed-reversal time?
```

Then let the reviewer attack whether even _that_ function exists. Only after
survival: _what information property is required?_ Only then: _what representation
carries it?_ This keeps `structural`, `SubjectId`, effects, snapshots and
generation tokens out of the question until they are earned.

### Why the misses happened — recorded, because it is the finding

This session ran with:

```text
one reasoner + executable tests + RETROSPECTIVE external review
```

Executable tests caught implementation flaws well. External review caught premise
flaws well. What was missing was putting the second mechanism **before the commit
boundary**. An adversarial-review harness already existed in this repo
(`tools/cross-review/`, and the read-only `release-reviewer` subagent) and went
unused while increasingly elaborate self-checklists were written instead. **That
should have been surfaced far earlier rather than simulated.**

## Required Validation

```bash
pnpm nx test core --skip-nx-cache --output-style=static --verbose
pnpm nx build core --skip-nx-cache --output-style=static
pnpm nx lint core --skip-nx-cache --output-style=static
```

Use focused characterization or slice-level validation first when practical.
Run the authoritative ladder before checkpointing a release slice.

## Workspace Dirt Not Owned By Release Tasks

**The list is empty.** The user-owned `63900634` checkpoint included the former
`.nvmrc` newline-only edit; no release-agent commit rewrote it.

- ~~`eslint.config.mjs`~~ — committed alone at `e5fe21e7` (the `@nx/rollup`
  build-tooling allowlist entry, and a `no-empty-function` exemption for
  `tools/`). Validated directly rather than by proxy: `nx lint core` is green,
  `eslint 'tools/**'` reports 0 errors, and forcing the rule back on produces 9
  violations — so the exemption is load-bearing rather than dead config.
- ~~`packages/ng-forms/src/signals/greenfield-branch-model.spec.ts`~~ — deleted
  by FORM-DEL (`b57ba293`). The file has not existed since; the entry was
  outliving its subject.

The rule stands for whatever appears next: never include unrelated dirt in
release commits. Committing it ALONE is not a violation of that rule — leaving
it to accumulate until it has to be untangled from a release slice is.

## Rules

0. **Measure the property that actually governs the decision. A convenient proxy
   is not evidence for a DIFFERENT property. When two measurements disagree,
   determine whether they measure the same property; if they do, reconcile them
   before acting.**

   Two distinct failure classes, and conflating them is itself a mistake:

   **(a) A weak measurement of the RIGHT property.** These are simply wrong, and
   each produced a confident conclusion that survived until something
   contradicted it:

   | Weak                               | Said               | Strong                   | Truth                             |
   | ---------------------------------- | ------------------ | ------------------------ | --------------------------------- |
   | `grep -c '^export'` on `index.ts`  | core 141           | checker export graph     | 209 across 6 entrypoints          |
   | `SymbolFlags.Value` on an alias    | 2 runtime exports  | `getAliasedSymbol` first | 84                                |
   | `signal(`                          | `stored` uses none | `signal\s*[<(]`          | 1 — it is `signal<T>(`            |
   | `toContain('a')` on a JSON payload | test green         | parse, compare the value | red — matched the `a` in `"data"` |

   **(b) Correct measurements of DIFFERENT properties.** These do not contradict
   each other; all can be true at once, and each answers its own question:

   | Measurement                       | Property it governs          |
   | --------------------------------- | ---------------------------- |
   | Angular imported by source files  | implementation coupling      |
   | Angular in the public `.d.ts`     | type-contract coupling       |
   | Angular in the emitted entrypoint | runtime / package dependency |

   Core is 169-of-209 by the first, 3-of-209 by the second, and requires Angular
   by the third. Reading the second as "core is nearly framework-neutral" would
   be a category error: `angularInType` measured that `schema`'s public API does
   not EXPOSE Angular — it never measured whether the package REQUIRES Angular
   at runtime, which the emitted root import settles, and it does.

0b. **Name the property first, then design the falsifier that measures THAT
property directly. A proxy may support an investigation; it may never close
one.**

Rule 0 says which measurement is right. This says how to arrive at one, and it
is operational rather than an exhortation to care more:

1.  State the property.
2.  State what result would falsify the current hypothesis.
3.  Measure that property directly.
4.  Require a POSITIVE success condition — never merely the absence of a known
    failure string.
5.  Only then change production code.

Step 4 is the one that keeps being skipped. Every row below is a real error
from the 15.0 work, and they look nothing alike until you line them up:

| Question                                    | Weak proxy                                             | Decisive property                           |
| ------------------------------------------- | ------------------------------------------------------ | ------------------------------------------- |
| Is the SDK neutral?                         | module-graph traversal                                 | retained runtime / declaration closure      |
| Does variadic `.with()` work?               | neutral tuple, realization enhancer chained separately | a realization enhancer INSIDE the tuple     |
| Does `T` flow through `restoration`?        | annotated call sites                                   | unannotated inferred consumer type          |
| Is the declaration valid?                   | source typecheck                                       | packed `.d.ts`, consumer compile            |
| Did the build succeed?                      | absence of `error TS`                                  | exit 0 AND artifact exists                  |
| Is the API unchanged?                       | exported symbol names                                  | public type contract                        |
| Is the package consumable?                  | `skipLibCheck: true`                                   | `skipLibCheck: false`                       |
| Does barrel reachability cause the pruning? | plausible export topology                              | already-exported `DefaultKey` still missing |

Corollary, and it is not a consolation prize: **optimize for cheaper, earlier,
more decisive failures — not for fewer failed experiments.** Every falsifier
that fired in this work improved the architecture rather than merely blocking
a change. The heterogeneous `.with()` failure exposed the neutral/realization
distinction; the `RestorationMethods<T>` falsifier produced the polymorphic
`this` design; the emitted-declaration failure exposed a shipped-package
defect that predated the work entirely; the failed barrel probe eliminated a
whole class of API "fixes" that would have widened the public surface to
satisfy a build bug. A green experiment that measured the wrong property costs
far more than a red one that measured the right property.

0c. **"Public" is determined by declaration reachability, not by the `export`
keyword or by JSDoc intent.** If a public signature needs a type, that type
cannot be treated as removable implementation detail by the production
declaration pipeline, however inconvenient that is. `stripInternal` makes this
operationally enforceable rather than merely stylistic: an `@internal` tag on
anything a public declaration references produces a shipped `.d.ts` that names
what it does not declare. See the entity-map resolution under Phase 2.

**Corollary — closure is transitive across BOTH type-space and value-space.** A
public declaration is invalid if it reaches a stripped symbol through a named type,
a conditional or default type argument, a `typeof` query, an alias, or any other
declaration dependency. Two routes are proven in-tree, and treating them as
unrelated bugs is the mistake:

| route       | shape                                                | emitted                                      |
| ----------- | ---------------------------------------------------- | -------------------------------------------- |
| type-space  | `@internal` type named by a public signature         | reference survives, declaration stripped     |
| value-space | public alias of an `@internal` function/class/object | `declare const c: typeof _c` — `_c` stripped |

The value-space route is invisible to "is the name declared?" checks: the alias IS
declared. Only its inferred TYPE is dangling. Any closure gate must therefore check
semantic validity, not symbol presence.

**This rule is COMPLETE — stop adding rules for each new manifestation.** entity-map
and the value-space alias are EXAMPLES of the invariant above, not separate
architectural principles. The general statement is: public declaration closure is
transitive across every dependency needed to interpret the shipped contract.

0d. **FROZEN CONTRACT — a branch node IS a `NodeAccessor<T>`, not an Angular
`Signal<T>`.** This is the rule most at risk during the 15.0 type/API cleanup,
because an agent simplifying `SignalTree`/`ISignalTree`, neutral authoring types,
or enhancer contracts can look at `NodeAccessor` and conclude it "could just be
`Signal<T>`". It cannot.

The model:

```
NodeAccessor<T>   what a SignalTree branch IS
Signal<T>         one way a framework can OBSERVE it
```

Plain object branches such as `tree.$.user` must keep all three call forms:

```ts
tree.$.user(); // read User
tree.$.user({ age: 44 }); // partial / deep branch merge
tree.$.user((c) => ({ ...c, age: c.age + 1 })); // functional update
```

and must stay structurally navigable — `tree.$.user.name`, `tree.$.user.age`.

Required, non-negotiable:

- Do NOT add `.set()` / `.update()` to `NodeAccessor`.
- Do NOT make branch accessors pass Angular's `isSignal()`.
- Preserve the distinction: branch `NodeAccessor<T>` is the SignalTree
  structural/state API; a leaf signal is the framework reactive primitive.
- A branch MAY be reactive when called inside Angular `computed()` / `effect()`
  without itself being an Angular Signal. That is the intended design, not a gap.
- If an Angular API genuinely requires a real `Signal<T>` for a branch, supply it
  through an EXPLICIT adapter/view — never by changing `NodeAccessor<T>`.
- Prefer that branch-to-Signal view be READ-ONLY unless a writable semantic
  contract is separately justified. Angular's `.set()` must not ambiguously mean
  SignalTree deep merge.

Permanent contract tests to add and retain:

```
node()                     reads the exact typed snapshot
node(partial)              deep-merges, preserves omitted state
node(curr => next)         functional update
nested branch navigation   intact
branch  isSignal()         false
leaf    isSignal()         true in the Angular realization
computed(() => node())     reacts correctly
```

Any proposed change to these semantics is a **breaking architectural decision
requiring an explicit counterexample** — not routine type/API cleanup. This
distinction also belongs in the Gate-B realistic type/runtime matrix.

0g. **KERNEL-FIRST GREENFIELD DERIVATION. For every capability, derive the
optimal implementation assuming the current 15.0 kernel exists and NO prior
SignalTree API, package, implementation, or compatibility constraint ever
existed. Existing mechanisms are revealed only AFTER the kernel-native design is
stated. A useful legacy capability does NOT justify its legacy abstraction.**

The decision order, and it is not negotiable:

```
1  GREENFIELD FUNCTION   what capability should exist in an ideal SignalTree 15?
2  KERNEL-NATIVE DESIGN  given the kernel we have, how would we build it if no
                         previous API or package had ever existed?
3  OWNERSHIP             kernel / causal / consequence / publication / adapter /
                         application
4  PUBLIC NECESSITY      does an EXTERNAL implementer genuinely need access?
5  MINIMUM SURFACE       if so, the smallest kernel-native primitive
6  COMPARE               only now, look at the existing mechanism
7  MIGRATION COST        ignore for architecture; record afterwards as execution
```

Step 2 is the one that was missing:

> **Given the kernel, would we invent this abstraction today?**

If no, then having users, tests, docs, third-party value, or completed
conversion work is NOT sufficient to keep its current FORM.

**This applies to INTERNAL machinery as much as public API.** A private
mechanism can be legacy-shaped too. Users never seeing it does not make it
harmless if it forces the kernel through the wrong lifecycle or duplicates an
authority.

0i. **SEMANTIC ROLES ARE DISTINCT AND NARROW. Marker, enhancer, adapter,
consequence and causal integration are different semantic roles. A feature must
EARN its role from its greenfield function. "It needs to plug into SignalTree
somehow" is NOT justification for an enhancer or a marker.**

```
                         SignalTree kernel
                               |
        +----------------------+----------------------+
        |                      |                      |
   compilation            capabilities           publication
        |                      |                      |
     MARKERS               ENHANCERS               ADAPTERS
  what state IS         what the tree CAN DO    how outsiders interact
```

Plus two roles the kernel made explicit:

```
CONSEQUENCE   acts BECAUSE surviving committed truth exists, without becoming
              mutation authority
CAUSAL        owns why/how semantic state changed across time
```

**THE CLASSIFIER:**

```
describes WHAT A POSITION IS                        -> MARKER
adds WHAT THE TREE CAN SEMANTICALLY DO              -> ENHANCER
connects SignalTree to an EXTERNAL REPRESENTATION   -> ADAPTER
acts AFTER surviving committed truth                -> CONSEQUENCE
explains WHY/HOW state changed over time            -> CAUSAL AUTHORITY
```

A feature may use several internally; its PUBLIC ABSTRACTION follows its
PRIMARY OWNER.

**AMENDMENT — THESE ROLES ARE NOT AN EXHAUSTIVE ONTOLOGY.** They are mutually
distinguishable WHERE APPLICABLE, not a complete list of SignalTree concepts.
Plenty of things are none of them: compiler functionality, construction syntax,
queries/read models, utilities, policies, services, derived computations,
framework-local helpers.

> **If a function does not naturally fit one of the five, DO NOT MANUFACTURE A
> ROLE FOR IT.**

Otherwise we replace "everything is an enhancer" with "everything must fit our
new five boxes" — the same form-first error with better vocabulary.

**THE ENHANCER TEST, stated sharply:**

> If I apply this, has the SEMANTIC BEHAVIOUR of the SignalTree itself changed?

```
tree.with(transactions()); tree.transaction(...)
   -> the tree ACQUIRED transaction semantics                  ENHANCER holds

tree.with(formBridge()); tree.getAngularForm(...)
   -> the tree owns the same truth, writes, identity, causality as before.
      An Angular object now presents that truth.               ENHANCER FAILS
```

The second is `Enhancer` used as _"a convenient way to attach methods to the
tree"_ rather than _"a semantic extension of the tree"_. Rule 0g exists to
eliminate exactly that.

**Before the kernel, making everything an enhancer was defensible — the tree
object was the only integration point. It no longer is.** In 15.0 these are
SEMANTIC CATEGORIES WITH NARROW OWNERSHIP, not generic hooks.

#### CONSEQUENCE FOR COMPLETED WORK — item #3 must be re-audited

Migrating six built-ins to `Enhancer<Methods>` proved the PROTOCOL is neutral
and coherent. Under Rule 0h that says nothing about whether each of those
features should BE an enhancer. Do not conclude _"we built an excellent neutral
enhancer model, therefore schema/realtime/ng-forms must fit it"_. Conclude
_"we built an excellent neutral enhancer model — now determine which functions
are actually enhancers"_.

**PRELIMINARY CLASSIFICATION — every row needs its own 0g derivation; none is a
disposition:**

```
transactions   tree acquires transaction semantics        ENHANCER plausible
restoration     temporal/causal capability                 installation form UNPROVEN;
                                                          causal owner already matters
batching       notification timing of realization         UNPROVEN — may be
                                                          publication-side
serialization  DOWNGRADED to UNPROVEN. "tree can serialize itself" assumed the
               conclusion. Apply the test literally: does installing it change
               the tree's SEMANTIC BEHAVIOUR, or merely provide a REPRESENTATION
               of existing truth? `serialize(tree)` as a utility/service may be
               the honest shape rather than `tree.with(serialization())`.
persistence    OWNER FROZEN — governed CONSEQUENCE over surviving committed
               truth, settled in Gate A and NOT reopened here.
               PUBLIC INSTALLATION FORM — should it be installed via an
               Enhancer? UNPROVEN. Rule 0i may reject the installation form
               without touching the semantics.
schema         derived subsystem over truth               UNPROVEN
devTools       external diagnostic projection             ADAPTER hypothesis
guardrails     authoring-time diagnostics                 UNPROVEN
realtime       external synchronization                   UNPROVEN — adapter,
                                                          consequence or other,
                                                          per product function
formBridge     Angular Reactive Forms interop             ADAPTER ownership DERIVED
                                                          (`b4e1ebd5`); enhancer
                                                          form REJECTED; marker
                                                          dependency SEVERED
                                                          (`2937ecbb`)
```

**The persistence row is the pattern to copy:** a FROZEN semantic owner and an
UNPROVEN installation form are different questions. Rule 0i attacks installation
mechanisms without reopening settled semantics.

#### MARKERS GET THE SAME HOSTILITY

`registerMarkerProcessor` existing does not mean feature packages should invent
markers. For each of `entityMap`, `stored`, `status`, `form`, `asyncSource`,
`asyncQuery`, `compared`:

> If the kernel existed first, would this concept genuinely be encoded in the
> DECLARATIVE SEMANTIC STATE DESCRIPTION?

**"Describes what a position is" is NECESSARY BUT NOT SUFFICIENT.** Otherwise
almost any adjective earns a marker — validated, remote, audited, visible,
editable, cached — and we simply move generic extension machinery from enhancers
into markers. A marker must additionally earn CONSTRUCTION-TIME COMPILATION:

```
Does this declare an INTRINSIC SEMANTIC PROPERTY of a position
AND must that property participate in CONSTRUCTION / COMPILATION?
   YES -> marker plausible
   NO  -> marker probably wrong
```

`entityMap` looks strong because structural/entity identity affects how the
graph is COMPILED. Angular forms clearly fails. `form()` is precisely why the
stronger test is needed.

```
entityMap   carries structural/identity meaning            MARKER plausible
stored      encodes durable-storage semantics on a position — check against the
            persistence-CONSEQUENCE architecture before assuming
form        THE INTERESTING ONE — see below
```

**`form` — separate two things that are currently one word.** "This subtree
participates in form/validation SEMANTICS" is not the same as "Angular Reactive
Forms / Signal Forms INTEGRATION". If they separate cleanly, the architecture is:

```
SignalTree semantic form marker
   |-- schema / validation semantics
   |-- Angular Reactive Forms ADAPTER
   +-- Angular Signal Forms ADAPTER
```

rather than Angular forms concerns embedded in SignalTree enhancers. A
HYPOTHESIS to derive — not something to preserve from today's `form()`.

**The contamination test for a marker:** would you accept
`signalTree({ profile: reactiveFormBridge(...) })`? No — that puts Angular
presentation concerns into the semantic state definition. So Reactive Forms
interop is not a marker concern either.

0h. **MIGRATION COST IS NON-SEMANTIC. Migration difficulty, consumer count,
already-completed conversion work, documentation volume and compatibility effort
have ZERO weight in determining the 15.0 architectural endpoint.**

```
CORRECT    determine ideal endpoint -> freeze it -> measure blast radius -> migrate
FORBIDDEN  measure blast radius -> adjust the endpoint to make migration easier
```

None of these are architectural arguments:

```
"this would change 40 call sites, maybe keep an alias"
"we already migrated this enhancer, probably keep it"
"deleting this breaks the demo, maybe it is required"
```

They describe how much EXECUTION follows a decision, never which decision is
right. Under Rule 0e, the forbidden ordering is precisely how old ontology
survives a major release.

### DISPOSITION VOCABULARY — `DELETE` alone conflates function with form

```
KEEP         function AND current abstraction are kernel-optimal
REDESIGN     function survives; current abstraction does NOT
MOVE         function survives under a DIFFERENT semantic owner
INTERNALIZE  function survives but is not a PUBLIC capability
DELETE       the FUNCTION itself is unnecessary
UNPROVEN     function or ownership has not earned survival
```

`REDESIGN` is the one that was missing, and it is where most legacy lands:
a capability can be valuable while its abstraction is wrong.

0e. **15.0 HARD-CUTOFF RULE. No compatibility surface may preserve an API path,
type decomposition, package dependency, or runtime protocol that the 15.0
architecture has assigned to a different semantic owner. Migration
documentation replaces shims.**

15.0 is the point where the old architecture stops being REPRESENTABLE, not
merely where a preferred API appears alongside it. The test, applied whenever
someone asks "should we keep an alias just in case?":

```
Does keeping it allow consumers to continue expressing the old architecture?

YES -> delete it in 15.0.
NO  -> compatibility may be harmless; evaluate normally.
```

> **Do not preserve an architectural boundary violation just because we can
> write a compatibility shim for it.** In a major, a shim becomes tomorrow's
> compatibility obligation.

Four cutoff tests:

1. **One semantic concept, one public owner.** `SignalTree<T>` survives;
   `ISignalTree` goes private. `NodeAccessor` owns branch semantics; `TreeNode`
   is the `$` structural view. Enhancer identity and capability dependencies
   have separate authorities. No aliases that let consumers keep coding against
   the discarded ontology.
2. **One operation, one canonical protocol.** Enhancers go through `.with()`;
   no `composeEnhancers` escape hatch. State is addressed through `$`; no root
   surface. Cite only protocols this release plan has actually accepted — an
   example here reads as a 15.0 commitment.
3. **The package boundary is PHYSICAL, not documentary.** When
   `@signaltree/authoring` exists: no Angular runtime dependency, no dependency
   back on core, no `core/authoring` compatibility subpath, no workspace-source
   imports, no framework realization primitives masquerading as neutral
   contracts. If something cannot cross cleanly it stays on the realization
   side — do not weaken the boundary to ease migration.
4. **Old grammar must fail at COMPILE/IMPORT time**, not be silently routed:

```
tree.count                  compile error
SignalTreeBase<T>           no export
ISignalTree<T>              no public export
composeEnhancers            no export
@signaltree/core/authoring  no shim once the package extraction lands
provided.has(req) || appliedNames.has(req)   never — two namespaces again
```

The goal for 15.0 is not "new API available". It is: **there is one obvious way
to express each SignalTree concept, and the old architectural divisions are no
longer part of the public language.**

Once `GATE B` freezes, the ontology is FINISHED. Gates C-G prove and ship that
architecture; they must not discover that half of 14.x was left reachable for
convenience.

0f. **DEFECT DISPOSITION. 14.x stays maintained while 15.0 is built. A major
release is not an excuse to leave a known 14.x bug unfixed.**

```
If behavior in 14.x is objectively defective and can be corrected WITHOUT
intentionally breaking the supported 14.x contract
    -> document it and ship it in a 14.x PATCH.

If fixing it requires changing the public contract, removing an API path, or
enforcing the new architectural division
    -> it belongs to 15.0.
```

Every finding gets exactly one of three dispositions:

| disposition                   | meaning                                                                                                                                                                                      |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **14.x DEFECT -> PATCH**      | incorrect implementation or documentation under the EXISTING 14.x contract. Fix on the 14.x line, document, patch-release, and ensure 15.0 inherits the correction.                          |
| **15.0 BREAKING CORRECTION**  | 14.x publicly promised or permitted the wrong thing; correcting it necessarily changes consumer-visible semantics. Document the defect against 14.x; the contract change lands only in 15.0. |
| **15.0 ARCHITECTURAL CUTOFF** | not necessarily a 14.x bug — a supported old design deliberately removed or reassigned in the major.                                                                                         |

Each 14.x defect needs a record carrying:

```
Affected versions        Impact
Observed behavior        Workaround, if any
Expected behavior        Patch disposition / target version
Regression test added    15.0 disposition
```

**STANDING GATE-B REQUIREMENT.** Before `GATE B` freezes, review every
`KNOWN DEFECT`, `TRANSITIONAL` marker, and audit-discovered inconsistency and
classify it explicitly. **No defect may disappear into the major-release ledger
without a 14.x disposition.** Expect this to bite hardest during the built-in
enhancer migration, where runtime behaviour is most likely to disagree with
documented 14.x semantics.

1. Characterize before fixing.
2. Do not reopen frozen semantics without a failing falsifier.
3. Never optimize a green path because timing merely looks high.
4. One conceptual change per commit.
5. Run focused validation first, authoritative ladder before commit.
6. Never include unrelated dirt.
7. Update this ledger after every checkpoint commit.
8. Stop and reassess after every phase gate.

## Gate Model

- `GATE A — Kernel freeze`
  persistence + heterogeneous atomicity + antagonistic audit green

  ```text
  ✅ persistence ordering (stored + persistence/autoSave)
  ✅ heterogeneous observational atomicity
  ✅ antagonistic persistence audit — 3 blockers found and closed
  ✅ framework-neutrality invariant, gated in CI
  ✅ no demonstrated current-HEAD kernel blocker
  ⚠  pre-existing bundle budget debt — NOT a kernel blocker
  ```

  GATE A freezes semantics, physical correctness, atomicity and architecture. A
  stale-or-red packaging budget is a different failure class and does not hold
  the kernel unfrozen. This is NOT permission to ship red: the budget must be
  green before `1.0.0-rc.1`, because a release gate that is red at RC means
  nothing. It moves to `GATE C`/`GATE D`:

  - establish a trustworthy current bundle baseline;
  - decide whether the budgets are stale or the implementation is oversized
    (`AGENTS.md` still claims bare 5.46KB/5.8 budget; the tool says 9.26/5.9 —
    at least one is wrong);
  - either reduce static reachability or deliberately reset justified budgets;
  - green before RC.

  Do not optimize bundle size during kernel freeze.

- `GATE B — API freeze`
  public exports/types/features intentionally selected
- `GATE C — Package proof`
  npm-packed artifacts install in clean TS + Angular consumers
- `GATE D — Release quality`
  compatibility, lifecycle, errors, docs, examples, metadata green
- `GATE E — Automation`
  clean checkout can test/build/package/publish without manual surgery
- `GATE F — RC`
  published RC installs and runs from npm in external projects
- `GATE G — 1.0`
  RC issues resolved, API frozen, final clean-clone release gate green

## Phase 1 — Kernel Completion

- [x] `stored()` consequence ordering
- [x] heterogeneous persistence/atomicity proof — proven on both paths
      (`e74e63d1`), contract stated as observable coherence (`59bed701`)
- [x] fresh HEAD antagonistic audit — 3 blockers demonstrated (`1f94f74a`)
- [x] targeted regression audit of the fix — 2 MORE blockers (`49a8ab34`)
- [ ] fix remaining release-blocking findings — see "Freeze readiness" below
- [x] freeze kernel — FROZEN at `4f7a2169`, invariants under "Current Phase"

Exit condition: `GATE A` — **SATISFIED**

Post-freeze regression work, recorded rather than held (none kernel-blocking;
each belongs to a later gate):

| Case                                                               | Gate                                                                                   |
| ------------------------------------------------------------------ | -------------------------------------------------------------------------------------- |
| undo/redo overlapping an open commit scope                         | next correctness pass — closest to GATE A, expected to follow from the tree-level rule |
| structural (`entityMap`) consequences via the HELD path            | next correctness pass                                                                  |
| `stored()` `debounceMs > 0` / `maxWaitMs` interacting with a hold  | `GATE D` persistence contract                                                          |
| SSR / `storage === null`                                           | `GATE D` SSR decision                                                                  |
| packages other than core                                           | `GATE C` ecosystem verification                                                        |
| a natural (unmocked) port-level refusal                            | next correctness pass                                                                  |
| remove dead exports `hasOpenCommitScope` / `onCommitScopesSettled` | cleanup; `scheduleDurableConsequence` replaced both                                    |
| rename settle outcome `'commit'` → `'flush'`                       | cleanup; settlement is not causal confirmation                                         |

Checkpoint record for this phase:

- latest completed item: `stored()` consequence ordering — **DONE**, decided
  Option A (persistence is post-commit) and applied to both persistence APIs.
- last checkpoint commit: `f0da4dc8`
- last authoritative validation: full ladder green at `367f8678` —
  `nx test core` 1699 passed / 20 skipped / 1 todo / 0 failed,
  `nx build core` clean, `nx lint core` clean.

Commits in this slice:

| Commit     | What                                                         |
| ---------- | ------------------------------------------------------------ |
| `83e241ef` | characterize the pre-decision behavior (falsifier)           |
| `51a98699` | `stored()` post-commit via `internals/commit-consequence.ts` |
| `367f8678` | `persistence()` autoSave post-commit + discard-ordering fix  |
| `f0da4dc8` | kernel framework-neutrality lint gate                        |
| `e74e63d1` | heterogeneous atomicity proof, forward authoring path        |
| `59bed701` | atomicity contract stated as observable coherence            |
| `1f94f74a` | close 3 blockers from the fresh HEAD antagonistic audit      |
| `49a8ab34` | close 2 more blockers from the targeted regression audit     |

### Verification of the new authority — PASSED, one caller fixed

Freeze criterion: _can either persistence surface write while its own tree has
unresolved speculative state?_ **No** — not reproducible by any path, including
the ones that produced the previous six defects.

Properties re-proven by executed probe: bare writes still durable at
`debounceMs: 0` on a settled tree; the gate is tree-local; nothing stranded
after any of the six settle orderings of two overlapping pendings; `authoredSeq`
never skips an operation that should run; `resolveScopeKey` gives one identity
for tree / `$` / registry and never collides across trees; teardown neither
resurrects nor strands. Two `persistence()` enhancers on one tree is impossible
by construction (`signal-tree.ts` throws on duplicate enhancer), so that concern
is moot rather than untested.

**Seventh defect, fixed at `4f7a2169` — outside the new authority.** Both
compensation doors settled `'discard'` from a `finally` that could not tell
"compensation APPLIED" from "compensation REFUSED". A refusal reverses nothing,
so discarding made durable truth disagree with live truth. Pre-existing, not a
regression, and at a different location from the previous six — which is
corroborating evidence the replacement did its job. Outcome now tracks whether
compensation actually applied.

Two lessons worth keeping:

- _"Nothing to reverse" is a rollback that succeeded trivially, not a refusal._
  The first fix treated an empty effect list as un-compensated and flushed a
  `clear()` that had just been rolled back. Only the port THROWING means
  nothing was compensated.
- _A single-character `toContain` on a serialized payload asserts nothing._
  `expect(getItem(key)).toContain('a')` passed against the buggy code because
  `{"__v":1,"data":"v0"}` contains the 'a' in `"data"`. Compare parsed values.

Coverage the verification did NOT reach — carry into later gates, none
kernel-blocking: structural (`entityMap`) consequences under the HELD path;
`stored()` with `debounceMs > 0` / `maxWaitMs` interacting with a hold;
time-travel undo/redo overlapping an open scope; SSR / `storage === null`;
packages other than core; a natural (unmocked) port-level refusal.

Minor cleanup for after freeze: `hasOpenCommitScope` and `onCommitScopesSettled`
now have zero production consumers — `scheduleDurableConsequence` replaced both.
Dead internal exports, kept only by tests.

### RESOLVED — Option A implemented at `ed7b4d02`

The escalation was accepted and the abstraction replaced rather than patched a
fourth time. `scheduleDurableConsequence({claimant, key, run})` is now the only
way a durable consequence reaches storage; `stored()` no longer uses the ambient
write context to determine DURABILITY or commit-ness (it still reads it for the
devtools-replay check at `stored.ts:726`, which is not a durability decision),
and `persistence()` no longer runs its own gate. State 4 in the
table below no longer exists — the authority asks the tree, not the call stack.

**Accepted contract change:** while any transaction on a tree is unsettled, a
bare `stored()` write on that same tree is no longer immediately durable. It is
held and released with the surviving committed truth when the tree settles. A
tree with nothing speculative in flight keeps same-stack durability at
`debounceMs: 0`, and a foreign tree's transaction never delays it.

`authoredSeq` stays — it answers a different question. The scope gate says WHEN
durability may run; the sequence says WHICH operation is still current.

Ladder at `ed7b4d02`: 1714 passed / 20 skipped / 1 todo / 0 failed, build and
lint clean. One final focused verification is running; its single criterion is
"can either persistence surface write while its own tree has unresolved
speculative state?". If provably no, `GATE A` freezes.

### Historical — the escalation that produced the above

Third audit of this boundary. **Sixth defect, same class.** Characterized at
`c110a446` and deliberately NOT patched, per the escalation rule: three rounds of
one subsystem yielding defects is evidence about the design, not the code.

**The defect.** A rollback compensation write is applied through the realization
port with no transaction on the stack, so it cannot be attributed and falls
through to an immediate durable write. With two overlapping pendings — the
designed-for case, since only NESTED transactions are refused — the value it
restores is the OTHER pending's speculative value, durable while that
transaction is still unconfirmed. The two surfaces disagree on the same tree at
the same instant: `persistence()` writes nothing (it gates on
`hasOpenCommitScope`), `stored()` has already written the speculative value.

**Root cause.** `stored()` infers commit-ness from the WRITER'S CALL STACK. The
ambient write context has four distinguishable states; the code collapses them
into two:

|     | Ambient state                                              | Truth             | Today                           |
| --- | ---------------------------------------------------------- | ----------------- | ------------------------------- |
| 1   | no transaction anywhere                                    | committed         | write now ✅                    |
| 2   | inside my tree's transaction                               | speculative       | defer ✅                        |
| 3   | inside a FOREIGN tree's transaction                        | committed for me  | write now ✅ (`1f94f74a`)       |
| 4   | no transaction on the stack, but my tree has an open scope | **NOT committed** | **indistinguishable from 1** ❌ |

State 4 is reachable from the realization port _without any transaction on the
stack_, which is exactly why an ambient-context test cannot see it. Every one of
the six defects has been a path reaching durable storage unable to answer "is
this committed?", and answering "yes" by default. `persistence()` never had the
class only because its timer could not read the write context at all, forcing it
onto the per-tree gate.

**The reassessment.** The mechanism is not too complicated — a registry plus a
gate is small. The problem is that there are TWO ways of answering one question,
and the ambient one is structurally blind to state 4. Unifying on the tree's
scope state DELETES a state from the space rather than adding machinery.

- **Option A — one answer, per-tree scope state (recommended).** Both surfaces
  ask the tree, not the call stack: an unattributable write while the tree has
  an open scope is held and released via `onCommitScopesSettled`. Small in code.
  Preserves the foreign-tree property from `1f94f74a`, since the gate is
  per-tree. **Contract change:** `stored()` stops being durable while any
  transaction on its tree is unsettled, extending the "unsettled transaction
  holds writes indefinitely" trade from `persistence()` to `stored()`.
- **Option B — patch the compensation path.** The fourth local repair to a state
  space that has produced a defect on every inspection. Explicitly what the
  escalation rule exists to prevent.
- **Option C — positive attribution on realization writes.** Have the port mark
  its writes as committed realization. Rejected on inspection: the port does not
  know either — when `p2` rolls back it restores `p1`'s pending value, so only
  the tree's scope state can answer.

### Freeze readiness — NOT yet clean

The stop condition was "freeze if the targeted pass comes back clean." It did
not: it found two more blockers in the same boundary, one of them the SAME wedge
through a second refusal door that `1f94f74a` missed.

Running total on this one surface: **5 blockers across 2 audits.** Every one was
in the commit-consequence / persistence boundary; none touched PositionId,
SubjectId, realization semantics, structural storage, atomicity, or the causal
model. That is the good news — the kernel model is holding and the defects are
consequence-lifecycle and attribution bugs at its edge — but the density is a
signal in itself.

Two things gate the freeze decision:

1. **`49a8ab34` changed the boundary again**, so the second audit's clean
   conclusions are now as stale as the first's were. The delta is small (a
   settle on the plan-refusal path, plus a monotonic authored sequence in
   `stored()`), so a third pass should be scoped to that delta only, not the
   whole boundary.
2. ~~One semantic choice needs review.~~ **DECIDED — keep the flush.**

   **A rollback refusal is not a rollback success, and not a transaction
   abort.** The attempt to REVERSE the transaction failed. SignalTree refused to
   change state, which is the fail-closed principle working. Nothing was
   compensated, so the authored effects are still the live authoritative state
   and their deferred consequences must flush. Discarding them would
   deliberately manufacture `live truth = B, durable truth = A`, which is worse
   — and it makes the crash semantics coherent: if an app means to catch the
   refusal and refetch but dies first, recovery restores the last state
   SignalTree actually considered authoritative.

   The persistence consequence per outcome:

   | Outcome                                         | Physical state                | Persistence consequence                 |
   | ----------------------------------------------- | ----------------------------- | --------------------------------------- |
   | `confirm()`                                     | authored state survives       | **flush**                               |
   | successful `rollback()`                         | authored state compensated    | **discard**                             |
   | thrown callback, compensated                    | baseline restored             | **discard**                             |
   | rollback REFUSED before compensation            | authored state still survives | **flush surviving truth**               |
   | compensation begins then fails catastrophically | catastrophic boundary         | error; never pretend rollback succeeded |

   `abandon()` is NOT added for this release. "Drop this pending causal
   relationship without compensating its physical state" is a real feature with
   its own semantic questions (do those effects persist? what holds until the
   refetch?), not cleanup. Design it deliberately if a genuine use case appears.

   **Terminology debt, deliberately deferred:** the outcome is spelled
   `'commit'`, which risks being read as causal confirmation. `'flush'` /
   `'discard'` describes the persistence consequence more precisely —
   _persistence settlement is not causal confirmation_. Not renamed now: it
   would churn the exact delta the third audit is reviewing. Do it after freeze.

**Audit result (read-only `release-reviewer`, independent context, ran the
ladder itself).** Three blockers demonstrated with executed probes, all now
closed and each proven red as a test before any production change:

1. A refused rollback compensation permanently wedged `persistence()` for the
   tree — `settleCommitScope` was skippable by a fallible step. Now settles in
   a `finally` on all three lifecycle exits.
2. `stored().clear()` was durable immediately inside a transaction and never
   compensated. Now shares the write path's boundary and consequence key.
3. A committed write was DROPPED when made inside a foreign tree's transaction
   callback — ambient attribution absorbed it into a scope that could not
   compensate it. Deferral now requires positive proof of tree ownership.

Blockers 1 and 3 were regressions from `51a98699`. 1 and 3 compound: a wedged
tree loses `persistence()` while `stored()` keeps working, so an app using both
loses half its durable state silently.

Explicitly cleared by the audit, not merely unexamined: the lint gate is real
(static, `import type`, and `export … from` all error; dynamic `import()` is an
uncaught base-rule limitation with zero occurrences in HEAD); WeakMap retention
in `commit-consequence.ts` forms a proper ephemeron cycle and is collectible;
`hasOpenCommitScope` keys on the base tree that every enhancer in a chain
receives; `e74e63d1`'s atomicity proof is non-vacuous.

**DECIDED — Option A, observational atomicity is the contract.** A successful
heterogeneous transaction advances **two** physical revisions (the scalar and
structural substrates each commit their own frame), and that is fine: a `'**'`
subscriber capturing the whole tree on every notification never observes
`count` advanced without the row, nor the row without `count`. The invariant is
amended above; no code change. The scalar/structural substrate is NOT to be
redesigned merely to collapse revision increments.

Unifying the two frames into a single `CommittedFrame` remains available as
kernel-internal evolution — the natural place to design it deliberately is
during kernel extraction, not by contorting the current substrate before freeze.

Note: `TODO.md` §1 still carries the superseded "success advances one physical
revision" wording. Left alone because `TODO.md` is currently dirty with
unrelated user work; this file is the controller and supersedes it.

Semantics now enforced — "persistence observes committed physical truth, never
speculative authored state", worded to survive every path rather than keying on
`confirm()`:

| Path                      | Durable consequence                                              |
| ------------------------- | ---------------------------------------------------------------- |
| bare `set()`              | immediate; commits in its own stack, `debounceMs: 0` unchanged   |
| successful transaction    | one coherent write per key, final values only                    |
| thrown / rolled back      | zero speculative writes — never wrote, not wrote-then-repaired   |
| undo / redo / realization | non-authoring, but the result IS committed truth, so it persists |

- newly discovered work:
  - **AUDIT ITEM CLEARED: nothing equates a semantic transaction with one
    physical revision increment.** Every production consumer of `revision()`
    enumerated: `tree-scalar-slot-angular-runtime.ts:172` and
    `tree-scalar-slot-runtime.ts:123` (delegation), two `atomic-state/*`
    prototypes, and `tree-realization-adapter.ts:560`/`:771`. Only the last is
    a comparison, and it is a staleness guard inside a single realization
    ("Heterogeneous realization base revision is stale."), not a transaction
    identity. It compares the SAME counter: `tree-scalar-slot-angular-runtime.ts:139`
    builds the kernel from the `physicalCommitClock`, and the neutral runtime's
    `revision()` returns `physicalCommitClock?.revision() ?? revision`. Nothing
    treats revision as a turn id. Turn identity and physical revision are
    already properly distinct.
  - **The RESTORE path already implements the unified-frame pattern.**
    `tree-realization-adapter.ts:766-800` commits the scalar frame with
    `advanceRevision: false`, every structural plan with
    `advancePhysicalRevision: false`, then advances the clock exactly ONCE and
    publishes. So heterogeneous realization is already one revision; only the
    forward authoring path is two. This is the strongest argument that the
    future `CommittedChangeSet` envelope needs no new machinery — the forward
    path would adopt a mechanism the kernel already contains. Post-freeze work;
    recorded under Kernel Extraction Prerequisites.
  - **DECIDED: the bundle budget does not block `GATE A`.** Proven unrelated to
    this kernel slice (0.000KB attributable), so it is release debt carried to
    `GATE C`/`GATE D` and mandatory before RC. Full reasoning under the Gate
    Model above. Detail:
  - **Bundle budget is red, PRE-EXISTING.** `signaltree-bare` measures 9.26KB
    prod gzip against a 5.9KB budget (also `-entities` 20.05/9.75,
    `-form` 11.47/8). Attributed by esbuild stub-substitution: this slice
    contributes **0.000KB** — the bare bundle is byte-identical with and without
    `commit-consequence.ts`. Release debt, not a regression. Note `AGENTS.md`
    still claims bare is 5.46KB against a 5.8 budget; both numbers are stale.
  - **Kernel neutrality is real but not fully gated.** The 23 non-spec files in
    `lib/physical/` + `lib/internals/causal-runtime/` have zero direct
    `@angular` imports and are now gated. Transitive coupling remains:
    `causal-runtime/tree-realization-adapter.ts` imports
    `../tree-scalar-slot-angular-runtime`, whose `TreeScalarSlotRuntime` exposes
    `WritableSignal` where the neutral `tree-scalar-slot-runtime.ts` exposes
    `SlotIndex`. Migrating the adapter to the neutral interface is Phase 2+
    work — it is kernel-structural and must not reopen the freeze.
    (`../owned-mutation` is by contrast a clean split: the adapter uses only the
    metadata getters; `untracked()` is confined to `runOwnedMutation`.)
  - **`stored()` multi-key writes are post-commit but not atomic.** `Storage`
    has no multi-key atomic write, so N stored keys remain N `setItem` calls.
    Every observable value is a committed one, but the sequence is observable.
    `persistence()` (whole tree, single key) is genuinely atomic. Pinned as a
    RECORDED LIMIT in `stored-commit-ordering.spec.ts`.
  - **An unsettled transaction holds `autoSave` indefinitely** — deliberate, and
    documented at the call site. An unresolved optimistic mutation has no
    committed truth to persist.
  - `AGENTS.md:231` lists the nested sub-skills as
    `{ng-forms,enterprise,guardrails,events,realtime}`. `docs/skills/using-signaltree/`
    actually holds `ng-forms, guardrails, events, realtime, schema` — `enterprise`
    was removed in 14.0.0 and `schema` is missing from the list. Not release-blocking;
    left alone because `AGENTS.md` is currently dirty with unrelated user work.

## Post-Freeze — Kernel Extraction Prerequisites

Not Phase 1. Recorded here so the sequencing is not lost: these are the real
prerequisites for an honest `@signaltree/kernel`, and none of them may reopen
the kernel before `GATE A`.

- [ ] **Migrate the realization port to the neutral physical interface.** This
      is the actual blocker, not moving files.
      `causal-runtime/tree-realization-adapter.ts` consumes the
      `TreeScalarSlotRuntime` from `internals/tree-scalar-slot-angular-runtime.ts`,
      whose surface is Angular-shaped (`createLeaf`/`resolveScalarLeaf` return
      `WritableSignal<T>`). The neutral `internals/tree-scalar-slot-runtime.ts`
      already exposes the physical equivalent (`createSlot`/`readSlot`/
      `commitSlot`/`updateSlot` over `SlotIndex`). Until the adapter is migrated,
      any extracted kernel is framework-neutral in name only.
- [ ] **Give the publication boundary a unified commit envelope**, so an adapter
      receives one coherent published change set regardless of how many private
      substrate commits occurred:

      ```ts
      interface CommittedChangeSet {
        transactionId?: TransactionId;
        revisionFrom: number;
        revisionTo: number;
        changedSlots: readonly SlotIndex[];
        structuralChanges: readonly StructuralDelta[];
      }
      ```

      This needs less new machinery than it looks: the RESTORE path already does
      exactly this (`tree-realization-adapter.ts:766-800` — every substrate
      commits with advance suppressed, then ONE `physicalCommitClock.advance()`,
      then publish). The forward authoring path would adopt the mechanism that
      already exists rather than inventing one. Design it during the
      framework-neutral interface migration — it is the natural shape for a
      multi-framework adapter, and it must NOT be attempted before freeze.

- [ ] Split the metadata getters out of `internals/owned-mutation.ts`. Cheap:
      the adapter uses only `getOwnedOwnerPath`/`getOwnedPositionIds`, while
      `untracked()` is confined to `runOwnedMutation`, which the adapter never
      calls.
- [ ] Extend the neutrality lint gate from direct `@angular` imports to the
      adapter module itself, once the two items above make it pass.
- [ ] Only then decide whether `packages/kernel/` exists, and whether it is
      private or published. Package identity is the last step, not the first.

## Phase 2 — Public Release Surface

- [x] inventory public packages — `6e7bf16a`, baseline `tools/api-baseline.json`
- [x] delete unearned companion packages — `a4bc5493` removed `guardrails`,
      `a0cf4f34` removed live `enterprise` / `callable-syntax` remnants, and
      `7335ed88` removed nonexistent `schema` from package lists;
      `048c5132` removed `realtime`
- [x] **PACKAGE TOPOLOGY DECISION** (below) — closed by `f4de79a9`, `3065bc65`,
      `5f3dcd8a`, and the private-kernel decision recorded here
- [x] freeze exports — `5f1c96e0`; `node tools/api-inventory.mjs --check`,
      `node tools/check-demo-coverage.mjs`, `node tools/verify-tarball-consumer.mjs`
- [x] public TypeScript tests — `npm run typecheck:typing`,
      `node tools/verify-consumer-typecheck.mjs`
- [x] compatibility matrix — `node tools/check-angular-compat.mjs`,
      `node tools/verify-tarball-consumer.mjs`, `node tools/verify-consumer-typecheck.mjs`
- [x] freeze public API — `GATE B` satisfied after `5f1c96e0`, `f4de79a9`,
      `1ce22bd4`, `3065bc65`, `5f3dcd8a`

Exit condition: `GATE B` — **SATISFIED AGAIN** (`cf008545` / `b957f604`)

Reopened by deterministic RC surface evidence at `7c182798` / `ca8f6006`:
`@signaltree/core` still publicly exports symbols whose disposition is DELETE,
NOT EARNED, LC/mechanically retained, or unresolved. This is a public-surface
gate failure, not a new release-time product decision. Settled negatives default
to absence. The executable gate is `node tools/check-rc-public-dispositions.mjs`.

Reclosed after public-surface removals through `18fe5781`, reviewer blocker fix
`08b8fae5`, and stale warning cleanup `b957f604`. Validation: `node
tools/check-rc-public-dispositions.mjs`, `node scripts/lint-readme-apis.mjs`,
`node tools/check-doc-links.mjs`, `node tools/verify-tarball-consumer.mjs`,
`npm run typecheck:source`, `npm run typecheck:typing`, `pnpm nx test core
--skip-nx-cache --output-style=static`, `pnpm nx build demo
--configuration=production --skip-nx-cache --output-style=static`, `node
tools/verify-consumer-typecheck.mjs`, and `node tools/verify-angular-consumer.mjs`.

### Historical measured public surface (`6e7bf16a`, checker-resolved, not regex)

| Package    | Total | Runtime | Type-only | **Angular in public TYPE** | Angular in decl | Internal-decl leaks |
| ---------- | ----: | ------: | --------: | -------------------------: | --------------: | ------------------: |
| `core`     |   209 |      84 |       125 |                      **3** |             169 |              **17** |
| `events`   |   116 |      63 |        53 |                      **0** |              11 |                   0 |
| `ng-forms` |    34 |      15 |        19 |                      **3** |              26 |                   0 |

`guardrails`, `schema`, `enterprise`, `callable-syntax`, and `realtime` are
deleted from the 15.0 live release surface. The 6e7bf16a inventory remains
historical evidence only where it explains why those packages did not earn
survival.

The table above is the Phase 2 starting point, not current HEAD. Since that
inventory, `./authoring` has been removed from `@signaltree/core`, root demo
coverage is green at 27/27, and the package currently publishes only `.`,
`./security`, `./lazy`, `./edit-session`, and `./storage`.

**The headline finding: core's CONTRACT is already framework-neutral.** Only 3 of
209 symbols expose an Angular type publicly — `linked`, `trackHistory`,
`toWritableSignal` — even though 169 declaring files import Angular internally.
Framework coupling is an implementation fact, not an API fact. A kernel
extraction therefore does not require a large public API change, which is a
materially stronger position than the file counts suggested.

### Emitted-entrypoint dependency analysis (runtime truth)

Transitive external imports of each BUILT entrypoint. This is the question that
settles a peer dependency; `angularInType` does not, and the tool docblock has
been corrected to say so.

| Entrypoint                          | Emitted external imports                                                         |
| ----------------------------------- | -------------------------------------------------------------------------------- |
| `core` `.`                          | `@angular/core`, `@angular/core/rxjs-interop`, `rxjs`, `rxjs/operators`, `tslib` |
| `core/lazy`, `core/edit-session`    | `@angular/core`                                                                  |
| **`core/security`, `core/storage`** | **(none)**                                                                       |
| **`events` `.`**                    | **`zod` only — no Angular, no Nest, no rxjs**                                    |
| `events/angular`                    | `@angular/core`, `@angular/core/rxjs-interop`, `rxjs`, `rxjs/webSocket`, `tslib` |
| `events/nestjs`                     | `@nestjs/common`, `bullmq`, `tslib`                                              |
| `events/testing`                    | (none)                                                                           |
| `ng-forms` `.`                      | `@angular/core`, `@angular/forms`, `@signaltree/core`, `rxjs`                    |
| `ng-forms/audit`                    | `@signaltree/core` only — confirms it is a pure re-export                        |

**This corrects an earlier claim of mine.** `schema` and `guardrails` are no
longer package-topology inputs. Their existence was current-form evidence, not a
reason to preserve a package or SDK boundary. `realtime` joined them in
`048c5132`: external synchronization did not earn package survival.

`events` is the genuine success: its root emits only `zod`, with Angular
confined to `./angular` and Nest/bullmq to `./nestjs`. That is the shape the
others should reach — and it argues for `peerDependenciesMeta.optional` rather
than deleting peers, since npm peers are package-scoped, not subpath-scoped.

Two anomalies to verify at `GATE C`, not now:

- `realtime` declares `@supabase/supabase-js` as a peer, but no emitted `.js`
  references it — only the `.d.ts`, README and package.json. Either a
  type-only dependency mis-declared as a runtime peer, or dead weight.
- A `${path}` template-literal specifier appeared while scanning `realtime`.
  Probably my scanner matching a dynamic import inside a template literal;
  needs confirming before anyone treats it as a defect.

### PACKAGE TOPOLOGY DECISION — required before the export freeze

Freezing 209 core symbols before deciding the topology risks discovering that
some belong elsewhere and having to redo `GATE B`. Four questions:

1. **Root internal declarations — CLOSED.** `ProcessDerived`, `DeepMergeTree`,
   `DerivedFactory`, and `SignalTreePlanBuilder` were removed from the root
   public barrel. `derivedFrom`, `WithDerived`, and `SignalTreeBuilder` remain
   because they have current app/docs usage for external derived definitions and
   store helpers. The `./authoring` internal-leak class was closed by deleting
   the subpath in `f4de79a9`.
2. **`ng-forms` audit/export topology — CLOSED.** The current package manifest
   publishes only `.`, with no `./audit` subpath. `ng-forms` now uses an
   explicit public barrel instead of `export *`, so core owns audit and forms
   owns only its Angular forms API.
3. **`events` peer topology — CLOSED.** Root remains framework-neutral and emits
   `zod` only. Framework-specific dependencies are package-scoped optional peers
   because npm cannot scope peers per subpath; install only the peers for the
   subpaths used.
4. **`@signaltree/kernel` package identity — CLOSED for 15.0.** No published
   kernel package. Keep the kernel boundary private until the neutral port
   prerequisites are complete; package identity is the last step, not the first.

### `@signaltree/authoring` — STOPPED. Package/form is UNPROVEN.

**Corrected after peer review and package deletion commits.** The split below is
retained as evidence about neutral declarations, not as an architectural
conclusion. A set of framework-neutral contracts may be needed by independently
surviving external implementers, but the package/form `@signaltree/authoring`
does not inherit survival from current `core/authoring`, marker processors,
enhancers, guardrails, or extraction convenience.

Current rule:

```text
Specific external implementer need first.
Shared neutral contract only after multiple surviving needs converge.
Package name and public SDK form last.
```

So the next action is **not** "create `@signaltree/authoring`". The next action
is to derive or delete each external implementer need independently.

### Historical `@signaltree/authoring` split notes — evidence only

**Decision reversed: the split happens in this major.** 15.0 is already the
breaking release; keeping `@signaltree/core/authoring` now and moving it later
would manufacture a second migration. The failed dependency check below changed
the SEQUENCE, not the destination — the prerequisites land before `GATE B`.

**GATE A stays frozen throughout.** Implementation and package refactoring are
allowed; frozen semantics are not. Stop if the split can only be achieved by
changing a GATE A invariant or redesigning marker semantics.

#### What the marker analysis proved

The problem is **file/package co-location, not semantic entanglement.** The
neutral model already exists:

```text
authorship factory  ->  plain descriptor { [X_MARKER]: true, config }
                            ->  materializer
                                    ->  framework create*Signal realization
```

Every Angular primitive in all five marker modules is inside the `create*Signal`
REALIZATION function. Zero are in the authorship factories, which return inert
objects.

| Module         | Angular primitives                    | Location                         | Authorship |
| -------------- | ------------------------------------- | -------------------------------- | ---------- |
| `form`         | `signal`×6, `computed`×9              | all in `createFormSignal`        | inert      |
| `status`       | `signal`×2, `computed`×6              | all in `createStatusSignal`      | inert      |
| `stored`       | `signal`×1, `untracked`×2             | all in `createStoredSignal`      | inert      |
| `async-query`  | `signal`×4, `untracked`×1, `effect`×1 | all in `createAsyncQuerySignal`  | inert      |
| `async-source` | `signal`×3                            | all in `createAsyncSourceSignal` | inert      |

So `@signaltree/authoring` needs no new abstraction — it needs the existing
separation made physical. The `create*Signal` functions are Angular REALIZATIONS,
not SDK contracts, and belong with the adapter in core.

Measurement note: count generic calls with `signal\s*[<(]`, not `signal(`.
`signal<T>(` does not contain `signal(`, which under-reported `stored` as having
zero uses.

#### FROZEN refactor constraint for these splits

> Marker descriptors own configuration and semantic intent. Framework
> realization owns reactive observation state. Neither becomes a second source
> of authoritative SignalTree truth.

That protects the frozen identity/authority model while files move. Do not solve
Angular removal by relocating mutable state into an ambient registry.

#### Canonical split shape — establish with `async-source`, then conform

```text
markers/async-source.ts           neutral: descriptor, guard, marker symbol, config types
markers/async-source.angular.ts   Angular: createAsyncSourceSignal + signal(...)
```

The suffix matters less than making the direction obvious. **Do not invent five
slightly different patterns** — `async-source` sets the structure and the other
four conform.

#### Pin these four on every split

1. **Public semantics unchanged** — same marker object shape, same identity
   symbol, same config semantics.
2. **Realization behavior unchanged** — existing core tests exercise the same
   Angular implementation after relocation.
3. **Dependency direction improves** — the neutral descriptor must NOT import
   the realization module; realization may import the descriptor.
4. **API symbol set unchanged** — until the final package move this must appear
   as declaration-location movement, which `tools/api-inventory.mjs --check`
   now reports separately from a contract change.

#### The package-boundary falsifier

Not "the Angular import disappeared from the neutral file", but:

> Can the descriptor module be imported in a process with **no Angular
> installed** and still construct, inspect, and type the marker?

**Prove it with an isolated consumer, not a grep.** Build a throwaway fixture
where `@angular/core` is genuinely unresolvable — a temp project outside the
workspace, or an esbuild/tsc run with Angular aliased to a failing stub — then
import the descriptor module, construct a marker, run its guard, and type-check
against its config. Grepping imports proves the file does not name Angular; it
does not prove the module's transitive closure can load without it. Every proxy
measurement in this release that drove a decision was materially wrong at least
once (see the standing rule below), and this is the decision the whole package
boundary rests on.

Success criterion for the first slice:

```text
Neutral descriptor closure     Angular runtime imports  = 0
                               core-internals reachback = 0
Angular realization            behavior unchanged
                               same marker identity/config semantics
                               same public symbol set
```

**If any symbol appears or disappears during `async-source`, STOP and understand
why before continuing.** The first split must be pure declaration-location
movement; a symbol-set change there means the seam is not where the analysis
said it was.

#### Order — deliberately not by marker name

```text
1. async-source   349 lines, 3 calls — simplest realization seam, sets the pattern
2. stored         richer: persistence consequences + untracked
3. status
4. form
5. async-query    LAST — effect() adds lifecycle deserving more scrutiny
```

After `async-source`, do `stored` NEXT rather than sweeping the rest: if both a
simple case and a consequence-bearing case split with no semantic drift, the
remaining three become safely mechanical.

#### Create the package only when this is true

```text
proposed @signaltree/authoring closure
    Angular runtime imports:      0
    core internals reach-through: 0
```

**Do not create the package halfway through the five splits.**

#### Recorded, NOT to be solved during the splits

Adapter registration (`installMaterializationRealization`, `064f19ab`) is
module-load and currently "last adapter imported wins". Fine for a single
Angular-facing core; it matters when a second adapter becomes viable. Desired
rule when that day comes:

```text
same adapter installed twice     -> idempotent
different incompatible adapter   -> deterministic failure
```

Release debt. Do not derail a split to fix it unless a split directly requires it.

#### Closure proof — measured, 38 of 46 already neutral

All five splits are done. Bundling the `authoring.ts` entrypoint with Angular
external and tree-shaking on, then inspecting what the OUTPUT retains:

| Class                      |     n | Detail                                                                                                                                                                |
| -------------------------- | ----: | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Type-only                  |     9 | Cannot retain a runtime dep by construction                                                                                                                           |
| Value, neutral             |    29 | `registerMarkerProcessor`, every guard and marker symbol, all 8 `*_READERS`, `onHydrateDecision`, `onTreeError`, `getPathNotifier`, write-context, enhancer authoring |
| **Value, retains Angular** | **8** | below                                                                                                                                                                 |

Seven of the eight are symbols ALREADY slated to leave authoring:

```text
createFormSignal, createAsyncSourceSignal, createAsyncQuerySignal
    Angular realizations -> core, not the SDK

composeEnhancers, isAnySignal, isNodeAccessor, isTraversableNode
    ordinary-user utilities from utils.ts, already classified as mis-filed
```

**`interceptLeafSignals` is the only genuine SDK symbol still dragging Angular.**
It reaches `../utils` (for `isTraversableNode`) and `./owned-mutation` (which
calls `untracked`). `utils.ts` is genuinely runtime-coupled — `isSignal` x7,
`signal`, `computed` — so this is not a type-only fix.

Two candidate resolutions, to decide next session:

- Extract the purely structural guards from `utils.ts` into a neutral module,
  the same contract pattern. `isTraversableNode` is pure structure and needs
  nothing; `isAnySignal`/`isNodeAccessor` call Angular's `isSignal` and cannot
  follow — but both are ordinary-user API leaving authoring anyway.
- `owned-mutation`'s `untracked` is a realization concern. Either
  `interceptLeafSignals` gains a narrow port like marker materialization did
  (`064f19ab`), or it is accepted as an Angular-side SDK piece and stays in core.

MEASUREMENT NOTE, Rule 0 again. The first attempt reported ALL 46 symbols as
framework-dragging, including ones known neutral. It was measuring module-graph
TRAVERSAL, not RETAINED closure — importing any name from a barrel walks the
whole barrel regardless of tree-shaking. Only the output-inspection version
measures the property that governs the decision. Caught because the result was
implausible, not because the method was reviewed.

#### Package move — scoped, NOT started

`9e193a7f` closed the last neutrality blocker. The SDK surface is proven neutral;
what remains is a physical migration.

**Retained closure of the proposed SDK: 23 modules, zero Angular in output.**
Measured with esbuild's metafile (bytes contributed), not module traversal:

```text
path-notifier (12.7KB)  intercept-leaf-signals  materialize-markers
constants               enhancers/index         owned-metadata
visit-tree              readonly                node-shape
types (252B runtime)    write-context           causal-write-mode
error-reporter          materialization-realization
production-substrate-stats
5 marker contracts      markers/derived         shared/lib/constants
```

NOT retained, despite appearing in a traversal measurement: `utils`,
`entity-signal`, `entity-map`, all of `physical/*`, the three marker
realizations, and most of `shared`.

**This settles the dependency direction, and it is the harder answer.** Core
needs `path-notifier`, `materialize-markers`, `write-context`, `types` and
`constants` centrally, so they cannot simply leave core. Since
`@signaltree/authoring` must NOT depend on core, the direction must be:

```text
@signaltree/authoring   owns the 23-module neutral closure
        ^
@signaltree/core        imports it
```

That is a real physical migration of ~22 core modules plus one shared module,
with circular-import risk, not a re-export shuffle. Scoped here so it can start
cold rather than be discovered mid-move.

Constraints already decided, do not relitigate:

- No `@signaltree/core` peer on authoring, not even for convenience. If the
  manifest ends up with one, stop and find out why.
- Move public CAPABILITY, not internal substrate. `OWNED_NODE_METADATA` and the
  other newly extracted internals stay private unless extension authors need
  them in the supported contract.
- No `@signaltree/core/authoring` forwarding shim. 15.0 is the breaking reset;
  a forwarding path has to be supported for all of 15.x and invites continued
  use. The migration guide carries the one-line import change instead.
- Packed-artifact proof before `GATE B`: pack the tarball, install it in a temp
  consumer OUTSIDE the workspace with no Angular installed and no tsconfig path
  aliases, import every runtime export, typecheck the type exports, and grep the
  tarball for `packages/core/src`, `../core`, `@angular/core`,
  `@signaltree/core/authoring`, `workspace:*`.

#### THREE closures, not one — measure all three before `git mv`

The 23-module result is the RETAINED RUNTIME closure. It is **not** yet the
package-migration closure. Three separate properties govern this move, and
esbuild answers only the first:

```text
1. RETAINED RUNTIME CLOSURE      esbuild metafile bytesInOutput
                                 -> MEASURED: 23 modules, 0 Angular

2. DECLARATION / TYPE CLOSURE    tsc declaration emit + resolution
                                 -> NOT YET MEASURED. What must exist for
                                    authoring's .d.ts to stand alone without
                                    reaching into @signaltree/core?

3. NATIVE MODULE-LOAD CLOSURE    built ESM imported with NO bundler
                                 -> NOT YET MEASURED. Does importing the
                                    package root make Node evaluate Angular or
                                    a core-only module?
```

**(2) is the one to worry about.** esbuild correctly erases type-only
dependencies, so they contribute zero bytes and vanish from the runtime
measurement — but `GATE B` freezes a TYPESCRIPT API, so a declaration
dependency on core is just as disqualifying as a runtime one. Do not engrave
"22 core modules + 1 shared module" as the physical move count until declaration
emit agrees.

And measure the EMITTED declaration specifiers, not TypeScript's source graph —
a fourth member of the same Rule 0 family:

```text
compiler source resolution   !=   shipped declaration resolution
```

A type can resolve perfectly inside the monorepo while the generated `.d.ts`
still carries an import path that is invalid once packed, or that reaches back
into core. The property that actually governs `GATE B` is:

```text
packed @signaltree/authoring .d.ts
        resolves using only itself + legitimate neutral dependencies
        never @signaltree/core
        never workspace-relative source paths
```

Read the emitted `.d.ts` files. Do not infer them from `tsc` succeeding.

#### First cold-session task: graph, not `git mv`

```text
candidate modules -> runtime edges + type/declaration edges
                  -> strongly connected components
                  -> topological migration order
```

Two stop conditions fall out of it:

- a candidate authoring `.d.ts` that references `@signaltree/core` -> STOP;
- a runtime SCC spanning a neutral-authoring module and an Angular/core-only
  module -> STOP and split that SCC first.

This is a MEASUREMENT exercise. It is not permission to reopen the authoring
architecture; do that only if one of these produces a real cross-boundary
dependency.

#### Migrate SCC-by-SCC, never 23 files at once

Establish the package, then move leaf groups upward in dependency order, keeping
BOTH packages building after each coherent slice. Let the SCC graph decide the
order, not the file names. The invariant after every slice:

```text
authoring -> NEVER core
core      -> MAY authoring
```

No temporary reverse edge "just until the move is finished". Those are exactly
the edges that survive migrations.

#### Two ownership maps — do not collapse them

`core -> authoring` being the right dependency direction does NOT mean every
module in the closure becomes public SDK API:

```text
PHYSICAL ownership   authoring may own 20+ implementation modules
PUBLIC   ownership   authoring EXPORTS only the ~38 supported capabilities
```

`owned-metadata`, the materialization machinery and any storage objects live
inside the package while staying package-private. The extraction at `9e193a7f`
deliberately preserved that line; the migration must not quietly erase it.

#### Packed proof covers three different things

```text
pack -> temp project OUTSIDE the workspace, no Angular installed,
        no workspace path aliases, install the tarball

node import('@signaltree/authoring')   proves MODULE LOADING
tsc consumer.ts --noEmit               proves DECLARATIONS
bundle representative imports          proves TREE-SHAKING
```

Native import matters on its own: a bundler can tree-shake something Node's ESM
loader would still evaluate.

**MEASUREMENT WARNING — this error was made TWICE in one session.** Module-graph
TRAVERSAL is not RETAINED closure. `onLoad`/`onResolve` fire during graph
construction, before tree-shaking; only the metafile's `bytesInOutput` (or
inspecting the bundled output) reports what survives. The traversal reading
scoped this migration at 45 modules against a true 23, and earlier reported all
46 authoring exports as framework-dragging when 38 were clean. Both times an
implausible result caught it, not the method. Use the metafile.

#### Declaration preflight — MEASURED, classified, decision taken

Measurement B is done. Runtime and declaration closures disagree, exactly as
predicted:

```text
retained RUNTIME closure       23 modules, 0 Angular, 0 core
shipped DECLARATION closure    29 files,  11 import @angular/core, 0 core
```

Neither closure depends on `@signaltree/core`. The architecture is NOT reopened:
the implementation boundary is right, the DECLARATION ownership is wrong.

**Symbol-level classification of all 46 authoring exports** (TypeScript parser,
not grep — a regex first reported four false `@signaltree/core` dependencies by
matching JSDoc `import` examples as code):

| Bucket                         |   n | Meaning                                                                                                    |
| ------------------------------ | --: | ---------------------------------------------------------------------------------------------------------- |
| 1 — declaration co-location    |  28 | Neutral declarations sharing a `.d.ts` with Angular-typed ones                                             |
| 2 — already leaving authoring  |   5 | `createFormSignal`, `createAsyncSourceSignal`, `createAsyncQuerySignal`, `composeEnhancers`, `isAnySignal` |
| 3 — genuine Angular-shaped SDK |   1 | `isSignalTree`                                                                                             |

**Bucket 1 has one dominant root cause: `lib/types.d.ts`.** Its Angular import
exists for `ISignalTree` and the leaf types, but `ENHANCER_META` (a Symbol),
`EnhancerMeta` (five plain fields) and `NodeAccessor<T>` (three call signatures
over `T`) need none of it. Eight module groups inherit the edge purely by
co-location: `enhancers/index`, `intercept-leaf-signals`, `materialize-markers`
(via `position-registry`), `node-shape`, `form.contract`, `path-notifier`,
`write-context`. `readonly.d.ts` is the same pattern independently — `import
type` for the `Pick` sources while the eight `*_READERS` are key allowlists.

**DECIDED — `isSignalTree` moves to `@signaltree/core`.** Its runtime is
framework-agnostic, but its predicate narrows to `ISignalTree<T>`, whose public
shape exposes Angular `WritableSignal` leaves. The rule this establishes:

> Runtime neutrality does not make an API authoring-neutral if its supported
> TYPE contract describes the framework realization.

**DECIDED — `isNodeAccessor` stays in authoring.** `NodeAccessor<T>` is neutral;
its Angular edge is co-location in `types.ts`, not intrinsic coupling.

**DECIDED — no Angular peer on `@signaltree/authoring`**, not optional, not
type-only. A non-Angular TypeScript consumer must not need `@angular/core`
installed to typecheck a framework-neutral SDK. `rxjs` is a separate question and
may legitimately remain if it appears in neutral async contracts.

#### Next session — in this order

1. Split the two declaration hotspots, using the pattern already proven five
   times on markers. Extract ONLY the neutral substrate the SDK consumes; do not
   move all of `types.ts`.

   ```text
   types.ts     -> neutral: ENHANCER_META, EnhancerMeta, NodeAccessor, ...
                -> stays:   ISignalTree, leaf/realization-facing types
   readonly.ts  -> neutral: the eight *_READERS allowlists
                -> stays:   Angular-derived source types
   ```

   **Extract the MINIMUM neutral contract.** The goal is the smallest substrate
   the SDK actually consumes — NOT "`types.ts` without the Angular import". If
   the neutral module grows into a shadow copy of core's full type model, the
   split has failed even when the declaration closure reports zero Angular.

   **STOP CONDITION during the split:** if a supposedly neutral declaration
   needs `ISignalTree`, `Signal`, `WritableSignal` or another realization-facing
   type for its ACTUAL PUBLIC SEMANTICS — not merely because it shares a file
   with one — stop and reclassify that symbol into bucket 3. Do not widen the
   neutral substrate to accommodate it. That is the same judgement already made
   for `isSignalTree`, and the same rule applies: runtime neutrality does not
   make an API authoring-neutral if its supported type contract describes the
   framework realization.

2. **Preserve nominal identity.** `ENHANCER_META` is a `Symbol` and must remain
   exactly ONE authoritative runtime instance — extract it, do not duplicate it
   into neutral and core copies with matching names. Same for any brand symbol
   behind `NodeAccessor`: ownership moves to the neutral side and core CONSUMES
   it, consistent with `core -> authoring`.

3. Relocate the five bucket-2 symbols. NOTE: they were moved to `./authoring`
   FROM the root barrel in 14.0.0, so removing them from authoring without
   giving them a home in core deletes them from the public API. This is an API
   move, not an export deletion.

4. Move `isSignalTree` to core.

5. Rerun the parsed emitted-declaration closure. **Required: 0 `@angular/*`,
   0 `@signaltree/core`, 0 `packages/core/src`, 0 core-relative shipped paths.**
   If a genuine authoring declaration still imports Angular, STOP and classify
   before proceeding.

6. FREEZE that result, then and only then compute A (runtime SCCs) and C
   (combined physical closure + topological order). Computing them now would
   bake in declaration edges that steps 1-4 are about to remove.

#### Progress

- [x] Neutralize marker materialization behind a realization port — `064f19ab`.
      `internals/materialize-markers.ts` now imports zero framework code.
- [x] `async-source` split — `af273898` (canonical pattern)
- [x] `stored` split — `6bb04f1d` (consequence-bearing proof)
- [x] `status` split — `7d2e51ca`
- [x] `form` split — `d09407b7` (type-only `HistoryFeature` edge)
- [x] `async-query` split — `3c5521fc` (lifecycle proven realization-side)
- [x] Contract-neutrality gate — `tools/check-contract-neutrality.mjs`, 5/5 pass
- [x] Closure proof run — 38/46 neutral; see the table above
- [x] Readonly reader-key declaration hotspot split — `4f62d082`.
      `authoring.d.ts` now exports `*_READERS` from `./lib/readonly-readers`,
      whose emitted declaration has 0 `@angular/core` imports. Validation:
      `readonly.spec.ts`, `typecheck:source`, `typecheck:typing`, `nx build core`,
      `nx lint core`, emitted declaration inspection.
- [x] Move current-form package pressure out of the decision — `a4bc5493`,
      `a0cf4f34`, `7335ed88`
- [x] Remove `ng-forms` dependency on `@signaltree/core/authoring` — `b6aac5a9`,
      corrected in the follow-up local-guard slice. `ng-forms` now owns its
      tiny structural traversal predicate instead of promoting it to core root;
      validation: `pnpm nx build ng-forms --skip-nx-cache --output-style=static`,
      emitted artifact grep, `npm run typecheck:source`.
- [x] Remove demo pressure for unearned authoring APIs — `58d27090` removed the
      benchmark service dependency on enhancer-order internals, and `e71e758c`
      deleted the reachable custom marker/enhancer authoring page. Validation:
      `pnpm nx build demo --skip-nx-cache --output-style=static`.
- [x] Remove the final app-side `@signaltree/core/authoring` import — `151354dd`
      deleted the What’s New observation-hook demo section. Validation:
      `pnpm nx build demo --skip-nx-cache --output-style=static`; grep confirms
      zero `apps/**` imports of the authoring subpath.
- [x] Remove `plannedSignalTree` from the root public barrel — follow-up slice
      after the product map already classified it as not frozen public API.
      Validation: `pnpm nx build core --skip-nx-cache --output-style=static`,
      `npm run typecheck:source`, `node tools/check-demo-coverage.mjs` now reports
      five remaining root-export questions instead of six.
- [x] Demonstrate `SignalTreeRollbackError` as app-facing error authority —
      handled in the time-travel demo instead of removed. Validation:
      `pnpm nx build demo --skip-nx-cache --output-style=static`,
      `npm run typecheck:source`, `node tools/check-demo-coverage.mjs` now reports
      four remaining root-export questions instead of five.
- [x] Remove async realization factories from the root public barrel —
      `createAsyncSourceSignal` and `createAsyncQuerySignal` are materializers,
      not app-facing marker declarations. Validation: `pnpm nx build core
--skip-nx-cache --output-style=static`, `npm run typecheck:source`,
      `node tools/check-demo-coverage.mjs` now reports two remaining root-export
      questions instead of four.
- [x] Remove remaining undemonstrated structural guards from the root barrel —
      `isAnySignal` and `isSignalTree` had no app/demo/package consumer need.
      Validation: `pnpm nx build core --skip-nx-cache --output-style=static`,
      `npm run typecheck:source`, `node tools/check-demo-coverage.mjs` is green
      at 28/28.
- [x] Remove `@signaltree/core/authoring` from the published package surface —
      no live app/package/tool consumer remained after the previous slices.
      Removed the export map entry, Rollup entrypoint, source entrypoint and the
      obsolete generated API-surface gate that only targeted deleted managed
      docs. Validation: `npm run build:all` command path via static Nx build,
      `pnpm nx build core --skip-nx-cache --output-style=static`,
      `node tools/verify-tarball-consumer.mjs`,
      `node tools/verify-consumer-typecheck.mjs`,
      `node tools/check-declaration-closure.mjs`, `npm run typecheck:source`,
      no built authoring artifacts, root demo coverage green at 27/27.
- [ ] Derive or delete each remaining external implementer need independently
- [ ] Only after convergence, decide whether any shared neutral contract and
      package boundary exists
- [x] Remove `@signaltree/core/authoring` as a 15.0 breaking change — `f4de79a9`
- [x] Regenerate the API baseline deliberately — current measured surface:
      `core 126`, `events 116`, `ng-forms 18`; validation:
      `node tools/api-inventory.mjs && node tools/api-inventory.mjs --check`

### Historical — the dependency check that produced the sequence above

The gate was: _can `@signaltree/authoring` be consumed by a third-party
extension package without importing `@signaltree/core` implementation modules or
Angular?_ **No, on both counts.** Files were NOT moved.

Module-level import graph for the 37 SDK symbols — 14 declaring modules:

| Class                                           | Modules                                                                                                                                                     | Verdict              |
| ----------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- |
| **Runtime-neutral**                             | `internals/error-reporter.ts` (zero imports of any kind), `write-context.ts`, `path-notifier.ts`, `enhancers/index.ts`                                      | could move today     |
| **Type-only Angular** — erasable, not a barrier | `types.ts` (`Signal`, `WritableSignal` as types), `readonly.ts` (`import type`)                                                                             | not blocking         |
| **Runtime Angular**                             | `internals/materialize-markers.ts` (`computed`, `isSignal`), `markers/{form,status,stored,async-query,async-source}.ts` (`signal`, `computed`, `untracked`) | **blocks the split** |

`markers/derived.ts` looked Angular-coupled but its `computed` mention is inside
a JSDoc comment; it has no imports at all.

**The blocker is `registerMarkerProcessor`, the flagship extension API.** It is
declared in `internals/materialize-markers.ts`, which needs Angular's `computed`
and `isSignal` at RUNTIME and additionally reaches into `./physical-commit-clock`
(kernel), `./position-registry`, `../path-notifier` and `../utils`. Moving it
produces exactly the package-shaped dependency leak the check exists to prevent:
a package that is a façade over core internals.

Confirmed against the built artifact rather than inferred — `core/authoring`
emits `@angular/core`, `@angular/core/rxjs-interop`, `rxjs`, `rxjs/operators`.

**Missing neutral port:** a reactive-primitive port (create a computed, detect a
signal) beneath both packages. That is the SAME class of work as the realization
port needing the neutral `SlotIndex` interface, and it is already recorded under
Kernel Extraction Prerequisites. Sequence the authoring split AFTER that
migration, not before it.

The audience argument for the split still holds — 37 of 48 symbols have no
ordinary-app use. The seam is real; it just cuts THROUGH the SDK today rather
than around it, so splitting now would ship the wrong boundary permanently.

### Historical keep / remove / move symbol map — superseded as a plan

**SUPERSEDED BY `a4bc5493`, `a0cf4f34`, `7335ed88`, `048c5132` and peer
review.** The table below is retained only as evidence about how symbols were
classified before the companion-package deletions. It is **not** a plan to
create `@signaltree/authoring`, and it does not establish a generic enhancer,
marker, declaration-lowering or SDK package concept.

Use it only to ask narrower questions:

```text
Does this specific symbol serve a surviving external implementer need?
If yes, what is the smallest neutral contract that need requires?
If multiple independently surviving needs converge, then consider a shared form.
```

Governing rule, applied per symbol rather than per package history:

```text
ordinary app needs it                          -> core
extension/plugin author needs it               -> authoring
framework-specific integration needs it        -> adapter/integration package
nobody outside SignalTree implementation needs it -> stop exporting it
```

**`core/authoring` — 48 symbols.** Earlier text said the seam was clean enough
to justify a split. That conclusion is withdrawn: current-form grouping is not
survival evidence, and package/form remains unproven.

| Class                                                                                                                                               |   n | Disposition                                                                                                                                                  |
| --------------------------------------------------------------------------------------------------------------------------------------------------- | --: | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Extension-looking surface — marker processing, hydrate/error hooks, enhancer composition, write context, path notifier, 4 `create*Signal` factories |  24 | EVIDENCE ONLY. Derive each external implementer need independently; no SDK/package entitlement                                                               |
| Marker introspection — 8 `*_READERS`, 6 `is*Marker`, `*_MARKER` tokens                                                                              |  13 | EVIDENCE ONLY. Co-location does not establish a generic marker/declaration protocol                                                                          |
| General utilities — `composeEnhancers`, `isAnySignal`, `isNodeAccessor`, `isTraversableNode`, `SIGNAL_TREE_CONSTANTS`, `SIGNAL_TREE_MESSAGES`       |   7 | KEEP in core — ordinary-user API mis-filed under authoring                                                                                                   |
| **Private-package leakage** — `isBuiltInObject`, `parsePath`                                                                                        |   2 | **REMOVE.** Declared in `@signaltree/shared`, which is `"private": true`. Publishing them makes a private package's internals part of core's public contract |

37 of 48 looked like extension-author surface with no ordinary-app use. That is
not enough. The corrected conclusion is: these symbols are a queue of possible
external implementer needs, not evidence that an SDK package survives.

**Root's 7 `internals/` exports.** Verify each against docs, examples and typing
specs before cutting; expected dispositions: `derivedFrom` KEEP (user-facing);
`DerivedFactory`, `WithDerived` KEEP or MOVE to authoring; `SignalTreeBuilder`,
`SignalTreePlanBuilder` MOVE to authoring; `ProcessDerived`, `DeepMergeTree`
REMOVE — type machinery public only because inference needed it.

**`ng-forms` audit/export topology — CLOSED.** `ng-forms/audit` no longer exists
in the current package manifest/source, and `ng-forms`' root barrel is explicit
rather than `export *`-based. Core owns audit; `ng-forms` owns Angular forms.
Validation: `pnpm nx build ng-forms --skip-nx-cache --output-style=static`,
`npm run typecheck:source`, `TS_JEST_DISABLE_VER_CHECKER=true pnpm nx test
ng-forms --output-style=static --silent`.

**Historical `realtime` note — superseded by `048c5132`.**

The classification below is retained only as evidence for why `realtime` was
examined. It is not an active package-topology recommendation: external
synchronization did not earn package survival for 15.0, and `@signaltree/realtime`
has been deleted.

Earlier classification:

| Class             |   n | Detail                                              |
| ----------------- | --: | --------------------------------------------------- |
| Provider-neutral  |   9 | The whole root; `RealtimeAdapter` is a genuine seam |
| Supabase-specific |   4 | The whole `./supabase` subpath                      |
| Angular-specific  |   0 | —                                                   |

Earlier conclusion, now withdrawn: keeping the name was plausible only if the
external synchronization package itself survived. It did not.

Recommended topology, pending that decision:

```text
              @signaltree/kernel  (private first)
                      |
              @signaltree/core    (Angular integration + product API)
                      |
   +----------+-------+--------+-----------+
   |          |                |           |
ng-forms   schema?          realtime?   guardrails
(Angular)  (deleted)        (deleted)   (deleted)

events: root neutral, Angular peer scoped to ./angular, Nest to ./nestjs
```

This topology sketch is historical; current live packages after companion
deletions are `core`, `events`, and `ng-forms`, plus private `shared`.

### RESOLVED at `56572c5d` — declaration closure, entity-map instance

`@rollup/plugin-typescript` compiles with `tsconfig.lib.prod.json`, which sets
`stripInternal: true`. `EntityMapComputedSlices`, `EntityMapMarkerWithSlices`, and
`DefaultKey` were referenced by PUBLIC declarations while marked `@internal`, so
their declarations were stripped and every reference to them survived — shipping
a `.d.ts` naming types it does not declare.

**`stripInternal` was functioning exactly as configured. The defect was
classifying declaration dependencies as `@internal` while public signatures
reference them.** The fix is therefore source-contract hygiene — remove the
incorrect classification — NOT disabling `stripInternal`, which remains a
legitimate mechanism for genuinely internal declarations.

| name                        | raw `tsc` | plugin | rolled `dist` | packed | after fix |
| --------------------------- | --------- | ------ | ------------- | ------ | --------- |
| `EntityMapComputedSlices`   | GOOD      | BAD    | BAD           | BAD    | GOOD      |
| `EntityMapMarkerWithSlices` | GOOD      | BAD    | BAD           | BAD    | GOOD      |
| `DefaultKey`                | GOOD      | BAD    | BAD           | BAD    | GOOD      |

Raw emission looked correct only because that probe used a different tsconfig
(`tsconfig.typecheck.json`) with no production stripping. Flipping `stripInternal`
as a single variable in a reproduction of the plugin stage turned every column
GOOD; removing the three tags with `stripInternal` left ON did the same.

CORRECTION — this ledger previously recorded `stripInternal` as RULED OUT. **That
was invalid.** The experiment removed the tags, checked the result with
`grep -c "error TS"` returning 0, and then read a `dist` file that was very likely
stale: it asserted neither build success nor artifact freshness. This is the Rule
0b step-4 failure, and it was already written down as a rule while sitting in this
document as a conclusion — which is exactly how a wrong causal claim survives.
Root-barrel reachability remains correctly ruled out (`DefaultKey` is exported
from its module AND `index.ts:129` and was dropped anyway); do not spend a cycle
widening exports.

A prior in-file fix attempt at `entity-map.ts` exported `DefaultKey` with a
correct diagnosis of the SYMPTOM but left the tag in place, so it did not resolve
the defect.

#### RESOLVED — one cause, two source presentations

`stripInternal` is the single production cause for every instance found. Proven by
toggling ONE variable on the production plugin path and searching the whole output
tree (121 `.d.ts` files):

|                    | `stripInternal: true`        | `stripInternal: false`                      |
| ------------------ | ---------------------------- | ------------------------------------------- |
| `createFormSignal` | declarations 0, references 5 | declarations 1 (`form.d.ts`)                |
| `HydrateMode`      | declarations 0, references 3 | declarations 1 (`materialize-markers.d.ts`) |

It is reached through two SOURCE presentations, not two mechanisms:

| presentation | shape                                                                             | detectable by `getJSDocTags()`? |
| ------------ | --------------------------------------------------------------------------------- | ------------------------------- |
| direct       | the declaration's own leading `@internal`                                         | yes                             |
| orphan       | an EARLIER `@internal` docblock still sitting in the declaration's leading trivia | **NO**                          |

`createFormSignal` is direct (own tag at `form.ts:342`). `HydrateMode` is orphan:
`materialize-markers.ts` closes an `@internal` docblock at line 43, has a banner
comment, opens a fresh docblock at 49, and declares `HydrateMode` at 71 with NO
declaration in between — so the orphaned tag is in its leading trivia.
`ts.getJSDocTags()` on that declaration reports `[none]`.

> **For SignalTree's production TypeScript emit, `getJSDocTags()` is not sufficient
> to predict `stripInternal`.** An orphaned `@internal` block in a declaration's
> leading comment trivia can cause stripping even when the parsed declaration
> reports no `internal` JSDoc tag.

This retroactively explains `DefaultKey`: the earlier in-file fix exported it and
left an orphaned `@internal` above the new docblock, which is why exporting looked
correct and changed nothing.

**THE EARLIER AST SCAN IS INVALIDATED.** It used `getJSDocTags()`, so it measured
attached-JSDoc semantics as a proxy for the emitter's LEXICAL behaviour. Its "3
defects" result understates the true count. Do not patch it with a special case for
`HydrateMode` — replace the measurement.

Two more of my own conclusions were wrong for the recorded reason and are corrected
here: "removing `createFormSignal`'s tag didn't help" (the tag is demonstrably the
cause) and the earlier `isDev` refutation. Both trusted a check never verified
against a fresh artifact. Fourth occurrence of that failure mode this session.

#### The measurement that can CLOSE the declaration chapter

Stop hunting symbols one at a time and stop trying to reimplement TypeScript's rules
for what counts as internal. Run the production declaration emit twice and diff:

```
stripInternal: true   vs   stripInternal: false
        |
        v
anything present ONLY in the `false` output
that is still REFERENCED by the `true` output
        =
broken declaration closure
```

That directly measures the dangerous property and is presentation-agnostic — it
catches ordinary type references, default generic helpers, orphaned comment blocks,
`typeof` value queries, and any fourth syntactic form. A leading-trivia scan is
still useful as a candidate FINDER, never as the oracle.

#### Repairs — deterministic, product intent already frozen

```
createFormSignal   KEEP  -> remove its declaration's own @internal
HydrateMode        KEEP  -> remove the orphaned @internal docblock above it
```

No API redesign, no barrel changes, no `stripInternal` config change. Verify each
INDEPENDENTLY before combining: build exit 0, fresh artifacts, whole-tree
declaration AND reference search, packed declaration, external consumer against the
packed artifact, exact intended public type. For `HydrateMode` prove the emitted
union is exactly `'merge' | 'restore' | 'rehydrate' | 'transfer'` and that the public
hook/event declarations resolve to it. For `createFormSignal` prove the function
SIGNATURE is present, not merely that a re-export mentions the name.

#### FROZEN — do not reopen

```
isDev             KEEP        createFormSignal   KEEP
HydrateMode       KEEP        stripInternal      KEEP ENABLED
re-export chains  NOT causal  barrel widening    NOT a fix
```

The re-export-chain hypothesis was never tested and does not need to be: one
compiler variable explained both cases.

#### Third fixture presentation

Add the orphan presentation to the permanent closure fixture — a regression case for
the bug that defeated source inspection, not a new rule:

```ts
/** @internal */

// banner comment, no declaration in between

/** Public support type. */
export type PublicSupport = 'a' | 'b';
```

Assert the gate detects `PublicSupport` disappearing while a public declaration still
references it. This exercises Rule 0c; it is not a new rule.

`isDev`, `createFormSignal`, and `HydrateMode` are also publicly exported yet
`@internal`. Removing `isDev`'s tag did NOT restore its declaration, so at least
one of these is a DIFFERENT mechanism. `isDev` is `export const isDev = _isDev`,
making the alias target the obvious suspect.

The one question to answer, in an isolated fixture on the SAME production
tsconfig/plugin path — no API changes during the measurement:

> Does `stripInternal` remove a public alias's declaration because the aliased
> implementation symbol is `@internal`, even when the public alias itself is not?

Four minimal forms: exported-`@internal` target with a public alias;
module-local-`@internal` target with a public alias; `@internal` function target
with a public alias; and a plain public value as control. Property measured is
"public alias declaration survives production `.d.ts` emit" — not "the name
appears somewhere". Assert exit 0, fresh artifact, alias declaration count == 1,
and that packed matches rolled.

RESULT — the four-form fixture was run on the production tsconfig/plugin path:

| form | target                         | alias declared? | emitted type                  |
| ---- | ------------------------------ | --------------- | ----------------------------- |
| A    | exported `@internal` const     | YES             | `a = true` (inlined — safe)   |
| B    | module-local `@internal` const | YES             | `b = true` (inlined — safe)   |
| C    | exported `@internal` FUNCTION  | YES             | `c: typeof _c` — **DANGLING** |
| D    | plain public const (control)   | YES             | `d = true`                    |

**The alias-target hypothesis is REFUTED** — `@internal` on an alias target does not
strip the public alias. But the fixture found a second real route anyway: primitive
aliases inline their literal type and are safe, while FUNCTION (and likely
class/object) aliases emit `typeof target`, so the alias survives referencing a
stripped declaration. Visible only because the fixture asserted the emitted TYPE
rather than the name's presence — on a presence-only check all four rows read YES.

`isDev` therefore does NOT match the alias hypothesis. `_isDev` is module-local and
NOT `@internal`; `isDev` itself carries the tag, making it most likely the SAME
mechanism as entity-map. The earlier observation that removing its tag did not
restore the declaration is NOT trustworthy: it grepped one presumed file
(`constants.d.ts`) without confirming where the symbol should be emitted — the third
instance this session of answering a slightly different question than the one that
governs the decision. Re-test before recording any mechanism.

The rigorous falsifier asks the PUBLIC property, avoiding the location assumption:
after removing only `isDev`'s own `@internal` tag, can a consumer
`import { isDev } from '@signaltree/core'`, and what exact type arrives? Assert
build exit 0; dist recreated after the edit; package-root declaration exists;
`isDev` reachable from the root; consumer import typechecks; inferred type is the
expected boolean/literal shape; negative control proves it is not `any`/`unknown`.
Search the WHOLE fresh declaration tree for declaration sites and references to both
`isDev` and `_isDev`. If tag removal does not restore the contract, stop and
characterize what the fresh declarations actually contain — no mechanism guess.

Report the `isDev` result as this table, not as prose — it makes promoting one
sub-result into the conclusion much harder, which is exactly how the previous
`isDev` claim went wrong:

|                    | tagged | tag removed |
| ------------------ | ------ | ----------- |
| root importable    | ?      | ?           |
| rolled declaration | ?      | ?           |
| packed declaration | ?      | ?           |
| consumer type      | ?      | ?           |
| negative control   | ?      | ?           |

**SCOPE LIMIT.** The expected result is that `isDev` tagged is stripped, and that
removing only its own `@internal` restores the declaration, root importability, and
a boolean-compatible consumer type. If the table shows that, **the mechanism is
closed — do not investigate declaration tooling further.** Go straight to the
product question, and require POSITIVE evidence for keeping `isDev`, since it is
already deletion-favoured by the utility audit. Only if the table FALSIFIES the
same-mechanism explanation is a fresh-artifact investigation warranted.

**The packed gate is where declaration work ENDS.** Once packed + declared peers +
external consumer + no workspace resolution + `skipLibCheck: false` + `tsc` exit 0
is green, add the two-route regression fixture and return to API reduction. Do not
continue improving the declaration machinery past that point.

Then run an AST **characterization scan** (not a fix list) for the value-space
route. **Do not limit it to functions** — the recorded invariant is broader. The
property is whether the emitted public type contains a VALUE QUERY (`typeof
InternalThing`) whose target will not survive production declaration emission:

```ts
export const x = internalFunction;
export const x = InternalClass;
export const x = internalObject;
export const x = internalCallableObject;
```

Primitive initializers inline their literal type and are safe; anything the checker
describes by reference to another symbol is a candidate.

**Decide intent BEFORE de-internalizing any of the three, or any scan hit.** `isDev` is already in
the deletion-first utility audit below, so the product fix may be to remove it
from the public surface rather than to make its declaration survive. For each of
`isDev`, `createFormSignal`, `HydrateMode`: intended public API -> its declaration
closure must survive; not intended -> remove from public reachability instead of
de-internalizing. Otherwise a build-tool investigation quietly preserves an API
already slated for deletion.

#### Acceptance invariant

> A type reachable from a shipped public declaration must itself be present in
> the shipped declaration closure. Direct root importability is a SEPARATE
> API-design decision.

#### Permanent gate

Public declaration validation runs against the **packed** artifact, from an
external consumer, with no workspace path aliases, `skipLibCheck: false`, and
asserts `tsc` exit status 0. The repo may use `skipLibCheck` for speed; this gate
never may — an earlier "passing" external compile passed ONLY because
`skipLibCheck` suppressed errors inside `.d.ts` files, i.e. it suppressed exactly
the property under test.

The fixture must install the packed tarball PLUS its declared required peers
(`@angular/core`), while still excluding workspace aliases, monorepo source paths,
and undeclared dependencies. The harness must distinguish two failures that look
identical in the output:

| symptom                                   | meaning        |
| ----------------------------------------- | -------------- |
| missing required PEER dependency          | fixture defect |
| missing transitive DECLARATION dependency | package defect |

**GREEN at `629b3b7d`.** Measured, not asserted: fresh `npm pack` of
`dist/packages/core`, installed into a project OUTSIDE the workspace together with
all REQUIRED declared peers (`@angular/core`, `tslib`) — optional `rxjs`
deliberately omitted — no tsconfig path aliases, no
monorepo source resolution, `skipLibCheck: false` — `tsc --noEmit` exits 0 with zero
errors.

The fixture has reach rather than merely importing the package. It exercises every
declaration family that broke during this chapter, and carries three negative
controls that pass only if the shipped types are precise:

| family             | assertion                                                                                                                        |
| ------------------ | -------------------------------------------------------------------------------------------------------------------------------- |
| `isDev`            | `boolean`; rejects `string`                                                                                                      |
| `HydrateMode`      | all four members accepted; `'nope'` rejected                                                                                     |
| `createFormSignal` | callable at its emitted signature (the value re-export the differential cannot see)                                              |
| `entityMap`        | `DefaultKey` / computed-slice declarations resolve                                                                               |
| `restoration`      | `entry.state.count: number`, `.profile.name: string`, rejects `string` — receiver-derived inference surviving the packed `.d.ts` |

One failure during construction was correctly classified as a FIXTURE defect, not a
package defect: the fixture invented an `initial` member on `EntityConfig`. No
package was installed to make `tsc` pass — only declared peers — so an undeclared
dependency could not hide behind the harness.

#### Negative controls — `tools/check-declaration-closure-fixtures.mjs`

The production gate reporting zero is only meaningful if the checker can FAIL when
it should. Three synthetic inputs, one per discovered presentation, each asserting
the full semantic property rather than "the declaration disappeared":

```
production emit succeeds
stripping removes declaration X
a SURVIVING emitted declaration still depends on X
the checker reports X as broken closure
```

| case            | stripped               | still depends on it          | detected |
| --------------- | ---------------------- | ---------------------------- | -------- |
| A type-space    | `FixtureInternalType`  | `FixturePublicType`          | yes      |
| B value-space   | `fixtureInternalFn`    | `fixturePublicFn` (`typeof`) | yes      |
| C orphan trivia | `FixtureOrphanSupport` | `FixtureOrphanConsumer`      | yes      |

Stripping an implementation-only declaration is CORRECT. The defect is a removed
declaration plus a surviving shipped dependency, which is why each case asserts all
three conditions.

Fixture names are deliberately distinctive so the checker's bare-identifier keying
cannot collide with a real declaration and mask a result — testing the checker that
exists rather than presupposing the module-qualified rewrite. The marker token
appears in each fixture ONCE, in the position under test, and nowhere else: prose
mentioning it re-arms the behaviour.

### GATE B DECLARATION CLOSURE — GREEN. Investigation CLOSED.

Reopen only on a packed-consumer counterexample. No module-qualified rewrite, no
export-specifier enhancement, no further `stripInternal` archaeology. The two
documented checker approximations stay until an actual falsifier demands otherwise;
the packed external consumer is the stronger oracle.

HISTORICAL: `56572c5d` proved the entity-map instance is gone. It did not prove
the packed consumer gate passes: the temp consumer had no `node_modules`, so
`@angular/core` was unresolved (fixture defect), and the `isDev` instance was a real
package defect — both since resolved.

#### Permanent closure fixture — must cover BOTH routes

A fixture covering only a non-root support type would miss the value-space case
entirely, so it must exercise both proven routes:

```ts
// type-space closure
/** @internal */ export interface InternalType {}
export interface PublicType {
  value: InternalType;
}

// value-space closure
/** @internal */ export function internalFn(): number {
  return 1;
}
export const publicFn = internalFn;
```

The production declaration gate must reject both if stripping leaves a dangling
reference. Add it only AFTER the cause is fully repaired — a fixture added while
the pipeline is still broken proves little.

#### Build-experiment evidence rule

A missing error string is not evidence that a build succeeded. `grep -c "error
TS"` returned 0 for a build that failed and emitted no artifact at all. Every
decisive build experiment must assert all three: command exit status 0, expected
artifact exists, artifact has/lacks the property being tested.

### GATE B needs three independent dimensions

No single proxy can freeze the API. Each of these has now been observed passing
while another failed:

| dimension             | question                                  | failure it missed                                                                                                                                            |
| --------------------- | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Export inventory      | what names exist?                         | `RestorationMethods<T>` -> `RestorationMethods` (arity change, symbol set identical); `StateOf` (inventory clean, declaration invalid)                       |
| Public type contracts | what do those names mean to TypeScript?   | not yet systematic — targeted contract tests are sufficient for 1.0. `SignalTree<T>` is now covered by `signal-tree-type-matrix.typing.spec.ts` (`9f0d1464`) |
| Declaration closure   | can the shipped types be consumed at all? | the entity-map blocker above                                                                                                                                 |

`tools/api-inventory.mjs` compares symbol sets and metadata; it structurally
cannot see a type-shape change to an existing symbol. Generic-arity plus
signature fingerprinting is a possible later improvement, NOT a 1.0 requirement.

### Enhancer + tree-type vocabulary — decided

`Enhancer` is framework-neutral (`8e294c4c`), the demo authors against it
(`6b302bb9`), and time-travel no longer needs a state generic (`b266457d`).
FROZEN unless a deterministic counterexample appears — do not reopen.

Settled by measurement, with the evidence recorded in those commit messages:

- `createEnhancer` stays; the two-stage model wanted no second verb.
- `EnhancerHost` stays private.
- Return-additions authoring REJECTED on runtime evidence: 8 of 9 enhancer
  bodies do something a generic `tree + additions` combiner cannot express
  (`batching` replaces tree identity, `copyTreeProperties` exists because
  `Object.assign` dropped non-enumerable methods, `transactions` attaches a
  side-channel key).
- The neutral / realization-facing `.with()` overload split reflects two real
  authoring models, not legacy accommodation.
- `SignalTreeBase<T>` — DELETE. Character-identical to `SignalTree<T>`, zero
  consumers (declaration + barrel re-export are its only occurrences).
- `SignalTree<T>` — canonical public tree type.
- `ISignalTree<T>` — remove from public API, but only AFTER the enhancer
  migration; its remaining legitimate use is realization-facing enhancer
  signatures in `guardrails`, `realtime`, `schema`, `ng-forms`. Every demo use is
  paired with a cast or a compensating `& Methods` annotation.
- `composeEnhancers` — DELETE. `enhancers.reduce((t, e) => e(t), tree)` typed
  `(tree: T) => T`, so it erases `TAdded` entirely. Not a synonym for
  `.with(a).with(b)` — a strictly worse path. Independent of variadic `.with()`.

Variadic `.with(a, b, c)` is typing-proven for neutral enhancers and for real
converted built-ins, INCLUDING `as const` spread and negative controls. It is
blocked only on migrating each built-in's public contract to
`Enhancer<Methods>` — a mechanical candidate proven on `batching` (three lines:
signature, `import type`, one boundary cast; body untouched), to be migrated
one at a time with per-enhancer characterization rather than assumed
batching-shaped.

## RULE 0o — LEGACY CONTINUITY IS NEVER A PREMISE

> **No SignalTree 14 API, abstraction, capability, extension point, test,
> documentation, package boundary, representation or behaviour receives survival
> weight merely because it existed, was public, was documented, was intentional,
> or may have users.**
>
> Legacy evidence may establish only that a problem was PREVIOUSLY BELIEVED
> valuable enough to address. The corresponding 15 function must independently
> survive greenfield derivation.
>
> **If the function does not independently survive, there is no replacement,
> migration form, minimised equivalent, compatibility adapter or "better version"
> to derive. A failed function has no form question.**

### Why 0o exists when 0l and 0n already do

They were not strong enough in EXECUTION. The pattern recurred:

```text
v14 has X -> X is public/tested/documented/used -> therefore some 15 equivalent
must exist -> derive a smaller, better X
```

and required a human to interrupt with _"we don't need to keep that."_ That
interruption should never be necessary. **The burden drifted** from

```text
CORRECT     prove the function is NECESSARY
DRIFTED TO  prove the old FORM is UNNECESSARY
```

The second lets legacy survive by default. The standing default for anything
inherited is now:

```text
SURVIVAL = NO ASSUMPTION

not  KEEP until disproved
not  REDESIGN until disproved
not  "function probably survives, form unproven"
just NOTHING
```

Legacy may submit evidence FOR a function. The function then earns existence
from zero.

### Replacement-seeking is prohibited, not just compatibility-seeking

Legacy gravity has a subtler form: preserving a mechanism's NEGATIVE SPACE after
deleting the mechanism.

```text
MarkerProcessor rejected      -> "so what is the smaller extension boundary?"
derived->derived unnecessary  -> "so users cannot author it"
status deleted                -> "so where does error-retention move?"
```

All three are the deleted thing still steering. The answers may be _no boundary_,
_users can_, and _nowhere_. **Never propose a replacement for a rejected
mechanism in the same reasoning step that rejects it.**

```text
CORRECT   DELETE X -> nothing -> keep deriving -> later find gap Y
          independently -> derive Y
WRONG     DELETE X -> invent X2
```

### The four-way capability split, required BEFORE the first experiment

"The capability survives" is ambiguous and was used ambiguously. Classify:

```text
HISTORICAL     v14 could do this
SEMANTIC       this application/kernel outcome independently matters
DX             this way of EXPRESSING the outcome may be desirable
ARCHITECTURAL  SignalTree itself must own machinery to provide it
```

The custom-marker row resolved `historical YES · semantic YES · DX deferred ·
architectural NO EVIDENCE`. That split should have existed before the first
experiment, not after four rounds.

### ZERO-STATE CHECKPOINT — mandatory before implementation detail

```text
Assume SignalTree 14 never existed.

known surviving architecture     ...
function under consideration     ...
what independently requires it   ...
what breaks without it           ...
can surviving primitives already solve it   ...

LEGACY EVIDENCE MAY NOW BE OPENED:  YES / NO
```

**If the first questions cannot be answered without naming `marker`, `enhancer`,
`.with()`, `status`, `stored`, `linked`, `serialization` or `entityMap`, the
function has not been stated yet.**

### Legacy gets LAST look, not first

```text
WRONG   read what entityMap does -> ask what survives
RIGHT   derive the collection functions SignalTree requires -> THEN open
        entityMap to see whether it names a use case we missed
```

Same for `stored` (derive inbound/outbound durability and reconstruction
functions first) and `linked` (derive whatever synchronisation relation might
exist, if any).

### Phrases that are warning signs

```text
"we need an equivalent"    "we still need a way to"   "replace X with"
"the new version of"       "preserve the ability to"  "third parties may rely on"
"this is public"           "this was documented"      "tests cover"
"migration"                "compatibility"
```

Not always wrong — but each can hide _old thing existed -> new thing must fill an
equivalent role_. The response is **"why must that role exist at all?"** before
any discussion of what fills it.

### Consequence for arbitration

_"Should we preserve this because v14 had it?"_ is **NOT a valid arbitration
question** and must never be escalated as one. It is answered mechanically by
this rule. The only admissible restatement is _"does greenfield SignalTree need
this function?"_

## RULE 0n — MAJOR-VERSION CONTINUITY IS NON-SEMANTIC

> **SignalTree 15 has no obligation to preserve SignalTree 14 APIs, extension
> protocols, package boundaries, representations or compatibility paths. A public
> legacy capability is evidence that a USER PROBLEM may exist; it is not evidence
> that either the capability or its mechanism must survive. Users requiring the
> old architecture may remain on the old major version.**

And the harder corollary:

> **There is no internal 14 -> 15 compatibility boundary.** An adapter whose only
> purpose is to let rejected SignalTree 14 architecture participate in SignalTree
> 15 is FORBIDDEN unless a separate EXTERNAL interoperability function
> independently earns it.

### The model

```text
SignalTree 14                          SignalTree 15
  existing ecosystem                     greenfield architecture
  existing extension APIs      !==       may deliberately be a different system
  existing semantics
```

AngularJS versus Angular 2+. The old major stays the old world.

### Why this rule was needed

M1+M2-R1 found that `registerMarkerProcessor` is public, taught in the guides,
exercised by the demo with two custom declaration kinds, and advertised as a
product capability — and I inferred from that a "real open-set requirement" that
made the null "much harder". **That was publicness acting as a survival bonus**,
which is Rule 0l's failure mode wearing a new disguise. The same demo sentence
advertises _"markers AND enhancers"_, and the enhancer half was already found to
have no surviving function.

What the evidence actually establishes:

> **This was INTENTIONAL functionality, not accidental dead code.**

That is genuinely useful — it means the IDEA deserves examination rather than
silent deletion. It establishes **zero compatibility burden**.

### The order this forces

```text
A  is the capability intrinsically valuable to SignalTree 15?
B  if yes, what is the GREENFIELD MINIMUM?
C  only afterward: how does the old mechanism map to it?
```

C may answer `DELETE` even when A answers `YES` — a greenfield extension model
could be entirely different in shape, with **no adapter between them**.

And it demotes every implementation question beneath A:

```text
tree-shaking of unused kinds     DO NOT DERIVE YET
constant-time discrimination     DO NOT DERIVE YET
predicate-scan cost              DO NOT DERIVE YET
```

Proving the current registry is an efficient implementation is worthless until
the capability it implements has earned survival.

## RULE 0m — DX CAPABILITY IS EVIDENCE; DX SPELLING IS NOT ARCHITECTURE

> During semantic derivation, preserve useful authoring capabilities as explicit
> pressures and falsifiers — but do not freeze their syntax, and do not require
> the semantic or runtime topology to mirror the authoring topology. Final DX is
> derived only after the functional matrix is substantially closed, using
> compiler and lowering freedom to reconcile ergonomics with the minimal semantic
> model.

And its corollary, which is the one that was nearly violated:

> **A semantic deletion does not imply a DX prohibition.** If a capability can be
> represented entirely at authoring/compilation time and lowered into surviving
> semantics, its USER-FACING capability remains eligible even when the
> corresponding RUNTIME concept does not survive.

### The two failure directions, and both are live

```text
DX AS ARCHITECTURAL AUTHORITY          forbidden now
  "tree._.users.reload() reads well"   -> invents a command topology
  "features: [...] is a clean grammar" -> invents a feature ontology
  ".with() is pleasant"                -> preserves a rejected chain

DX AS PRESSURE / FALSIFIER             required now
  "did this conclusion remove an authoring capability the semantic result
   does not actually forbid?"
```

**The worked example is `derived`.** RFC 0015 proved that a runtime
derived->derived semantic topology is unnecessary — projectors are pure functions
of store truth, so any finite acyclic composition collapses by substitution. That
is a statement about the RUNTIME GRAPH. It was one inference step from becoming
_"the author may not compose named projections"_, which the semantics do not
require: the dependency can expand transitively to canonical inputs during
lowering, leaving the authoring capability intact.

```text
AUTHORING       derived B references derived A
SEMANTICS       both are projections of canonical truth
LOWERING        B's dependency expands transitively to canonical inputs
```

Authoring ontology and runtime ontology need not be isomorphic. Lowering is the
bridge, and it is why the `LOWERING HYPOTHESIS` column matters beyond
bookkeeping.

### What this changes in practice

Every closing matrix row now also answers:

> **Did this conclusion accidentally remove a useful authoring capability that
> the semantic result does not actually forbid?**

Recorded as CAPABILITY, never as spelling. For `derived` that reads _"let authors
compose named projections naturally"_ — NOT `$.subtotal()`, `derived.subtotal`,
`derive(subtotal)`, or any other candidate syntax, none of which is frozen.

**The final DX pass is explicitly deferred**, and its question is not "what API
survives?" but:

> If SignalTree had never existed, given only the functions now proved necessary
> and the compiler freedoms now earned, what is the best possible way to author
> it?

Running that per-feature during derivation would optimize locally and conflict
globally. It runs once, over the closed matrix.

## RULE 0l — LEGACY MECHANISMS ARE EVIDENCE REPOSITORIES, NOT MIGRATION TARGETS

> **A legacy mechanism may identify a problem worth solving. It may not
> constrain the solution.**

The audit has crossed the point where `.with()`, `Enhancer`, `plannedSignalTree`,
`bind()`, `requires`, `provides` and `name` deserve to be treated as candidate
architecture. They are now HISTORICAL EVIDENCE about functions the old system
happened to provide.

The question stops being _"how do we replace enhancers?"_ and becomes:

> **What useful functions existed, which still matter, which are already
> satisfied naturally by the derived architecture, and what is the optimal
> greenfield solution for any remaining gap?**

### Why this correction is earned rather than stylistic

Three times now, a function survived while its mechanism evaporated — and in
each case the mechanism would have survived if it had been the unit of audit:

```
plannedSignalTree   looked essential      -> function is PRECONSTRUCTION
                                             PLANNING; the second constructor
                                             is not part of it
identity replacement looked like a need   -> function is ALTER FINAL CALLABLE
                                             BEHAVIOUR; replacement is fallout
                                             from doing it after construction
.with() accumulation looked structural    -> T0 proved type contribution never
                                             needed sequential application
```

Auditing the noun would have preserved all three.

### The extraction process, replacing "does X survive?"

```
1  USE CASE            what concrete application need exists?
2  OWNER               is it actually SignalTree's job?
3  NEW-SYSTEM COVERAGE does the already-derived architecture satisfy it?
4  NULL                remove the function entirely — what becomes impossible?
5  GREENFIELD MINIMUM  if a real gap remains, the smallest optimal mechanism
                       ASSUMING SIGNALTREE 14 NEVER EXISTED
6  LOWERING            declaration / compiler / kernel / realization /
                       publication / external adapter
7  LEGACY DISPOSITION  only at the end, map old concepts onto the result
```

**No proposed solution may cite compatibility with a current mechanism as a
reason for its shape.** No `.with()`-compatible declaration, no `Enhancer`
adapter, no `plannedSignalTree` bridge, no `requires`/`provides` compatibility
layer. If a greenfield result happens to resemble an old mechanism, it must earn
that resemblance independently.

### ADAPTERS — one class is legitimate, one is prohibited

```
ALLOWED — the adapter IS the surviving function

  SignalTree-owned truth  <->  external system representation
  e.g. Angular Reactive Forms, a storage implementation, a devtools protocol,
       a network transport

FORBIDDEN by default — the adapter exists only to preserve something rejected

  new SignalTree architecture  <->  rejected SignalTree 14 mechanism
  e.g. a declarative compiler with an old `.with()` enhancer shim
```

The test is whether the boundary being crossed is EXTERNAL. Crossing from the
new architecture to our own discarded architecture is not a boundary, it is a
compatibility obligation we chose to create. Build one only if an external
compatibility requirement independently survives GATE B.

## B2-1 STEPS 2-8 — **WITHDRAWN.** Replaced by functional extraction

Steps 2-8 were written as `Enhancer` -> `plannedSignalTree` -> `bind()` ->
`requires`/`provides` survival audits. **That is still letting old nouns
determine the investigation**, which is what Rule 0l now forbids. Running an
"`Enhancer` null" in particular starts from the legacy abstraction: it asks
whether `(tree) => tree & TAdded` survives, when the real question is whether
authoring intent, type contribution and runtime realization are even the same
concept.

`.with()`'s DELETE stands as a LEGACY DISPOSITION — it was reached by extracting
the supposed function and finding no surviving use, not by comparing forms.

The active work is now **extension-cluster functional extraction and coverage
audit**. See RFC 0016 Amendment 2 for the functional matrix; the legacy symbols
appear there only in an evidence column.

## B2-1 STEP 1 — `.with()` FUNCTION: **DELETE**. No surviving function found.

Run against the sharpened null, which prevents `.with()` reclaiming functions
T0/T1/T0-G already removed from its column:

> Assume all authoring declarations are supplied to `signalTree({...})` before
> compilation, static contribution conflicts are rejected at the declaration
> site, all tested runtime realization completes before EXPOSE, and no measured
> consumer performs genuine late attachment. **What independently required
> PUBLIC function remains that requires `.with()` itself?**

### THE DISTINCTION THAT LOOKED LIKE A COUNTEREXAMPLE AND IS NOT

`@signaltree/realtime` was the strongest candidate: connections come and go, and
it contributes `connect()`, `disconnect()`, `subscribe()`, `isConnected()`.
Those are called long after the tree is live.

```
post-exposure INVOCATION    calling a capability contributed before EXPOSE
post-exposure COMPOSITION   adding a capability after EXPOSE
```

Only the second requires `.with()`. Realtime is entirely the first — it is the
shape T1 CASE 1 already modeled. **This distinction is the one thing that could
have saved the chain, and it does not.**

### Measured, not assumed

```
@signaltree/realtime          touches ZERO `tree.*` APIs at application time.
                              It wraps and returns; its runtime methods live on
                              the contributed object.

withUndo (TP-STYLE authoring, custom-extensions-demo)
                              captures `tree` in a closure and reads `tree.$`
                              LAZILY inside takeSnapshot, i.e. at INVOCATION.
                              Needs a CONSTRUCTED tree, never an EXPOSED one.

docs/guides/custom-markers-enhancers.md
                              no dynamic-installation, plugin-registration,
                              conditional-late-attachment or attach/detach
                              pattern is documented anywhere.

CASE 0 repository sweep       zero genuine post-exposure attachment.
```

The TP-style example is the important row. `withUndo` is the closest thing this
repo has to a third-party enhancer author, and what it needs from the chain is
nothing: a constructed tree it can close over. A REALIZE phase supplies that.

### Disposition

```
FUNCTION      public post-exposure / incremental tree composition
OWNER         no surviving SignalTree-owned requirement found
PUBLIC NEED   no CI evidence. No FP evidence — realtime, guardrails, ng-forms
              and events all contribute rather than compose late.
              TP remains HYPOTHETICAL; for this symbol the standing rule is that
              keeping it requires POSITIVE evidence, and none was found.
CURRENT FORM  post-construction chained enhancer application
DISPOSITION   DELETE
```

**The physical cut is NOT authorized by this row.** Steps 2-6 must first
determine which functions currently hanging off the chain have to migrate into
the declarative model — type contribution, realization, planning, dependency,
duplicate identity. Rule 0j-2 permits removing the mechanism only once its
surviving functions have somewhere to live.

## B2-1 STEP 7 CRITERIA — frozen NOW, spelling deferred

The public authoring property name must not be chosen before steps 1-6 establish
the surviving ontology, and it must not be chosen by taste by anyone. The
criteria are frozen here so the eventual choice is scored rather than preferred.

A candidate spelling scores positively only if it:

```
1  reads as DECLARATIVE INPUT, not mutation of an existing tree
2  does not imply sequential application or source-order execution
3  makes sense for both first-party and third-party declarations
4  does not imply the authoring value is a runtime object
5  accommodates declarations affecting construction capabilities, runtime
   realization, and public/type contribution — WITHOUT claiming every
   declaration does all three
6  reads naturally beside `store` and `derived` in one declaration
7  does not smuggle the rejected enhancer mental model back in through naming
```

**Do not preserve `extensions` merely because the prototype used
`ExtensionDeclaration`.** Three candidates stay alive — `features`,
`extensions`, `using` — and they are NOT equally promising:

```
features    strongest IF the survivors are declarative selections of optional
            tree behaviour. Says what the tree HAS, not what is done to it.
extensions  strongest IF the dominant survivor is an open third-party extension
            protocol. Weaker if this is mainly compiler input for first-party
            capabilities. Fails criterion 1 by default reading: "here is a
            finished thing, now extend it" — the exact mental model under audit.
using       avoids "bolted on" and reads well at declaration time, but is less
            noun-like beside `store`/`derived` and says almost nothing about
            what the values ARE.
```

Working hypothesis, explicitly not a disposition: `features` leads. It must win
on the derived semantics — "optional capabilities the tree is declared to have"
— not on sounding better.

### The identical-contribution policy, deferred with a warning

T0-G accepts two declarations contributing the same key with an identical type,
because its comparison is `Equal<H[K], Seen[K]>`. When that policy comes due:

> **Type compatibility cannot establish semantic compatibility.** Two
> declarations may each expose `refresh(): void` with completely different
> ownership and implementation. Do not let `Equal<A, B>` become the
> architectural rule because it made the type guard convenient.

### What T0-G bought, stated once

The compiler can now own BOTH sides of the same contract, which the current
model does not:

```
TYPE COMPILATION     incompatible contributions -> authoring-site compile error
RUNTIME COMPILATION  incompatible/duplicate realization -> refuse before EXPOSE
```

That is materially cleaner than a type system silently accumulating one thing
while runtime composition does another.

## SHAPE-T1 DERIVED — with four corrections to what the prototype actually proved

Evidence: `single-pass-construction.spec.ts`, plus the CASE 0 repository
measurement. **Four claims from my own summary are narrowed here before any
disposition is built on them.**

```text
MEASURED CURRENT USE
  genuine post-exposure extension attachment              ZERO

PROVED IN THE MODEL
  runtime contribution can occur pre-EXPOSE               YES
  callable interception can occur pre-EXPOSE              YES
  runtime collision refusal can occur pre-EXPOSE          YES
  cleanup registration can occur pre-EXPOSE               YES
  dependent realization can occur pre-EXPOSE              YES
  duplicate refusal can occur pre-EXPOSE                  YES

NOT YET PROVED
  static/type-level collision rejection
  minimum representation of realization dependencies
  minimum representation of duplicate identity
  exhaustive absence of TP post-exposure need

CONSEQUENCE
  no TESTED function requires public post-exposure composition
  the .with() chain has lost its known semantic justification
```

### The four corrections

1. **CASE 3 does NOT close the T0 collision defect.** It closes the RUNTIME
   half: whole-set DISCOVER can refuse conflicting contributions before
   exposure. T0's defect was also a TYPESCRIPT CONTRACT defect — the declaration
   expression stays type-valid while an incompatible intersection silently
   resolves to one overload. Either a typing theorem makes incompatible
   declarations fail AT THE DECLARATION SITE, or collision rejection is
   consciously chosen as runtime-only. For a compiler-like authoring surface the
   former is strongly preferred, and it is step 0 of cluster closure.

2. **CASE 5 does not establish how realization order is OBTAINED.** The
   prototype succeeds because `producer` precedes `consumer` in the array. That
   proves an internal order is SUFFICIENT — and therefore that `.with()` is not
   required — but not that the order is derivable without some dependency
   relation. `requires`/`provides` stay unproven; the underlying FUNCTION
   "declare or derive a realization dependency" becomes a legitimate survivor
   candidate.

3. **CASE 6 does not establish that a declaration `id` is MINIMAL.** It shows an
   explicit `id` is SUFFICIENT to reject duplicates. Whether duplicate semantics
   can instead be derived from contribution, capability or type identity — with
   no separate identity axis — has not been asked. The prototype's convenient
   field must not become the architecture.

4. **`Object.freeze(tree)` is model ENFORCEMENT, not evidence.** It proves the
   prototype does not cheat by composing after exposure. The evidence that no
   late composition is needed is CASE 0's repository measurement. Do not count
   the freeze as an independent reason `.with()` is unnecessary.

### Naming

This is the **current construction-model cluster** — `.with()`, `Enhancer`,
`plannedSignalTree`, `bind()`, `requires`, `provides`, `name`. Calling it the
"obsolete" cluster would embed the verdict the audit has not yet emitted.

## SHAPE-T1 CASE 2 — IDENTITY REPLACEMENT IS AN ARTIFACT, MEASURED IN PRODUCTION CODE

Not a prototype. This is why the three identity-replacing built-ins replace
identity, read out of the shipping implementations.

### The root cause

All three build a NEW FUNCTION and copy the old tree onto it:

```text
batching.ts:307      const enhancedTree = function (this, ...args) { ... }
time-travel.ts:2739  const enhancedTree = function (this, ...args) { ... }
devtools-impl.ts:1653 const enhancedTree = function (this, ...args) { ... }

then, in each:  Object.setPrototypeOf(enhancedTree, getPrototypeOf(tree))
                copyTreeProperties(tree, enhancedTree)
                redefine $, redefine .with()
```

**The tree is CALLABLE, and JavaScript cannot change a function's `[[Call]]`
behaviour in place.** Batching must intercept `tree(...)` to schedule its
notification; time travel and devtools must intercept it to record. On an
ALREADY-CONSTRUCTED tree that requires SOME new callable identity — the current
copy-and-redefine is one realization of that constraint, and a Proxy would be
another. **WORDING CORRECTED:** the surviving requirement is _change callable
behaviour_, not _replace identity_; an earlier draft said "the only way", which
overclaimed. The architectural conclusion is unchanged, because every mechanism
that satisfies the constraint post-construction produces a new callable.

So identity replacement is not a capability any enhancer wanted. It is the only
mechanism available for modifying a callable that already exists.

### The circularity, in the code's own words

`batching.ts:353` and `devtools-impl.ts:1736` carry the same comment:

> _"Define new .with() method that passes enhancedTree (not the original tree) to
> subsequent enhancers. This is critical for preserving the enhancer chain."_

The replacement redefines `.with()` **in order to preserve the chain**, and the
replacement itself exists only because the chain applies changes after
construction. The chain requires replacement; replacement exists to serve the
chain.

### Consequence under single-pass construction

If the compiler knows before constructing that batching, time travel or devtools
want to intercept the call, it builds ONE callable with those interceptions
already in it. There is nothing to replace, and no second `.with()` to redefine.

**That deletes BLOCKER #3b rather than fixing it.** The guard bypass exists
because a replacement tree is a new object that cannot reach the original's
per-tree bookkeeping closure. No replacement, no unreachable bookkeeping, no
bypass. The defect is a property of the mechanism, and the mechanism is
compensation for the chaining architecture.

**T1 case 2 verdict: no surviving function requires application to an
already-exposed tree.** Identity replacement is CURRENT FORM explained, not a
function.

### T1 case 4 — lifetime, partial measurement

`registerCleanup(fn: EnhancerCleanup)` is already a TREE method, and all five
built-ins that need teardown call `tree.registerCleanup(...)` — serialization,
transactions, devtools, batching, time travel. It is a lifecycle registration on
the tree, not a property of `.with()`. So teardown registration during a REALIZE
phase needs nothing that does not already exist.

**Not yet answered:** whether any surviving function requires LATE attachment or
REMOVAL after exposure. That is the hard falsifier for case 4 and it is still
open.

### T1 CASE 0 — late attachment, measured before prototyping

Searched every `.with()` call site outside core's own implementation and specs,
separating _syntax split across statements during construction_ from _a live,
exposed tree extended later_.

```
demo call sites                         all construction-time
two that LOOKED like late attachment    both are factory-then-enhance
  batching-comparison.ts:89               createCountingTree() -> base.with(...)
                                          nothing reads `base` in between
  serialization-demo.ts:113               baseStore -> this.store = baseStore.with(...)
                                          same constructor, nothing in between
genuine post-exposure attachment        ZERO
conditional/dynamic registration        ZERO
attach-then-detach                      ZERO
```

Zero hits is evidence, not a verdict — but it sharply constrains what T1B must
model, and it means no existing consumer would lose a capability if composition
ended at EXPOSE.

**One incidental observation with independent weight.** The
`serialization-demo` site needs `as any` TWICE, with an eslint-disable around it,
to make `.with()` typecheck. So the chain's type accumulation is already failing
a real first-party consumer in a case the SHAPE-T0 declarative form handled
without any assertion. That is not proof of anything on its own — the cast may
be masking an unrelated defect — but it is the opposite of evidence that the
chain's typing is serving people well.

### Still open in T1

```
1  runtime contribution      can behaviour bind post-kernel, pre-exposure?
3  collision detection       can the compiler reject the T0 silent shadowing
                             before exposure?
4  late attach/remove        the hard falsifier above
5  cross-extension dependency does realization B need runtime OUTPUT of A?
                             note: outcome B (compiler-known dependency) does
                             NOT save `.with()` — an internal topological order
                             is not a public composition API
```

## B2-1 GOVERNING NULL — REPLACED. The question is the construction shape, not `.with()`'s consumers

Item 0 changed what this cluster is asking. The old question — does `.with()`
have consumers, does `requires` have consumers — is too weak, because it can only
ever confirm current form. The replacement:

> **Assume there is no chained `.with()`. Given a single declarative
> `signalTree({...})` that receives extension descriptors BEFORE compilation,
> what SignalTree-owned function becomes impossible?**

If the answer is "none", `.with()` dies even though extension functionality
survives completely. That is the strong form, and it is the one to run.

**Why the reframe is earned rather than attractive:** item 0 measured that
capability planning must happen BEFORE construction, and that chained `.with()`
structurally cannot do it because the tree already exists when an enhancer is
applied. That is a property of the API SHAPE. Every remaining question in this
cluster — `requires`, `provides`, `bind()`, the realization overload — is a
question about a chain that may not survive.

**Working hypothesis, recorded so it is not mistaken for a conclusion:** the
extension FUNCTION may survive; the post-construction CHAIN probably does not.
The candidate shape and its ledger live in
[RFC 0016 Amendment 1](docs/rfcs/0016-signaltree-15-candidate-architecture.md) —
CANDIDATE, nothing frozen, and it must not be cited from here as authority.

### Sequence, revised to follow the dependency the measurement found

```text
construction shape  <- the null above; decides whether a chain exists at all
        |
        +-- if a chain survives:  requires -> provides -> bind() -> .with() overload
        |
        +-- if it does not:       those four are moot as CHAIN concepts and each
                                  must be re-asked against the declarative form
```

**Do not audit `requires`, `bind()` or the `.with()` overload before the shape
question.** Judging them as chain features would answer a question that may not
exist, and repairing the #3b protocol defect would build coherence into a chain
that may not survive.

### What the shape null needs, and what it must not accept

The decisive falsifier is TYPING, not usage. `.with()` accumulates through
`this & TAdded`, and `this`-polymorphism is what carries every prior
accumulation forward; a tuple of descriptors must reproduce that against the
REAL `ISignalTree`/`TreeNode`/`NodeAccessor` types, with callable trees.

A scratch probe against simplified types is clean — tuple accumulation resolves,
the store type survives, `derived` infers, `$` is provably not `any`, and three
negative controls fire. **That is not acceptance.** RFC 0015 recorded an encoding
that appeared to infer correctly and did not, and the only thing that exposed it
was revealing the inferred generic. The shape null is answered by a typing SPEC
in `packages/core`, built the way `derived-projection-contract.typing.spec.ts`
was, or it is not answered.

Other functions to test independently, none of them assumed:

```
1  order-independent contribution   does anything need enhancers to arrive
                                    without one owner controlling order?
2  deferred construction            already ANSWERED YES by item 0
3  capability resolution pre-tree    already ANSWERED YES by item 0
4  TP extension contract            reproducible externally, or does it duplicate
                                    SignalTree-owned semantics?
5  identity replacement             three built-ins replace the tree today. Is
                                    that a function, or an artifact of applying
                                    changes to an already-built tree?
```

Item 5 is the one most likely to dissolve: if construction happens once with full
knowledge, there may be nothing to replace.

## B2-1 ITEM 0 — `plannedSignalTree`: the FUNCTION SURVIVES, and it is not the one I attributed to it

Derived with the implementation held aside, then revealed. **This CORRECTS the
opening measurement below**, which recorded `requires` as downstream of
`plannedSignalTree`'s survival. That coupling is an artifact of a shared call
site, not a semantic dependency.

### FUNCTION — survives, and it is capability-driven substrate construction

```
ordinary signalTree()
  LEGACY_TREE_BUILD_PLAN = ['causal-runtime', 'temporal-snapshots']
  and 'causal-runtime' depends on 'mutation-capture' + 'position-topology'
  -> ALL FOUR capabilities are ALWAYS installed, whatever the app uses

plannedSignalTree().build()
  buildPlan = buildTreePlan(enhancers)      from their declared `capabilities`
  physicalCommitClock created ONLY IF buildPlan.has('causal-runtime')
  -> the substrate is built from what was actually asked for
```

The `capabilities` axis is EXERCISED in production, unlike `requires`:

```
transactions   capabilities: ['causal-runtime']
time-travel    capabilities: ['causal-runtime', 'temporal-snapshots']
```

**Positional `.with()` structurally cannot express this.** `.with()` applies an
enhancer to an ALREADY-CONSTRUCTED tree whose substrate is already fixed to the
legacy plan; a capability that must exist at construction time — leaf
specialization, the causal substrate, position topology — cannot be retrofitted
onto it. The spec names say exactly this: _"installs causal capability before
exposure so retained set refs stay correct"_, _"keeps status marker source leaves
non-authoring without mutation-capture"_.

So the NULL is answered: something real is lost. Deferred construction is not
ordinary application composition here — it is the only point at which the
substrate decision can be made.

### THE CORRECTION — `requires` is NOT downstream of this

`build()` currently bundles THREE separable things:

```
1  capability collection -> substrate planning     field: `capabilities`
     REAL, exercised, and the reason plannedSignalTree has a function

2  enhancer ordering                                field: `requires`/`provides`
     resolveEnhancerOrder; a no-op on every production input (zero requires)

3  duplicate + dependency guard
     ALSO present on the ordinary .with() path — not unique to this call
```

Only (1) gives `plannedSignalTree` its function. (2) merely has its only call site
here. So `plannedSignalTree` surviving does NOT carry `requires`/`provides` with
it, and the earlier claim that it did was wrong — I inferred a semantic
dependency from a shared call site, which is the same class of error as inferring
function from current form.

**`requires` must be judged on its own**, and the narrower null is the right one
regardless of how item 0 resolves:

> Does SignalTree need a PUBLIC dependency GUARD for enhancer capabilities on the
> ordinary positional `.with()` path?

### DISPOSITION — function SURVIVES; the PUBLIC SPELLING is UNPROVEN

```
FUNCTION           SURVIVES — substrate built from declared capabilities
OWNER              SignalTree; it owns the substrate. Not arguable.
PUBLIC NEED        the FUNCTION is CORE-INTERNAL at minimum.
                   Whether the plannedSignalTree SPELLING must be PUBLIC is
                   UNPROVEN — zero consumers anywhere, and
                   docs/architecture/causal-runtime-contract.md already lists it
                   as "a public API candidate", i.e. never settled.
MINIMUM PRIMITIVE  capability declaration on enhancer metadata, plus a plan
                   computed BEFORE construction.
CURRENT FORM       a second public constructor with a deferred build()
DISPOSITION        NOT DELETE. Function survives. Form UNPROVEN.
```

**The live alternative, which must be refuted before `plannedSignalTree` is kept
public:** `signalTree()` itself could compute the plan from its enhancer chain,
which would make the second public constructor unnecessary while KEEPING the
function. That is a REDESIGN candidate, not authorized here — it changes when
construction happens on the primary path, which is a GATE A-adjacent question.

### One consequence worth carrying to GATE C/D

Every ordinary `signalTree()` pays for all four capabilities whether or not the
app uses transactions or time travel. That is a measured substrate cost, and it
is relevant to the bundle-budget reconciliation already queued. Recorded here as
an observation; it is not a B2 item and must not be optimized during a surface
audit.

## B2-1 OPENING MEASUREMENT — `requires` is unexercised, and its only reordering consumer is unaudited

Run with the implementation held aside, per the B2 rule that an existing export
is evidence of CURRENT FORM only.

### The capability axis, measured across all production code

```
requires:  non-empty declarations in production      ZERO
           the only production occurrence is serialization.ts:1305 `requires: []`
           everything else is the implementation, one JSDoc example, and specs

provides:  six declarations, and FIVE RESTATE `name`
           batching     -> ['batching']
           devTools     -> ['devTools']
           restoration   -> ['restoration']
           transactions -> ['transactions']
           serialization-> ['serialization']
           persistence  -> ['persistence','serialization']   <- the only one that
                                                                names a second token
```

So the capability system's CONSUMER SIDE is entirely unexercised. `provides` is,
in five of six production instances, a synonym for `name` — exactly the
`name != provides` distinction the docs assert and the code has never once
exercised. And with zero non-empty `requires`, the dependency graph
`resolveEnhancerOrder` builds has NO EDGES, so its topological sort is the
identity function on every real input.

### The finding that changes the sequence

**`resolveEnhancerOrder` has exactly one internal caller: `plannedSignalTree()`'s
`build()`.** The ordinary `signalTree().with(...)` path never calls it — order on
that path is positional, exactly as the consumer wrote it.

```
ordinary .with() chain     order is positional; resolver NOT consulted
                           `requires` acts only through the .with() dependency
                           guard — which the identity-replacing built-ins
                           DISABLE (see BLOCKER for #3b)

plannedSignalTree().build() the resolver's ONLY caller; with zero requires in
                           production it reorders nothing

plannedSignalTree consumers ZERO outside its own export line
```

So `requires` today has no reordering effect anywhere, and its validation effect
is bypassed in the configurations most applications use.

### Why no verdict is recorded yet

Two reasons, and neither is squeamishness:

1. **Zero consumers is evidence, not a verdict.** The TP case — a third-party
   enhancer author declaring "apply me after capability X" — is exactly the level
   workspace evidence cannot refute. It has to be argued, not assumed absent.
2. **`requires`'s reordering function is downstream of `plannedSignalTree`'s
   survival, and that is MUT-0 order item 9 — unaudited.** If
   `plannedSignalTree` does not survive, the resolver loses its only caller and
   `requires` loses its only reordering authority, leaving just the guard. If it
   does survive, the ordering function has a home and the question is real.

**SEQUENCING CONSEQUENCE:** `plannedSignalTree`'s PUBLIC-SURFACE status is B2
work, not derivation-lane work, and it was not in the B2-1 list. It should be
settled before `requires`, because it determines what `requires` can even mean.
Deciding `requires` first would be deciding a dependent before its dependency.

**Do not repair the protocol yet.** The BLOCKER for #3b is a real defect, but
repairing it would be building coherence into a protocol whose individual
functions have not yet survived — the explicit B2-1 guard.

### API cleanup queue, after the declaration fix

**Two verified surface findings, added to this queue.** Both were measured while
building RFC 0016, both are Gate B mechanics rather than architecture, and
neither implies any replacement design:

- **`ENTITY_LOADER_READERS` is an orphan public export.** Exported from
  `@signaltree/core/authoring`, referenced only by `readonly.ts:191`, and there
  is **no `entityLoader` factory anywhere in any package source** — verified by
  a whole-`packages/` scan, not by an index grep. A public reader allowlist for
  a factory that does not exist is a surface-cleanup item. Rule 0j-1 applies: do
  NOT infer a replacement `entityLoader` design from its readers.
- **`tools/api-baseline.json` is stale and cannot currently defend anything.**
  It still carries `form`, `FORM_MARKER`, `FORM_READERS`, `FORM_WIZARD_READERS`,
  `createFormSignal`, `isFormMarker` and the entire `schema` package — all
  deleted by FORM-DEL (`b57ba293`) and SCHEMA-DEL. Any `--check` run compares
  HEAD to an architecture that no longer exists, so a "clean" result is
  meaningless and a dirty one is uninformative.

  **Sequencing, and it is the part that is easy to get backwards:** re-baseline
  only AFTER the intended public surface is established, never before. The
  baseline must record what the surface is intended to be; using it to decide
  what to repair would let a stale artifact select the API being frozen. An
  existing export is not evidence of intended public API.

1. ~~Delete `SignalTreeBase`.~~ **DONE** — characterized `9f0d1464`, deleted
   `6a515699`. See "Slice 1 — `SignalTreeBase`" below.
2. ~~Delete `composeEnhancers`.~~ **DONE** — characterized `2f46115b`, deleted
   `6c3d73a8`, equivalence claim refuted and corrected `d09525d6`, migration
   `2ae531c1`. See "Slice 2" below.
3. ~~Migrate remaining built-ins to `Enhancer<Methods>`, one at a time.~~ **DONE** — all six migrated, one per commit: `batching` `cc7ad43f`, `restoration` `cfbd4985`, `devTools` `a0ebaf3f`, `serialization` `7850acf8`, `persistence` `37e59e1c`, `transactions` `5fa0053e`. Protocol prerequisites first: capability authority `681ffb8e`, continuity across identity replacement `7a6bd4c9`. <- item #4 is NEXT
   **Also owns the `requires` namespace defect** found in slice 2 (below), and
   the transitional tests in `planned-enhancer-dependencies.spec.ts` that record
   it. Those tests are NOT a compatibility contract — changing the behaviour
   means updating them, not restoring the bug.
4. Remove the realization-facing `.with()` overload; add heterogeneous variadic
   `.with(...enhancers)` with runtime order-equivalence tests and an
   identity-replacing enhancer case.
   **ITS RECORDED JUSTIFICATION NO LONGER HOLDS.** The overload's docblock said
   it exists because "core's built-ins are declared `<T>(tree: ISignalTree<T>)
=> ISignalTree<T> & Methods`". After item #3 that is FALSE — all six are
   `Enhancer<Methods>`. Core no longer justifies it. That is NOT proof it is
   unused: `guardrails`, `realtime`, `schema` and `ng-forms` still declare
   enhancers against `ISignalTree`, and THAT is what must be measured before
   deleting. The stale premise is corrected in `types.ts` so the next reader
   does not treat it as current evidence either way.

   **Also delete the three built-in `.with()` overrides** (`batching.ts:355`,
   `time-travel.ts:2820`, `devtools-impl.ts:1733`). `7a6bd4c9` made the
   canonical `with` overwrite them on adoption. `batching`'s and `restoration`'s
   are then dead machinery; `devTools`' is NOT — see the correction below —
   but under Rule 0e the canonical path should be the SOLE owner, not merely the
   winner. Do not keep them because the fix tolerates them.

5. Realistic `SignalTree` vs `ISignalTree` matrix (state containing nested
   object + `entityMap` + marker + primitive leaf, with negative controls).
   **The annotation/constructor alignment half is DONE** (`243dd5fb`,
   `215568cb`) — the constructor's return now satisfies `SignalTree<T>`
   positively. What remains is internalizing `ISignalTree` **BEHIND**
   `SignalTree<T>` — `SignalTree<T>` is the public name and it stays; only its
   current representation becomes private. EXTEND
   `signal-tree-type-matrix.typing.spec.ts`; do not start a new file.
6. `FORM_MARKER` / `isFormMarker` — one owner. Declared in
   `@signaltree/core/authoring`, re-exported by `ng-forms`
   (`form-bridge.ts:582`); pick the marker-contract owner.
7. Un-publish `@signaltree/guardrails/./noop` as a public subpath, keeping it as
   the conditional-export target. Falsifiers first: repo/docs explicit imports of
   it = 0, no compelling external usage.
8. Authority audit — `flushAllStoredSignals`, `clearStoragePrefix`,
   `invalidateTag` fit no grammar bucket. Decide whether the authority is
   genuinely process-wide or leaked implementation ownership.
9. Deletion-first audit — `deepEqual`, `isDev`, `toWritableSignal`, `asReadonly`.
10. Metadata polish — `readonly`/literal-friendly `EnhancerMeta` arrays.

### Slice 1 — `SignalTreeBase` DELETED (`9f0d1464`, `6a515699`)

Rationale is ontological, not aesthetic: the name asserted a base/derived
relationship with `SignalTree<T>` that never existed. Both aliases expanded to
`ISignalTree<T> & TreeNode<T>`, so "base" was a synonym wearing a taxonomy.

```
PROPERTY   SignalTreeBase has no independent supported semantic contract.
FALSIFIER  a consumer or API contract where replacing SignalTreeBase with
           SignalTree changes expressible type semantics, inference,
           assignability, or public capability.
RESULT     no counterexample -> deleted
```

The falsifier was UNIVERSAL, not sampled: `Equal<SignalTree<T>,
SignalTreeBase<T>>` at a free unresolved `T` is a statement about every
instantiation. It was proven able to fire before it was trusted — mutating the
alias to `ISignalTree<T>` turned the universal row and all five sampled rows
red, and mutating it to `ISignalTree<unknown> & TreeNode<T>` additionally turned
the member-level `bind` row red. `registerCleanup` cannot distinguish either
mutation because its member type does not mention `T`; recorded rather than
papered over.

**`packages/core/src/lib/signal-tree-type-matrix.typing.spec.ts` is permanent
and is the third GATE B dimension for the one type consumers annotate with.**
It closes the recorded `api-inventory` blind spot for `SignalTree<T>`
specifically: the inventory compares symbol sets and metadata, so it cannot see
a type-shape change to a symbol that keeps its name. Dimensions pinned: root
object tree, primitive root, nested access, markers, `entityMap`, enhancer
accumulation, `bind`/`destroy`/`registerCleanup`, negative controls. Rows are
invariant identity, not assignability — assignability passes on a widened type.
Section 0 pins that the `Equal` helper is not vacuous.

Rule 0d is pinned there deliberately: the three branch call forms, structural
navigability at depth, and `branch is not a signal` are exactly what a type
cleanup erodes while every runtime test stays green.

Two things learned that outlive the slice:

- **`state` is NOT on `SignalTree<T>`.** It is a `SignalTreeBuilder` member, so
  it exists on what `signalTree()` returns but not on the type consumers
  annotate with. The first draft of the matrix asserted it; `tsc` refuted it.
  Now a negative control.
- **`api-inventory --check` output does not prove the absence of metadata
  drift.** It prints symbol-set changes and then reports "SURFACE CHANGED",
  staying silent about metadata drift on RETAINED symbols even though such
  drift also fails the comparison. Confirming an intended delta therefore means
  regenerating the baseline and diffing the JSON, not reading `--check`. Done
  here: exactly the nine-line `SignalTreeBase` block, core 207 -> 206, every
  other package byte-identical.

Ladder at `6a515699`: tsc typecheck green; `nx build core` exit 0 with fresh
artifacts (`SignalTree` declared in the emitted `types.d.ts`, `SignalTreeBase`
absent from the whole `dist` tree); vitest 1715 passed / 20 skipped / 1 todo;
`nx lint core` green; `check-declaration-closure` stripped-but-referenced=0;
closure fixtures 3/3; `nx run-many -t build --all` with only the documented
`demo:build:production` noise.

#### Matrix corrected at `cd49e9a0` — and it found a live defect

Review of `9f0d1464` caught the matrix doing three things a PERMANENT gate must
not do. All three are fixed; the deletion at `6a515699` is unaffected and
stands.

| defect                                                 | why it was wrong                                                                                                                                                                                     |
| ------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| froze `SignalTree<T> === ISignalTree<T> & TreeNode<T>` | freezes a decomposition queue item 7 schedules for DELETION; the file would contradict the plan and have to be edited by the slice doing the work                                                    |
| `declare const primitiveTree: SignalTree<number>`      | measured that an ANNOTATION is expressible and called it a product contract. The constructor is `T extends object`. Rule 0 category error, and it committed the release to a capability nobody chose |
| every row used `declare const … : SignalTree<T>`       | proved only "given a value already typed `SignalTree<T>`, these semantics follow" — never that a consumer calling `signalTree()` gets them                                                           |

The rule this establishes for every future contract matrix:

> Assert what a consumer can DO. Never assert the implementation decomposition,
> and never assert a capability merely because the type system can express it.

**LIVE DEFECT found the moment the constructor path was measured.** The
canonical annotation does not accept the documented constructor:

```ts
const tree: SignalTree<MyState> = signalTree({ ... }); // does NOT compile
```

There are **TWO independent mismatches**, and the second is invisible until the
first is neutralized. This was nearly recorded as "`bind()` is the ONLY
incompatibility" on the strength of one elaborated error — a proxy for a
property it does not measure, since **TypeScript stops at the first decisive
member incompatibility**. The one-variable experiment refuted it.

| #   | mismatch                                                                                                                       | which side is wrong                                                                                                                                  |
| --- | ------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | builder `bind()` -> `(value?: S) => S \| void`; `ISignalTree.bind()` -> `NodeAccessor<S>`                                      | the **declaration**. Runtime copies the base tree's `bind` verbatim (`signal-tree.ts:1802`) and it returns `NodeAccessor<T>` (`signal-tree.ts:1365`) |
| 2   | `SignalTree<T>` = `ISignalTree<T> & TreeNode<T>` requires the STATE KEYS on the tree object; the builder does not declare them | the **annotation**. The runtime root has no state keys at all                                                                                        |

Mismatch 2 is the serious one and it inverts the first diagnosis. Executed
runtime probe on `signalTree({ count, tags, user })`:

```
Object.keys(tree)   []
tree.count          undefined
Object.keys(tree.$) [ 'count', 'tags', 'user' ]
```

Meanwhile `declare const t: SignalTree<S>; t.count` typechecks green as
`CallableWritableSignal<number>`. **The canonical public tree type promises a
root-level state surface that does not exist at runtime.** `types.ts` still
explains the `& TreeNode<T>` as "properties copied to the root callable ...
legacy consumers rely on this"; that copying does not happen for state keys —
the only copy loop in `signal-tree.ts:1762` copies ENHANCER result keys.

So `SignalTreeBuilder` is HONEST and `SignalTree<T>` OVER-PROMISES. Making the
builder satisfy the annotation as written would mean inventing a root surface
the design deliberately puts behind `$`. Mismatch 1 alone is the drift class
`internals/builder-types.ts` documents for `destroyed`, `registerCleanup` and
`updateAndReport` — each runtime-present but type-missing, each repaired
separately, each caught by an accident rather than a gate. Matrix section B6 is
now that gate. `name` is absent from the missing-property list only because a
function already has `Function.prototype.name`.

Corroborating, and it may matter more than either defect: **nothing in this repo
or its docs annotates with `SignalTree<T>`.** Every call site infers from
`signalTree()`; the only `: SignalTree<` outside the matrix is one RFC
signature. A "canonical public tree type" that no code uses, that rejects the
constructor's return, and that describes a runtime shape which does not exist is
a candidate for being the wrong abstraction rather than a broken one.

#### DECIDED and CLOSED — `243dd5fb`, `215568cb`

**Decision: keep `SignalTree<T>` as the sole canonical consumer type, remove the
false root surface, align builder `bind` separately, prove constructor
assignability positively.**

Landed as two commits, one variable each, in that order:

| commit     | one variable                                        | proven result                                                                                                                                        |
| ---------- | --------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `243dd5fb` | `SignalTree<T>` -> `ISignalTree<T>`                 | assignment still RED; sole remaining blocker is now exactly `bind(...)(...)` returning `void \| RootState`, verified by reading the elaborated error |
| `215568cb` | `SignalTreeBuilder.bind` -> `NodeAccessor<TSource>` | assignment GREEN, no `@ts-expect-error`                                                                                                              |

Endpoint now asserted positively in matrix section C:

```
runtime grammar      tree.$
public annotation    tree.$
constructor return   satisfies the public annotation
bind runtime/type    aligned
```

**Rejected — root property copying.** Adding state keys to the runtime root
would create `tree.count()` alongside `tree.$.count()`: two ways to address one
node, the duplicate grammar this API deliberately does not have. It also
contradicts the `$`-centric design every call site already uses.

**Rejected — deleting `SignalTree<T>`.** That it is barely annotated in-repo is
weak evidence: local code relies on inference, while a public library still
needs a nameable type for `function inspect(tree: SignalTree<AppState>)` and
`interface Store { tree: SignalTree<AppState> }`. Deleting it would leave
consumers choosing among `SignalTreeBuilder`, `ISignalTree`, or
`ReturnType<typeof signalTree>` — the opposite of one obvious path per concept.

Settled ontology:

```
SignalTree<T>          public semantic tree contract   <- the name that survives
SignalTreeBuilder<…>   construction / inference machinery
ISignalTree<T>         implementation vocabulary, queued for internalization
TreeNode<T>            the shape behind tree.$
NodeAccessor<T>        semantic branch/root callable
```

`SignalTree<T> = ISignalTree<T>` is the correct CURRENT REPRESENTATION, not the
final algebra. The docblock says so explicitly, because item 7 internalizes
`ISignalTree` BEHIND `SignalTree` — `SignalTree` is not the thing that
disappears.

**Wording that must not be collapsed.** The two mismatches pointed in OPPOSITE
directions and the loose phrase "the builder is honest" was wrong as a general
statement:

```
root-state mismatch   SignalTree<T>          OVER-promised
bind mismatch         SignalTreeBuilder      UNDER-promised
```

**FROZEN — state is addressed through `$`, and only through `$`.** Matrix
section A1 now holds `@ts-expect-error` rows for `tree.count` / `tree.user`
beside green `tree.$.count()` / `tree.$.user()`, so the root surface cannot
return by a re-added `& TreeNode<T>`, by runtime property copying, or by any
other route.

**What no other gate could have caught.** `api-inventory --check` was CLEAN
across both commits — the symbol set never changed, and it structurally cannot
see a type-shape change. A public type was describing a different API grammar
from the runtime and typechecking access to properties that do not exist. This
is the case for the type-contract dimension existing at all.

#### Newly discovered — not this slice

- **The `6e7bf16a` "Measured public surface" table above is stale.** It records
  core 209 / `ng-forms` 34 / internal-decl 17; the tracked baseline before this
  slice was core 207 / `ng-forms` 29 / internal-decl 19. The table is labelled
  with its commit and is left as the historical measurement it is — but do not
  cite those numbers as current. `tools/api-baseline.json` is the live figure.
- **`nx test core` swallows the vitest reporter output.** A failing run prints
  only "Running target test for project core failed" with no test name, at any
  `--output-style` and with `--verbose`. During this slice the nx-mediated suite
  alternated fail / pass / fail and Nx itself flagged the task as flaky, while
  three consecutive direct runs were green at the ledger's exact counts. So the
  known timing flakiness is confirmed, but it is currently UNDIAGNOSABLE through
  the documented command. `npx vitest run` from `packages/core` reports
  normally — the `ngModule null` failure applies to running from the repo ROOT,
  not from the package directory. This belongs with the Phase 5 flaky-spec item:
  a release gate that cannot say which test failed is not a usable gate.

### Slice 2 — `composeEnhancers` DELETED (`2f46115b`, `6c3d73a8`, `d09525d6`)

**DECISION, final.** `composeEnhancers` DELETE confirmed. It is an opaque
alternate composition grammar, not a runtime-equivalent helper. Consumer
characterization showed single-enhancer application is type-invalid;
multi-enhancer application loses accumulated additions; composed child enhancers
bypass canonical metadata/dependency validation and differ from chained
`.with()` for identity-replacing enhancers. Canonical replacement is ordered
`.with(a).with(b)`. Variadic `.with(...)` remains a separate later decision and
was NOT coupled to this.

Migration: `docs/guides/migration-v14-v15.md` (`2ae531c1`).

```
P1 REACHABILITY   declared lib/utils.ts; exported ONLY from ./authoring
                  (left the root barrel in v12). Zero internal consumers, zero
                  tests, zero package-to-package consumers, zero demo use.
                  Taught in ENHANCERS.md, skills reference, generated llms/SKILL.

P2 CAPABILITY     NOT equivalent. See the correction below.

P3 TYPE           broken in BOTH arities, DIFFERENTLY:
                    composeEnhancers(A)     cannot be applied at all — `T`
                                            infers from the RETURN and is then
                                            demanded as input, so the enhancer
                                            requires the additions it exists to
                                            add
                    composeEnhancers(A, B)  applies, silently erases every
                                            addition
                  Not "erasure in both". The distinction was a real finding.
```

**The taught example never compiled.** `ENHANCERS.md` imported `composeEnhancers`
from `@signaltree/core`, where it had not existed since v12, and passed enhancer
FACTORIES where enhancers are required (TS2345 + TS2769 when reproduced
verbatim). The adjacent "recommended" example was also wrong — it used a
variadic `.with()` that does not exist. Both replaced with a form that was
compiled before being written down.

#### CORRECTION — I claimed runtime equivalence and it was refuted (`d09525d6`)

`2f46115b`/`6c3d73a8` stated P2 as "no unique runtime capability" on evidence
covering only ordinary `signalTree()` with mutating enhancers. Two falsifiers on
the uncovered protocol boundaries both fired. History was NOT rewritten; the
wrong claim stays and `d09525d6` is the correction.

```
P2a  plannedSignalTree dependency validation
     separate  .with(late).with(early).build()
               THREW "late requires base to be applied first", log ["early"]
               -> fail-CLOSED, `late` never ran
     composed  .with(composeEnhancers(late, early)).build()
               ok, log ["late","early"]
               -> fail-OPEN, ran with its requirement unmet

P2b  identity-replacing enhancer
     chained   2nd enhancer observed {symbol: null, prop: null}; final: neither
     composed  2nd enhancer observed {symbol: set, prop: true}; final: both
```

The guard lives INSIDE `.with()` and runs before the enhancer is invoked. A
composed fold calls its children directly, so they never reach it — no duplicate
detection, no dependency validation, no ordering, no capability collection. The
metadata-hiding was also an accidental escape hatch for forcing raw source order;
removed deliberately, since an undocumented way to defeat a fail-closed check is
not a feature and nothing used it.

**THE LESSON, and it was paid for twice in this chapter:**

> A green representative example does not prove equivalence of two API paths.
> Test the protocol boundaries where their implementations differ.

The first instance was `SignalTree<T>` (Section A and Section B both green while
they disagreed — fixed by a positive JOIN assertion). The second is this one.

NOT MEASURED, and not an open prerequisite: whether composing also hid child
CAPABILITIES from `buildTreePlan`. The probe could not observe the build plan.
Reopen only if a concrete item-#3 decision depends on it.

#### ROUTED FORWARD — enhancer metadata defect, item #3 owns it

`requires` currently resolves against two different namespaces:

```
resolveEnhancerOrder   edge only when `a.provides.has(req)`   -> CAPABILITY
.with() guard          `appliedEnhancers.has(req)`            -> NAME
```

so a requirement is satisfiable only when an enhancer is BOTH named `x` AND
declares `provides: ['x']`. Measured across all four spellings:

| `requires` | provider `name` | provider `provides` | result        |
| ---------- | --------------- | ------------------- | ------------- |
| `base`     | `provider`      | `['base']`          | THROWS        |
| `provider` | `provider`      | `['base']`          | THROWS        |
| `provider` | `provider`      | `['provider']`      | OK, reordered |
| `base`     | `base`          | `['base']`          | OK, reordered |

Both natural spellings fail. Characterized in
`packages/core/src/lib/planned-enhancer-dependencies.spec.ts` as **CURRENT
BEHAVIOUR, NOT FROZEN SEMANTICS** — the file carries a DO-NOT-FREEZE banner
saying that if those rows go red because the namespace was made coherent, the
TESTS get updated, not the implementation. That file also pins the durable
guarantee worth keeping: dependency validation is fail-closed.

### Item #3 opening measurement — `requires` has no coherent semantic owner

Item #3 starts here, NOT with `batching`. The metadata inconsistency sits
underneath the protocol the built-ins participate in, so the contract has to be
settled before nine signatures are migrated to target it.

**PROPERTY: what does `requires: ['x']` semantically name?**

```
A  enhancer identity / name
B  provided capability
C  something else explicitly modelled
```

Measured against docs, metadata types, built-ins, the ordering implementation,
the validation guard, and the third-party authoring contract — NOT inferred from
the field names.

#### The concepts, separated

| field          | type               | consumed by                                                       | means                                                                         |
| -------------- | ------------------ | ----------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `name`         | `string`           | `.with()` duplicate detection, `.with()` dependency guard         | identity                                                                      |
| `provides`     | `string[]`         | `resolveEnhancerOrder` edges                                      | capability token                                                              |
| `requires`     | `string[]`         | `resolveEnhancerOrder` (as CAPABILITY), `.with()` guard (as NAME) | **two authorities, disagreeing**                                              |
| `capabilities` | `TreeCapability[]` | `buildTreePlan` -> `collectRequestedTreeCapabilities`             | tree SUBSTRATE capability — a separate, typed axis; not part of this question |
| `description`  | `string`           | docs only                                                         | —                                                                             |

#### Evidence — every source says CAPABILITY except the guard

```
docs/guides/custom-enhancers.md:22-24
    provides: ['myEnhancer'],   // "Capabilities this enhancer adds"
    requires: ['serialization'] // "Capabilities that must be applied first"

docs/guides/custom-markers-enhancers.md:770-773   <- the decisive one
    { name: 'withAudit', provides: ['audit'], requires: ['logger'] }
    name != provides, and the comment reads
    "Requires withLogger to be applied first"

packages/core/src/enhancers/index.ts:20-22  (createEnhancer JSDoc)
    { name: 'myEnhancer', provides: ['feature1'], requires: ['feature2'] }
    name != provides
```

**Two of those three documented examples CANNOT WORK TODAY** — same class as the
`composeEnhancers` example slice 2 found. `withAudit` requires `'logger'`, which
under the guard needs an applied enhancer NAMED `logger`; the enhancer that
provides it is named `withLogger`. It throws.

**Proven on a REAL built-in, not a fixture.** `persistence` declares
`{ name: 'persistence', provides: ['persistence', 'serialization'] }` — a
capability it does not own as a name. Applying it and then an enhancer declaring
`requires: ['serialization']`:

```
plannedSignalTree({count:0}).with(persistence({key})).with(consumer).build()
  -> THREW: Enhancer "consumer" requires "serialization" to be applied first
```

The capability a shipping enhancer advertises is not honoured. `provides` is
consulted for ORDERING and ignored for VALIDATION.

**Why every built-in hides the defect:** all of them declare `name ===
provides[0]` (`batching`/`['batching']`, `devTools`/`['devTools']`,
`transactions`/`['transactions']`, `serialization`/`['serialization']`,
`restoration`/`['restoration']`). The accidental intersection is satisfied, so
nothing in-repo fails. `persistence` is the one built-in that declares a second
capability, and that second capability is exactly what does not work.

Historical note, not a proposal: `docs/archive/UPGRADE_TO_V6.md` used `provides`
for METHOD names (`['undo','redo','canUndo',…]`). The vocabulary drifted from
"methods added" to "capability token" without the guard following.

#### Backward-compatibility fact that constrains the decision

Today a requirement is satisfiable only when `provider.name === req` AND
`provider.provides` includes `req`. So today's working set is a SUBSET of both
candidate semantics — **A and B are each strictly backward compatible for
everything that currently works.** Nothing in-repo breaks under either. The
choice is therefore about which contract is correct, not about migration risk.

#### DECISION REQUIRED — see the session report

Recommendation is **B (capability)**, with `name` retained as identity for
duplicate detection only. Under A, `provides` loses its only consumer and
becomes vestigial, and all three documented authoring examples stay wrong.

Do NOT keep the current intersection. "Satisfiable only when the provider is
both NAMED x and PROVIDES x" has no coherent semantic owner and forces authors
into a redundant spelling to make dependencies work at all.

`planned-enhancer-dependencies.spec.ts` records the current behaviour and is
banner-marked DO NOT FREEZE; its two DEFECT rows are EXPECTED to go red when this
is resolved.

### NEEDS RECONCILIATION — "guardrails dead in prod"

Investigated: `@signaltree/guardrails` root resolves to `dist/noop.js` under the
`production` export condition, documented at `README.md:66-77`, with `default`
deliberately mapping to the REAL implementation so a bundler setting neither
condition gets the functional build. The rules measured are authoring-time
architectural diagnostics (`noDeepNesting`, `noFunctionsInState`,
`noCacheInPersistence`).

**No correctness defect demonstrated. The production no-op is intentional,
documented package behavior.** That is deliberately weaker than "loses nothing a
consumer depends on" — not every supported build environment has been shown to
select the intended branch, and rule names do not prove nobody relies on them as
enforcement. The original ledger item must either identify a narrower failing
invariant or be retired with evidence. Do not silently convert it to "false".

The real finding is API hygiene, queued above: `./noop` is separately public
though users should never select it themselves.

## 14.x DISPOSITION LEDGER (Rule 0f)

**Two axes, not one label.** A finding can be both a defect 14.x users are
living with AND a surface 15.0 removes; collapsing those understates the first.

```
14.x ACTION   PATCH CODE | PATCH DOCS / KNOWN ISSUE | NEEDS CONSUMER PROOF | NO ACTION
15.0 DISP.    INHERIT PATCH | BREAKING CORRECTION | ARCHITECTURAL CUTOFF | TOOLING DEBT
```

**Every first-column claim below was measured AT THE `v14.1.1` TAG**, not
inferred from 15.0-dev HEAD. That distinction is load-bearing: this queue has
twice produced a wrong conclusion by characterizing HEAD and reasoning backward
about an older release. Method: `git show v14.1.1:<path>` and compare the
decisive lines.

| Finding                                                                                    | Verified at `v14.1.1`                                                                                                                                                                                                                            | 14.x action                                                                            | 15.0 disposition                                                |
| ------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------- | --------------------------------------------------------------- |
| `requires` resolved against NAMES while the sorter matches `provides`                      | guard `appliedEnhancers.has(dep)`; sorter `a.provides.has(req)` (`enhancers/index.ts:91`) — the disagreement is real at 14.1.1                                                                                                                   | **PATCH CODE**                                                                         | inherit (`681ffb8e`)                                            |
| enhancer marked applied BEFORE it succeeds                                                 | `appliedEnhancers.add(meta.name)` precedes `return enhancer(tree)`                                                                                                                                                                               | **PATCH CODE**                                                                         | inherit                                                         |
| anonymous enhancer's `requires` silently ignored                                           | whole block gated on `if (meta?.name)`                                                                                                                                                                                                           | **PATCH CODE**                                                                         | inherit                                                         |
| `ENHANCERS.md` composition example cannot compile                                          | imports `composeEnhancers` from `@signaltree/core`, where `index.ts:303` carries only a REMOVAL COMMENT ("removed from the root barrel in v12"); also passes enhancer FACTORIES                                                                  | **PATCH DOCS**                                                                         | corrected docs continue                                         |
| `withAudit` guide example cannot work                                                      | `{ name: 'withAudit', provides: ['audit'], requires: ['logger'] }` — `name !== provides`, unsatisfiable under the name-based guard                                                                                                               | **PATCH DOCS**                                                                         | ditto                                                           |
| `createEnhancer` JSDoc example cannot work                                                 | `provides: ['feature1'], requires: ['feature2']` — same shape                                                                                                                                                                                    | **PATCH DOCS**                                                                         | ditto                                                           |
| builder `bind()` under-promise                                                             | `bind(thisArg?: unknown): (value?: TSource) => TSource \| void` (`builder-types.ts:70`)                                                                                                                                                          | **NEEDS CONSUMER PROOF** — see below                                                   | corrected (`215568cb`); SURVIVAL is a separate question, item 9 |
| false `SignalTree<T>` root-state surface                                                   | `export type SignalTree<T> = ISignalTree<T> & TreeNode<T>` (`types.ts:1297`)                                                                                                                                                                     | **PATCH DOCS / KNOWN ISSUE** — do not silently make a breaking type correction on 14.x | **BREAKING CORRECTION** (`243dd5fb`)                            |
| `composeEnhancers` broken types + bypass semantics                                         | implementation byte-identical (`utils.ts:377`)                                                                                                                                                                                                   | **PATCH DOCS / DEPRECATION** — see the warning below                                   | **ARCHITECTURAL CUTOFF** (`6c3d73a8`)                           |
| `SignalTreeBase`                                                                           | present (`types.ts:1298`); no defect                                                                                                                                                                                                             | **NO ACTION**                                                                          | **ARCHITECTURAL CUTOFF** (`6a515699`)                           |
| **identity-replacing enhancers silently disable the enhancer protocol**                    | `Object.defineProperty(enhancedTree, 'with', …)` in `batching.ts`, `time-travel.ts`, `devtools-impl.ts` — independently present in all three at the tag; the replacement `with` only type-checks its argument and calls `enhancer(enhancedTree)` | **PATCH CODE**                                                                         | **BLOCKS #3b** — see below                                      |
| stale generated API-surface docs                                                           | **NOT MEASURED at 14.1.1** — the staleness found was relative to HEAD source                                                                                                                                                                     | **UNCLASSIFIED**                                                                       | 15.0 cleanup (`7772effa`)                                       |
| `nx test core` unreliable + swallows the reporter; `api-inventory` member/shape blind spot | tooling, not a consumer contract                                                                                                                                                                                                                 | **NO ACTION**                                                                          | **TOOLING DEBT** — Phase 5                                      |

### BLOCKER for #3b — the enhancer protocol does not survive its own built-ins

Found while characterizing `batching` for #3b, before touching its signature.
**All three identity-replacing built-ins redefine `.with()` on their replacement
tree, and the redefinition carries no metadata guard at all.** Measured:

```
                              unsatisfied requirement    duplicate name
plain tree                    THROWS                     THROWS
after .with(batching())       no throw                   no throw
```

`batching.ts:355`, `time-travel.ts:2820`, `devtools-impl.ts:1733` — each
installs a `with` that validates only `typeof enhancer === 'function'` and then
calls `enhancer(enhancedTree)` directly. No duplicate detection, no dependency
validation, no capability publication.

This is the SAME defect class as `composeEnhancers` — a fail-closed check
bypassed by an alternate application path — and it **defeats the `681ffb8e`
repair in exactly the configurations most real apps use**, since batching,
devTools and restoration are the common enhancers. The protocol is disabled for
the remainder of the chain from the moment any of them is applied.

**Why this is not a #3b sub-task.** MEASURED: the bookkeeping
(`appliedEnhancerNames`, `providedEnhancerCapabilities`) is per-tree closure
state inside `create()`, and a replacement tree is a new object that does not
reach it. Also measured: the original `with` invokes `enhancer(tree)` against the
ORIGINAL receiver, so naive delegation would hand the enhancer the
pre-replacement tree.

HYPOTHESIS, NOT YET PROVEN — that the fix requires factoring the guard into a
reusable "apply against THIS receiver" operation sharing one tree's bookkeeping.
That is a candidate implementation shape, not a derived requirement. The
SEMANTIC requirement is proven; the implementation must be selected from the
falsifier matrix below, not assumed.

#### Falsifier matrix — run BEFORE choosing an implementation

Two independent properties, and an implementation can satisfy one while failing
the other:

```
1. protocol bookkeeping follows the semantic tree lineage across replacement
2. enhancer invocation uses the CURRENT realization, not the original receiver
```

```
A  provides[cap] -> REPLACE -> requires[cap]          must PASS
B  REPLACE -> provides[cap] -> requires[cap]          must PASS
C  REPLACE -> requires[missing]                       must FAIL before it runs
D  REPLACE -> A -> A                                  duplicate must FAIL
E  REPLACE -> throwing provides[cap] -> requires[cap] contributes NEITHER
F  REPLACE -> B                                       B receives CURRENT tree
G  provider -> batching -> restoration -> requires[provider cap]
                                                      survives MULTIPLE handoffs
```

G matters because a fix that repairs only the first replacement would pass A-F.

**Recommended sequencing — do NOT fold this into #3b.** It is a shared-protocol
defect, not a per-enhancer one, and #3b must not absorb fixes to other built-ins.
Treat it as `#3a-2`, the same shape as `#3a`: repair the protocol first, then
migrate built-ins onto a protocol that is actually coherent. Migrating
`batching`'s signature while its runtime silently drops the protocol would type a
contract the implementation does not honour.

DECISION REQUIRED before proceeding — see the session report.

### Do NOT "repair" `composeEnhancers` runtime semantics in a 14.x patch

Making it traverse the canonical `.with()` boundary instead of invoking children
directly would change ordering, dependency-validation outcomes, duplicate
detection and identity-replacement behaviour. That is a semver-BREAKING change
wearing a bug-fix costume. A documentation/deprecation patch discharges the 14.x
maintenance obligation; deletion stays the 15.0 answer.

### Required postcondition for the enhancer-bookkeeping patch

```
validate prerequisites -> invoke enhancer -> enhancer SUCCEEDS -> publish
                                                                  identity +
                                                                  capabilities
```

A throwing enhancer must contribute NEITHER identity NOR capabilities.

### `bind()` — NEEDS CONSUMER PROOF, and the question is bigger than the type

Do not classify this as a 14.x type defect yet. Repairing the declaration of a
surface 15.0 may delete would MANUFACTURE a 14.x contract rather than honour
one. Sequence:

```
Is bind() an independently supported 14.x CONSUMER contract?
  NO  -> internalize/delete question; do not "fix" its declaration on 14.x
  YES -> characterize the real public semantics, THEN ask whether the
         declaration is defective and patchable
```

An apparently more accurate declaration can still be breaking under TypeScript
assignability, so a real 14.x consumer matrix is required either way.

**Measured, and it is why this is not routine cleanup.** Every meaningful use is
one pattern — capture the original callable, then replace tree identity —
at `batching.ts:305`, `devtools-impl.ts:1670`, `time-travel.ts:2134`, and taught
at `custom-markers-enhancers.md:800`. Two of those three CAST AROUND the declared
type (`as unknown as { bind: (t: unknown) => … }`), so the declaration was not
functioning as a contract for the code that needed it. And `bind` is the NAMED
cause of the variance failure that forced the fixed `EnhancerHost`
(`types.ts:1476`): `NodeAccessor<T>` has input positions, so `ISignalTree<Model>`
is not assignable to a host declaring `bind(): NodeAccessor<unknown>`.

So it intersects the callable-tree ontology AND the neutral enhancer boundary —
do not bury it beside `deepEqual`. The audit property for item 9:

> Does SignalTree semantically own a public "bound callable accessor" concept,
> or is `bind()` merely the mechanism enhancer realizations use to preserve the
> pre-wrapper invocation path?

Falsifier for deletion: a supported consumer behaviour that requires
`tree.bind(...)`, cannot be expressed through the canonical tree/authoring
contracts without loss, and is not merely machinery for wrapping the callable.

**NOT PROVEN, do not repeat as fact:** that a closure `(...args) => tree(...args)`
is semantically equivalent to `bind()`. That was asserted in session and
retracted — it needs a real falsifier over read/update call forms, mutation
context and metadata, identity-replacement behaviour, `this` semantics, and the
wrapper's property/prototype copying.

### Branch mechanics are execution, not classification

A live 14.x maintenance branch is NOT required to classify. Prove the defect
against supported 14.x source first; create the branch from the latest supported
14.x state when patch work is actually scheduled.

## Item #4 — DISCOVERY COMPLETE, neither deletion earned yet

Two independent claims, measured separately. Neither is clean, and one of them
corrects a claim I made in `7a6bd4c9`.

### A — delete the realization-facing `.with()` overload: NOT EARNED

Measured by REMOVING the overload from both `ISignalTree` and
`SignalTreeBuilder` and building the workspace. Four public enhancers in three
packages still require it, compiler-proven:

```
ng-forms    formBridge   <T>(tree: ISignalTree<T>) => ISignalTree<T> & AngularFormsMethods
schema      schemas      <T>(tree: ISignalTree<T>) => ISignalTree<T> & SchemaMethods
guardrails  guardrails   <Tree extends ISignalTree<any>>(tree: Tree) => Tree & {…}
```

**`realtime` / `supabaseRealtime` are concrete-tree too but did NOT surface** —
every `.with(...)` call site for them is inside JSDoc, so no compiled consumer
exercised them. That is INFERRED, not proven, and needs its own type-contract
test: "no build caller happened to instantiate it" is not evidence that a public
declaration is safe.

**Measurement lesson worth keeping:** a literal-shape grep is not an exhaustive
public-type falsifier. `guardrails` was missed by searching for
`(tree: ISignalTree<T>) => ISignalTree<T> &` because it expresses the same
semantic dependency through a generic constraint,
`<Tree extends ISignalTree<any>>(tree: Tree) => Tree & …`. The compiler was the
direct measure; the text search was a proxy.

### B — delete the three built-in `.with()` overrides: TRUE FOR TWO, FALSE FOR ONE

```
batching    pure forwarder                      -> vestigial, safe to delete
restoration  pure forwarder                      -> vestigial, safe to delete
devTools    forwarder + composition reporting   -> NOT vestigial
```

`devtools-impl.ts`'s override pushes the enhancer name onto a `compositionChain`,
calls `trackComposition(...)`, and sends a `SignalTree/with` action to Redux
DevTools. Found because deleting it made `compositionChain` an unused variable —
lint caught what reading one sibling's body had not.

**CORRECTION to `7a6bd4c9`.** That commit stated "Overwriting the built-ins'
`with` loses nothing — theirs only forwarded." That is true for two of three and
FALSE for `devTools`. The claim came from reading `batching`'s body and
generalizing. History is not rewritten; this entry and the corrected comment in
`signal-tree.ts` are the current authority.

**MEASURED (#4c-1) — `7a6bd4c9` IS A REGRESSION.** The first probe was vacuous:
it captured zero both before and after because it never flushed
`scheduleSend`'s `queueMicrotask` + rate-limit timer. A corrected probe installs
the fake extension on `window` (not `globalThis`), awaits both flush stages, and
carries a CONTROL — an ordinary state write that must produce a send, so another
zero cannot be mistaken for a result:

```
                    connected  total  types                        SignalTree/with
7a6bd4c9~1          true       2      ["", "SignalTree/with"]      1
current HEAD        true       2      ["", "SignalTree/n"]         0
```

The control fires at HEAD (`SignalTree/n` from the state write), so the
connection is live and the zero is real. Composition tracking WORKED before the
canonical-`with` adoption and does not now.

Scope: `7a6bd4c9` is unreleased 15.0-dev, so this is NOT a 14.x defect and needs
no 14.x patch — 14.1.1 never had the adoption. It is a 15.0 regression to fix
before release.

Note the pre-fix run reported 1, not 2, for two `.with()` calls: `scheduleSend`
clobbers a second pending explicit action rather than queueing it. That is
pre-existing rate-limit behaviour, unrelated to the adoption, and is not
something this slice changes.

### Sequencing — Gate B may NOT freeze with the overload still present

Retaining a second `.with()` authoring grammar whose only justification is
"some packages have not migrated yet" is exactly what Rule 0e forbids. The
external migrations are therefore on the Gate B critical path, not deferrable.

```
#4c-1  DONE — regression confirmed, then RESOLVED BY DELETION. Burden of proof
       was on keeping and was not met: 0 docs, 0 tests, absent from
       DevToolsMethods and the api-baseline, reachable only via the `__devTools`
       escape hatch. Deleted rather than rescued with an observation hook.
#4a    migrate the external concrete-tree enhancers, ONE AT A TIME
       guardrails / schema / realtime / ng-forms  (item #3 is CLOSED for core;
       this is not reopening it)
#4b    delete the realization overload — only once every public consumer is neutral
#4c    DONE — devTools composition reporting deleted (`a8fbee3a`), then all
       three overrides deleted; canonical `.with()` is the sole owner
#5     variadic .with(...)
```

If one of the four cannot be represented honestly as `Enhancer<TAdded>` without
degrading inference or semantics, STOP — that is a Gate B architecture decision.
Do not keep the overload merely to avoid answering it.

**Endpoint for devTools — the factual half is now settled; the ownership half is
a DECISION.** The tracking is real and currently broken. Keeping a DevTools-owned `.with()` override would restore two
owners immediately after establishing one. The shape that preserves both
properties is `.with()` owning application and DevTools OBSERVING it through a
hook — not DevTools replacing `.with()` to learn that application happened.

## MUT — the 15.0 mutation participation model (DERIVATION SLICE, no production changes)

**Method rule for this slice, and it is the one that keeps being violated:**

> Derive the contract from the frozen semantic model FIRST. Then determine what
> kernel changes are required to satisfy it. Do NOT let what the kernel happens
> to emit today define what the contract can promise — that turns implementation
> limitations into architecture by accident.

### TWO RETRACTIONS before anything is built on them

**R1 — `PathNotifier` is NOT "the greenfield observation boundary".** It is a
CANDIDATE SUBSTRATE. It has attractive ingredients — `MutationEnvelope` carries
semantic identity, the class imports zero Angular, and `emitOwnedMutation`
already forwards envelopes into it — but the join test is decisive against
promoting it: **ordinary leaf writes produce ZERO events through it**, with or
without `restoration()`. Calling it "already exists" would repeat the exact error
this queue keeps making: promoting a discovered implementation into the
architecture before its semantics are shown to match the endpoint.

**R2 — `PathNotifierInterceptor` is NOT a PREPARE contract.** Establishing this
from call ORDER rather than from the shape of its return type:

```
runOwnedMutation:  read before -> apply()  -> read after -> emitOwnedMutation
emitOwnedMutation: ... -> notifier.emitMutation(envelope)
emitMutation:      notify(path, envelope.after, envelope.before, …)
```

`envelope.after` is produced by reading AFTER `apply()`. So interceptors are
consulted once the physical mutation has already happened. `{ block, transform }`
is a SYNTACTIC property; running before any live mutation is the SEMANTIC
property of PREPARE, and this does not have it. It may be old-architecture
vocabulary whose semantics never fit the frozen lifecycle.

### What IS established

```
SCHEMA'S REQUIREMENT (measured from its callback)
  needs      path, next value, metadata (intent/source/suppressGuardrails)
  ignores    previous value (`_prev`)
  semantics  OBSERVE-ONLY, never rejects writes

  -> schema needs NO PREPARE participation. That narrows the problem.
  -> but "post-commit" is not yet precise enough: after PRIVATE COMMIT, after
     PROJECT, or after PUBLISH are no longer interchangeable. To be DERIVED.
```

```
CURRENT REALITY (measured)
  plain leaf at HEAD    no intrinsic emitter, no owned positionIds
  interceptLeafSignals  does not wrap the leaf's `.set` at all
  PathNotifier          zero events for plain leaf writes
  emitOwnedMutation     early-returns when positionIds[0] is undefined

  -> ordinary leaf writes participate in NO observation contract today.
```

```
SUBSTRATE FACTS (candidate ingredients, not endorsements)
  MutationEnvelope      positionId, path, ownerPath, before, after, kind,
                        subjectId, structural, attribution
  PathNotifier          zero Angular imports
  subscribe handler     EIGHT POSITIONAL ARGS — flattens the envelope; kind,
                        structural and attribution structure are lost
  getPathNotifier()     PROCESS-GLOBAL SINGLETON; consumers filter other trees
                        themselves (time-travel does exactly this)
```

### DEMO EVIDENCE — what a real application actually reaches for

Measured by parsing every `import { … } from '@signaltree/*'` in
`apps/demo/src` (excluding specs), multi-line aware. **METHOD NOTE:** the first
attempt used a single-line regex and silently missed multi-line imports —
including `guardrails`, which it reported as unused. Corrected before any
conclusion was drawn. This is evidence about CURRENT DEMO USAGE, which is one
signal about function, not proof of it.

**The authoring SDK is barely used by an application.** Six symbols, once each:

```
onHydrateDecision, onTreeError          observation hooks
createEnhancer, ENHANCER_META,
  resolveEnhancerOrder                  enhancer authoring
registerMarkerProcessor                 marker authoring
```

That is 6 of ~36 `./authoring` exports.

**ZERO demo usage — the symbols this whole MUT investigation is about:**

```
interceptLeafSignals     0     the mechanism schema depends on
getPathNotifier          0     the candidate observation substrate
withWriteContext         0
getActiveWriteContext    0
```

No application reaches for leaf interception, the notifier, or write context.
They are used only by core internals and by `@signaltree/schema`'s
implementation.

**OVERCLAIM CORRECTED.** This previously read: "if the only consumers of a
public observation protocol are the library's own internals, it is not serving
an authoring function." **That does not follow.** An authoring SDK is precisely
the kind of API that may have near-zero ordinary application usage —
`registerMarkerProcessor` and `createEnhancer` are obvious cases, and the demo's
own usage is dominated by higher-level APIs exactly as it should be. The
supportable inference is narrower:

> Zero demo usage removes **"ordinary application need"** as a justification.
> It does NOT remove **"third-party implementer need"**.

Which is what MUT-0 exists to determine.

**Other zero-usage results relevant to the survival audit:**

```
plannedSignalTree        0     the second construction concept
transactions             0     as an enhancer import
asReadonly               0
isSignalTree             0
```

**Counter-evidence worth recording — things a real app DOES use:**

```
ISignalTree              5 files   <- MIGRATION IMPACT, not a keep-argument.
clearStoragePrefix       1
flushAllStoredSignals    1         <- the three "global authority" symbols
invalidateTag            1            already flagged as suspicious: each has
                                      exactly one real consumer.
```

**EVIDENCE HIERARCHY — demo usage is a witness, never the judge.**

```
GREENFIELD FUNCTION
      -> required semantic owner
      -> does third-party implementation require access?
      -> minimum public capability
      -> existing consumers / demo usage as SUPPORTING evidence
```

NOT `demo uses it -> keep` / `demo doesn't -> delete`. That methodology would
delete the extension SDK of almost every library.

**`ISignalTree` is the worked example of doing this correctly.** Five demo files
import it — and the answer is still not "keep":

```
used by real consumers?                 YES  (5 files)
semantic concept independently needed?  YES
correct 15.0 owner?                     SignalTree<T>
=> migrate consumers, DELETE the ISignalTree public vocabulary
```

The usage count sized the migration. It did not decide the architecture.

**ng-forms shape — evidence for the adapter hypothesis:**

```
signalForm      6 files   from @signaltree/ng-forms/signals
createFormTree  2
ngFormValidators 2
formBridge      2         <- the ENHANCER is the least-used entry point
```

**OVERCLAIM CORRECTED.** Usage frequency cannot establish ontology. It tells us
consumers reach for the Angular-facing APIs more often; it does NOT tell us
`formBridge` has the wrong ontology. The audit question is functional:

> What function does `formBridge` provide that `signalForm` / the Angular
> adapter does not?

```
merely bridges realization into Angular Forms  -> Angular adapter owns it
independently adds semantic tree capability    -> enhancer may be correct
redundant with signalForm                      -> DELETE
```

What the frequency DOES support is refusing the reverse error: do not force
`formBridge` through `Enhancer<TAdded>` merely to enable deleting the
realization overload. That would let a deletion procedure drive the ontology.

### MUT-0 — GREENFIELD SURVIVAL INVENTORY (runs BEFORE MUT-2)

**THE RULE THIS SLICE ENFORCES:**

> Existing code may prove a FUNCTION is useful. It may NEVER prove its current
> ABSTRACTION is necessary. Derive function and ownership with the current API
> names HIDDEN; reveal the existing mechanism only after the greenfield
> requirement is stated.

**TWO SEPARATE VERDICTS, never conflated.** A concept can be perfectly
implemented and still be DELETE:

```
CORRECTLY IMPLEMENTED?     <- what the last ~150 commits proved
NECESSARY?                 <- what MUT-0 asks
```

This applies with FULL FORCE to work already converted. `Enhancer<TAdded>` being
neutral and coherent does not establish that it belongs in 15.0. Declaration
closure being correct does not justify every shipped declaration. Authoring
being framework-neutral does not prove every authoring symbol belongs in the
extracted package. Those proofs remain valuable and are not reopened — they
simply answer a different question.

#### Template — CURRENT FORM is filled in LAST, deliberately

```
FUNCTION            what capability must exist?
OWNER               which frozen 15.0 authority naturally owns it?
PUBLIC NEED         must a THIRD-PARTY IMPLEMENTER have access?
                    why can SignalTree not own the integration itself?
MINIMUM PRIMITIVE   smallest capability that provides the function
CURRENT FORM        <- LAST. Prevents designing around PathNotifier,
                       Enhancer, formBridge, etc. by reflex.
DISPOSITION         KEEP / INTERNALIZE / MOVE / SPLIT / DELETE / UNPROVEN
```

`PUBLIC NEED` is the question the demo evidence cannot answer and MUT-0 must:
zero application usage removes "ordinary application need", never "third-party
implementer need".

#### Three levels of need — never collapse them

```
CORE-INTERNAL          core needs it; no contract crosses a package boundary
FIRST-PARTY PACKAGE    schema/realtime/ng-forms need it; may justify an
                       INTERNAL SHARED contract, NOT a public protocol
THIRD-PARTY SDK        arbitrary extension authors need it; only this level
                       justifies public authoring surface
```

`@signaltree/schema` being separately published does NOT prove third-party need.
Demo evidence cannot answer any of these; first-party consumption cannot answer
the third.

#### Order — highest architectural gravity first, not alphabetical

```
1  SYNCHRONIZATION / INTEGRATION FUNCTIONS  (deliberately NOT named
   "observation" — that phrase pre-selects an abstraction)
2  Enhancer / createEnhancer / ENHANCER_META / resolveEnhancerOrder
3  schema integration
4  realtime integration
5  ng-forms / formBridge / signalForm
6  guardrails
7  persistence integration
8  devTools integration
9  plannedSignalTree
10 global storage / tag authorities
```

Then outward. The hypothesis worth testing first, because confirming it would
delete a large amount of machinery:

```
history / undo / redo / rollback  -> causal authority
transactions                      -> semantic/causal authority
persistence                       -> governed consequence
realtime                          -> governed consequence?
schema                            -> derived invalidation from committed truth
devtools                          -> diagnostic projection
Angular                           -> publication / reactivity
ng-forms                          -> Angular adapter?
```

None of those rows obviously requires `observeEveryMutation(callback)`. If they
all place cleanly with their owning authority, the generic observation concept
disappears rather than being redesigned.

Conversely, if a genuine third-party function emerges — e.g. "a custom semantic
extension must be notified when its registered positions participate in a
settled semantic transaction" — then a public capability IS proven, and can be
designed at minimum size without inheriting 14.x form.

### ANGULAR SUPPORT RANGE — **DECIDED: 21 and 22. Angular 20 excluded.**

**MY FRAMING OF THIS WAS WRONG AND IS RETRACTED.** `a52f0124` said:

```
IF 22+ ONLY -> the Reactive Forms function falls outside the product boundary
            -> formBridge becomes a DELETE candidate
```

**That does not follow.** It conflates THREE independent things:

```
framework version   which Angular majors we support
forms paradigm      Reactive Forms vs Signal Forms vs Template-driven
SignalTree form     enhancer vs adapter
```

Reactive Forms is a **current, supported, distinct forms system in Angular 22** —
not a legacy path being replaced by Signal Forms. Angular's own guidance
presents them as different approaches for different cases, recommending Signal
Forms for new signal-based apps while existing Reactive Forms apps continue on
Reactive Forms. So SignalTree-to-`FormGroup` interoperability is a legitimate
greenfield requirement **on every supported major**, including 22-only.

That makes the subtraction result STRONGER, not weaker: **the Reactive Forms
function is independent of Angular-major compatibility.** The range determines
whether a SECOND forms integration is available, never whether the first has
value.

**SECOND CORRECTION — "/signals has a hard Angular 22 requirement".** Signal
Forms exist in Angular 21+; they became STABLE in 22. The repo's own comment
says so precisely — _"`@angular/forms` ships **stable** Signal Forms via the
`./signals` subpath starting in v22.0.0"_. So the boundary is **SignalTree
PRODUCT POLICY** — do not build a stable integration contract on an Angular API
that did not yet carry Angular's stability guarantee — not a technical absence
in 21. Defensible, but it must be stated as policy.

#### The decision

```
@signaltree/*                    peer Angular ^21 || ^22
Angular 20                       OUT of the 15.0 product boundary
Angular 21                       supported
Angular 22                       supported, primary development target
@signaltree/ng-forms/signals     UNRESOLVED after schema-route deletion; current
                                 package manifest publishes no such subpath
```

**Rationale is PRODUCT HORIZON, and note it is the compatibility-UNfriendly
choice** — supporting another major would be the easier path, so Rule 0h is not
being violated in reverse. Angular support status, as supplied by the reviewer
from Angular's published release page (external evidence, not measured by me):

```
Angular 22   Active   active to June 2027, LTS to June 2028
Angular 21   LTS      to June 2027
Angular 20   LTS      to 28 November 2026
```

Shipping a greenfield major in August 2026 built around a version that goes
unsupported in ~3 months creates immediate legacy obligation. Angular 21 remains
supported to June 2027, so excluding it would discard a real supported user base.

#### Resulting product

```
Angular 21    SignalTree + Reactive Forms integration
Angular 22    SignalTree + Reactive Forms integration + Signal Forms integration
```

#### Consequence for `formBridge` — the FORM is still UNPROVEN

```
FUNCTION      SignalTree <-> Angular Reactive Forms interoperability
              SURVIVES, on BOTH supported majors, independent of the range
CURRENT FORM  an ENHANCER mutating a tree to add `AngularFormsMethods` and a
              Map<string, AngularFormBridge>
              UNPROVEN under Rule 0g — the subtraction test proved the function
              and did NOT rescue the form
DISPOSITION   REDESIGN CANDIDATE
```

**The next test, with the name erased:** given the 15.0 kernel, the Angular
publication architecture, and a requirement to interoperate with
`FormGroup`/Reactive Forms, what would we build today?

```
SUSPECTED (unproven)        vs        CURRENT
SignalTree truth                      tree.with(formBridge())
   -> Angular publication                -> mutate SignalTree realization
   <-> Reactive Forms adapter            -> add getAngularForm(), bridge Map
   <-> FormGroup / FormControl
```

An adapter over published realization may be the kernel-native answer. That must
be DERIVED, not assumed — and it bears directly on #4a, where migrating
`formBridge` to `Enhancer<TAdded>` would be converting a form that may not
survive.

**Realtime R0 is UNBLOCKED** — the Angular conditional no longer hangs over the
inventory.

### V1.1 — DOES A FIRST-PARTY VALIDATION FACILITY SURVIVE? — **NO COUNTEREXAMPLE FOUND**

```
NULL   SignalTree ships NO validation evaluator/package.
       A user reads a value/snapshot, passes it to their own validator/schema,
       and receives that validator's native result.

       What REQUIRED SignalTree workflow becomes impossible?
```

Four candidate counterexamples, no fifth escape hatch.

#### A — SignalTree-specific snapshot semantics — **FAILS**

Does validation require a coherent read that ordinary access cannot provide?
No. `tree()` and `tree.$.order()` already ARE coherent reads — the frozen
atomicity invariant guarantees no external consumer observes intermediate
heterogeneous state. Nothing new is needed, and per the corrected cross-field
model the owner of coherent multi-position reads would be READ SEMANTICS
anyway, not validation.

#### B — marker/kernel-aware meaning — **FAILS**

Is there a REQUIRED rule whose meaning cannot be represented by the resulting
snapshot? **MEASURED across REPRESENTATIVE structural / storage / status / async
marker classes** — not an exhaustive enumeration, and the claim does not need
one:

```
users  (entityMap)     {"all":[{"id":1,"name":"Ada"},{"id":2,"name":"Bob"}]}
load   (status)        {"state":"NOT_LOADED","error":null}
theme  (stored)        "light"
remote (asyncSource)   {"value":[]}
plain                  42
```

Markers flatten to plain data, and that data carries what rules judge: entity
collections arrive as arrays with their domain keys, status arrives with its
state, stored/async arrive as values. Uniqueness, existence, membership,
cross-entity and status-dependent rules are all expressible.

The one gap found — `asyncSource` snapshots `{value}` WITHOUT load state — is
**not a validation gap**. "Do not validate while loading" is about WHEN to
validate, not WHAT is valid, and the caller already decides whether to call.

**THE ARGUMENT IN ITS HARDER-TO-FALSIFY FORM**, which does not depend on
exhaustive coverage:

> **No established validation requirement needs MARKER IDENTITY rather than the
> VALUE exposed by the read surface.**

If a future marker carries semantically meaningful information omitted from its
value projection, that is a NEW counterexample to evaluate then. It does not
justify preserving a validation facility now.

#### C — issue-to-tree correspondence — **FAILS**

**CORRECTED — do NOT claim issues locate by "domain keys".** A validator's issue
path over that snapshot is typically structural, e.g. `all[0].name`. The entity's
domain key merely happens to sit INSIDE the value; it is not necessarily the
locator. The sufficient argument is narrower and does not depend on that claim:

```
explicit validation evaluates snapshot X
its issues describe snapshot X
no baseline requirement says those issues must retain SEMANTIC IDENTITY across
  future topology changes
```

That alone removes any need for `PositionId`, rekey-stable issue ownership, or
tree-addressed results. A later requirement that _"a result stays attached to
entity 42 across reorder/rekey"_ would be a CONTINUOUSLY MAINTAINED PROJECTION
and must be derived independently.

#### D — cross-format normalization — **FAILS, and it is the dangerous one**

Standard Schema ALREADY IS the cross-format interoperability boundary; that is
its entire purpose. SignalTree normalizing validator libraries on top of it adds
a layer over an existing standard.

> **"A normalized result shared across multiple formats" is the last refuge of a
> package whose real function has disappeared.** The question is not whether
> normalization is useful, but whether users need SIGNALTREE to normalize
> validation libraries — or whether SignalTree should support a standard
> validation interface and get out of the way.

#### RESULT — **PROPOSED REVERSAL of V0.6**

```
APPLICATION VALIDATION IS USEFUL              YES  (never in doubt)
SIGNALTREE MUST PROVIDE A VALIDATION FACILITY NO   (no counterexample found)
```

The honest 15.0 shape becomes:

```ts
const value = tree.$.order();
const result = await mySchema['~standard'].validate(value);
```

plus DOCUMENTATION showing validation libraries how to consume SignalTree truth.
V0's product decision is then satisfied without a package.

#### What this makes `@signaltree/schema`

Its measured surface does something `validate(value, rules)` does not: it
maintains a CONTINUOUS, per-path validation projection wired into the tree, with
`isValid`/`errors`/`pending` as live signals, using Angular's `signal`/`computed`.

**That extra function is exactly the one V0 excluded from the baseline** —
continuous currency, i.e. observation. And observation is Angular-owned.

```
FUNCTION       explicit validation of truth      -> user's own validator + docs
FUNCTION       CONTINUOUS validation projection  -> Angular observation layer
CURRENT FORM   Angular-coupled tree enhancer
               shipped as a SignalTree package   -> DELETE CANDIDATE
```

**CORRECTED — Angular-owned does NOT mean forms-adapter-owned.** I wrote that
the surviving function belongs "beside the two forms adapters". The first arrow
is supported; the second is not. An Angular app may reasonably want
`validation.errors()` / `validation.isValid()` in a component **without using
Angular Forms at all**.

```
ESTABLISHED    function: maintain an Angular-reactive validation projection over
                         SignalTree truth
               owner:    Angular observation / integration layer
NOT ESTABLISHED owner:   Reactive Forms or Signal Forms adapter
```

The forms adapters may CONSUME it; that does not make them its owner. Concluding
otherwise would repeat the same error in reverse — correctly pulling validation
out of SignalTree, then shoving all validation observation into "forms" because
forms happen to consume it.

```
@signaltree/schema PACKAGE                 DELETE CANDIDATE
explicit validation function               DELETE from the SignalTree product
                                           -> validator ecosystem + docs
continuous Angular validation projection   FUNCTION UNPROVEN; owner is the
                                           Angular layer IF it survives
current tree-enhancer form                 REJECTED
```

**Do NOT preserve the package while that question is open.**

### V0.6 — **REVERSED AND CLOSED**

```
APPLICATION VALIDATION IS USEFUL              YES
SIGNALTREE MUST PROVIDE VALIDATION            NO
KERNEL VALIDATION ONTOLOGY                    NONE
VALIDATION OBSERVATION                        NONE
NORMALIZED VALIDATION-RESULT ONTOLOGY         NONE

15.0 GUIDANCE
  read SignalTree truth
  -> validate with the validator/schema the application already uses
```

The last clause is load-bearing and comes from V1.1-D, probably the deepest
result of the slice: **Standard Schema already supplies interoperability.**
SignalTree wrapping validator ecosystems in a second normalized representation
would be an invented layer.

**THEREFORE THE V1 SCAFFOLDING IS ALSO DELETED — not parked as "maybe later":**

```
validate(value, rules)   Result   Issue   rules
```

Those were DERIVATION SCAFFOLDING that let the question be asked precisely. They
are not surviving SignalTree concepts and must not sit in the architecture as
future options.

**WHAT V1.1 ACTUALLY ESTABLISHED**, stated at full strength:

> After removing observation, installation, markers, addressing, identity,
> retained state and normalization, **there is no remaining SignalTree-owned
> validation function.**

Not merely "we could not find coupling". The audit found a requirement we had
INVENTED OURSELVES — and deleted it.

### V1 — VALIDATION FACILITY, MINIMAL CONTRACT — **DERIVED PROPOSAL, NOT FROZEN**

Derived from `validate(node, rules)` with `@signaltree/schema`, `form()`,
enhancers, paths and Angular signals hidden. Each responsibility proven
independently; everything else absent unless required.

#### R1 — EVALUATION

What does the evaluator minimally need? A VALUE to judge, and RULES to judge it
by. So the first question is what the first parameter actually has to be:

```
CANDIDATE A   validate(value, rules)         caller reads; evaluator gets a snapshot
CANDIDATE B   validate(() => value, rules)   evaluator reads on demand
CANDIDATE C   validate(nodeAccessor, rules)  evaluator holds a SignalTree node
```

**Under EXPLICIT evaluation, A suffices.** The caller already holds the tree; it
reads and passes `tree.$.order()`. B and C are only needed if the evaluator must
re-read on its own initiative — which is precisely the CONTINUOUS-CURRENCY
function that V0 placed outside the baseline.

**RETRACTED — the cross-field closure argument.** I wrote that a rule needing
other parts of the tree simply CLOSES OVER them. That smuggles live SignalTree
reads back in through the rule body:

```ts
validate(order(), (value) => {
  const customer = tree.$.customer(); // ambient SECOND read
});
```

The supposedly pure `value + rules -> result` operation can then observe TWO
DIFFERENT MOMENTS OF TRUTH. Even where JS execution makes most cases safe in
practice, the architecture is wrong: a snapshot evaluator must not secretly
acquire more truth through closures when input consistency matters.

**CORRECTED MODEL — all dependencies belong in the EXPLICIT validation input**
unless a live-reader model is separately specified and proven:

```ts
validate({ order: tree.$.order(), customer: tree.$.customer() }, rules);
// or, when a subtree snapshot already contains everything:
validate(tree.$.order(), orderRules);
```

Cross-field validation still does not prove SignalTree coupling — but for a
STRONGER reason than the one I gave. And it raises a real candidate: if
SignalTree must supply a COHERENT MULTI-POSITION SNAPSHOT, that could be genuine
SignalTree-specific functionality — **but its owner would be SNAPSHOT/READ
SEMANTICS, not validation.** Do not give validation ownership of a primitive it
merely consumes.

```
R1 RESULT   the evaluator needs a VALUE and RULES.
            It does NOT need NodeAccessor, paths, PositionId, revisions, or any
            kernel primitive.
```

#### R2 — RESULT

Minimum normalized shape:

```
{ valid: boolean, issues: Issue[] }
Issue: a message + a location RELATIVE TO THE VALIDATED VALUE
```

Location must be relative to the validated value, not a tree address —
otherwise the result type acquires a tree-addressing ontology it does not need.
Normalizing a rule format's native issue shape into this is the **ADAPTER's**
job, not the evaluator's.

#### R3 — ASYNC LIFECYCLE — **COLLAPSES**

The stated responsibility was _"obsolete async runs must never overwrite newer
results"_. Attack it directly:

> **Overwrite WHAT?**

Under explicit evaluation the facility STORES NOTHING. `await validate(…)`
returns a value to the caller. With no retained result, there is nothing an
obsolete run could overwrite — staleness is only a problem for something holding
a mutable current-result slot.

```
R3 RESULT   NOT a facility responsibility. Whoever RETAINS a result owns
            deciding which result to keep — the Angular adapter, or any consumer
            building a continuous projection. No generation counters, no
            revisions, no invocation registry in the primitive.
```

That also removes the last candidate reason to touch kernel identity.

#### THE SMALLEST SUFFICIENT PUBLIC CONTRACT

```
validate(value, rules) -> Result | Promise<Result>
```

- **SYNC/ASYNC SHAPE IS UNPROVEN.** The argument that always-Promise imposes
  microtask semantics is valid, but it does not establish that a
  `Result | Promise<Result>` UNION is optimal — a union pushes uncertainty onto
  every caller. `validate` + `validateAsync`, always-async, or a format-driven
  distinction are all live. **This cannot be settled until we know what `rules`
  actually are.**

```
ASYNC LIFECYCLE OWNERSHIP    COLLAPSED — keep this result
PUBLIC SYNC/ASYNC API SHAPE  UNPROVEN
```

- no stored state, no registration, no installation, no tree coupling.

#### REJECTED ALTERNATIVES, each with its falsifier

```
tree.with(validation())      REJECTED. Installation changes nothing the tree
                             semantically DOES; hanging methods off a tree is
                             the formBridge mistake.
                             FALSIFIER: a validation capability that alters
                             tree semantics.

validated() marker           REJECTED. No construction-time semantic
                             requirement.
                             FALSIFIER: validation that must participate in
                             graph COMPILATION.

continuous validation obj    REJECTED from the baseline. That bundles a SECOND
                             function — observation/invalidation.
                             FALSIFIER: V0's continuous-currency question
                             reopening.

pending in the primitive     REJECTED. No stored state -> nothing pends.
                             FALSIFIER: a required result the caller cannot
                             derive from the promise it is already holding.

rule registry / registration REJECTED. The caller holds its own rules.
                             FALSIFIER: rules that must be discoverable by a
                             party that does not hold them.

dependency tracking          REJECTED. Explicit evaluation reads what it needs
                             at call time.
                             FALSIFIER: continuous currency being required.

NodeAccessor parameter       REJECTED for the baseline (see R1).
                             FALSIFIER: the evaluator needing to re-read on its
                             own initiative.
```

#### THE SEVERE FINDING — and it must not be buried

The derived primitive has **ZERO SignalTree coupling**. It is a pure function
over a value and rules. Which raises the question this derivation is obliged to
ask:

> **If the facility needs nothing from SignalTree, why is it a SignalTree
> package rather than any existing validation library?**

```
(a) IT SHOULD NOT BE. A caller can already write
    `await someSchema.parseAsync(tree.$.order())`. V0's product decision would
    then be satisfied by DOCUMENTATION, not by a package.
(b) SOME SIGNALTREE COUPLING IS GENUINELY REQUIRED and this derivation has not
    yet found it.
```

**This is unresolved and is the next thing to attack.** Candidate couplings that
would justify (b), none yet proven:

```
- validating a SUBTREE where the shape must be derived from tree structure
  rather than supplied by the caller
- marker-aware validation (entityMap collections, async markers) where reading
  a raw snapshot loses semantics the rules need
- issue locations that must survive tree topology changes
- a normalized result shape shared across MULTIPLE rule formats, which is
  integration value rather than evaluation value
```

**Do not answer this by adding coupling to justify the package.** If (a) is
true, the honest 15.0 outcome is that the validation FUNCTION is satisfied
without a first-party evaluator — which would REOPEN V0.6's answer rather than
implement it.

### V0 — **CLOSED. PRODUCT DECISION FROZEN.**

```
PRODUCT DECISION       **REOPENED at `238b971d` — see V1.1.** V1 derived a
                       primitive with ZERO SignalTree coupling, which falsifies
                       the reasoning that produced this line. Everything else in
                       this block REMAINS FROZEN.
OWNERSHIP              downstream DERIVED facility over SignalTree truth
FRAMEWORK              framework-neutral BY FUNCTION (neutrality follows from
                       ownership; it was not chosen independently)
KERNEL VALIDATION      NONE
ONTOLOGY
DEFAULT EXECUTION      EXPLICIT evaluation
CONTINUOUS CURRENCY    NOT part of the baseline contract
ANGULAR                owns reactive observation and lifecycle for Angular
                       validation experiences
STANDARD SCHEMA        format/interoperability ADAPTER, not a second authority
@signaltree/schema     REDESIGN candidate; package and API not yet derived
```

**THE REASONING THAT WAS WRONG, recorded because the shape of the error
matters.** The argument ran: `await validate(tree.$.order(), orderRules)` is
generally useful, THEREFORE SignalTree should provide `validate`. That does not
follow. Once V1 erased SignalTree and derived `validate(value, rules)`, the
function is no longer _validate SignalTree state_ — it is _validate a JavaScript
value_. **The value having come from SignalTree gives SignalTree no ownership
claim over the operation.**

```
STILL FROZEN
  kernel application-validation ontology   NONE
  authoritative refusal                    NOT ESTABLISHED
  validation observation                   NOT KERNEL-OWNED
  continuous currency                      NOT BASELINE
  Angular observation/lifecycle            ANGULAR-OWNED
  validation enhancer                      UNJUSTIFIED
  validation marker                        UNJUSTIFIED

REOPENED
  15.0 ships a general first-party
  validation facility                      UNPROVEN
```

The original functional argument is preserved below for the record, but it
proves only that the CAPABILITY is useful — never that SignalTree must PROVIDE
it. Validation of SignalTree state is useful _without Angular Forms existing at
all_:

```ts
const result = await validate(tree.$.order, orderRules);
if (!result.valid) { … }
```

Nothing there is Angular-specific, form-specific or presentation-specific — it
is useful in services, imports, workflows, pre-submit checks and background
processing. Angular Forms being one major consumer does not make Angular the
semantic owner of the operation. Putting validation _only_ inside Angular Forms
would make a general state concern subordinate to a UI integration.

**THE DISTINCTION THAT SPLITS THE PRODUCT:**

```
VALIDATING TRUTH                        general, SignalTree-adjacent  -> WE PROVIDE
OBSERVING TRUTH SO VALIDATION STAYS     framework/runtime-specific    -> WE DO NOT
CURRENT
```

Providing only the first preserves _"SignalTree owns truth, Angular owns
observation"_ — and prevents validation from being used to smuggle a generic
mutation observer back into the kernel.

**THE CONTRACT, negatively stated:**

```
SignalTree 15 provides OPTIONAL, DESCRIPTIVE validation of current truth.
It does NOT:
  make validation part of kernel truth      refuse writes by default
  own validation observation                require Angular
  require continuous validity               require mutation events
  require public PositionId/path ontology
```

#### Two constraints carried into the derivation

**NOT AN ENHANCER** unless a later derivation proves installation changes what
the tree semantically DOES. The primitive currently looks like
`validate(node, rules)`, not `tree.with(validation(…))` — installing an
evaluator onto a tree so methods can hang off it would repeat the `formBridge`
mistake exactly.

**NOT A MARKER** — `signalTree({ profile: validated(…) })` is unjustified unless
a separate CONSTRUCTION-TIME semantic requirement appears.

#### Consequence for `form()`

**WORDING CORRECTED — `form()` has not lost its "last" justification.** It has
lost two large INHERITED ones — Angular Reactive Forms integration (RF-M1) and
validation ownership (V0/V1.1). Precisely:

> **`form()` now inherits NO justification from Angular interop or from
> validation. Its remaining functions must independently justify BOTH themselves
> AND any construction-time `form` marker.**

Those remaining functions — `dirty`/`touched`, `submitting`, `wizard`,
`reset`/`clear`/`patch` — are underived. The target shape:

```
              validation facility
              /                 \
   Reactive Forms adapter   Signal Forms adapter
              \                 /
              SignalTree truth
```

not `form()` owning validators + Angular Reactive Forms + Signal Forms + wizard

- touched + submitting. After the facility's API is frozen, `form()` can be
  audited with essentially ALL of its inherited justifications stripped.

#### Next — kernel-first derivation, everything hidden

Derive the facility's minimal API with `@signaltree/schema`, `form()`,
enhancers, paths, Angular signals and the current API ALL HIDDEN. Only three
candidate responsibilities:

```
EVALUATION       run rules against current readable truth
RESULT           normalized validity / errors
ASYNC LIFECYCLE  obsolete async runs must never overwrite newer results
```

**Even `pending` may not belong in the primitive.** `await validate(…)` needs no
persistent pending model; a consumer wanting `pending` / `isValid` / `errors` /
`lastResult` maintains that operational projection around the evaluator.

Package naming (`@signaltree/schema` -> `@signaltree/validation`?) is FORM and is
deliberately NOT decided — Rule 0g, function first.

### MUT-0 ROW — VALIDATION OWNERSHIP — **OPEN. Higher priority than realtime R0.**

Promoted ahead of realtime because RF-M1 produced evidence that 15.0 may carry
**TWO AUTHORITIES FOR ONE SEMANTIC FUNCTION**, which can contaminate `form()`,
schema, both Angular forms adapters and marker design simultaneously. Realtime is
a self-contained product question; this is not.

**RETRACTED NULL HYPOTHESIS.** This row opened with _"SignalTree has exactly ONE
semantic validation authority unless falsified"_. That **already assumes
SignalTree should own validation semantics at all**, which has not been earned.
Rule 0g requires deleting REQUIREMENTS too — and "we currently have two
validation systems" is not evidence that we need one.

#### V0 — DOES SIGNALTREE OWN VALIDATION AT ALL? (runs FIRST)

```
ASSUME NONE OF IT EXISTS
  no form()          no validators()      no schemas()
  no @signaltree/schema                   no Angular forms
  no path-based validation API

Given ONLY the 15.0 kernel: what validation capability, if any, should
SignalTree DELIBERATELY provide?
```

**A/B/C ARE NOT MUTUALLY EXCLUSIVE — CORRECTED.** They were framed as rival
architectures; they are INDEPENDENT OWNERSHIP AXES, and **B + C is a perfectly
legitimate result**:

```
SignalTree kernel                     owns truth only
first-party validation package        derives verdicts from truth
Zod / Valibot / Standard Schema       supply rule formats via adapters
```

Critically: **"not kernel semantics" does NOT imply "SignalTree should have no
validation package."** A package can be extremely valuable while remaining
strictly downstream of truth. Ask five independent questions instead of picking
a winner:

```
V0.1  does the KERNEL own any validation semantics?
V0.2  should the PRODUCT ship a first-party validation facility, even if
      validation is NOT kernel semantics?
V0.3  if yes, what does that facility own — policy? evaluation? result
      projection?
V0.4  which parts are merely ADAPTERS to external rule formats?
V0.5  does any of it require public kernel integration BEYOND READING TRUTH?
```

#### V0.0 — THE FIRST QUESTION: DESCRIPTIVE or AUTHORITATIVE?

Do not let the word "validation" collapse two radically different products:

```
DESCRIPTIVE    "this current truth violates these rules"
               -> a downstream derived system is very plausible
AUTHORITATIVE  "this semantic operation is ILLEGAL and must not commit"
               -> kernel / PREPARE integration potentially REQUIRED
```

**STATUS — measured behaviour, NOT a frozen greenfield decision.** My previous
wording, "V0.0 is now measured, not open", overstated it. Correctly:

```
MEASURED          no existing workflow demonstrates write refusal
DERIVED DEFAULT   do NOT introduce authoritative validation without an
                  independently required function that needs PREPARE refusal
PRODUCT SEMANTICS still falsifiable if such a function is discovered
```

Rule 0g forbids current behaviour from settling a greenfield product question.
This keeps the burden of proof where it belongs without making 14/15-dev
behaviour the specification.

**MEASURED — both current systems are DESCRIPTIVE. Neither refuses a write.**

```
@signaltree/schema   documented "observe-only … never blocks writes"
form() / FormSignal  `set(values)` NEVER consults validity. The only two
                     `if (!valid) return false` sites in the whole marker are
                     wizard `next()` and `goTo()` — WORKFLOW NAVIGATION, not
                     state refusal.
```

So **no measured function requires write refusal**, and nothing yet justifies
promoting validation into PREPARE or kernel semantics. Historical behaviour is
not normative — but it also means we must not casually INVENT write-refusal
semantics we have never had.

The wizard finding also reinforces the form-session decomposition: wizard gating
is WORKFLOW CONSUMING validation as an input, not validation itself.

#### V0.0b — APPLICATION VALIDATION vs KERNEL INVARIANTS

A third thing hides under the same word, and conflating them would drag
structural correctness into this cleanup:

```
KERNEL INVARIANT        required for SignalTree's OWN correctness
                        e.g. entity identity cannot be duplicated
APPLICATION VALIDATION  user/domain policy over state
                        e.g. "email must look valid"
DOMAIN INVARIANT        e.g. "order.total must equal sum(lines)" — could be
                        any of the three depending on product semantics
```

> **"The kernel owns no application validation" does NOT mean "the kernel never
> refuses invalid state."** The kernel may enforce its own structural/semantic
> invariants without owning a general user validation system. `entityMap`
> constraints must not be swept into this row.

**THE DECISIVE FALSIFIER, and it is simpler than the inventory below.** Before
enumerating async, errors and cross-position dependencies, assume:

```
SignalTree           owns current truth
validation consumer  reads truth -> derives verdict
```

> **What user-visible capability becomes IMPOSSIBLE if SignalTree itself owns
> ZERO validation semantics?**

Attack that null with: sync validation, cross-field validation, subtree
validation, async validation, errors, isValid, pending, manual validate,
automatic recomputation, Standard Schema support. If all are satisfiable without
changing the semantic state engine, that is strong evidence against A.

The null has real support: `NodeAccessor`s provide readable state, so no mutation
interception, paths, marker ownership or causal records are automatically
needed. An async evaluator can also own its own operational concerns —
_read truth -> validate against input X -> newer input arrives -> old result is
stale -> publish only the surviving result_ — WITHOUT `pending` becoming
SignalTree truth. **And solve staleness with an EVALUATOR-LOCAL GENERATION
COUNTER, not physical revisions**, unless the required semantics demand kernel
identity: _run 41 starts, run 42 starts, 41 resolves -> ignore, 42 resolves ->
publish._

**RETRACTED FROM MY OWN ARGUMENT — "publication machinery provides reactive
realization".** That is ANGULAR-specific. The frozen invariant is _"Angular owns
observation"_, so a FRAMEWORK-NEUTRAL validation package cannot casually lean on
Angular publication to solve automatic currency. Two questions must be split:

```
CAN validation be COMPUTED from truth?          -> reads suffice
HOW does a NEUTRAL system know WHEN to recompute? -> the real falsifier
```

**BUT FIRST — IS NEUTRALITY EVEN REQUIRED? MEASURED: NO, not today.**

```
@signaltree/schema imports `signal`, `computed`, `Signal` from '@angular/core'
                   and declares an @angular/core PEER DEPENDENCY
```

The current validation package is **not framework-neutral**. So "a
framework-neutral validation package" is a requirement I was about to INVENT,
not one that exists. It must earn its place like any other:

**V0.6 REPLACED — neutrality is not a free-standing switch.** Asking it
independently permits an OWNERLESS MIDDLE GROUND:

```
REJECTED SHAPE
a general "SignalTree validation" package that REQUIRES Angular for observation
-> the public abstraction says SignalTree; the actual owner is Angular
   realization
```

Neutrality should FALL OUT of ownership, so V0.6 becomes the higher-order
product question:

> **Does SignalTree 15 deliberately ship a GENERAL FIRST-PARTY VALIDATION
> FACILITY, independent of any UI/framework integration?**

```
YES -> neutrality FOLLOWS from the owner's function
       SignalTree truth -> neutral evaluator -> Standard Schema / custom rules
       Angular observation is OPTIONAL downstream realization

NO  -> no general facility is needed. Do NOT neutralize `@signaltree/schema`;
       question whether the package should exist in its current conceptual role
       at all. Validation then lives in the Angular forms adapters.
```

Do not preserve a generic Angular-coupled validation package merely because one
exists today.

**The burden of proof for KERNEL ownership is therefore very high — and the
automatic-currency falsifier only applies CONDITIONALLY on V0.6.**

#### THE MATRIX — three columns, not one binary

`NEEDS SIGNALTREE-SPECIFIC SUPPORT` is separated from `NEEDS VALIDATION
SEMANTICS IN KERNEL`, because the answers differ and collapsing them is what
produced the old observer machinery.

```
CAPABILITY            KERNEL VALIDATION   KERNEL          SIGNALTREE-SPECIFIC
                      SEMANTICS?          INTEGRATION?    SUPPORT?
--------------------  -----------------   -------------   -------------------
sync evaluation       NO                  NO              reads only
manual validate()     NO                  NO              reads only
errors / isValid      NO                  NO              derived result
Standard Schema       NO                  NO              format adapter
async evaluation      NO                  NO              reads only
pending               NO                  NO              evaluator state
staleness/cancel      NO                  NO              evaluator-local
                                                          generation counter
cross-field deps      NO                  NO*             reads only
subtree validation    NO                  NO*             reads only
AUTOMATIC CURRENCY    NO                  REAL FALSIFIER  conditional on V0.6
authoritative refusal YES (PREPARE)       YES             ONLY if the product
                                                          requires refusal —
                                                          nothing measured does
```

`*` **UNDER EXPLICIT EVALUATION these collapse from MAYBE to NO.** Cross-field
and subtree rules are simply THINGS THE EVALUATOR READS. Several values
participating does not imply a dependency-NOTIFICATION system. Both MAYBEs
existed only because continuous currency was being assumed.

**CORRECTED SUMMARY.** "Every capability answers NO to kernel validation
semantics" was too absolute — authoritative refusal answers YES if that product
function is ever required. Methodologically stronger:

> **Every CURRENTLY ESTABLISHED validation requirement can be satisfied with
> ZERO application-validation semantics in the kernel. No established
> requirement falsifies that null.**

**The shape this produces is internally consistent and worth stating:**

```
VALIDATION SEMANTICS IN KERNEL     NO
SIGNALTREE-SPECIFIC INTEGRATION    MAYBE (one row)
FIRST-PARTY VALIDATION PACKAGE     plausibly YES
```

Those three are perfectly compatible — which is exactly why A/B/C had to stop
being rival architectures.

#### AUTOMATIC CURRENCY MUST EARN ITS OWN EXISTENCE FIRST

Do not inherit it as a requirement merely because today's schemas are reactive.

```
FUNCTION     what user outcome requires always-current validity?
WITHOUT IT   what becomes IMPOSSIBLE rather than merely less convenient?
```

Two materially different product promises:

```
EXPLICIT   await validation.run(); validation.errors();
           Angular Forms handles its own triggering
CONTINUOUS validation.isValid() must ALWAYS correspond to current truth
```

**GREENFIELD BASELINE — EXPLICIT EVALUATION.** Adopt this as the default:

> Validation evaluation is EXPLICIT unless a specific product function
> independently requires continuously-current derived validation.

```
BASELINE   const result = await validate(node, rules);
           result.valid; result.errors;
NOT        validation.isValid()  // a perpetual promise to track future truth
```

Because _"evaluate current truth against rules"_ is unquestionably validation,
while _"remain continuously synchronized with future truth"_ is a SECOND
function — observation/invalidation of changing dependencies. Those must not be
silently bundled. Angular layers the second naturally, because Angular owns
observation; a future non-Angular adapter supplies its own mechanism.

Only if CONTINUOUS is required, AND V0.6 says a general neutral facility is
required, does the falsifier bite. And even then the result is **NOT** "validation belongs in the
kernel". It is:

```
zero kernel VALIDATION ontology still survives
+ some narrow neutral dependency-invalidation integration may be required
```

#### THE ARCHITECTURE TO ATTACK NEXT

```
SignalTree kernel -> truth -> NodeAccessor / reads
                                   |
                          validation evaluator
                        /          |          \
                custom rules   Standard    other formats
                                Schema
                                   |
                          validation result
                          /                \
              Angular Reactive        Angular Signal
               Forms adapter           Forms adapter
                          \                /
                    Angular observation / lifecycle
```

```
kernel owns application validation      NO
kernel owns validation observation      NO
evaluator owns evaluation               YES
format adapters own input translation   YES
Angular owns reactive observation       YES
```

Whether that evaluator deserves a FIRST-PARTY PACKAGE is the remaining product
question — i.e. V0.6.

#### `@signaltree/schema` — the audit question, sharpened

Do NOT ask _"should `@signaltree/schema` become neutral?"_ Ask:

> Assuming 15.0 deliberately ships a general validation facility, ERASE
> `@signaltree/schema`. What would the optimal evaluator + Standard Schema
> integration look like today?

Then reveal the package. Candidate outcome, to be tested rather than assumed:

```
FUNCTION       first-party validation + Standard Schema interoperability   KEEP
CURRENT FORM   Angular-signal-backed schema ENHANCER attached to a tree
                                                        likely DELETE / REDESIGN
GREENFIELD     neutral evaluator + Standard Schema format adapter
FORM                                                    HYPOTHESIS to test
```

If V0.6 answers NO, even the FUNCTION does not survive as a SignalTree concern.

**Audit it as a possible evaluator / format adapter — NOT as an enhancer, and
NOT as the canonical authority by inheritance.**

**CRITICAL DISTINCTION — dependency invalidation is NOT mutation observation.**
The minimum sufficient information may be only:

```
"something relevant to dependency set D may have changed"   -> then REREAD truth
```

with NO before, no after, no path, no mutation kind, no event envelope, and no
`PositionId` exposure. That preserves everything MUT-0 row 1 established, and it
is a far better question than _"what replaces `interceptLeafSignals`?"_

Only AFTER V0 does the one-authority falsifier run, and then in its corrected
form: _can every SURVIVING validation function be satisfied by one
non-overlapping semantic authority?_

**A counterexample must identify TWO GENUINELY DIFFERENT FUNCTIONS.** These are
representation and format differences until proven otherwise:

```
one API uses fields          one API uses paths
one API uses functions       one API takes StandardSchema
```

**VALIDATION MAY ITSELF SPLIT.** "One canonical authority" means ONE OWNER PER
SEMANTIC RESPONSIBILITY, not one giant subsystem:

```
VALIDATION POLICY     which rules apply to which semantic targets/dependencies
VALIDATION EXECUTION  run sync/async rules against current truth
VALIDATION RESULT     errors / validity / pending derived projection
FORMAT ADAPTERS       Standard Schema, Angular validator fns, custom validators
```

That shape would let Standard Schema survive WITHOUT `@signaltree/schema` being
a second authority. The evaluator itself may also belong outside SignalTree.
Both open.

#### A. THE FUNCTION INVENTORY — derived with names hidden

```
DECLARATION      how are rules attached to semantic state?
EVALUATION       who runs them, against what truth?
DERIVED STATE    who owns errors / valid / invalid?
DEPENDENCY       how does a rule know it must recompute?
ASYNC            who owns pending / cancellation / staleness?
COMPOSITION      how do field, subtree and whole-graph rules combine?
EXTERNAL INTEROP how do Angular forms systems consume the result?
```

#### B. MEASURED — the two current surfaces are NEAR-ISOMORPHIC

```
form() / FormSignal                    @signaltree/schema
--------------------------------       ----------------------------------
valid:      Signal<boolean>            isValid:   Signal<boolean>
errors:     Signal<Partial<Record<     errors:    Signal<Readonly<Record<
              keyof T, string|null>>>              string, string|null>>>
errorList:  Signal<string[]>           errorList: Signal<readonly string[]>
validate(): Promise<boolean>           validate():     Promise<boolean>
validateField(k): Promise<boolean>     validatePath(p): Promise<boolean>
—                                      pending / pendingPaths / isPendingAt
—                                      errorsAt / isValidAt / schemaFor /
                                       boundPaths / compact
```

**Same concept, two vocabularies.** Differences that might be SEMANTIC rather
than historical packaging, and must be adjudicated rather than assumed:

```
SCOPE       form: keyed by field WITHIN one form (`keyof T`)
            schema: keyed by dot-path ACROSS the tree (`string`)
DECLARATION form: inline per-field validator functions
            schema: StandardSchema objects per path (Zod/Valibot/ArkType/…)
ASYNC       schema models pending explicitly; form exposes only a Promise
```

**DO NOT ATTACK THE SCOPE DIFFERENCE FIRST.** Both sides are
REPRESENTATION-SHAPED, and NEITHER is the kernel's semantic identity model:

```
keyof T    TypeScript object structure
dot-path   MUTABLE ADDRESS structure
PositionId semantic/topological identity   <- the kernel's actual model
```

So the greenfield question is not _"field scope or path scope?"_ but:

> **What semantic THING is being validated, and what DEPENDENCIES may its rule
> have?**

**AND DO NOT PROMOTE `PositionId` INTO VALIDATION'S PUBLIC ONTOLOGY.** That
would be another nearby-kernel-structure promotion. The kernel may internally
compile a dependency such as _"`profile.name` depends on `profile.country`"_
into semantic identities while a rule author still writes something like
`validate(tree.$.profile.name, …)` or a schema object over a subtree. The
question is:

```
does validation need stable semantic dependency identity INTERNALLY?
NOT: should validation's PUBLIC ontology expose PositionId?
```

The answer may well be **internal YES / public NO.**

e.g. _validate position P using truth at P, Q and R_, or _validate subtree S
against current committed truth_. Both `keyof T` and dot-paths may vanish from
the internal model entirely — which is precisely the kind of thing this audit
exists to catch.

**FALSIFIER:** _can every required validation workflow be expressed through ONE
canonical authority without losing a genuinely distinct semantic capability?_
If yes, two owners are wrong. If no, state precisely why both exist and give
them NON-OVERLAPPING ownership.

#### C. A SEPARATE FUNCTION FOUND INSIDE `form()`

`FormSignal` bundles validation with something else entirely:

```
VALIDATION        valid, errors, errorList, validate, validateField
FORM-SESSION      dirty, touched, submitting, touch, touchAll, reset, clear,
                  patch, wizard
```

Form-session state is **not validation**, and under the Rule 0i amendment it may
be none of the five roles.

**AND IT IS NOT ONE COHERENT FUNCTION EITHER.** Do not treat the leftover bundle
as a single surviving thing:

```
dirty / touched      interaction / session concepts
submitting           process state
wizard               workflow / navigation
reset / clear / patch operations
```

Those may each have different owners. So the question after validation is
resolved is NOT _"does the remaining form-session bundle justify `form()`?"_ but:

> **What INDEPENDENTLY REQUIRED functions remain inside the historical form
> bundle?**

`form()` may disappear even if several of its functions survive elsewhere.

#### D. ANGULAR STAYS STRICTLY DOWNSTREAM — with one nuance

The RF-M1 contamination finding (`formGroup`, `formControl`, `angularErrors`,
`asyncPending` written onto the marker) must be removed regardless of which
authority survives. But do NOT delete a concept merely for sitting next to
Angular baggage:

```
Angular FormControl/FormGroup refs   clearly ADAPTER-owned
Angular error representation         ADAPTER-owned
validation PENDING                   see below — three separate UNPROVEN questions
```

**"Schema already models pending as domain state" was TOO STRONG and is
retracted.** What is established is only that `@signaltree/schema` publicly
models pending as reactive derived state. That does not establish it belongs to
SignalTree's semantic truth. It may simply be OPERATIONAL STATE OF AN EVALUATOR:

```
truth -> async validation process -> pending / result
```

And there is a reason for active suspicion: undo/redo/rollback should almost
certainly NOT treat _"a validator promise is currently unresolved"_ as authored
domain history. Keep all three questions separate:

```
pending concept required?   POTENTIALLY
owner?                      UNPROVEN
part of semantic state?     UNPROVEN
```

Current public visibility must not promote its ontology.

#### E. SEQUENCING — `form()` is NOT audited yet

Its survival is entangled with this row. If validators are the only semantic
content left in `form()`, assigning validation ownership may collapse most of
the marker's reason to exist — so auditing it now would test it against
semantics that may move.

```
NOW    validation ownership      -> canonical validation semantics
THEN   form() marker survival    -> what remains after validation is assigned?
                                    (form-session state is the live candidate)
THEN   realtime R0
```

**RF-M1's lesson generalized:** the adapter did not need "form-ness", it needed
VALIDATION METADATA. Accidental coupling of that kind is exactly what this audit
exists to expose.

### RULE 0g DERIVATION — Reactive Forms interoperability — **RESULT: REDESIGN / MOVE**

First full application of Rule 0g. Requirement stated with the existing name and
mechanism withheld:

> A supported Angular application using Reactive Forms must interoperate a
> SignalTree-backed state model with `FormGroup`/`FormControl` **without
> creating a second authority for application truth.**

**THE DECIDING FALSIFIER:** does this require CHANGING THE SEMANTIC CAPABILITIES
of a SignalTree, or merely ADAPTING between Angular's forms model and an already
published SignalTree realization?

**MEASURED — it is purely adaptive.** The implementation is bidirectional sync
and nothing else:

```
createFormGroupFromValues(...)                 build FormGroup from marker values
formGroup.valueChanges.subscribe -> set(...)   FormGroup  -> SignalTree
effect(() => syncSignalToControl(), {injector}) SignalTree -> FormGroup
```

No new semantic capability is added to the tree. **So the enhancer is the wrong
owner.**

#### Three findings that make this conclusive, not merely stylistic

**1. It requires an Angular INJECTION CONTEXT the enhancer cannot guarantee.**
It imports `inject`, `Injector`, `DestroyRef`, and its config carries escape
hatches — with this comment:

> _"Injector for reactive FormSignal -> FormGroup sync (auto-injected if in
> injection context). **Without one, signal-side writes only reach the FormGroup
> at creation time.**"_

A tree-mutating enhancer applied via `tree.with(...)` may run anywhere, so the
integration **silently degrades to one-way** when the context is absent.
**CORRECTED WORDING:** an Angular-owned adapter can make Angular
lifecycle/injection context an EXPLICIT CONSTRUCTION REQUIREMENT, whereas a
generic tree enhancer cannot assume one. (Not "always has it by construction" —
that overstates it and does not need to be true for the argument to hold.) The
escape hatch is a symptom of the wrong owner, not a convenience.

**2. Lifecycle owner is mismatched.** Cleanup keys on `DestroyRef` — Angular
injector/component lifetime. The enhancer attaches to TREE lifetime. Those are
different lifetimes, and the tree's is usually longer.

**3. Cardinality is wrong — REINFORCING evidence, not foundational.** Findings 1
and 2 already convict the enhancer form; this row would need an independent
requirement for multiple simultaneous `FormGroup`s over one subtree to carry
weight on its own. `formBridge: Map<string, AngularFormBridge>` keyed by path is
SINGLETON STATE ON THE TREE. Two components each wanting their own
`FormGroup` over the same `form()` marker — a routine Angular scenario — collide.
The natural cardinality of a forms binding is PER COMPONENT, not per tree.

#### The eight questions

```
1 synchronization owner  BIDIRECTIONAL, and the write-back must go through the
                         canonical SignalTree write path — never a second authority
2 what is truth          FormGroup carries UI state (dirty/touched/pristine) that
                         must NOT enter SignalTree semantics. Only VALUES cross.
3 identity needed        public node accessors suffice — no PositionId, no
                         realization identity. Evidence for adapter, not kernel.
4 topology change        UNRESOLVED — entity add/remove/rekey under a bound form.
                         Must be answered by whatever owns the adapter.
5 validation owner       TWO independently-owned systems bridged explicitly;
                         `@signaltree/schema` already owns its side
6 must it be tree.method()?  NO. Nothing measured requires `tree.getAngularForm(p)`
                         over `createReactiveFormsAdapter(node, …)`
7 multiple FormGroups?   YES, legitimately -> tree-attached singleton bridge state
                         is inherited architecture (see finding 3)
8 lifecycle owner        Angular injection context / component — NOT tree lifetime
```

#### Disposition

```
FUNCTION       SignalTree <-> Reactive Forms interoperability          KEEP
CURRENT FORM   tree-mutating enhancer + AngularFormsMethods +
               tree-attached bridge Map                                DELETE
GREENFIELD     Angular-owned adapter over SignalTree publication /
FORM           node accessors, with Angular lifecycle ownership        KEEP
DISPOSITION    REDESIGN / MOVE TO OWNER
```

```
                  DERIVED                          CURRENT
SignalTree NodeAccessor /             tree.with(formBridge())
  published Angular view                 -> mutates realization
   <-> Angular-owned RF adapter          -> adds getAngularForm() + Map
   <-> FormGroup / FormControl           -> hopes for an injection context
```

**WHICH SIDE OF THE PUBLICATION BOUNDARY the adapter consumes is NOT PROVEN.**
Question 3 concluded public node accessors suffice — so forcing the adapter
through an Angular publication abstraction could itself be an unnecessary layer.
Left open deliberately.

**CONSEQUENCE FOR #4a — `formBridge` must NOT be migrated to
`Enhancer<TAdded>`.** That would convert a form this derivation concludes should
not survive, purely to enable deleting the realization overload. Rule 0h: the
deletion procedure does not get to drive the ontology.

**STILL OPEN, and honestly so:** question 4 (topology change under a bound form)
is unanswered by either design, and the derived adapter's exact surface is not
specified — this slice establishes OWNERSHIP, not API.

#### RF-M1 — does Reactive Forms interop justify the `form()` MARKER?

Removing the enhancer while preserving the same architecture one level down in
the marker would be a hollow win. Null assumption: **no `form()` marker exists.**
Can an Angular-owned adapter implement the complete function from an arbitrary
suitable `NodeAccessor<T>`?

**MEASURED — everything the bridge takes from the marker:**

```
formSignal()                              read values      -> NodeAccessor gives this
formSignal.set(formValues)                write values     -> NodeAccessor gives this
formSignal.valid                          validity signal  -> DERIVED from validators
mergeMarkerValidators(formSignal, …)      VALIDATORS       -> the ONLY real dependency
```

**ANSWER: values need no marker. The marker contributes exactly ONE thing —
DECLARED VALIDATION RULES attached to the position.**

So Reactive Forms interop does not depend on "form-ness" at all. It depends on
_"where are this subtree's validation rules?"_ — **a VALIDATION-OWNERSHIP
question, not a forms-interop one.** And validation already has a second owner in
`@signaltree/schema`, so 15.0 currently has TWO validation systems and the forms
adapter is coupled to one of them by accident of history.

**WORSE — the bridge CONTAMINATES the semantic marker with Angular objects:**

```ts
(formSignal as …)['formGroup']     = …
(formSignal as …)['formControl']   = …
(formSignal as …)['angularErrors'] = …
(formSignal as …)['asyncPending']  = …
```

Angular presentation state written onto a SignalTree semantic marker. That is
the contamination Rule 0i's marker test forbids, happening in the opposite
direction from the one anticipated.

```
RF-M1 RESULT   Reactive Forms interop does NOT justify `form()` as a marker
               -> sever the architectural dependence
               -> `form()` faces its own MUT-0 survival audit on whatever
                  semantics genuinely remain (validation declaration? dirty?
                  submission?), inheriting NOTHING from forms integration
```

**This does NOT delete `form()`.** It may independently own real semantics. It
simply may not inherit survival from Reactive Forms integration.

### SUBTRACTION TEST — `formBridge` — **FUNCTION SURVIVES; FORM UNPROVEN**

Pulled forward as a cheap functional falsifier: delete it and ask what capability
disappears that `signalForm` cannot provide. It was expected to be an obsolete
pre-Signal-Forms bridge. **It is not**, and the evidence is the project's own
documentation.

```
CONSUMERS   exactly ONE real call site —
            apps/demo/.../form-marker-demo.component.ts:357
            everything else is README prose and code-sample STRINGS
```

That count alone would have looked like a deletion. It is not, because:

```
signalForm()   Angular SIGNAL FORMS   requires @angular/forms/signals, Angular 22+
formBridge()   Angular REACTIVE FORMS interop (FormGroup), Angular 20/21
```

The demo states it outright: _"Requires Angular 22+ (`@angular/forms/signals`).
The classic `formBridge()` (Reactive Forms) remains available for Angular 20/21
apps."_ And the peer range is `^20 || ^21 || ^22` on both `core` and `ng-forms`.

**These are two DIFFERENT Angular form systems, not old and new versions of one.**
`formBridge` provides `getAngularForm(path)` and a `Map` of `AngularFormBridge`
— FormGroup interop — which `signalForm` does not and cannot provide on Angular
20/21.

```
FUNCTIONAL FALSIFIER
  workflow lost if deleted?      YES — Reactive Forms interop on Angular 20/21
  signalForm covers it?          NO  — different API, requires Angular 22+
  only demos/tests/docs?         NO  — the function is real; the low usage count
                                       reflects the demo having one page per
                                       feature, not disuse
```

**LESSON — the subtraction test earned its place by REFUTING a deletion.** One
consumer plus "it looks superseded" was a deletion-shaped story. The audit's
value is symmetric: it must be as willing to find a real function as to delete a
mechanism, or it becomes a demolition process with extra steps.

**THE REAL QUESTION IT EXPOSED, which is a genuine 15.0 product decision:**

```
Does SignalTree 15.0 support Angular 20/21, or require 22+?

supports 20/21  -> formBridge is REQUIRED; deleting it removes forms interop
                   for the majority of the supported range
requires 22+    -> formBridge's reason to exist evaporates and it becomes a
                   real DELETE candidate
```

The peer range currently says `^20 || ^21 || ^22`. **DECISION REQUIRED — the
supported Angular range is a release-scope question, not a cleanup.**

**CORRECTION UNDER RULE 0g — my "KEEP" verdict conflated FUNCTION with FORM.**
The subtraction test proved the function is real. It proved nothing about the
abstraction. Rule 0g step 2 has not been run:

```
FUNCTION      Angular Reactive Forms integration for the supported range
              -> SURVIVES (subject to the Angular-range decision)
CURRENT FORM  an ENHANCER that mutates a tree to add `AngularFormsMethods`
              and a `Map<string, AngularFormBridge>`
              -> UNPROVEN

KERNEL-NATIVE QUESTION, NOT YET ASKED:
  given the 15.0 kernel and no prior API, would Angular forms integration be
  built as a tree-mutating enhancer at all — or as an ADAPTER over published
  realization?
      Angular forms adapter  <->  published SignalTree realization

DISPOSITION   REDESIGN CANDIDATE, not KEEP
```

If the kernel-native answer is an adapter, then the enhancer form is wrong even
though the functionality is valuable — and that is exactly the case `REDESIGN`
exists for. It also bears directly on #4a: forcing `formBridge` through
`Enhancer<TAdded>` would then be migrating a form that should not survive.

### REALTIME FUNCTION RESET — start at R0, OWNERSHIP

Do not begin by asking what realtime needs. Ask whether it is SignalTree's
concern at all — a package name is itself inherited architecture.

```
R0  does optimal SignalTree promise ANY remote-state semantics?
    NO  -> realtime is an integration/product OUTSIDE SignalTree semantics,
           and its needs MUST NOT shape the kernel
    YES -> state exactly which remote guarantee SignalTree owns
```

Only then choose among four DIFFERENT PRODUCTS:

```
A  STATE CONVERGENCE     eventually make remote equal surviving committed truth
B  CHANGE PROPAGATION    transmit eligible committed changes efficiently
C  OPERATION REPLICATION transmit semantic operations, not resulting state
D  CAUSAL REPLICATION    preserve ordering, conflicts, identity, supersession
```

**SEMANTIC NECESSITY vs PERFORMANCE OPTIMIZATION — keep these apart.** If
convergence is the function, a delta may be a bandwidth optimization, not a
semantic requirement. This must never become "therefore SignalTree needs a
transition API".

**DO NOT ASSUME these are requirements:** deltas, `source`-based echo
suppression, remote-write metadata, or change notification. Echo suppression
especially — an optimal design might have the integration know which inbound
operation it submitted, or use causal/origin identity. The existing `source`
flag is not automatically the right concept.

Answer BEFORE reading the current protocol:

```
1 is remote sync a SignalTree responsibility at all?
2 what correctness guarantee is promised — eventual convergence, ordered
  replication, causal convergence, offline reconciliation?
3 is the transmitted unit semantically significant, or an optimization?
4 does realtime need causal MEANING, or only committed truth?
5 who owns conflict resolution — SignalTree, adapter, backend, application?
6 are remote writes ORDINARY semantic operations on arrival, or is there a
  special remote-write ontology?           <- avoids a parallel architecture
7 what does a third-party implementer need — transport adapter, serializer,
  conflict policy, commit notification?
```

Neither outcome implies a generic observer: "only committed truth" points to a
purpose-specific consequence; "genuinely needs causal operations" points to the
CAUSAL AUTHORITY.

### MUT-0 ROW 1 — SYNCHRONIZATION / INTEGRATION — **DRAFT PROPOSAL, NOT A DISPOSITION**

Deliberately NOT called "observation". Derived with current API names hidden
until step F.

#### A. REQUIRED FUNCTIONS — outcomes 15.0 must provide

```
A1  a non-kernel capability stays CORRECT as SignalTree truth changes
A2  durable storage reflects surviving committed truth
A3  Angular re-renders from published truth
A4  authored operations retain causal meaning (undo/redo/rollback)
A5  a capability may decline to act on changes it should ignore
```

Note what is NOT listed: "a subsystem is notified of mutations". That is a
MECHANISM, not an outcome.

#### B. WHICH FROZEN AUTHORITY ALREADY OWNS EACH

```
A2  governed persistence consequence      OWNED, frozen
A3  Angular publication                   OWNED, frozen (F2)
A4  causal kernel                         OWNED, frozen (F3)
A5  attribution on the semantic operation OWNED in principle — see E
A1  <- the only genuinely open row
```

A2-A4 need nothing new. They were never observation problems.

#### C. THE NULL DESIGN — assume NONE of it exists

Assume there is no generic observer, no mutation bus, no public write context,
and no leaf interception. Can A1 still be implemented?

**MEASURED — the shape exists:**

```ts
interface CausalTurn {
  readonly id: TurnId;
  readonly effects: readonly CausalEffect[];
  readonly participants: readonly PositionId[]; // <- AFFECTED SEMANTIC POSITIONS
  readonly state: TurnState;
}
```

**COMPLETENESS FALSIFIER — RUN, AND IT FAILS. My own draft is refuted.**

The draft claimed "affected semantic identity, transaction granularity and
settlement lifecycle ALL exist already". That is TRUE OF `CausalTurn` and FALSE
as a statement about ordinary truth changes. Measured:

```
new TurnStore()   constructed in exactly ONE place:
                  packages/core/src/enhancers/transactions/transactions.ts:926

TurnStore in lib/ zero construction sites — turns are NOT part of ordinary
                  tree construction
```

**`CausalTurn` is TRANSACTION-SCOPED, not tree-wide.** An ordinary
`signalTree()` leaf write produces no turn at all. So the model
`turn settles -> participants -> invalidate` does not see ordinary writes, and
`CausalTurn` is a TEMPTING NEARBY STRUCTURE rather than a proven invalidation
source.

This is the same class of error the whole slice exists to prevent: I found a
structure that already had the right FIELDS and promoted it before checking its
COVERAGE.

**What survives, and ONLY as a scoped hypothesis:** invalidate by semantic
identity at a settled boundary, then reread truth. That is a
**SCHEMA / CURRENT-TRUTH-CONSUMER hypothesis**, NOT a universal SignalTree
architecture.

**Do NOT now hunt for "the real universal invalidation source".** That is the
same proximity trap one level up: having found `CausalTurn` insufficient, the
reflex is to look for whatever else emits affected positions for everything.
**There may correctly be no such thing.** A plausible optimal design has no
universal channel at all:

```
authored semantic operation  -> causal authority gets meaning
physical semantic commit     -> current-truth consumers invalidate
structural operation         -> topology/compiler invalidation
persistence                  -> governed consequence
realtime                     -> purpose-specific committed consequence
Angular                      -> publication
```

The completeness failure is itself evidence for this: one structure did not
cover everything because covering everything may not be one structure's job.

**COMPLETENESS REQUIREMENT, now explicit.** Before any invalidation source is
adopted, prove it covers every semantically meaningful way truth can change:

```
ordinary authored write          multi-position semantic transaction
speculative write                confirmation with no new value change
rollback                         confirmed undo / redo
derived / internal realization   hydrate / restore
structural entity operations
```

Some rows may correctly produce NO invalidation — but that must be a semantic
decision, not an accident of which enhancer happens to construct a store.

A dependent capability would then need no mutation stream:

```
turn settles
   -> participants: PositionId[]
   -> capability's dependencies on those positions invalidate
   -> capability READS CURRENT TRUTH from the tree
   -> derived state recomputed
```

**The event need not carry the value at all.** SignalTree owns truth (F1); a
mutation payload would be a second copy of it. Schema's measured requirements
confirm this — it already ignores `prev`, and `next` is obtainable by reading.

#### D. PUBLIC NECESSITY — if a primitive IS needed, at which level?

```
CORE-INTERNAL        certainly sufficient for A2/A3/A4
FIRST-PARTY PACKAGE  schema and realtime would consume A1. An internal shared
                     contract satisfies that WITHOUT a public protocol.
THIRD-PARTY SDK      UNPROVEN. No measured consumer. COUNTEREXAMPLE NEEDED:
                     an extension only a third party could write, requiring
                     position-level invalidation.
```

#### E. THE ONE CANDIDATE MISSING PRIMITIVE

**RETRACTED — "schema's irreducible requirement".** Previously this said
suppression by `intent`/`source` was schema's irreducible extra requirement.
That is a fact about the CURRENT IMPLEMENTATION, promoted to a derived
requirement. We have established only that today's schema reads those fields.
We have NOT established that optimal 15.0 schema should have a
suppression-by-source/intent concept at all.

**THE RULE THIS VIOLATED, now explicit:**

> Delete REQUIREMENTS as aggressively as we delete MECHANISMS. A legacy
> requirement preserved uncritically is as damaging as a legacy mechanism, and
> harder to see — it arrives wearing the words "we need".

`CausalTurn` carries `id`, `effects`, `participants`, `state` — no attribution.
Whether anything SHOULD is downstream of a function question nobody has asked.

```
MINIMUM MISSING PRIMITIVE (stated without reference to current APIs)

  attribution of a settled semantic operation must be readable by whatever
  decides whether a dependent capability should react to it.
```

**DO NOT conclude "therefore it belongs on the turn".** That would repeat the
error above — attaching metadata to whichever structure is nearby. The
attribution's SEMANTIC OWNER AND GRANULARITY are unresolved:

```
could ONE semantic transaction contain changes with DIFFERENT
source / intent / suppression policy?
```

If yes, turn-level attribution is too coarse. Candidate owners — semantic
operation, individual instruction, causal effect, transaction — are all open.
**MUT-2 must DERIVE the owner, not inherit it from proximity.**

#### F. ONLY NOW — the existing forms, and provisional dispositions

```
interceptLeafSignals    finds Angular signals and wraps their setters.
                        CORRECTION: this does NOT categorically contradict
                        F1/F2. Angular IS permitted to observe Angular
                        realization — that is its ownership. The narrower and
                        correct argument:
                          as a NEUTRAL SEMANTIC AUTHORING primitive
                            -> very likely DELETE: it derives semantic change
                               from framework realization rather than from
                               SignalTree-owned truth
                          as an ANGULAR-LOCAL implementation technique
                            -> judge independently, by function
                        Otherwise Rule 0e degenerates into "no code may ever
                        look at a signal".              -> DELETE CANDIDATE

PathNotifier /          global process-wide mutation bus; flattens
getPathNotifier         MutationEnvelope into 8 positional args; requires
                        consumers to filter foreign trees. Global authority in
                        a tree-owned architecture.  -> INTERNALIZE or DELETE

write-context APIs      raw ambient write context. If attribution belongs on
                        the turn (E), owning subsystems receive it directly and
                        no consumer needs the raw context. -> INTERNALIZE
                                                              (provisional)

MutationEnvelope        the RICHEST existing shape, and the one closest to
                        being unnecessary — a turn already names participants,
                        and truth is readable.        -> likely INTERNAL only
```

**PROVISIONAL ROW-1 RESULT — all weakened to CANDIDATE pending the falsifiers:**

```
generic PUBLIC mutation observation    NOT-NEEDED CANDIDATE (strong)
leaf interception                      DELETE CANDIDATE (strong: observes
                                       framework realization, contradicts
                                       F1/F2; zero application usage)
public mutation bus                    DELETE / INTERNALIZE CANDIDATE
public write context                   INTERNALIZE / REPLACE CANDIDATE
MutationEnvelope                       INTERNAL IMPLEMENTATION CANDIDATE —
                                       explicitly NOT delete-on-the-strength-of
                                       turn participants. A structure can be
                                       wrong as PUBLIC authoring abstraction
                                       and exactly right internally for
                                       physical/causal machinery.
invalidation source                    UNPROVEN — NOT CausalTurn
attribution owner                      UNPROVEN — do not assume the turn
```

**"No event needs values" is NOT frozen.** It holds for capabilities deriving
from CURRENT TRUTH. It would not hold for recording "A -> B happened", sending
a delta to a replica, or an incremental transformation that cannot be
reconstructed. Keep only the weaker rule: _current-truth consumers should not
receive copied state unless proven necessary._

**COUNTEREXAMPLES THAT WOULD OVERTURN THIS:**

```
X1  a capability that CANNOT recompute from current truth and must see the
    transition itself (before/after)
X2  a capability needing per-physical-commit granularity (contradicts F8+F9)
X3  a third-party extension that cannot be written without a public hook
X4  attribution that cannot live on the turn without breaking causal semantics
X5  a capability needing to REFUSE — none measured; schema is observe-only
```

#### FUNCTION RESET — runs BEFORE X1

X1 as previously written still assumed several EXISTING feature requirements are
requirements of the optimal design. Reset each candidate's function first,
ignoring its current API and protocol:

```
REALTIME    what must optimal 15.0 realtime ACCOMPLISH?
            "make remote state converge to surviving committed truth"
              -> current truth may suffice
            "replicate semantic operations preserving concurrency meaning"
              -> operation/delta information is probably fundamental
            These are DIFFERENT PRODUCTS with different information needs.
            Derive from the intended function, never from what the current
            implementation happens to send.

DEVTOOLS    SEPARATE THESE FIRST — they may not be one capability.
vs AUDIT    inspector: show current state + diagnostics -> current truth
            audit:     immutable "A -> B happened" provenance -> transitions
            Even if audit needs transitions, it may consume CAUSAL RECORDS or a
            dedicated audit consequence — not a generic mutation stream.

SCHEMA      what must validation ACCOMPLISH?
            Does optimal schema have source/intent suppression AT ALL?
            If it survives, derive its SEMANTICS from the product function
            before worrying about timing.
```

#### X1 SPLIT INTO THREE CLAIMS OF INCREASING STRENGTH

Binary X1 permits the bad inference _"realtime needs A->B, therefore SignalTree
needs a public mutation observer"_. Split:

```
X1a  does ANY legitimate non-causal capability require historical TRANSITION
     information rather than current truth?
X1b  if yes, must it come from a SHARED semantic mechanism, or can its owning
     subsystem receive it through a PURPOSE-SPECIFIC integration?
X1c  if a shared mechanism is needed INTERNALLY, must THIRD-PARTY implementers
     have PUBLIC access to it?
```

A capability needing transitions can still land as
`semantic commit authority -> purpose-specific consequence` with **zero public
observer API**, preserving the null design at the SDK level. Only X1c reaching
"yes" creates public surface.

**AND NOT WITH `restoration`.**

`restoration` is a CONTAMINATED candidate: it IS the authority that owns causal
history, so of course undo needs before/after. That proves only "causal history
needs transition information", which is already frozen — and using it would
falsely resurrect `MutationEnvelope` as a public concept because the causal
kernel needs data that belongs INSIDE the causal kernel.

Attack X1 from OUTSIDE the owning authority:

```
realtime        does outbound sync need the transition/delta, or can it
                serialize current committed truth?
devtools/audit  is there a promised function that must say "A -> B happened",
                rather than display current truth?
schema          does any validation behaviour depend on the TRANSITION rather
                than final truth + operation policy?
```

**SCHEMA'S REAL FALSIFIER IS SUPPRESSION TIMING, not `prev`/`next`.** Given

```
T1 changes P7 with "suppress schema"
T2 changes P7 normally
```

and coalesced invalidation, "P7 changed -> eventually reread truth" is ambiguous
between: do not validate the value produced by T1; do not SCHEDULE validation
because of T1; or keep the previous verdict until an eligible operation occurs.
Those differ when T2 arrives quickly. That schema ignores `prev` does NOT prove
identity + current truth + policy reproduces its function.

#### Not yet: running the demo

Runtime exercise would characterize CURRENT BEHAVIOUR more richly, which is
precisely what must not define the architecture. Defer it until a function
SURVIVES MUT-0 and we need to characterize what that surviving function must
preserve.

### MUT-1 — PARTICIPATION MODEL — **DERIVED PROPOSAL, NOT FROZEN**

Answers ONE question: _at which lifecycle phases may external authoring
participants act, and what authority does each phase permit?_ No event types, no
mapping of existing classes — those are MUT-2 and later.

Every line below is labelled. Nothing here is ledger truth until reviewed.

#### FROZEN INPUTS used (quoted from Release Invariants)

```
F1  "SignalTree owns truth."
F2  "Angular owns observation."          <- ANGULAR, not "framework"
F3  "Causal history owns meaning."
F4  "All expected fallible semantic work precedes private commit."
F5  "PRIVATE COMMIT consumes prepared instructions only."
F6  "PROJECT reflects committed truth; it never determines authority."
F7  "Persistence is post-commit."
F8  "no observer, publication adapter, persistence consequence, or other
     external consumer may observe an intermediate heterogeneous state."
F9  "a semantic transaction may span more than one private substrate commit"
F10 durable gate is TREE-LOCAL; "Callers describe a consequence; they do not
     decide when it runs."
F11 `PositionId != SubjectId != SlotIndex != key/path`
```

#### Phase-by-phase

**PREPARE — DERIVED PROPOSAL: yes, a public participation tier.**

```
already true at entry   a semantic change has been PROPOSED; nothing is live
may still fail          everything that can legitimately fail
extension may           observe the proposal; REFUSE it
extension MUST NOT      observe other trees; assume it runs once per physical
                        commit; mutate live state
```

Derivation: F4 puts all fallible semantic work here by definition. If refusal is
a supported capability anywhere, it can only be here — refusing after PRIVATE
COMMIT would contradict F5, which admits only prepared instructions.

**REVISED — the phase conclusion and the public-surface conclusion are separate
claims, and only the first is derived.**

```
FROZEN-DERIVED     refusal, if it exists at all, must occur during PREPARE
UNPROVEN           that any PUBLIC PREPARE participation API should exist
```

F4/F5 constrain WHERE refusal can happen. They say nothing about whether an
external plugin protocol is required there. If SignalTree itself, schema
compilation, or another built-in semantic subsystem performs all necessary
refusal during PREPARE, no public tier is needed. No current consumer requires
it: schema is observe-only by design, guardrails is a diagnostic.
COUNTEREXAMPLE NEEDED: a real authoring case that must PREVENT a write rather
than report on it.

**OPEN QUESTION — transformation/normalization.** Distinct from refusal and much
riskier: a transforming participant becomes a co-author of truth, which strains
F1. Recommend excluding it unless a counterexample forces it.

**PRIVATE COMMIT — DERIVED PROPOSAL: NO external participation.**

Direct from F5. It consumes prepared instructions ONLY. Any extension code here
would be either fallible work that F4 says belongs in PREPARE, or an observer
that F8 forbids from seeing intermediate state.

**POST-COMMIT SEMANTIC OBSERVATION — DERIVED PROPOSAL: yes, a public tier, and
the one most consumers want.**

```
already true at entry   accepted semantic truth exists
may still fail          nothing semantic; an observer's own failure is its own
extension may           observe committed truth WITH causal attribution
extension MUST NOT      alter or reject; assume framework publication happened;
                        assume one notification per physical commit
```

**REVISED — separating what F8+F9 prove from what they do not.**

```
FROZEN-DERIVED  the semantic transaction boundary is the EARLIEST COHERENT
                point at which committed truth could be consumed without
                exposing heterogeneous physical commits
UNPROVEN        that any general PUBLIC consumption API should exist there
```

F8 + F9 establish a property of the LIFECYCLE: a semantic transaction may span
several private commits, and no external consumer may observe an intermediate
heterogeneous state — so anything consuming committed transitions must respect
transaction granularity, never per-substrate-commit. That is a real constraint.

It does NOT establish that the authoring SDK needs a public `CommittedObserver`.
The previous draft made exactly that leap. Whether ANY public API exposes this
boundary is MUT-0's question.

Also derived from F2: this tier must NOT sit behind publication. Angular owns
observation, so an authoring extension that waited for Angular publication would
inherit a framework dependency it has no business having — and would break in
any non-Angular realization.

**PROJECT — DERIVED PROPOSAL: NOT an extension boundary.**

F6 is decisive: projection "never determines authority". Exposing it publicly
would invite extensions to influence realization, and would leak realization
concerns into a semantic authoring contract. Nothing an extension legitimately
needs is first available at PROJECT.

**PUBLISH — DERIVED PROPOSAL: framework-adapter boundary, NOT general authoring
API.**

Direct from F2. The Angular adapter owns this. Ordinary authoring extensions sit
deliberately BELOW publication, which is also what makes them portable across
realizations. **DERIVED PROPOSAL: publication observation is not part of the
neutral authoring SDK.**

**PERSISTENCE CONSEQUENCE — DERIVED PROPOSAL: a governed mechanism, NOT a
general post-commit effect tier.**

F7, F10 and the durable-gate invariant already give this strong, specific
semantics: consequences are gated on tree-local settled state, and "callers
describe a consequence; they do not decide when it runs." Generalizing this into
"any extension may run arbitrary effects after commit" would discard that
governance. An extension wanting arbitrary post-commit work belongs in the
observation tier and owns its own scheduling.

#### Causal meaning stays ORTHOGONAL

Per F3, physical phase and causal meaning are different axes. The same committed
physical mutation may be authored, derived, speculative, confirmed, or the
realization of a rollback/undo/redo.

**DERIVED PROPOSAL, phase-level only:** causal attribution must be ESTABLISHED at
or before PREPARE (the proposal knows who authored it and why) and PRESERVED
through to the observation tier. What history actually receives is MUT-2, not
this slice.

#### The proposed public model, in full

```
1  PREPARE PARTICIPANT             may refuse         OPEN: wanted at all?
2  COMMITTED SEMANTIC OBSERVER     observe only, transaction-granular,
                                   below publication, causally attributed
—  PRIVATE COMMIT / PROJECT        NOT extension boundaries
—  PUBLISH                         Angular adapter only
—  CONSEQUENCE                     governed mechanism, not an observer tier
```

**REVISED CENTRAL RESULT.** The previous draft concluded "the SDK plausibly
needs one public tier". That was the premature step. Corrected:

```
internal lifecycle boundaries exist          YES, frozen
some subsystems must act at them             YES
ANY public participation API is required     UNPROVEN — possibly NONE
```

"None" must stay a live answer. The subsystems that react to committed truth may
each integrate with the authority that owns the information they need, with no
shared observation contract at all.

#### Challenge cases — "can this actor's legitimate responsibility be placed

cleanly?", NOT "where does it run today"

```
schema           tier 2. Observe-only by design, needs attribution for
                 suppression. Placing it in PREPARE would grant authority its
                 requirements do not ask for.                        CLEAN
guardrails       tier 2. Authoring-time diagnostics, reports.        CLEAN
devTools         tier 2 for state; publication timing is Angular's.  CLEAN
persistence      CONSEQUENCE, already governed.                      CLEAN
restoration       tier 2 + causal axis. OPEN: does recording need more
                 than an observer can see? MUT-2.              NEEDS MUT-2
transactions     NOT an extension of this model — it DEFINES the semantic
                 unit that tier 2 observes.                          CLEAN
realtime         tier 2 inbound; outbound is an ordinary write.      CLEAN
third party      tier 2.                                             CLEAN
Angular adapter  PUBLISH. The only actor there.                      CLEAN
```

**COUNTEREXAMPLE NEEDED before this proposal can be frozen:**

```
C1  an authoring case that must REFUSE a write, not merely report on it
    (absent this, tier 1 is speculative surface and should not ship)
C2  an authoring case that legitimately needs per-PHYSICAL-commit granularity
    (would contradict the transaction-granular derivation from F8+F9)
C3  an authoring case that must observe PROJECT or PUBLISH
    (would contradict F6/F2 and force reopening those boundaries)
C4  a consumer needing transformation rather than refusal
    (would strain F1 — SignalTree owns truth)
```

### The four questions this slice must answer, in order

```
MUT-1  PHASES     which semantic phases may extension authors participate in?
                  PREPARE / PRIVATE COMMIT / PROJECT / PUBLISH / CONSEQUENCE
MUT-2  ONTOLOGY   what identity, value and attribution exist AT EACH PHASE?
MUT-3  SCOPE      how is observation bound to ONE tree lineage rather than
                  process-global state? A global singleton requiring consumers
                  to filter foreign trees is evidence about current plumbing,
                  not a candidate public contract.
MUT-4  CONSUMERS  map schema, causal history, transactions, time travel,
                  persistence, devtools, realtime and third parties onto those
                  contracts — including which need NONE of them.
```

Only AFTER those: _can `MutationEnvelope` + `PathNotifier` be refactored into
this model?_ Plausible outcome — envelope survives largely intact, the notifier
becomes a tree-scoped dispatcher, and the flattened callback, the global
singleton, the post-hoc "interceptors" and `interceptLeafSignals` are all
deleted. Or the derivation produces something else; that is why it comes first.

### Where the leaf-realization root cause belongs

AFTER the contract is stated, not before. The question then becomes the useful
one:

> Why do ordinary leaf writes fail to enter the canonical semantic mutation
> pipeline?

rather than the old-mechanism-centred:

> Why does `interceptLeafSignals` not wrap them?

**Do not repair `interceptLeafSignals`. Do not promote `PathNotifier` to public
architecture. `schemas()` migration remains blocked.**

### ANG-V0 — the Angular question, run against the HARSHEST null — **CLOSED**

V0.6's reversal left exactly one open function: whether an ANGULAR-REACTIVE
VALIDATION PROJECTION must be owned by SignalTree's Angular layer.

The first phrasing was too generous. It named the candidate — "a general
Angular-reactive validation projection" — and asking whether that is required
already concedes that a SignalTree-owned projection OBJECT is the thing under
discussion. Starting from `validation.errors()` / `validation.isValid()` builds
the answer into the question. The null was hardened to:

> **ASSUME `@signaltree/schema` DOES NOT EXIST and SignalTree exposes NO
> validation-specific Angular API. What required Angular workflow becomes
> impossible?**

with the null implementation being ordinary Angular composition:

```
SignalTree publishes Angular-readable truth
            v
       Angular computed / effect
            v
  application-owned validator
            v
     validator-native result
```

Falsifier: **not** "a projection API is convenient" — a REQUIRED WORKFLOW that
cannot be implemented correctly without SignalTree-specific knowledge.

Evidence: `packages/core/src/lib/angular-validation-null.spec.ts`, 21 tests,
GREEN. The file may not import `@signaltree/core/authoring` for the null; the
one section that touches `interceptLeafSignals` does so to characterize it.

#### ANG-V0-A/B — sync

The null tracks every published write form: nested leaf `.set()`, branch
call-form, branch updater, root write, root read after a deep leaf write, and
leaf-scoped reads. It is also already PRECISE — it does not recompute for an
unrelated sibling write, does not recompute for a deep-equal write that never
landed, and a per-field projection recomputes only for its own field
(`nameRuns` stayed 1 while `ageRuns` went to 2).

This kills the strongest sync argument, which was that SignalTree knows WHICH
PATHS a write touched and plain `computed` does not, so the null must
over-validate. Measured: it does not.

#### ANG-V0-C — async, tested separately so it could not rescue the abstraction

The question was never "is manual async validation annoying". It was whether
correct async validation needs information only SignalTree can provide.

An `effect` + an evaluator-local generation counter, owned entirely by the
consumer, handles out-of-order resolution correctly: three runs dispatched
(initial, W1, W2), resolved newest-first, stale verdicts discarded, final state
`verdict-for-second`. Pending/settled fall out as ordinary Angular signals.

Same async ownership result V1 already established, now confirmed in the
Angular-reactive case. No SignalTree semantic primitive was required.

#### ANG-V0-D — is any truth change invisible to the pull surface?

The real reason `@signaltree/schema` exists in its current form is that it does
NOT use `computed`. It attaches `interceptLeafSignals` and validates PUSH-side.
So: is there validation-relevant truth that changes without notifying the
Angular read surface?

Measured across marker classes: `entityMap` CRUD, `status` transitions and
`form`-marker field writes are ALL visible to a plain `computed`. A control
confirms a computed that reads nothing never recomputes, so the section is
falsifiable. A `status` marker projects its VALUE into the root snapshot
(`{ state: 'NOT_LOADED', error: null }`), so a whole-object validator receives
ordinary data, not a marker object.

**No candidate found.**

#### ANG-V0-F — the converse, and the decisive result

D found nothing invisible to pull. F asks the honest converse: does PUSH see
anything PULL misses?

```
CASE                                   PULL      PUSH
nested leaf write, depth 40            saw       MISSED  (seen === [])
lazily materialized node write         saw       saw     ('f299.a')
ARRAY-VALUED LEAF write                saw       MISSED  (seen === [])
entityMap CRUD                         saw       saw     ('rows')
```

**CORRECTED CLAIM.** "Push is a strict subset of pull" asserts a universal
set-theoretic relation the evidence does not reach. The measured claim:

> **In the tested mutation classes, Angular pull observation covered every case
> push covered, and additionally covered ordinary cases push missed. NO
> CAPABILITY ADVANTAGE FOR PUSH WAS ESTABLISHED.**

That is what the four rows support -- two misses, two parities -- and it is
sufficient, because the abstraction needed an advantage and has none. The
privileged mechanism is not more capable than the null, and its own docblock
says why: it
wraps `.set`/`.update` by WALKING THE TREE AT ATTACH TIME, with `maxDepth = 32`,
skipping built-ins and arrays. `computed` has no depth cap and no shape
snapshot; it subscribes to whatever it reads, when it reads it.

The array miss deserves naming. An array-valued leaf — `tags: string[]`,
`items: T[]` — is one of the most ordinary things an application validates, and
the interceptor reports nothing for it.

SCOPE OF THAT CLAIM: measured on `interceptLeafSignals` directly, from core.
`@signaltree/schema` was NOT executed here, so this is not yet a proven
end-to-end schema defect — but schema's continuous invalidation routes through
that callback, so it is the expected consequence.

#### ANG-V0-G — the forms adapter, which INVERTS the last candidate

Candidate 4 was that the forms adapters need a shared Angular validation
projection they cannot get from validator-native results. Measured against
`@signaltree/ng-forms/signals`, which is the only first-party consumer.

`applySignalTreeSchemas` reads exactly two things:

```
tree.schemas.boundPaths()        -> dotted paths
tree.schemas.schemaFor(fullPath) -> the raw StandardSchemaV1 the APP registered
```

then calls Angular's own `validateStandardSchema(field, schema)`.

It reads **`errors()`, `errorList()`, `isValid()`, `pending()`, `pendingPaths()`,
`errorsAt()`, `isValidAt()`, `isPendingAt()`, `validate()`, `validatePath()` —
NONE of them.** The entire validation-projection surface of
`@signaltree/schema` is UNUSED by SignalTree's own forms adapter. Angular Signal
Forms runs the validator itself.

Candidate 4 does not merely fail. It INVERTS: the adapter is already an existence
proof of the correct architecture — the application supplies validators, Angular
runs them, SignalTree publishes truth. The bridge treats `schemas()` as a
**path -> schema REGISTRY**, and that registry's content is the plain object
literal the application handed to `schemas({ schemas: { ... } })`.

The only genuinely tree-aware residue is WILDCARD EXPANSION — resolving
`items.*.name` against actual topology (`WILDCARD`, `compilePattern`,
`enumerateLeafPaths`). Name it honestly: that is PATH-PATTERN EXPANSION OVER
TREE TOPOLOGY, not validation. It is needed only because the registry is keyed
by path, and a bridge given the schema map directly could expand it against the
tree with no enhancer, no installation and no projection.

#### ANG-V0 — RESULT

```
@signaltree/schema PACKAGE                    DELETE
SignalTree validation API                     NONE
SignalTree Angular validation projection      NONE

Angular application
    observes SignalTree using Angular
    validates using its chosen validator
```

The continuous-Angular-projection requirement is DELETED, not relocated. The
package is not moved sideways into the Angular layer; it is deleted, and its
one first-party consumer is rewritten to take the schema map directly.

**WHAT THIS SECTION PROTECTS AGAINST.** "Angular owns observation" must never be
allowed to become "therefore SignalTree ships wrappers for every useful Angular
observation." Those are different claims. The first says Angular mechanisms are
the correct LAYER for observation. It does not make SignalTree responsible for
packaging every `computed`, `effect` or projection an Angular consumer might
want. Precomposed application code attached to a tree is the `formBridge`
failure pattern with computed validation state substituted for `FormGroup`s:

> useful behaviour != semantic capability != reason to hang methods on
> SignalTree.

Final ownership, no fourth owner required:

```
SignalTree     publish state so Angular can observe it
Application    compose computed/effect/resource over that state
Validator      judge the supplied value
Forms adapter  translate between Angular Forms and validator results
```

#### Consequence for the SCHEMA REGRESSION blocker below

The 25 RED schema tests and the leaf-realization root cause are now **MOOT AS A
RELEASE BLOCKER**. The package is deleted, not repaired. What survives from that
investigation is the CORE finding it exposed — ordinary leaf writes do not enter
a canonical semantic mutation pipeline — which belongs to MUT, not to schema,
and is where it was already filed.

#### Consequence for `form()`

`form()` now enters its audit with ZERO validation residue:

```
gone as justifications:
  Reactive Forms integration
  Signal Forms integration
  validation declaration
  validation execution
  validation results
  validation observation
```

Leaving only the underived historical bundle: `dirty`/`touched`, `submitting`,
`wizard`, `reset`/`clear`/`patch`.

**Do not audit `form()` as a unit.** Audit each function independently, then ask
at the END whether any surviving function requires CONSTRUCTION-TIME form
semantics. If none does, the marker dies even if several helpers survive
elsewhere.

## SCHEMA-DEL — EXECUTION BOUNDARY, derived before any production change

Rule 0h: the endpoint is frozen, so the order is ENDPOINT -> BLAST RADIUS ->
MIGRATE. Auditing `form()` while a dead package and its consumer wiring stay in
place would let deleted structure keep shaping the next audit.

```
FROZEN
@signaltree/schema                         DELETE
SignalTree validation API                  NONE
SignalTree Angular validation projection   NONE

NOT ALLOWED
recreating schemas() under another name    new validation registry
a new tree enhancer                        new validation result model
new observer / invalidation machinery      a generic topology utility
```

### THE DERIVATION — what is the minimum input the Signal Forms adapter needs?

The proposed replacement was `applySignalTreeSchemas(form, tree, schemaMap)`,
with wildcard expansion local to the adapter. Run hostile, the answer subtracts
further than that.

**MEASURED — Angular Signal Forms already has a first-class schema mechanism,
and this adapter already supports it.** `signal-form-schema.spec.ts` (3 tests,
pre-existing) exercises `signalForm(tree.$.profile, { injector, schema })` where
`schema` is Angular's own `SchemaFn`, calling Angular's own `disabled()` and
`validate()`. And `validateStandardSchema` — the function the deleted bridge
ends up calling — is an `@angular/forms/signals` export, not ours.

So the application already has, from Angular alone:

```ts
signalForm(tree.$.account, {
  injector,
  schema: (root) => {
    validateStandardSchema(root.username, z.string().min(3));
  },
});
```

**MINIMUM INPUT REQUIRED FROM SIGNALTREE: NONE.**

Therefore `applySignalTreeSchemas` and the `signalForm(tree, rootPath, subtree)`
overload are DELETED, not rewritten. **Do not build
`applySignalTreeSchemas(form, tree, schemaMap)`** — it would be a thinner
version of the same mistake: SignalTree packaging an Angular composition the
consumer can already write, which is the `formBridge` pattern one more time.

Supporting measurement — the deleted route was never load-bearing. The
`schemas()` call shape has exactly ONE test
(`marker-bridge.spec.ts:422`), and that test asserts only two-way binding
between the FieldTree and the subtree. **It never asserts that a validation
error surfaces.** Two-way binding comes from `toWritableSignal`, which the
marker route provides anyway.

### THE WILDCARD SUBTRACTION — asked, and it deletes too

> Does Angular Signal Forms actually require wildcard declarations like
> `items.*.name`, or is that convenience inherited from `schemas()`?

```
WILDCARD COVERAGE IN packages/ng-forms/src/signals/     ZERO
```

Never supported, never tested, on the Signal Forms side. Wildcard IS an
established product capability — but of the REACTIVE FORMS adapter, which is a
different consumer, and it does not come from `@signaltree/schema`:

```
packages/shared/src/lib/match-path.ts   matchPath(pattern, path), isGlobKey(key)
packages/ng-forms/src/core/ng-forms.ts  glob validator keys ('phones.*.value')
                                        LAZY MATCH-ON-DEMAND — no enumeration,
                                        no registry, no bound-path list
```

So schema's `compilePattern` / `enumerateLeafPaths` / `matchLeaf` is a SECOND
implementation of a capability that already ships elsewhere, in a worse shape
(eager registry vs lazy match). **Deleting `@signaltree/schema` deletes a
duplicate, not a capability.** Nothing is extracted, nothing is generalized, and
no topology utility is created — the surviving implementation is the one already
in use by the adapter that actually has the requirement.

`boundPaths()` and `schemaFor()` existed only because the enhancer compiled a
path registry. The registry dies with the enhancer.

### EXECUTION PLAN — one bounded migration, its own commit

```
1  remove the @signaltree/schema package, workspace entry and path mappings
2  remove schemas() and its types / internals / tests
3  remove the schema dependency from consumers
4  delete the ng-forms/signals schema route; apps use Angular's own `schema:`
5  delete schema-specific release blockers
6  retain ONLY the independent MUT finding
7  run affected package tests / types / lint
8  commit as its own architectural boundary
```

Historical records — CHANGELOGs, `docs/audits/**`, `docs/research/**`,
`docs/rfcs/**` — are NOT rewritten. They record what was true when written.

### ONE EVIDENCE-HYGIENE RULE FOR THE NULL SPEC

`angular-validation-null.spec.ts` must NOT permanently contract the deficiencies
of `interceptLeafSignals`. The POSITIVE Angular-publication tests are the
durable result and stay. The ANG-V0-F negative characterization served its
evidentiary purpose the moment the deletion was decided, and a mechanism already
headed for hostile audit under MUT must not acquire accidental test-backed
legitimacy — a suite asserting `maxDepth = 32` behaviour is a suite that has to
be updated when the mechanism is deleted, which is backwards. F is therefore
marked EVIDENCE, SUPERSEDED and removed at execution; its four measured rows
survive in this ledger, which is where a one-shot measurement belongs.

## MERGE — DEFERRED PRODUCT QUESTION, with preconditions MEASURED

Raised as a forward-looking model, not a slice: if SignalTree gains divergent
causal histories, merging could be modelled on Git's ancestry + three-way merge
rather than on `merge(current, incoming)`.

```
             BASE                 base=A ours=B theirs=A  -> B
              |                   base=A ours=A theirs=C  -> C
        +-----+-----+             base=A ours=B theirs=B  -> B
        |           |             base=A ours=B theirs=C  -> CONFLICT
      OURS        THEIRS
        \         /
          MERGED STATE
```

The genuinely interesting part is SCOPE, not mechanism: Git merges text hunks,
SignalTree would merge SEMANTIC POSITIONS. `ours.users[42].name` vs
`theirs.users[42].age` need not conflict; with `entityMap`, editing entity 42
while another branch adds entity 73 need not treat the collection as one blob.

**CARRIED FORWARD — the narrow form, which is all that is claimed:**

> If SignalTree eventually supports divergent causal histories, model merging as
> ANCESTRY-AWARE RECONCILIATION, keep DETECTION separate from RESOLUTION, and
> allow resolution policy to vary by SEMANTIC SCOPE.

Three sub-claims worth keeping distinct, because they have different owners:

```
DETECTION    "these two semantic changes disagree"     engine, truth-bearing
RESOLUTION   "therefore ours wins"                     policy, replaceable
LEGALITY     "these histories cannot merge at all"     REFUSED, a third outcome
```

Keeping detection replaceable-independent is the load-bearing bit: a strategy
swap must not weaken the truth of conflict detection. And LAST-WRITE-WINS IS ONE
SELECTABLE POLICY, NOT THE DEFINITION OF MERGING. Equally, SignalTree must never
infer policy from type — seeing two numbers and deciding "numbers get summed" is
the domain owner's call, never the framework's.

Also carried: a conflicted merge should NOT immediately become canonical truth.
Git's conflicted index is the right precedent — a candidate merge is a value
OUTSIDE canonical state until committed.

### PRECONDITIONS — MEASURED AT HEAD, and they do not hold

Before any of this is designable, three-way merge needs a merge base. Measured
rather than assumed:

```
CausalTurn = { id, effects, participants, state }
                              causal-runtime/causal-types.ts:30

ANCESTRY GRAPH        ABSENT      no parent / ancestors field on CausalTurn
MERGE BASE            NOT COMPUTABLE
DIVERGENT LINEAGE     ABSENT      TurnStore holds ONE linear
                                  `orderedConfirmedTurnIds` and ONE
                                  `frontiers: Record<PositionId, TurnId>`
BASE DURABILITY       CONTRADICTED
REALTIME CONFLICT     ZERO        no conflict / lastWrite / authoritative
                                  vocabulary anywhere in packages/realtime/src
```

**The eviction finding is the sharp one, stated at exactly its true width.**
`TurnStore` is a CAPACITY-BOUNDED RING that evicts (`capacity`,
`onEvictConfirmedTurn`, and a `'history-evicted'` failure reason on both
pending-turn transitions). The base is by definition OLD -- it is the point
BEFORE the divergence -- so the longer branches live, the more certain its
eviction becomes. The requirement this proves:

> **The current bounded `TurnStore` cannot serve as durable merge ancestry.
> Three-way merging would require an INDEPENDENTLY RETAINED ancestry/base
> concept whose lifetime is NOT governed by the reversible-history capacity.**

**It does NOT prove `merge support -> unbounded TurnStore`.** That inference is
unestablished and must not be smuggled in later. A separately justified design
could retain parent ids, checkpoint identity, a base snapshot or hash, or a
compacted causal summary while still evicting detailed reversible turns. What is
ruled out is only reusing the reversible-history window AS the ancestry.

`frontiers` deserves LESS credit than "exactly what divergence detection
compares". A `PositionId -> latest TurnId` map is potentially useful input, but
WITHOUT ANCESTRY IT CANNOT DISTINGUISH SUCCESSION FROM CONCURRENCY. Given only

```
ours[P]   = T41
theirs[P] = T57
```

nothing answers whether T41 is an ancestor of T57, T57 of T41, or neither -- so
these two shapes are indistinguishable:

```
linear evolution          divergence
T41 -> ... -> T57              Tbase
                               /   \
                             T41   T57
```

Different latest-turn ids are not evidence of divergence. That is a constraint
for realtime, not just for merge.

### TWO DEFECTS IN THE SKETCH, named now so they are not inherited

**1 — the rule address silently picks the one identity kind that cannot cross.**

```ts
rules: [{ at: tree.$.preferences, resolve: 'theirs' }];
```

`tree.$.preferences` is a live NodeAccessor from OUR tree — a REALIZATION HANDLE.
The entire premise of merging is that the two sides diverged, so a rule must
address a position in a tree it is not attached to. Under the frozen invariant
`PositionId != SubjectId != SlotIndex != key/path`, a realization handle is the
one address with no meaning on the other side. Any future merge API must choose
its address kind DELIBERATELY and say which of the four it is; the ergonomic
spelling is what makes this easy to get wrong.

**2 — "the kernel makes it possible" is not "SignalTree should ship it."**

This is the V0.6 trap verbatim, and it is worth stating explicitly one slice
after paying for it. A capability enabling something is not a requirement to
offer it. Merging is a PRODUCT DECISION gated on realtime/multi-writer
semantics actually demanding branching and reconciliation — and three-way
semantic merge is only one candidate product there, alongside CRDTs and
server-authoritative overwrite. The kernel should carry stable identity, causal
ancestry, atomic turns and canonical truth because THOSE are derivable; merge
POLICY is a different layer and must not be pulled into the kernel because it
would be convenient to have it there.

### ONE FALSIFIABLE HYPOTHESIS, worth tracking through MUT

> undo, redo, rollback, branch, merge and conflict resolution are all operations
> over ONE causal-history substrate, not five unrelated features.

As a description of HEAD this is FALSE, and measurably so: `new TurnStore()`
appears in exactly one place — `transactions.ts:926` — so time travel does not
run on the causal runtime, and history, transactions and time travel are three
separate mechanisms today. That makes the statement a DESIGN TARGET with a known
current truth value, which is the useful kind. If MUT's contract lands and those
features still cannot be expressed over the one substrate, the hypothesis is
refuted and the substrate is not what it claims to be.

**STATUS: DEFERRED. No API designed, no kernel requirement created.** Revisit
only when realtime product semantics establish that divergent histories exist.

## SCHEMA REGRESSION — **CLOSED AS MOOT.** Package deleted, not repaired

**The package is gone (SCHEMA-DEL EXECUTED). Nothing below is a release
blocker.** It is kept because the investigation produced one finding that
survives the deletion and belongs to MUT: _ordinary leaf writes do not enter a
canonical semantic mutation pipeline._ Read the rest as evidence for that, not
as work.

```
FIRST BAD    d8824b91  feat(history): scaffold causal runtime kernel
PARENT       d8824b91~1
RANGE        v14.1.1 .. 0693f683  (193 commits, 7 bisect steps)
PREDICATE    schema's own Nx test target (`vitest run` in packages/schema),
             not a hand-picked invocation — the runner lesson applies to the
             bisect classifier too. `demo:test` deliberately EXCLUDED from the
             predicate: its 4 failures are the same defect and would only add
             noise. It is a repair confirmation instead.
```

### The observable change — CONFIRMED

`d8824b91` does not touch `@signaltree/schema` at all. It changes
`interceptLeafSignals`, the PUBLIC authoring API schema observes writes through.

```
                       leaf `.set` replaced?   callback paths
d8824b91~1             (not measured)          ["count","user.name"]
current HEAD           NO                      []
```

At HEAD the interceptor does not wrap a plain leaf's `.set` AT ALL — the
identity of `leaf.set` is unchanged after `interceptLeafSignals()` runs. So the
callback is not merely filtered; the wrapping never happens.

### MECHANISM — RETRACTED, still unresolved

This section previously asserted the cause was the new early-return:

```ts
const hasOwnedMutationEmitter = hasIntrinsicMutationEmitter(node);
if (hasOwnedMutationEmitter) return false;
```

**That is REFUTED.** Measured on a plain leaf of a default `signalTree()` at
HEAD:

```
own symbols on the leaf   ["Symbol(SIGNAL)"]     <- Angular's only
intrinsic emitter         false
owned positionIds         null
```

With no intrinsic emitter the skip cannot fire, so it is not what stops the
wrapping. The claim was inferred from reading the diff rather than measured, and
it is corrected here rather than left standing.

Two further measurements, both negative, that narrow the search:

- `getPathNotifier().subscribe('**', …)` receives NOTHING for plain leaf writes,
  with or without `restoration()` applied. So the new capture path is not
  silently taking over delivery either — nobody observes those writes.
- `emitOwnedMutation` early-returns when `positionIds?.[0]` is `undefined`, and
  plain leaves have no positionIds. That is consistent with the silence but does
  not explain the missing WRAPPING, which happens earlier and independently.

**The effect is confirmed and reproducible; the mechanism is not yet
established.** It needs a focused root-cause pass — most likely on how leaves
are realized in `createSignalStore`/`materialize-markers` at HEAD versus the
parent, not on `interceptLeafSignals`' own diff.

### Direct consequence — this part stands

Schema's callback never fires, so no verdict is ever applied, which is exactly
the observed failure family: `isValid` stays `true` ("expected true to be
false") and the errors map stays empty ("expected undefined to be 'a-err'").
The bisect result and the consequence are solid; only the mechanism above was
overclaimed.

### Why this is the most consequential finding of the slice

`interceptLeafSignals` is exported from `@signaltree/core/authoring`. It is the
supported way a third-party enhancer observes leaf writes, and the ledger
already flags it as the last genuine SDK symbol dragging Angular. Its contract
was narrowed by an internal kernel change, and the only external consumer in the
repo broke silently for ~150 commits.

### Repair hypotheses — CANDIDATES ONLY, not chosen

```
A  restore the public contract: interceptLeafSignals delivers callbacks for
   owned-emitter nodes too, so an external observer sees every leaf write
B  migrate schema onto the new mutation-capture path, accepting that the
   authoring contract narrowed deliberately
```

A treats the narrowing as an unintended break of a supported API; B treats it as
an intentional redesign that schema simply never followed. **Do NOT revert
`d8824b91`** — this branch carries ~150 commits of intentional 15.0 work built
on that kernel; the commit locates where the invariant was lost, it does not
prescribe the endpoint.

The deciding question is whether `interceptLeafSignals` is still meant to be the
supported leaf-observation contract for third-party authors. That is a Gate B
API decision, not a repair detail.

## VALIDATION LADDER — workspace test rung (rung retained; its trigger is gone)

**Building a package is not evidence that its runtime contract passes.** The
ladder ran `nx run-many -t build --all` and tested CORE ONLY, so
`@signaltree/schema` sat 25 tests red through ~150 commits while every gate
reported green — and Gate B reasoning repeatedly leaned on "runtime unchanged".

The rung is added NOW, before schema is repaired. It is expected to be RED until
then. That is the information, not noise.

```
1. targeted slice tests          diagnosis — keep these, they read clearly
2. package-specific tests        the package being changed
3. nx run-many -t test --all     nothing else silently red
4. typecheck / lint / build / API / declaration gates
```

Rungs 1-2 stay: `nx test <project>` swallows the reporter, so targeted runs are
still how a failure gets identified. Rung 3 is what stops another package
sitting red unnoticed.

> **GATE B may not claim repository behavioural health until every package test
> target passes.** Record the baseline BY IDENTITY, as with the demo build —
> if `test --all` exposes further failures, characterize them before attributing
> them to a known cause.

**Ask the project's Nx target which runner it uses.** `vitest run --root` gives
false readings for Jest projects — "no tests" for `ng-forms`, "27 failed" for
`demo`. Both were artifacts.

## ~~BLOCKER #4a-2~~ — **VOID.** The 25 RED tests were deleted with the package

Found while capturing the pre-migration runtime baseline for `schemas()`.

```
guardrails   62 passed / 1 skipped
realtime     34 passed
schema       25 FAILED / 15 passed      <-- only red package
ng-forms     Jest, not vitest — `nx test ng-forms` exits 0
events      221 passed
shared       80 passed
```

Nine of ten schema spec files fail: `aggregates`, `ancestor`, `compact`,
`smoke`, `suppress`, `sync-fast-path`, `walker-conformance`, `wildcard`,
`write-sequence`. Real assertion failures ("expected true to be false",
"expected undefined to be 'a-err'"), not infrastructure.

**PRE-EXISTING, and proven so rather than assumed.** Two independent checks:

1. Substituting `signal-tree.ts` from before `681ffb8e` (the capability-authority
   repair) reproduces the identical 25/15 split — so neither `681ffb8e` nor
   `7a6bd4c9` caused it.
2. A worktree at the SESSION-START commit `0693f683` reproduces the identical
   25/15 split.

**WHY NOBODY NOTICED — a real gap in the validation ladder.** The ladder runs
`nx run-many -t build --all`, which BUILDS every package, and `vitest run` for
CORE ONLY. No step runs the other packages' tests. A package can be entirely red
and every gate stays green. `nx run-many -t test --all` belongs in the ladder;
its absence is why 25 failures survived to Gate B.

### 14.x disposition (Rule 0f) — MEASURED: 15.0 BEHAVIOURAL DIVERGENCE from 14.x, no 14.x patch

```
v14.1.1                 10 files / 40 tests   ALL PASSING
branch start 0693f683    9 failed / 1 passed   25 failed / 15 passed
current HEAD             9 failed / 1 passed   25 failed / 15 passed
```

Identical test COUNT at the tag and at HEAD — no specs added or removed, the
same tests now fail. So:

```
14.x ACTION        NO ACTION — v14.1.1 is green, nothing to patch
15.0 DISPOSITION   REGRESSION introduced somewhere in this branch's ~150
                   commits. Must be repaired before Gate B.
```

Ownership is not in question: the 15.0 workstream owns getting HEAD green
regardless of where the defect entered. Rule 0f only decided whether there is an
ADDITIONAL 14.x maintenance obligation, and there is not.

### `demo:test` — 4 failures, SAME defect

`nx run-many -t test --all` also fails `demo:test`. Measured rather than
attributed: 26 suites, 25 passed, 4 tests failed, and ALL FOUR are
`SchemaDemoComponent` — downstream of the schema regression, not an independent
defect.

RUNNER-MISMATCH TRAP, hit twice and worth stating as a rule. `vitest run --root
apps/demo` reports "27 failed" and `--root packages/ng-forms` reports "no
tests"; both are ARTIFACTS — those projects run on Jest. Ask the project's Nx
test target what runner it uses; do not assume one runner across the workspace.

### Workspace test baseline, by identity

```
schema:test   25 failed / 15 passed   the regression
demo:test      4 failed / 177 passed  all SchemaDemoComponent, same defect
core:test     documented flaky timing specs (Phase 5); reads clean via
              `npx vitest run --root packages/core`
```

Everything else green: guardrails 62/1 skipped, realtime 34, events 221,
shared 80, ng-forms `nx test` exit 0.

### Effect on #4a-2 — `schemas()` migration is BLOCKED

Rejected the "identical failure set before and after" shortcut. That discipline
is sound for the demo build because those failures are OUTSIDE the package being
changed. Here it would mean changing `@signaltree/schema` while a quarter of its
own behavioural tests are red — which can show the change made nothing worse,
but cannot show the migrated enhancer preserves the behaviour those tests exist
to cover.

Repair schema and establish a green baseline first. The characterization at
`c1213225` stays frozen and is unaffected.

The `schemas()` CONSUMER CONTRACT characterization is unaffected and green — it
is type-only.

## SCHEMA-DEL — **EXECUTED**

The frozen endpoint, applied. One bounded migration, no new abstraction.

```
DELETED
packages/schema/**                      the whole package, 40 files
packages/ng-forms/src/signals/bridge.ts applySignalTreeSchemas
signalForm(tree, rootPath, subtree)     the schema overload
apps/demo/.../schema-demo/**            the demo page + route
docs/architecture/schema-enhancer-plan.md
docs/skills/using-signaltree/schema/**
```

Config followed the code out: `tsconfig.base.json` path mappings, ng-forms
`package.json` peer + peerDependenciesMeta + devDependency, its `tsconfig.lib`
paths and `jest.config` moduleNameMapper, the demo's asset-copy glob and
`project.json`, `lint-skills` resolver, `ship-skills` package list, the
AI-codegen benchmark library list and scorer, and the pnpm lockfile.

**NOTHING WAS RECREATED.** No `applySignalTreeSchemas(form, tree, schemaMap)`,
no registry, no wildcard utility. The demo, the ng-forms README and `llms*.txt`
now show the surviving pattern, which is ordinary Angular:

```ts
form(
  toWritableSignal(tree.$.user),
  (u) => {
    validateStandardSchema(u.name, z.string().min(2));
  },
  { injector }
);
```

`toWritableSignal()` is PUBLICATION and survives on its own terms. It is what
"SignalTree owns truth, Angular owns observation" actually looks like.

One consequence worth naming: the deleted overload was the only way to build a
Signal Forms `FieldTree` from a NON-MARKER subtree. That capability is not lost,
it is relocated to where it belonged — Angular's own `form()` over a published
writable signal.

### ANG-V0-F removed from the null spec, as required

The negative characterization of `interceptLeafSignals` is gone from
`angular-validation-null.spec.ts`; the 17 positive Angular-publication tests
remain. Its four measured rows live in this ledger. The mechanism's own docblock
in `intercept-leaf-signals.ts` now records that it lost its last external
consumer and shows no measured advantage over `computed`, and that it is queued
for hostile audit under MUT — a comment, not a test contract.

### VERIFICATION — by identity, not by count

```
core:test        1761 passed / 20 skipped / 1 todo    exit 0 ALONE
ng-forms:test    109 passed  (11 suites)              exit 0
demo:test        174 passed  (25 suites)              exit 0  <- was 4 FAILED
guardrails / realtime / events / shared                exit 0
lint  (all projects, + scripts separately)             exit 0
build core/ng-forms/guardrails/realtime/events/shared  exit 0, fresh artifacts
```

`demo:test` was the recorded baseline's only test-rung red — _"4 failed / 177
passed, all SchemaDemoComponent, same defect."_ Those four died with the
component. **The workspace test ladder is now green.**

TWO PRE-EXISTING REDS, stated so they are not silently inherited:

```
core:test under PARALLEL run-many
  1 failed: production-scalar-substrate.benchmark.spec.ts
            "public undo-of-remove realizes through one incremental restore"
            10885ms — the documented Phase-5 flaky TIMING class. Green alone.

nx build demo
  4 TS errors, ALL in files this change never touched:
    form-marker-demo.component.html:600,625,627  FormHistoryApi
      'clearHistory' / 'history' do not exist
    packages/core/src/lib/types.ts:638           TS4114 missing 'override'
  Confirmed untouched via `git diff --name-only HEAD`; neither file imports
  the deleted package. Recorded BY IDENTITY so the next build compares
  diagnostics, not counts.
```

The `types.ts:638` TS4114 is worth a look on its own — a missing `override` in
core surfacing only through the demo's compiler settings is a real defect, just
not this one's.

## `form()` AUDIT — seven functions, INDEPENDENTLY

The field is cleared: no schema package, no SignalTree validation ontology, no
Angular validation wrapper, no Reactive Forms justification, no Signal Forms
justification. `form()` inherits nothing.

**The unit of audit is the FUNCTION, not `form()` and not "form session".**
Each gets the same seven rows, with the current implementation revealed LAST
(Rule 0g). Only after all seven dispositions are known:

> Did any surviving function establish an INTRINSIC SEMANTIC PROPERTY OF A
> POSITION that must participate in construction / compilation?

If not, `form()` the MARKER dies — however many useful helpers survive
elsewhere.

**`dirty` and `touched` are deliberately NOT paired.** Frameworks present them
together, which is exactly why the pairing must not be assumed:

```
dirty     a COMPARISON question   has value diverged from some baseline?
touched   an INTERACTION question has a user/UI interaction occurred?
```

Different questions, potentially different owners. Evidence for this section:
`packages/core/src/lib/form-function-audit.spec.ts` (TEMPORARY; deleted when the
dispositions freeze, same protocol as ANG-V0-F).

### AUDIT ROW — F1 `dirty`

```
FUNCTION       Report whether current values differ from a baseline the user
               would recognize as "saved" / "unchanged".
OWNER          Whoever owns the BASELINE. That is the application: only it knows
               when a save succeeded, when a draft was accepted, when a
               server-hydration is the new zero point.
GREENFIELD     const baseline = signal(tree.$.p());
MECHANISM      const dirty = computed(() => !eq(tree.$.p(), baseline()));
               ...and after a successful save: baseline.set(tree.$.p());
SIGNALTREE?    NO. It needs a value read and an equality function. The read is
               already published; the equality is the application's (deep,
               shallow, field-subset, ignore-whitespace are all legitimate and
               domain-dependent).
CONSTRUCTION?  NO -- and MEASURED to be actively harmful, see below.
```

**CURRENT FORM, revealed last.** `initial` is captured at CONSTRUCTION and never
moves:

```ts
const dirty = computed(() => {
  const current = valuesSignal();
  const eq = config.equalityFn ?? defaultEquality;
  return Object.keys(initial).some((k) => !eq(current[k], initial[k]));
});
```

**MEASURED — the marker exposes no way to move the baseline.** `markPristine`,
`commit`, `setInitial`, `setBaseline`, `rebase`, `markClean`: all `undefined`.

**MEASURED — the consequence is a defect, not a preference:**

```
marker.patch({ name: 'Ada' })          dirty() === true
await marker.submit(save)              save SUCCEEDS
                                       dirty() === true   <-- still
marker.reset()                         dirty() === false, name === ''
```

**After a successful save, the form is permanently dirty, and the only way to
clear it is to discard the saved work.** `form().dirty` does not mean "has
unsaved changes" -- the thing every form UI binds it to. It means "differs from
the values this tree was CONSTRUCTED with", and it cannot mean anything else,
BECAUSE the baseline is construction-time.

So construction time is not merely unnecessary for `dirty`. **It is the cause of
the defect.** The null also captures a baseline LATE -- after hydration, after a
server write, after any point the application decides is the zero -- which a
construction-time capture structurally cannot express.

```
DISPOSITION    F1 dirty -> DELETE from SignalTree.
               Function real, owner is the application, mechanism is
               `computed` over a published read and an app-held baseline.
               No SignalTree API, no marker, no construction-time capture.
```

One thing NOT concluded here: this says nothing yet about whether some OTHER
function needs construction time. F1 contributes one row to that question and
nothing more.

### AUDIT ROW — F2 `touched`

```
FUNCTION       Record that a user/UI INTERACTION occurred at a field, so errors
               show for fields the user has visited and hide for ones they
               have not.
OWNER          The interaction / session layer -- view or forms control.
               SignalTree has no inputs, no focus, no blur.
GREENFIELD     const touched = signal<Record<string, boolean>>({});
MECHANISM      const touch = (f) => touched.update(t => ({ ...t, [f]: true }));
SIGNALTREE?    NO
CONSTRUCTION?  NO
UNDO           Baseline truth-undo does NOT imply interaction-undo. Session
               rewind, if ever required, is a SEPARATE product capability.
```

Unlike F1 this is NOT derivable from values -- you cannot recompute "the user
focused this field". Derivability was never the question. The questions are who
writes it, and whether SignalTree's version buys anything.

**MEASURED — no SignalTree VALUE-WRITE path moves `touched`.** Stated at the
width of the experiment: the marker's principal write APIs were exercised, not
every conceivable internal path.

```
marker.patch({ name: 'Ada' })    touched -> { name: false, age: false }
marker.set({ age: 36 })          touched -> { name: false, age: false }
marker.$.name.set('Grace')       touched -> { name: false, age: false }
marker.touch('name')             touched -> { name: true,  age: false }
```

Inspection strengthens the measurement: `touch()` / `touchAll()` mutate
`touchedSignal` directly and are the only writers in the module. So the marker
holds a bag the application fills and reads, with no SignalTree semantics
attached to the contents. A plain `signal<Record<string, boolean>>({})` in the
component is the same object with one less indirection.

**MEASURED — the map shape is frozen at construction** from
`Object.keys(initial)`. The null is not shape-locked and can record
`'phones.0.value'` for a repeated row, a dynamically added control, or a field
the server sent late. Construction time is a CEILING here, not a capability.

#### The undo question — answered by OWNERSHIP, not by current failure

The marker's processor registration argues that `touched` must ride in the
snapshot:

> _"`touched` is restored for UNDO/REDO ... Undo must land the user exactly
> where they were, errors and all -- a cleaned-up undo is a lie about what they
> did."_

**THE ARCHITECTURAL ANSWER COMES FIRST, and it is independent of what the code
does today** (Rule 0g -- a current failure may not answer a product question):

```
1. user focuses Name       touched.name = true
2. user edits Name  A -> B
3. user clicks Undo        value B -> A
```

Should step 3 make it false that the user ever visited Name? **No.** They did
interact with it; reverting the value does not un-happen the focus. The same
holds for focus/blur/edit/undo-edit: undoing the edit does not mean the focus
never occurred.

```
value history        causal / state history      SignalTree
interaction history  UI / session history        the view
```

So baseline truth-undo SHOULD NOT rewind interaction state. A product that
genuinely wants SESSION REWIND -- "put the whole editing experience back
exactly as it was" -- is a separate compound capability needing explicit
session-history semantics (focus, scroll, cursor, selection, not just a boolean
map). It must not arrive by making `touched` part of ordinary SignalTree undo.

**SEPARATELY, and NOT as the architectural reason:** the current implementation
does not deliver the fidelity its comment claims. Measured on both paths:

```
setup   patch name='Ada'; touch('name')      -> { name: true,  age: false }
        patch name='Grace'; touch('age')     -> { name: true,  age: true  }

form({ history: history() }).undo()
        values   'Ada'                        CORRECT
        touched  { name: true, age: true }    NOT restored

.with(restoration()) -> tree.undo()
        values   { name: 'Ada', age: 0 }      CORRECT
        touched  { name: true, age: true }    NOT restored
```

Descriptively, why: `history()` records `project(ctx.read())` -- values only --
so the snapshot/hydrate pair that carries `touched` is not the path
`form({ history })` undo uses; it keeps its own buffer. And `touch()` /
`touchAll()` do not `announce`, `recordHistory` or `schedulePersist`, measured
directly: a `touch()` plus a `touchAll()` leave `tree.getRestorationHistory().length`
unchanged, so no entry ever exists at a distinct touched state. (Free
consequence nobody has claimed: a touch alone therefore never persists either.)

The `snapshot`/`hydrate` touched path is NOT dead -- it has exactly one
consumer, `applyState`, reached only from DEVTOOLS REPLAY
(`devtools-impl.ts:1444`), which passes mode `'restore'`. The comment is
accurate about a mechanism existing and over-claims about which operations use
it.

```
DISPOSITION    F2 touched -> DELETE from SignalTree.
               Function real and genuinely irreducible; owner is the VIEW.
               Undo ownership rejects the coupling on greenfield grounds, not
               because today's code fails.
```

#### 14.x disposition — decided from the 14.x contract, NOT from 15.0

Rule 0f exists to stop exactly the inference "15 deletes it, so skip the 14.x
defect". The earlier draft of this row made that error; corrected here. The
14.x question is asked on its own evidence:

```
A  comment wrong          patch the misleading documentation
B  behaviour wrong        repair if that is the promised 14.x contract
C  non-contractual        record why no customer-facing patch is required
```

**MEASURED, to choose between them:**

```
public docs claiming undo restores touched     NONE
  (README / llms.txt / llms-full.txt / skills: no such claim; the one
   llms-full hit is "password untouched", an unrelated sense of the word)
shipped type-level contract                     NONE
  FormSignal.touched documents only "Per-field touched state"
the claim's location                            an in-function source comment
emitted dist/packages/core/.../form.d.ts        0 occurrences
```

```
14.x DISPOSITION   C, with an A component.
                   No customer-facing patch: the claim is internal and
                   non-contractual, and no published surface promises
                   undo-restores-touched, so no consumer can be relying on it.
                   The misleading INTERNAL comment is still a real defect and
                   should be corrected in whichever 14.x line is live, because
                   the next maintainer will read it and believe it.
15.0 DISPOSITION   ARCHITECTURAL CUTOFF -- the marker goes, comment included.
```

B is rejected on evidence, not convenience: teaching 14.x history to record
interaction state would ADD the coupling this row just rejected on ownership
grounds.

### AUDIT ROWS — F3a `submitting` and F3b `submit()`

**The row was nearly mis-scoped.** `submit()` bundles three independent things:

```
1  operational lifecycle       submittingSignal.set(true / false)
2  validation orchestration    await validateAll()
3  application operation       await handler(valuesSignal())
```

Auditing only #1 would delete the flag and leave `tree.$.p.submit(handler)`
alive purely because it rode alongside it -- the exact pattern this audit keeps
finding in `form()`: **auditing the attached state while preserving the
convenience method that justified the state in the first place.** #2 is already
dead by validation ownership. #3 and the wrapper itself get their own row.

#### F3a `submitting`

Asked in the order that avoids the trap -- NOT "does `form.submit()` toggle a
flag", which answers nothing:

> **What semantic fact does `submitting` represent, WHO CAN KNOW it became true,
> and does that fact describe SignalTree TRUTH or the LIFECYCLE OF AN EXTERNAL
> OPERATION?**

```
FUNCTION       Report that an operation which SENDS state somewhere -- an HTTP
               POST, an IPC call, a save -- is currently in flight.
OWNER          Whoever RUNS the operation. It is the only party that can know it
               started and the only one that learns it finished.
GREENFIELD     const saving = signal(false);
MECHANISM      try { saving.set(true); await save(v); } finally { saving.set(false); }
SIGNALTREE?    NO. SignalTree cannot observe an HTTP request. The subject of the
               operation may be tree values, but the FACT is about the
               operation.
CONSTRUCTION?  NO -- because nothing about submission lifecycle needs graph
               compilation or construction-time specialization of the position.
               Any value can be submitted by an external operation after
               construction.
```

**The construction-time reason is stated carefully.** "An in-flight boolean is
not a property of a position because the same position is submitting sometimes
and not others" was the earlier draft, and it is WRONG as a test: a marker may
declare an intrinsic semantic type whose runtime state changes -- `status()` is
exactly that shape. Changing state does not fail the marker test. Not needing
construction-time specialization does.

**MEASURED — the flag does not mean what its name says.** Only
`marker.submit()` sets it. An application that saves the very same values
through its own service leaves `submitting()` `false` throughout. So it does not
report _"a submission of this state is running"_; it reports _"one particular
API on this marker was called"_ -- a fact about an API call, not about truth.

**MEASURED — one boolean cannot describe N concurrent operations:**

```
slow  = marker.submit(async () => { await blocked; return 'slow'; })
        submitting() === true
await marker.submit(async () => 'fast')
        submitting() === false   <-- while `slow` is STILL RUNNING
```

**CHARACTERIZATION, NOT JUSTIFICATION — `status()`.** Core's `status()`
distinguishes NotLoaded / Loading / Loaded / Error and carries the error, where
`submitting` is a boolean collapsing all four. That is _evidence that
`submitting` duplicates an already-recognized operational-state category_. **It
does not justify either abstraction.** `status()` is itself unaudited and does
not get a vote on what should exist; ownership of `submitting` is decided
independently, by who owns the external operation. The inference "legacy A
duplicates legacy B, therefore preserve B" is exactly what this audit rejects.

**PERSISTENCE EXCLUSION, stated at its true width.** The marker excludes
`submitting` from the snapshot, reasoning that restoring it would leave "a form
permanently submitting with nothing running to finish it". An earlier draft
generalized this to _"a field the marker will not persist because it does not
describe the state is a field that does not belong to the state"_ -- **too
broad. Non-durability does not prove non-statehood**; plenty of legitimate
runtime state should not survive persistence. The narrow claim: persistence
exclusion is CONSISTENT with `submitting` being transient operational state
whose lifetime is coupled to an operation. **Ownership removes it from
SignalTree, not persistence.**

One argument checked and NOT found: `submit()` does not lock the marker, so
`submitting` is not a write-gate.

```
DISPOSITION    F3a submitting -> DELETE from SignalTree.
```

#### F3b `submit()` — the orchestration wrapper

> Erase `form()`, validation, `submitting` and the current implementation. A
> SignalTree-backed value must be sent through an application-owned async
> operation. What becomes impossible with `await handler(node())`?

Six candidates, none granted in advance.

**MEASURED — no latent SignalTree-specific capability is present in the current
wrapper:**

```
CAUSAL ATTRIBUTION   a submit records nothing; getRestorationHistory() unchanged under
                     restoration
WRITE GATING         the tree stays writable mid-submit; patch() lands
ERROR OWNERSHIP      a throwing handler propagates exactly as the null does, and
                     no error is retained (`submitError`, `lastError`: undefined)
CANCELLATION         `abort`, `cancel`, `abortSubmit`: undefined
AUTO STATE CHANGE    nothing transitions on success or failure
```

**Those five rows are ABSENCE EVIDENCE, not the architectural falsifier.**
"The current implementation does not do X" must never become "SignalTree should
never do X" -- a distinction that will matter directly when realtime introduces
genuinely causal external operations. What closes the row is greenfield
OWNERSHIP:

```
save / POST / IPC operation      operation owner
errors, cancellation, retries    operation owner
write locking during save        application workflow policy
snapshot timing                  application workflow policy
result-driven tree mutation      an explicit subsequent SignalTree write
```

No orchestration responsibility remains for SignalTree to hold.

#### VALUE-CAPTURE POLICY — the sharpest row, corrected

An earlier draft said the marker "decides wrongly" about when the value is read.
**That is not established, and it let current behaviour answer a semantic
question.** Both policies are legitimate:

```
CALL-TIME CAPTURE          user presses Save at T1 -> submit snapshot T1
POST-VALIDATION CAPTURE    user presses Save -> async validation -> submit
                           currently-valid truth at T2
```

Neither is universally correct. A draft editor may want exactly what was on
screen; a system validating against a moving server may want the currently-valid
value. Others are equally legitimate: reread immediately before send, or refuse
if truth changed meanwhile.

**MEASURED — the current wrapper silently picks one.** `submit()` reads
`valuesSignal()` AFTER awaiting validation, so a write landing between the
button press and the handler is included:

```
marker.submit(h)                 // user presses Save
marker.patch({ name: 'RACED' })  // a write lands during the await
handler receives                 name === 'RACED'
```

The null leaves the choice with the operation owner, who can capture at call
time, after validation, immediately before send, or refuse on change:

```
const submitted = save(tree.$.p());   // this app chose call-time
tree.$.p({ name: 'RACED' });
(await submitted).name === 'Ada'
```

```
NO SIGNALTREE INVARIANT ESTABLISHES ONE CAPTURE INSTANT AS CANONICAL.
Submission snapshot timing is APPLICATION / OPERATION policy.
```

That is the argument -- **SignalTree has no authority to choose the capture
instant**, so choosing one is an unearned policy commitment, not a capability.
The race is retained below as 14.x characterization, where it is genuinely
useful.

```
DISPOSITION    F3b submit() -> DELETE from SignalTree.
               With validation gone, submit() reduces to `await handler(node())`
               plus a capture-instant choice SignalTree has no authority to make
               and a flag whose owner is the operation.
```

**F3 IS THEREFORE A COMPLETE DELETION**, not merely the removal of a boolean.

**F3 FROZEN:**

```
F3a submitting
  FUNCTION      operational in-flight state
  OWNER         external operation owner
  SIGNALTREE    NO
  CONSTRUCTION  NO
  DISPOSITION   DELETE

F3b submit()
  FUNCTION      orchestrate an application-owned operation over tree values
  OWNER         application / operation
  SIGNALTREE    NO
  CONSTRUCTION  NO
  DISPOSITION   DELETE

SIGNALTREE DOES NOT CHOOSE submission snapshot timing, concurrency policy,
cancellation, error retention, or write gating. Those are operation / workflow
semantics.
```

#### 14.x dispositions, decided on 14.x evidence (Rule 0f)

**F3a concurrency -> `14.x DEFECT`** (promoted from DEFECT CANDIDATE once the
contract question was answered):

```
Does the 14.x contract forbid or serialize overlapping submit() calls?
  public docs (README / llms.txt / llms-full.txt)   NO STATEMENT
  JSDoc on submit()                                  NO STATEMENT
  runtime guard                                      NONE -- the call is accepted
  documented meaning of the signal                   "Whether form is currently
                                                      submitting"
```

Nothing forbids them and the API accepts them, so a signal documented as
"currently submitting" reading `false` while an accepted submit promise is still
unresolved is a clean falsifier. **The FIX is a separate decision** and is NOT
made here -- reference counting, serializing, and rejecting-while-active have
different observable semantics and need their own semver call on the 14.x line.

**F3b value coherence -> `14.x DEFECT CANDIDATE`.** Reading values after the
validation await is defensible as "submit what is valid now", and no public text
states which instant is submitted. Recorded with the evidence; the 14.x line
must decide whether the contract implies call-time capture.

### AUDIT ROW — F4 `wizard`

**INTEGRITY NOTE.** Rule 0g wants the current mechanism hidden until last. It
was not, here: the wizard implementation was read earlier in the same session
while inventorying `form()`'s surface. That is declared rather than papered
over, and the row is therefore built on STRUCTURAL MEASUREMENTS that do not
depend on recall.

The null:

> **No concept called "wizard" exists. An application has state, and a UI
> containing several views. What required capability becomes impossible?**

**The bundle is split BEFORE measuring**, so "wizard" cannot smuggle five
separately-owned things through as one:

```
current step                 where am I
allowed transition / guard   may I move
step ordering                what follows what
step completion              is this step done
next / previous              convenience over the above
```

#### The decisive measurement — is the step TREE STATE at all?

```
after goTo(1):
  wizard.currentStep()        1
  JSON.stringify(tree())      {"p":{"values":{...},"touched":{...}}}
                              NO step, NO currentStep, NO 'step' substring
```

**The step index is invisible to the tree's own value.** It is a private signal
that happens to be reachable through a marker. Two more measurements confirm it
is not tree state in any operational sense:

```
restoration undo    values rewind 'Grace' -> 'Ada'; currentStep STAYS 1
two next() calls   tree.getRestorationHistory().length UNCHANGED
```

So navigation is not persisted, not undone, not serialized, and not recorded.
**A wizard step already behaves as session/routing state that merely lives
inside the tree object graph.** Nothing has to be argued to move it out; it is
already out, in every respect except where the variable is declared.

#### Per-concept ownership

```
CURRENT STEP        Session / routing state. In a real app this is usually the
                    URL -- a step you cannot deep-link to or reload into is a
                    known UX defect, and SignalTree has no routing authority.
                    OWNER: router / session.   SIGNALTREE: NO

STEP ORDERING       A static list the application declares. `['one','two']` is
                    domain data, not tree structure.
                    OWNER: application.        SIGNALTREE: NO

ALLOWED TRANSITION  Workflow policy: "may the user leave this step". Depends on
                    completion rules the application owns -- and, in the current
                    design, on validation, which SignalTree no longer has.
                    OWNER: application.        SIGNALTREE: NO

STEP COMPLETION     "Is this step done" is a domain predicate over values. It is
                    `computed` over a published read, exactly like F1's dirty.
                    OWNER: application.        SIGNALTREE: NO

NEXT / PREVIOUS     Convenience over an integer.
                    OWNER: whoever owns the integer.
```

**MEASURED — the guard does not guard.** `canNext()` is `true` on step 0 of a
freshly constructed wizard with nothing filled in:

```
currentStep() === 0    canNext() === true     nothing completed, nothing valid
goTo(2)                canNext() === false    isLastStep() === true
```

`canNext` answers _"is there a later step"_ -- step ARITHMETIC -- not _"may I go
there"_. A template binding `[disabled]="!wizard.canNext()"` therefore enables a
Next button that `next()` may refuse, which is the button-that-does-nothing
defect. Naming aside, this confirms the split above: **ordering and permission
are different concepts, and the current API conflates them.**

#### The null

The entire surface is one integer plus `computed`s over a static list:

```ts
const steps = ['one', 'two', 'three'] as const;
const step = signal(0);
const stepName = computed(() => steps[step()]);
const canPrev = computed(() => step() > 0);
const isLast = computed(() => step() === steps.length - 1);
const next = () => step.update((i) => Math.min(i + 1, steps.length - 1));
```

Measured working. No SignalTree involvement of any kind -- not even a published
read, because **the wizard never touches tree values.**

```
CONSTRUCTION?  NO. Nothing about a step index needs graph compilation or
               construction-time specialization of a position. The step list is
               data the application already has; declaring it at tree-build time
               buys nothing and costs deep-linkability.

DISPOSITION    F4 wizard -> DELETE from SignalTree, and do NOT recombine.
               Five concepts with at least three different owners were travelling
               as one word. Current step is session/routing, ordering and
               completion are application domain, transition permission is
               workflow policy. None is SignalTree's.
```

**14.x (Rule 0f).** `canNext` reporting arithmetic while reading as permission
is a `14.x DEFECT CANDIDATE` -- the JSDoc says "Can navigate forward", which a
consumer would reasonably read as permission, and `next()` can refuse when it is
`true`. Promotion requires checking whether any published example binds a
control to `canNext`; not decided here.

### AUDIT ROWS — F5 `reset`, F6 `clear`, F7 `patch`

Attacked as ORDINARY OPERATIONS before any "form" semantics are granted.

#### F7 `patch` — heaviest burden, taken first

SignalTree already has partial-merge branch writes, so the burden is not "is
`form.patch()` convenient":

> **What operation becomes impossible without a form-specific patch?**

```
FUNCTION       Write some fields of a composite value, leaving the rest.
OWNER          SignalTree -- writing state IS its job.
GREENFIELD     tree.$.p({ name: 'Grace' })
MECHANISM
SIGNALTREE?    YES, and it ALREADY SHIPS IT. The question is whether a SECOND,
               form-specific spelling adds anything.
CONSTRUCTION?  NO.
```

**MEASURED — nothing.**

```
marked.$.p.patch({ name: 'Grace' })    -> { name: 'Grace', age: 36 }
plain.$.p({ name: 'Grace' })           -> { name: 'Grace', age: 36 }
both record history under restoration
```

**And the plain branch write is MORE capable: it merges at EVERY DEPTH.**

```
plain.$.p({ a: { y: 99 } })   ->  { a: { x: 1, y: 99 }, b: 3 }
```

`patch` is a shallow spread over one level. So the form-specific spelling is not
even a convenience win where composite values are nested.

```
FUNCTION SURVIVES          partial state update
FORM-SPECIFIC ABSTRACTION  does not

DISPOSITION    F7 patch -> DELETE THE SURFACE. The required function is real and
               is ALREADY OWNED by ordinary SignalTree authoring; `patch()`
               collapses into it, contributing no distinct semantics while being
               strictly less capable.
```

#### F5 `reset`

```
FUNCTION       Return values to a baseline the user calls "unchanged".
OWNER          Whoever owns the BASELINE -- the application. Identical to F1.
GREENFIELD     tree.$.p(baseline())      // one ordinary write
SIGNALTREE?    NO -- the write is already published; the baseline is not
               SignalTree's to hold.
CONSTRUCTION?  NO.
```

`reset` and `dirty` are the SAME QUESTION seen from two sides -- _"does this
differ from the baseline"_ and _"put the baseline back"_ -- so `reset` inherits
F1's OWNERSHIP problem exactly:

> **SignalTree has no basis for deciding WHICH historical value is the baseline.**

At least five application meanings are legitimate, and nothing distinguishes
them from inside SignalTree:

```
reset = construction defaults        reset = last explicit checkpoint
reset = last loaded server state     reset = blank / new-record state
reset = last successful save
```

**MEASURED — the current implementation silently picks the first:**

```
patch({ name: 'Ada' });  await submit(save);   // the save SUCCEEDS
reset()                                        // user presses "Revert"
marker().name === ''                           // the BUILD-TIME value
```

An earlier draft called that a DEFECT and asserted Revert "should" return to the
saved values. **Neither is established.** Construction-baseline reset is a
coherent policy; it is simply one of five, chosen without authority. Calling it
wrong would repeat the F3b capture-instant error -- letting one application's
expectation stand in for a SignalTree invariant. It is only a 14.x defect if the
14.x contract promises a different baseline, and it does not: the JSDoc says
"Reset to initial values", which is exactly what it does.

The current `reset()` also clears `touched`, `asyncErrors` and the wizard step --
all now DELETE by F2, validation ownership and F4 respectively. Once those are
gone, `reset()` is one ordinary write of a value the application chose.

```
DISPOSITION    F5 reset -> DELETE THE SURFACE. Restoring an
               application-defined baseline is an ordinary write; the
               baseline is not SignalTree's to choose or to hold.
```

#### F6 `clear`

```
FUNCTION       Set fields to "empty".
OWNER          The DOMAIN. What "empty" means is a domain fact, not a type fact.
GREENFIELD     tree.$.p(EMPTY)   // an application-declared empty value
SIGNALTREE?    NO.
CONSTRUCTION?  NO.
```

**MEASURED — `clear()` infers domain policy from the TypeScript type:**

```
text: 'hello'  ->  ''
count: 7       ->  0
list: [1, 2]   ->  []
obj: { a: 1 }  ->  {}
nul: null      ->  null
bool: true     ->  true      <-- UNCHANGED
```

Two independent problems, both measured.

**1 — the number rule collapses "empty" with a VALID DOMAIN VALUE.** A
`rating: 5` clears to `0`. Zero is a legitimate answer, not the absence of one,
and after `clear()` nothing can distinguish "cleared" from "the user said 0".
Only the domain knows whether the empty rating is `0`, `null` or `undefined`.

**2 — the table is not even internally consistent.** `boolean` is left alone, so
a checkbox the user ticked stays ticked through a "clear". Whatever rule
produced `''` and `0` was not applied to `true`.

This is precisely the antipattern the MERGE row already condemned -- _"SignalTree
must never infer policy from type; seeing two numbers and deciding numbers get
summed is the domain owner's call"_ -- shipped and running.

```
DISPOSITION    F6 clear -> DELETE. Type-inferred domain policy SignalTree has no
               authority to choose, and the choice is inconsistent besides.
```

### DEFECT FOUND WHILE MEASURING F7 — cross-tree undo contamination

Not a `form()` question, and it outlives every deletion above. Narrowed by
one-variable experiment:

```
form-marker patch + a second WRITTEN restoration tree   THROWS
    Error: Unsupported scoped undo effect at structural-drift
    time-travel.ts:2175 -> applyTurnEffectsThroughRealizationPort

form-marker patch + a second IDLE restoration tree      CLEAN
form-marker patch, its tree ALONE                      CLEAN
two PLAIN restoration trees, both written               CLEAN
```

**Both conditions are required**: a `form()` marker write AND a concurrent write
to an unrelated `restoration()` tree. Two plain trees do not contaminate each
other, so this is not generic time-travel scoping -- the marker's write is what
makes the difference.

**WHAT IS ESTABLISHED, and no more:**

> **An unrelated tree's activity changes whether undo of a valid form-marker
> write succeeds.**

**ROOT CAUSE — UNPROVEN.** An earlier draft asserted "the contaminating
mechanism is in time-travel / the realization port, not in the marker". That is
not measured. The stack frame says WHERE THE REFUSAL IS RAISED, not where the
contamination originated -- and assigning ownership to the place an error throws
is exactly the failure mode this audit has been policing. The experiment
requires a form-marker write, so all of these remain live:

```
form emits incorrectly scoped effects
restoration stores global / shared state
the realization port mixes identities
marker hydration uses process-global metadata
an interaction of two otherwise-correct mechanisms
```

### CORRECTION — the "both conditions are required" narrowing is WRONG

Evidence: `undo-nonscalar-leaf.spec.ts`, 7 rows, plus the same file run with
inverted expectations on `main`.

The record above concludes:

> **Both conditions are required**: a `form()` marker write AND a concurrent
> write to an unrelated `restoration()` tree. Two plain trees do not contaminate
> each other, so this is not generic time-travel scoping.

**Neither condition is required.** The same guard refuses undo with **one tree,
no marker, and no second tree at all**. The only requirement is that a leaf's
value is not scalar:

```text
ONE plain tree, no marker, .with(restoration())

  n: 0            number   undo OK
  s: ''           string   undo OK
  rows: []        array    THROWS  Unsupported scoped undo effect at rows
  when: Date      Date     THROWS  ... at when
  lookup: Map     Map      THROWS  ... at lookup
  seen: Set       Set      THROWS  ... at seen
```

The path is `applyTurnEffects` (**:1673**), not
`applyTurnEffectsThroughRealizationPort` (:2175). The gate is
`isSupportedEffect`, :1680-1694:

```ts
case 'set':
  return (isScalarValue(before) && isScalarValue(after))
      || (subject === undefined && ownerPath !== path);

// isScalarValue: null | undefined | string | number | boolean | bigint
```

An array is not scalar and a top-level leaf is its own owner, so both clauses
fail. The earlier narrowing tested "two plain trees" — presumably with scalar
leaves — and so never varied the one variable that actually matters.

### SEVERITY — a scalar sibling is COLLATERAL

`applyTurnEffects` validates the **whole effect list before applying any of it**,
so one non-scalar leaf in a turn refuses the entire undo:

```text
tree = { n: 0, rows: [] }
  n.set(1)              tick
  n.set(2); rows.set([9])  tick
  undo()  ->  THROWS, and n is STRANDED AT 2
```

So this is not "arrays cannot be undone." It is **one array write anywhere in a
turn breaks undo for everything in that turn.**

### IT IS A REGRESSION, not a never-worked

The identical seven scenarios pass on `main` with inverted expectations — array
undoes to `[1]`, the Date to 2021, the Map to `a:1`, the Set to `['a']`, and the
stranded scalar recovers to `1`.

```text
INTRODUCED BY   06785300  2026-08-11 22:29
                "feat(history): cut over public undo to frontier authority"
                EMPTY COMMIT BODY. Same third-bucket commit as SubjectId.
```

### Relationship to the form-marker case above

The form-marker + second-tree scenario may still be a distinct defect — it throws
from a different path (:2175). But it is no longer evidence for
_"the marker's write is what makes the difference"_, because the guard fires with
no marker present. The cheaper explanation now available: both are the same
incomplete cutover, and the form-marker experiment simply produced a non-scalar
effect by another route.

**ROOT CAUSE — still not asserted.** What is established is the trigger, not the
intent. `isSupportedEffect` throwing rather than falling back reads like a
deliberate guard on an unfinished implementation — fail loudly rather than
corrupt — which is defensible engineering that shipped its incompleteness into
the branch. Whether non-scalar support was deferred knowingly is unrecorded,
because the commit body is empty.

### Consequence for the derivation

```text
BLOCKS   the conforming-collection prototype's CANONICALITY row, which is the
         last property standing between the M-cluster and physical subtraction.
CONTAMINATES  Derivation E's canonicality column. On this branch entityMap passes
         because it emits SUBJECT-BEARING effects, which isSupportedEffect
         admits, while an ordinary array does not. That column was measuring the
         undo engine's admission rule, not the shapes.
GATE     must be fixed, or consciously accepted with its blast radius recorded,
         before the M cut.
```

```
14.x   DEFECT. `tree.undo()` throws on a tree whose own writes were valid,
       because of activity in a DIFFERENT tree. Nothing in the public contract
       says undo is process-global. Root cause and fix both undecided.
15.0   The specific form-triggered REPRODUCER may well disappear when `form()`
       is deleted. **Do NOT claim the underlying scoping defect is resolved by
       that deletion** until MUT determines why foreign-tree activity affected
       the first tree. What survives the deletion regardless is the warning:
       tree-local causal/undo machinery has demonstrated CROSS-TREE SENSITIVITY
       under at least one supported semantic write path.
MUT-3  DIRECT COUNTEREXAMPLE motivating tree-lineage isolation -- "how is
       observation bound to ONE tree lineage rather than process-global state?"
       Here is a measured case where it is not.
```

### AUDIT ROW — F8, THE OMITTED SURFACES

The seven were not the whole marker. `$`, `set`/`data` and the persistence trio
were never in the list and **must not be deleted by omission** -- a surface that
dies unexamined is a surface that can be resurrected unexamined.

#### F8a `$` — structural navigation

> Does a form position expose any navigation an ordinary compiled
> `NodeAccessor` would not already provide?

**MEASURED — no.** Field read/write through `marker.$.name` matches
`plain.$.p.name` exactly, and the plain branch additionally navigates to
arbitrary depth (`plain.$.p.addr.city`). `$` is INHERITED TREE MACHINERY
presented as form functionality.

It is also strictly WORSE ergonomically, and one measurement shows why that is
not merely taste:

```
plain tree     tree.$.p.name()          the field
form marker    tree.$.p.$.name()        the field
               tree.$.p.name            'formSignalFn'   <-- a STRING
               typeof tree.$.p.length   'number'
```

**DEFECT — the marker is a callable, so field names collide with
`Function.prototype`.** `name` is among the most ordinary field names there is;
on a form marker `tree.$.p.name` silently yields the JavaScript function name,
not an accessor and not a value from this form. `length`, and by the same route
`caller`, `arguments` and `constructor`, are in the same class. A plain branch
has no such hazard.

```
14.x   DEFECT CANDIDATE. Not a crash -- a silent wrong value on a plausible
       field name. Whether it is contractual depends on whether the extra `.$.`
       hop is documented as REQUIRED; not decided here.
DISPOSITION  F8a $ -> DELETE WITH THE MARKER. Nothing to preserve: the
             capability is the tree's, and the marker's version degrades it.
```

#### F8b `set` / `data`

**MEASURED — `set` and `patch` have identical behaviour**, and inspection shows
identical bodies (`{ ...curr, ...values }` + announce + persist + record). Two
names, one function.

**DEFECT — `set` is documented "Set all values at once" and MERGES:**

```
initial { name: 'Ada', age: 36 }
set({ name: 'Grace' })
result  { name: 'Grace', age: 36 }      <-- `age` survived
```

A caller trusting the JSDoc would expect the omitted field to be reset or the
call to be rejected; instead it is a partial merge under a total-write name. It
is also typed `Partial<T>`, which contradicts the prose rather than the code --
so the TYPE tells the truth and the DOC does not.

`data()` is an alias for calling the marker, and is documented as one. Its
stated rationale is that AI agents trained on `FormGroup` / Formik /
react-hook-form reach for `.data()`. **That is a familiarity argument, not a
capability argument** -- exactly the class this audit rejects. An alias does not
survive because it makes an API look familiar.

```
14.x   `set` prose/behaviour mismatch -> DEFECT CANDIDATE. The fix is almost
       certainly documentation (the type already says Partial), but that is the
       14.x line's call.
DISPOSITION  F8b set / data -> DELETE. `set` is `patch` is the branch write;
             `data` is an alias for a call.
```

#### F8c `persistNow` / `reload` / `clearStorage`

Their burden is high before measurement, because GATE A already froze the owner:

> **PERSISTENCE CONSEQUENCE -- a governed mechanism.**

A form marker must not regain survival by carrying manual storage controls whose
semantic owner is frozen elsewhere.

**MEASURED — all three exist, and all three are INERT without a
construction-time `persist` key.** Called on a marker with no `persist`
configured, `persistNow()`, `reload()` and `clearStorage()` all silently do
nothing; `reload()` in particular does not report that there is nothing to
reload from.

```
FUNCTION       force a save, force a reload, drop the stored copy
OWNER          the persistence consequence (GATE A, already frozen), and
               `stored()` is core's existing durability marker, which needs no
               form position
SIGNALTREE?    the CONSEQUENCE is; these three imperative escapes are not
CONSTRUCTION?  the trio is inert without a construction-time key, so the
               construction coupling is real -- but it is persistence's
               construction coupling, borrowed. It establishes nothing about
               FORM-ness.
```

That last row matters for the final question. The trio does depend on something
declared at construction -- but what is declared is a STORAGE KEY, which is
persistence's property, not evidence that a position is intrinsically "a form".

```
DISPOSITION  F8c -> DELETE from the form marker. If imperative
             flush/reload/clear controls are required at all, they are the
             persistence consequence's surface to justify, on its own terms.
14.x   silent no-op `reload()` with no storage configured -> NOTE only, not a
       defect claim: no contract says it should report.
```

## `form()` — WHOLESALE DELETION, and the audit STOPS HERE

**The legacy audit is halted, and not because every method was individually
prosecuted.** Continuing to try each remaining surface would violate the spirit
of Rule 0g: once "form" is shown not to be an intrinsic SignalTree concept, the
old `FormSignal` surface must stop being the UNIT OF ANALYSIS. Whittling a
legacy abstraction down is the wrong direction; deleting it and greenfielding
forward is the right one.

**What the rows did establish is that the abstraction's cohesion is ARTIFICIAL.**
Its pieces have already scattered to at least seven different owners:

```
dirty          baseline comparison            application policy
touched        interaction state              UI / session
submitting     external operation lifecycle   operation owner
submit()       operation orchestration        application
validation     judging a value                validator ecosystem
wizard         step position + workflow       routing / session / app policy
reset          restore a chosen baseline      application + ordinary write
clear          what "empty" means             domain + ordinary write
patch          partial state update           ORDINARY SIGNALTREE AUTHORING
persistence    durability                     the governed consequence (GATE A)
```

Once a supposed abstraction decomposes into that many owners, asking whether its
remaining helper aliases survive is backwards. **Nothing left could establish the
only claim that would save the marker:**

> _this position INTRINSICALLY IS A FORM and must therefore be COMPILED
> differently._

The single construction-time coupling found anywhere in the audit (F8c) is a
STORAGE KEY -- persistence's property, borrowed. It is not form-ness.

### FROZEN

```
FORM POSITION ONTOLOGY     NONE
form() marker              DELETE
FormMarker                 DELETE
FormSignal                 DELETE as a semantic type
form processor             DELETE
form-specific state model  DELETE
```

Subject to exactly one reopening condition: **a deterministic counterexample
showing some required capability cannot exist without construction-time form
semantics.** Not "the API is nice". Not "users like `.reset()`". Not "Angular
forms need integration". A genuine construction requirement. None was found.

### The legacy surface is now a CHECKLIST, not an agenda

From here the old API gets **zero weight** -- names, grouping, methods, marker
representation, lifecycle and implementation all count for nothing. It survives
only as a capability-discovery list, answering one question: _did it contain a
useful user capability we have not considered?_

```
CAPABILITY                 STATUS
field navigation           already provided by the kernel
whole-value read/write     already provided by the kernel
partial write              already provided by the kernel (deeper, too)
baseline comparison        WORTH GREENFIELDING -- as a checkpoint/baseline
                           concept, NOT as form state
interaction tracking       owned elsewhere (UI / session)
validation                 owned elsewhere (validator ecosystem) -- CLOSED
submission                 owned elsewhere (operation owner) -- CLOSED
workflow navigation        WORTH GREENFIELDING -- as workflow/navigation,
                           NOT as "form state"
storage                    owned elsewhere (persistence consequence, GATE A)
history                    already core's (`history()`, `trackHistory()`)
clear / reset              collapses into baseline + ordinary write
```

**The anchoring trap this avoids.** "What should replace `persistNow()`?" is the
wrong question; `persistNow()` does not get to frame it. The right question is
"given 15.0's persistence architecture, does a user need an imperative
durability control at all?" -- which may answer no.

### The greenfield DX pass — DEFERRED, and hostile by default

Deleting `form()` does not mean deleting good UX, and the freedom to invent
pleasant first-party APIs is explicitly preserved. But the DEFAULT is:

```
DO NOT ADD A SIGNALTREE FEATURE.
```

A capability survives only if first-party support gives SUBSTANTIAL VALUE BEYOND
ORDINARY COMPOSITION. `tree.$.profile({ name: 'Jon' })` already has excellent
DX; `profile.patch({ name: 'Jon' })` adds nothing but a name form libraries
happen to use. `const saving = signal(false)` is already excellent Angular DX;
wrapping it as `tree.$.profile.submitting()` improves nothing unless SignalTree
owns semantics Angular does not. **That is the ANG-V0 lesson applied to DX
rather than to architecture.**

**SEQUENCING: the greenfield pass runs AFTER the core / causal / API owners are
frozen** -- MUT in particular. Some candidate capabilities may collapse further
once those primitives exist, and designing on top of unfrozen primitives would
just re-run this audit later.

### EVIDENCE DISPOSITION — one judgment call, surfaced

`form-function-audit.spec.ts` is deleted under the ANG-V0-F protocol: its
dispositions are frozen, and a suite pinning a doomed mechanism's behaviour
would give it test-backed legitimacy.

**But one of its tests is not about `form()` at all.** The cross-tree
contamination reproducer documents a live defect in TIME TRAVEL, a surviving
mechanism whose root cause is UNPROVEN. Deleting it silently would lose the
reproducer. It also cannot simply be kept, because it REQUIRES `form()` to
trigger -- a permanent test would block the deletion it is filed alongside.

Resolved by recording it here verbatim, as evidence rather than as a live test:

```ts
// THROWS: Unsupported scoped undo effect at structural-drift
const marked = signalTree({
  p: form<Profile>({ initial: { name: 'Ada', age: 36 } }),
}).with(restoration());
const other = signalTree({ q: { n: 1 } }).with(restoration());
await tick();

marked.$.p.patch({ name: 'Grace' });
other.$.q({ n: 2 }); // an UNRELATED tree
await tick();

marked.undo(); // throws
```

```
CONTROLS (all clean): marker tree alone; second tree idle; two PLAIN trees
                      both written
```

**MUT OBLIGATION.** When `form()` is deleted this reproducer becomes
unrunnable. That is NOT evidence the defect is fixed. MUT must determine why
foreign-tree activity affected the first tree, and must look for a second
trigger path that does not involve `form()`. If none is found, the finding is
recorded as _closed by removal of the only known trigger_ -- explicitly not as
_resolved_.

## RULE 0j — SUBTRACTION-ONLY, and PHYSICAL deletion follows ARCHITECTURAL deletion

### 0j-1 — a rejected feature does not require a replacement design

> **During the subtraction audit, a rejected feature does not require a
> replacement design. Preserve only the USER CAPABILITY as a future
> consideration where it looks genuinely useful. Architecture first;
> convenience reconstruction later.**

So the question is never _"what should replace `persistNow()`?"_ It is _"does
`persistNow()` belong on this abstraction as written?"_ If no: DELETE, and the
replacement is DEFERRED — possibly to nothing.

**DEFERRED CAPABILITY CANDIDATES** — deliberately weak. Not "future SignalTree
features"; these have NOT earned first-party ownership, and the old
implementation gets **no vote** when the pass runs.

```
checkpoint / baseline UX
interaction / touched helpers
workflow / step navigation
operation lifecycle helpers
imperative durability controls
framework integration conveniences
```

The list means only: _things users may find useful enough to reconsider after
stabilization._ Default remains **DO NOT ADD A SIGNALTREE FEATURE.**

**AMENDED — CANDIDATE is not the only bucket.** The list above was too weak: it
placed capabilities that ALREADY SURVIVED hostile audit next to ones that never
earned ownership. Two buckets, not one:

```
DEFERRED CANDIDATE   a useful-looking capability that never earned first-party
                     or product ownership. May come back. May not.

DEFERRED OBLIGATION  a function that ALREADY SURVIVED hostile audit, whose
                     CURRENT FORM was rejected. Replacement design deferred
                     until the architecture stabilizes. It does NOT revert to
                     "maybe useful" merely because its implementation happened
                     to depend on a deleted mechanism.
```

```
CANDIDATES                        OBLIGATIONS
checkpoint / baseline UX          Reactive Forms interoperability
interaction / touched helpers       (the FUNCTION survived the formBridge
workflow / step navigation           subtraction test; only the marker-coupled
operation lifecycle helpers          enhancer dies)
imperative durability controls    Angular Signal Forms interoperability
                                    (inside the frozen Angular product boundary)
```

So FORM-DEL means:

```
formBridge() current enhancer / API     DELETE
signalForm() current marker bridge      DELETE

Reactive Forms interoperability         SURVIVING FUNCTION, realization deferred
Signal Forms interoperability           SURVIVING PRODUCT FUNCTION, deferred
```

No replacement design now -- but these are OBLIGATIONS on the later greenfield
pass, not candidates that may quietly evaporate.

### 0j-2 — the corpse does not participate in the next experiment

**ARCHITECTURAL deletion and PHYSICAL deletion are different events, and the gap
between them is a contamination window:**

```
endpoint frozen
      v
dead mechanism REMAINS AT HEAD
      v
next architecture audit observes it
      v
dead mechanism influences the derived contract
```

> **Once a death certificate is signed, executing it is the NEXT EXECUTION
> BOUNDARY — not deferrable work.** Deriving a new contract while declared-dead
> machinery is still live measures the new architecture against something
> already ruled non-architectural.

**AMENDED — the rule travels at the width of its justification.** "Once a death
certificate is signed, executing it is the NEXT EXECUTION BOUNDARY" is too
universal; it would forbid batching frozen deletions or landing an unrelated
documentation fix. The evidence-hygiene rule actually justified is:

> **A frozen architectural deletion must be PHYSICALLY EXECUTED before any
> subsequent derivation whose EVIDENCE SURFACE can include, or be affected by,
> that dead mechanism.**

For the current case the outcome is unchanged:

```
form() frozen DELETE
MUT's evidence surface includes mutation machinery that form() participates in
-> FORM-DEL MUST PRECEDE MUT
```

**This is not cleanup. It is evidence hygiene**, and it directly improves the
next two derivations:

```
WITH form() LIVE     MUT can drift into "how should mutation participation
                     support this weird form write?" — a question about a
                     mechanism with no future standing.
AFTER DELETION       "For the SURVIVING mutation universe, what constitutes
                     participation in one tree/lineage, and can activity
                     belonging to ANOTHER tree alter it?"
```

Git preserves retired experiments; HEAD does not need to. The cross-tree
reproducer is recorded verbatim in this ledger and remains executable at the
audit-boundary commit, which is sufficient — keeping dead production code alive
to host a test is the wrong trade.

### CORRECTED QUEUE

```
1  EXECUTE the frozen deletions
     @signaltree/schema                                DONE (5bd821d3)
     form() / FormMarker / FormSignal / processor       NEXT
2  PROVE the resulting package / type / build surface clean
3  MUT — derive the mutation-participation contract against the SURVIVING
     architecture only
4  Causal owner convergence, including the common-substrate falsifier
5  Remaining survival / package / API audits
6  Stabilization
7  SEPARATE greenfield UX pass, starting from NULL, using the old APIs only as
     a historical capability inventory
```

### BLAST-RADIUS MEASUREMENT for step 1 (taken before executing)

```
ng-forms core/ng-forms.ts        0 marker refs   createFormTree takes plain values
ng-forms wizard/wizard.ts        0 marker refs
ng-forms history/history.ts      0 marker refs
ng-forms enhancer/form-bridge    19 refs         DIES
ng-forms signals/marker-bridge    5 refs         DIES
```

**What dies is `formBridge()` and `signalForm()`** (whose only remaining
overload is the marker one, the schema overload having gone with SCHEMA-DEL).

**AMENDED — dependency independence is not survival proof.** "`@signaltree/ng-forms`
SURVIVES the deletion" claims more than the measurement supports, and would let
"nothing forces it to die" become "it lives", which is the inference Rule 0g
forbids. What was measured:

> **FORM-DEL does not force deletion of `@signaltree/ng-forms`; a
> marker-independent remainder exists. The package's own architectural survival
> remains UNPROVEN pending its survival audit.**

**`createFormTree()` — REMOVE THE DEAD POINTER, DO NOT RE-POINT.** Its runtime
deprecation currently steers users to the deleted API. Under subtraction-only,
re-pointing would endorse another endpoint before that endpoint is audited.

```
REMOVE       guidance naming form() / formBridge() as the migration target
DO NOT       re-point to another API
DO NOT       declare createFormTree the survivor
DO NOT       un-deprecate it
STATUS       createFormTree deprecation AND survival -> UNPROVEN, its own audit
```

A bare deprecation notice may stand temporarily. What cannot stand is guidance
toward a deleted API.

**CONSEQUENCE TO SURFACE, not to silently resolve:** `createFormTree()` is
currently DEPRECATED IN FAVOUR OF the thing being deleted — its warning tells
users to migrate to the marker plus `formBridge()`. Deleting `form()` therefore
INVERTS a live deprecation. The notice must be removed or re-pointed as part of
the execution; whether `createFormTree()` is itself the right survivor is a
SEPARATE audit and is not decided by this deletion.

## FORM-DEL — EXECUTED (`b57ba293`), with the DOC SURFACE still open

```
58 files changed, 46 insertions, 10 499 deletions
```

### Deleted

```
core     markers/form.ts, form.contract.ts, form.spec.ts, form-shapes.spec.ts
         the factory, FormMarker, FormSignal, FormConfig, FormFields, FormWizard
         validators, withKind, createFormSignal, FORM_MARKER, isFormMarker
         history()   — its ONLY consumer was the marker's `history` option
         FormHistoryApi KEPT: trackHistory() still uses that shape
ng-forms enhancer/**  formBridge()
         signals/**   signalForm(), applySignalTreeSchemas, the ./signals export
demo     form-marker-demo, signal-forms-demo (page + fundamentals example),
         their routes, and the marker zoo's form article
```

### Retained mechanically — NOT audited survivors

```
trackHistory()    takes a plain WritableSignal; never referenced the marker
createFormTree()  zero marker refs
wizard adapter    zero marker refs
history adapter   zero marker refs
```

`createFormTree()`'s deprecation is **DE-POINTED, NOT RE-POINTED** — it now says
its migration target was removed and no replacement has been chosen. Reactive
Forms and Signal Forms interoperability stay DEFERRED OBLIGATIONS.

**CORRECTED — "not forced to die" is not "survived".** The line above read
_"Survivals were measured, not assumed"_, which is the SAME inference just
removed for `@signaltree/ng-forms` one section earlier. Zero marker references
establish INDEPENDENCE, not necessity:

```
PROVED        trackHistory() does not depend on the deleted marker
              -> FORM-DEL does not force its deletion
NOT PROVED    trackHistory() is something greenfield SignalTree 15 should ship
```

```
trackHistory()        RETAINED MECHANICALLY; survival UNPROVEN
createFormTree()      RETAINED MECHANICALLY; survival UNPROVEN
ng-forms wizard       RETAINED MECHANICALLY; survival UNPROVEN
ng-forms history      RETAINED MECHANICALLY; survival UNPROVEN
```

**Do NOT audit them now** — subtraction-only says stop calling them survivors,
not go prosecute them. Each keeps its own hostile audit, unfrozen.

Reactive Forms and Signal Forms INTEROPERABILITY are different, and the
distinction is exact: those FUNCTIONS survived prior architectural decisions, so
they are DEFERRED OBLIGATIONS. **Their particular retained implementations do
not inherit that status** — an obligation attaches to the function, never to the
code that happened to provide it.

### COMMIT-BOUNDARY BLEMISH in `b57ba293` — recorded, NOT rewritten

The `SignalTreeRollbackError.cause` repair is UNRELATED PRODUCTION WORK folded
into a 10 499-line deletion commit because it blocked the green gate.

```
blocked verification -> fix needed before the gate      TRUE
                     -> fix belongs in THIS commit      DOES NOT FOLLOW
```

History is not rewritten. It is recorded so a future bisect does not attribute
every semantic change in `b57ba293` to marker removal:

```
b57ba293 CONTAINS one unrelated gate repair: SignalTreeRollbackError no longer
         declares `cause` as a field; it is assigned through a cast.
14.x     LIB-TARGET DISAGREEMENT remains INDEPENDENTLY OPEN — the demo's
         compiler options and core's rollup build disagree about whether
         `Error.cause` exists at their lib targets. The cast satisfies both;
         it does not resolve the disagreement.
```

### TEST-STRIPPING CAVEAT — do not over-credit "mechanical and bounded"

Form-dependent `it()` blocks were removed from nine mixed specs by an automated
stripper. It produced a green suite, but it **malformed `marker-roundtrip.spec.ts`
once and had to be repaired by hand.** The parser and the suite caught it, so
FORM-DEL stands — but a green suite after automated surgery is NOT proof that
every removed assertion was semantically marker-only.

```
OBLIGATION (deferred, cheap, not an architecture cycle)
  A deletion-diff sanity pass over `b57ba293`: for every test block removed from
  a MIXED surviving spec, did that assertion protect ONLY the deleted surface, or
  did it also protect a surviving general invariant? Where the latter, restore
  the invariant using a surviving trigger.
```

### Two unrelated defects fixed because they blocked the gate

The demo build had been red all session on `TS4114` at `types.ts` —
`SignalTreeRollbackError` redeclaring `cause`. Adding `override` fixed the demo
and instantly broke core's rollup build with `TS4113`, _"not declared in the base
class"_. **The two configs disagree about whether `Error.cause` exists at their
lib targets.** Resolved by not declaring the field and assigning through a cast,
which satisfies both; the disagreement is recorded in a comment at the site.

```
14.x   LIB-TARGET DISAGREEMENT between the demo's compiler options and core's
       rollup build. Recorded, not chased — a real config defect that outlives
       FORM-DEL and deserves its own look.
```

### VERIFICATION

```
core 1651 · ng-forms 40 · demo 158 in 22 suites · guardrails, realtime, events, shared
run-many across all seven projects            exit 0  (including core)
lint, every project                           exit 0
every package build, fresh artifacts          exit 0
demo build                                    exit 0  <- first time this session
```

### OPEN — the doc surface, roughly 100 references

**This is a SHIPPING-CORRECTNESS obligation, not an evidence-hygiene one.** The
amended Rule 0j-2 requires physical deletion before a derivation whose EVIDENCE
SURFACE is affected; MUT derives against CODE, not prose. So this blocks
**Phase 3/4, NOT MUT.**

```
apps/demo/public/llms-full.txt              26   ships in the core tarball
docs/skills/using-signaltree/ng-forms/      16   ships in the package
docs/skills/using-signaltree/SKILL.md        9   ships in the package
apps/demo/public/llms.txt                    7   ships in the core tarball
packages/ng-forms/README.md                 37   whole sections are marker-built
packages/core/README.md                      4
docs/skills/.../reference/core.md            2
docs/ai/agent-templates.md                   2
docs/overview.md                             1
```

plus live prose in `docs/errors/README.md`,
`docs/guides/custom-markers-enhancers.md`,
`docs/guides/time-travel-in-production.md`, `docs/architecture/*.md`,
`docs/compare/ngrx-signalstore.md`, `docs/myths-and-misconceptions.md`, and
several demo component templates.

**Highest harm first:** `llms.txt` and `llms-full.txt` ship INSIDE the core
tarball and exist to steer AI agents. Every reference there currently teaches an
agent to emit APIs that no longer exist. The skills ship inside the packages and
have the same problem.

**NOT rewritten (historical records):** `docs/audits/**`, `docs/research/**`,
`docs/rfcs/**`, the CHANGELOGs, and the past-version migration guides
(`migration-v11-v12`, `v12-v13`, `v13.2`, `v14-v14.1`). They record what was true
when written. `docs/guides/migration-v14-v15.md` is the LIVE one and must gain
the marker deletion.

### MUT EVIDENCE BOUNDARY — frozen BEFORE MUT begins

The doc surface was classified as shipping-correctness on the grounds that "MUT
derives against code, not prose". **That is defensible only if MUT's evidence
boundary actually excludes those files** — otherwise a repo-wide search for
`mutation`, `write`, `history` or `participation` surfaces stale architecture
prose exactly as readily as production source, and roughly a hundred live
references currently teach deleted APIs. The two `llms` files exist SPECIFICALLY
to steer agents, which makes the risk concrete rather than theoretical.

So the boundary is frozen rather than assumed:

```
MUT PRIMARY EVIDENCE
  packages/** production source
  surviving tests and type tests
  frozen RELEASE-1.0 decisions
  measured runtime experiments

NOT MUT ARCHITECTURAL EVIDENCE
  llms.txt, llms-full.txt
  package READMEs
  shipped skills
  general guides
  demo explanatory prose
  historical audits, RFCs, migration guides

EXCEPTION
  prose may be consulted LAST, and only to DISCOVER a claimed capability or a
  14.x contract. Never to derive the 15.0 endpoint.
```

**Without this exclusion, Rule 0j would in fact require cleaning the live prose
first.** With it, the doc surface genuinely waits for the shipping gate.

## MUT — the mutation-participation derivation

### FRAMING CORRECTION, before any experiment

My opening question was _"what makes a write a semantic participant in exactly
one tree/lineage?"_ **That contains part of the answer.** "Exactly one
tree/lineage" is a CANDIDATE INVARIANT, not part of the definition of
participation — and collapsing `tree` with `lineage` behind a slash assumes they
are the same scope before anything has established it.

### MUT-0 — THE NULL

> **Assume SignalTree exposes NO generic mutation-observation protocol. A change
> to physical truth occurs. What information MUST exist for SignalTree ITSELF to
> remain correct?**

For every fact proposed:

```
who requires it?          when must it exist?      who owns it?
is it per-tree?           is it causal?
is it SEMANTIC, or merely REALIZATION / PUBLICATION?
```

### MUT-1 — the first decisive question

> **What distinguishes a physical change that merely REALIZES or RESTORES truth
> from a SEMANTIC MUTATION that must participate in SignalTree authority?**

This deliberately gets UNDERNEATH `interceptLeafSignals`, `PathNotifier`, change
reporting, time travel and the causal runtime, rather than starting from any of
them.

**The three are not synonyms**, and the audit must keep them apart:

```
LANDED WRITE            physical truth changed
SEMANTIC MUTATION       it participates in SignalTree's mutation model
CAUSALLY AUTHORED       a turn authored it
```

Restore, rollback and realization already change truth without obviously
creating authorship; persistence observes committed truth without becoming
mutation authority. A chain of `write -> participant -> lineage -> causal turn`
would rebuild the universal mutation ontology this audit exists to challenge.

### DIMENSIONS, derived independently — not one object

```
LANDED               did physical truth actually change?
SEMANTIC MUTATION    does the landed change participate in the mutation model?
SCOPE                which tree or authority owns it?
CAUSAL ATTRIBUTION   was it authored by a turn, and which?
IDENTITY             which PositionId, SubjectId, physical location participated?
PUBLICATION          what Angular-visible realization must update?
CONSEQUENCE          which post-commit consequences may observe it?
```

### THREE HYPOTHESES — `tree` and `lineage` held apart

```
H1  every semantic mutation has exactly ONE OWNING TREE
      near-definitional for signalTree(), but still stated as a hypothesis

H2  every AUTHORED mutation belongs to exactly ONE CAUSAL LINEAGE
      depends on what causal authority turns out to be

H3  tree ownership and causal-lineage ownership are THE SAME SCOPE
      NOT EARNED. Nothing yet establishes it.
```

A tree may plausibly contain confirmed causal history, speculative causal
history, non-authored realization, restore and rollback effects, and post-commit
consequences — without all of those being one simple lineage. **Do not invent a
`TreeLineageId` or equivalent before necessity appears.**

### MUT-3 SEQUENCING — the old defect is a FALSIFIER, not the starting model

```
CORRECT                              WRONG
1 derive the scope contract from     old bug involved two trees
  surviving code                     -> hunt global state
2 construct minimal two-tree         -> derive the scope model around
  falsifiers against that contract      whatever caused it
3 ONLY THEN hunt a second analogue
  of the deleted reproducer
```

Otherwise MUT degenerates into a defect investigation wearing an architecture
derivation's clothes.

The strongest two-tree falsifier is broader and cleaner than "does undo throw":

> **Can an operation performed solely against tree B alter any semantic result
> subsequently obtained solely from tree A, absent an explicitly established
> relationship between A and B?**

To be tested across surviving semantic machinery: ordinary writes, transactions,
time travel, devtools capture, persistence scheduling, surviving marker
realization, and the causal runtime. If B changes A's result, that is evidence of
SCOPE LEAKAGE without assuming its mechanism.

### MUT-4 CONSUMERS — last, and with a hard limit

> **Consumers may FALSIFY an insufficient contract. They may NOT DEFINE the
> contract merely because current code wants certain metadata.**

Without that limit, time travel wanting paths plus devtools wanting snapshots
plus persistence wanting authored sequence unions into a giant mutation-event
object — precisely the abstraction this audit exists to challenge.

### MUT-1 — FIRST MEASUREMENTS (evidence, not yet a contract)

`packages/core/src/lib/mut-participation.spec.ts`, 15 tests, GREEN. TEMPORARY
under the ANG-V0-F protocol — deleted when MUT-1's contract freezes; the rows
below are what survives.

**A control was needed and taken.** The first pass subscribed with `''`, which
`PathNotifier.matches()` treats as a literal path, so every row read "no
notification". The catch-all is `'**'`. All rows below use it.

```
OPERATION              LANDED   HISTORY d   PATHNOTIFIER
leaf .set()            yes      +1          a.n
branch call form       yes      +1          a.n
root call form         yes      +1          a.n, top      LANDED leaves only
root updater form      yes      +1          top
deep-equal write       NO        0          (none)
UNDO                   yes       0          a.n
entityMap CRUD         yes      +1          rows.a
status() transition    yes      +1          job.state
```

#### R1 — a non-landed write produced no consequence ON THE MEASURED PATHS

**CORRECTED — narrowed to the experiment.** The earlier wording, _"LANDED is the
precondition for every other dimension"_, converted one negative control into
ontology. What was measured:

> **For the HISTORY and PATHNOTIFIER paths, a non-landed deep-equal write
> produces no observable consequence.**

Two subsystems, one write shape. It was NOT established that no other surviving
subsystem can observe an attempted, refused or non-landed operation — transactions
and guardrails, to name two, were not exercised. Whether `LANDED` is UNIVERSALLY
prerequisite is a later MUT question, not a settled one.

#### R2 — PathNotifier emits exactly the LANDED LEAVES, on a BARE tree

Measured without any enhancer applied. A root write of
`{ a: { n: 4 }, top: 7 }` over `{ a: { n: 1, s: 'x' }, top: 0 }` emits `a.n` and
`top` — **`a.s` is absent**, having been rewritten with its own value. Branch and
root writes are decomposed to the leaves that actually changed.

So notification is a property of CORE'S WRITE PATH, not of an enhancer.

#### R3 — THE DISCRIMINATOR: a notification cannot encode WHY truth changed

```
ordinary authored-looking write   truth changes   notifier emits   history +1
undo                              truth changes   notifier emits   history  0
```

**Undo is indistinguishable from an authored write AT THE NOTIFIER.** Any
consumer inferring _"the user changed this"_ from a PathNotifier event is wrong,
and the error is invisible.

**CORRECTED — history is EVIDENCE of a category distinction, not the DEFINITION
of authorship.** The earlier wording let time travel's history stand in for the
causal model before MUT-2 derives it. What the measurement supports:

> **PathNotifier cannot distinguish an ordinary write that current history
> records from an undo realization that current history does not. It therefore
> lacks information required to separate at least these two semantic
> categories.**

That the current history machinery differentiates them is evidence such a
distinction is real and load-bearing. It does NOT establish `history delta` as
the canonical authorship oracle. **MUT-2 must ask which surviving authority
actually owns that distinction.**

**CORRECTED — PathNotifier is NOT "publication".** The earlier row read
`PUBLICATION tracks LANDED exactly`, which quietly redefined a frozen term. What
was measured is a CORE CALLBACK BUS firing at landed-leaf granularity. Under the
frozen invariant _Angular owns observation_, that is not automatically the
Angular publication boundary:

```
LANDED                measured
PATH NOTIFICATION     measured; tracks landed leaves in the tested write shapes
ANGULAR PUBLICATION   NOT TESTED HERE
AUTHORSHIP            NOT represented by PathNotifier
```

So the claim travels as:

> **`PathNotifier` is AT LEAST a landing-notification bus. Whether it
> participates in, implements, or merely PARALLELS publication is UNPROVEN.**

#### R4 — the `interceptLeafSignals` docblock premise is FALSE AT HEAD

Its justification reads:

> _"SignalTree's recursive update pipeline writes to leaf signals directly
> without invoking PathNotifier ... a direct call like
> `tree.$.user.profile.name.set(x)` never produces a PathNotifier event by
> itself. Enhancers that need to observe every mutation must intercept those
> leaf writes themselves."_

Tested on its own named example:

```
tree.$.user.profile.name.set('b')   ->   notified: ['user.profile.name']
```

**Refuted verbatim.** Every write path measured reaches the notifier on a bare
tree. `git log` on `path-notifier.ts` shows `45d06959 feat(history): distinguish
causal realization writes` as the most plausible point where this changed —
NOTED, not asserted, since causation was not measured.

Consequence, stated at its true width: **the stated justification for
`interceptLeafSignals` no longer holds.** That is not by itself a disposition —
absence of its original reason does not decide its fate, and the derivation, not
this row, must do that.

#### Correction to the SCHEMA-era finding — stated without a mirror overclaim

The schema investigation concluded _"ordinary leaf writes do not enter a
canonical semantic mutation pipeline."_ Replacing that with _"they DO enter a
canonical semantic mutation pipeline"_ would be the same overclaim inverted.
What is proved:

> **Ordinary leaf writes DO enter PathNotifier. The earlier claim that they
> bypass all common core notification machinery was therefore FALSE. Whether
> PathNotifier is SEMANTIC AUTHORITY remains open.**

R3 is evidence for the sceptical reading: a mechanism that cannot distinguish
undo from authorship is not, on its own, carrying semantics.

### CARRIED INTO MUT-3 — a falsifier candidate, NOT YET RUN

The MUT-1 harness itself surfaced something. The subscription interface is

```ts
resetPathNotifier();
getPathNotifier().subscribe('**', handler);
```

— visibly **not tree-qualified at subscription time**, with a callback that
carries a path but no obvious tree identity. **Do not conclude global scope from
an interface shape.** Recorded as the candidate falsifier for MUT-3:

```
tree A and tree B both contain the path "a.n"
one subscription to PathNotifier '**'
write ONLY B's a.n

Can the observer distinguish A's a.n from B's a.n using
NOTIFIER-OWNED INFORMATION ALONE?
```

If not, that is stronger scope evidence than the deleted reproducer ever was: it
uses SURVIVING machinery and asks a direct IDENTITY question rather than
observing a thrown error.

**Deliberately not run yet.** MUT-3's sequence stands: first derive what scope
information a landing notification actually NEEDS, if any. Running the falsifier
first would let the mechanism's shape write the contract.

### MUT-2 — WHICH AUTHORITY DISTINGUISHES AUTHORED FROM REALIZED?

Started from the corrected question rather than an inventory:

> **A landed truth change may be an ordinary authored change, an undo/redo
> realization, a rollback, a restore, or some other non-authoring realization.
> Which surviving authority, if any, MUST distinguish those categories for
> SignalTree to remain correct?**

#### A representation exists and is named — see MUT-2A for what it is NOT

```ts
type CausalWriteMode = 'authoring' | 'realization';   // types.ts
interface WriteAttribution { participation?: ...; source?: ...; intent?: ... }
interface MutationEnvelope { positionId; path; ownerPath?; before; after;
                             kind; subjectId?; structural?; attribution?; }
```

`packages/core/src/lib/causal-write-mode.ts` owns the mode. This is what
`45d06959 feat(history): distinguish causal realization writes` added.

#### MEASURED — the distinction DOES reach observers

**This REFINES R3.** R3 said a consumer inferring _"the user changed this"_ from
a notification is wrong. That holds for the PATH, and only for the path. The
notification's META does carry the distinction:

```
AUTHORED write   path a.n   source null       meta { mutationIntent: 'replace' }
UNDO             path a.n   source 'system'   meta { intent: 'system',
                                                     source: 'system',
                                                     participation: 'realization',
                                                     positionIds: [3] }
REDO             path a.n   source 'system'   participation 'realization'
```

So the corrected R3 is (further qualified by MUT-2A):

> **The notification PATH cannot separate authored from realized. The
> notification META can, on two independent channels (`source === 'system'` and
> `participation === 'realization'`).**

A consumer using path alone is wrong; a consumer reading meta is not.

#### THE ARCHITECTURAL FINDING — the marking is ASYMMETRIC

```
REALIZATION   POSITIVELY MARKED     participation: 'realization', source: 'system'
AUTHORING     NOT MARKED AT ALL     no participation; only mutationIntent
```

**Authorship is signalled by ABSENCE.** `CausalWriteMode` names two modes, but
only one is ever stamped; `'authoring'` is inferred from the realization mark not
being there.

That is fragile in a specific, nameable way:

```
any write path that FORGETS to stamp participation is SILENTLY CLASSIFIED AS
AUTHORED — the default is the semantically stronger claim.
```

A new enhancer, a new marker, a new internal restore path, or a refactor that
drops the stamp all fail in the direction that INVENTS authorship rather than
losing it. And the failure is invisible: nothing distinguishes "authored" from
"nobody stamped this".

This is a MUT-2 candidate requirement, stated as a requirement rather than a
design:

> **If the authored/realized distinction is load-bearing, the SAFE DEFAULT is
> the weaker claim. A change whose mode nobody established should not silently
> present as authored.**

Whether that becomes an explicit `'authoring'` stamp, a required mode on every
write, or something else is NOT decided here — MUT-2 establishes the requirement;
the contract decides the mechanism.

#### Still open for MUT-2

```
rollback / restore / hydrate / devtools replay   modes NOT yet measured
transaction writes                               NOT yet measured
does every consumer that needs the distinction actually READ it?  NOT measured
how long must the mode survive, and can it be reconstructed later? NOT derived
```

### MUT-2A — ABSENCE SEMANTICS, run BEFORE expanding the matrix

Three MUT-2 claims outran their evidence and are corrected below. The pass was
run first because **an `undefined` result from hydrate or rollback would have
told us almost nothing until `undefined` itself had a known meaning.**

#### CORRECTION 1 — "the authority exists, and it is named" -> too strong

Finding `type CausalWriteMode` plus a field on `WriteAttribution` proves
**VOCABULARY AND TRANSPORT** exist. It does not prove semantic ownership, which
would require answering who decides the mode, who may establish it, when, who
relies on it for correctness, and what happens when nobody establishes it.

> **A REPRESENTATION for the distinction exists and reaches the measured
> notification path. Its SEMANTIC OWNER is UNPROVEN.**

#### CORRECTION 2 — "two independent channels" -> two CORRELATED indicators

`source === 'system'` and `participation === 'realization'` were observed together
on undo and redo. They may be two fields stamped from ONE ambient context.
Independence needs a divergence test — can either occur without the other? —
which was not run. Recorded as **two correlated indicators**, so we do not
conclude there are two semantic authorities where there may be redundant
transport.

#### CORRECTION 3 — the absence claim, now MEASURED rather than inferred

MUT-2 asserted _"`'authoring'` is inferred from the realization mark's absence"_
and _"a forgotten stamp is silently classified as authored"_. That needed a
defaulting rule to exist. **It does**, and the whole of it is four lines:

```ts
// packages/core/src/lib/causal-write-mode.ts
export const getCausalWriteMode = (meta?: Pick<WriteMetadata, 'participation'> | undefined): CausalWriteMode => meta?.participation ?? 'authoring';
```

#### THE FULL TRACE

```
WRITERS OF 'realization'        8 sites
  time-travel.ts:1628
  internals/causal-runtime/tree-realization-adapter.ts   x7

WRITERS OF 'authoring'          ZERO production sites
  the string appears exactly twice in packages/core/src: in the type union,
  and as the `??` default above

READERS                         7 call sites, ALL testing === 'realization'
  transactions.ts:968, 1021
  time-travel.ts:2604, 2647, 2777
  internals/causal-runtime/transaction-capture-bridge.ts:51
  path-notifier.ts:518, 555, 571   (batch-identity discriminator)
```

**No reader tests `=== 'authoring'`. No reader distinguishes absence from
`'authoring'`** — every one routes through `getCausalWriteMode`, which collapses
them first.

#### THE ANSWER, to the sharpened question

> **Does SignalTree represent authorship POSITIVELY anywhere, or does its causal
> machinery merely mark EXCEPTIONS to an implicit default?**

```
IT MARKS EXCEPTIONS. Authorship is never written, only synthesized by `??`.
```

And the falsifier resolves cleanly:

> _"If I construct a landed change with no `participation`, what surviving semantic
> consumer treats it differently from one explicitly marked `'authoring'`?"_

```
NOTHING. Provably — they are collapsed by the single function every reader uses.
```

So `'authoring'` is **IMPLICIT / DEFAULTED** (see amendment 1 below; the
earlier word here was "aspirational vocabulary", which overreached): a member of the union that no
production code writes and no reader names. Of the three candidate ontologies,
`undefined = authoring` is the one implemented, in exactly one place.

#### THE EARNED REQUIREMENT — and it is stronger than MUT-2 stated

The unsafe default is real, and the failure direction is concrete. Every reader
tests `=== 'realization'` in order to EXCLUDE such writes from capture. So an
unmarked write is CAPTURED as authored history — meaning a realization path that
forgets its stamp produces **phantom undo entries**, a failure this repository
has already paid for once (`history-scoped-capture.spec.ts`, "no PHANTOM undo
steps").

The candidate invariant is therefore not merely _"realization must be stamped"_:

> **UNKNOWN != AUTHORING.** A landed change whose mode nobody established must
> not silently acquire authorship. Absence is a THIRD state, and collapsing it
> into the semantically stronger claim is what makes the current default unsafe.

**NOT a design.** Whether that becomes a required mode on every write, an
explicit `'authoring'` stamp, or a distinct `'unknown'` member is the contract's
call. MUT-2A establishes only that the requirement is real and that the current
representation cannot express it.

#### NOW the matrix can be expanded

rollback, restore, hydrate, devtools replay and transaction writes become
interpretable, because each result now has a known meaning:

```
explicit 'realization'   correct, and excluded from capture
absent                   collapsed to authoring, and CAPTURED
explicit 'authoring'     never occurs in production
```

### MUT-2A AMENDED, and MUT-2B — the falsifier that earns the contract

Three MUT-2A claims are narrowed first; the falsifier then earns a stronger,
narrower result than the one they reached for.

#### AMENDMENT 1 — `'authoring'` is IMPLICIT/DEFAULTED, not "aspirational"

Calling it _"a union member no code writes and no reader names"_ went too far.
No production site writes the STRING, true — but `getCausalWriteMode()` PRODUCES
`'authoring'` as its normalized result, and that is production behaviour. Its
callers branch against realization, so `'authoring'` is the complementary
normalized state whether or not anyone spells the comparison.

```
authoring     IMPLICIT — synthesized by normalization
realization   EXPLICIT — positively transported
```

The asymmetry criticism is untouched; only the word "aspirational" goes.

#### AMENDMENT 2 — the capture claim was broader than the trace supports

_"An unmarked write is CAPTURED as authored history"_ generalized over readers
that do different jobs. `PathNotifier` uses the mode for BATCH IDENTITY, not
causal capture, and `mode != realization` does not by itself imply
`will become history` — other predicates may apply. The trace supports only:

> **At capture gates that reject `realization`, an unmarked change takes the
> same branch as authoring and therefore cannot be excluded on causal-mode
> grounds.**

The phantom-history consequence needed proving separately. It is proved below.

#### AMENDMENT 3 — `UNKNOWN != AUTHORING` is DOWNGRADED to design pressure

MUT-2A proved the REPRESENTATION behaves as a two-state ontology with absence
normalizing to authoring. It did NOT prove the SEMANTIC ontology must have three
states. A greenfield architecture could legitimately hold that all ordinary
authoring entry points establish authorship BY CONSTRUCTION, with realization as
an exceptional internal mode requiring explicit establishment — negative-tagging
risk and all, without a third state.

Earning `UNKNOWN != AUTHORING` would need a required class of landed changes for
which NOBODY has authority to claim either mode at the moment the distinction
becomes load-bearing. That class has not been demonstrated.

```
UNKNOWN != AUTHORING     CANDIDATE DESIGN PRESSURE, not an earned invariant
```

### MUT-2B — ONE-VARIABLE FALSIFIER

Physically identical write, otherwise eligible for capture, differing in
**exactly one field**. Both arms run through `withWriteContext`, so the
transport path is identical.

```
                                   participation      HISTORY d   value
no write context at all            (absent)        +1          1
A  { participation: 'realization',
     source: 'system',
     intent: 'system' }            realization      0          1
B  { source: 'system',
     intent: 'system' }            (absent)        +1          1
```

**A and B differ only in `participation`. B produced a history entry that A did
not.**

```
OMITTING THE REALIZATION CLASSIFICATION PRODUCES A CAPTURE ENTRY.
(See MUT-2C amendment 1 — the earlier wording said "manufactures authorship",
which hands history back the authority we spent three rounds removing.)
Deterministic, one variable, same physical effect, same resulting value.
```

#### THE EARNED CONTRACT

> **Realization versus authoring must be authoritatively established BEFORE
> causal capture. Omission cannot be allowed to create authorship.**

This is narrower and harder than `UNKNOWN != AUTHORING`, and it is proved rather
than argued. It says nothing yet about how many semantic states exist.

#### A DIVERGENCE RESULT, obtained for free

Amendment 2 of MUT-2A recorded `source === 'system'` and
`participation === 'realization'` as CORRELATED INDICATORS pending a divergence
test. **Arm B is that test.** It carries `source: 'system'` and `intent:
'system'` WITHOUT `participation`, and it was captured anyway.

```
source: 'system' occurred WITHOUT the exclusion behaviour
-> for the capture gate, `participation` is LOAD-BEARING and `source` is NOT
```

They are correlated in EMISSION but not equivalent in EFFECT. The reverse
direction — `participation: 'realization'` without `source: 'system'` — is still
unmeasured.

#### THE STRUCTURAL FINDING — normalization happens at READ TIME

```
transport   participation?: CausalWriteMode        OPTIONAL
consumer    getCausalWriteMode(meta)            SUPPLIES THE SEMANTIC DEFAULT
```

Every consumer trusts an optional transport field and RECONSTRUCTS semantic
meaning from its absence. So the question MUT-2 is actually converging on is a
boundary question, not an enum question:

> **At what boundary must authored-versus-realized become TOTAL?**

Candidates, none chosen: total before a `MutationEnvelope` is admitted to causal
machinery; separate entry points for authoring and realization; an ambient causal
context that owns it.

The requirement, stated without presupposing a mechanism:

> **A load-bearing causal classification must be established by its OWNER before
> any consumer whose behaviour depends on it. Consumers must not manufacture the
> STRONGER semantic claim from missing transport metadata.**

That does not imply an `'unknown'` enum member, and does not decide the boundary.

### MUT-2B AMENDED, and MUT-2C — the classification is SUPPLIED, not owned

#### AMENDMENT 1 — "manufactures authorship" reclaims what we just took away

The heading read _"OMITTING THE REALIZATION CLASSIFICATION MANUFACTURES
AUTHORSHIP"_. Three rounds were spent preventing time-travel history from
becoming the DEFINITION of causal authorship, and that wording hands it back.
What the experiment deterministically proves:

> **A realization-shaped write whose classification is omitted is not excluded by
> the current capture machinery, and produces a history entry that the
> explicitly-classified equivalent does not.**

Ontology-neutral, and already severe. It may be promoted to "authorship" only
once causal authority establishes that such capture CONSTITUTES creation of a
turn.

#### AMENDMENT 2 — "authoritatively established" is premature

The BEFORE-CAPTURE half is earned. The AUTHORITATIVELY half is not, while the
semantic owner is still UNPROVEN. Frozen as:

> **The authored-versus-realized classification must be RESOLVED BEFORE any
> causal capture decision that depends on it. A missing classification must not
> silently take the capture branch merely because the transport field is
> optional.**

#### AMENDMENT 3 — the control was MISLABELLED

The row _"no write context at all"_ was wrong: the helper always wrapped the
write, so `run({})` was an EMPTY CONTEXT. Corrected with a true no-context arm
and a four-rung ladder:

```
no ambient context                                        d +1
empty ambient context {}                                  d +1
{ source:'system', intent:'system' }                      d +1
{ source:'system', intent:'system', participation:'realization' }   d  0
```

**The MODE FIELD is decisive, not the presence of a context.** The first three
rungs are indistinguishable at this gate. And `source: 'system'` is not a
substitute for realization classification at the measured time-travel capture
gate.

### MUT-2C — OWNERSHIP AND FORGEABILITY

> **Is `participation` merely transport for a fact owned by the causal kernel, or
> can ordinary authoring code MANUFACTURE that fact?**

`withWriteContext` is exported from `@signaltree/core/authoring`, which
`package.json#exports` publishes as a real subpath. So the question is not
hypothetical.

```ts
withWriteContext({ participation: 'realization' }, () => {
  tree.$.balance.set(1_000_000);
});
```

```
                    landed      history d   canUndo()
FORGED CLAIM        1 000 000       0        false
HONEST CONTROL      1 000 000      +1        true
```

**An ordinary tree write, executed under CALLER-SUPPLIED authoring metadata
claiming realization, lands in full and is suppressed from the MEASURED
TIME-TRAVEL capture and undo surface.**

**CORRECTED — the measured owner is `restoration()`, not "causal history".** The
experiment used `.with(restoration())`, `tree.getRestorationHistory()` and `tree.canUndo()`.
Promoting that to canonical causal history would annex an authority MUT has not
established, and the unified-substrate hypothesis is explicitly unproven.

#### THE ANSWER

**CORRECTED — ownership and enforcement are different claims.**

```
OWNER        UNPROVEN     MUT is still deriving who should own the fact
EXCLUSIVITY  REFUTED      at the current API boundary
VALIDATION   ABSENT       for the measured capture path
```

> **The current implementation does not exclusively control or validate the
> realization classification before the measured capture decision.**

A design can hold that the causal kernel OWNS this fact while having an API that
lets other code forge it. That gap may itself be the defect — but it is a
statement about ENFORCEMENT, not about ownership.

#### STATED AT ITS TRUE WIDTH — this is NOT yet a security finding

`/authoring` self-documents as _"Enhancer- and marker-author plumbing ...
application code should not need any of it."_ So this is a DOCUMENTED-INTERNAL
surface, not an untrusted-input boundary, and no threat model has been
established. The finding is architectural:

```
PROVED        the claim is reachable from a published subpath and TAKES EFFECT
PROVED        the current implementation neither restricts nor validates it
NOT PROVED    that this constitutes a vulnerability — no threat model exists,
              and the subpath is documented as internal plumbing
NOT DECIDED   who SHOULD own the classification
```

The architectural consequence stands regardless of threat model: **a semantic
distinction that determines whether a change enters causal history is asserted
by the caller and believed.** Whether realization should be exclusively a
causal-kernel operation is exactly what MUT must now derive.

#### A SECOND FINDING, for MUT-3

`write-context.ts` documents its own storage:

> _"`activeContext` is a module-level singleton."_

**Write-context STORAGE is MODULE-GLOBAL and not intrinsically keyed by tree.**

**CORRECTED — that is not yet a semantic defect.** `withWriteContext` is
synchronous and stacks/restores the prior context, and may legitimately describe
an operation whose nested writes span some allowed scope. Module-global storage
does not by itself prove foreign-tree contamination. What it creates is exactly
the question MUT-3 needs:

> **An ambient classification exists and is not keyed by tree. WHICH WRITES is
> it legitimately allowed to govern?**

Recorded, NOT yet run: MUT-3 derives the scope contract first.

### FROZEN AFTER MUT-2C

```
PROVED
  participation changes the measured time-travel capture behaviour
  explicitly-realized       -> history d 0
  otherwise-identical unmarked -> history d +1
  the mode FIELD is decisive, not context presence
  source:'system' does not substitute for it at this gate
  classification must be resolved before this capture decision
  the classification is caller-supplied and unverified
  it is reachable from a published subpath and takes effect

NOT YET PROVED
  extra history entry == canonical authorship
  who owns authored-vs-realized classification
  that caller-supplied classification is a vulnerability
  that a third semantic UNKNOWN state is required
```

## RULE 0k — "ANGULAR HAS A PRIMITIVE" IS EVIDENCE, NOT A FALSIFIER

The audit has deleted three large surfaces in a row. That builds momentum toward
a shortcut which would be as unprincipled as keeping everything:

```
WRONG                                  RIGHT
Angular has resource()                 What becomes IMPOSSIBLE without the
-> asyncSource unnecessary             SignalTree concept?
Angular has signals                          v
-> status unnecessary                  Only THEN: does Angular already supply
Angular has equality                   the minimum primitive for that function?
-> compared unnecessary
```

**The function must be derived BEFORE the primitive is compared**, or we conclude
redundancy without ever proving the two things mean the same thing. That is the
`form()` category error with a different mask.

### THE COUNTEREXAMPLE, and it was caught by review rather than by the audit

I cited `derived()`'s removal in 6.3.1 as precedent — _"the project already
applied this test once and deleted."_ **It did not.** Measured:

```
REMOVED     the standalone `derived()` FACTORY
ALIVE       `.derived($ => ({...}))`   a first-class tree API
ALIVE       `derivedFrom()`            exported helper
ALIVE       `linked()`                 writable-derived over Angular linkedSignal
ALIVE       `isDerivedMarker`          runtime, merge-derived.ts:158
ALIVE       `DerivedMarker`            drives ProcessDerived / WithDerived types
```

**One SPELLING died; the CAPABILITY was kept and reshaped.** So it is a data
point AGAINST the deletion prior, not for it:

```
Angular has computed()
   !=
all SignalTree derived functionality is redundant
```

The surviving function may be something like _"compile additional state whose
identity and TYPE SURFACE derive from the tree and participate in the resulting
facade"_ — categorically different from _"give me a computed signal"_. And
`linked()` may differ again: **Angular owns the reactive primitive while
SignalTree may own how that primitive participates in a compiled tree surface.**

> **Sometimes Angular owns the MECHANISM while SignalTree still owns
> COMPILATION, STRUCTURAL INTEGRATION, IDENTITY, or tree-level DX. The next
> phase must not become "find the Angular primitive and delete the SignalTree
> feature."**

### REVISED TRIAGE — four tiers, and NOT one shared verdict

An earlier draft proposed running `asyncSource`, `asyncQuery`, `loader`,
`status` and `compared` against ONE shared Angular-null falsifier. **Rejected —
too heterogeneous.** Their functions are not obviously the same thing:

```
asyncSource / asyncQuery   orchestration + async result lifecycle?
loader                     acquisition / loading?
status                     semantic operation state?
compared                   equality and change semantics?
```

They may be audited CHEAPLY and in ONE PASS, but **each gets its own NULL and
its own verdict**:

```
asyncSource   assume it does not exist. What async-state capability is lost?
asyncQuery    same, INCLUDING the input -> result relationship
loader        what acquisition/loading capability is lost?
status        what semantic state does it carry that ordinary signals do not?
compared      what does SIGNALTREE ITSELF need to know about equality?
```

#### The four tiers

```
1  FINISH MUT FIRST — their semantics depend on the contract
     restoration · transactions · PathNotifier · interceptLeafSignals
     devtools causal behaviour · batching (if mutation/publication affects it)
     the cross-tree undo defect

2  AUDITABLE AFTER MUT, but MUT does not define their function
     asyncSource · asyncQuery · loader · status · compared
     cheap, one pass, five separate verdicts

3  NEEDS ITS OWN DERIVATION once the kernel settles
     entityMap        KERNEL-ADJACENT, strong survival candidate
                      (SubjectId is frozen; Angular provides no normalized identity)
     stored           OWNER FROZEN (persistence consequence), REALIZATION unproven
     derived surface  STRUCTURALLY SIGNIFICANT, FUNCTION SURVIVAL UNPROVEN

4  PACKAGE VERDICTS LAST
     ng-forms · guardrails · realtime · events · shared
```

**Tier 3 is deliberately not one bucket.** An earlier draft called all three
"the right realization of something we have already frozen" — too generous.
`entityMap` has frozen identity concepts making its function plausible; `stored`
has a frozen owner but an unproven realization; **the derived surface has no
established function at all yet.** We know only that it is substantial and
structural enough to deserve a real audit.

**Package survival must never be inferred from surviving files.** That inference
has already been caught twice in this audit.

#### One sequencing guard

"Almost everything waits on MUT-3" is broadly right for causal machinery and must
not become a universal blocker. Tier 2 does not need MUT to define its function.

#### And one status correction

The substrate hypothesis — undo/redo/rollback/branch/merge as operations over one
causal substrate — is recorded as FALSE AT HEAD. That is a **current
implementation fact, not an architectural disposition.** Time travel and the
causal runtime being separate today refutes _"already unified"_, not
_"should unify."_

### AI DISCOVERABILITY — artifacts deleted, function retained

```
AI DISCOVERABILITY FUNCTION     SURVIVES
current llms / skills ARTIFACTS DELETE
REPLACEMENT                     DEFERRED OBLIGATION
```

**Reason:** they are DERIVED DESCRIPTIONS of an architecture that is not frozen.
They teach APIs that were deleted, and — more importantly — most of what they
teach that is still ACCURATE describes concepts that have not been
survival-audited. Patching only the schema and marker references would produce a
document accurate today and wrong again after the next disposition.

Greenfield them only after the surviving public surface freezes. This is Rule
0j-1: a rejected artifact does not require a replacement design now.

**Confidently-wrong AI guidance is worse than none.** A missing `llms.txt` makes
an agent fall back to types and README; a stale one makes it emit deleted APIs
with conviction.

**READMEs are a DIFFERENT CLASS.** A package cannot have no front door. They are
REDUCED to frozen truths only — anything UNPROVEN disappears from instructional
prose until audited, rather than the file being deleted.

**Publish wiring must follow.** `prepare-publish-artifacts.mjs` hard-fails on a
missing source ON PURPOSE:

> _"NOT conditional. A missing source is the failure this script exists to
> surface ... Either produce the file or remove its entry from
> @signaltree/core's `files` — do not restore the silent skip."_

So the deletion must also remove the copy-list entries and the `files` entries,
exactly as that error instructs. The guard itself stays intact for everything
else.

## Phase 3 — Packaging Proof

- [x] preflight: close Gate B reviewer lint finding — move `isTraversableNode`
      helper to private `@signaltree/shared` and consume it from `ng-forms`;
      validation: `pnpm nx lint ng-forms --output-style=static`,
      `pnpm nx lint shared --output-style=static`, shared/ng-forms tests,
      `pnpm nx build ng-forms --skip-nx-cache --output-style=static`,
      `npm run typecheck:source`
- [x] audit built package output —
      `nx run-many -t build --projects=core,ng-forms,shared,events --output-style=static`,
      `node scripts/verify-package-hygiene.js`,
      `node scripts/verify-publish-artifacts.mjs core events ng-forms`
- [x] `npm pack` every publishable package — covered by
      `node scripts/verify-package-hygiene.js` and
      `node tools/verify-tarball-consumer.mjs`
- [x] verify tarball exports/types/layout —
      `node tools/verify-tarball-consumer.mjs`
- [x] clean TypeScript consumer smoke project —
      `node tools/verify-consumer-typecheck.mjs`
- [x] clean Angular consumer smoke project —
      `node tools/verify-angular-consumer.mjs`

Exit condition: `GATE C` — **SATISFIED**

Gate C independent review at `aa481df6`: no blocker demonstrated. Residual Gate
D risks carried forward: fix `check-bundle-budget.mjs` after deleted `form`,
re-baseline or reduce bundle budgets, ship LICENSE files in package tarballs,
and clean stale `dist/packages/*` artifacts for deleted packages.

## Phase 4 — Release Quality

- [x] compatibility/runtime/browser coverage — updated route-smoke coverage to
      match surviving routes after package deletion, then validated the built
      demo. Validation: `pnpm nx build demo --configuration=production
--skip-nx-cache --output-style=static`, `npm run smoke:routes` (21 passed).
- [x] lifecycle/memory/churn tests — focused lifecycle/churn specs passed
      (66/66): `enhancer-cleanup`, `entity-predicate-churn`,
      `marker-snapshot-memo`, `stored-leak`, `memory-manager`, `memory-stress`.
      Smoke measurements: `node --expose-gc tools/bench-retention-arms.mjs
scalar 100 5`, `node --expose-gc tools/bench-retention-arms.mjs sameRow
100 5`, `node tools/bench-predicate-memo.mjs --n 100 --reads 20 --json`.
- [x] error model audit — focused error tests passed (156/156),
      `node tools/check-error-codes.mjs`, `node tools/check-error-codes.mjs --self-test`,
      `node tools/check-devmode-foldable.mjs`,
      `node tools/check-devmode-foldable.mjs --self-test`
- [x] persistence contract audit/documentation — focused persistence,
      stored, hydration and SSR specs passed (98/98); active persistence docs
      reviewed: `docs/guides/persistence-guide.md`,
      `docs/guides/persistence-and-security.md`
- [x] SSR/hydration decision and tests/docs — focused SSR/hydration specs passed
      (29/29): `ssr-transfer`, `rehydrate-ownership`, `hydrate-decisions`,
      `rehydration`, `marker-serialization`, `marker-roundtrip`; active guide
      reviewed: `docs/guides/ssr-and-hydration.md`
- [x] README upgrade — removed active README/doc imports for deleted APIs
      (`status`, `form`, `validators`, `formBridge`, `memoization`, `entities`,
      presets, `withTimeTravel`, `bindFormToTree`) and restored the canonical
      Angular support claim. Validation: `node scripts/lint-readme-apis.mjs`,
      `node scripts/verify-version-claims.js`.
- [x] docs/examples/demo — stale links to deleted AI artifacts and removed
      source files were removed or rewritten as prose. Validation:
      `node tools/check-doc-links.mjs`, `node scripts/lint-readme-apis.mjs`,
      `node scripts/verify-version-claims.js`, `npm run smoke:routes`.
- [x] package metadata/license/security audit — publishable package manifests
      now include `LICENSE` and `NOTICE`, Rollup build assets copy them into
      each dist package, and package hygiene enforces both files. Direct
      production advisories were cleared by updating `echarts`/`lodash-es`,
      moving type-only `@vercel/node` to devDependencies, and pinning its dev
      `undici` tree to the latest 5.x patch. Validation:
      `pnpm audit --prod`, `pnpm nx run-many -t build -p core,events,ng-forms
--skip-nx-cache --output-style=static`,
      `node scripts/verify-package-hygiene.js`,
      `node scripts/verify-package-hygiene.js --self-test`,
      `node scripts/verify-exports.js`,
      `node scripts/verify-publish-artifacts.mjs core events ng-forms`,
      `node tools/verify-tarball-consumer.mjs`,
      `node tools/verify-consumer-typecheck.mjs`,
      `node tools/verify-angular-consumer.mjs`,
      `node tools/check-bundle-budget.mjs`.

Exit condition: `GATE D` — **SATISFIED**

Gate D independent review at `1fea406c`: no blocker demonstrated. Residual
Phase 5/RC risk carried forward: numeric-claim generator annotations needed
repair before publishing release candidate docs; closed during Phase 5.

## Phase 5 — Automation

- [x] **Fix two timing-sensitive specs that fail under parallel load.**
      `status.spec.ts` "should initialize 100 markers in under 50ms" and
      `production-scalar-substrate.benchmark.spec.ts` "public undo-of-remove
      realization" both failed transiently during Phase 1 runs and pass on a
      quiet machine. Not kernel blockers — but a wall-clock assertion in the
      default suite makes release automation nondeterministic, which is exactly
      what a CI release gate cannot tolerate. Either give them a generous
      margin, move them out of the gating suite, or assert complexity rather
      than milliseconds.

      **Also make the failure legible.** `nx test core` reports a failure
      without naming the failing test at any `--output-style`, `--verbose`
      included, so the flakiness above currently cannot be diagnosed through the
      documented command — see "Newly discovered" under slice 1. `npx vitest
      run` from `packages/core` reports normally.

      Done at `1c67f91b`: the stored-marker wall-clock performance
      suite is already gated behind `ST_PERF=1`; the public undo-of-remove
      100k complexity audit now has the same explicit `20_000` timeout as the
      neighboring large structural audits; and `nx test core` now routes through
      `tools/run-core-vitest.mjs`, preserving the documented command while
      streaming Vitest's own failure names and stacks. Validation:
      `node --check tools/run-core-vitest.mjs`,
      `pnpm nx test core --testFile=packages/core/src/lib/production-scalar-substrate.benchmark.spec.ts --skip-nx-cache --output-style=static`,
      `pnpm nx test core --testFile packages/core/src/lib/production-scalar-substrate.benchmark.spec.ts --skip-nx-cache --output-style=static`,
      `pnpm nx test core --testNamePattern="should initialize 100 markers" --skip-nx-cache --output-style=static`,
      `pnpm nx test core --skip-nx-cache --output-style=static`.

- [x] CI release gate — release and publish workflows now use the surviving
      unified gate set instead of deleted guardrails/taught-symbol scripts;
      retired `lint:skills`/`taught-symbols` entries were removed from
      `tools/verify-gates.mjs`; `release-claims` now tracks live claim surfaces;
      stale v9 bundle ceilings and the dead-export ratchet were re-baselined;
      numeric claims now carry generator annotations. Gate E review found
      `gates:self-test` still blocked release/publish workflows; fixed at
      `22ff88ac` by retargeting the blind `dead-exports:self` and
      `declaration-docs` mutations. Validation:
      `node tools/verify-gates.mjs --only=lint:skills,taught-symbols`,
      `node tools/check-release-claims.mjs`,
      `node tools/verify-gates.mjs --self-test --only=release-claims`,
      `node tools/verify-gates.mjs --self-test --only=dead-exports:self,declaration-docs`,
      `node tools/verify-gates.mjs --self-test`,
      `node scripts/v9-budget-checks.js`,
      `node tools/find-dead-exports.mjs --max=110`,
      `node tools/check-numeric-claims.mjs`,
      `node tools/verify-gates.mjs --fast`,
      `node tools/verify-gates.mjs --self-test --only=release-claims,package-hygiene:self,numeric-claims:self`,
      workflow YAML parse via Ruby.
- [x] trusted publishing/provenance — CI publish now prefers npm trusted
      publishing through GitHub Actions OIDC (`id-token: write`, npm CLI
      11.5.1+, no `NPM_TOKEN` in the workflow) while retaining `NPM_TOKEN` as
      an explicit fallback for emergency/local runs. `ci-publish.sh --dry-run`
      exercises all pre-publish checks without writing to npm. Done at
      `c2a93b5d`. Validation: npm trusted-publishing docs review,
      `bash -n scripts/ci-publish.sh`, workflow YAML parse via Ruby,
      `GITHUB_ACTIONS=true NPM_CONFIG_PROVENANCE=true bash scripts/ci-publish.sh --dry-run`.
- [x] clean-checkout release flow — added
      `scripts/verify-clean-checkout-release-flow.sh`, which clones committed
      `HEAD` into a temporary directory, installs from the frozen lockfile,
      builds publishable packages, runs `node tools/verify-gates.mjs --fast`,
      and exercises `ci-publish.sh --dry-run` through the GitHub Actions OIDC
      branch. Done at `88b82a8a`. Validation:
      `bash scripts/verify-clean-checkout-release-flow.sh`.
- [x] final performance baseline generation — regenerated final measurement
      outputs under ignored local scratch directory
      `artifacts/final-baseline-2026-08-21/` from the authoritative generator
      scripts. `tools/size-report.mjs` was updated to remove deleted
      `status`/`form` scenarios, and `tools/bench-ssr-payload.mjs --json` now
      suppresses dev warnings so JSON output stays machine-readable.
      `tools/bench-history-ownership.mjs` now stages the real committed modules
      in its transpiled `path-notifier` dependency graph, removing the stub
      drift that broke the release-only harness gate. Validation:
      `node tools/size-report.mjs --json`,
      `node --expose-gc tools/bench-compare.mjs --n 10000 --json`,
      `NODE_OPTIONS=--max-old-space-size=8192 node tools/bench-vs-signalstore.mjs --json`,
      `node tools/bench-depth-latency.mjs --json`,
      `node tools/bench-leaf-equality.mjs --json`,
      `node tools/bench-ssr-payload.mjs --json`,
      `node --expose-gc tools/bench-history-ownership.mjs --json`,
      parse every generated JSON file, and
      `node tools/verify-gates.mjs --release --only=size-report,size-compare,bench-harness,history-ownership-bench,memory-harness,memory-compare,state-scale,raw-signals`.

Exit condition: `GATE E` — **SATISFIED**

Gate E independent review at `f0dadad4`: no blocker demonstrated after the
`gates:self-test` blocker was fixed. Residual Phase 6 risk: the trusted
publishing workflow has not fired against npm yet because no `1.0.0` tag exists;
first real publish remains the RC task.

## Phase 5.5 — Greenfield Implementation / Convergence

> ⚠️ **INSERTED AFTER GATE E, AND IT BLOCKS PHASE 6.** The controller had Gate E
> flowing straight into `publish 1.0.0-rc.1`. That sequencing predates the frozen
> greenfield decisions and is wrong.

**Gate B froze the INCUMBENT. It did not establish that incumbent `tree()` is the
final public API.** The freeze means _stop modifying the incumbent while we build
its replacement_ — a stable semantic reference point — not _this is the release
candidate_.

An RC asserts: "this is the product we intend to release unless testing finds
defects." We already know it is not:

```text
CURRENT FROZEN INCUMBENT          KNOWN 1.0 TARGET
  tree()                            tree                  controller, not callable
  Angular-shaped core               tree.$()              root read
  69-export contract                tree.$(value)         authored replace
                                    tree.$(fn)            authored derive
                                    framework-neutral kernel
                                    Angular/React/Vue above publication
```

Those are not bug fixes between RC and final. They are deliberate public API and
architecture replacements, and `tree()` → `tree.$()` replaces the PRIMARY
read/write grammar.

⚠️ PUBLISHING FIRST WOULD REVERSE THE AUTHORITY FLIP. External RC users would
depend on `tree()`, and we would then either break them before final or keep the
old spelling _because the RC shipped it_ — the prematurely published incumbent
vetoing the architecture. It also violates ONE SEMANTIC JOB, ONE AUTHORITATIVE
PUBLIC SURFACE, by advertising a spelling already decided to die.

> ⚠️ RE-SEQUENCED after `GREENFIELD-FRAMEWORK-NEUTRALITY-SPIKE-0`. The spike found
> the framework handoff **already physically present** for scalar truth: a neutral
> kernel owns values, equality, revision and `changedSlots`, while Angular holds
> only per-slot publication tokens. `GREENFIELD-FRAMEWORK-HANDOFF-0` was LOCATED,
> not invented — so this is adapter extraction plus type-closure work, not a
> framework-neutral rewrite. Full evidence:
> [`docs/architecture/v15-framework-neutrality-spike.md`](docs/architecture/v15-framework-neutrality-spike.md).

### A. MECHANICAL FLOOR — DONE

```text
[x] extract neutral foundational types    3 one-line redirects; the types were
                                          already neutral, the kernel was importing
                                          them from a re-exporting hub
[x] neutral type-closure gate             kernel-neutrality + :self, mutation-proven
[x] audit atomic-state invariant carriers ATOMIC-STATE-RETIREMENT; 2 ORPHANED
                                          subjects recovered as carriers first
[x] delete atomic-state prototypes        15 files, one bounded batch
[x] full gate register                    54/54
```

Kernel type closure: 27 files / 6 Angular-tainted → **6 files / 0**.
Production files importing Angular: 25 → **19**.

⚠️ Public Angular APIs were NOT moved in this step, by design.

### B. CLOSE GREENFIELD-ROOT-ACCESSOR-SHAPE-0 — NEXT

Must complete BEFORE retyping the 132 Angular-shaped public type sites.

```text
[x] freeze the callable grammar        B1 FROZEN
        tree                  controller, non-callable
        location()            READ
        location(fn)          DERIVE
        location(leaf(fn))    REPLACE the callable AS DATA
        the root tree.$ uses the SAME location grammar
[x] canonical location object owned by the KERNEL, not a WritableSignal
[x] Angular WritableSignal = explicit `toWritableSignal(location)` adapter view
[x] resolve function-valued-state disambiguation   FUNCTION-AS-STATE-0 = FNS-A
[x] branch object write semantics                      RULED — whole-value T
```

GREENFIELD-BRANCH-WRITE-0 ruled on the principle, not on merge-vs-replace:

> **THE LOCATION TYPE DEFINES WHAT CONSTITUTES A COMPLETE VALUE.
> THE MUTATION SURFACE MUST NOT IMPLICITLY WEAKEN IT.**

The canonical callable takes a WHOLE `T`. A state author writing `user: User`
gets a required complete `User`; one writing `user: Partial<User>` gets partials
— because that IS a complete value of that location's type. Measured: weakening
the overload to `Partial<T>` kills all three strictness rejections, including
erasing the `name` requirement from an author's own
`{ name: string; age?: number }`.

Entity parity falls out — `$.user(fullUser)` and `$.rows.byId(1)(fullRow)` mean
the same thing, retiring the incumbent's plain-branch-merges/entity-replaces
special case. Patching stays accurate as a DERIVE; a `patch()` convenience may
earn its own spelling later.

⚠️ CARRIED TO §C: partial EXTERNAL acquisition (bind-branch-0) is admitted and
RELOCATES to an explicit ingress capability — it must not survive as a second
meaning on the authored callable.

FUNCTION-AS-STATE-0 closed as **FNS-A (admitted)**: function-valued state is a
defect-driven requirement with four regression tests behind it. The incumbent
already tried inferring intent from the current value and REVERTED it as
unknowable at runtime, so:

> **FUNCTION INTENT MAY NOT BE INFERRED FROM CURRENT STATE. THE ARGUMENT SHAPE DECIDES.**

> **AN OPERATION THAT ALREADY KNOWS ITS MUTATION SEMANTICS MUST NOT RE-ENTER
> THROUGH SYNTAX WHOSE JOB IS TO INFER THOSE SEMANTICS.** — realization,
> restoration, hydrate and Link acquisition install raw values directly.

The marker is invocation-only encoding: consumed at the boundary, never entering
state, snapshots, Link values, persistence, restoration facts or causal payloads.

Discriminator over the real neutral kernel: **24/24 across 8 cases**, with two
independent falsifiers (reintroducing the inference heuristic; routing ingress
through the authored entrance) both proven to turn it red.

⚠️ CARRIED INTO §C — as a REQUIREMENT, not a presumed fix. The ordinary-value
overload must exclude callable functions AND constructors: today `$.ctor(Thing)`
typechecks as REPLACE while the runtime invokes it and throws. Public `NotFn`
itself gets `NOTFN-GREENFIELD-DISPOSITION` — DO NOT ASSUME KEEP. It has no live
consumer, and INTERNAL IMPLEMENTATION NEED DOES NOT MANUFACTURE PUBLIC API VALUE;
expectation is delete-and-use-an-internal-type.

FROZEN — **GREENFIELD LEAF OWNERSHIP**: the kernel owns the canonical callable
location; a framework representation is a VIEW of SignalTree truth, never the truth.
Angular interop is explicit and does not define `tree.$.count`.

A and B are one public-contract problem; do not implement callable leaves until the
function-as-data disambiguation is settled.

### C. GREENFIELD IMPLEMENTATION

> **AUTHORITY.** §B contracts are FROZEN. Incumbent behaviour is reference and
> evidence only. Implementation does NOT get to renegotiate: canonical
> `Location<T>`; whole-value `T` assignment; updater ⇒ DERIVE; marked callable ⇒
> whole-value assignment of the raw callable; the kernel owns the canonical
> location; an Angular `WritableSignal` is a VIEW; non-authored ingress bypasses
> authored syntax. **§C must not reopen §B because implementation is awkward.**

```text
C1 REAL LOCATION SUBJECT
   [x] implement kernel Location<T> over the neutral scalar runtime — 81780c4e
   [x] move the §B discriminator onto the REAL subject — cases 1–8, the
       historical-inference mutation, the wrong-authority-ingress mutation
   [x] do NOT create another prototype carrier

C2 TYPE CONTRACT
   [x] author strictness preserved: User rejects a partial; Partial<User>
       accepts one; { name; age? } keeps name required; entity Row same grammar
   [x] ordinary-value overload excludes callables AND constructors
   [x] NOTFN-GREENFIELD-DISPOSITION — public NotFn deleted; exclusion is internal

C3 MARKER PUBLIC SURFACE
   [x] `leaf(value)` is the smallest author-facing terminal/callable-data spelling
   [x] no global augmentation, no transform, no Angular dep, no persistent
       wrapper, no second assignment verb; good inference for callbacks,
       constructors, null unions, updater-shaped stored functions

C4 NON-AUTHORED INGRESS
   [x] explicit realization/acquisition entrance taking raw values and
       preserving the caller's known causal class
   [x] the three bind-branch partial-acquisition cases relocate here
   [x] NOT location(partialPayload), NOT location(rawFunction)
   [x] adapter-only export exists only where Angular proves the ingress need

C5 REMOVE INCUMBENT CALLABLE SEMANTICS
   [x] retire NodeAccessor Partial<T> callable + merging updater — 1495f713
   [x] retire incumbent tree(); migrate the root to tree.$ — 1495f713
       [x] merge carrier contradicted; strict whole-value and explicit runtime
           permissiveness controls retained — 1495f713
   [x] fixture-only callers migrate to complete values or explicit runtime probes,
       assertions unchanged — 1495f713

C6 ANGULAR HANDOFF
   [x] move the Angular scalar publication adapter, the WritableSignal view, the
       DI/lifecycle facade, toWritableSignal, Angular memo/invalidation
   [x] kernel stays neutral under the existing closure gate
   [x] do NOT make Angular signal identity canonical again to ease migration

C7 ENTITY DISCRIMINATOR — CLOSURE EVIDENCE, NOT PLANNING EVIDENCE
   [x] real entity path through a NON-Angular publication adapter: neutral
       physical truth, structural/value mutation, commit/publication result,
       non-Angular observation, same semantic result as the Angular view
   [x] required before GREENFIELD-FRAMEWORK-HANDOFF-0 closes

C8 SURFACE REVIEW — before regenerating the baseline
   [x] NotFn disposition · `leaf` spelling · `toWritableSignal` bridge spelling
   [x] no duplicate mutation verbs
   [x] no leaked SlotIndex / revision / frame / internal marker types
   [x] no incumbent tree() · no WritableSignal as canonical location
   [x] regenerate the baseline for the ACTUAL greenfield surface and
       rerun the C/D/E release gates
```

⚠️ **WHOLE-VALUE ASSIGNMENT MUST NOT BE IMPLEMENTED AS "PARTIAL WRITE WITH
OMITTED KEYS CLEARED."** The §B probe manufactured `undefined` writes for omitted
descendants; it was fine for measurement but misbehaved twice in ways that would
be production defects — a spurious mutation event per omitted key, and unknown
keys discarded before the diagnostic could see them. The kernel installs the
complete `T`. This matters for notifications, causal events, structural deletion,
entity-containing branches and diagnostics.

⚠️ The §13 target packages do not exist: `authoring/` is an empty `src/`, `events/`
and `ng-forms/` hold only `node_modules`. No `kernel/`, no `angular/`.

### D. ENTITY DISCRIMINATOR

The spike's vanilla-adapter proof covered **scalars only**. Before the handoff can be
called closed — not merely before planning:

```text
[x] one entity vertical slice through neutral stores + neutral commit +
    a vanilla publication adapter, yielding the SAME semantic result as Angular
```

### E. DELETE INCUMBENT REPRESENTATION

```text
[x] delete incumbent `tree()`
[x] delete Angular-owned leaf representation from the kernel
[x] compiler-drive the fallout
```

Then, before any RC:

```text
[x] exhaustive public API review of the GREENFIELD surface
[x] regenerate `tools/api-baseline.json` for the ACTUAL 1.0 surface
[x] prove package/type closure on that artifact
[x] rerun ordinary Phase 3/4/5 gates against the greenfield artifact
[ ] rerun release-only gates against the exact final candidate
```

⚠️ **GATES C/D/E DO NOT CARRY OVER AUTOMATICALLY.** Their TOOLING stays valid;
their CONCLUSIONS concern the incumbent artifact. Replacing the kernel, the
package layout and the public surface invalidates what they certified, so they
are re-run against what we actually intend to publish.

Exit condition: the greenfield public surface is frozen and its gates are green.

## Phase 6 — Release Candidate

RC1 is live. Phase 5.5's former block is discharged by the frozen greenfield
surface and the exact-artifact release evidence above.

This phase is stabilization, not architecture rescue. Further physical-density
ideas belong to a separate optional post-RC optimization backlog and cannot
delay `GATE F` or GA without a concrete release falsifier.

> ⚠️ AND "1.0" HERE IS NOT A SEMVER LITERAL. The published line is `15.x` —
> npm now holds `@signal-tree/kernel` and `@signal-tree/angular` at
> `15.0.0-rc.1`. "1.0" in this file means _the first stable release of the
> reworked library_, not a literal semver line.

- [x] **Resolve RC public surface reconciliation before publishing.**
      `docs/audits/2026-08/rc-public-surface-reconciliation.md` maps the
      current tarball exports against the final disposition map. Progress:
      `165e71f9` removed `asyncSource`/`asyncQuery` from the public RC surface;
      `22792f97` removed `loader`/`invalidateTag` helpers and their public type
      companions; `c53aa416` removed `stored`, storage-key helpers, and global
      stored flush from the public RC surface; `52644fa3` removed `linked` and
      its public type companion; `b339b921` removed `trackHistory` and its
      public type companion; `2029db99` removed `serialization` and its public
      type companions; `76ab032c` removed `compared`/`byKeys` and their public
      type companion; `18fe5781` removed the unplaced `lazy` and `edit-session`
      subpaths from the package exports and build entry points. The executable
      public-disposition gate now passes. Independent review found four internal
      evidence specs still importing removed symbols through the public barrel;
      `08b8fae5` moved those specs to internal imports and `pnpm nx test core
--skip-nx-cache --output-style=static` passed on rerun. `b957f604` removed
      stale `compared()` advice from dev warnings after `compared` left the
      public API. The `entityMap` retention figures previously recorded here
      were produced by a defective harness and are withdrawn. The 18 MB / 60 MB
      anomaly was a measurement artifact, not a property of the code:
      `memory-report.mjs` applied a turn boundary to one scenario and no other.
      Repaired (`tools/lib/heap-quiescence.mjs`, one settling protocol for every
      arm; timing and retention split into separate processes in
      `bench-compare.mjs`, which also loads each library's module graph outside
      the measured window; new `memory-consistency` gate rejecting any table
      where a scenario measures less than one it strictly contains; new
      `historical-ab-isolation` gate after `NX_WORKSPACE_ROOT_PATH` was found to
      silently defeat worktree isolation). Quiescent baseline is ~11.3 MB per 10k
      3-field entities; ~81% of the all-held configuration is held per-row
      node/field realization; the physical stores are compact at ~455 B/entity.
      Cross-library retention, module graphs excluded: SignalTree 11.44 MB vs
      NgRx 1.07 MB and raw signals 6.28 MB — ~10.7x, not the ~2.6x an
      earlier repaired-but-unhoisted run suggested, and nothing like the
      published 66/0.93. `bench-vs-signalstore.mjs` could not run at HEAD at all
      (OOM; the whole file was one synchronous job with no turn available for
      deferred cleanup) and is fixed; its NgRx arm was audited for fairness and
      is sound — idiomatic `signalStore(withEntities())` measures the same at
      1k/10k/50k, the dependent read is O(1) on both sides, and NgRx's O(n) is
      inherent to rebuilding the entity map. The flat-vs-linear shape claim
      survives; the deep-write `~100x` claim does not (11.5x today) and is
      withdrawn, as is the published collection-throughput claim: `setAll` has
      regressed against 14.0.0 on a byte-identical harness while all three
      competitor arms reproduce. Key churn also retains without bound
      (~119.7 MB across 150 generations at constant 1k live membership with no
      restorer attached), split into earned and orphan portions in
      `docs/architecture/entity-churn-retention.md`. Neither the regression nor
      the churn finding is automatically an rc.1 blocker under a
      public-API/functional-correctness definition of RC. The `setAll` regression is now
      ATTRIBUTED and its primary mechanism DELETED
      (`docs/architecture/setall-regression.md`). Against an isolated 14.0.0
      build both curves are linear, so it was a ~41x constant-factor increase in
      per-member work, not an algorithmic change. `setAll` called
      `deriveSubjectPositions` per entity, which materialized the full per-row
      node facade, recursively walked it, also walked the whole collection
      `api`, and then discarded the node — work that bought no retained state
      and violated the `member exists != node exists` boundary at
      bulk-population time. Stubbing it left 1,794 core tests passing and failed
      11, all representation assertions in causal specs; a behavioural probe
      with no envelope assertions found every observable public `restoration()`
      undo behaviour intact, and the real transaction suite passed 29/29 with
      position information removed from EVERY entry point including the
      hand-authored `draft.capture` inputs. REMOVE, ADD and REKEY were each
      covered independently. The whole transport was then deleted with it — the
      field, the `subjectState` it fed, `deriveSubjectState`,
      `deriveUndoSubjectState`, three apply loops, `applySubjectState`, the
      adapter plumbing, forwarding across six modules, and seven synthetic
      tests that were its only exercise (all hand-construct `CausalTurn`
      effects; none reachable from a public API). `git grep subjectPositions
      packages/core/src` now returns nothing. No replacement was introduced.
      Result: `setAll(10k)` 90.4 -> ~18-19 ms, `setAll(50k)` 528 -> ~89 ms,
      same-turn high-water heap 59.9 -> 15.3 MB, settled retention unchanged at
      ~11.3 MB (confirming those nodes were always transient). Remaining: ~8x
      the 14.0.0 control, now measurable on a clean build, with
      BASE-SUBJECT-STATE-SIGNAL next (an Angular `WritableSignal` per unobserved
      subject is an ownership question) ahead of BASE-STRUCTURED-CLONE (likely
      only a representation choice).
- [x] publish `15.0.0-rc.1` — exact kernel then Angular tarballs under the `rc`
      dist-tag; tag points to `4020b7dd`
- [x] install from npm in an external project — exact names, strict typecheck,
      bundle, and runtime green
- [x] collect RC packaging/DX/docs failures — Angular `sideEffects` metadata and
      stale emitted `.with()` JSDoc recorded; no semantic/API falsifier
- [x] fix RC issues only — Angular's metadata finding was superseded by
      construction-bound realization; stale active `.with()` guidance and the
      declaration-gate package-universe defect closed at `78ea2ff6`
- [x] **Triage the full-tree repository audit before any next RC or GA
      publish.** Treat the audit as hypotheses, not verdicts. Release-blocking
      until proved absent or fixed: phantom package aliases/directories,
      published-scope inconsistency, and live `core` -> `kernel` drift in build,
      validation, publish, tree-shaking, documentation, or benchmark paths.
      Also verify tracked scratch/backup/migration artifacts and stale shipped
      documentation. Record each finding as confirmed, already superseded,
      non-shipping hygiene, or rejected with an executable falsifier where one
      exists. Broad root/docs/tools/scripts/spec relocation and package-layout
      normalization are non-gating unless they produce a concrete package,
      build, API, documentation, or release-automation failure. The detailed
      inventory lives in `TODO.md` under `V15 pre-publish repository audit`.
      **Exit condition:** every audit finding has one recorded disposition:
      confirmed and fixed, already superseded, explicitly accepted/deferred as
      non-shipping hygiene, or rejected by evidence. No confirmed package
      contract mismatch, generated-artifact mismatch, publish-surface
      ambiguity, broken consumer workflow, or consumer-facing stale guidance
      remains. Once those conditions hold, close this item; discovering more
      aesthetically desirable cleanup is not a reason to extend it.
      **Current-guidance checkpoint:** `2fbd51b2` replaced the stale kernel
      README, AI reference/templates, application architecture guide, and
      Angular/native comparison surfaces with the v15 package and ownership
      model. It corrected current whitepaper, error, restoration, collection,
      and performance prose, while visibly classifying historical API examples
      in audit/decision/history records. `lint-readme-apis.mjs` now discovers
      package names from built manifests; validates named, default, namespace,
      and side-effect imports; scans fenced examples, API tables, and API-shaped
      prose; requires line/block-local exemptions or a near-title historical
      evidence role; and has killing self-tests for import-form and exemption
      leakage. Validation passed: linter self-test and production scan,
      documented imports/symbols, 310/310 links, numeric-claim ratchet,
      declaration-documentation gate, ESLint, and `git diff --check`.
      **Scripts/release checkpoint:** `d32a1131` replaced the stale scripts
      catalog with an authority-aware index and its review exposed two live
      release defects. The dist-reading gate harness now builds the actual
      `kernel,angular,react` package set instead of nonexistent `core`. This was
      superseded at `109595e6` by one Node release plan and one exact-candidate
      publisher. `release.sh` now prepares signed tags and cannot publish;
      manual and CI wrappers delegate to `publish-candidate.mjs`. Routing and
      package order have killing mutations, and a dry run validates exact
      tarballs without registry writes.
      **Source-comment checkpoint:** `aba7d92b` removed stale present-tense
      builder, enhancer-chain, deleted form-marker, and mirrored-overload
      language from `signal-tree.ts` while retaining the architectural reason
      declarative construction validates one complete enhancer set. Production
      behavior is unchanged except that ST2017 now describes a replacement
      returned by the configured set rather than a deleted chain. Prettier,
      ESLint, kernel typing, diagnostics, `git diff --check`, and independent
      review passed.
- [x] **Final public API review.** The former greenfield API froze at
      `75c003c2`; `FRAMEWORK-NATIVE-CARRIERS-0` deliberately superseded its leaf
      carrier types at `7ab2e82d`. The API baseline, release claims, package
      exports, and strict packed declarations are green for the replacement.

Exit condition: `GATE F` — **SATISFIED at `109595e6`**

## Phase 7 — 1.0 Release

- [x] **Clean-clone final release matrix (`8d0108bc`).** Frozen-lockfile install
      green; release matrix 69/69 green; registered gate mutation/self-test
      matrix 60/60 green with zero unproven, blind, or errored proofs. Known
      technical GA blockers: none.
- [x] **`AI-SEMANTIC-DISCOVERABILITY-0`.** The root `llms.txt` is the one
      canonical v15 teaching source, copied deterministically into kernel,
      Angular, and React tarballs; their package READMEs link the co-packed
      manifest. The manifest and permanent mutation-proven gate pin positioning,
      facade imports, `link()`/persistence composition, external authority, and
      causal explanation as projection. Root v10 guidance is historical only.
      Packed artifacts, documentation/import/symbol checks, strict `bundler` and
      `node16` consumers, demo test/build, and V3's 79-project gate are green.
      Independent phase-boundary review found no blocker; the exact final
      release matrix passed 73/73 with zero known-red.
- [x] **`CAUSAL-REPRESENTATION-0` (`8aa9591d`).** The fact inventory, mutation-
      proven baseline, one-owner attribution controls, bounded carrier tests,
      and auxiliary-retention audit preserve all frozen causal laws and select
      the incumbent. `observedBatches` was removed as the sole unbounded
      diagnostic sidecar; `historyIndex`, the confirmed-turn Map, and the
      separate historical-event array remain measured derived or causal state.
      The sole compact-store experiment was semantically green but missed its
      density floor and regressed churn materially, so no replacement is
      selected. Full kernel validation is green; no second carrier experiment
      is authorized.
- [x] **Final v15 demo and recurring benchmark surface (`af8c0c75`, comparator
      retirement `2dd94c15`, sampling/lifecycle `4046ebfb`, final comparator
      removal `217ccd107`, documentation `ee08645e`).** The
      public comparison starts after construction and keeps three independent
      recurring workloads: keyed update plus point read, conditional keyed
      update plus complete projection, and designated change plus undo. Their
      capability-admitted cohorts contain `5 / 5 / 3` first-party arms (`13`
      checked rows); initialization has no public rank or value score, and no
      crossover, payback, or aggregate score survives. Schema 5 exports the
      measured/warmup plan, raw timings, structured calculation context, exact
      package/source provenance, capability contracts, and three independent
      per-1k/10k/100k normalizations. Quick defaults to 25 measured rounds,
      Steady to 100, and users may select 1 through 1,000. One prepared store per
      arm remains live across warmup and measured rounds; accumulators reset and
      correctness is checked after every round, every disposer is attempted,
      and execution plus cleanup failures remain visible. Projection correctness
      is order-independent. Browser copy
      treats sub-millisecond restoration gaps near the timer floor as diagnostic
      and overlapping ranges as no clear difference, while
      `RESTORATION-HOT-PATH-0` records a bounded, non-gating Node attribution
      experiment before any retained-turn representation change. Validation:
      demo tests `143` passing / `4` intentionally skipped; strict typecheck;
      production AOT; demo lint with zero errors and one pre-existing warning;
      focused benchmark Playwright `5/5`; complete production route/layout/
      hover matrix `126/126`; schema-5 Steady production export `100` measured / `5`
      warmup rounds and `13` rows; development export refusal; numeric claims
      `138/138`; complete comparison, update,
      and 12-arm capability-density generators; benchmark gate and its
      undo-removal mutation proof; final independent review clean. The retired
      comparator has no manifest, lockfile, installed, executable, current-doc,
      package-source, demo, or built-artifact presence; point-in-time audit and
      comparison evidence remains explicitly historical.
- [x] **Bounded restoration and bundle performance closure (`e9adaabc`).**
      `RESTORATION-HOT-PATH-0` attributed the production undo pathology to
      `assertTurnStatusConsistency()` scanning retained history after every
      reversal. At 1,000 retained turns, that scan raised the batch from about
      4 ms without the assertion to about 119 ms. It now runs only when Angular
      reports development mode or `NODE_ENV` is explicitly `development` or
      `test`; production and unknown-browser paths retain exact restoration
      behavior without the diagnostic scan. The rebuilt production path takes
      about 4-6 ms for 1,000 root undos; the manager effect pipeline is about
      1.9 ms and precomputed physical application about 1.1 ms. The probe pins
      values, entity identity, frontiers, retained history, redo state, one
      atomic application per turn, and zero production consistency scans.
      `BUNDLE-REACHABILITY-0` found no accidental optional-feature import edge;
      corrected generators exercise a real `undoable()` turn and measure bare,
      EntityMap, and restoration at 9.55 KB, 21.49 KB, and 28.11 KB gzip.
      Density remains closed, construction and bulk population remain
      regression ceilings, and mixed restoration lifetime profiling is
      post-GA/non-public. Validation: restoration `114` passing / `1` existing
      todo; strict typecheck; kernel lint; production demo build and benchmark
      Playwright `5/5`; bundled Angular, React-style, partial-process, unknown-
      browser, and development policy probes; release gates `74/74`; release-
      inclusive mutation proofs `74/74` with zero unproven, blind, or errored
      gates; final independent review clean.

  - [x] **Kernel-owned universal locations and first-party Vue facade
        (`5efeb7f5`; framework identity superseded by `7ab2e82d`).** Canonical
        values, equality, revisions, dependency propagation, subscriptions,
        derived memoization, and grouped publication remain behind the neutral
        location runtime. The experiment's claim that every facade should expose
        the same nominal location did not survive the native-carrier falsifiers.
  - [x] **Callable kernel/root/branch grammar and explicit terminal topology
        (`81780c4e`; narrowed by `7ab2e82d`).** Neutral locations plus root and
        object branches retain read/replace/derive call syntax; `leaf(value)`
        marks topology and callable data. Framework terminal leaves now use their
        native writable APIs. The digest-pinned historical comparison finds no
        clear read, derivation, or construction change and measures scalar
        replacement at about `+4.1 ns`.
  - [x] **Framework-native leaf carriers with kernel authority (`7ab2e82d`).**
        Angular exposes `WritableSignal` / `Signal`, Vue exposes `Ref` /
        `ComputedRef`, and React remains hook-native. Direct carrier identity,
        batching interception, kernel snapshots, causal intent, EntityMap
        projections, Vue `watch` / `unref` / `toValue` / `isReadonly`, strict
        packed declarations, architecture assets, and full demo migration are
        covered. HYBRID-A was rejected by preregistered CPU and density criteria;
        the selected direct carrier preserves the unobserved `1,934 B/leaf`
        density while materially improving Angular hot paths. Validation:
        package suites, strict typecheck, lint, production package/demo builds,
        digest-pinned CPU and forced-GC memory harnesses, `55/55` fast gates,
        `63/63` ordinary gates, and independent review with no blocker. Exact-
        candidate release-only verification remains owed.
  - [x] **Framework-native carrier release audit (`63900634`).** Synchronous Vue
        publication is coherent for root replacement, transactions, EntityMap
        `setAll`, and undo without invalidating 100 unrelated observed derived
        carriers. Nested groups drain every queued invalidation and preserve the
        original mutation error. Native scalar/EntityMap `link()` inference,
        facade-bound `AccessibleNode` / `EntitySignalWithSlices`, and the
        distinction between intrinsic `ComputedRef` values and type-only
        readonly `Ref` views are pinned in source and packed consumers. Live
        bundle figures were refreshed from the authoritative generator. Exact
        committed HEAD passed Vue `13/13`, kernel `2,178` plus two expected
        failures, Angular `99` passing / `3` skipped, React `6/6`, demo `145`
        passing / `4` skipped, strict typecheck, all lints, four production package
        builds, packed `bundler` / `node16` consumers, numeric claims `176/176`,
        API and release-claim gates, `55/55` fast gates, and `63/63` ordinary
        gates. Independent release review found no source blocker. Exact-
        candidate release-only verification remains owed.
  - [x] **RC13 mutation-proof and documentation closure (`6db0e7df`).** Tagged RC13 passed
        all 74 production gates and failed closed on four stale proof anchors.
        The replacements target direct framework contamination, native Angular
        publication, the live `replaceLocation` release claim, and the measured
        kernel declaration-doc baseline. All four now fail under mutation and
        pass restored. A complete live README/docs/demo audit found no remaining
        current API or architecture drift; current version displays and
        StackBlitz dependencies are generated, Vue is present in the package and
        AI surfaces, demo tests/lint/production build pass, and 34 architecture
        assets remain current. Historical RC1 records remain explicitly
        historical. RC14 exact-candidate verification is next.
  - [x] **RC15 browser and release-metadata closure (`807bbbe2`,
        `a752d54f`).** RC14 passed tagged CI and was published under npm's `rc`
        dist-tag, but the complete production route-smoke matrix subsequently
        falsified its mobile demo layout and GitHub exposed its release as
        stable metadata. RC14 remains immutable and is superseded. The demo now
        passes all `127/127` desktop/mobile browser checks: benchmark grids shed
        desktop minimum widths, deep-typing copy no longer forces an incoherent
        break, and mobile architecture labels remain in their intended gaps.
        GitHub release creation derives `prerelease` from the tag, and the new
        `release-prerelease-metadata` gate rejects a hardcoded stable release.
        Validation: production demo build; focused browser checks `28/28`;
        complete route-smoke matrix `127/127`; fast gates `56/56`; ordinary
        gates `64/64`; mutation proofs `64/64`; workflow syntax validation;
        independent release review found no blocker. RC15 exact-candidate
        verification and registry proof remain owed; GA is not authorized.
  - [x] **RC16 React SSR source closure (`1b150355`).** RC15 passed its exact-tag
        workflow, published all four packages under npm's `rc` dist-tag, and
        matched the immutable candidate's four SHA-512 values in canonical
        `kernel → angular → react → vue` order. Clean registry tarballs passed
        facade identity and strict `bundler` / `node16` consumers. The required
        post-registry semantic smoke then falsified React SSR with
        `Missing getServerSnapshot`; RC15 remains immutable and published but is
        superseded. `useSignalTree()` now supplies the canonical selector as the
        server snapshot, with source and packed `react-dom/server` regression
        coverage plus the mutation-proven `react-ssr-facade` release gate.
        Validation: React `7/7`; strict typecheck; React lint/build; README and
        documented-import checks; packed runtime and dual-resolver consumers;
        clean packaged semantic-smoke overlay; fast gates `57/57`; ordinary
        gates `65/65`; mutation proofs `65/65`; browser routes `127/127`;
        independent release review found no blocker. RC16 exact-candidate,
        registry, and V3 brownfield verification closed before GA authorization.

  - [x] **GA publication and stable consumer closure (`8418cd7d`,
        `07c13fdb5`).** Signed-tag run `34001591297` and sanctioned publisher run
        `34002838449` passed the complete release and mutation matrices. Four
        candidate-matching npm artifacts own `latest`; exact and unversioned
        clean installs, dual-resolver declarations, cross-framework semantics,
        React SSR, and stable V3 consumption are green.

- [x] publish `15.0.0`
- [x] verify npm/docs/install instructions from scratch
- [x] post-release operational readiness

Technical readiness disposition: **GA RELEASED / REGISTRY-VERIFIED.**
Source/API, exact-candidate, mutation, registry-integrity, packed-consumer,
stable V3 adoption, and post-publication proof are closed.

Exit condition: `GATE G` **SATISFIED** by the official release and independent
post-publication verification recorded above.

## Suggested Chat Boundaries

- Chat 1: persistence + final atomicity
- Chat 2: fresh HEAD release-blocker audit
- Chat 3: public API/type freeze
- Chat 4: packaging + `npm pack` + consumers
- Chat 5: compatibility/lifecycle/error audits
- Chat 6: docs/examples
- Chat 7: CI/release automation
- Chat 8: RC verification

When a phase is complete, start a fresh chat and tell the agent to read
`AGENTS.md`, this file, current git status, and recent history before touching
the next phase.

## Autonomous Slice Contract

1-3 commits is a normal checkpoint size, **not a stop condition**. If the next
item is unambiguous and context is still healthy, continue. Stop only for a real
decision, a phase boundary, a technical block, or degraded context quality —
never merely because a commit count was reached.

Each commit must have:

- has one clear purpose
- has focused tests green
- has authoritative gate green
- has diff inspected
- has this ledger updated

Intervention is required for:

- semantic choices
- API compatibility choices
- packaging/public-surface choices
- two plausible architectures
- a failing test suggesting a frozen invariant is wrong
- release feature scope changes

## Implementer Prompt

```text
Read AGENTS.md, RELEASE-1.0.md, current git status, and recent history. We are
finishing SignalTree for a public 1.0 release. Work autonomously through the
current release phase only. Always characterize correctness/complexity issues
before changing production, preserve frozen architecture invariants, keep
unrelated dirt untouched, make one conceptual change per commit, run focused
validation followed by the authoritative relevant test/build/lint gates, update
RELEASE-1.0.md after each checkpoint, and continue to the next item in the
current phase while the next step is unambiguous. Stop the phase when its gate
is satisfied or when a genuine product/API/semantic decision is required. Do
not do speculative optimization or start the next release phase.
```

## Reviewer Prompt

```text
Do not modify code initially. Adversarially audit HEAD against the release
invariants and RELEASE-1.0.md. Treat historical findings as stale. Identify
only current release blockers with concrete evidence. Rank them. Do not
recommend speculative optimizations.
```

## Current Sequence From Here

> ⚠️ **THE TAIL OF THIS FILE IS STALE, AND THE 28-STEP LIST BELOW IS INCUMBENT-
> SCOPED.** Steps 1–21 describe reaching a stable release of the INCUMBENT
> surface. Phase 5.5 now sits between the Gate B freeze and any RC, because the
> greenfield decisions replace the primary public grammar. Read the phase
> headings, not this list, for sequencing.
>
> Individually stale as of the Gate B freeze: step 1 ("finish stored()/
> persistence atomic consequence semantics") is VACUOUS — `stored()` is deleted.
> Step 5 ("freeze public API") is done for the INCUMBENT and owed again for the
> greenfield surface.

**THE DECLARATION ARTIFACT IS NOW TRUSTWORTHY. The precondition on the API
cleanup queue is DISCHARGED.** Re-measured at HEAD on a freshly built artifact
(`c5dd6320`), because the `dist/` on disk predated three package-surface
deletions:

```text
declaration closure   stripped-but-referenced = 0, self-contained
packed exports        core 13 · guardrails 7 · ng-forms 2 · realtime 5 ·
                      events 9 — all shipped; shared skipped as private
core consumer         all six documented subpaths resolve from a real install
```

**Steps 1 and 5 of the former NEXT-SESSION note were already done, and the note
outlived them.** The `isDev` falsifier ran at `bc50d960` with the mandated 2x5
table filled by searching the whole declaration tree; it confirmed the SAME
mechanism as entity-map, which by the recorded scope limit CLOSES the mechanism
— do not investigate declaration tooling further. The packed gate was recorded
green at `f1e951ba` and is green again now.

**Step 3 lost a third of its subject.** `createFormSignal` no longer exists;
FORM-DEL (`b57ba293`) deleted it. The intent decision is over two symbols, not
three.

WHAT ACTUALLY REMAINS IN B1

1. ~~AST characterization scan for the value-space route.~~ **DONE — ZERO
   DEFECTS.** Run against the freshly built production declarations rather than
   source, which is the only place the property is observable. Seven value
   queries ship in core's declarations — `timeTravelHistory` in `time-travel`,
   and three each in `causal-runtime/confirmed-undo` and `confirmed-redo`. Every
   target is declared or imported from a file that declares it, consistent with
   the closure gate's `stripped-but-referenced = 0`; and neither `confirmed-*`
   file is reachable from a public entrypoint, so they are not public surface at
   all.

   `isDev` emits as `export declare const isDev: boolean` — the primitive
   inlined its literal type exactly as the fixture predicted, so `bc50d960`'s
   fix holds at HEAD. The value-space route is CLOSED with no repairs owed.

2. ~~Decide public intent for `isDev`, `HydrateMode`, and each scan hit.~~
   **BOTH DECIDED. The scan produced no hits.**

   - `isDev` — **NOT public. REMOVED at `f075f3b1`.** Zero consumers in the
     workspace, in any first-party package, or inside core itself; guardrails
     takes a `boolean` parameter and has its own `isDevEnvironment()`, and the
     demo uses Angular's `isDevMode()`. The third-party argument (an enhancer
     author wanting core's exact ngDevMode-then-NODE_ENV determination) was
     available and NOT accepted — for this symbol the rule requires evidence to
     keep, not evidence to remove. Both declarations went, not just the
     re-export, since `lib/constants` is not a published subpath and the
     survivor would have been an orphan of the class already queued here.
   - `HydrateMode` — **PUBLIC. Argument ACCEPTED, no repair owed.** The need is
     third-party-implementer level: `onHydrateDecision` is exported, so
     `HydrateDecisionEvent.mode` must be nameable and a marker processor's
     `hydrate` hook must be able to type its own parameter. Zero workspace usage
     is structurally incapable of refuting a TP need — that is exactly the level
     MUT-0 says demo evidence cannot answer. Its declaration already ships.

3. ~~Repair only intended public contracts.~~ **NOTHING OWED.** The value-space
   scan found no defects, and the one symbol whose declaration had been repaired
   (`isDev`, at `bc50d960`) turned out not to be public — so the repair was
   withdrawn with the export rather than kept.
4. Re-baseline `tools/api-baseline.json` — **ONCE, after B2 AND B3 both settle,
   immediately before the GATE B freeze.** Not at the end of B2: B3's
   authoring/realization package separation can move declaration locations and
   exported paths even where semantic APIs are unchanged, and the baseline
   records both. Regenerating after B2 would produce a baseline that B3
   invalidates, and a baseline that has to be regenerated twice is a baseline
   nobody trusts. Everything still pending — `bind()`, `requires`, the
   realization-facing `.with()` overload, `ENTITY_LOADER_READERS`, and the
   deletion-first utilities `deepEqual` / `toWritableSignal` / `asReadonly` —
   changes the surface it exists to record.

### The `isDev` episode, as a permanent methodology note

```text
Declaration correctness does not imply public survival.
bc50d960 proved isDev COULD ship correctly;
the intent audit proved it should not ship AT ALL.
```

So the sequence is `measure artifact -> decide public intent -> repair only
survivors`, never `broken declaration -> repair the public API`. The second
order silently converts a build-tool investigation into a decision to keep an
API, and it does so without anyone stating the decision.

The plugin-stage question is ANSWERED: the plugin emits the broken declaration
(`stripInternal` under `tsconfig.lib.prod.json`), not a later Nx/Rollup step.

1. Finish `stored()`/persistence atomic consequence semantics.
2. Add final heterogeneous atomicity forcing test.
3. Perform fresh correctness/complexity audit of HEAD.
4. Fix every release-blocking audit finding.
5. Freeze public API.
6. Add exhaustive public type/API tests.
7. Establish Angular/TS/Node compatibility matrix.
8. Audit built package output.
9. `npm pack` every publishable package.
10. Build clean external consumer projects from the tarballs.
11. Complete runtime/browser/SSR decisions and tests.
12. Run lifecycle/memory/churn tests.
13. Audit errors and persistence API semantics.
14. Complete README.
15. Complete signaltree.io docs.
16. Generate public API reference.
17. Build a production example/demo.
18. Complete package metadata/licenses/security audit.
19. Configure CI release gate.
20. Configure automated trusted publishing/provenance.
21. Generate final performance baseline.
22. Publish `1.0.0-rc.1`.
23. Test RC from genuinely external projects.
24. Fix RC packaging/DX/documentation issues only.
25. Freeze v1 public API.
26. Run clean-clone final release matrix.
27. Publish `1.0.0`.
28. Verify the published package and documentation from scratch.


## Studio tooling release preparation — 2026-09-11

- [x] **Restore legacy causal fixture addresses (`8409ec97`).** Following
  `7649aa65cc`, 20 spec files now model required `path`/`ownerPath` fields.
  A pre-edit audit classified 290 direct input records; a separately audited
  addendum covered six nested stub effects exposed at four diagnostic sites.
  Whole-owner scalar addresses, shared collection scope and inline member paths
  remain distinct. Native structural capture is tested with a member path;
  collection-path equality is asserted only for appropriate abstract fixtures.
  The settings/profile undo test retains distinct scopes and proves its
  applied-versus-redo premise before exercising the original outcome.
- [x] **Validate the fixture migration.** 269 tests across 25 suites pass,
  including a native entity-field rollback witness. Structural AST comparison
  preserves all 1,128 original assertions apart from required address metadata.
  Independent review found no new casts, type assertions or suppressions.
  The spec-type gate passes with 223 unrelated known diagnostics in 36 files;
  its baseline was not increased. This fixture commit changes no production code.
- [x] **Verify the prepared six-package source together.** An independent local
  checkout reconstructed the package release scope with a fresh frozen install
  and only the adapter esbuild importer added to the committed lockfile. All six
  production builds and strict installed-tarball consumers pass. The full release
  matrix passes 76/76, including the fixture migration and pending Studio package
  and release-tooling changes. This is combined source validation, not a claim
  that the fixture commit alone contains the complete release preparation.
- [x] **Checkpoint the Studio package release source (`7fa20637`).** The
  63-file package/release commit includes the minimal validated lockfile change.
  Uncommitted UI work and private evaluation material remain outside that commit.
- [x] **Close final-version documentation gaps (`b3a4a1bb`).** Preparing
  15.1.0-rc.1 changes the release-claims baseline from 14.1.1 to 15.0.0,
  exposing the previously unlisted `entityKeyedView` and
  `getConfirmedTurnRecords` members. The kernel README and changelog now
  describe their actual display/internal roles. Explicit 15.0.0 delta coverage
  passes for all 114 additions, alongside README API and numeric-claim checks.
  The failed preparation restored source versions before creating any tag.
- [x] **Prepare the immutable first Studio candidate (`31b030cd`).** Signed
  `v15.1.0-rc.1` was pushed after 76/76 local release gates and six-package
  installed-tarball validation. Independent verification matched all six hashes,
  package order, candidate commit and signed tag. The original Studio working
  tree was fast-forwarded with all 79 uncommitted files preserved byte-for-byte.
- [x] **Repair the declaration gate mutation (`44805555`).** Tagged CI run
  `34609297591` passed the normal gates but stopped at 64/65 mutation proofs.
  The old 168-to-169 documentation threshold mutation was inert against the new
  197-block artifact. The replacement strips JSDoc from the built kernel root
  declarations, reducing unique shipped documentation to 112 and triggering the
  unchanged 168-block floor. Focused clean/mutated checks, independent review,
  all 65/65 mutation proofs and all 76/76 release gates pass. No package runtime,
  public API, documentation baseline or production checker changed.
- [ ] **Publish the corrected Studio evaluation candidate.** The signed
  15.1.0-rc.1 tag remains immutable and UNPUBLISHED; no publisher was dispatched.
  A new 15.1.0-rc.2 candidate on the rc channel requires version authorization,
  canonical preparation, tagged CI and exact registry consumer verification.
  The broader Studio product backlog and human evaluation remain incomplete.
  Private application evaluation material is excluded from package releases.


## Studio commercial boundary — 2026-09-11

The user superseded the free-Studio interpretation and authorized separation:
public Apache-2.0 kernel/framework packages and existing integration primitives;
private paid Studio application, attachment/bridge, recording, sessions and
investigation queries. No pricing or new commercial license terms are set here.

- rc.1 is immutable and unpublished (tagged CI failed its stale mutation proof).
- rc.2 at b8455615 is immutable and unpublished. Run34615177142 was cancelled;
  no publisher was dispatched. Both Studio npm package lookups returned404.
- Source and tags were already pushed to the public repository. This separation
  protects future work; it is not history erasure or retroactive relicensing.
- All subsequent public releases must contain only kernel, angular, react, vue.
  The old six-package tag workflows must not be resumed.
- Private Studio retains the development and evaluation work and its existing
  attribution notices. Commercial licensing/distribution and any free tier are
  separate unresolved product decisions; workspace separation is not a paywall.


Commercial separation validation:

- Public source removal preserves all prior Studio development/evaluation files
  in the private workspace, with an exact original-source migration backup.
- Four-package builds and installed-tarball consumer checks pass. The private
  build exposed a root/adapter LeafDefinition declaration identity mismatch;
  extending the existing EntityMapMarker identity fix closes it. The new packed
  Angular leaf regression fails before and passes after under Bundler and Node16.
- Public gates pass77/77; mutation proofs pass66/66, including private-package
  rejection. No public runtime semantics or exports were changed.
- Private query31, adapter203 and app113 tests pass; strict consumers and all4
  runtime identity cases pass. Angular AOT and interactive preview pass. Private
  lint has0errors and96existing warnings. Initial panel516403bytes is below the
  unchanged600000-byte budget.
- Pricing, commercial legal terms, entitlement enforcement and private hosted
  distribution are not implemented by this workspace migration.

Commercial workspace separation is checkpointed at public commit82dbd57d and
private local commitbb72e07. The public branch contains no Studio implementation
source; the private workspace has no remote. Exact original working directories
and all79 prior dirty-file hashes remain preserved in its ignored migration
backup. Public npm publication remains paused; the prior six-package tags are
not usable release candidates. The active local preview now runs from the
private workspace at its existing localhost address.


### 2026-09-11 — synchronous transaction observation identity

User objective: correlate declared operation context with the exact transaction
without inferring causality from matching effects or notification timing.
The existing confirmed reader cannot distinguish a no-op invocation, identical
effects, reverse confirmation order, or reentrant notification delivery. The
notification-window candidate was rejected: transaction entry may flush earlier
queued events before allocating the new transaction ID.

Independent contract review and premise attack accepted the narrow observation
seam: activeTransactionContext() on /internals projects only the existing ambient
owner token and transaction ID during the synchronous callback. It is not a
write-target assertion or evidence of commit, and adds no state, listener, hot-path
write, root export, operation label, or realization semantics. A wrapper earns
association by reading at the entry of the callback passed to the actual tree.
Owner identity is ephemeral and must not be serialized. Async propagation and
automatic input-dependency attribution remain outside this contract.

Evidence: 18 focused observation tests; full kernel suite 273 files, 2,276 passed,
7 expected failures, 13 skipped, 1 todo. The prior confirmed reader regressions
also pass. Production ES2022 root-only consumer bundles before and after are
byte-for-byte identical: 101,523 minified bytes / 30,781 gzip bytes (esbuild
0.25.12, tslib external). This is a local development artifact, not an npm release.
