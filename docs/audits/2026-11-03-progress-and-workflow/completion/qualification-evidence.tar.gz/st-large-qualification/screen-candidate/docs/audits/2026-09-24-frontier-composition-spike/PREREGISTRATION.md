# Frontier composition spike — PREREGISTERED before implementation

Frozen 2026-09-24, **before any spike code exists**, so no property can be
adjusted after seeing a result. Recorded at the point where frontier leads the
bridgeable contract surface but has not earned selection.

## Why this exists

The bridge answered what it honestly could and stopped. It deliberately models
none of Link, batching, restoration, framework publication or retention, and it
cannot: PROTOCOL disclaims them. The question it therefore cannot reach is the
one that decides v16:

> Can the frontier mechanism keep its semantic advantage when connected to the
> actual SignalTree machinery the bridge could not model?

SignalTree has historically failed **at boundaries**, not inside a subsystem.
That is precisely what is untested so far.

## Status entering the spike

On the 203 bridge-carryable rows, after six bridge defects were found and fixed
and calibration came back with no distorting categories:

    path                held  violated  unsupported
    native               110        58           35
    incumbent-bridged    108        57           38
    frontier             177         0           26
    prepared             106        60           37
    draft                 69       112           22
    replay                43         0          160

Frontier is the only candidate that is both broad and violation-free on the
honestly bridgeable surface. Replay's zero violations are not comparable -- it
declines most of the surface. This is a LEAD, not a verdict: 177/0 was measured
through an instrument that produced six false candidate findings before it was
calibrated.

## The architecture constraint — the spike's main risk

Frontier must **replace one responsibility**, not sit beside the existing engine
as a second semantic system:

    public direct write
        -> existing semantic addressing / lifetime
        -> frontier ownership resolution        <- the candidate replacement
        -> existing coherent realization / publication
        -> Link / frameworks / restoration

It keeps PositionId, SubjectId, StructuralStore, mutation frames,
PathNotifier/publication and framework-native realization. It replaces the
baseline-compensation / overlap-decision responsibility.

> **If the spike ends up maintaining two sources of truth, that is NEGATIVE
> evidence and is to be reported as such, not engineered around.**

This is the same trap the draft adapter rule named: the finding is not allowed
to be quietly implemented away.

## Preregistered properties

Each is pass / fail / unsupported-with-reason. `unsupported` is never a pass.

    F1 overlapping pending scalar writers
       P1 writes x,y; P2 writes y,z; all R8 reject/confirm orders
       -> settles correctly, with NO unnecessary refusal

    F2 later ordinary/external truth over an older pending contribution
       later write at the same location
       -> later truth survives
       -> settling the older contribution does not resurrect or clobber it

    F3 pending-created entity lifetime  (the case draft could not do)
       P1 creates S1; P2 edits S1
       -> shared-live semantics actually work
       -> settling either contribution preserves valid dependent truth

    F4 structural topology
       add / remove / rekey, plus a new lifetime at a freed key
       -> SubjectId lifetime stays correct
       -> no key-based retargeting

    F5 Link / L16                      (unmeasurable through the bridge)
       pending contribution on x, unrelated y changes
       -> unrelated outbound progress continues
       -> no fabricated mixed snapshot is ever sent
       -> only a DEMONSTRATED dependency may hold

    F6 batching / deferred context
       transaction / external / restoration across deferred execution
       -> semantic classification survives scheduling

    F7 restoration
       later authoritative truth arrives after an authored contribution
       -> undo/rollback never erases later truth

    F8 L15 retention                   (unmeasurable through the bridge)
       after the obligation ends:
       -> active correctness state is reclaimed
       -> diagnostic retention is optional and explicitly bounded

    F9 publication
       settlement emits only coherent snapshots
       -> no intermediate torn state through the real notifier/framework path

F5 and F8 are the two the bridge structurally could not reach (9 Link rows and
41 confirmedCount rows). They are the point of the spike, not an extra.

## Order of execution — and why it is NOT F3 first

    PHASE 0  DECISION PROBE     F1 -> F5          <- run this first
    PHASE A  ownership is real  F3, F2, F4
    PHASE B  ownership composes F6, F7, F9
    PHASE C  no permanent baggage  F8

The natural instinct is F3 first, because it is the best pure integration test:
it forces the candidate through real SubjectId, StructuralStore, entity lifetime
and field ownership, and an F5 failure before ownership is stable is ambiguous
between frontier being wrong, the integration being incomplete, the Link handoff
being wrong, and publication timing being wrong.

That reasoning is correct for PROVING the architecture. It is the wrong order
for DECIDING WHETHER TO BUILD IT, and that is the open question.

Reason: the measured value of the structural rows is low. Of the 58 contract
violations frontier fixes, 48 are rekey scenarios with two or three
simultaneously-pending operations -- 40 of them "three pending rekeys" alone.
That is a pathological pattern, not an application pattern. The property with
real user value is F5, the tree-wide Link hold, which is everyday-path and
entirely unmeasured.

So what is PROVEN is low-value and what is HIGH-VALUE is unproven, and the order
should resolve that asymmetry first.

F1 and F5 are both purely SCALAR. F5 needs scalar ownership plus Link; it does
not need entity lifetime, SubjectId or StructuralStore, which is what makes F3
expensive. F1 supplies exactly the control that disambiguates an F5 failure: if
F1 holds and F5 fails, the failure is in ownership-to-Link composition and not in
ownership itself. The diagnostic argument is therefore satisfied without first
building structural ownership for the exotic-rekey family.

KILL CONDITION. If F5 fails after F1 holds, STOP. Frontier's remaining
demonstrated value is 58 exotic rekey rows, which does not justify replacing a
working ownership mechanism in a GA product. Phases A-C are not attempted.

## What would make frontier EARNED

All of the following, together. Any one failing sends it back:

1. converts the known unnecessary refusals into correct settlements
2. preserves every current safety property
3. passes structural lifetime cases NATURALLY, not via presence guards
4. removes or materially narrows the global Link hold
5. requires no retained per-write history after obligations end
6. preserves coherent publication
7. does not require developers to stop using normal direct writes
8. is SIMPLER in semantic exceptions than the current compensation machinery

Criterion 8 is a judgment, so it is decided against a count, not a feeling --
and the count separates two categories, because they are not the same thing:

    MECHANISM RULES  rules intrinsic to the ownership model, e.g.
                     "the latest surviving contribution determines the
                     visible value"
    PATCH RULES      conditionals whose only purpose is repairing an
                     interaction or edge case, e.g. "...unless a later pending
                     writer overlaps, except the external versioned case,
                     except rekey collision, except..."

Ten lines of general ownership machinery can be mechanically larger and
semantically SIMPLER than five scattered compensating guards. So the comparison
is over:

    number of semantic concepts
    number of exception branches
    number of cross-subsystem special cases
    number of retained state classes

and explicitly NOT over raw lines of code.

## Rules for running this

- Preregistered properties are frozen. A property discovered mid-spike is
  recorded as NEW and reported separately; it never retroactively joins this
  list.
- A spike defect is classified as a spike defect before any result is reported
  as architecture evidence. Six bridge defects were found this way; the same
  discipline applies here and the prior should be that more exist.
- The incumbent is a REFERENCE MEASUREMENT, not an oracle. It violates 58 of the
  frozen contract's own cases. Expected behaviour comes from the contract.
- No aggregate score. Per-property verdicts only.
- Verdicts are exit codes, never greps of output.

---

## Naming — DECIDED: `transact()` stays

Settled by the owner 2026-09-24. `speculate()` was considered seriously and is
arguably more descriptive of live-until-settled semantics -- `transact()` carries
a database implication (writes hidden until commit) that is the inverse of this
model. It is not adopted. The vocabulary was consolidated onto `transact()` this
session and shipped in 15.3.0, and no rename is worth a second breaking change
to the same API.

`contribution`, `owner`, `frontier` and `disposition` remain INTERNAL
vocabulary. This is closed; it is not to be reopened by a spike result.

---

# OWNER-SEAM-0 — scoped 2026-09-24, no production commitment

Scopes the plumbing each owner-resolution candidate needs, after OWNER-KEY-0
showed neither populates itself for free.

## Candidate B is far smaller than OWNER-KEY-0's failure implied

The prerequisite failed because a write registers no dependency node. But the
reason is not that the write path LACKS the node -- it is that the write branch
simply never calls anything with it. In `location-runtime.ts` the callable is
one function closing over one `node`:

    const location = markTreeCell(function (value) {
      if (arguments.length === 0) {
        trackDependency(node, token);   // READ branch uses node
        return read();
      }
      binding.replace(value);           // WRITE branch: node IS in scope,
                                        // nothing is called with it
    });

`binding.notify` in the same closure already does `node.version += 1;
notifyDependents(node)`. So the node is in lexical scope on both branches at
every site.

    DependencyNode creation sites in location-runtime.ts:  3
    sites where the write path lacks the node:             0
    files touched:                                         1

Entity field leaves are covered by the same seam rather than needing separate
structural plumbing: OWNER-KEY-0 showed `A.score()` registers dependency nodes,
which means entity fields already ARE locations on this machinery. The seam sits
at the location layer, which is the universal one.

## Candidate A pays a permanent-metadata cost B does not

A needs a durable `DependencyNode -> PositionId` mapping: new metadata per
location, allocated on creation, with an explicit cleanup obligation at subject
retirement.

That collides with the hard criterion. v15 earned whole-lifetime forgetting, and
a registry that outlives retired subjects would REGRESS a hard-won property, not
merely add implementation work.

B has no equivalent exposure. Ownership keyed directly by node can live in a
`WeakMap<DependencyNode, owner>`, so when a subject retires and its nodes become
unreachable the frontier entries disappear with them. Zero-residue is structural
rather than a cleanup path that must be written, tested and kept correct.

    criterion                         A                         B
    new permanent identities          one per location          none
    translation steps                 node -> position -> turn  node -> owner
    cleanup at retirement             explicit, must not leak   automatic
    subject/key-reuse special cases   required                  none (F3-B, D)
    production touchpoints            registry + write + retire 3, one file

## Recommendation

**Candidate B**, on the criteria as written: fewer permanent identities, fewer
translation steps, fewer special cases, cleaner cleanup. OWNER-KEY-0's
structural result independently supports it -- the kernel already exposes a
subject anchor node plus distinct leaf nodes, which is the identity a frontier
wants, so nothing has to reconstruct `(SubjectId, leaf)`.

UNMEASURED, and not to be asserted: the runtime cost of registering ownership on
every write. DEPENDENCY-1's timings were too noisy to use and this seam sits on
the hottest path in the kernel. A real isolated benchmark is required before
adoption, and the zero-owner case must stay free.

## Standing constraint

Implement only enough of B to make F3 real, then run F5 IMMEDIATELY. If F5 shows
no meaningful independent-progress gain, stop and reassess rather than
continuing to refine ownership. The ownership model is not the deliverable; the
Link/L16 behaviour is.

---

# OWNER-SEAM-1 — the answer is NO for B, and it REVERSES the recommendation

Question: can `{node, semanticOwner}` meet at the existing mutation boundary
without new global hot-path coupling?

## Two corrections to OWNER-SEAM-0 accepted first

Candidate A does NOT require durable per-location metadata with explicit
retirement cleanup. `WeakMap<DependencyNode, PositionId>` works: the PositionId
already exists, the mapping is weak, and a dead node drops its entry. A also
needs no key-reuse special cases -- that flaw belonged to ADDRESS matching, not
to node->position mapping. The retirement criterion therefore does NOT decide
between them, and OWNER-SEAM-0 overstated B's advantage on exactly the criterion
it called decisive.

B is also not cleanup-free: settlement needs the reverse relation
`P1 -> {nodeX, nodeY, subjectAnchor}` so claims can be released. That is
transient correctness state and it does require terminal cleanup.

## The finding

**The entire write-to-transaction delivery path speaks PositionId, not
DependencyNode.** PathNotifier's payload carries `positionIds`, and the
transaction runtime builds turns from `positionIds` (transactions.ts:158, 687,
710). Transactions already receive writes this way.

So B's real cost is not obtaining the node -- it is that the boundary which
already delivers writes to the transaction layer does not speak in nodes. B
would need either the notifier payload extended to carry nodes, which changes a
measured hot path, or an ambient current-owner consulted per write.

**The kernel already tried the ambient mechanism and rejected it**
(intrinsic-mutation.ts:18-22):

> "A first fix short-circuited on a process-wide installed-observer count. It
> MEASURED WELL but it is the wrong ownership boundary: one observer installed
> anywhere puts the probe back on every unrelated tree in the process. Pay for
> use belongs at the smallest practical boundary."

CORRECTED SCOPE of that evidence. What was rejected is a PROCESS-WIDE
installed-observer gate, where one observer anywhere imposed work on unrelated
trees. That establishes a design rule -- pay-for-use belongs at the smallest
practical boundary -- and is strong evidence against GLOBAL AMBIENT solutions.
It is NOT a blanket falsification of every possible B implementation, and this
file should not claim the kernel already tried the exact shape B needs.

The accurate statement: B would require changing the existing write->transaction
boundary to carry node/owner information, or introducing another owner-context
seam. The existing observer boundary is per-leaf and pay-for-use, and a
transaction cannot pre-register on leaves it has not yet seen, so B cannot ride
it unchanged.

## Revised recommendation: Candidate A

Not because B's identity story is wrong -- OWNER-KEY-0's subject-anchor result
still makes node identity the natural ownership key -- but because A joins the
captured read identity to the stream the transaction layer ALREADY consumes,
with one weak mapping and no hot-path change:

    captured DependencyNode
      -> WeakMap<DependencyNode, PositionId>     <- the only new thing
      -> existing positionIds already on the turn
      -> owner

B's elegance was real but it was measured against the wrong cost. The seam is
not three lines in one file; it is a new ambient ownership channel on the
hottest path, of the exact kind this kernel already removed on measurement.

**Candidate A: LEADING. Neither selected.** The remaining unknown for A is
whether a node can be mapped to its PositionId at creation, where both are in
scope -- unverified, and the next thing to check.

---

# OWNER-SEAM-2 — outcome B for scalar leaves; entity/anchor coverage UNVERIFIED

Question: at what construction boundary, if any, are the stable DependencyNode
and its correct PositionId simultaneously available?

## Verified: scalar leaves are outcome B, one call boundary apart

Two existing sites already hold what the mapping needs, with NO signature
changes and no new subsystem:

    location-runtime.ts createCell   `location` and `node` are both in scope
                                     (the node lives in the location's closure)

    signal-tree.ts  (leaf, path, positionIds, ..., registry, address)
                                     receives the SAME Location object as `leaf`
                                     together with its positionIds, and already
                                     calls defineNodeAddress(leaf) and
                                     defineOwnedPositionIds(leaf, positionIds)

So the join is two weak writes at sites that already have both objects:

    createCell        NODE_OF.set(location, node)
    leaf construction POSITIONS_OF_NODE.set(NODE_OF.get(leaf), positionIds)

That is materially smaller than "new registry plumbing", and it is weak-keyed,
so retired nodes drop their entries without a cleanup path.

## NOT VERIFIED, and it is the part that decides whether A solves F3

DEPENDENCY-1F established that the identities frontier needs are THREE:

    scalar leaf        verified above
    entity field leaf  UNVERIFIED
    subject anchor     UNVERIFIED

Entity positions are allocated separately at `entity-signal.ts:778`, not through
the leaf-construction path inspected above, so entity field leaves and the
subject anchor may follow outcome C (independent construction boundaries) or
outcome D (node without PositionId, or PositionId without node). OWNER-KEY-0
showed entity fields DO have DependencyNodes; whether those nodes reach a
PositionId at any shared construction boundary is simply not established here.

**If only scalar cells map cleanly, A has not solved F3.** F3 is a structural
property and its dependency is on a pending-created SUBJECT, so the anchor and
field identities are the ones that matter. This must be measured before A is
selected, not assumed from the scalar result.

## Non-vacuity controls required before adopting any mapping

A WeakMap being weak does not make the MAPPED POSITION semantics
lifetime-correct. Recreate the DEPENDENCY-1F discriminators against the mapping
itself:

    key reuse   old A.score node -> position_old
                remove old A, create fresh A
                fresh A.score node -> position_fresh
                REQUIRE node_old != node_fresh
                AND position_old must not resolve the fresh subject's ownership

    rekey       A -> B, same node
                mapping still names the same semantic position/lifetime,
                with no remap keyed by business key

## Cost model, if the shape holds

    ordinary write, no capture   zero new lookup cost
    location creation            one weak registration
    transaction with reads       one lookup per DISTINCT captured node

That is a healthier model than adding work to every mutation, which is what B
would have required. No benchmark until the shape is established.

---

# CANDIDATE STATUS — frozen 2026-09-24, before the C spike

    A  node -> PositionId
       FALSIFIED for structural ownership. Entity fields collapse to one
       collection-level position (OWNER-SEAM-2B), destroying leaf, subject and
       lifetime separation.

    B  node-keyed frontier + write-site owner context
       VIABLE but invasive. Retained as fallback. Needs owner context on the
       hot write path, which the existing write->transaction boundary does not
       carry.

    C  node -> lossless semantic identity -> existing effect owner
       PROMOTED TO IMPLEMENTATION SPIKE. **Not selected.**

"C leading on both halves" overstated it and is withdrawn. C has enough evidence
to EARN implementation; its decisive join equality is the first thing that
implementation must prove, not something already shown.

## The two gates the C spike must clear FIRST

Both were preregistered and NEITHER has passed.

    ROW 8 EQUALITY  the semantic identity derived from the TurnEffect must
                    EQUAL the identity bound to the captured anchor node.
                    OWNER-KEY-1 half 2 only showed BOTH EXIST and are separately
                    stable. Equality was untestable with no binding to derive a
                    key from.

    SCALAR ROW      x node <-> the effect position for x. Unmeasured entirely.

## Scope limit for the spike

Three namespaces only. No generalized semantic-identity framework, no tagged
union forced over every fact, no public API:

    scalar            DependencyNode -> PositionId
    subject existence DependencyNode -> SubjectId
    entity leaf       DependencyNode -> SubjectId + scoped leaf segments

The transaction side normalizes existing TurnEffects into those same three
classes. No display path, no business key, and no reverse inference participates
in owner identity at any point.

ROW3b, though exploratory rather than preregistered, is why this is worth
building: reading `A.score` captures the subject ANCHOR as well as the leaf, so
"P2 depends on S1 existing" falls out of ordinary read capture instead of
needing a separate existence detector.

---

# STATUS AFTER F5 — C earns a production-integration track

F5 proved both sides at once: more progress without less safety, with a mutant
showing the dependency edge is what controls the behaviour.

    CONTROL    x held   y held
    CANDIDATE  x held   y progresses
    DEPENDENT  x held   dependent y held
    MUTANT     edge removed -> dependent y escapes

## The old proxy is now falsified in three directions

Not a collection of edge cases -- three independent failures of ONE mechanism,
which is what justifies DELETING it rather than layering C beside it:

    F1  overlap without dependency    -> blocks safe settlement
    F3  dependency without overlap    -> misses unsafe settlement
    F5  unrelated source, same tree   -> blocks safe outbound progress

## Hard production invariant, earned from a safety failure

> Ownership must become visible ATOMICALLY with the authored write, before any
> consequence can test eligibility.

The first candidate run leaked speculative `x` because ownership was registered
after the flush. Anything asynchronous or post-flush is structurally unsafe, and
it fails in the dangerous direction rather than the conservative one.

## THREE mandatory gates before C is integration-ready

An earlier note listed two and demoted the third to a caveat. That was wrong:

    1. F5-C whole-source control        link(root) may legitimately stay held
    2. entity-leaf semantic binding     SubjectId + scoped leaf segments
    3. KERNEL-NATIVE ENFORCEMENT        F3 and F5 both applied policy at
                                        harness level, so the model and policy
                                        are proven but the real settlement and
                                        consequence machinery implementing them
                                        is NOT

Gate 3 is not optional and is not a footnote. Nothing so far shows the kernel
itself enforces any of this.

## Then the normal hardening sequence, not more architecture discovery

    production-native C mechanism -> mutation tests / ablations -> retention and
    cleanup -> hot-path benchmark -> full semantic suite -> framework and app
    validation

No further search for prettier models unless one of the three gates breaks C.

---

# GATE 1 RESTATED — emission footprint, not read capture

The F5-C failure is a CONCEPTUAL BOUNDARY, not a missing feature. The wrong fix
would be making branch reads capture descendant leaves: that distorts the
reactive dependency model to serve Link, and manufactures reads, nodes and
O(tree-size) work at Link registration.

Three footprints, ONE semantic identity vocabulary, three different truthful
sets:

    READ FOOTPRINT       what a computation consumed    -> dependency edges
    OWNERSHIP FOOTPRINT  what a pending turn owns       -> settlement authority
    EMISSION FOOTPRINT   what a consequence would expose-> outbound eligibility

For a scalar these coincide trivially. For a branch they do not, and that is
correct rather than a defect to repair.

    Gate 1  OPEN -- requires consequence EMISSION FOOTPRINT, not dependency-read
            capture.

## What Link's existing machinery does and does not provide

MEASURED. Link advances scalar and branch sources incrementally through
`internals/source-mutation.ts`: `relativeSourceAddress(...)` resolves an
incoming mutation's address relative to the source, and
`applyAtRelativePath(previous, segments, value)` patches it into the eligible
value. The projection starts from one `read()` and patches thereafter.

So Link NEVER enumerates the leaf set of a branch source. An emission footprint
by enumeration is therefore not derivable from what exists, which is consistent
with the warning against building it by walking and reading.

Link's entity egress is already SUBJECT-KEYED -- `EntityEgressProjection`, kept
that way explicitly because "Row[] carries no identity, and a rekey moves an
address without touching the payload". `StructuralEffect` and `EntityTopology`
in source-mutation.ts are likewise keyed by `subject`. So the egress path
already speaks part of C's vocabulary.

## HYPOTHESIS for EMIT-FOOTPRINT-0 — unverified, do not build on it yet

Enumerating what a source WILL emit may be the wrong direction. The inverse
needs no enumeration:

    eligible(source) := no OPEN contribution owns a write whose address
                        resolves WITHIN this source

Link already computes exactly that containment for every incoming mutation, via
`relativeSourceAddress`. The question becomes "does any owned identity lie
inside this source", which is answerable per pending write rather than per
source leaf, and is O(open writes) instead of O(tree size).

This is a HYPOTHESIS derived from reading the machinery, not a measurement. The
last several rounds each punished exactly this inference step, so EMIT-FOOTPRINT-0
must test it rather than assume it -- including the falsifier that omitting a
pending write from the containment check makes the branch wrongly eligible and
lets speculative state escape.

---

# HYPOTHESIS CORRECTED — it was worse than the code already run

The hypothesis recorded in 9e004d95 was:

    eligible(source) := no OPEN contribution owns a write inside this source

**That is insufficient, and it is wrong in the dangerous direction.** Take the
F5 dependent case: P1 pending x, P2 writes y = x() + 1, P2 CONFIRMS. No open
contribution then owns y, so the rule releases y -- while y still derives from
unresolved P1. It quietly collapses dependency back into ownership, which is the
exact conflation F3 and F5 were run to separate.

The correct predicate is the absence of unresolved OBLIGATIONS represented by
the source, from either origin:

    1. DIRECT OWNERSHIP   an open contribution owns truth this source represents
    2. DEPENDENCY         truth this source represents depends on an unresolved
                          contribution

## Row D is ALREADY DEMONSTRATED, by a different mechanism than I described

The F5 DEPENDENT arm IS Row D: P2 derives y from pending x, `p2.confirm()` runs,
and y is measured afterwards. It stayed held. The implementation keyed its edges
by CLAIMANT (`edges.add(tree.$.y)`), not by turn, so the blocker survived P2's
settlement. That is blocker tracking, not open-write scanning.

So the code that passed F5 was already the better mechanism, and the prose
committed afterwards described a weaker one. The discrepancy is recorded because
the write-up, not the experiment, was the defect.

## NOT demonstrated: blocker REMOVAL

    DEPENDENT before P1 settles   x=[]  y=[]
    DEPENDENT after  P1 settles   x=[1] y=[2]

y is released -- but NOT because the blocker was removed. Once `p1.confirm()`
makes `hasOpen(scopeKey)` false, the tree-wide hold lifts and eligibility is
never consulted at all. The blocker set still contains a stale edge for y, and
it is never cleared.

So if ANY other contribution were open at that moment, y would remain blocked by
an obligation that no longer exists. Blocker lifecycle is untested and the
current spike leaks, which in production is a hang rather than a leak of
speculative state. EMIT-FOOTPRINT-0 must test removal, not only installation.

## EMIT-FOOTPRINT-0 rows

    A scalar pending x                     link(x) blocked
    B independent branch                   link(other) progresses
    C whole branch {x,y}, x pending        blocked
    D dependent y, P2 CONFIRMED            still blocked   (already shown)
    E mutant: suppress P2->P1              y wrongly eligible
    F Link created AFTER P1 is pending     must SEED the blocker
    G rekey / key reuse                    blocker follows SubjectId, not the
                                           reusable business address
    H blocker REMOVAL on resolution        released, with another turn still
                                           open, so the hold is not doing it

Row F matters because incremental tracking learns only from future mutations; a
relationship created after a pending contribution starts ignorant of it. Seeding
at creation is O(open obligations), not O(tree size).

## Architectural rule to preserve

> Containment decides whether an event participates in a Link source. Semantic
> identity decides what obligation that event represents.

Address may answer "is this mutation inside this source". It may never become
the identity answering "which subject, lifetime or leaf owns this truth".

---

# EMIT-FOOTPRINT-0 — PREREGISTERED before implementation

## Gate 1 sharpened again

    A Link source must maintain the exact set of LIVE UNRESOLVED OBLIGATIONS
    represented by its current eligible payload.

That contains the emission-footprint idea and adds the lifecycle property the
F5 spike lacked. No stale blockers, no missing blockers.

## Why Set<LinkClaimant> is not enough

The spike held `blockedSources = { y }`. That proved F5 but cannot answer which
obligation caused the block, when it may be removed, or what happens when two
obligations block the same source. The representation must be:

    Link source -> Set<UnresolvedObligation>

## Obligation propagation, without retaining settled turns

    P1 owns x                  -> x carries O1
    P2 reads x, writes y       -> y inherits O1
    P2 CONFIRMS                -> y still carries O1
    P1 resolves                -> O1 terminal, cleared from x, y and anything
                                  that inherited it

P2 confirming does NOT clear O1, because P2 settling does not make its
dependency on P1 disappear. The unresolved ROOT obligation propagates; the chain
of settled turns does not have to stay alive. That is L15: retain correctness
responsibility, not historical machinery.

## Rows

    A  scalar pending x                      link(x) blocked
    B  independent branch, x pending         link(other) progresses
    C  whole branch {x,y}, x pending         blocked
    D  dependent y, P2 CONFIRMED             still blocked   (shown by F5)
    E  mutant: suppress the P2->P1 edge      y wrongly eligible
    F  Link created AFTER P1 pending         must SEED from live obligations,
                                             not reconstruct history
    G  rekey / key reuse                     blocker follows SubjectId, never the
                                             reusable business address
    H1 removal WITH unrelated open work      P3 pending z; resolving P1 releases
                                             y even though P3 is still open
    H2 MULTI-BLOCKER                         y derives from x (P1) and w (P4);
                                             resolve P1 -> y STILL blocked;
                                             resolve P4 -> eligible
    T  TRANSITIVE inheritance                P2: y=x+1 confirm; P3: z=y+1 confirm;
                                             link(z) blocked until P1 resolves,
                                             WITHOUT retaining P2

H1 is what proves release came from removing the actual blocker rather than from
`hasOpen(tree)` going false -- the exact confusion that made the F5 spike look
correct. H2 is what proves the representation is obligation-specific rather than
a boolean flag; its mutant drops all blockers when P1 resolves and must let y
escape while P4 is unresolved.

## Preserved rule

    Containment decides whether an effect participates in a Link source.
    Semantic identity decides which obligations that truth carries.

Address may answer the first. It may never become the identity answering the
second.
