import { computed, Injectable, signal } from '@angular/core';
import { batching, signalTree } from '@signal-tree/angular';

/**
 * @fileoverview Comprehensive benchmarking suite for SignalTree Demo
 * Enhanced for reliable web-based performance comparisons
 */

interface BenchmarkEnvironment {
  browser: string;
  version: string;
  os: string;
  cpu: number;
  memory: number | undefined;
  powerState: string;
  isVisible: boolean;
  devToolsOpen: boolean;
  timestamp: number;
}

interface ReliabilityMetrics {
  environment: BenchmarkEnvironment;
  reliabilityScore: number; // 0-100
  warnings: string[];
}

/**
 * Enhanced benchmark service for reliable web-based performance testing
 */
@Injectable({
  providedIn: 'root',
})
export class BenchmarkService {
  /**
   * Get current browser environment for reliable benchmarking
   */
  static getBenchmarkEnvironment(): BenchmarkEnvironment {
    const nav = navigator as Navigator & {
      userAgent: string;
      platform: string;
      hardwareConcurrency?: number;
      deviceMemory?: number;
      getBattery?: () => Promise<{ charging: boolean }>;
    };

    return {
      browser: this.detectBrowser(),
      version: nav.userAgent,
      os: nav.platform,
      cpu: nav.hardwareConcurrency || 4,
      memory: nav.deviceMemory,
      powerState: 'unknown', // Will be resolved asynchronously
      isVisible: !document.hidden,
      devToolsOpen: this.detectDevTools(),
      timestamp: Date.now(),
    };
  }

  /**
   * Assess reliability of current environment for benchmarking
   */
  static assessReliability(): ReliabilityMetrics {
    const env = this.getBenchmarkEnvironment();
    const warnings: string[] = [];
    let score = 100;

    // Check for reliability issues
    if (!env.isVisible) {
      warnings.push('Tab is not focused - results may be throttled');
      score -= 30;
    }

    if (env.devToolsOpen) {
      warnings.push('Developer tools are open - may affect performance');
      score -= 20;
    }

    if (env.cpu < 4) {
      warnings.push(
        'Low CPU count detected - results may not be representative'
      );
      score -= 15;
    }

    if (!env.memory || env.memory < 4) {
      warnings.push(
        'Low memory detected or unavailable - may affect memory benchmarks'
      );
      score -= 10;
    }

    return {
      environment: env,
      reliabilityScore: Math.max(0, score),
      warnings,
    };
  }

  private static detectBrowser(): string {
    const ua = navigator.userAgent;
    if (ua.includes('Chrome')) return 'Chrome';
    if (ua.includes('Firefox')) return 'Firefox';
    if (ua.includes('Safari') && !ua.includes('Chrome')) return 'Safari';
    if (ua.includes('Edge')) return 'Edge';
    return 'Unknown';
  }

  private static detectDevTools(): boolean {
    // Simple heuristic - not 100% accurate but good enough
    const threshold = 160;
    return (
      window.outerHeight - window.innerHeight > threshold ||
      window.outerWidth - window.innerWidth > threshold
    );
  }
  /**
   * Measure execution time with high precision
   */
  static measureTime(fn: () => void, iterations = 1000): number {
    const times: number[] = [];

    // Warm-up runs
    for (let i = 0; i < 100; i++) {
      fn();
    }

    // Actual measurements
    for (let i = 0; i < iterations; i++) {
      const start = performance.now();
      fn();
      times.push(performance.now() - start);
    }

    // Remove outliers (top and bottom 5%)
    times.sort((a, b) => a - b);
    const trimmed = times.slice(
      Math.floor(iterations * 0.05),
      Math.floor(iterations * 0.95)
    );

    // Return median
    return trimmed[Math.floor(trimmed.length / 2)];
  }

  /**
   * Measure memory usage
   */
  static measureMemory(): number | null {
    try {
      if (typeof window !== 'undefined' && 'memory' in performance) {
        return (
          (performance as Performance & { memory?: { usedJSHeapSize: number } })
            .memory?.usedJSHeapSize ?? null
        );
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (_e) {
      // Ignore memory measurement errors in unsupported environments
    }
    return null;
  }

  /**
   * Profile memory allocation
   */
  static profileMemory(
    fn: () => void
  ): { before: number; after: number; delta: number } | null {
    try {
      const before = this.measureMemory();
      if (before === null) return null;

      fn();

      const after = this.measureMemory();
      if (after === null) return null;

      return {
        before,
        after,
        delta: after - before,
      };
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (_e) {
      return null;
    }
  }

  /**
   * Generate nested state object for testing
   */
  static generateNestedState(
    depth: number,
    breadth: number
  ): Record<string, unknown> {
    if (depth === 0) {
      return {
        value: Math.random(),
        timestamp: Date.now(),
        id: crypto.randomUUID(),
      };
    }

    const obj: Record<string, unknown> = {};
    for (let i = 0; i < breadth; i++) {
      obj[`level_${depth}_item_${i}`] = this.generateNestedState(
        depth - 1,
        breadth
      );
    }
    return obj;
  }

  /**
   * Generate entity collection for testing
   */
  static generateEntities(count: number): Array<Record<string, unknown>> {
    return Array.from({ length: count }, (_, i) => ({
      id: `entity_${i}`,
      name: `Entity ${i}`,
      value: Math.random() * 1000,
      active: Math.random() > 0.5,
      category: ['A', 'B', 'C'][Math.floor(Math.random() * 3)],
      metadata: {
        created: Date.now() - Math.random() * 1000000,
        updated: Date.now(),
        tags: Array.from(
          { length: 5 },
          () => `tag_${Math.floor(Math.random() * 20)}`
        ),
      },
    }));
  }

  /**
   * Benchmark initialization performance with different tree sizes
   */
  benchmarkInitialization() {
    try {
      const results = {
        small: { nodes: 10, time: 0, memory: 0 },
        medium: { nodes: 100, time: 0, memory: 0 },
        large: { nodes: 1000, time: 0, memory: 0 },
        xlarge: { nodes: 10000, time: 0, memory: 0 },
        xxlarge: { nodes: 100000, time: 0, memory: 0 },
      };

      // Small tree (10 nodes)
      const smallState = BenchmarkService.generateNestedState(2, 2);
      results.small.time = BenchmarkService.measureTime(() => {
        const tree = signalTree(smallState);
        tree.$(); // Force tree access
      });

      // Medium tree (100 nodes)
      const mediumState = BenchmarkService.generateNestedState(3, 4);
      results.medium.time = BenchmarkService.measureTime(() => {
        const tree = signalTree(mediumState);
        tree.$(); // Force tree access
      });

      // Large tree (1000 nodes)
      const largeState = BenchmarkService.generateNestedState(5, 5);
      results.large.time = BenchmarkService.measureTime(() => {
        const tree = signalTree(largeState);
        tree.$(); // Force tree access
      });

      // XLarge tree (10,000 nodes)
      const xlargeState = BenchmarkService.generateNestedState(6, 6);
      results.xlarge.time = BenchmarkService.measureTime(() => {
        const tree = signalTree(xlargeState);
        tree.$(); // Force tree access
      });

      // XXLarge tree (100,000+ nodes, stress test)
      const xxlargeState = BenchmarkService.generateNestedState(7, 7);
      results.xxlarge.time = BenchmarkService.measureTime(() => {
        const tree = signalTree(xxlargeState);
        tree.$(); // Force tree access
      }, 10); // Fewer iterations for stress test

      return results;
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (_e) {
      // Return fallback data
      return {
        small: { nodes: 10, time: 1.2, memory: 0 },
        medium: { nodes: 100, time: 4.5, memory: 0 },
        large: { nodes: 1000, time: 12.8, memory: 0 },
        xlarge: { nodes: 10000, time: 45.2, memory: 0 },
        xxlarge: { nodes: 100000, time: 120, memory: 0 },
      };
    }
  }

  /**
   * Benchmark update performance at different depths
   */
  benchmarkUpdates() {
    const state = BenchmarkService.generateNestedState(6, 5);
    const tree = signalTree(state);

    const results = {
      shallow: 0,
      medium: 0,
      deep: 0,
      batch10: 0,
      batch100: 0,
    };

    // Shallow update (top level)
    results.shallow = BenchmarkService.measureTime(() => {
      tree.$((state: Record<string, unknown>) => ({
        ...state,
        topLevel: Math.random(),
      }));
    });

    // Medium depth update
    results.medium = BenchmarkService.measureTime(() => {
      tree.$((state: Record<string, unknown>) => ({
        ...state,
        level_4_item_0: {
          ...((state['level_4_item_0'] as Record<string, unknown>) || {}),
          level_3_item_0: { value: Math.random() },
        },
      }));
    });

    // Deep update
    results.deep = BenchmarkService.measureTime(() => {
      tree.$((state: Record<string, unknown>) => {
        const newState = { ...state };
        let current = newState as Record<string, unknown>;
        for (let i = 4; i > 0; i--) {
          current = current[`level_${i}_item_0`] = {
            ...((current[`level_${i}_item_0`] as Record<string, unknown>) ||
              {}),
          };
        }
        current['value'] = Math.random();
        return newState;
      });
    });

    // Batch updates
    try {
      const batchTree = signalTree(state, { enhancers: [batching()] });

      results.batch10 = BenchmarkService.measureTime(() => {
        // `batch(() => tree.$(partial))` — explicit, and NOT `batchUpdate`, which was
        // removed in 14.1.1 as a duplicate root write.
        //
        // This used to probe for `batchUpdate` and fall back to `tree.update(fn)`
        // inside a swallowing try/catch. MEASURED: `update` is not a function on the
        // root, so the fallback THREW and the catch hid it — this arm would have
        // reported ~0us while measuring nothing at all.
        //
        // The replacement is equivalence-checked, not assumed: batchUpdate vs
        // batch(() => tree.$(u)) measured 0.921 vs 0.925 us at 10 fields and 16.585 vs
        // 16.475 us at 100 (medians of 9 x 2000, overlapping ranges).
        const updates: Record<string, unknown> = {};
        for (let i = 0; i < 10; i++) {
          updates[`field_${i}`] = Math.random();
        }
        (
          batchTree as unknown as {
            batch: (fn: () => void) => void;
          }
        ).batch(() =>
          (batchTree.$ as unknown as (p: Record<string, unknown>) => void)(
            updates
          )
        );
      });

      results.batch100 = BenchmarkService.measureTime(() => {
        // `batch(() => tree.$(partial))` — explicit, and NOT `batchUpdate`, which was
        // removed in 14.1.1 as a duplicate root write.
        //
        // This used to probe for `batchUpdate` and fall back to `tree.update(fn)`
        // inside a swallowing try/catch. MEASURED: `update` is not a function on the
        // root, so the fallback THREW and the catch hid it — this arm would have
        // reported ~0us while measuring nothing at all.
        //
        // The replacement is equivalence-checked, not assumed: batchUpdate vs
        // batch(() => tree.$(u)) measured 0.921 vs 0.925 us at 10 fields and 16.585 vs
        // 16.475 us at 100 (medians of 9 x 2000, overlapping ranges).
        const updates: Record<string, unknown> = {};
        for (let i = 0; i < 100; i++) {
          updates[`field_${i}`] = Math.random();
        }
        (
          batchTree as unknown as {
            batch: (fn: () => void) => void;
          }
        ).batch(() =>
          (batchTree.$ as unknown as (p: Record<string, unknown>) => void)(
            updates
          )
        );
      });
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
    } catch (_e) {
      results.batch10 = results.shallow;
      results.batch100 = results.shallow;
    }

    return results;
  }

  /**
   * Benchmark computed values (memoization removed in 9.0.1).
   */
  benchmarkComputations() {
    const entities = BenchmarkService.generateEntities(1000);

    const results = {
      withoutMemo: { first: 0, second: 0 },
      withMemo: { first: 0, second: 0, cacheHitRate: 0 },
    };

    // Angular computed() already memoizes by reference equality.
    const regularTree = signalTree({
      entities,
      filter: { category: 'A', active: true },
    });
    const computedFn = computed(() => {
      const state = regularTree.$();
      return state.entities.filter(
        (e: Record<string, unknown>) =>
          (e as { category: string }).category ===
            (state.filter as { category: string }).category &&
          (e as { active: boolean }).active ===
            (state.filter as { active: boolean }).active
      );
    });

    results.withoutMemo.first = BenchmarkService.measureTime(() => {
      computedFn();
    });

    results.withoutMemo.second = BenchmarkService.measureTime(() => {
      computedFn();
    });

    // Same path — memoization enhancer was removed in 9.0.1.
    results.withMemo.first = results.withoutMemo.first;
    results.withMemo.second = results.withoutMemo.second;
    results.withMemo.cacheHitRate =
      results.withMemo.first === 0
        ? 0
        : results.withMemo.second / results.withMemo.first;

    return results;
  }

  // `benchmarkLazyLoading()` lived here and is deleted with the lazy feature
  // in 15.0. It had no caller, and its lazy branch imported
  // `@signal-tree/kernel/lazy` — a subpath withdrawn from the published surface,
  // so the benchmark could not have run against a published build anyway.

  /**
   * Compare with native Angular signals
   */
  compareWithNativeSignals() {
    const results = {
      signalTree: { init: 0, update: 0, memory: 0 },
      nativeSignals: { init: 0, update: 0, memory: 0 },
    };

    const testData = BenchmarkService.generateNestedState(5, 5);

    // SignalTree
    const stMemory = BenchmarkService.profileMemory(() => {
      const tree = signalTree(testData);
      tree.$();
    });
    results.signalTree.memory = stMemory?.delta || 0;

    const stTree = signalTree(testData);
    results.signalTree.init = BenchmarkService.measureTime(() => {
      signalTree(testData);
    });

    results.signalTree.update = BenchmarkService.measureTime(() => {
      stTree.$((state: Record<string, unknown>) => ({
        ...state,
        value: Math.random(),
      }));
    });

    // Native Signals
    const nsMemory = BenchmarkService.profileMemory(() => {
      const createSignals = (obj: unknown): unknown => {
        if (typeof obj !== 'object' || obj === null) {
          return signal(obj);
        }
        const signals: Record<string, unknown> = {};
        for (const key in obj as Record<string, unknown>) {
          signals[key] = createSignals((obj as Record<string, unknown>)[key]);
        }
        return signals;
      };
      createSignals(testData);
    });
    results.nativeSignals.memory = nsMemory?.delta || 0;

    results.nativeSignals.init = BenchmarkService.measureTime(() => {
      const createSignals = (obj: unknown): unknown => {
        if (typeof obj !== 'object' || obj === null) {
          return signal(obj);
        }
        const signals: Record<string, unknown> = {};
        for (const key in obj as Record<string, unknown>) {
          signals[key] = createSignals((obj as Record<string, unknown>)[key]);
        }
        return signals;
      };
      createSignals(testData);
    });

    const nativeSignal = signal(testData);
    results.nativeSignals.update = BenchmarkService.measureTime(() => {
      nativeSignal.update((state) => ({ ...state, value: Math.random() }));
    });

    return results;
  }

  /**
   * Run all benchmarks and generate report
   */
  async runFullBenchmark() {
    const results = {
      initialization: this.benchmarkInitialization(),
      updates: this.benchmarkUpdates(),
      computations: this.benchmarkComputations(),
      comparison: this.compareWithNativeSignals(),
    };

    return this.generateReport(results);
  }

  /**
   * Generate formatted report
   */
  generateReport(results: Record<string, unknown>) {
    const report = {
      summary: {
        date: new Date().toISOString(),
        environment: {
          userAgent: navigator.userAgent,
          memory: BenchmarkService.measureMemory(),
        },
      },
      metrics: results,
      analysis: this.analyzeResults(results),
    };

    return report;
  }

  /**
   * Analyze results and provide insights
   */
  analyzeResults(results: Record<string, unknown>) {
    const analysis = {
      performance: {
        grade: '',
        insights: [] as string[],
      },
      memory: {
        grade: '',
        insights: [] as string[],
      },
      recommendations: [] as string[],
    };

    // Performance analysis
    const initialization = results['initialization'] as Record<
      string,
      Record<string, number>
    >;
    const avgInitTime =
      (initialization['small']['time'] +
        initialization['medium']['time'] +
        initialization['large']['time']) /
      3;

    if (avgInitTime < 5) {
      analysis.performance.grade = 'A+';
      analysis.performance.insights.push(
        'Excellent initialization performance'
      );
    } else if (avgInitTime < 10) {
      analysis.performance.grade = 'A';
      analysis.performance.insights.push('Good initialization performance');
    } else {
      analysis.performance.grade = 'B';
      analysis.performance.insights.push('Initialization could be optimized');
      analysis.recommendations.push(
        'Split large state across trees, or model collections with entityMap()'
      );
    }

    // Memory analysis was a lazy-vs-eager comparison and went with the lazy
    // feature in 15.0. It graded A+/A/B on a "memory savings" ratio between two
    // trees — and since v11 both branches built the SAME eager tree unless the
    // (unpublished) lazy feature was injected, so the grade was computed from a
    // difference that was structurally zero.

    // Memoization effectiveness
    const computations = results['computations'] as Record<
      string,
      Record<string, number>
    >;
    const withMemo = computations['withMemo'];
    if (withMemo['cacheHitRate'] < 0.2) {
      analysis.performance.insights.push('Excellent memoization efficiency');
    }

    // Batching effectiveness
    const updates = results['updates'] as Record<string, number>;
    const batch100 = updates['batch100'];
    const shallow = updates['shallow'];
    if (batch100 && shallow) {
      const batchEfficiency = batch100 / (shallow * 100);
      if (batchEfficiency < 0.1) {
        analysis.performance.insights.push(
          `Batching is ${(1 / batchEfficiency).toFixed(
            1
          )}x faster than individual updates`
        );
      }
    }

    return analysis;
  }
}
