import { DecimalPipe } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  signal,
} from '@angular/core';
import {
  entityMap,
  signalTree,
  restoration,
  undoable,
} from '@signal-tree/angular';

/**
 * 14.0.0, running.
 *
 * The What's New page narrates this release; nothing on the site let you CALL
 * any of it. A capability audit that finds a gap, a release that closes it, and
 * a demo that never shows it is three quarters of a feature.
 *
 * The two benchmarks here run IN YOUR BROWSER on purpose. Every number the repo
 * publishes is Node 24 / V8 on one machine, and whether the ratios transfer to
 * a browser is explicitly unestablished in the research. A page that prints a
 * number from someone else's CI run asks for trust; one that measures on the
 * visitor's own machine does not need it.
 */

interface Row {
  id: string;
  label: string;
  done: boolean;
}

interface Measurement {
  hoistedMs: number;
  inlineMs: number;
  ratio: number;
  entities: number;
}

interface FanoutPoint {
  consumers: number;
  granularMs: number;
  wholeStateMs: number;
  ratio: number;
}

let seq = 0;
const nextId = () => `r${++seq}`;

@Component({
  selector: 'app-whats-new-14',
  standalone: true,
  imports: [DecimalPipe],
  templateUrl: './whats-new-14.component.html',
  styleUrl: './whats-new-14.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WhatsNew14Component {
  // ── Collections: prepend, active entity, id migration ────────────────────
  readonly tree = signalTree(
    {
      rows: entityMap<Row, string>({ selectId: (r) => r.id }),
      note: 'edit me',
      // Sealing counter. A collection mutation does NOT create a history entry —
      // only a tree/branch write does — so a bulk import needs a root write after
      // it to record one entry holding the finished result.
      imports: 0,
    },
    {
      enhancers: [
        // A cursor move is not an undo step — but that is no longer a
        // comparator over recorded transitions. `shouldSkip` was deleted in
        // 15.0: it recorded the transition and then asked whether the user
        // should perceive it, which is the decision `undoable()` makes BEFORE a
        // turn exists. The row operations below are designated; `select()` and
        // `clearSelection()` are not, which is the whole filter.
        restoration({ maxHistorySize: 50 }),
      ],
    }
  );

  constructor() {
    this.tree.$.rows.addMany([
      { id: nextId(), label: 'first', done: false },
      { id: nextId(), label: 'second', done: true },
    ]);
  }

  readonly rows = computed(() => this.tree.$.rows.all());
  readonly activeRow = computed(() => this.tree.$.rows.activeEntity());
  readonly canUndo = computed(() => this.tree.canUndo());
  readonly canRedo = computed(() => this.tree.canRedo());

  prepend(): void {
    undoable(() => {
      this.tree.$.rows.prependOne({
        id: nextId(),
        label: 'prepended',
        done: false,
      });
    });
  }

  /** Front, in the order given — `prependMany([a, b])` reads back as `a, b`. */
  prependBatch(): void {
    undoable(() => {
      this.tree.$.rows.prependMany([
        { id: nextId(), label: 'batch A', done: false },
        { id: nextId(), label: 'batch B', done: false },
      ]);
    });
  }

  append(): void {
    undoable(() => {
      this.tree.$.rows.addOne({ id: nextId(), label: 'appended', done: false });
    });
  }

  select(id: string): void {
    this.tree.$.rows.setActiveId(id);
  }

  clearSelection(): void {
    this.tree.$.rows.clearActiveId();
  }

  /** The other half of optimistic creation: adopt the id the server assigned. */
  adoptServerId(): void {
    const first = this.rows()[0];
    if (!first) return;
    this.tree.$.rows.changeId(first.id, `srv-${first.id}`);
  }

  /**
   * A bulk import is ONE undo step, and it needs no ceremony at all.
   *
   * This method used to pause recording, add 25 rows, resume, then perform a
   * synthetic "sealing" root write. Every part of that was wrong:
   *
   * - `pauseRecording()` was REMOVED in 14.1.1. It could only express "record
   *   nothing", never "one step", and it was a global mute that suppressed
   *   unrelated writers too.
   * - The comment justifying the seal claimed "collection mutations do not
   *   create history entries at all". That was RETRACTED — it came from
   *   asserting `getRestorationHistory().length` in the same tick as a `queueMicrotask`
   *   flush, without ever calling `undo()`. Collection mutations record fine.
   *
   * What actually makes this one step is that all 25 writes land in ONE
   * microtask, and history granularity is currently per-microtask. Which is
   * also the thing that needs fixing — that boundary is decided by whether a
   * caller happens to `await`, not by intent. See
   * docs/architecture/history-the-greenfield-target.md §4.
   */
  bulkImport(): void {
    for (let i = 0; i < 25; i++) {
      this.tree.$.rows.addOne({
        id: nextId(),
        label: `bulk ${i}`,
        done: false,
      });
    }
  }

  undo(): void {
    this.tree.undo();
  }
  redo(): void {
    this.tree.redo();
  }

  // ── ST2026, measured here ────────────────────────────────────────────────
  readonly predicateResult = signal<Measurement | null>(null);
  readonly measuring = signal(false);

  /** Hoisted to a stable reference — this is the fix ST2026 asks for. */
  private readonly notDone = (r: Row) => !r.done;

  async measurePredicate(entities = 1000): Promise<void> {
    this.measuring.set(true);
    await new Promise((r) => setTimeout(r, 0));

    const bench = signalTree({
      rows: entityMap<Row, string>({ selectId: (r) => r.id }),
    });
    bench.$.rows.addMany(
      Array.from({ length: entities }, (_, i) => ({
        id: `b${i}`,
        label: `row ${i}`,
        done: i % 3 === 0,
      }))
    );

    const PASSES = 200;

    // Hoisted: one predicate identity, so the WeakMap cache hits every time.
    const t0 = performance.now();
    for (let i = 0; i < PASSES; i++) bench.$.rows.where(this.notDone)();
    const hoistedMs = performance.now() - t0;

    // Inline: a NEW arrow per pass — exactly what a template allocates on every
    // change-detection cycle. Misses the cache, re-filters the collection.
    const t1 = performance.now();
    for (let i = 0; i < PASSES; i++) bench.$.rows.where((r: Row) => !r.done)();
    const inlineMs = performance.now() - t1;

    this.predicateResult.set({
      hoistedMs,
      inlineMs,
      ratio: inlineMs / Math.max(hoistedMs, 0.0001),
      entities,
    });
    this.measuring.set(false);
  }

  // ── Fan-out, measured here ───────────────────────────────────────────────
  readonly fanoutResult = signal<FanoutPoint[] | null>(null);
  readonly measuringFanout = signal(false);

  /**
   * Granular vs whole-state notification, same workload.
   *
   * Both arms hold the same data and take the same number of writes. The only
   * difference is what a consumer DEPENDS on: one leaf, or the whole state. The
   * second arm is what a store with one signal at the root gives you — every
   * consumer re-projects on every emission and filters downstream.
   */
  async measureFanout(): Promise<void> {
    this.measuringFanout.set(true);
    await new Promise((r) => setTimeout(r, 0));

    const points: FanoutPoint[] = [];
    const WRITES = 200;

    for (const consumers of [0, 100, 1000, 5000]) {
      const fields: Record<string, number> = {};
      for (let i = 0; i < 100; i++) fields[`k${i}`] = 0;

      // Arm 1 — consumers depend on ONE leaf each.
      // The population loop establishes k0; arbitrary Record keys remain unknown.
      const granular = signalTree({ ...fields } as Record<string, number> & {
        k0: number;
      });
      const granularConsumers = Array.from({ length: consumers }, (_, i) =>
        computed(() =>
          (granular.$ as Record<string, () => number>)[`k${i % 100}`]()
        )
      );
      granularConsumers.forEach((c) => c());
      for (let w = 0; w < 20; w++) granular.$['k0'].set(w);
      granularConsumers.forEach((c) => c());

      const g0 = performance.now();
      for (let w = 0; w < WRITES; w++) granular.$['k0'].set(w);
      granularConsumers.forEach((c) => c());
      const granularMs = performance.now() - g0;

      // Arm 2 — one signal holds everything; consumers project off the whole
      // object, which is the immutable-root shape.
      const root = signal<Record<string, number>>({ ...fields });
      const rootConsumers = Array.from({ length: consumers }, (_, i) =>
        computed(() => root()[`k${i % 100}`])
      );
      rootConsumers.forEach((c) => c());
      for (let w = 0; w < 20; w++) root.set({ ...root(), k0: w });
      rootConsumers.forEach((c) => c());

      const r0 = performance.now();
      for (let w = 0; w < WRITES; w++) root.set({ ...root(), k0: w });
      rootConsumers.forEach((c) => c());
      const wholeStateMs = performance.now() - r0;

      points.push({
        consumers,
        granularMs,
        wholeStateMs,
        ratio: wholeStateMs / Math.max(granularMs, 0.0001),
      });
      await new Promise((r) => setTimeout(r, 0));
    }

    this.fanoutResult.set(points);
    this.measuringFanout.set(false);
  }
}
