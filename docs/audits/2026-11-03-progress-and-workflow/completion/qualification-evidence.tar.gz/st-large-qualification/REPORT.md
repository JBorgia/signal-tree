# Finite selected-case functional qualification — stopped

Selected source remains `/private/tmp/st-v16-integration-candidate`, manifest `8bd6920bb81f676466a1c7d12d61395766694d881fcf2aa8c2dcdd35b5dce670`. This is single-candidate functional qualification, not an A/B memory, CPU or performance campaign. No workload assertions, timeouts, runtime or budget ceilings changed.

The previously completed I4 invocation selected exactly nine small neighbour-search cases (9 passed, two large cases skipped). It is reused without repetition. Both exact-cwd graph preparations passed separately within180s and resolved the expected kernel test wrapper; all four N2048 screen cases passed once in fresh workers. The screen changes only the two LARGE constants and is not original130k coverage.

Original130k partition:

| Case | First outcome |
| --- | --- |
| membership-observed setAll/replace/clear | exit0, exactly one selected pass, worker51344, unchanged source/dependencies, no survivors |
| replacement undo/redo | operational aggregate-owned-RSS abort; exit-15, worker51877, no completed case receipt |
| directed restoration jumps | not started; protocol stopped |
| restoration truncation | not started; protocol stopped |

The second invocation crossed the preregistered2GiB aggregate owned-process RSS ceiling: sampled2,201,042,944 bytes versus2,147,483,648. The observed host-free percentage minimum for that invocation was38%, above the12.5% floor. Host hw.memsize was34,359,738,368 bytes; free percentage comes from `memory_pressure -Q`. These are named operational safety policies, not library budgets or exact library-retained/peak memory measurements. No guard was raised and no run retried.

The abort followed verified worker launch and structured Vitest run-start/module-start events. There was **no case-start or case-result receipt**. It therefore does not identify the precise internal operation phase or establish an assertion failure, test timeout, OOM, or a universal130k limitation. The birth-matched supervisor sent SIGTERM, then SIGKILL to the remaining parent. No owned descendants remained. Both original test timeouts (60/120s), external360s cap and180s structured-no-progress guard were preserved.

Full source hashes before/after each invocation and final preservation checks found no drift; installed dependency identity hashes also remained unchanged. Final selected and screen manifests each checked3,127 files with zero mismatches. The five-package artifact seal is unchanged: `sha256-4e10ab551ba731818b9ab68941f7da013cd79c33920518c6eff2d8b501c8d012`.

`I7-PARTITION.json` gives exact source hashes, names and reusable original coverage. I7 must not repeat the nine small cases or passing original membership case merely to obtain whole-file totals; the aborted and unstarted cases remain unqualified. Every command, environment, setup result, first log, structured events, sampled telemetry, signal and final result remains under `runs/`. `STOP.json` prevents further protocol invocation. C0/R1 historical packets are untouched.

The initial graph controller and preregistration are preserved. Before the first test, `CONTROLLER-BOUNDARY-ADDENDUM.json` moved full manifest hashing out of the live telemetry loop, keeping it before/after invocation so it could not delay resource polling. No test was retried and no limits changed. Polling is sampled operational telemetry, not an allocation profiler.

Separate outstanding qualification failure: the integration artifact registry passed8/9; bundle budgets failed with unchanged ceilings. That failure is distinct from this resource-policy abort. Sole heavy slot is retained for Main's separately authorized installed workflow; no further large invocation is permitted in this protocol.
