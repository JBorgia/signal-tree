from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent
cost=json.loads((p/'cost-final/AFTER.json').read_text());assert cost['completedChildren']==84 and cost['validChildren']==84 and not cost['globalStop'] and not cost['sourceMismatches'] and not cost['inputMismatches']
def guarded(name,argv):
 subprocess.run(['python3',str(p/'guard.py'),name,'900',*argv],check=True)
 r=json.loads((p/'runs'/name/'RESULT.json').read_text());print(name,r,flush=True)
 assert r['exit']==0 and not r['guardReason'] and not r['sourceMismatches'] and not r['remainingOwned'],r
# Final exact artifacts were rebuilt after all checker mutation controls.
guarded('corrected-tarball-consumer',['node','tools/verify-tarball-consumer.mjs'])
subprocess.run(['python3',str(p/'final-registry.py'),'main'],check=True)
s=json.loads((p/'REGISTRY-MAIN-STATUS.json').read_text());assert not s.get('stop') and len(s['results'])==len(s['selected']),s.get('stop')
guarded('production-review-build',['node',str(p/'build-reviewed-demo.cjs')])
guarded('production-browser',['corepack','pnpm','exec','playwright','test','--config='+str(p/'browser.config.cjs')])
print('Main qualification complete',flush=True)
