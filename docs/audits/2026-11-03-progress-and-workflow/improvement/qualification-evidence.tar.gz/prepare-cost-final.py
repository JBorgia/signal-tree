from pathlib import Path
import json,hashlib,shutil,datetime,subprocess
p=Path(__file__).resolve().parent/'cost-final';p.mkdir(exist_ok=False)
old=Path('/private/tmp/st-v16-representative-cost');candidate=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate');before=p.parent/'before'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(p/'harness').mkdir()
for name in ['child.mjs','child-heap-v2.mjs','heap-quiescence.mjs']:shutil.copy2(old/'harness'/name,p/'harness'/name)
runner=(old/'campaign.py').read_text().replace('text=True,timeout=5).splitlines():','text=True,timeout=30).splitlines():')
(p/'campaign.py').write_text(runner)
shutil.copy2(old/'analyze.py',p/'analyze.py')
roots={'retained':before,'selected':candidate};sources={};artifacts={}
for arm,root in roots.items():
 manifest=p/(arm.upper()+'-MANIFEST.json')
 if arm=='retained':
  paths=subprocess.check_output(['git','ls-tree','-r','--name-only','-z','c2127a34b2fdd162ea1bd7bb2000f4815a2d8461'],cwd=candidate).decode().strip('\0').split('\0');m={n:sha(root/n) for n in sorted(paths)}
  manifest.write_text(json.dumps(m,sort_keys=True,indent=2)+'\n')
 else:shutil.copy2(p.parent/'MANIFEST.json',manifest)
 sources[arm]={'root':str(root),'manifest':str(manifest),'manifestSha256':sha(manifest)}
 entries={str(f.relative_to(root)):{'sha256':sha(f),'executable':f.stat().st_mode&0o111} for f in sorted((root/'dist/packages').rglob('*')) if f.is_file()}
 amap=p/(arm.upper()+'-ARTIFACTS.json');amap.write_text(json.dumps(entries,indent=2)+'\n');artifacts[arm]={'root':str(root),'manifest':str(amap),'manifestSha256':sha(amap),'files':len(entries)}
prior=json.loads((old/'BINDINGS.json').read_text())
receipts={'retained':{'command':'/private/tmp/st-v16-takeover-evidence/runs/post-mutation-build/COMMAND.json','result':'/private/tmp/st-v16-takeover-evidence/runs/post-mutation-build/RESULT.json'},'selected':{'command':str(p.parent/'runs/corrected-five-build/COMMAND.json'),'result':str(p.parent/'runs/corrected-five-build/RESULT.json')}}
for record in receipts.values():
 assert json.loads(Path(record['result']).read_text())['exit']==0
 for field in ['command','result']:record[field+'Sha256']=sha(Path(record[field]))
for n,h in prior['dependencies']['hashes'].items():assert sha(Path(n))==h,n
binding={'sources':sources,'artifacts':artifacts,'dependencies':prior['dependencies'],'buildReceipts':receipts,'beforeCommit':'c2127a34b2fdd162ea1bd7bb2000f4815a2d8461','afterCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=candidate,text=True).strip(),'armLabels':{'retained':'sealed pre-trial v16 candidate, NOT v15 production','selected':'three-trial batch and lint hygiene'},'baselineEquivalence':'BEFORE-ARTIFACTS.json matches prior final 193-file build; c212 documentation seal did not alter runtime artifacts','intent':json.loads((p.parent/'MEASUREMENT-PLAN.json').read_text())}
(p/'BINDINGS.json').write_text(json.dumps(binding,indent=2)+'\n')
schedule=json.loads((old/'SCHEDULE.json').read_text())
for row in schedule:
 row['argv'][2]=str(p/'harness'/Path(row['argv'][2]).name);row['argv'][3]=str(roots[row['arm']]/'dist/packages/kernel/dist');row['cwd']=str(p/'harness')
(p/'SCHEDULE.json').write_text(json.dumps(schedule,indent=2)+'\n')
reg=json.loads((old/'PREREGISTRATION.json').read_text());reg.update({'registeredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final singleton-corrected before/after v16 comparison; first d343 cohort preserved under cost/; owner accepts size, not runtime cost; no per-trial attribution, new SLO or favorable retries','bindingsSha256':sha(p/'BINDINGS.json'),'scheduleSha256':sha(p/'SCHEDULE.json'),'runnerSha256':sha(p/'campaign.py'),'harnessHashes':{n:sha(p/'harness'/n) for n in ['child.mjs','child-heap-v2.mjs','heap-quiescence.mjs']},'review':{'sourceOnly':'/private/tmp/st-v16-cost-source-attribution/INDEPENDENT-INVARIANT-REVIEW.md','localReview':'gate_review independently reviewed trial invariants and concrete diffs; no claimed measurements'}})
reg['operationalGuards']['processCensusTimeoutSeconds']=30
reg['analysisRules']['decision']='Before/after candidate comparison only. Keep persistent heap distinct; no runtime-cost waiver or point-bound change. Size is owner accepted; numerical gates remain reported.'
(p/'PREREGISTRATION.json').write_text(json.dumps(reg,indent=2)+'\n')
print(json.dumps({'packet':str(p),'rows':len(schedule),'sources':sources,'artifacts':artifacts},indent=2))
