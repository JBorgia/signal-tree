const { defineConfig } = require('/Users/jonathanborgia/code/signaltree/node_modules/@playwright/test');
const root='/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate';
module.exports=defineConfig({
 testDir:root+'/scripts/playwright', testMatch:['route-smoke.spec.ts','v16-candidate-workflow.spec.ts'],
 timeout:60000, retries:0, workers:1,
 reporter:[['list'],['json',{outputFile:'/private/tmp/st-v16-improvement/BROWSER-RESULTS.json'}]],
 outputDir:'/private/tmp/st-v16-improvement/browser-artifacts',
 use:{baseURL:'http://127.0.0.1:43217',browserName:'chromium',trace:'retain-on-failure',screenshot:'only-on-failure'},
 webServer:{command:'node scripts/playwright/serve-dist.mjs 43217',cwd:root,url:'http://127.0.0.1:43217',reuseExistingServer:false,timeout:30000}
});
