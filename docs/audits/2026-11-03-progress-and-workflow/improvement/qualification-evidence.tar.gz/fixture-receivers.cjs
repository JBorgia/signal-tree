const ts=require('/Users/jonathanborgia/code/signaltree/node_modules/typescript'),fs=require('fs'),cp=require('child_process');
for(const f of cp.execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim().split('\n')){
 if(!f.includes('.spec.'))continue;let s=fs.readFileSync(f,'utf8');const sf=ts.createSourceFile(f,s,ts.ScriptTarget.Latest,true),edits=[];
 function visit(n){if(ts.isCallExpression(n)&&ts.isCallExpression(n.expression)&&n.expression.expression.getText(sf)==='required'&&ts.isPropertyAccessExpression(n.expression.arguments[0])){
 const member=n.expression.arguments[0]; edits.push({start:n.expression.end,end:n.expression.end,value:'.call'});edits.push({start:n.expression.end+1,end:n.expression.end+1,value:member.expression.getText(sf)+(n.arguments.length?', ':'')});
 }ts.forEachChild(n,visit);}visit(sf);for(const e of edits.sort((a,b)=>b.start-a.start))s=s.slice(0,e.start)+e.value+s.slice(e.end);fs.writeFileSync(f,s);
}
