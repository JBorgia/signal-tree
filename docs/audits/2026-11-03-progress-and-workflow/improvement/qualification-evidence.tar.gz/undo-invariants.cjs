const ts=require('/Users/jonathanborgia/code/signaltree/node_modules/typescript'),fs=require('fs'),cp=require('child_process');
for(const f of cp.execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim().split('\n')){
 if(!f.endsWith('.ts'))continue;let s=fs.readFileSync(f,'utf8');if(!s.includes('requirePresent'))continue;
 s=s.replace(/^import \{ requirePresent \} from '[^']+';\n/m,'');
 function rewrite(s){const sf=ts.createSourceFile(f,s,ts.ScriptTarget.Latest,true);let nodes=[];function visit(n){if(ts.isCallExpression(n)&&n.expression.getText(sf)==='requirePresent'){nodes.push(n);return;}ts.forEachChild(n,visit);}visit(sf);for(const n of nodes.sort((a,b)=>b.pos-a.pos)){s=s.slice(0,n.getStart(sf))+rewrite(n.arguments[0].getText(sf))+'!'+s.slice(n.end);}return s;}
 fs.writeFileSync(f,rewrite(s));
}
fs.unlinkSync('packages/kernel/src/lib/internals/require-present.ts');
