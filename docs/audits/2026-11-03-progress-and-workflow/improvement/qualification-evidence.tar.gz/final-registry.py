from pathlib import Path
import subprocess,json,datetime,sys
p=Path(__file__).resolve().parent
names=[line.split()[0] for line in (p/'GATES.txt').read_text().splitlines() if line.strip()]
assert len(names)==87
mode=sys.argv[1] if len(sys.argv)>1 else 'main'
assert mode in ['self','main']
names=[n for n in names if n!='test:all' and (n.endswith(':self') if mode=='self' else not n.endswith(':self'))]
seal=json.loads((p/('STAGE-ARTIFACT-SEAL.json' if mode=='self' else 'CORRECTED-ARTIFACT-SEAL.json')).read_text())['seal']
status={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'artifactSeal':seal,'selected':names,'excluded':{'test:all':'Separate seven-project uncached receipts are listed in CORRECTED-TEST-STATUS.json; unchanged point-work failure remains binding. Combined invocation resource stop is preserved separately.'},'mutationScope':'Fresh lint gate outer proof; prior full proof is preserved under its own predecessor identity, not claimed fresh','results':[]}
for index,name in enumerate(names):
 run='registry-'+mode+'-'+str(index+1).zfill(2)+'-'+name.replace(':','-')
 status['running']=name;(p/('REGISTRY-'+mode.upper()+'-STATUS.json')).write_text(json.dumps(status,indent=2)+'\n')
 subprocess.run(['python3',str(p/'guard.py'),run,'900','node','tools/verify-gates.mjs','--release','--only='+name,'--artifact-integrity='+seal],check=True)
 result=json.loads((p/'runs'/run/'RESULT.json').read_text());status['results'].append({'gate':name,'run':run,**result});print(name,result['exit'],result['guardReason'],flush=True)
 (p/('REGISTRY-'+mode.upper()+'-STATUS.json')).write_text(json.dumps(status,indent=2)+'\n')
 if result['guardReason'] or result['sourceMismatches'] or result['remainingOwned']:status['stop']='Infrastructure/integrity/cleanup';break
 if result['exit'] and name!='bundle-budget':status['stop']='New baseline failure: '+name;break
status['running']=None;status['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(p/('REGISTRY-'+mode.upper()+'-STATUS.json')).write_text(json.dumps(status,indent=2)+'\n')
