from pathlib import Path
import subprocess,json,shutil,datetime
p=Path(__file__).resolve().parent;c=Path.cwd();node='/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node'
argv=['corepack','pnpm','nx','run-many','-t','build','--projects=kernel,angular,react,vue,solid','--skip-nx-cache','--parallel=1']
def build(name,sealfile):
 if (c/'dist').exists():shutil.rmtree(c/'dist')
 subprocess.run(['python3',str(p/'guard.py'),name,'900',*argv],check=True)
 r=json.loads((p/'runs'/name/'RESULT.json').read_text());assert r['exit']==0 and not r['guardReason'] and not r['sourceMismatches'] and not r['remainingOwned'],r
 seal=subprocess.check_output([node,'--input-type=module','-e','import {buildIntegrity} from "./scripts/publish-artifact-integrity.mjs";console.log(buildIntegrity(process.cwd(),["kernel","angular","react","vue","solid"]));'],text=True).strip()
 data={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceManifestSha256':r['sourceManifestSha256'],'seal':seal,'buildReceipt':str(p/'runs'/name/'RESULT.json'),'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};(p/sealfile).write_text(json.dumps(data,indent=2)+'\n');print(name,data,flush=True);return seal
stage=build('corrected-stage-build','STAGE-ARTIFACT-SEAL.json')
subprocess.run(['python3',str(p/'final-registry.py'),'self'],check=True)
s=json.loads((p/'REGISTRY-SELF-STATUS.json').read_text());assert not s.get('stop') and len(s['results'])==len(s['selected']) and all(r['exit']==0 for r in s['results']),s.get('stop')
final=build('corrected-five-build','CORRECTED-ARTIFACT-SEAL.json');assert stage==final,'Final rebuilt artifacts differ from restored source stage'
subprocess.run(['python3',str(p/'prepare-cost-final.py')],check=True)
with (p/'cost-final/campaign.log').open('x') as log:subprocess.run(['python3',str(p/'cost-final/campaign.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
with (p/'cost-final/analysis.log').open('x') as log:subprocess.run(['python3',str(p/'cost-final/analyze.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Final matched campaign complete',flush=True)
