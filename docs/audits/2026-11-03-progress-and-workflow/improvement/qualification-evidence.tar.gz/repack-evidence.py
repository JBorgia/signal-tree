from pathlib import Path
import json,hashlib,tarfile
p=Path(__file__).resolve().parent;d=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/docs/audits/2026-11-03-progress-and-workflow/improvement');old=json.loads((p/'EVIDENCE-INDEX.json').read_text());meta=json.loads((d/'ARCHIVE.json').read_text())
def cache(path):return any(part.startswith('nx-native-file-cache-') or part in ['node-compile-cache','jest_dx'] for part in Path(path).parts)
entries=[x for x in old['entries'] if not cache(x['path']) and x['path']!='EVIDENCE-INDEX.json']
notes={'draftArchive':meta,'removed':'Duplicated Nx native, Node compile and Jest caches only; all command/result logs, manifests, measurement samples, fixture outputs and exact artifact bytes retained','excludedCacheFiles':old['files']-len(entries)};(p/'ARCHIVE-PREPARATION.json').write_text(json.dumps(notes,indent=2)+'\n')
for name in ['repack-evidence.py','ARCHIVE-PREPARATION.json']:
 f=p/name;entries.append({'path':name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'executable':f.stat().st_mode&0o111})
entries.sort(key=lambda x:x['path'])
for item in entries:assert hashlib.sha256((p/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
index={'files':len(entries),'entries':entries,'excluded':old['excluded']+'; duplicated Nx native, Node compile and Jest caches'};(p/'EVIDENCE-INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
tmp=d/'qualification-evidence.compact.tar.gz'
with tarfile.open(tmp,'w:gz',compresslevel=6) as out:
 for item in entries:out.add(p/item['path'],arcname=item['path'],recursive=False)
 out.add(p/'EVIDENCE-INDEX.json',arcname='EVIDENCE-INDEX.json',recursive=False)
tmp.replace(d/'qualification-evidence.tar.gz');archive=d/'qualification-evidence.tar.gz';meta.update({'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries)+1});(d/'ARCHIVE.json').write_text(json.dumps(meta,indent=2)+'\n');(d/'EVIDENCE-INDEX.json').write_bytes((p/'EVIDENCE-INDEX.json').read_bytes())
print(json.dumps(meta,indent=2))
