# First bounded-batch comparison (c212 → d343)

This is the preserved first cohort, not the final singleton-corrected artifact. All 84 fresh child workloads passed their unchanged assertions. Before/after source, artifact and dependency checks have no mismatches. The command was `python3 campaign.py` in this packet, followed by `python3 analyze.py`; `PREREGISTRATION.json`, `BINDINGS.json`, `SCHEDULE.json` and each child COMMAND/stdout receipt bind the workload and artifact identity.

| Workload | Before wall ms | After wall ms | Before CPU ms | After CPU ms | Interpretation |
| --- | ---: | ---: | ---: | ---: | --- |
| bare | 57.279 | 47.371 | 117.662 | 105.368 | wall unresolved; CPU unresolved |
| point | 50.025 | 42.343 | 90.294 | 84.159 | wall unresolved; CPU unresolved |
| projection | 13.353 | 16.904 | 18.117 | 24.197 | wall unresolved; CPU unresolved |
| confirm | 22.666 | 28.667 | 35.222 | 46.844 | wall unresolved; CPU unresolved |
| rollback | 42.602 | 41.090 | 69.369 | 67.373 | wall unresolved; CPU unresolved |

The five independent samples per arm and separate two-sample before-arm A/A controls are fully reported in DISTRIBUTIONS.json and ALL-SCALAR-SAMPLES.csv. Under the registered rule, disjoint ranges alone are insufficient: a median change must also exceed observed same-arm variability. Every timing/CPU comparison is unresolved. This is a busy development host, not a production SLO or a newly sampled v15-production comparison.

heap-populated: live_minus_baseline_bytes median 17,746,672 → 17,757,704 bytes; selected-higher. These are whole-process post-quiescence heap deltas, not dominator attribution or per-row storage measurements.
heap-pending: pending_live_minus_idle_bytes median 1,028,904 → 1,031,832 bytes; unresolved. These are whole-process post-quiescence heap deltas, not dominator attribution or per-row storage measurements.

All 24 heap children cleared their sampled tree WeakRefs after teardown. This is finite evidence, not a universal no-leak claim. Persistent populated heap was not recovered. Independent review recomputed all 756 CSV metric rows and confirmed the generated classifications.

A source review identified an unnecessary empty repeated-subject Set for singleton packets. Its correction changes the measured artifact; any following cohort has its own source/build bindings. No sample here is discarded, retried or relabeled as a result for that correction.
