from pathlib import Path
import subprocess,sys,json
p=Path(__file__).resolve().parent
plan=[
 ('final-framework-tests',['corepack','pnpm','nx','run-many','-t','test','--projects=angular,react,vue,solid','--parallel=1','--skip-nx-cache','--maxWorkers=2']),
 ('final-demo-tests',['corepack','pnpm','nx','test','demo','--runInBand','--skip-nx-cache','--json','--outputFile='+str(p/'DEMO-TESTS.json')]),
 ('final-source-types',['corepack','pnpm','run','typecheck']),
 ('final-spec-types',['node','tools/check-spec-types.mjs']),
 ('final-lint',['node','tools/check-lint-budget.mjs'])
]
for name,argv in plan:
 subprocess.run([sys.executable,str(p/'guard.py'),name,'900',*argv],check=True)
 r=json.loads((p/'runs'/name/'RESULT.json').read_text());print(name,r,flush=True)
 if r['sourceMismatches'] or r['remainingOwned'] or r['guardReason']:raise SystemExit('Integrity/resource/cleanup stop')
