// Owner accepted production size. Override only budget diagnostics for this
// review build; preserve the committed production ceilings and all code options.
const { createRequire } = require('node:module');
const requireCandidate = createRequire('/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/package.json');
const { createProjectGraphAsync, readProjectsConfigurationFromProjectGraph, runExecutor } = requireCandidate('@nx/devkit');
(async () => {
  const root = process.cwd();
  const graph = await createProjectGraphAsync();
  const context = { root, cwd: root, isVerbose: false,
    projectsConfigurations: readProjectsConfigurationFromProjectGraph(graph),
    nxJsonConfiguration: JSON.parse(require('node:fs').readFileSync(root+'/nx.json','utf8')), projectGraph: graph };
  console.log('Production review build: owner-accepted size; budgets=[] override only; committed ceilings unchanged.');
  const results = await runExecutor({project:'demo', target:'build', configuration:'production'}, {budgets:[]}, context);
  let success = false;
  for await (const result of results) { console.log(JSON.stringify(result)); success = result.success; }
  process.exitCode = success ? 0 : 1;
})().catch(error => { console.error(error); process.exitCode=1; });
