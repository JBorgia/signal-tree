from pathlib import Path
import subprocess,json,re
p=Path(__file__).resolve().parent
plan=[('corrected-kernel-serial',['corepack','pnpm','nx','test','kernel','--skip-nx-cache','--maxWorkers=1'])]
for project in ['angular','react','vue','solid','react-reference']:
 plan.append(('corrected-'+project,['corepack','pnpm','nx','test',project,'--skip-nx-cache','--maxWorkers=2']))
plan.append(('corrected-demo',['corepack','pnpm','nx','test','demo','--skip-nx-cache','--runInBand','--json','--outputFile='+str(p/'CORRECTED-DEMO-TESTS.json')]))
results=[]
for name,argv in plan:
 subprocess.run(['python3',str(p/'guard.py'),name,'900',*argv],check=True)
 r=json.loads((p/'runs'/name/'RESULT.json').read_text());results.append({'run':name,**r});(p/'CORRECTED-TEST-STATUS.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r,flush=True)
 if r['guardReason'] or r['sourceMismatches'] or r['remainingOwned']:raise SystemExit('Resource/integrity/cleanup stop')
 if r['exit']:
  failures=re.findall(r'^ FAIL\s+(\S+)',(p/'runs'/name/'first.log').read_text(),re.M)
  if name!='corrected-kernel-serial' or not failures or set(failures)!={'src/lib/entity-granular-reactivity.spec.ts'}:raise SystemExit('New functional failure; inspect')
