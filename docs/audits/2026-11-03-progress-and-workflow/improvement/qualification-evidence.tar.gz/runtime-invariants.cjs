const ts=require('/Users/jonathanborgia/code/signaltree/node_modules/typescript');const fs=require('fs'),path=require('path');
const ds=JSON.parse(fs.readFileSync('/private/tmp/st-v16-improvement/lint-current-clean.json','utf8'));
// Replace unchecked assertions with checked private invariants. Existing supported
// inputs already require presence; failures now identify the violated invariant.
for(const entry of ds){
 if(!entry.filePath.includes('/packages/kernel/src/')||entry.filePath.includes('.spec.'))continue;
 if(!entry.messages.some(m=>m.ruleId==='@typescript-eslint/no-non-null-assertion'))continue;
 let text=fs.readFileSync(entry.filePath,'utf8');
 function rewrite(s){const f=ts.createSourceFile(entry.filePath,s,ts.ScriptTarget.Latest,true);let targets=[];function visit(n){if(ts.isNonNullExpression(n)){targets.push(n);return;}ts.forEachChild(n,visit);}visit(f);for(const n of targets.sort((a,b)=>b.pos-a.pos)){s=s.slice(0,n.getStart(f))+'requirePresent('+rewrite(n.expression.getText(f))+')'+s.slice(n.end);}return s;}
 text=rewrite(text);
 let rel=path.relative(path.dirname(entry.filePath),path.resolve('packages/kernel/src/lib/internals/require-present')).replaceAll('\\','/');if(!rel.startsWith('.'))rel='./'+rel;
 text=`import { requirePresent } from '${rel}';\n`+text;
 fs.writeFileSync(entry.filePath,text);
}
