from pathlib import Path
import json,hashlib,subprocess,shutil,os,tarfile,datetime
p=Path(__file__).resolve().parent;c=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate');node='/Users/jonathanborgia/.nvm/versions/node/v24.15.0/bin/node'
seal=json.loads((p/'CORRECTED-ARTIFACT-SEAL.json').read_text())['seal']
actual=subprocess.check_output([node,'--input-type=module','-e','import {buildIntegrity} from "./scripts/publish-artifact-integrity.mjs";console.log(buildIntegrity(process.cwd(),["kernel","angular","react","vue","solid"]));'],cwd=c,text=True).strip();assert actual==seal
owned={}
for root in [p/'runs',p/'cost/children',p/'cost-final/children']:
 for f in root.rglob('OWNED.json'):
  for v in json.loads(f.read_text()):owned[(v['pid'],v['birth'])]=v
ps={}
for line in subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,rss=,lstart='],text=True,timeout=30).splitlines():
 a=line.split()
 if len(a)>=8:ps[(int(a[0]),' '.join(a[3:]))]={'pid':int(a[0]),'birth':' '.join(a[3:]),'rssBytes':int(a[2])*1024}
live=[ps[k] for k in owned if k in ps]
(p/'FINAL-PROCESS-CENSUS.json').write_text(json.dumps({'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedPidBirthIdentities':len(owned),'remainingOwned':live},indent=2)+'\n');assert not live,live
review=p/'INDEPENDENT-REVIEW.md';s=review.read_text().replace('Final corrected-cohort interpretation and closure review are pending.','')
s+='''\n## Closure review\n\nNo new qualification blocker demonstrated. The reviewer verified 24 companion-control passes, 61/62 normal baseline passes with the numerical size failure retained under owner disposition, seven-project results with the single point-work failure, and 28 production-browser passes without skips/flaky/unexpected outcomes. The production configuration overrides only budgets=[], which does not establish committed-ceiling compliance. Artifact/source cohorts remain separate. HOLD for point work and runtime-cost acceptance is correct. CPU/most timing comparisons, persistent heap, the absolute work bound and fresh complete outer-mutation proof remain material limits.\n''';review.write_text(s)
# Store the actual qualified artifact bytes, without dependencies or caches.
art=p/'artifacts-final';shutil.copytree(c/'dist/packages',art/'packages')
shutil.copytree(c/'dist/apps/demo/browser',art/'demo-browser')
entries=[]
for root,dirs,files in os.walk(p):
 root=Path(root);rel=root.relative_to(p)
 dirs[:]=[d for d in dirs if d not in ['node_modules','.git','__pycache__','nx-cache','nx-data','npm-cache'] and not (root/d).is_symlink()]
 if str(rel)=='before':dirs[:]=[d for d in dirs if d=='dist'];files=[]
 if str(rel)=='before/dist':dirs[:]=[d for d in dirs if d=='packages'];files=[]
 for n in sorted(files):
  f=root/n;r=str(f.relative_to(p))
  if f.is_symlink() or r=='before-source.tar':continue
  entries.append({'path':r,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'executable':f.stat().st_mode&0o111})
entries.sort(key=lambda x:x['path']);(p/'EVIDENCE-INDEX.json').write_text(json.dumps({'files':len(entries),'entries':entries,'excluded':'Dependencies, caches, .git directories, baseline source tree/tar (reconstructible from c212 Git), and symlinks; baseline/final artifact bytes retained'},indent=2)+'\n')
d=c/'docs/audits/2026-11-03-progress-and-workflow/improvement';d.mkdir(exist_ok=True)
archive=d/'qualification-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as out:
 for item in entries:out.add(p/item['path'],arcname=item['path'],recursive=False)
 out.add(p/'EVIDENCE-INDEX.json',arcname='EVIDENCE-INDEX.json',recursive=False)
meta={'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries)+1,'artifactSeal':seal,'codeCommit':'fe18a8e1c1f3da42727341d6c6fa30a407c1461e'}
(d/'ARCHIVE.json').write_text(json.dumps(meta,indent=2)+'\n')
for src,name in [('QUALIFICATION.json','QUALIFICATION.json'),('cost-final/DISTRIBUTIONS.json','COST-DISTRIBUTIONS.json'),('cost-final/PREREGISTRATION.json','COST-PROTOCOL.json'),('cost-final/BINDINGS.json','COST-BINDINGS.json'),('INDEPENDENT-REVIEW.md','INDEPENDENT-REVIEW.md'),('EVIDENCE-INDEX.json','EVIDENCE-INDEX.json'),('PRODUCTION-DEMO-ARTIFACTS.json','PRODUCTION-DEMO-ARTIFACTS.json'),('FINAL-PROCESS-CENSUS.json','FINAL-PROCESS-CENSUS.json')]:shutil.copy2(p/src,d/name)
print(json.dumps(meta,indent=2))
