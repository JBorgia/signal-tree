
      import { signalState, patchState } from '@ngrx/signals';
      const store = signalState({ count: 0, user: { name: 'a' } });
      patchState(store, { count: 1 });
      globalThis.__sink = [store.count(), store.user.name()];
    