
      import { signalTree, entityMap } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
      const tree = signalTree({ users: entityMap() });
      tree.$.users.addOne({ id: 1, name: 'a' });
      tree.$.users.updateOne(1, { name: 'b' });
      globalThis.__sink = [tree.$.users.all(), tree.$.users.byId(1)?.()];
    