
      import { signalTree } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
      const tree = signalTree({ count: 0, user: { name: 'a' } });
      tree.$.count(1);
      globalThis.__sink = [tree.$.count(), tree.$.user.name()];
    