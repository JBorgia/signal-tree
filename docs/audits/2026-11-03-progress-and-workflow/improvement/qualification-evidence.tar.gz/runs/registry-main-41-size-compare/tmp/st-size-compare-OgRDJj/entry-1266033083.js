
      import { signalState, patchState } from '@ngrx/signals';
      import { addEntity, updateEntity } from '@ngrx/signals/entities';
      const store = signalState({ entityMap: {}, ids: [] });
      patchState(store, addEntity({ id: 1, name: 'a' }));
      patchState(store, updateEntity({ id: 1, changes: { name: 'b' } }));
      globalThis.__sink = [store.ids(), store.entityMap()[1]];
    