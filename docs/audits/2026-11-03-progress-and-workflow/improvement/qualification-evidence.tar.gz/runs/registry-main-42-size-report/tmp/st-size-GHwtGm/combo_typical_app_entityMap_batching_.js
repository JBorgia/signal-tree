
    import { signalTree, entityMap, batching } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
    const t = signalTree({
      rows: entityMap({ selectId: (r) => r.id }),
      count: 0,
    }, { enhancers: [batching()] });
    t.batch(() => { t.$.rows.addOne({ id: 1 }); t.$.count(1); });
    globalThis.__sink = [t.$.rows.all(), t.$.count()];