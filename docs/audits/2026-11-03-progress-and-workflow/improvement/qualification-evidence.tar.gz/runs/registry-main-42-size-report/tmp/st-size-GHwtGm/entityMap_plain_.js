import { signalTree, entityMap } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";

    const t = signalTree({ rows: entityMap({ selectId: (r) => r.id }) });
    t.$.rows.addOne({ id: 1 }); t.$.rows.updateOne(1, {});
    globalThis.__sink = [t.$.rows.all(), t.$.rows.count()];