
    import { signalTree, restoration, undoable } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
    const t = signalTree({ count: 0 }, { enhancers: [restoration()] });
    t.$.count(1); undoable(() => t.$.count(2)); t.undo(); t.redo();
    globalThis.__sink = [t.$.count()];