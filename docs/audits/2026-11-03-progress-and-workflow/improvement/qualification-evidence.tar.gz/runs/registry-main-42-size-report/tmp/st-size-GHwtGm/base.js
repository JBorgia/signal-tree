
  import { signalTree } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
  const t = signalTree({ count: 0, user: { name: 'a' } });
  t.$.count(1); t.$.user({ name: 'b' });
  globalThis.__sink = [t.$.count(), t.$()];
