
    import { signalTree, batching } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
    const t = signalTree({ count: 0 }, { enhancers: [batching()] });
    t.$.count(1); t.batch(() => t.$.count(2));
    globalThis.__sink = [t.$.count()];