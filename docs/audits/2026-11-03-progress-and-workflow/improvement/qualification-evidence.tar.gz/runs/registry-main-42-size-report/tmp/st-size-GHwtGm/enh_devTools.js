
    import { signalTree, devTools } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
    const t = signalTree({ count: 0 }, { enhancers: [devTools()] });
    t.$.count(1); t.connectDevTools();
    globalThis.__sink = [t.$.count()];