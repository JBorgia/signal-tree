
import * as kernel from '@signal-tree/kernel';
import * as angular from '@signal-tree/angular';
import * as react from '@signal-tree/react';
import * as vue from '@signal-tree/vue';
import { isSignal } from '@angular/core';
import { createElement } from 'react';
import { renderToString } from 'react-dom/server';
import { isRef } from 'vue';

const sharedRuntimeSymbols = [
  'entityMap',
  'link',
  'restoration',
  'undoable',
  'external',
  'asReadonly',
  'batching',
  'devTools',
  'transactions',
  'onTreeError',
  'SignalTreeRollbackError',
];

const facades = { angular, react, vue };
for (const packageName of ['angular', 'react', 'vue']) {
  const facade = facades[packageName];
  for (const symbol of sharedRuntimeSymbols) {
    if (facade[symbol] !== kernel[symbol]) {
      throw new Error(
        '@signal-tree/' + packageName + ' does not forward kernel ' + symbol + ' by identity.'
      );
    }
  }
}

if (react.signalTree !== kernel.signalTree) {
  throw new Error('@signal-tree/react does not forward kernel signalTree by identity.');
}
const reactTree = react.signalTree({ count: 1 });
const ReactCounter = () => createElement(
  'output',
  null,
  react.useSignalTree(reactTree, ($) => $.count())
);
if (!renderToString(createElement(ReactCounter)).includes('>1</output>')) {
  throw new Error('@signal-tree/react did not provide a canonical server snapshot.');
}
reactTree.destroy();
if (angular.signalTree === kernel.signalTree) {
  throw new Error('@signal-tree/angular silently fell back to neutral construction.');
}
if (vue.signalTree === kernel.signalTree) {
  throw new Error('@signal-tree/vue silently fell back to neutral construction.');
}
const angularTree = angular.signalTree({ count: 1 });
if (!isSignal(angularTree.$.count)) {
  throw new Error('@signal-tree/angular did not expose a native signal leaf.');
}
angularTree.$.count.set(2);
if (angularTree.$.count() !== 2) {
  throw new Error('@signal-tree/angular did not route a native signal write.');
}
angularTree.destroy();

const vueTree = vue.signalTree(
  { count: 1 },
  { derived: ($) => ({ doubled: () => $.count.value * 2 }) }
);
if (!isRef(vueTree.$.count) || !isRef(vueTree.$.doubled)) {
  throw new Error('@signal-tree/vue did not expose native ref leaves.');
}
vueTree.$.count.value = 2;
if (vueTree.$.doubled.value !== 4) {
  throw new Error('@signal-tree/vue did not route a native ref write.');
}
vueTree.destroy();
