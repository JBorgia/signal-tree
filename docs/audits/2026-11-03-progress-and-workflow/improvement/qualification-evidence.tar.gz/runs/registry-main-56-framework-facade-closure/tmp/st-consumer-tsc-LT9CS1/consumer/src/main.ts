
import {
  signalTree,
  entityMap,
  leaf,
  link,
  restoration,
  batching,
  transactions,
  undoable,
  type ReadonlyLocation,
  type ChangeStatus,
  type InspectedChange,
  type PendingTransaction,
  type TransactionInspection,
  type TreeId,
} from '@signal-tree/kernel';
import {
  createSignalTreeFactory,
  type EpochHandle,
  type ObservationAdapter,
  type ObservationToken,
} from '@signal-tree/kernel/adapter';
// Supported tooling is a separate shipped declaration entry, not covered by
// importing the root and adapter alone. Keep branded tree identity across it.
import {
  treeCapabilities,
  treeRuntimeId,
  stateLocationReader,
  confirmedTurnReader,
  transactionLifecycleReader,
  restorationReader,
  entityMembershipReader,
  linkStateReader,
  type EntityMembershipEvent,
  type LinkStateEvent,
  type RestorationReaderEvent,
  type StateLocationSegment,
  type TransactionLifecycleObservation,
} from '@signal-tree/kernel/internals';
import {
  defineStore,
  leaf as angularLeaf,
  entityMap as angularEntityMap,
  signalTree as angularSignalTree,
  restoration as angularRestoration,
  type LeafDefinition as AngularLeafDefinition,
  type AccessibleNode as AngularAccessibleNode,
  type EntitySignalWithSlices as AngularEntitySignalWithSlices,
} from '@signal-tree/angular';
import type { Signal as AngularSignal, WritableSignal } from '@angular/core';
import {
  useSignalTree,
  signalTree as reactSignalTree,
  leaf as reactLeaf,
} from '@signal-tree/react';
import {
  signalTree as solidSignalTree,
  leaf as solidLeaf,
} from '@signal-tree/solid';
import type { ComputedRef, Ref } from 'vue';
import {
  asReadonly as vueAsReadonly,
  entityMap as vueEntityMap,
  signalTree as vueSignalTree,
  leaf as vueLeaf,
  restoration as vueRestoration,
  type LeafDefinition as VueLeafDefinition,
  type AccessibleNode as VueAccessibleNode,
  type EntitySignalWithSlices as VueEntitySignalWithSlices,
} from '@signal-tree/vue';


// A THIRD-PARTY FRAMEWORK ADAPTER, built from public exports only.
//
// `@signal-tree/<framework>` is the physical-realization optimizer for its
// framework, so the adapter seam is a supported extension point -- which means
// every type needed to implement it has to be nameable from the public entry.
// `EpochHandle` was declared but NOT exported until this was checked, so an
// external adapter could not type its own createEpoch/advanceEpoch pair.
//
// The pair is the contract: the adapter creates a handle and the adapter
// advances it. The kernel never assumes the handle is writable, has `.value`,
// or is any particular framework's primitive.
const thirdPartyAdapter: ObservationAdapter = {
  createToken(): ObservationToken {
    let version = 0;
    return { observe: () => void version, invalidate: () => void (version += 1) };
  },
  createEpoch(): EpochHandle {
    let version = 0;
    const handle = (() => version) as EpochHandle & { bump?: () => void };
    handle.bump = () => void (version += 1);
    return handle;
  },
  advanceEpoch(epoch: EpochHandle): void {
    (epoch as EpochHandle & { bump?: () => void }).bump?.();
  },
  runInvalidationGroup(run: () => void): void {
    run();
  },
};
void thirdPartyAdapter;

// All public Angular markers must retain identity across root/adapter .d.ts.
const markedAngularTree = angularSignalTree({ count: angularLeaf<number>(1) });
// Public factory constraints must survive declaration packaging in both resolvers.
// @ts-expect-error primitive factory results cannot be injected store objects
defineStore(() => 42);
// @ts-expect-error null cannot be an owned store object
defineStore(() => null);
// @ts-expect-error an absent factory result cannot be an owned store object
defineStore(() => undefined);
const ObjectStore = defineStore(() => ({ count: 0 }));
const CallableStore = defineStore(() => () => 42);
const acceptObjectStore = (store: InstanceType<typeof ObjectStore>): number => store.count;
const acceptCallableStore = (store: InstanceType<typeof CallableStore>): number => store();
void [acceptObjectStore, acceptCallableStore];

markedAngularTree.$.count.set(2);
const markedCount: number = markedAngularTree.$.count();
void markedCount;
markedAngularTree.destroy();

type User = { id: number; name: string; version: number };

// Enhancers are DECLARED, all of them, in one array. There is no .with() to
// chain and no order to get right -- the sample shows the only shape there is.
const tree = signalTree(
  {
    count: 0,
    user: { name: 'Ada', age: 36 },
    bounds: leaf({ min: 0, max: 10 }),
    callback: leaf((value: number) => value),
    users: entityMap<User, number>({ selectId: (u: User) => u.id })
      .computed('names', (all) => all.map((user) => user.name)),
  },
  { enhancers: [restoration(), batching()] }
);

// Reads
const n: number = tree.$.count();
const whole: { count: number } = tree.$() as { count: number };
const rows: User[] = tree.$.users.all();
const names: ReadonlyLocation<string[]> = tree.$.users.names;
const currentNames: string[] = names.peek();
const unsubscribeNames = names.subscribe(() => undefined);
unsubscribeNames();

// Neutral kernel locations use callable read/replace/derive grammar.
tree.$.count(5);
tree.$.count((count: number) => count + 1);
tree.$.bounds({ min: 1, max: 9 });
tree.$.callback(leaf((value: number) => value + 1));

// Branch + root state locations ARE callable
tree.$.user({ name: 'Grace', age: 36 });
tree.$((current) => ({ ...current, count: 9 }));

// Marker APIs
tree.$.users.addOne({ id: 1, name: 'a', version: 1 });
tree.$.users.updateOne(1, { name: 'b' });

// Angular leaves and readonly projections use native Angular signal types while
// EntityMap methods and kernel semantic authority remain intact.
const angularTree = angularSignalTree({
  count: 0,
  profile: { name: 'Ada' },
  users: angularEntityMap<User, number>({ selectId: (u: User) => u.id })
    .computed('names', (users) => users.map((user) => user.name)),
});
const angularCount: WritableSignal<number> = angularTree.$.count;
const angularUsers: AngularSignal<User[]> = angularTree.$.users.all;
const angularProfile: AngularAccessibleNode<{ name: string }> = angularTree.$.profile;
const angularSlicedUsers: AngularEntitySignalWithSlices<
  User,
  number,
  { names: string[] }
> = angularTree.$.users;
angularCount.set(1);
angularTree.$.users.setAll([]);
link(angularTree.$.count, { set: (value) => void value.toFixed() });
link(angularTree.$.users, { set: (value) => void value[0]?.name });
void [angularProfile, angularSlicedUsers];

// Vue leaves and derived values use native Ref contracts over kernel truth.
const vueTree = vueSignalTree(
  {
    count: 1,
    profile: { name: 'Ada' },
    users: vueEntityMap<User, number>({ selectId: (u: User) => u.id })
      .computed('names', (users) => users.map((user) => user.name)),
  },
  { derived: ($) => ({ doubled: () => $.count.value * 2 }) }
);
const vueCount: Ref<number> = vueTree.$.count;
const vueDoubled: ComputedRef<number> = vueTree.$.doubled;
const vueProfile: VueAccessibleNode<{ name: string }> = vueTree.$.profile;
const vueSlicedUsers: VueEntitySignalWithSlices<
  User,
  number,
  { names: string[] }
> = vueTree.$.users;
const vueReader = vueAsReadonly(vueTree);
const vueReadonlyCount: Readonly<Ref<number>> = vueReader.$.count;
vueCount.value = 2;
link(vueTree.$.count, { set: (value) => void value.toFixed() });
link(vueTree.$.users, { set: (value) => void value[0]?.name });
void [vueProfile, vueSlicedUsers];
void vueReadonlyCount.value;
// @ts-expect-error a type-only readonly view of a writable Ref is not ComputedRef
void vueReader.$.count.effect;

// Generic entity markers and nested opaque payloads must survive declaration
// bundling without inspecting their generic configuration or payload internals.
export function makeAngularGenericStore<E, K extends string | number, F>(
  selectId: (row: E) => K,
  filter: F
) {
  const store = angularSignalTree(
    { rows: angularEntityMap<E, K>({ selectId }), filters: { value: angularLeaf(filter) }, count: 1 },
    { enhancers: [angularRestoration()], derived: ($) => ({ doubled: () => $.count() * 2 }) }
  );
  const payload: F = store.$.filters.value();
  const doubled: number = store.$.doubled();
  const canUndo: boolean = store.canUndo();
  void [payload, doubled, canUndo];
  return store;
}
export function makeVueGenericStore<E, K extends string | number, F>(
  selectId: (row: E) => K,
  filter: F
) {
  const store = vueSignalTree(
    { rows: vueEntityMap<E, K>({ selectId }), filters: { value: vueLeaf(filter) }, count: 1 },
    { enhancers: [vueRestoration()], derived: ($) => ({ doubled: () => $.count.value * 2 }) }
  );
  const payload: F = store.$.filters.value.value;
  const doubled: number = store.$.doubled.value;
  const canUndo: boolean = store.canUndo();
  void [payload, doubled, canUndo];
  return store;
}

// Packed declarations must retain native terminal carriers and unwrap optional
// leaf definitions in both location reads and whole-root snapshots.
const angularDefinition: {
  optional?: AngularLeafDefinition<{ enabled: boolean }>;
  union: AngularLeafDefinition<number> | string;
} = { optional: angularLeaf({ enabled: true }), union: angularLeaf(1) };
const angularTerminals = angularSignalTree({
  ...angularDefinition,
  weakMap: new WeakMap<object, string>(),
  bytes: new Uint8Array(2),
  callback: (text: string) => text.length,
});
const angularOptional: { enabled: boolean } | undefined = angularTerminals.$.optional?.();
const angularUnion: number | string = angularTerminals.$.union();
const angularWeakMap: WritableSignal<WeakMap<object, string>> = angularTerminals.$.weakMap;
const angularBytes: Uint8Array = angularTerminals.$.bytes();
const angularCallback: (text: string) => number = angularTerminals.$.callback();
const angularSnapshot: { optional?: { enabled: boolean }; union: number | string } = angularTerminals.$();
// @ts-expect-error a terminal payload does not expose branch methods
void angularTerminals.$.weakMap.get;
// @ts-expect-error typed array elements belong to the terminal payload
void angularTerminals.$.bytes[0];
void [angularOptional, angularUnion, angularWeakMap, angularBytes, angularCallback, angularSnapshot];
angularTerminals.destroy();

const vueDefinition: {
  optional?: VueLeafDefinition<{ enabled: boolean }>;
  union: VueLeafDefinition<number> | string;
} = { optional: vueLeaf({ enabled: true }), union: vueLeaf(1) };
const vueTerminals = vueSignalTree({
  ...vueDefinition,
  weakMap: new WeakMap<object, string>(),
  bytes: new Uint8Array(2),
  callback: (text: string) => text.length,
});
const vueOptional: { enabled: boolean } | undefined = vueTerminals.$.optional?.value;
const vueUnion: number | string = vueTerminals.$.union.value;
const vueWeakMap: Ref<WeakMap<object, string>> = vueTerminals.$.weakMap;
const vueBytes: Uint8Array = vueTerminals.$.bytes.value;
const vueCallback: (text: string) => number = vueTerminals.$.callback.value;
const vueSnapshot: { optional?: { enabled: boolean }; union: number | string } = vueTerminals.$();
// @ts-expect-error a terminal payload does not expose branch methods
void vueTerminals.$.weakMap.get;
// @ts-expect-error typed array elements belong to the terminal payload
void vueTerminals.$.bytes[0];
void [vueOptional, vueUnion, vueWeakMap, vueBytes, vueCallback, vueSnapshot];
vueTerminals.destroy();

// THE EIGHT OBSERVATION HELPERS, admitted from every facade through the packed
// tooling entry. A real tree with an opaque leaf() object and an entity map
// must be accepted as constructed (its accumulated surface, not TreeNode<T>
// rebuilt from unwrapped state), and the TreeId brand must agree across the
// root and tooling declaration entries.
const runtimeTreeId: TreeId | undefined = treeRuntimeId(tree);
const observedTreeId: TreeId | undefined =
  transactionLifecycleReader(tree)?.snapshot().treeId;
const linkedTreeId: TreeId = linkStateReader(tree).snapshot().treeId;
const membershipTreeId: TreeId | undefined =
  entityMembershipReader(tree)?.snapshot().treeId;
const historyTreeId: TreeId | undefined = restorationReader(tree)?.treeId;
const confirmedTreeId: TreeId | undefined = confirmedTurnReader(tree)?.treeId;
void [runtimeTreeId, observedTreeId, linkedTreeId, membershipTreeId, historyTreeId, confirmedTreeId];
void treeCapabilities(tree);
const located: readonly (readonly StateLocationSegment[] | undefined)[] =
  stateLocationReader(tree)?.locate([{ position: 1, lifetimeId: 1, fieldSegments: ['name'] }]) ?? [];
void located;
void confirmedTurnReader(tree)?.readConfirmedTurns().turns[0]?.effects[0]?.fieldSegments;
transactionLifecycleReader(tree)?.subscribe((event: TransactionLifecycleObservation) => {
  if (event.kind === 'refused') void [event.reason, event.pendingRetained, event.consequencesReleased];
});
restorationReader(tree)?.subscribe((event: RestorationReaderEvent) => {
  if (event.kind === 'operation') void [event.outcome, event.affectedEntryIds];
});
entityMembershipReader(tree)?.subscribe((event: EntityMembershipEvent) => {
  void [event.collection.location, event.changes];
});
linkStateReader(tree).subscribe((event: LinkStateEvent) => void event.link.held);

const reactObserved = reactSignalTree({ count: 0, bounds: reactLeaf({ min: 0, max: 1 }) });
const solidObserved = solidSignalTree({ count: 0, bounds: solidLeaf({ min: 0, max: 1 }) });
void treeCapabilities(angularTree);
void treeRuntimeId(angularTree);
void confirmedTurnReader(angularTree);
void stateLocationReader(angularTree);
void transactionLifecycleReader(angularTree);
void restorationReader(angularTree);
void entityMembershipReader(angularTree);
void linkStateReader(angularTree);
void treeCapabilities(vueTree);
void treeRuntimeId(vueTree);
void confirmedTurnReader(vueTree);
void stateLocationReader(vueTree);
void transactionLifecycleReader(vueTree);
void restorationReader(vueTree);
void entityMembershipReader(vueTree);
void linkStateReader(vueTree);
void treeCapabilities(reactObserved);
void treeRuntimeId(reactObserved);
void confirmedTurnReader(reactObserved);
void stateLocationReader(reactObserved);
void transactionLifecycleReader(reactObserved);
void restorationReader(reactObserved);
void entityMembershipReader(reactObserved);
void linkStateReader(reactObserved);
void treeCapabilities(solidObserved);
void treeRuntimeId(solidObserved);
void confirmedTurnReader(solidObserved);
void stateLocationReader(solidObserved);
void transactionLifecycleReader(solidObserved);
void restorationReader(solidObserved);
void entityMembershipReader(solidObserved);
void linkStateReader(solidObserved);
// Admission is not weakened to arbitrary objects or bare root accessors.
// @ts-expect-error a root accessor alone is not a tree controller
void treeRuntimeId(tree.$);
// @ts-expect-error arbitrary objects are not tree controllers
void transactionLifecycleReader({});
// @ts-expect-error arbitrary objects are not tree controllers
void entityMembershipReader({ $: {} });
reactObserved.destroy();
solidObserved.destroy();

// Enhancer methods
tree.undo();
tree.redo();
tree.batch(() => tree.$.count(0));

export const _used = [n, whole, rows, names, currentNames, angularCount, angularUsers, vueCount, vueDoubled, createSignalTreeFactory, defineStore, useSignalTree];

// PROPOSAL-0, folded into transact() (d394047c) — review through inspect(),
// exercised exactly as the docs teach it.
// Packed-tarball proof: these types must be nameable and these calls must
// compile against the PUBLISHED export map, not against workspace internals.
const reviewTree = signalTree(
  { rows: entityMap<{ id: string; name: string }, string>({ selectId: (r) => r.id }), note: '' },
  { enhancers: [restoration({ maxHistorySize: 10 }), transactions()] }
);

// Restoration is orthogonal: undoable() wraps the transaction's writes, never
// confirm(). A confirm()-time flag could not work — undoable() designates the
// causal turn containing its writes.
let pendingTransaction!: PendingTransaction;
undoable(() => {
  pendingTransaction = reviewTree.transact(() => {
    reviewTree.$.note('proposed');
    reviewTree.$.rows.addOne({ id: 'a', name: 'Alpha' });
  });
});

const review: TransactionInspection = pendingTransaction.inspect();
const firstChange: InspectedChange | undefined = review.changes[0];
const changeStatus: ChangeStatus | undefined = firstChange?.status;
const changePath: string | undefined = firstChange?.path;
pendingTransaction.confirm();
// After settlement inspect() reports the inspection as of that settlement.
const settled: TransactionInspection = pendingTransaction.inspect();

// CONSTRUCTION, not just consumption. Reading an InspectedChange type-checks
// whatever fields it has, so a required field added to the type is invisible
// to a read-only probe — which is how the 16.0.0 address change shipped as a
// declared break that nothing measured. A consumer with a test double, a
// fixture or an adapter mapping must build one, so this builds one.
const constructedChange: InspectedChange = {
  path: 'a.b',
  address: ['a', 'b'],
  status: 'current',
};
const changeAddress: readonly string[] | undefined = constructedChange.address;
const changeSubject: number | undefined = constructedChange.subject;

void changeStatus;
void changePath;
void changeAddress;
void changeSubject;
void settled.changes.length;
