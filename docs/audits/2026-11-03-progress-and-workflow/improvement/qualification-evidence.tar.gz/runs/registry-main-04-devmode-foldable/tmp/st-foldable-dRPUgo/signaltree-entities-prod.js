
    import { signalTree, entityMap } from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate/dist/packages/kernel/dist/index.js";
    const t = signalTree({ count: 0, users: entityMap() });
    t.$.users.addOne({ id: 1, name: 'a' });
    globalThis.__sink = t.$.users.all();
  