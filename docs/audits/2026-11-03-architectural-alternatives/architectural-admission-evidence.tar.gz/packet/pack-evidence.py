from pathlib import Path
import json,hashlib,tarfile,io
p=Path(__file__).resolve().parent;c=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-sparse-responsibility-0');o=c/'docs/audits/2026-11-03-architectural-alternatives';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();entries={}
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.json','.py','.cjs','.mjs','.ts','.tgz']:entries['packet/'+f.name]=f
for folder in ['baseline-cost','manifests','correct-frozen-build']:
 for f in (p/folder).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:entries['packet/'+str(f.relative_to(p))]=f
for f in (p/'runs').rglob('*'):
 if f.is_file() and 'tmp' not in f.relative_to(p/'runs').parts:entries['packet/'+str(f.relative_to(p))]=f
for f in (c/'tools/runtime-representation-selection').iterdir():
 if f.is_file():entries['replay/'+f.name]=f
for f in o.iterdir():
 if f.is_file() and f.name not in ['EVIDENCE.json','architectural-admission-evidence.tar.gz']:entries['audit/'+f.name]=f
# Published package is supplied as exact registry tarball; extracted input hashes bind109files.
manifest={n:{'bytes':f.stat().st_size,'sha256':sha(f)} for n,f in sorted(entries.items())};out=o/'architectural-admission-evidence.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for n,f in sorted(entries.items()):t.add(f,arcname=n,recursive=False)
 raw=(json.dumps(manifest,indent=2)+'\n').encode();item=tarfile.TarInfo('EVIDENCE-MANIFEST.json');item.size=len(raw);item.mode=0o644;t.addfile(item,io.BytesIO(raw))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getmembers())==len(manifest)+1
 for n,v in manifest.items():raw=t.extractfile(n).read();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
receipt={'file':out.name,'bytes':out.stat().st_size,'sha256':sha(out),'members':len(manifest)+1,'everyMemberVerified':True,'contains':'Original/corrected bindings and registrations,24baselinechildren,2counterchildren,Nxsemantic/prefixruns,source/artifact/dependency maps,exactpublishedv15tarball,correctfrozenbuildreceipt,oracles/scripts/reviews','candidateRuntimeChanged':False};(o/'EVIDENCE.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
