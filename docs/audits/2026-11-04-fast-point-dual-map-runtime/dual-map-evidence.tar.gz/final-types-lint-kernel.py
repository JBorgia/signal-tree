import subprocess,sys
commands=[['node','tools/verify-gates.mjs','--only=typecheck,spec-types'],['corepack','pnpm','exec','eslint','packages/kernel/src/lib/experimental-publication/entity.ts','packages/kernel/src/lib/fast-point-dual-map.spec.ts','packages/kernel/src/lib/point-result-allocation.spec.ts','packages/kernel/src/lib/singleton-row-allocation.spec.ts','--max-warnings=0']]
for argv in commands:
 r=subprocess.run(argv)
 if r.returncode:sys.exit(r.returncode)

sys.exit(subprocess.run(['corepack','pnpm','nx','test','kernel','--skip-nx-cache','--maxWorkers=1']).returncode)
