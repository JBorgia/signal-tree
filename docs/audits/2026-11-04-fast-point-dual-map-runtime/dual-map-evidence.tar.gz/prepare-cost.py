from pathlib import Path
import json,hashlib,shutil,datetime
base=Path(__file__).resolve().parent;p=base/'cost';p.mkdir(exist_ok=False);old=Path('/private/tmp/st-v16-runtime-attribution/cost');before=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-integration-candidate');after=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-fast-point-dual-map-0');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
shutil.copytree(old/'harness',p/'harness');runner=(old/'campaign.py').read_text().replace('len(schedule)==84','len(schedule)==48').replace("'maxChildren':84","'maxChildren':48").replace('/84','/48').replace("'rollback':200};t=","'rollback':200,'construction':200};t=");(p/'campaign.py').write_text(runner);shutil.copy2(old/'analyze.py',p/'analyze.py')
roots={'retained':before,'selected':after};sources={};artifacts={}
for arm,root in roots.items():
 manifest=p/(arm.upper()+'-MANIFEST.json');shutil.copy2(old/'RETAINED-MANIFEST.json' if arm=='retained' else base/'MANIFEST.json',manifest);sources[arm]={'root':str(root),'manifest':str(manifest),'manifestSha256':sha(manifest)}
 entries={str(f.relative_to(root)):{'sha256':sha(f),'executable':f.stat().st_mode&0o111} for f in sorted((root/'dist/packages').rglob('*')) if f.is_file()};amap=p/(arm.upper()+'-ARTIFACTS.json');amap.write_text(json.dumps(entries,indent=2)+'\n');artifacts[arm]={'root':str(root),'manifest':str(amap),'manifestSha256':sha(amap),'files':len(entries)}
assert json.loads((p/'RETAINED-ARTIFACTS.json').read_text())==json.loads((old/'RETAINED-ARTIFACTS.json').read_text())
prior=json.loads((old/'BINDINGS.json').read_text());receipts={'retained':prior['buildReceipts']['retained'],'selected':{'command':str(base/'runs/prototype-five-build/COMMAND.json'),'result':str(base/'runs/prototype-five-build/RESULT.json')}}
for r in receipts.values():
 assert json.loads(Path(r['result']).read_text())['exit']==0
 for key in ['command','result']:r[key+'Sha256']=sha(Path(r[key]))
bindings={'sources':sources,'artifacts':artifacts,'dependencies':prior['dependencies'],'buildReceipts':receipts,'armLabels':{'retained':'frozenfe18runtime,3eabcsource','selected':'FAST-POINT-DUAL-MAP-0 uncommittedsourceovereef7;fullmanifestbound'},'meaning':'v16before/prototypecomparisononly;notv15. Completecostdimensionsseparate;noadoptionfromcounterpass'};(p/'BINDINGS.json').write_text(json.dumps(bindings,indent=2)+'\n')
# Same per-profile controls/pairing as prior validated protocol, four relevantprofiles.
previous=json.loads((old/'SCHEDULE.json').read_text());schedule=[row for row in previous if row['profile'] in ['point','heap-populated','heap-pending']];construction=[]
for row in [r for r in previous if r['profile']=='point']:
 row=dict(row);row['profile']='construction';row['size']=0;row['id']=row['id'].replace('point-1000','construction-0');row['argv']=row['argv'][:-2]+['construction','0'];construction.append(row)
schedule=construction+schedule
for i,row in enumerate(schedule):
 row['ordinal']=i+1;row['argv'][2]=str(p/'harness'/Path(row['argv'][2]).name);row['argv'][3]=str(roots[row['arm']]/'dist/packages/kernel/dist');row['cwd']=str(p/'harness')
assert len(schedule)==48;(p/'SCHEDULE.json').write_text(json.dumps(schedule,indent=2)+'\n')
reg=json.loads((old/'PREREGISTRATION.json').read_text());reg.update({'registeredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'FAST-POINT-DUAL-MAP-0 aftersemantic/absolute-work/type/frameworkscreens;fourrelevantprofiles,notfullreleaseacceptance','profiles':[{'kind':'construction','size':0},{'kind':'point','size':1000},{'kind':'heap-populated','size':1000},{'kind':'heap-pending','size':1000}],'maxFreshCostChildren':48,'bindingsSha256':sha(p/'BINDINGS.json'),'scheduleSha256':sha(p/'SCHEDULE.json'),'runnerSha256':sha(p/'campaign.py'),'review':{'source':'independent dualMapcode+protocol review;rawresultinterpretationseparate'},'exclusiveSlot':'Mainownssoleheavyslot;noexclusivecore/hostcalibrationclaim'})
reg['requiredMetrics']={'point':'sync_cpu_ms','heap-populated':'live_minus_baseline_bytes'}
reg['constructionWorkload']={'dispatchSize':0,'fixtureRows':100,'measuredIterations':200,'warmupIterations':20,'includes':'construction, population, count assertion, destroy'}
reg['analysisRules']['decision']='ExperimentaladvancementrequiresunchangedpointgateAND point.sync_cpu_ms AND heap-populated.live_minus_baseline_bytes both selected-lowerbeyondregisteredvariability. Otherdimensionsindependentlyreported;no gaincompensatesforregressionorunresolvedreleasecost. Nofullreleasequalificationoradoptionfromthisscreen.'
(p/'PREREGISTRATION.json').write_text(json.dumps(reg,indent=2)+'\n');print(str(p),'48freshchildren')
