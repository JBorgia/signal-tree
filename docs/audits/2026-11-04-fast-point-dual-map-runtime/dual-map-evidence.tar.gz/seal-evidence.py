from pathlib import Path
import json,hashlib,shutil,tarfile
p=Path(__file__).resolve().parent;d=p/'sealed-evidence';d.mkdir(exist_ok=False);sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def copy(src,target):
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
names=['OWNER-REVIEW.txt','PLAN.json','COST-INTENT.json','MANIFEST.json','guard.py','run-semantics.py','types-lint.py','run-controls.py','run-final-scopes.py','prepare-cost.py','public-surface-checks.py','public-and-demo.py','post-diagnostic-verification.py','final-types-lint-kernel.py','run-allocation-diagnostics.py','run-baseline-allocation.py','seal-evidence.py','CONTROL-PREREGISTRATION.json','CONTROL-RESULTS.json','CONTROL-RESTORATION.json','first-fixture.before.ts','first-fixture.corrected.ts','point-allocation-observations.jsonl','singleton-allocation-observations.jsonl','field-design-notes.md','allocation-diagnostic-rationale.md','independent-premise-review.md','independent-code-review.md','independent-cost-protocol-review.md','independent-cost-interpretation.md','independent-allocation-oracle-review.md','EXECUTION-INDEX.json','PUBLIC-DEMO-RESULTS.json','POST-DIAGNOSTIC-ARTIFACT-EQUIVALENCE.json','post-diagnostic-build.log','production-demo.log','public-surface-and-size.log']
for n in names:copy(p/n,d/n)
for name in ['manifests','source-checkpoint','allocation-diagnostic-before','surface-checks','cost']:
 shutil.copytree(p/name,d/name)
for name in ['runs','baseline-allocation']:
 for f in (p/name).rglob('*'):
  if f.is_file() and not any(x in {'tmp','nx-cache','nx-data','npm-cache'} for x in f.relative_to(p/name).parts):copy(f,d/f.relative_to(p))
b=json.loads((p/'cost/BINDINGS.json').read_text())
for arm,a in b['artifacts'].items():
 root=Path(a['root']);m=json.loads(Path(a['manifest']).read_text())
 for n,h in m.items():
  f=root/n;assert sha(f)==h['sha256'] and f.stat().st_mode&0o111==h['executable'],(arm,n);copy(f,d/'artifacts'/arm/n)
 for k in ['command','result']:copy(Path(b['buildReceipts'][arm][k]),d/'build-receipts'/arm/(k.upper()+'.json'))
(d/'SCOPE.json').write_text(json.dumps({'baseCommit':'eef7dfc0b95c16658b825d7b1466c95b1cf43c20','measuredSource':'cost/SELECTED-MANIFEST.json c5aacad...; measured2-package-file replay in source-checkpoint/REPLAY.json','qualifiedSource':'MANIFEST.json and source-checkpoint/QUALIFIED-REPLAY.json;2testonlydiagnosticcorrections aftercost, runtimeunchanged, fresh193artifacts reproduced','included':'Both exact193file packages, rawmeasurements/commands/harness/guards/firstfailures/controls, original-runtime diagnostic proof, source patches/newfiles, independentreviews','omitted':'Complete Git history, unchanged historical source payloads, node_modules/caches, demo output. Replay requires baseGit checkout+pinneddependencies. This is not all-test reproducibility or repository-history completeness.','replay':'Original absolutepaths preserved; remap only in NEW packet, never overwrite startedregistrations or retryforfavorablecost.'},indent=2)+'\n')
m={str(f.relative_to(d)):{'sha256':sha(f),'bytes':f.stat().st_size,'executable':f.stat().st_mode&0o111} for f in sorted(d.rglob('*')) if f.is_file()};(d/'FILE-MAP.json').write_text(json.dumps(m,indent=2)+'\n');a=p/'dual-map-evidence.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in sorted(d.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(d)),recursive=False)
record={'sha256':sha(a),'bytes':a.stat().st_size,'verifiedPayloads':len(m),'mapSha256':sha(d/'FILE-MAP.json')};(p/'EVIDENCE-SEAL.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
