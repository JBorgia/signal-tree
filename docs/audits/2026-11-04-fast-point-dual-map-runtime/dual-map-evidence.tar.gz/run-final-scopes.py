import subprocess,sys
commands=[['python3','/private/tmp/st-v16-fast-point-dual-map-0/run-semantics.py'],['corepack','pnpm','nx','run-many','-t','test','--projects=angular,react,vue,solid','--skip-nx-cache','--parallel=1','--maxWorkers=1']]
for argv in commands:
 print('FINAL_SCOPE',argv,flush=True);r=subprocess.run(argv)
 if r.returncode:sys.exit(r.returncode)
