from pathlib import Path
import subprocess,sys,os
p=Path(__file__).resolve().parent;env=os.environ.copy();env['ST_POINT_ALLOCATION_OUTPUT']=str(p/'point-allocation-observations.jsonl');env['ST_SINGLETON_ALLOCATION_OUTPUT']=str(p/'singleton-allocation-observations.jsonl')
argv=['corepack','pnpm','nx','test','kernel','--skip-nx-cache','--maxWorkers=1','--testFile=src/lib/point-result-allocation.spec.ts','--testFile=src/lib/singleton-row-allocation.spec.ts'];print(argv,flush=True);sys.exit(subprocess.run(argv,env=env).returncode)
