from pathlib import Path
import subprocess,json,sys
p=Path(__file__).resolve().parent/'surface-checks';p.mkdir(exist_ok=False)
commands={'api-baseline':['node','tools/api-inventory.mjs','--check'],'api-callable-baseline':['node','tools/api-callable-inventory.mjs','--check'],'built-barrels':['node','tools/verify-built-barrels.mjs'],'exports-importable':['node','scripts/verify-exports.js'],'bundle-budget':['node','tools/check-bundle-budget.mjs']}
results=[]
for name,argv in commands.items():
 with (p/(name+'.log')).open('x') as log:r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'argv':argv,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(int(any(r['exit'] for r in results)))
