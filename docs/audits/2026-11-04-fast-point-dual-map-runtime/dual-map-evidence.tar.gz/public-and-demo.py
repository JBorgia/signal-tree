from pathlib import Path
import subprocess,json,sys
p=Path(__file__).resolve().parent
commands={'public-surface-and-size':['python3',str(p/'public-surface-checks.py')],'production-demo':['corepack','pnpm','nx','build','demo','--configuration=production','--skip-nx-cache']}
results=[]
for name,argv in commands.items():
 print('CHECK',name,argv,flush=True)
 with (p/(name+'.log')).open('x') as log:r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'argv':argv,'exit':r.returncode});print(name,r.returncode,flush=True)
(p/'PUBLIC-DEMO-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');sys.exit(int(any(v['exit'] for v in results)))
