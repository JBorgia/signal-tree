from pathlib import Path
import subprocess,json,hashlib,sys
p=Path(__file__).resolve().parent;r=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-fast-point-dual-map-0');argv=['corepack','pnpm','nx','run-many','-t','build','--projects=kernel,angular,react,vue,solid','--skip-nx-cache','--parallel=1'];print('POST_DIAGNOSTIC_BUILD',argv,flush=True)
with (p/'post-diagnostic-build.log').open('x') as log:rc=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT).returncode
assert rc==0,rc
m=json.loads((p/'cost/SELECTED-ARTIFACTS.json').read_text());actual={str(f.relative_to(r)) for f in (r/'dist/packages').rglob('*') if f.is_file()};assert actual==set(m);bad=[n for n,h in m.items() if hashlib.sha256((r/n).read_bytes()).hexdigest()!=h['sha256'] or (r/n).stat().st_mode&0o111!=h['executable']];assert not bad,bad
(p/'POST-DIAGNOSTIC-ARTIFACT-EQUIVALENCE.json').write_text(json.dumps({'buildArgv':argv,'buildExit':rc,'sameFileSet':True,'verifiedFiles':len(m),'mismatches':bad,'meaning':'Fresh build after test-only diagnostic corrections reproduces every measured package byte and executable mode. No cost cohort repeated.'},indent=2)+'\n');print('All measured artifact bytes reproduced',flush=True)
sys.exit(subprocess.run(['python3',str(p/'public-and-demo.py')]).returncode)
