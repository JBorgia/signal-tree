from pathlib import Path
import json,hashlib,subprocess,sys
p=Path(__file__).resolve().parent;r=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-fast-point-dual-map-0');n='packages/kernel/src/lib/experimental-publication/entity.ts';f=r/n;original=f.read_bytes();manifest=(p/'MANIFEST.json').read_bytes();base=json.loads(manifest);sha=lambda b:hashlib.sha256(b).hexdigest()
controls=[{'name':'omit-late-retirement-token-refresh','replacements':[
('if(retirementRevisions.has(targetFields))retirementRevisions.set(targetFields,revision);','/* deliberately omit late field token refresh */'),
('if(retirementRevisions.has(targetViews))retirementRevisions.set(targetViews,revision);','/* deliberately omit late View token refresh */')], 'file':'src/lib/fast-point-dual-map.spec.ts'},
{'name':'omit-escaped-map-copy','replacements':[
('const copyFields=fieldsPreparing||escaped.has(baseFields),copyViews=viewsPreparing||escaped.has(baseViews);','const copyFields=fieldsPreparing,copyViews=viewsPreparing;'),
('copyFields||escaped.has(baseFields)?new Map(baseFields):baseFields','copyFields?new Map(baseFields):baseFields'),
('copyViews||escaped.has(baseViews)?new Map(baseViews):baseViews','copyViews?new Map(baseViews):baseViews')], 'file':'src/lib/integrated-field-facts.spec.ts'}]
(p/'CONTROL-PREREGISTRATION.json').write_text(json.dumps({'sourceManifestSha256':sha(manifest),'sourceSha256':sha(original),'controls':controls,'rule':'each must fail a useful assertion; resource/setup/import/drift failures do not count; restore exact bytes in finally; no costrun duringcontrols'},indent=2)+'\n');results=[]
try:
 for c in controls:
  modified=original.decode()
  for a,b in c['replacements']:
   assert modified.count(a)==1,(c['name'],a);modified=modified.replace(a,b)
  f.write_text(modified);m=dict(base);m[n]=sha(f.read_bytes());(p/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
  name='control-'+c['name'];argv=['python3',str(p/'guard.py'),name,'300','corepack','pnpm','nx','test','kernel','--skip-nx-cache','--maxWorkers=1','--testFile='+c['file']]
  subprocess.run(argv,check=True)
  result=json.loads((p/'runs'/name/'RESULT.json').read_text());log=(p/'runs'/name/'first.log').read_text();killed=result['exit']!=0 and not result['guardReason'] and not result['sourceMismatches'] and not result['remainingOwned'] and 'AssertionError' in log
  results.append({'name':name,'killed':killed,'result':result});print(name,'killed' if killed else 'INVALID_OR_SURVIVED',flush=True)
  assert killed,results[-1]
finally:
 f.write_bytes(original);(p/'MANIFEST.json').write_bytes(manifest)
 (p/'CONTROL-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');(p/'CONTROL-RESTORATION.json').write_text(json.dumps({'sourceRestored':f.read_bytes()==original,'manifestRestored':(p/'MANIFEST.json').read_bytes()==manifest,'sourceSha256':sha(f.read_bytes()),'sourceManifestSha256':sha(manifest)},indent=2)+'\n')
