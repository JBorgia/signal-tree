# Allocation diagnostic correction

Only point-result-allocation.spec.ts and singleton-row-allocation.spec.ts changed. Before bytes saved in allocation-diagnostic-before/. Production runtime, original absolute point-work gate, CPU/heap harness and acceptance thresholds are unchanged.

A positive allocation floor in a workload is not a semantic requirement. Each helper now snapshots its original workload counters, then exercises deterministic empty and two-entry copied Maps with the very same interception still installed. The seed uses saved Original to exclude it from probe counts. Point-result also probes one three-element Array.map. Exact probe deltas and resulting values must match. The returned/reported counters remain the original workload snapshot; probe activity is excluded.

Workload counts must be nonnegative safe integers (therefore finite), and every 200-write endpoint check, untouched-row check, width/size combination, optional output and teardown remains. Existing independent exact calibration tests are unchanged. Known-bad controls restore global Map during workload and require the in-window probe to reject; point-result also controls removal of Array.map interception. Helpers restore globals in finally after both success and refusal.

No tests, builds or lint run by this worker. Root retains execution and records.
