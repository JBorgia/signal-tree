# Dual-map field port: source admission notes

Inspected clean eef7dfc0b worktree, predecessor f165 entity implementation, integrated seven witnesses, frozen eef design, contributor contracts, current source preparation/finalization and lifecycle finalizer. No implementation or execution yet.

Restore predecessor ordinary endpoint Map and physical View Map per row. Each Map naturally retains its side-specific field order. No RowFacts, pair wrappers, side key arrays or per-row revision tokens. Generic preparation should return to predecessor snapshots and lazy per-side fallback behavior, retaining integrated completion exposure as metadata only.

Point preparation marks both base Maps busy before callback-capable payload presence/value reads. Reentrant point writes copy any busy base Map. It chooses copied targets for any escaped/busy base Maps; otherwise terminal installation can update targets in place. Requirements, endpoints and physical View semantics stay unchanged.

Expose generic native completion marks all staged ordinary and physical row Maps before recipient.prepare receives it. Repeated-subject ordinary snapshots and per-edit physical images are detached already and never installed, so they cannot be mutated by a later point installer. Physical-only ordinary fallback stays dynamic, as predecessor requires. No marking or freezing turns that fallback into a snapshot.

Point completion exposure must seal detached ordinary target plus immutable per-edit physical proof image, while preserving live equal-value physical View mutation for source captures. Source-only evidence stays dynamic. Opaque successful native-only completions retain the eef escape boundary.

Retirement preparation marks both current row Maps escaped before returning. A later exact-row point installation must replace them, so comparing the two identities replaces revision tokens. Unrelated rows do not invalidate the plan. Support-only/equal-value updates still replace ordinary endpoint and force marked row Maps to copy.

Current lifecycle.finalizeNativeRequirement is pure internal proof/window normalization; its comment explicitly places it after callback-capable preparers. Source validates revisions around native finalize. The normal source pipeline has no user callback between point target choice/exposure and terminal installation. Supported arbitrary manual retention of PreparedPublicationUnit, if any, should be considered separately before code admission; no new public contract is proposed.

Cost premise: common populated layout returns to predecessor two Maps, endpoint objects and View objects; new state is participant-scoped weak escape/busy/completion metadata. Weak container backing store and conditional held snapshots still need measurement. No byte saving is claimed from source inspection.

## Implemented checkpoint after conditional admission

Restored f165 generic dual-map staging, per-side insertion order, repeated/unit-local pairing, evidence/support closures and retirement requirement enumeration. Retained common requirement helper and ported integrated direct point/exposure with independent ordinary/physical Map targets, busy protection, and exact detached per-edit physical evidence. No fused pair/row/order storage remains.

Concrete late capture falsifier: hold source-issued prepared point, then create native retirement plan, then finalize/install the held point. Preparation-only escape marking cannot invalidate by Map identity because target selection already happened. Admitted repair uses participant WeakMap<object,object> from captured row Maps to conditional retirement tokens. prepareRetirement establishes tokens and marks captured Maps escaped; current() checks both identities and both tokens. Point preparation precomputes one token. Terminal pointWrite conditionally updates already-enrolled target Maps only, with no copying, traversal, or new token allocation. Never-captured rows have no persistent retirement token/entry. New fast-point-dual-map.spec.ts covers changed-value and equal-value versions of this sequence.

No tests, builds, lint, profiling or cost runs performed by this worker. git diff --check passed at handoff. Root controls execution and disposition. Normal source expose-before-pass plus opaque native-only completion premise remains under independent review by root.
