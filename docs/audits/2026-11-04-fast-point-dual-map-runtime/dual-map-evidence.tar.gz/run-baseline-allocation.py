from pathlib import Path
import json,subprocess,hashlib,shutil,sys
p=Path(__file__).resolve().parent;b=p/'baseline-allocation';b.mkdir(exist_ok=False);r=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-point-control-baseline');current=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-fast-point-dual-map-0');base='f165d28e55dce241ff6466a58c9b850f1bbc20f3';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
status=subprocess.check_output(['git','status','--short'],cwd=r,text=True);assert status.strip()=='M packages/solid/src/lib/native-publication-error-boundary.spec.ts',status
names=['packages/kernel/src/lib/point-result-allocation.spec.ts','packages/kernel/src/lib/singleton-row-allocation.spec.ts'];original={n:(r/n).read_bytes() for n in names};sha=lambda v:hashlib.sha256(v).hexdigest()
try:
 for n in names:
  t=b/'before'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(original[n]);shutil.copy2(current/n,r/n)
 (b/'guard.py').write_text((p/'guard.py').read_text().replace(str(current),str(r)))
 files=set(subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=r).decode().split('\0'))-{''};m={n:sha((r/n).read_bytes()) for n in sorted(files) if (r/n).is_file()};(b/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
 argv=['python3',str(b/'guard.py'),'corrected-diagnostics-original-runtime','600','corepack','pnpm','nx','test','kernel','--skip-nx-cache','--maxWorkers=1',*['--testFile='+n.removeprefix('packages/kernel/') for n in names]];subprocess.run(argv,check=True)
 result=json.loads((b/'runs/corrected-diagnostics-original-runtime/RESULT.json').read_text());assert result['exit']==0 and not result['guardReason'] and not result['sourceMismatches']
finally:
 for n,v in original.items():(r/n).write_bytes(v)
 (b/'RESTORATION.json').write_text(json.dumps({'baseCommit':base,'restored':{n:sha((r/n).read_bytes())==sha(v) for n,v in original.items()},'preservedOtherDirtyFile':'packages/solid/src/lib/native-publication-error-boundary.spec.ts'},indent=2)+'\n')
