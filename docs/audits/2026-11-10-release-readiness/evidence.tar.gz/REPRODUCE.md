# Reproduction

Use the review branch checkout with its pinned Node24.15.0/pnpm10.17.0 dependencies. The archive contains executed source copies, source patches, exact built packages, raw controls and logs. It is not a complete Git history or a vendored dependency installation.

For new measurements, create a fresh packet and copy `baseline-kernel`, `packed-kernel`, and `v15-kernel` into it. Never overwrite the preserved raw cohorts. From the checkout run:

```sh
python3 tools/release-readiness/compare.py /absolute/fresh-packet
node tools/release-readiness/browser-readiness.mjs /absolute/fresh-packet
node tools/release-economics/coordinated.mjs selftest /absolute/fresh-packet/packed-kernel 1000
node --expose-gc tools/release-economics/retention-diagnostic.mjs suite /absolute/checkout /absolute/fresh-packet
```

The browser command uses the current checkout's actual React source and exact supplied kernels. The comparison binds every executed helper/artifact before and after children. `measured-source/` preserves the exact helpers preceding three behavior-neutral lint edits; `measurement-harness-lint-equivalence.json` records those hashes. `reproduction/` contains the corrected replay helpers and app/facade source closure. Dependencies are resolved from the pinned checkout.

For qualification, follow `.github/VALIDATION_GUIDE.md` serially. `qualification-driver.py` records this run's exact orchestration and local paths; update paths explicitly for another checkout. The strict size command and one browser size assertion remain failed under the owner's explicit disposition. The review-only production budget override was restored and never committed. Do not call those numerical tests green or publish directly from this packet.
