
import React from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import App from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-release-readiness/apps/react-reference/src/app/app.tsx";
import {createReferenceStore,INITIAL_JOBS} from "/Users/jonathanborgia/code/signaltree/.worktrees/v16-release-readiness/apps/react-reference/src/app/reference-store.ts";
import "/Users/jonathanborgia/code/signaltree/.worktrees/v16-release-readiness/apps/react-reference/src/styles.css";
const rows=Array.from({length:1000},(_,i)=>({...INITIAL_JOBS[i%5],id:i<5?INITIAL_JOBS[i].id:'J-CAP-'+i}));
window.runReadiness=async()=>{
 const host=document.getElementById('root');const began=performance.now();
 const state=createReferenceStore(rows);const treeReady=performance.now();
 const view=createRoot(host);flushSync(()=>view.render(React.createElement(App,{store:state})));
 const layout=host.getBoundingClientRect();const ready=performance.now();
 const visible=document.querySelectorAll('article.job').length;
 if(visible!==600||!layout.height)throw Error('Actual reference view not realized');
 const interactions=[];
 for(let i=0;i<30;i++){
  const start=performance.now();flushSync(()=>state.setTeam(i%2?'North':'South'));
  await new Promise(resolve=>setTimeout(resolve,0));flushSync(()=>{});
  host.getBoundingClientRect();interactions.push(performance.now()-start);
  if(document.querySelectorAll('article.job').length!==(i%2?600:400))throw Error('Filter-only render stale');
 }
 flushSync(()=>view.unmount());state.destroy();
 return{stateMs:treeReady-began,usableViewMs:ready-began,interactions,visible};
};
