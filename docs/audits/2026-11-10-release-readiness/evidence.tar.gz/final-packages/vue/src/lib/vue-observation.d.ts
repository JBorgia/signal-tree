import type { ObservationAdapter } from '@signal-tree/kernel/adapter';
export declare const createVueObservationAdapter: () => ObservationAdapter;
