import { type Ref } from 'vue';
import type { SignalTreeFactoryOf } from '@signal-tree/kernel/adapter';
export type FrameworkSignalTreeFactory = SignalTreeFactoryOf<'vue', Ref<unknown>>;
/**
 * Read each branch property once, so accessor-backed definitions cannot change
 * between validation and construction. Terminal data retains its identity.
 * No reactive primitive is read, subscribed to, or adopted here.
 */
export declare function prepareConstructionInput(initialState: object): object;
