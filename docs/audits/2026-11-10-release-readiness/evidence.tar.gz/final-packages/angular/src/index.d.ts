/** Angular observation plus the complete SignalTree application surface. */
import './lib/carrier.js';
import type { AccessibleNodeOf, EntityNodeOf, EntitySignalOf, EntitySignalWithSlicesOf, ISignalTreeOf, LeafOf, ReadonlyStoreOf, ReadonlyViewOf, TreeNodeOf } from '@signal-tree/kernel/adapter';
import { type FrameworkSignalTreeFactory } from './lib/construction-input.js';
/** Construct native Angular leaves from values; external signals require leaf(). */
export declare const signalTree: FrameworkSignalTreeFactory;
export type TreeNode<T> = TreeNodeOf<T, 'angular'>;
export type WritableLeaf<T> = LeafOf<T, 'angular'>;
export type AccessibleNode<T> = AccessibleNodeOf<T, 'angular'>;
export type ISignalTree<T, TAccum = TreeNode<T>> = ISignalTreeOf<T, 'angular', TAccum>;
export type SignalTree<T> = ISignalTree<T>;
export type EntityNode<E> = EntityNodeOf<E, 'angular'>;
export type EntitySignal<E, K extends string | number = string> = EntitySignalOf<E, K, 'angular'>;
export type EntitySignalWithSlices<E, K extends string | number, Slices extends Record<string, unknown>> = EntitySignalWithSlicesOf<E, K, Slices, 'angular'>;
export type ReadonlyView<T> = ReadonlyViewOf<T, 'angular'>;
export type ReadonlyStore<TSource, TAccum = TreeNode<TSource>> = ReadonlyStoreOf<TSource, TAccum, 'angular'>;
export declare const asReadonly: <TSource, TAccum>(tree: ISignalTreeOf<TSource, "angular", TAccum>) => ReadonlyStoreOf<TSource, TAccum, "angular">;
export * from '@signal-tree/kernel';
export { defineStore, type DefineStoreConfig } from './lib/define-store.js';
export { toWritableSignal } from './lib/to-writable-signal.js';
