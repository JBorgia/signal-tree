import type { ObservationAdapter } from '@signal-tree/kernel/adapter';
/** Angular dependency tracking for kernel-owned locations. */
export declare const ANGULAR_OBSERVATION_ADAPTER: ObservationAdapter;
