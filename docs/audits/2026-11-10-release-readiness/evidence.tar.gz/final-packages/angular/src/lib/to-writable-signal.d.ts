import { type WritableSignal } from '@angular/core';
import type { Location, NodeAccessor } from '@signal-tree/kernel';
/**
 * Converts a writable SignalTree branch into a WritableSignal, or returns an
 * Angular-native leaf unchanged, for use with any API that expects a
 * `WritableSignal` — e.g. as an Angular
 * Signal Forms model, or the value fed to `SignalFormControl`. (Note: Angular
 * has no `FormControl.connect(signal)` API — see `signalForm()` for the
 * signal-native forms bridge.)
 *
 * Branch adaptation creates a two-way binding between the NodeAccessor and a
 * WritableSignal:
 * - Reads all leaf values from the NodeAccessor and exposes them as a signal
 * - Writes to the WritableSignal update the underlying NodeAccessor
 *
 * **Important**: Branch adaptation and `{ undoable: true }` wrappers use
 * `effect()` internally for synchronization, which requires an injection
 * context. Passing an ordinary native leaf without options returns it directly
 * and needs no injection context. This function can be called in:
 * - Component/directive/pipe class field initializers
 * - Component/directive/pipe constructors
 * - Functions called from within an injection context
 *
 * @template T - The type of the node value
 * @param node - The branch accessor or writable leaf to expose
 * @returns The native leaf or a WritableSignal synchronized with the branch
 *
 * @example
 * ```typescript
 * const tree = signalTree({
 *   user: { name: '', email: '' }
 * });
 *
 * // Convert a slice to a WritableSignal (e.g. a Signal Forms model)
 * const userSignal = toWritableSignal(tree.$.user);
 *
 * // A leaf is already native; this returns the same object.
 * const nameSignal = toWritableSignal(tree.$.user.name);
 * ```
 */
export declare function toWritableSignal<T>(node: NodeAccessor<T> | Location<T> | WritableSignal<T>, injector?: unknown, options?: {
    /**
     * Mark writes ENTERING through this adapter as designating their authored
     * causal turn undoable — the same designation {@link undoable} applies, for
     * the case where there is no callback to wrap.
     *
     * Earned by evidence: Angular Signal Forms' `FormField` directive performs
     * the model write from inside its own DOM listener, so an application never
     * gets a callback around a user's edit. The adapter is the only place it
     * still controls.
     *
     * This is INGRESS designation, not location scoping. Eligibility follows the
     * mutation entrance, so a write to the SAME branch through an ordinary tree
     * handle stays non-undoable — the property that distinguishes this from
     * marking a branch "historical", and it has its own control test.
     *
     * ```ts
     * const model = toWritableSignal(tree.$.editForm, injector, {
     *   undoable: true,
     * });
     * const f = form(model);   // user edits are now undoable operations
     * ```
     */
    undoable?: boolean;
}): WritableSignal<T>;
