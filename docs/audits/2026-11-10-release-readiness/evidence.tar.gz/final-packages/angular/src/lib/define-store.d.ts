import { type Type } from '@angular/core';
import type { ISignalTreeOf, ReadonlyStoreOf } from '@signal-tree/kernel/adapter';
/**
 * Config for {@link defineStore}.
 */
export interface DefineStoreConfig {
    /**
     * `'root'` provides an application singleton. `'platform'` shares the store
     * across applications on that platform; do not use it for request-local state.
     * Omit/`null` to provide it locally via a component/route `providers` array.
     */
    providedIn?: 'root' | 'platform' | null;
    /**
     * `'readonly'` narrows the injected type to {@link ReadonlyStore} — sugar
     * over `asReadonly(tree)` (the primary readonly surface, from
     * `@signal-tree/kernel`): read-only `$` over the tree's **accumulated** type
     * (leaf `Signal` reads, derived computeds preserved, marker surfaces
     * narrowed to their reader allowlists) plus lifecycle
     * (`destroy()`/`destroyed`). This is a **type-only** narrowing:
     * `inject(MyStore)` resolves to the exact same tree object either way, so
     * it does not protect against a deliberate `as any` bypass — it protects
     * the common case where an AI agent or developer reaches for a
     * `.set()`/mutator that simply isn't offered on the injected type. Use it
     * when every consumer of this token should receive a readonly tree. An Ops
     * service injecting this same token is also readonly. For separate readers
     * and writers, own one writable tree and expose a non-owning readonly `$`
     * token; see the Angular package README's ownership example.
     *
     * Only accepted when the factory returns a real tree
     * (`signalTree(...)`-shaped); combining it with
     * a plain-object factory is a compile error rather than a silent no-op.
     */
    expose?: 'readonly';
}
/**
 * Wrap a `signalTree(...)` factory in an injectable Angular service class — the
 * idiomatic Angular DI pattern for a tree, comparable to NgRx SignalStore's
 * `signalStore()`.
 *
 * `inject(MyStore)` resolves to the **real tree** — with `$` and any
 * configured enhancer methods — not a wrapper. The tree's
 * `destroy()` is tied to the host injector's lifecycle via `DestroyRef`, so a
 * component-provided store tears down with the component and a root store with
 * the app.
 *
 * The factory runs inside Angular's injection context, so it may call `inject()`
 * (e.g. to read other services). Return a fresh owned object or function for
 * each providing injector, never a tree borrowed from another owner. The
 * factory selects the realization: import `signalTree` from this Angular
 * facade, not the neutral kernel. Use ordinary DI aliases for borrowed views;
 * another `defineStore` would register another destruction owner.
 *
 * Primitive factory results are rejected. If the returned object has a
 * `destroy()` method, failures are reported with Angular's default `ErrorHandler`,
 * not resolved from DI: an application handler may itself depend on this store,
 * and the owning injector is already destroyed when cleanup runs. Reporting
 * allows sibling cleanup to continue. SignalTree destruction is idempotent.
 *
 * @example
 * ```ts
 * import { signalTree, defineStore } from '@signal-tree/angular';
 *
 * export const CounterStore = defineStore(() =>
 *   signalTree({ count: 0 })
 * );
 *
 * // App-wide singleton:
 * export const SettingsStore = defineStore(
 *   () => signalTree({ theme: 'light' }),
 *   { providedIn: 'root' }
 * );
 *
 * @Component({ providers: [CounterStore] })
 * export class Counter {
 *   readonly store = inject(CounterStore);
 *   inc() { this.store.$.count((n) => n + 1); }
 * }
 * ```
 *
 * @example Read-only injection
 * ```ts
 * export const CounterStore = defineStore(
 *   () => signalTree({ count: 0 }),
 *   { expose: 'readonly' }
 * );
 *
 * @Component({ providers: [CounterStore] })
 * export class Display {
 *   readonly store = inject(CounterStore);
 *   read() { return this.store.$.count(); } // ✅ read-only
 *   // this.store.$.count(1);               // ❌ type error — not on ReadonlyStore
 * }
 * ```
 */
export declare function defineStore<T, A>(factory: () => ISignalTreeOf<T, 'angular', A>, config: DefineStoreConfig & {
    expose: 'readonly';
}): Type<ReadonlyStoreOf<T, A, 'angular'>>;
/**
 * Fallback overload. `expose?: undefined` means a config variable WIDENED to
 * {@link DefineStoreConfig} matches neither overload — pass a config object
 * literal (or `as const`). Deliberate: this cliff is what makes
 * `expose: 'readonly'` misuse a compile error instead of a silent no-op.
 */
export declare function defineStore<R extends object>(factory: () => R, config?: DefineStoreConfig & {
    expose?: undefined;
}): Type<R>;
