interface SignalTreeReactOwner<TRoot extends object> {
    readonly $: TRoot;
    readonly destroyed: () => boolean;
}
type SignalTreeSelector<TRoot extends object, TSelected> = (root: TRoot) => TSelected;
/**
 * Observe one owner-relative projection of canonical SignalTree truth.
 *
 * The selector must return an Object.is-stable value while its selected truth
 * is unchanged. Whole-root observation is explicit: `useSignalTree(tree, ($) =>
 * $())`.
 */
export declare function useSignalTree<TRoot extends object, TSelected>(owner: SignalTreeReactOwner<TRoot>, selector: SignalTreeSelector<TRoot, TSelected>): TSelected;
export {};
