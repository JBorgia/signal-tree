import hashlib,json,os,pathlib,shutil,subprocess,time

root=pathlib.Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-release-readiness')
q=pathlib.Path(pathlib.Path('/private/tmp/st-v16-readiness-path').read_text().strip())
os.chdir(root)
env={**os.environ,'NX_DAEMON':'false','NX_ISOLATE_PLUGINS':'false','NG_BUILD_MAX_WORKERS':'1'}
receipts=[]
def run(name,command,allowed=(0,),extra=None):
 start=time.time()
 with (q/(name+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**env,**(extra or {})})
 receipt={'name':name,'command':command,'exit':result.returncode,'startedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),'seconds':time.time()-start}
 receipts.append(receipt);(q/'qualification-sequence.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
 assert result.returncode in allowed, name
 return result.returncode
def source_hashes():
 names=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
 return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names if name and (root/name).is_file()}

before=source_hashes()
(q/'pre-mutation-source.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'files':before},indent=2)+'\n')
run('qualification-mutation',['node','tools/verify-gates.mjs','--self-test','--release'])
after=source_hashes();assert before==after,'mutation source restoration mismatch'
(q/'mutation-restoration.json').write_text(json.dumps({'filesVerified':len(before),'unchanged':True},indent=2)+'\n')
assert (root/'dist').resolve()==root/'dist'
shutil.rmtree(root/'dist')
run('post-mutation-build',['pnpm','run','build:all','--skip-nx-cache','--parallel=1'])
binding=json.loads((q/'candidate-artifact-binding.json').read_text())['files']
actual={str(p.relative_to(root/'dist/packages/kernel')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'dist/packages/kernel').rglob('*') if p.is_file()}
assert actual==binding,'post-mutation kernel differs from measured candidate'
(q/'post-mutation-kernel-equivalence.json').write_text(json.dumps({'filesVerified':len(actual),'byteIdenticalToMeasuredCandidate':True},indent=2)+'\n')
for name in ['tarball-consumer','consumer-typecheck','angular-aot-consumer']:
 run('final-'+name,['node','tools/verify-'+name+'.mjs'])
run('final-coordinated-selftest',['node','tools/release-economics/coordinated.mjs','selftest',str(root/'dist/packages/kernel'),'1000'])
run('final-retention-diagnostic',['node','--expose-gc','tools/release-economics/retention-diagnostic.mjs','suite',str(root),str(q)])
retention=json.loads((q/'retention-diagnostic/summary.json').read_text())
assert all(r['collected'] and all(v['collected'] for v in r['collected']) for r in retention if r['arm']=='packed')
old=pathlib.Path(pathlib.Path('/private/tmp/st-v16-release-economics-path').read_text().strip())
w=q/'witnesses';shutil.copytree(old/'witnesses',w,ignore=shutil.ignore_patterns('*.err','*.json'))
shutil.copy2(old/'witnesses/clone-reentry-review-base.json',w/'clone-reentry-review-base.json')
for name in ['built-witnesses','public-reentry','clone-reentry-review','frame-packet-witness']:
 run('final-'+name,['node',str(w/(name+'.mjs')),str(root/'dist/packages/kernel/dist')])
run('final-counter',['node',str(w/'replay/counter-child.mjs'),'repaired',str(root/'dist/packages/kernel/dist/index.js')])
counter=json.loads((q/'final-counter.log').read_text());assert all(row['passesOriginalBound'] for row in counter['rows'])
run('demo-production-strict',['pnpm','nx','build','demo','--configuration=production','--skip-nx-cache'],allowed=(0,1))
project=root/'apps/demo/project.json';original=project.read_bytes();config=json.loads(original)
try:
 config['targets']['build']['configurations']['production']['budgets']=[]
 project.write_text(json.dumps(config,indent=2)+'\n')
 run('demo-production-size-disposition',['pnpm','nx','build','demo','--configuration=production','--skip-nx-cache'])
finally:project.write_bytes(original)
assert source_hashes()==before,'production review override restoration mismatch'
run('production-browser',['pnpm','exec','playwright','test','--config','scripts/playwright/route-smoke.config.ts','--workers=1','--retries=0'],allowed=(0,1),extra={'CI':'true'})
print('Sequence complete; review every expected size failure before closure.',flush=True)
