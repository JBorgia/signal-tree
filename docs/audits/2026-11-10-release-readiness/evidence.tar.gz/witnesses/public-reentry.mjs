import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
globalThis.ngDevMode = false;
const directory = pathToFileURL(process.argv[2] + '/').href;
const {signalTree,entityMap} = await import(directory + 'index.js');
const {getEntityPublicationBinding} = await import(directory + 'lib/internals/entity-publication.js');
const tree = signalTree({rows:entityMap()});
const rows = tree.$.rows;
const source = getEntityPublicationBinding(rows).source;
let armed = true, unsubscribe, saved, subjects, enrolledAt;
const payload = new Proxy({id:'a',n:1}, {
  getOwnPropertyDescriptor(target,key) {
    // Select the callback boundary under test, leaving earlier staging and
    // cloning reflection alone. Both artifacts expose the same module path.
    const stack = armed && new Error().stack;
    if (stack && stack.includes('/lib/experimental-publication/entity.js')) {
      armed = false;
      enrolledAt = stack;
      unsubscribe = source.subscribe({
        prepare(packet, completion) {
          subjects = packet.ordinary;
          saved = completion.facts;
        },
        complete() { throw new Error('refused attempt completed'); },
      });
    }
    return Reflect.getOwnPropertyDescriptor(target,key);
  },
});
try {
  const initial = source.evidence().field(1,'n','physical');
  assert.throws(() => rows.setAll([payload,{id:'b',n:2}]),/recipients changed during preparation/);
  assert.equal(rows.count(),0);
  assert.equal(source.evidence().field(1,'n','physical'),initial);
  assert.equal(subjects.length,2);
  assert.ok(saved?.forEdit);
  unsubscribe();
  rows.setAll([{id:'a',n:7},{id:'b',n:8}]);
  assert.equal(rows.byIdOrFail('a')().n,7);
  assert.equal(rows.byIdOrFail('b')().n,8);
  for (const edit of subjects) {
    const captured = saved.forEdit(edit);
    const proof = captured.field(edit.subject,'n','physical');
    assert.notEqual(proof,initial);
    assert.notEqual(proof,source.evidence().field(edit.subject,'n','physical'));
    assert.equal(proof,captured.field(edit.subject,'n','ordinary'));
  }
  console.log(JSON.stringify({directory,enrolledAt,refused:true,rowsAfterRefusal:0,laterValues:[7,8],savedSubjects:subjects.map(e=>e.subject)}));
} finally {
  unsubscribe?.();
  tree.destroy();
}
