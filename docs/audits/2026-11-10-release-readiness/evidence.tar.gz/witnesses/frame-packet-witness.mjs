import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

globalThis.ngDevMode = false;
const entry = pathToFileURL(process.argv[2] + '/').href;
const { entityMap, signalTree } = await import(entry + 'index.js');
const { getEntityPublicationBinding } = await import(entry + 'lib/internals/entity-publication.js');
const tree = signalTree({ rows: entityMap() });
const rows = tree.$.rows;
const captured = [];
const release = getEntityPublicationBinding(rows).source.subscribe({
  prepare(packet, native) {
    assert.ok(packet.steps);
    if (packet.steps.length === 0) {
      assert.deepEqual(packet.ordinary, []);
      assert.deepEqual(packet.physical, []);
      return undefined;
    }
    const ordered = packet.steps.flatMap(step => step.ordinary);
    assert.equal(ordered.length, packet.ordinary.length);
    for (let i = 0; i < ordered.length; i++) {
      assert.equal(ordered[i], packet.ordinary[i]);
      assert.equal(native.facts.forEdit(ordered[i]), native.facts.forEdit(packet.ordinary[i]));
    }
    captured.push(ordered.map(edit => [
      edit.structural?.kind ?? 'update',
      edit.structural?.key ?? edit.after?.id,
      edit.structural?.beforeSubject ?? null,
      edit.structural?.afterSubject ?? null,
    ]));
    return undefined;
  },
  complete() { throw new Error('capture-only subscriber does not produce a terminal unit'); },
});
try {
  rows.setAll([{ id: 'a', value: 0 }, { id: 'b', value: 0 }, { id: 'c', value: 0 }]);
  rows.setAll([{ id: 'c', value: 1 }, { id: 'd', value: 1 }, { id: 'a', value: 1 }]);
  assert.deepEqual(rows.ids(), ['c', 'd', 'a']);
  assert.deepEqual(rows.all().map(row => row.value), [1, 1, 1]);
  assert.deepEqual(captured.map(ordered => ordered.map(([kind, key]) => [kind, key])), [
    [['add', 'a'], ['add', 'b'], ['add', 'c']],
    [['remove', 'b'], ['update', 'c'], ['update', 'a'], ['add', 'd']],
  ]);
  console.log(JSON.stringify(captured));
} finally {
  release();
  tree.destroy();
}
