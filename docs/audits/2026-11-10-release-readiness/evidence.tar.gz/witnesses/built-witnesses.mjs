import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

globalThis.ngDevMode = false;
const entry = pathToFileURL(process.argv[2] + '/').href;
const { entityMap, signalTree, transactions, link } = await import(entry + 'index.js');
const { getEntityPublicationBinding, EntityPublicationSource } = await import(entry + 'lib/internals/entity-publication.js');
const { installTerminalRecord } = await import(entry + 'lib/internals/intrinsic-mutation.js');
const { getPathNotifier } = await import(entry + 'lib/path-notifier.js');
const flush = async () => {
  getPathNotifier().flushSync();
  for (let i = 0; i < 160; i++) await Promise.resolve();
};
const results = [];
for (const width of [3, 4, 8, 32]) {
  for (const settle of ['confirm', 'rollback']) {
    const tree = signalTree({ rows: entityMap() });
    const foreign = signalTree({ z: 0 }, { enhancers: [transactions()] });
    const rows = tree.$.rows;
    const seed = { id: 'a', x: 0, y: 0 };
    const initialWidth = width === 4 ? 3 : width;
    for (let i = 3; i < initialWidth; i++) seed['w' + i] = i;
    let reader;
    try {
      rows.setAll([seed]);
      const owner = foreign.transact(() => foreign.$.z(7));
      const before = owner.inspect();
      for (let i = 1; i <= 64; i++) {
        rows.updateOne('a', { x: i });
        assert.equal(rows.byIdOrFail('a')().x, i);
      }
      const expected = { ...seed, x: 64, y: 8 };
      if (width === 4) {
        rows.updateOne('a', { extra: 1 });
        expected.extra = 1;
        assert.equal(rows.byIdOrFail('a')().extra, 1);
      }
      const sent = [];
      reader = link(rows, { set(value) { sent.push(value); } });
      reader.declare({ kind: 'independent' }, () => rows.updateOne('a', { y: 8 }));
      await flush();
      assert.deepEqual(sent, []);
      assert.deepEqual(owner.inspect(), before);
      owner[settle]();
      await flush();
      await reader.settled();
      assert.deepEqual(sent, [[expected]]);
      assert.deepEqual(rows.byIdOrFail('a')(), expected);
      results.push({ lateReader: width, settle });
    } finally {
      reader?.dispose();
      tree.destroy();
      foreign.destroy();
    }
  }

  const tree = signalTree({ rows: entityMap() });
  const rows = tree.$.rows;
  const { source } = getEntityPublicationBinding(rows);
  try {
    let previous;
    for (let generation = 0; generation < 16; generation++) {
      const value = { id: 'same', x: generation, y: 0 };
      for (let i = 3; i < (width === 4 ? 3 : width); i++) value['w' + i] = i;
      rows.setAll([value]);
      if (width === 4) rows.updateOne('same', { extra: 1 });
      const current = rows.byIdOrFail('same');
      const { subject } = getEntityPublicationBinding(current);
      assert.equal(current().x, generation);
      assert.notEqual(subject, previous);
      previous = subject;
      assert.equal(source.inspect().presence, 1);
      assert.equal(source.inspect().fields, width);
      rows.removeOne('same');
      await flush();
      assert.equal(current(), undefined);
      for (const key of ['fields', 'viewFields', 'presence', 'visible', 'mappings', 'mappingViews', 'retirementRequests']) {
        assert.equal(source.inspect()[key], 0, key);
      }
    }
    results.push({ retireAndReuse: width, generations: 16 });
  } finally {
    tree.destroy();
  }
}

for (const width of [3, 8]) {
  for (const next of [0, 7]) {
    let prepare;
    const source = new EntityPublicationSource(point => { prepare = point; });
    const install = unit => {
      assert.ok(unit);
      unit.finalize?.();
      unit.validate?.();
      installTerminalRecord(unit.record);
      source.complete(unit.completion);
    };
    try {
      const row = { x: 0 };
      for (let i = 1; i < width; i++) row['w' + i] = i;
      const add = { subject: 1, before: undefined, after: row, fields: Object.keys(row),
        structural: { kind: 'add', subject: 1, key: 1, value: row } };
      install(source.prepare({ owner: 0, id: {}, ordinary: [add], physical: [add] }));
      const after = { ...row, x: next };
      const unit = prepare({ owner: 0, id: {}, subject: 1, fields: ['x'],
        ordinaryBefore: row, ordinaryAfter: after, physicalBefore: row, physicalAfter: after });
      const plan = source.native.prepareRetirement(1);
      assert.ok(plan.current());
      const before = source.evidence().field(1, 'x', 'ordinary');
      install(unit);
      assert.notEqual(source.evidence().field(1, 'x', 'ordinary'), before);
      assert.equal(plan.current(), false);
      results.push({ lateRetirementPlan: width, value: next });
    } finally {
      source.dispose();
    }
  }
}
console.log(JSON.stringify({ entry, results }, null, 2));
