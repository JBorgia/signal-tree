import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
globalThis.ngDevMode = false;
const directory = pathToFileURL(process.argv[2] + '/').href;
const {signalTree,entityMap,transactions} = await import(directory + 'index.js');
const {getEntityPublicationBinding} = await import(directory + 'lib/internals/entity-publication.js');
const tree = signalTree({rows:entityMap()},{enhancers:[transactions()]});
const rows = tree.$.rows;
const source = getEntityPublicationBinding(rows).source;
const captures = [];
const off = source.subscribe({
  prepare(packet) {
    captures.push({ordinary:packet.ordinary.map(x=>[x.structural?.kind,x.structural?.key]),
      physical:packet.physical.map(x=>[x.structural?.kind,x.structural?.key])});
  },
  complete(){},
});
let reads = 0, innerFailure;
const getter = {id:'a',get n(){
  if (++reads === 2) {try{rows.setAll([{id:'inner',n:8},{id:'b',n:9}]);}catch(err){innerFailure=String(err);}}
  return 1;
}};
let failure;
try {
  try { rows.setAll([getter,{id:'b',n:2}]); }
  catch (err) { failure = String(err); }
  const live = rows.all();
  assert.deepEqual(live,[{id:'inner',n:8},{id:'b',n:9}]);
  assert.match(failure,/reentered installation/);
  assert.equal(captures.length,2);
  console.log(JSON.stringify({failure,live,captures,reads}));
} finally {
  off();
  tree.destroy();
}
