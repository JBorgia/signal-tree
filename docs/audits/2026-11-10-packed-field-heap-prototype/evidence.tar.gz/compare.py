import hashlib, json, pathlib, statistics, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
node=sys.argv[1]
arms={'C':root/'candidate-kernel/dist','P':root/'prototype-kernel/dist'}
sources=[root/'measure.mjs',root/'heap-quiescence.mjs',root/'cost/harness/child.mjs',pathlib.Path(__file__)]
def inputs():
    files=sources+[p for arm in arms.values() for p in sorted(arm.rglob('*')) if p.is_file()]
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
profiles=[('heap',1000),('cpu',100),('point',1000)]
schedule=[(mode,n,arm) for mode,n in profiles for arm in 'CCCPPC CPPC CP'.replace(' ','')]
# Two C controls, followed by five alternating CP/PC pairs.
assert len(schedule)==36
runs=root/'runs'; runs.mkdir()
before=inputs()
(runs/'plan.json').write_text(json.dumps(dict(schedule=schedule,node=node,inputs=before,
    decision='Report raw ranges and medians; resolved only if ranges do not overlap and median delta exceeds largest A/A or arm range. Populated live-minus-baseline heap is primary; bulk phase and point CPU are diagnostics. No retries.'),indent=2))
values={}
for i,(mode,n,arm) in enumerate(schedule):
    out=runs/f'{i:02}-{mode}-{n}-{arm}'
    with out.with_suffix('.log').open('w') as log:
        args=[node,'--expose-gc','--max-old-space-size=768']
        if mode in ('cpu','heap'):
            args += [str(root/'measure.mjs'),str(arms[arm]),mode,str(n),str(out)]
        else:
            args += [str(root/'cost/harness/child.mjs'),str(arms[arm]),mode,str(n)]
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=75)
    d=json.loads(out.with_suffix('.json' if mode in ('cpu','heap') else '.log').read_text())
    slot='AA' if i%12<2 else arm
    row=values.setdefault(f'{mode}-{n}',{}).setdefault(slot,[])
    row.append({'liveMinusBaseline':d['live']['heapUsed']-d['baseline']['heapUsed']} if mode=='heap' else {'sync':sum(d['syncCpu'].values())/1000,'populate':d['phases']['populate']['cpu']/1000} if mode=='cpu' else
               {'sync':sum(d['timing']['syncCpu'].values())/1000,'total':sum(d['timing']['totalCpu'].values())/1000})
    print(i,mode,n,arm,row[-1],flush=True)
assert inputs()==before
summary={}
for profile, groups in values.items():
    summary[profile]={}
    for key in groups['C'][0]:
        a,c,p=([item[key] for item in groups[arm]] for arm in ('AA','C','P'))
        cm,pm=map(statistics.median,(c,p))
        envelope=max(max(x)-min(x) for x in (a,c,p))
        direction='lower' if max(p)<min(c) and cm-pm>envelope else 'higher' if max(c)<min(p) and pm-cm>envelope else 'unresolved'
        summary[profile][key]={'AA':a,'C':c,'P':p,'CMedian':cm,'PMedian':pm,'deltaPct':100*(pm/cm-1),'direction':direction}
(runs/'summary.json').write_text(json.dumps(summary,indent=2))
