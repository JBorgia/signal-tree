import assert from 'node:assert/strict';
import {Session} from 'node:inspector/promises';
import {writeHeapSnapshot} from 'node:v8';
import {cpus, freemem, loadavg} from 'node:os';
import {performance} from 'node:perf_hooks';
import {writeFileSync} from 'node:fs';
import {quiesce} from './heap-quiescence.mjs';

globalThis.ngDevMode = false;
const [directory, mode, sizeText, prefix] = process.argv.slice(2);
const size = Number(sizeText);
const {signalTree, entityMap, transactions} = await import(directory + '/index.js');
const fields = () => Object.fromEntries(Array.from({length:16}, (_, i) => ['f' + i, 0]));
const seed = () => Array.from({length:size}, (_, i) => ({id:String(i), name:'row' + i, value:0}));
const drain = () => new Promise(setImmediate);
const checkpoint = () => ({cpu:process.cpuUsage(), wall:performance.now()});
const phases = ['input', 'create', 'populate', 'verify', 'destroy'];
const env = () => ({load:loadavg(),free:freemem()});
const out = {directory, mode, size, node:process.version, cpu:cpus()[0].model, start:env()};
function batch(count, measure) {
  const phase = Object.fromEntries(phases.map(name=>[name,{cpu:0,wall:0}]));
  const mark = () => measure ? checkpoint() : undefined;
  const record = (name, start) => {
    if (!start) return;
    const wall = performance.now() - start.wall;
    const cpu = process.cpuUsage(start.cpu);
    phase[name].wall += wall;
    phase[name].cpu += cpu.user + cpu.system;
  };
  for (let i=0; i<count; i++) {
    let at=mark();
    const shape = {fields:fields(), rows:entityMap()};
    const data = seed();
    record('input',at);
    at=mark();
    const tree = signalTree(shape);
    record('create',at);
    try {
      at=mark();
      if (size) tree.$.rows.setAll(data);
      record('populate',at);
      at=mark();
      assert.equal(tree.$.rows.count(),size);
      assert.equal(tree.$.fields.f15(),0);
      record('verify',at);
    } finally {
      at=mark();
      tree.destroy();
      record('destroy',at);
    }
  }
  return phase;
}
function createHeld(mode) {
  return Array.from({length:10}, () => {
    const tree = signalTree({fields:fields(),rows:entityMap()}, mode === 'pending' ? {enhancers:[transactions()]} : undefined);
    if (size) tree.$.rows.setAll(seed());
    assert.equal(tree.$.rows.count(),size);
    return tree;
  });
}
if (mode === 'cpu' || mode === 'profile') {
  const count = size >= 1000 ? 30 : 200;
  batch(Math.max(3,count/10),false);
  await drain(); await drain();
  const session = mode === 'profile' ? new Session() : undefined;
  if (session) {
    session.connect();
    await session.post('Profiler.enable');
    await session.post('Profiler.setSamplingInterval',{interval:200});
    await session.post('Profiler.start');
  }
  const start = checkpoint();
  out.phases = batch(count,mode==='cpu');
  out.syncWallMs = performance.now()-start.wall;
  out.syncCpu = process.cpuUsage(start.cpu);
  out.count = count;
  if (session) {
    const {profile} = await session.post('Profiler.stop');
    writeFileSync(prefix+'.cpuprofile',JSON.stringify(profile));
    session.disconnect();
  }
  await drain(); await drain();
  out.totalCpu = process.cpuUsage(start.cpu);
} else {
  out.baseline = await quiesce();
  let held = createHeld(mode);
  const weak = held.map(tree=>new WeakRef(tree));
  out.live = await quiesce();
  if (mode==='snapshot') writeHeapSnapshot(prefix+'.heapsnapshot');
  if (mode==='pending') {
    const row = tree=>tree.$.rows.byIdOrFail('0')();
    for (const tree of held) assert.equal(row(tree).value,0);
    out.primed = await quiesce();
    const owners = held.map(tree=>{
      const a=tree.transact(()=>tree.$.rows.updateOne('0',{value:1}));
      const b=tree.transact(()=>tree.$.rows.updateOne('0',{value:2}));
      assert.equal(row(tree).value,2);
      return [a,b];
    });
    out.pending = await quiesce();
    owners.forEach(([a,b],i)=>{
      b.rollback(); assert.equal(row(held[i]).value,1);
      a.rollback(); assert.equal(row(held[i]).value,0);
    });
    owners.length=0;
    out.settled = await quiesce();
  }
  held.forEach(tree=>tree.destroy());
  held=[];
  out.destroyed = await quiesce();
  out.weakAlive = weak.filter(r=>r.deref()!==undefined).length;
  assert.equal(out.weakAlive,0);
}
out.end=env();
writeFileSync(prefix+'.json',JSON.stringify(out,null,2));
