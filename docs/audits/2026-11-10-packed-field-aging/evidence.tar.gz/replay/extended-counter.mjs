import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { countIteratedElements } from './original-counter.mjs';
globalThis.ngDevMode = false;
const dist = process.argv[2];
const entry = pathToFileURL(dist + '/index.js').href;
const { signalTree, entityMap } = await import(entry);
const packedModule = dist + '/lib/experimental-publication/packed-field-row.js';
const packed = existsSync(packedModule)
  ? (await import(pathToFileURL(packedModule).href)).PackedFieldRow.prototype
  : undefined;
const iterate = packed?.[Symbol.iterator];
let packedVisits = 0;
if (packed) {
  packed[Symbol.iterator] = function* () {
    for (const value of iterate.call(this)) {
      packedVisits++;
      yield value;
    }
  };
}
function run(width, count, promote) {
  const tree = signalTree({ rows: entityMap() });
  const rows = tree.$.rows;
  try {
    rows.setAll(Array.from({ length: count }, (_, i) => {
      const row = { id: String(i), value: 0 };
      for (let j = 2; j < width; j++) row['w' + j] = j;
      return row;
    }));
    const patch = promote ? { extra: 1 } : { value: 1 };
    packedVisits = 0;
    const originalVisits = countIteratedElements(() => {
      for (let i = 0; i < 200; i++) rows.updateOne(String(i), patch);
    });
    const slotVisits = packedVisits;
    for (let i = 0; i < 200; i++) assert.equal(rows.byIdOrFail(String(i))()[promote ? 'extra' : 'value'], 1);
    assert.equal(rows.byIdOrFail('201')()[promote ? 'extra' : 'value'], promote ? undefined : 0);
    return { width, count, promote, originalVisits, slotVisits };
  } finally {
    tree.destroy();
  }
}
const results = [];
try {
  for (const [width, promote] of [[3,false],[8,false],[32,false],[3,true]]) {
    const a = run(width, 2000, promote);
    const b = run(width, 20000, promote);
    assert.equal(a.originalVisits, b.originalVisits);
    assert.equal(a.slotVisits, b.slotVisits);
    results.push(a, b);
  }
} finally {
  if (packed) packed[Symbol.iterator] = iterate;
}
console.log(JSON.stringify({ entry, results }, null, 2));
