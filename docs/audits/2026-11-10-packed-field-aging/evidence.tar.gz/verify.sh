#!/bin/bash
set -euo pipefail
q=$(cd "$(dirname "$0")" && pwd)
for arm in candidate prototype; do
  d="$q/$arm-kernel/dist"
  node --max-old-space-size=768 "$q/replay/counter-child.mjs" "$arm" "$d/index.js" > "$q/$arm-counter.json" 2> "$q/$arm-counter.log"
  node -e 'const r=require(process.argv[1]); if(r.rows.length!==2 || !r.rows.every(x=>x.passesOriginalBound))process.exitCode=1' "$q/$arm-counter.json"
  node --max-old-space-size=768 "$q/replay/extended-counter.mjs" "$d" > "$q/$arm-extended.json" 2> "$q/$arm-extended.log"
  node "$q/public-reentry.mjs" "$d" > "$q/$arm-reentry.json" 2> "$q/$arm-reentry.log"
  node "$q/built-witnesses.mjs" "$d" > "$q/$arm-witnesses.json" 2> "$q/$arm-witnesses.log"
done
NX_DAEMON=false NX_ISOLATE_PLUGINS=false pnpm nx test kernel --skip-nx-cache --maxWorkers=1 integrated-late-history packet-physical-pair-semantics saved-inspection-snapshot-isolation fixed-window-retirement entity-large-batches-v16-controls entity-set-all-staging entity-granular-reactivity integrated-field-facts packet-index-adversarial publication-retirement-boundaries publication-retirement-acceptance singleton-row-reuse packed-field-heap fast-point-dual-map > "$q/source-witnesses.log" 2>&1
