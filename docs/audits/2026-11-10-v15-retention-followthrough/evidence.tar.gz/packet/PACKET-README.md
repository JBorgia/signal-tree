# SignalTree v15/v16 follow-through evidence

This shared packet contains first failures, source controls, preregistered
measurements, exact copied packages, final served demo builds, local qualification
receipts and Linux retention/cleanup output. `qualification-summary.json` binds
commands, exits and sources. It is a record of executed work, not an instruction
to publish existing 15.4.4 or development versions.

`input-payloads/bindings.json` resolves all 2,526 registered input references by
content hash. Earlier copies are retained when a path was reused. Payloads for
both the predecessor and successor remain separate. `final-artifacts/manifest.json`
binds the post-mutation clean artifacts and the demo output used by Playwright.
The ordinary comparison's stale embedded policy label is preserved and clarified
by `final-ordinary/provenance-clarification.json`.

`checks/` contains commands, raw logs and source-at-completion receipts. The
mutation manifests verify source restoration; they are not complete Git objects.
`linux-ci/evidence.zip` matches GitHub's archive digest and `linux-ci/raw/` preserves
its payloads. Linux scope is the revised v15 retention control and direct cleanup,
not an unexecuted full Linux registry.

Node 24.15.0 and pnpm 10.17.0 are required. Historical absolute paths in registrations
are evidence of the original runs. Replaying in another checkout requires adapting
paths and installing the recorded dependency closure; the archive verifier does
not execute tests or establish identical results on every host. Repository commits
supply the surrounding source and build configuration. npm cache, transient Angular
cache and external dependency symlinks are omitted; registered input payloads are
resolved separately by hash. No complete repository-history claim is made.
