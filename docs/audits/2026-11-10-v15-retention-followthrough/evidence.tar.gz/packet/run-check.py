import os,sys,time,json,subprocess
from pathlib import Path
packet=Path(__file__).resolve().parent
label=sys.argv[1]
cmd=sys.argv[2:]
assert cmd and '/' not in label
out=packet/'checks'
out.mkdir(exist_ok=True)
log=out/(label+'.log')
assert not log.exists(), 'Preserve previous attempts'
start=time.time()
print('Starting '+label,flush=True)
with log.open('w') as f:
    result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
receipt={'label':label,'cwd':os.getcwd(),'command':cmd,'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'startedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),'seconds':time.time()-start,'exit':result.returncode}
(out/(label+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
sys.exit(result.returncode)
