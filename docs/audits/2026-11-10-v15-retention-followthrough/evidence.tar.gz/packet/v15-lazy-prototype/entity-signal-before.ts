import { defineEntityObservation } from './internals/entity-observation';
import {
  defineEntityMembershipInventory,
  defineEntityMembershipSource,
  type EntityMembershipChange,
  type EntityMembershipInventory,
  type EntityMembershipUnit,
} from './internals/entity-membership-inventory';

import { getPositionRegistry } from './internals/position-registry';
import type {
  Location,
  ReadableCell,
  WritableCell,
} from './internals/cell-runtime';
import type { EpochHandle } from './internals/observation-adapter';
import {
  createWritableProjection,
  deriveLocation,
  NEUTRAL_LOCATION_RUNTIME,
  replaceLocation,
  type LocationRuntime,
} from './internals/location-runtime';
import { deepClone } from './internals/utilities/deep-clone';
import { deepEqual } from './internals/utilities/deep-equal';

import {
  EntityMutationFrame,
  type PreparedFreshSubject,
  type PreparedKeyTransfer,
  type PreparedRetainedValueRetirement,
  type PreparedSubjectRestore,
  type PreparedSubjectTombstone,
  type PreparedValueReplacement,
} from './physical/entity-mutation-frame';
import { resolveEntityHandle } from './physical/entity-handle-resolution';
import { EntityValueStore } from './physical/entity-value-store';
import {
  StructuralStore,
  type AcquiredSubjectHandle,
  type SubjectLifetimeRecord,
} from './physical/structural-store';
import { defineOwnedOwnerPath, defineOwnedPositionIds } from './internals/owned-mutation';
import type { PhysicalCommitClock } from './internals/physical-commit-clock';
// Only `notify` is ever called on this — the neutral port contract, not the
// delivery engine's full surface.
import type { PathObservationPort } from './internals/path-observation-port';
import {
  getActiveWriteContext,
  isRecordedReplayWrite,
  runUserCallback,
} from '../lib/write-context';

import { recordProductionSubstrateStat } from './internals/production-substrate-stats';
import {
  defineEntityProjectionSeed,
  type EntityProjectionOrder,
} from './internals/entity-projection-seed';
import { markOwnerInvalidated } from './internals/owner-invalidation-port';
import {
  inStructuralWrite,
  isAbsentMember,
  MEMBERSHIP_CHANGED,
  reactivatePathOnWrite,
  structuralWrites,
} from './internals/member-membership';
import { physicalRows, taps } from './internals/physical-rows';
import type {
  CommittedEntityMutation,
  MutationCaptureRuntime,
} from './internals/mutation-capture-runtime';
import type {
  CollectionTransitionTarget,
  CollectionTransitionTargetBinding,
} from './internals/causal-runtime/target-transition';
import { appendAll } from './internals/utilities/append-all';

/**
 * The port plus an optional observer probe. A port that cannot answer is
 * treated as observed — see `pathObserved()`.
 */
export type EntityObservationPort = PathObservationPort & {
  hasObservers?(): boolean;
};

// Angular's global dev-mode flag (defined by the Angular CLI; undefined in
// plain test/node contexts, treated as dev there).
declare const ngDevMode: boolean | undefined;

/**
 * Wrong entityMap method names AI agents and devs reach for (from other state
 * libraries), mapped to the SignalTree equivalent. Used by a dev-mode proxy
 * guardrail to turn a cryptic "undefined is not a function" into an actionable
 * hint. Sourced from the documented cross-library hallucination table.
 */
const WRONG_ENTITY_METHODS: Record<string, string> = {
  upsert: 'upsertOne(entity) / upsertMany(entities)',
  add: 'addOne(entity) / addMany(entities)',
  insert: 'addOne(entity)',
  update: 'updateOne(id, changes) / updateMany(ids, changes)',
  remove: 'removeOne(id) / removeMany(ids)',
  delete: 'removeOne(id)',
  getAll: 'all() (a signal)',
  selectAll: 'all() (a signal)',
  selectMany: 'where(predicate)',
  selectEntity: 'byId(id)',
  addEntities: 'addMany(entities)',
  setEntities: 'setAll(entities)',
  setProps: 'set leaves directly — entityMap has no props object',
  next: 'set leaves directly — not an RxJS Subject',
  asObservable: 'use the signal directly — not an RxJS Subject',
};

type EntityPositionIdAllocator = () => number | undefined;
let nextStandaloneEntityPositionId = 1;
const standaloneEntityPositionIdAllocator: EntityPositionIdAllocator = () =>
  nextStandaloneEntityPositionId++;
let entityPositionIdAllocatorOverride: EntityPositionIdAllocator | undefined;
let entityPositionIdNotifyEnabled = true;

/** @internal Bench/test-only hook for owner PositionId allocation experiments. */
// ⚠️ NOT EXPORTED. Used only inside this module; the `export` was surplus.
// (ORPHAN sweep, 15.0. Same-file-only proves the EXPORT is unnecessary — it says
// nothing about who owns the code, and this code is live.)
function setEntityPositionIdAllocatorForTesting(
  allocator?: EntityPositionIdAllocator
): void {
  entityPositionIdAllocatorOverride = allocator;
}

/** @internal Bench/test-only hook to isolate owner-id carriage from stamping. */
// ⚠️ NOT EXPORTED. Used only inside this module; the `export` was surplus.
// (ORPHAN sweep, 15.0. Same-file-only proves the EXPORT is unnecessary — it says
// nothing about who owns the code, and this code is live.)
function setEntityPositionIdNotifyEnabledForTesting(enabled = true): void {
  entityPositionIdNotifyEnabled = enabled;
}

export type EntitySubjectPhysicalInventory<K extends string | number> = {
  subjectId: number;
  state: 'active' | 'tombstoned';
  subjectRevision: number;
  activeKey: K | undefined;
  retainedSubjectState: boolean;
  entitySignal: boolean;
  activationToken: boolean;
  nodeFacadeMaterialized: boolean;
  fieldFacadesMaterialized: readonly string[];
  positionIds: readonly PositionId[] | undefined;
  retainedValueBacking:
    | {
        kind: 'retained-entity-signal';
      }
    | undefined;
};

export type EntitySubjectReclamationResource =
  | 'subject-lifetime-record'
  | 'retained-value-backing'
  | 'subject-activation-channel'
  | 'row-facade'
  | 'field-facades'
  | 'ownership-metadata';

export type EntitySubjectReclamationUnresolved = {
  resource: EntitySubjectReclamationResource;
  reason: 'terminal-facade-dependency-unknown';
};

export type EntitySubjectReclamationPlan = {
  subjectId: number;
  eligible: boolean;
  retire: readonly EntitySubjectReclamationResource[];
  retain: readonly EntitySubjectReclamationResource[];
  unresolved: readonly EntitySubjectReclamationUnresolved[];
};

export type PreparedEntitySubjectReclamation = {
  subjectId: number;
  expectedLifetime: 'tombstoned';
  expectedSubjectRevision: number;
  retire: readonly EntitySubjectReclamationResource[];
  retain: readonly EntitySubjectReclamationResource[];
};

export type EntitySubjectReclamationPlanningOptions = {
  causallyEligible: boolean;
  /**
   * Also drop the subject's LIFETIME RECORD, not just its value bytes.
   *
   * Off by default because the two have different safety arguments. Retiring
   * the value is invisible: nothing reads `backingForSubject` on a tombstoned
   * subject, and every restorer holds its own copy. Forgetting the lifetime is
   * what makes the subject unrestorable, so it needs a caller that has
   * established nothing can still restore it.
   *
   * It is also the only half that BOUNDS retention. The value is ~132 B of the
   * measured 249 B/retired and the lifetime record is the other ~111 B, and the
   * ledger is what grows with every subject the collection has ever retired.
   * A sink that retires only the value leaves a slope — measured, after the
   * first version of this did exactly that and the inventory looked bounded
   * because `__listSubjectReclamationCandidates` only counts value-backed
   * subjects.
   */
  reclaimLifetimeRecord?: boolean;
};

export function planEntitySubjectReclamation<K extends string | number>(
  inventory: EntitySubjectPhysicalInventory<K>,
  options: EntitySubjectReclamationPlanningOptions
): EntitySubjectReclamationPlan {
  const retain: EntitySubjectReclamationResource[] = [];

  if (inventory.retainedSubjectState) {
    retain.push('subject-lifetime-record');
  }
  if (inventory.retainedValueBacking) {
    retain.push('retained-value-backing');
  }
  if (inventory.activationToken) {
    retain.push('subject-activation-channel');
  }
  if (inventory.nodeFacadeMaterialized) {
    retain.push('row-facade');
  }
  if (inventory.fieldFacadesMaterialized.length > 0) {
    retain.push('field-facades');
  }
  if ((inventory.positionIds?.length ?? 0) > 0) {
    retain.push('ownership-metadata');
  }

  if (inventory.state !== 'tombstoned') {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: [],
    };
  }

  if (!options.causallyEligible) {
    return {
      subjectId: inventory.subjectId,
      eligible: false,
      retire: [],
      retain,
      unresolved: [],
    };
  }

  const retire: EntitySubjectReclamationResource[] = [];
  const remaining = [...retain];
  const promote = (resource: EntitySubjectReclamationResource) => {
    retire.push(resource);
    const index = remaining.indexOf(resource);
    if (index !== -1) {
      remaining.splice(index, 1);
    }
  };

  if (inventory.retainedValueBacking) {
    promote('retained-value-backing');
  }
  if (options.reclaimLifetimeRecord && inventory.retainedSubjectState) {
    promote('subject-lifetime-record');
  }

  return {
    subjectId: inventory.subjectId,
    eligible: true,
    retire,
    retain: remaining,
    unresolved: [],
  };
}

/**
 * EntitySignal Implementation (Composition Pattern)
 *
 * Map-based reactive entity collections with:
 * - Full CRUD operations (addOne, updateOne, removeOne, upsertOne)
 * - Query signals (all, count, ids, byId, where, find)
 * - Entity hooks (tap for observation)
 * - Entity interceptors (intercept for blocking/transforming)
 * - Deep signal access (tree.$.users['id'].name())
 *
 * Uses composition (closures) instead of classes to avoid
 * Proxy + class `this` binding issues.
 *
 * @internal
 */

import type {
  EntityConfig,
  EntitySignal,
  TapHandlers,
  InterceptHandlers,
  InterceptContext,
  EntityNode,
  AddOptions,
  AddManyOptions,
  WriteMetadata,
  PositionId,
  StructuralEffect,
} from '../lib/types';
const DORMANT_MEMBERSHIP_UNIT: EntityMembershipUnit = {
  commit: () => undefined,
  cancel: () => undefined,
};
const DORMANT_MEMBERSHIP: Pick<EntityMembershipInventory, 'observed' | 'begin'> = {
  observed: () => false,
  begin: () => DORMANT_MEMBERSHIP_UNIT,
};
/** Neighbours an unobserved removal does not need to look up. */
const NO_NEIGHBORS: { beforeSubject?: number; afterSubject?: number } = {};


/**
 * Creates an EntitySignal using composition pattern.
 * All state is stored in closures - no `this` binding issues possible.
 *
 * @internal
 */

/**
 * True when the subjects present at both endpoints appear in a different
 * relative order. Subjects present at only one endpoint are ignored.
 */
function survivingOrderChanged(
  before: readonly number[],
  after: readonly number[]
): boolean {
  const inAfter = new Set(after);
  const inBefore = new Set(before);
  const survivingBefore = before.filter((subject) => inAfter.has(subject));
  const survivingAfter = after.filter((subject) => inBefore.has(subject));
  return survivingBefore.some(
    (subject, index) => subject !== survivingAfter[index]
  );
}
export function createEntitySignal<
  E extends Record<string, unknown>,
  K extends string | number = string
>(
  config: EntityConfig<E, K>,
  pathNotifier: EntityObservationPort,
  basePath: string,
  options?: {
    physicalCommitClock?: PhysicalCommitClock;
    mutationCaptureRuntime?: MutationCaptureRuntime;
    positionIdAllocator?: EntityPositionIdAllocator;
    ownerMetadataEnabled?: boolean;
    subjectMetadataEnabled?: boolean;
    positionMetadataEnabled?: boolean;
    /**
     * Registry namespace of the tree this collection belongs to.
     *
     * OWNER-REPLAY-2. Collections notify the path notifier DIRECTLY rather than
     * through the owned-write wrapper, so an authored `addOne`/`removeOne`
     * reached subscribers with `ownerId: undefined` while the restoration and
     * rollback replays of the SAME operation carried it. An owner-filtered
     * observer was therefore blind to every authored collection change.
     */
    ownerId?: number;
    locationRuntime?: LocationRuntime;
    /**
     * Whether anything in this tree could restore a subject after it retires.
     *
     * Comes from the finalized build plan (`RuntimeTreePlan`) and cannot change
     * for the life of the tree. `false` is what licenses zero-owner reclamation
     * at the retirement boundary below.
     *
     * DEFAULTS TO TRUE — retain. A collection created outside `signalTree`'s
     * construction path has no plan to consult, and reclaiming a subject some
     * unseen owner could restore is unrecoverable.
     */
    hasRestorationAuthority?: boolean;
  }
): EntitySignal<E, K> {
  const locations = options?.locationRuntime ?? NEUTRAL_LOCATION_RUNTIME;
  // ==================
  // CLOSURE STATE (no `this` needed)
  // ==================

  // Derived materialized projection only.
  // Authoritative structural state lives in structuralStore.
  // Authoritative subject values live in valueStore.

  /**
   * Collection version. Bumped once per mutation; every collection query below
   * derives from it LAZILY.
   *
   * This replaced eager rebuilding, which made a single-entity update O(size).
   * `updateSignals()` used to run on EVERY mutation and do three full copies of
   * the collection — `Array.from(storage.values())`, `Array.from(storage.keys())`
   * and `new Map(storage)` — plus a `.set()` on each derived signal, which then
   * deep-compared them. Measured on a 50,000-row collection: 2.8ms PER
   * `updateOne`, scaling cleanly with size (38us @1k, 510us @10k). That defeats
   * the entire point of a Map-backed entity store, whose storage write is O(1).
   *
   * (It was not the deep equality: shallow comparison measured the same. It was
   * the copying.)
   *
   * Now the copies happen only when a query is actually READ, and Angular's
   * computed caches them until the next mutation — so a grid that reads `all()`
   * once per frame pays once per frame instead of once per write.
   */
  const version = locations.createCell(0);
  /**
   * `SUBJECT-EPOCH-0`. Epochs to advance when the batch flushes.
   *
   * It holds the CELLS, not subject ids, and that is load bearing. `removeOne`
   * runs `tombstoneSubjectSignal` -> `reclaimRetiredSubjectsWithoutOwner` ->
   * `updateSignals`, and the middle step deletes the registry entry. Staging an
   * id means the flush looks up an epoch that no longer exists, skips the
   * advance, and a `computed` that read this row never learns it was removed.
   * Holding the cell keeps the pending invalidation alive across its own
   * reclamation — which is exactly why the map this replaced staged `Location`
   * objects rather than keys.
   *
   * No value is staged: the value is already in `EntityValueStore` before
   * anything lands here, so a copy would be a second truth.
   */
  const pendingSubjectEpochs = new Set<EpochHandle>();

  const createVersionedProjection = <TValue>(
    compute: () => TValue
  ): ReadableCell<TValue> => {
    let projectedVersion = -1;
    let initialized = false;
    let value: TValue;
    return locations.createDerived(() => {
      const currentVersion = version();
      if (!initialized || projectedVersion !== currentVersion) {
        value = compute();
        projectedVersion = currentVersion;
        initialized = true;
      }
      return value;
    });
  };

  /**
   * A query whose predicate is user code. The version-keyed cache above is only
   * right for projections that read nothing but this collection: a predicate
   * may also read another signal, and a cached result would ignore it (and drop
   * the dependency). Reproduced on 15.3.1: `where(r => r.v >= tree.$.min())`
   * kept the old rows after `min` changed. The derived itself memoises on every
   * dependency the predicate reads, plus the collection version read here.
   */
  const createQueryProjection = <TValue>(
    compute: () => TValue
  ): ReadableCell<TValue> =>
    locations.createDerived(() => {
      version();
      return compute();
    });

  function getProjectedEntity(id: K): E | undefined {
    const subjectId = structuralStore.subjectIdForKey(id);
    return subjectId === undefined
      ? undefined
      : valueStore.backingForSubject(subjectId);
  }

  function getProjectedEntries(): Array<readonly [K, E]> {
    const entries: Array<readonly [K, E]> = [];
    for (const id of structuralStore.activeKeysSnapshot()) {
      const entity = getProjectedEntity(id);
      if (entity !== undefined) {
        entries.push([id, entity] as const);
      }
    }
    return entries;
  }

  function getProjectedEntities(): E[] {
    // Value-only projections do not need an intermediate tuple per entity.
    // Keep a fresh array: held snapshots and sorted projections must not share
    // a mutable backing buffer with later reads.
    const entities: E[] = [];
    for (const id of structuralStore.activeKeysSnapshot()) {
      const entity = getProjectedEntity(id);
      if (entity !== undefined) entities.push(entity);
    }
    return entities;
  }

  /**
   * ⚠️ PUBLIC READS ARE ABSENT WHILE THE COLLECTION IS (v16 8e, ported). A
   * collection omitted itself or under an omitted member is an absent, empty
   * collection to every public read and to every write that names a row:
   * "DORMANT STORAGE MUST NOT SUPPLY THE REACTIVATED VALUE"
   * (`whole-value-membership.spec.ts` 18). Its retained rows stay physical
   * truth for restoration and transactions, which keep the `getProjected*`
   * reads. One symbol lookup on a collection that was never under an
   * omission.
   */
  const absent = (): boolean => isAbsentMember(api);
  // Row reads and row writes use physical truth only while a reversal or a
  // rollback is being applied to this collection's tree (`physicalRows`).
  // Projections never do, so nothing they cache can hold retained rows.
  // A tap reads absent-aware even inside the window, unless it started the
  // reversal itself: the window records the tap depth it opened at (v16 8f).
  const rowAbsent = (): boolean => {
    if (!absent()) return false;
    if (!physicalRows.length) return true;
    const registry = getPositionRegistry(api);
    return !physicalRows.some(
      ([open, depth]) => open === registry && depth === taps.depth
    );
  };
  const presentEntity = (id: K): E | undefined =>
    rowAbsent() ? undefined : getProjectedEntity(id);
  const presentEntries = (): Array<readonly [K, E]> =>
    absent() ? [] : getProjectedEntries();
  const presentEntities = (): E[] => (absent() ? [] : getProjectedEntities());

  function acquireEntityHandleForTesting(
    id: K
  ): AcquiredSubjectHandle | undefined {
    return structuralStore.acquireSubjectHandleForKey(id);
  }

  function resolveEntityHandleForTesting(handle: AcquiredSubjectHandle) {
    return resolveEntityHandle(structuralStore, valueStore, handle);
  }

  function rebuildActiveProjectionFromOwners(): ReadonlyMap<K, E> {
    return new Map(getProjectedEntries());
  }

  function createEntityMutationFrame(): EntityMutationFrame<K, E> {
    return new EntityMutationFrame(valueStore, structuralStore);
  }

  function prepareTransitionTarget(target: CollectionTransitionTarget): {
    install(): void;
    preparePublication(): void;
    publish(options?: { advancePhysicalRevision?: boolean }): void;
  } {
    if (positionId === undefined || target.owner !== positionId) {
      throw new Error(
        'Collection transition target owner does not match the binding'
      );
    }

    const currentSubjects = new Map<number, { key: K; value: E }>();
    const activeIdBefore = activeIdSignal();
    const activeSubjectBefore =
      activeIdBefore === undefined
        ? undefined
        : structuralStore.subjectIdForKey(activeIdBefore);
    for (const key of structuralStore.activeKeysSnapshot()) {
      const subjectId = structuralStore.subjectIdForKey(key);
      const value =
        subjectId === undefined
          ? undefined
          : valueStore.backingForSubject(subjectId);
      if (subjectId !== undefined && value !== undefined) {
        currentSubjects.set(subjectId, { key, value });
      }
    }

    const preparedSubjects = target.subjects.map((subject) => {
      if (
        subject.value === null ||
        typeof subject.value !== 'object' ||
        Array.isArray(subject.value)
      ) {
        throw new Error(
          `Collection target subject ${subject.subject} has no entity value`
        );
      }
      return {
        subjectId: subject.subject,
        key: subject.key as K,
        value: deepClone(subject.value) as E,
      };
    });
    const structuralTarget = structuralStore.prepareTarget(
      preparedSubjects,
      target.order,
      target.orderFrontier
    );
    const valueTarget = valueStore.prepareTargetValues(preparedSubjects);
    const affectedSubjects = new Set([
      ...currentSubjects.keys(),
      ...preparedSubjects.map(({ subjectId }) => subjectId),
    ]);
    const preparedBySubject = new Map(
      preparedSubjects.map((subject) => [subject.subjectId, subject])
    );
    const activeIdAfter =
      activeSubjectBefore === undefined
        ? undefined
        : preparedBySubject.get(activeSubjectBefore)?.key;
    const targetNeighborBySubject = new Map(
      target.order.map((subjectId, index) => [
        subjectId,
        {
          beforeSubject: target.order[index - 1],
          afterSubject: target.order[index + 1],
        },
      ])
    );
    const subjectChanges = [...affectedSubjects].map((subjectId) => {
      const before = currentSubjects.get(subjectId);
      const after = preparedBySubject.get(subjectId);
      return {
        subjectId,
        beforeKey: before?.key,
        afterKey: after?.key,
        beforeValue: before?.value,
        valueEpoch: subjectEpochs.get(subjectId),
        stateSignal: subjectStateSignals.get(subjectId)?.deref(),
        afterValue: after?.value,
        bindingChanged: !before || !after || before.key !== after.key,
        targetNeighbors: targetNeighborBySubject.get(subjectId),
      };
    });
    let membershipChanges: EntityMembershipChange[] = [];
    let membershipPublished = false;
    const wasVisible = !absent();
    let publicationPrepared = false;
    const preparePublication = (): void => {
      if (publicationPrepared) return;
      publicationPrepared = true;
      if (activeIdBefore !== activeIdAfter) {
        replaceLocation(activeIdSignal, activeIdAfter);
      }
      // A formerly visible collection can now be omitted. That changes public
      // reads even though writes to already-hidden rows normally publish nothing.
      updateSignals(wasVisible);
      for (const change of subjectChanges) {
        if (change.valueEpoch) advanceEpochHandle(change.valueEpoch);
        if (change.bindingChanged && change.stateSignal) {
          deriveLocation(change.stateSignal, (value) => value + 1);
        }
      }
    };

    return {
      install(): void {
        const unit = beginMembershipUnit();
        try {
          structuralStore.installPreparedTarget(structuralTarget);
          valueStore.installPreparedTargetValues(valueTarget);
          if (membershipInventory.observed()) {
            membershipChanges = subjectChanges.flatMap((change): EntityMembershipChange[] => {
              if (change.afterKey === undefined) return [{ kind: 'remove', lifetimeId: change.subjectId, key: change.beforeKey as K }];
              if (change.beforeKey === undefined) return [{
                kind: 'add', lifetimeId: change.subjectId, key: change.afterKey,
                beforeLifetimeId: change.targetNeighbors?.beforeSubject,
                afterLifetimeId: change.targetNeighbors?.afterSubject,
              }];
              return change.beforeKey !== change.afterKey ? [{ kind: 'rekey', lifetimeId: change.subjectId, beforeKey: change.beforeKey, afterKey: change.afterKey }] : [];
            });
          }
          if (membershipInventory.observed(true)) {
            const before = [...currentSubjects.keys()];
            const survivingBefore = before.filter((id) => preparedBySubject.has(id));
            const survivingAfter = target.order.filter((id) => currentSubjects.has(id));
            if (survivingBefore.some((id, index) => id !== survivingAfter[index])) {
              membershipChanges.push({ kind: 'reorder', before, after: [...target.order] });
            }
          }
        } finally {
          // The coordinator installs all targets before their publish methods.
          // Close this read guard now; deliver the captured deltas in publish.
          unit.commit([]);
        }
      },
      preparePublication,
      publish(options): void {
        // Direct users of a prepared collection also get current views. The
        // aggregate coordinator prepares every target before the first tap.
        preparePublication();
        if (!membershipPublished) {
          membershipPublished = true;
          beginMembershipUnit().commit(membershipChanges);
          membershipChanges = [];
        }
        for (const publication of subjectChanges) {
          const key = publication.afterKey ?? publication.beforeKey;
          if (key === undefined) {
            continue;
          }
          const structuralEffect: StructuralEffect | undefined =
            publication.beforeKey === undefined
              ? {
                  kind: 'add',
                  subject: publication.subjectId,
                  key,
                  value: publication.afterValue,
                  ...publication.targetNeighbors,
                }
              : publication.afterKey === undefined
              ? {
                  kind: 'remove',
                  subject: publication.subjectId,
                  key,
                  value: publication.beforeValue,
                }
              : publication.beforeKey !== publication.afterKey
              ? {
                  kind: 'rekey',
                  subject: publication.subjectId,
                  beforeKey: publication.beforeKey,
                  afterKey: publication.afterKey,
                }
              : undefined;
          pathNotifier.notify(
            `${basePath}.${String(key)}`,
            publication.afterValue,
            publication.beforeValue,
            basePath,
            [publication.subjectId],
            getPositionIdsForNotify(),
            structuralEffect
              ? createStructuralEffectMeta(structuralEffect)
              : ambientMeta()
          );
          // Taps see what a replay applied, as subscribers do: a row brought
          // back, a row taken away, a row whose value changed (15.4.3 tapped
          // nothing on this path). A rekey taps nothing, as changeId does.
          const { beforeValue, afterValue } = publication;
          const kind = structuralEffect?.kind;
          if (kind === 'add') emitTap('onAdd', afterValue as E, key);
          else if (kind === 'remove') emitTap('onRemove', key, beforeValue as E);
          else if (!kind && !deepEqual(beforeValue, afterValue))
            emitTap('onUpdate', key, afterValue as E, afterValue as E);
        }
        if (options?.advancePhysicalRevision !== false) {
          physicalCommitClock?.advance();
        }
      },
    };
  }

  function readTransitionSource(): CollectionTransitionTarget {
    if (positionId === undefined) {
      throw new Error('Collection transition binding has no owner PositionId');
    }
    const subjects = structuralStore.activeKeysSnapshot().map((key) => {
      const subject = structuralStore.subjectIdForKey(key);
      const value =
        subject === undefined
          ? undefined
          : valueStore.backingForSubject(subject);
      if (subject === undefined || value === undefined) {
        throw new Error(
          'Collection transition source is missing active subject truth'
        );
      }
      return { subject, key, value };
    });
    return {
      owner: positionId,
      subjects,
      order: subjects.map(({ subject }) => subject),
      orderFrontier: structuralStore.activeOrderFrontier(),
    };
  }

  function commitAndProjectEntityMutationFrame(
    frame: EntityMutationFrame<K, E>,
    options?: { advancePhysicalRevision?: boolean }
  ) {
    const capture = committedEntityObserver();
    const unit = beginMembershipUnit();
    const frontier = structuralStore.activeOrderFrontier();
    try {
      let membership: readonly EntityMembershipChange[] = [];
      const result = frame.commit(capture, membershipInventory.observed()
        ? (changes) => { membership = changes; }
        : undefined);
      publishFrontier(frontier);
      if (options?.advancePhysicalRevision !== false) {
        physicalCommitClock?.advance();
      }
      unit.commit(membership);
      return result;
    } catch (error) {
      unit.cancel();
      throw error;
    }
  }

  /** Reactive signals for queries — all derived, none eagerly maintained. */
  const computeAll = (): E[] => {
    const entities = presentEntities();
    // `sortComparer` gives `all`/`ids` a stable sorted order (parity with
    // @ngrx/entity); `map` keeps insertion order.
    if (config.sortComparer) entities.sort(config.sortComparer);
    return entities;
  };
  const allSignal: ReadableCell<E[]> = createVersionedProjection(computeAll);
  // O(1) — this used to be `entities.length` on a freshly built array.
  const computeCount = (): number =>
    absent() ? 0 : structuralStore.activeKeyCount();
  const countSignal: ReadableCell<number> =
    createVersionedProjection(computeCount);
  // Runtime-owned freshness applies inside taps too. Return the same native
  // or neutral projection throughout a write; delivery remains grouped.
  // Identity-stable across value-only writes: the key snapshot is shared until
  // the list or a key changes, so the copy (and every consumer) is reused.
  let idsSource: readonly K[] | undefined;
  let idsValue: K[] = [];
  const computeIds = (all: () => E[]): K[] => {
    if (absent()) return [];
    if (config.sortComparer) return all().map((e) => selectId(e));
    const keys = structuralStore.activeKeysSnapshot();
    if (keys !== idsSource) {
      idsSource = keys;
      idsValue = [...keys];
    }
    return idsValue;
  };
  const idsSignal: ReadableCell<K[]> = createVersionedProjection(() =>
    computeIds(allSignal)
  );
  // Still a copy: callers may hold the result across mutations and must not
  // see it change underneath them. But it is paid on read, not on write.
  const computeMap = (): ReadonlyMap<K, E> => new Map(presentEntries());
  const mapSignal: ReadableCell<ReadonlyMap<K, E>> =
    createVersionedProjection(computeMap);

  /**
   * Per-entity signals — the body-granular reactivity layer.
   *
   * Each entity that is read via `byId()`/node access gets its own
   * `Location<E | undefined>`. Per-entity field reads and `node()` depend ONLY
   * on this location, not on the whole-collection `mapSignal`, so
   * updating one entity dirties only that entity's readers (fan-out 1) instead
   * of every entity's computeds (fan-out N). Collection queries (`all`, `map`,
   * `count`, `ids`, `where`, `find`, computed slices) still depend on the
   * collection signals and recompute on any change — which is correct.
   *
   * Materialized lazily (on first `byId`/node access) and kept O(1) per
   * mutation by only syncing the entities that actually changed.
   */
  /**
   * `SUBJECT-EPOCH-0`. One stable reactive anchor per REALIZED subject, held
   * strongly and deliberately.
   *
   * This replaces `entitySignals`, a full `Location<E>` per subject holding a
   * copy of the entity. That copy was never the durable record —
   * `getEntitySignal` seeded every cell from
   * `valueStore.backingForSubject(subjectId)` — so it was authority duplicated
   * into the framework. Reads now take a dependency here and then read
   * `EntityValueStore` directly, which is the only copy.
   *
   * STRONG on purpose, and that is the design. `ENTITY-SIGNAL-SEMANTIC-0`
   * proved a weakly held carrier is unsafe: a non-live Angular `computed` does
   * not retain its producers, so `computed(() => rows.byId(k)?.()?.x)` loses
   * its carrier to a collection and silently freezes. An epoch is cheap enough
   * to simply keep — 562 B/entity against 1,248 B for the `Location` it
   * replaces — so reachability is guaranteed by retention rather than hoped
   * for.
   */
  const subjectEpochs = new Map<number, EpochHandle>();
  /**
   * `ANGULAR-NATIVE-EPOCH-0`. Advance through the RUNTIME, never by writing the
   * handle. A framework-supplied handle belongs to its adapter; the kernel
   * assuming it could write one is what left Vue's epoch permanently dead.
   */
  const advanceEpochHandle = (handle: EpochHandle): void => {
    locations.advanceEpoch?.(handle);
  };
  const structuralStore = new StructuralStore<K>();
  // Dormant until a membership reader first observes this collection; then
  // the reader installs the producer through the source defined below.
  // `observed()` gates add/remove/rekey records; `observed(true)` gates
  // `reorder` records, which an order-only consumer (Link) needs alone.
  let membershipInventory: Pick<EntityMembershipInventory, 'observed' | 'begin'> = DORMANT_MEMBERSHIP;
  const readMembers = () =>
    structuralStore.activeKeysSnapshot().map((key) => {
      const lifetimeId = structuralStore.subjectIdForKey(key);
      if (lifetimeId === undefined) throw new Error('Active entity membership has no lifetime.');
      return { lifetimeId, key };
    });
  let membershipGroupDepth = 0;
  let groupedMembershipUnit: EntityMembershipUnit | undefined;
  function beginMembershipUnit() {
    // Compound operations arm only at the first physical commit, so planning
    // and interceptors may still inspect a complete pre-operation inventory.
    if (membershipGroupDepth && !groupedMembershipUnit) groupedMembershipUnit = membershipInventory.begin();
    return membershipInventory.begin();
  }
  function withMembershipGroup<R>(run: () => R): R {
    membershipGroupDepth++;
    try { return run(); }
    finally {
      if (--membershipGroupDepth === 0) {
        const unit = groupedMembershipUnit;
        groupedMembershipUnit = undefined;
        unit?.commit([]);
      }
    }
  }
  function membershipAddition(lifetimeId: number, key: K): EntityMembershipChange {
    const neighbors = structuralStore.neighborSubjectsForKey(key);
    return { kind: 'add', lifetimeId, key, beforeLifetimeId: neighbors.beforeSubject, afterLifetimeId: neighbors.afterSubject };
  }
  const valueStore = new EntityValueStore<E>();
  /**
   * `SUBJECT-STATE-SEMANTIC-0`. Held WEAKLY.
   *
   * This carrier has no durable semantic value. Its number is a nonce: nothing
   * reads it, `currentKey` only subscribes to it, and the durable truth it
   * stands for is `structuralStore.subjectRevision`. So there is nothing here
   * to persist — only a carrier to FIND while something is still listening.
   *
   * Strongly held, it was the single largest item in the released residue: a
   * full `Location<number>` per realized subject, measured at 1,249 B/entity of
   * a 2,709 B residue. Weak, a released subject keeps a `WeakRef` and a `Map`
   * entry instead.
   *
   * THE INVARIANT. Every public dependency on subject structural state also
   * depends on a SECOND, permanently retained reactive path, so invalidation
   * reaches an observer that holds nothing here. That path is now
   * [[subjectEpochs]]: `tombstoneSubjectSignal` stages an epoch advance, and
   * the epoch is strong.
   *
   * It is NOT true that live consumers retain this carrier. Angular does not
   * give that property: measured across a forced GC, a `computed` closing over
   * the node retains its carrier, but `computed(() => rows.byId(k)?.()?.x)` —
   * an equally live observer that re-resolves each evaluation — does NOT, and
   * its carrier is collected. `ENTITY-SIGNAL-SEMANTIC-0` records the attempt
   * that proved it, by removing the stable path and watching that exact shape
   * freeze.
   *
   * So this stays safe only while the epoch stays strong, and the entry here is
   * replaced only when `deref()` comes back empty.
   */
  const subjectStateSignals = new Map<number, WeakRef<Location<number>>>();
  const ownerMetadataEnabled = options?.ownerMetadataEnabled ?? true;
  const subjectMetadataEnabled =
    options?.subjectMetadataEnabled ?? ownerMetadataEnabled;
  const positionMetadataEnabled = options?.positionMetadataEnabled ?? true;
  const hasRestorationAuthority = options?.hasRestorationAuthority ?? true;
  const ownerId = options?.ownerId;
  const physicalCommitClock = options?.physicalCommitClock;
  const mutationCaptureRuntime = options?.mutationCaptureRuntime;
  let positionId = (
    options?.positionIdAllocator ??
    (positionMetadataEnabled
      ? entityPositionIdAllocatorOverride ?? standaloneEntityPositionIdAllocator
      : undefined)
  )?.();
  let lastSubjectIds: number[] | undefined;

  type PendingStructuralEffect = StructuralEffect;
  type PendingAddStructuralEffect = Extract<
    PendingStructuralEffect,
    { kind: 'add' }
  >;

  /**
   * The ambient write context, ALWAYS carrying this collection's owning tree.
   *
   * Every meta this file builds goes through here rather than calling
   * `ambientMeta()` directly, so a new notification site cannot
   * silently omit the namespace — which is how OWNER-REPLAY-2's defect existed
   * across eighteen sites at once.
   */
  function ambientMeta(): WriteMetadata | undefined {
    const active = getActiveWriteContext();
    if (ownerId === undefined) return active;
    return { ...(active ?? {}), ownerId };
  }

  /**
   * Whether anything can receive this collection's notifications.
   *
   * Asked of the INJECTED port, once per operation, before any payload is
   * built: a structural effect deep-clones its row, its meta spreads the
   * ambient context, and in a plain tree nobody receives either — that was
   * ~68% of a 50k-row `setAll`. A port that cannot answer is observed, so a
   * bare `{ notify }` keeps every publication.
   *
   * Same semantics as the scalar route (`emitOwnedMutation`): an observer
   * attached between a write and its flush does not receive that write.
   */
  function pathObserved(): boolean {
    return pathNotifier.hasObservers?.() ?? true;
  }

  function effectMeta(
    base: WriteMetadata | undefined,
    structuralEffect: PendingStructuralEffect
  ): WriteMetadata {
    return { ...(base ?? {}), structuralEffect };
  }

  function getPositionIds(): number[] | undefined {
    return positionId === undefined ? undefined : [positionId];
  }

  function getPositionIdsForNotify(): number[] | undefined {
    return entityPositionIdNotifyEnabled ? getPositionIds() : undefined;
  }

  function createStructuralEffectMeta(
    effect: PendingStructuralEffect
  ): WriteMetadata {
    return effectMeta(ambientMeta(), effect);
  }

  /**
   * Warn about repeated predicate identities with identical source. Identity
   * drives memoization, but equal source does not imply equal captured values.
   * Count within a time window so legitimate slow replacement does not
   * accumulate forever. This is a heuristic, not proof of a rendering loop;
   * advice must preserve predicates whose captures actually change.
   */
  const predicateWindows = new Map<string, { count: number; start: number }>();
  const warnedPredicates = new Set<string>();
  /** Distinct identities within {@link PREDICATE_CHURN_WINDOW_MS} to accuse. */
  const PREDICATE_CHURN_THRESHOLD = 12;
  /** Bounded sampling window; timing alone cannot establish a cause. */
  const PREDICATE_CHURN_WINDOW_MS = 2000;

  function warnOnPredicateChurn(
    method: 'where' | 'find',
    predicate: (entity: E) => boolean
  ): void {
    const source = String(predicate);
    // Guard against pathological state growth in a long dev session: the map is
    // only ever as large as the number of DISTINCT predicate sources.
    if (predicateWindows.size > 200 || warnedPredicates.has(source)) return;

    const now =
      typeof performance !== 'undefined' ? performance.now() : Date.now();
    const window = predicateWindows.get(source);
    if (!window || now - window.start > PREDICATE_CHURN_WINDOW_MS) {
      // A fresh window, not an increment. This is what makes a slow drip of
      // legitimately-rebuilt predicates never accumulate to an accusation.
      predicateWindows.set(source, { count: 1, start: now });
      return;
    }
    window.count++;
    if (window.count < PREDICATE_CHURN_THRESHOLD) return;

    warnedPredicates.add(source);
    const perSecond = Math.round(
      (window.count / Math.max(now - window.start, 1)) * 1000
    );
    console.warn(
      `SignalTree: \`${method}()\` received ${window.count} different functions ` +
        `with identical source in ${Math.round(now - window.start)}ms ` +
        `(~${perSecond}/second). New predicate identities bypass query memoization. ` +
        `Reuse a stable predicate when its captured inputs are unchanged. ` +
        `Source: ${source.slice(0, 80)} [ST2026]`
    );
  }

  function planRekey(
    from: K,
    to: K
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    const entity = requireEntity(from);
    if (from === to) {
      // A no-op rekey still ADDRESSES this subject, and the leaf-signal
      // interceptor fires on every mutator call — including one that changes
      // nothing. Every sibling mutator narrows the latch unconditionally, so
      // the no-op must too: leaving the latch at the previous write's
      // participation set lets a no-op rekey re-publish a bulk write's
      // subject inventory into the capture bucket of whatever designated
      // write shares the tick. RESTORATION-REKEY-CLAIM-WIDTH-0.
      const noOpSubjectId = allocateSubjectId(from);
      return {
        commit(): void {
          lastSubjectIds = [noOpSubjectId];
        },
        publish(): void {
          // no-op
        },
      };
    }
    if (structuralStore.hasActiveKey(to)) {
      throw new Error(`Cannot change id to ${String(to)}: already in use`);
    }

    const subjectId = allocateSubjectId(from);
    const structuralEffect: PendingStructuralEffect = {
      kind: 'rekey',
      subject: subjectId,
      beforeKey: from,
      afterKey: to,
    };

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const transfer: PreparedKeyTransfer<K> = {
          kind: 'transfer-key',
          fromKey: from,
          toKey: to,
          subjectId,
        };
        const frame = createEntityMutationFrame();
        frame.stageKeyTransfer(transfer);
        const result = commitAndProjectEntityMutationFrame(frame, options);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        // Narrow last-write participation to the one rekeyed subject. The
        // leaf-signal interceptor re-reads `__subjectIds` after `changeId`
        // returns; without this it reports every subject of the prior
        // collection write as a participant, and restoration then retains a
        // claim per live subject. Sibling mutators all narrow this latch.
        // RESTORATION-REKEY-CLAIM-WIDTH-0.
        lastSubjectIds = [subjectId];

        if (activeIdSignal() === from) {
          replaceLocation(activeIdSignal, to);
        }

        syncEntitySignal(to);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        const meta = metaOverride ?? ambientMeta();
        pathNotifier.notify(
          `${basePath}.${String(to)}`,
          entity,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...(meta ?? {}),
            structuralEffect,
          }
        );
      },
    };
  }

  function planPreparedRekey(
    from: K,
    to: K,
    subjectId: number,
    entity: E
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    if (from === to) {
      // Same rule as `planRekey`'s no-op branch: the interceptor fires on the
      // call, so the latch must name the addressed subject even when the
      // rekey changes nothing. RESTORATION-REKEY-CLAIM-WIDTH-0.
      return {
        commit(): void {
          lastSubjectIds = [subjectId];
        },
        publish(): void {
          // no-op
        },
      };
    }

    const structuralEffect: PendingStructuralEffect = {
      kind: 'rekey',
      subject: subjectId,
      beforeKey: from,
      afterKey: to,
    };

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const transfer: PreparedKeyTransfer<K> = {
          kind: 'transfer-key',
          fromKey: from,
          toKey: to,
          subjectId,
        };
        const frame = createEntityMutationFrame();
        frame.stageKeyTransfer(transfer);
        const result = commitAndProjectEntityMutationFrame(frame, options);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        // Narrow last-write participation to the one rekeyed subject. The
        // leaf-signal interceptor re-reads `__subjectIds` after `changeId`
        // returns; without this it reports every subject of the prior
        // collection write as a participant, and restoration then retains a
        // claim per live subject. Sibling mutators all narrow this latch.
        // RESTORATION-REKEY-CLAIM-WIDTH-0.
        lastSubjectIds = [subjectId];

        if (activeIdSignal() === from) {
          replaceLocation(activeIdSignal, to);
        }

        syncEntitySignal(to);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        const meta = metaOverride ?? ambientMeta();
        pathNotifier.notify(
          `${basePath}.${String(to)}`,
          entity,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          {
            ...(meta ?? {}),
            structuralEffect,
          }
        );
      },
    };
  }

  /** Active-entity selection. See the `activeId`/`activeEntity` accessors. */
  const activeIdSignal = locations.createCell<K | undefined>(undefined);
  let cachedActiveEntity: ReadableCell<E | undefined> | undefined;

  /**
   * Re-orders `storage` so the given ids come first, in the order given.
   *
   * Only the map's iteration order changes; no per-entity signal is touched, so
   * prepending does not invalidate any row's consumers. The derived collection
   * signals pick the new order up from the version bump.
   */
  /** Whether an order delta has a consumer (a history or transaction capture). */
  // publishCollectionOrder() returns at once while no capture is active, so
  // skip the O(n) order comparison callers would hand it (123fd318).
  function orderConsumed(): boolean {
    return (
      positionId !== undefined &&
      !!mutationCaptureRuntime?.publishCollectionOrder &&
      mutationCaptureRuntime.isCaptureActive()
    );
  }

  /** A frontier-only transition, once per operation that replaced it. */
  function publishFrontier(before: unknown): void {
    if (before !== structuralStore.activeOrderFrontier() && orderConsumed())
      publishOrderChange(before);
  }

  function publishOrderChange(
    beforeFrontier: unknown,
    beforeSubjects?: number[],
    afterSubjects?: number[]
  ): void {
    mutationCaptureRuntime?.publishCollectionOrder?.({
      owner: positionId as number,
      ownerPath: basePath,
      beforeSubjects,
      afterSubjects,
      beforeFrontier,
      afterFrontier: structuralStore.activeOrderFrontier(),
      meta: ambientMeta(),
    });
  }

  function moveToFront(ids: K[]): void {
    const before = membershipInventory.observed(true) ? structuralStore.activeKeysSnapshot().map((key) => rememberSubjectId(key)) : undefined;
    const frontier = structuralStore.activeOrderFrontier();
    structuralStore.moveKeysToFront(ids);
    publishFrontier(frontier);
    if (before) {
      const after = structuralStore.activeKeysSnapshot().map((key) => rememberSubjectId(key));
      if (before.some((id, index) => id !== after[index])) {
        beginMembershipUnit().commit([{ kind: 'reorder', before, after }]);
      }
    }
    physicalCommitClock?.advance();
    updateSignals();
  }

  function requireEntity(id: K): E {
    // A row-naming write to an absent collection refuses, as on an empty one
    // (v16 8e); a reversal applying it reads physically (`rowAbsent`).
    const entity = presentEntity(id);
    if (!entity) {
      throw new Error(`Entity with id ${String(id)} not found`);
    }
    return entity;
  }

  function requireSubjectId(id: K): number {
    const subjectId = structuralStore.subjectIdForKey(id);
    if (subjectId === undefined) {
      throw new Error(`Entity with id ${String(id)} has no subject id`);
    }
    return subjectId;
  }

  function resolveSubjectId(id: K): number | undefined {
    return structuralStore.subjectIdForKey(id);
  }

  function resolveSubjectState(
    subjectId: number
  ): SubjectLifetimeRecord<K> | undefined {
    return structuralStore.stateForSubject(subjectId);
  }

  function getSubjectRevision(subjectId: number): number {
    return structuralStore.subjectRevision(subjectId);
  }

  function bumpSubjectRevision(subjectId: number): void {
    structuralStore.bumpSubjectRevision(subjectId);
  }

  /** Get (or lazily create) the per-entity signal, seeded from storage. */
  /** Stage an advance only for a subject something has actually realized. */
  function stageSubjectEpoch(subjectId: number): void {
    const epoch = subjectEpochs.get(subjectId);
    if (epoch) pendingSubjectEpochs.add(epoch);
  }

  /** Materialized lazily: a subject nobody has read has no epoch. */
  function getSubjectEpoch(subjectId: number): EpochHandle {
    let epoch = subjectEpochs.get(subjectId);
    if (!epoch) {
      epoch = locations.createEpoch ? locations.createEpoch() : neutralEpoch();
      subjectEpochs.set(subjectId, epoch);
    }
    return epoch;
  }

  function neutralEpoch(): EpochHandle {
    const cell = locations.createCell(0);
    const epoch = (() => cell()) as WritableCell<number>;
    epoch.set = (value: number) => cell(value);
    epoch.update = (fn: (current: number) => number) => cell(fn);
    epoch.asReadonly = () => cell;
    return epoch as unknown as EpochHandle;
  }

  /**
   * Take the stable dependency, then read the ONE copy of the value.
   *
   * Order matters: canonical stores are written by `install()` before
   * `publish()` advances any epoch, so a reader can observe a new value before
   * its invalidation, but never an invalidation before its value.
   */
  function readSubjectEntity(subjectId: number): E | undefined {
    getSubjectEpoch(subjectId)();
    return rowAbsent() ? undefined : valueStore.backingForSubject(subjectId);
  }

  function readEntityByKey(id: K): E | undefined {
    const subjectId = resolveSubjectId(id);
    if (subjectId === undefined) return presentEntity(id);
    return readSubjectEntity(subjectId);
  }

  function getSubjectStateSignal(subjectId: number): Location<number> {
    const existing = subjectStateSignals.get(subjectId)?.deref();
    if (existing) return existing;
    // Starting a replacement back at 0 is sound precisely because the value is
    // a nonce: every observer that could have compared against the old count
    // was retaining the old carrier, which is why this branch was not taken.
    const created = locations.createCell(0);
    // A first read may arrive after this lifetime was irreversibly forgotten.
    // Keep that carrier caller-owned; retained tombstones still register for undo.
    // Check after createCell so retirement during creation cannot leave an entry.
    if (resolveSubjectState(subjectId) !== undefined) {
      subjectStateSignals.set(subjectId, new WeakRef(created));
    }
    return created;
  }

  function bumpSubjectStateSignal(subjectId: number): void {
    // Publish only to an activation token that already exists. Interning here
    // would recreate eager realization through the write path: any subject that
    // is ever mutated would acquire a token whether or not anything observes it.
    const signal = subjectStateSignals.get(subjectId)?.deref();
    if (signal) deriveLocation(signal, (value) => value + 1);
  }

  function publishSubjectPhysicalChange(subjectId: number): void {
    bumpSubjectRevision(subjectId);
    bumpSubjectStateSignal(subjectId);
  }

  function allocateSubjectId(id: K): number {
    const existing = structuralStore.subjectIdForKey(id);
    if (existing !== undefined) {
      return existing;
    }

    return commitFreshSubject(id);
  }

  function commitFreshSubject(id: K): number {
    const subjectId = structuralStore.allocateFreshSubjectId();
    structuralStore.createSubject(subjectId, id);
    return subjectId;
  }

  function commitFreshSubjects(ids: readonly K[]): number[] {
    return ids.map((id) => commitFreshSubject(id));
  }

  /**
   * `UPDATEONE-FAST-0`. The single-subject form of `rememberSubjectIds`, which
   * allocates twice for one id — once for the caller's `[id]` literal and once
   * for `.map`.
   */
  function rememberSubjectId(id: K): number {
    const resolved = allocateSubjectId(id);
    lastSubjectIds = [resolved];
    return resolved;
  }

  // Source-owned capture runs after physical application and before any
  // invalidation/publication. Ambient attribution is frozen before callbacks.
  function committedEntityObserver():
    | ((changes: readonly CommittedEntityMutation[]) => void)
    | undefined {
    if (
      positionId === undefined ||
      !mutationCaptureRuntime?.hasCommittedEntityObservers?.()
    )
      return undefined;
    const owner = positionId;
    const meta = ambientMeta();
    return (changes) =>
      mutationCaptureRuntime.publishCommittedEntity?.({
        owner,
        ownerPath: basePath,
        changes,
        meta,
      });
  }

  function captureCommittedEntity(
    subject: number,
    before: unknown,
    after: unknown,
    structural: boolean
  ): void {
    const capture = committedEntityObserver();
    if (capture) capture([{ subject, before, after, structural }]);
  }

  /**
   * The value-replacement commit for a subject that already exists.
   *
   * NOT yet a single shared implementation, and the distinction matters.
   * `valueStore.retainSubjectValue` IS the true primitive and both routes call
   * it; what is duplicated is the REVISION advance, which happens here for the
   * fast path and in `commitAndProjectEntityMutationFrame` for the frame path.
   * Behaviour is equivalent and pinned by
   * `entity-update-one-equivalence.spec.ts`, which runs against both — but two
   * call sites advance the physical clock, so a change to revision semantics
   * has to find both.
   *
   * CLEANUP OWED: have `EntityMutationFrame`'s `replace-value` instruction go
   * through this function, or move the advance into `retainSubjectValue`, so
   * there is one place that decides what a value replacement costs.
   *
   * Admissible ONLY when the mutation is exactly one value replacement with no
   * structural consequence: the subject exists, keeps its SubjectId and
   * lifetime, does not change key, ordering, membership or structural owner,
   * and nothing is created, restored or retired. `updateOne` is that case by
   * construction — it stages one `replace-value` and nothing else — which is
   * why it can call this directly rather than testing for it.
   *
   * Profiled: the frame path cost `entity-mutation-frame.commit` 20.3% of
   * `updateOne` plus 9.4% GC, because `commit()` allocates a prepared-
   * instruction array, a `Set` and an id array per mutation regardless of size.
   * For a one-field update that machinery is the mutation.
   */
  function commitExistingSubjectValue(subjectId: number, nextValue: E): void {
    const capture = committedEntityObserver();
    const before = capture ? valueStore.backingForSubject(subjectId) : undefined;
    valueStore.retainSubjectValue(subjectId, nextValue);
    capture?.([
      { subject: subjectId, before, after: nextValue, structural: false },
    ]);
    physicalCommitClock?.advance();
  }


  function findKeyBySubjectId(subjectId: number): K | undefined {
    return structuralStore.activeKeyForSubject(subjectId);
  }

  function getNeighborSubjects(id: K): {
    beforeSubject?: number;
    afterSubject?: number;
  } {
    return structuralStore.neighborSubjectsForKey(id);
  }

  function restoreOne(
    key: K,
    entity: E,
    subjectId: number,
    beforeSubject?: number,
    afterSubject?: number
  ): void {
    const planned = planRestore(
      key,
      entity,
      subjectId,
      beforeSubject,
      afterSubject
    );
    planned.commit();
    planned.publish();
  }

  function planRestore(
    key: K,
    entity: E,
    subjectId: number,
    beforeSubject?: number,
    afterSubject?: number,
    /**
     * Keys the caller's frame will vacate before this restore commits.
     * RESTORE-P0 P0-D: the frame's own removals commit BEFORE its restores, so
     * a key listed here is free by the time this plan runs even though it is
     * occupied right now.
     */
    vacatingKeys?: ReadonlySet<string | number>
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    // The occupancy check answers "is this key free?" — but the honest question
    // is "will this key be free when I commit?". Undoing a turn that removed
    // 'a' and re-added 'a' produces two effects on two DIFFERENT subjects (a
    // removed key is tombstoned, so re-adding mints a new subject). Reversing
    // them frees 'a' and reclaims it in one frame, and asking the pre-frame
    // question turned a correct undo into a crash.
    if (structuralStore.hasActiveKey(key) && !vacatingKeys?.has(key)) {
      throw new Error(`Entity with id ${String(key)} already exists`);
    }

    const state = resolveSubjectState(subjectId);
    if (state && !state.restoreAllowed) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} has retired backing and cannot be restored.`
      );
    }

    const restoration: PreparedSubjectRestore<K, E> = {
      kind: 'restore-subject',
      key,
      subjectId,
      restoreAllowed: state?.restoreAllowed ?? true,
      beforeSubject,
      afterSubject,
      realizedValue: entity,
    };

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const frame = createEntityMutationFrame();
        frame.stageSubjectRestore(restoration);
        const result = commitAndProjectEntityMutationFrame(frame, options);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        // A restored lifetime re-enters collection membership. Value-only
        // delivery cannot reinsert it into an observer's collection topology.
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          undefined,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          effectMeta(metaOverride ?? ambientMeta(), {
            kind: 'add',
            subject: subjectId,
            key,
            value: deepClone(entity),
            beforeSubject,
            afterSubject,
          })
        );
        // Symmetric with planRemove: a replay that brings a row back taps
        // onAdd, as one that takes it away taps onRemove (15.4.3 tapped only
        // the removal).
        emitTap('onAdd', entity, key);
      },
    };
  }

  function planFreshAdd(
    key: K,
    entity: E,
    subjectId: number
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    const existingState = resolveSubjectState(subjectId);
    if (existingState) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} already exists and cannot be realized as fresh.`
      );
    }

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const frame = createEntityMutationFrame();
        frame.stageFreshSubject({
          kind: 'create-fresh-subject',
          key,
          subjectId,
          nextValue: entity,
        });
        commitAndProjectEntityMutationFrame(frame, options);
        lastSubjectIds = [subjectId];
        invalidateNodeCache(key);
        syncEntitySignal(key);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          entity,
          undefined,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          metaOverride
        );
        emitTap('onAdd', entity, key);
      },
    };
  }

  function planRemove(
    key: K,
    subjectId: number
  ): {
    commit(options?: { advancePhysicalRevision?: boolean }): void;
    publish(metaOverride?: WriteMetadata): void;
  } {
    const entity = requireEntity(key);

    const { beforeSubject, afterSubject } = getNeighborSubjects(key);
    const structuralEffect: PendingStructuralEffect = {
      kind: 'remove',
      subject: subjectId,
      key,
      value: deepClone(entity),
      beforeSubject,
      afterSubject,
    };
    const currentState = resolveSubjectState(subjectId);
    const tombstone: PreparedSubjectTombstone<K> = {
      kind: 'tombstone-subject',
      key,
      subjectId,
      restoreAllowed: currentState?.restoreAllowed ?? true,
    };

    return {
      commit(options?: { advancePhysicalRevision?: boolean }): void {
        const frame = createEntityMutationFrame();
        frame.stageSubjectTombstone(tombstone);
        const result = commitAndProjectEntityMutationFrame(frame, options);
        for (const changedSubjectId of result.physicallyChangedSubjectIds) {
          publishSubjectPhysicalChange(changedSubjectId);
        }
        lastSubjectIds = [subjectId];
        tombstoneSubjectSignal(subjectId);
        updateSignals();
      },
      publish(metaOverride?: WriteMetadata): void {
        pathNotifier.notify(
          `${basePath}.${String(key)}`,
          undefined,
          entity,
          basePath,
          [subjectId],
          getPositionIdsForNotify(),
          effectMeta(metaOverride ?? ambientMeta(), structuralEffect)
        );

        emitTap('onRemove', key, entity);
      },
    };
  }

  function assertSynchronousInterceptorFunction(
    handler: unknown,
    hookName: string
  ): void {
    if (
      typeof handler === 'function' &&
      handler.constructor?.name === 'AsyncFunction'
    ) {
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. ` +
          `Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }

  function assertSynchronousInterceptorResult(
    result: void | Promise<void> | undefined,
    hookName: string
  ): void {
    if (result && typeof result.then === 'function') {
      void result.catch(() => undefined);
      throw new Error(
        `SignalTree: ${hookName} interceptors must be synchronous. ` +
          `Async interceptors cannot safely block a synchronous mutation path. [ST2033]`
      );
    }
  }

  function assertSynchronousInterceptors(
    handlers: InterceptHandlers<E, K>
  ): void {
    assertSynchronousInterceptorFunction(handlers.onAdd, 'onAdd');
    assertSynchronousInterceptorFunction(handlers.onUpdate, 'onUpdate');
    assertSynchronousInterceptorFunction(handlers.onRemove, 'onRemove');
  }

  /**
   * The interceptors a write runs. None for a replay of recorded state writing
   * itself back — undo, redo, jumpTo, a rollback, a devtools jump: it restores
   * exactly the value or pre-image that was recorded, which the interceptors
   * already shaped when it was first written. Through them, a transforming
   * `onUpdate` re-transformed the pre-image an undo restored and a blocking one
   * made undo and rollback throw (15.4.3). A write a tap or subscriber makes
   * while the replay runs is forward work and is intercepted.
   */
  function activeInterceptors(): readonly InterceptHandlers<E, K>[] {
    return isRecordedReplayWrite() ? [] : interceptHandlers;
  }

  /**
   * One interceptor hook on every active interceptor, each handed the call's
   * own arguments: `block` throws `Cannot <verb> entity: <reason>`, and the
   * last `transform` is the value handed on (a removal has none to hand on).
   */
  function runInterceptors<T>(
    verb: string,
    hook: 'onAdd' | 'onUpdate' | 'onRemove',
    value: T,
    args: unknown[]
  ): T {
    // Already run for this call (a re-adding write, below; v16 8f).
    if (interceptsSuppressed) return value;
    for (const handler of activeInterceptors()) {
      const ctx: InterceptContext<T> = {
        block: (reason?: string) => {
          throw new Error(
            `Cannot ${verb} entity: ${reason || 'blocked by interceptor'}`
          );
        },
        transform: (next: T) => {
          value = next;
        },
        blocked: false,
        blockReason: undefined,
      };
      assertSynchronousInterceptorResult(
        (
          handler[hook] as
            | ((...hookArgs: unknown[]) => void | Promise<void>)
            | undefined
        )?.(...args, ctx),
        hook
      );
    }
    return value;
  }

  function interceptAddedEntity(entity: E): E {
    return runInterceptors('add', 'onAdd', entity, [entity]);
  }

  /** `onUpdate` interceptors for a whole-entity replacement. */
  function interceptReplacedEntity(id: K, entity: E): E {
    return runInterceptors('replace', 'onUpdate', entity, [id, entity]);
  }

  /** `onRemove` interceptors: a block throws; there is nothing to transform. */
  function interceptRemovedEntity(id: K, entity: E): void {
    runInterceptors('remove', 'onRemove', entity, [id, entity]);
  }

  function interceptUpdatedEntity(id: K, changes: Partial<E>): Partial<E> {
    return runInterceptors('update', 'onUpdate', changes, [id, changes]);
  }

  /**
   * An add call's id selectors and interceptors must leave this collection's
   * membership, keys and order alone — the rule `setAll` enforces (README,
   * 15.4.0). The call planned which of its ids exist, their subjects and its
   * anchors against the collection as it entered; a callback that changed it
   * would have the call write a stale plan (an interceptor adding the same id
   * made two rows under one key; one removing a row the call overwrites lost
   * the write; one removing the last row resurrected it as an empty member).
   * So it refuses before writing anything. The callback's own writes stand;
   * field-only writes are allowed.
   */
  function refuseTopologyChange(
    method: string,
    frontier: unknown,
    rows: ReadonlyArray<{ id: K; subjectId?: number }>,
    keysMoved?: boolean
  ): void {
    if (
      keysMoved ||
      structuralStore.activeOrderFrontier() !== frontier ||
      rows.some(({ id, subjectId }) => structuralStore.subjectIdForKey(id) !== subjectId)
    ) {
      throw new Error(
        `Cannot ${method}: collection topology changed during staging`
      );
    }
  }

  function addOneRow(entity: E, opts?: AddOptions<E, K>): K {
    const frontier = structuralStore.activeOrderFrontier();
    const id = deriveId(entity, opts);

    if (structuralStore.hasActiveKey(id)) {
      throw new Error(`Entity with id ${String(id)} already exists`);
    }

    const transformedEntity = interceptAddedEntity(entity);
    refuseTopologyChange('addOne', frontier, [{ id }]);
    // Read after the interceptors (ad275e33); the refusal above now also
    // guarantees they did not move it.
    const previousLastKey = structuralStore.lastActiveKey();
    recordProductionSubstrateStat('publicAddPreviousTailReads');
    const subjectId = structuralStore.planFreshSubjectIds(1)[0];
    if (subjectId === undefined) {
      throw new Error(
        `Fresh subject planning for ${String(id)} did not produce an id.`
      );
    }

    const frame = createEntityMutationFrame();
    const freshSubject: PreparedFreshSubject<K, E> = {
      kind: 'create-fresh-subject',
      key: id,
      subjectId,
      nextValue: transformedEntity,
    };
    frame.stageFreshSubject(freshSubject);
    commitAndProjectEntityMutationFrame(frame);
    const structuralEffect: PendingAddStructuralEffect | undefined =
      pathObserved()
        ? {
            kind: 'add',
            subject: subjectId,
            key: id,
            value: deepClone(transformedEntity),
            beforeSubject:
              previousLastKey === undefined
                ? undefined
                : allocateSubjectId(previousLastKey),
          }
        : undefined;
    lastSubjectIds = [subjectId];
    invalidateNodeCache(id);
    syncEntitySignal(id);
    updateSignals();

    if (structuralEffect) {
      pathNotifier.notify(
        `${basePath}.${String(id)}`,
        transformedEntity,
        undefined,
        basePath,
        [subjectId],
        getPositionIdsForNotify(),
        createStructuralEffectMeta(structuralEffect)
      );
    }

    emitTap('onAdd', transformedEntity, id);

    return id;
  }

  /**
   * `addMany`, and with `front` `prependMany`: the rows are committed, moved to
   * the front, and only then announced and tapped. A fresh row's `add` effect
   * is anchored to its neighbours in that committed order, so a tap — and any
   * write it makes — sees the call's result, never rows about to move. On
   * 15.4.3 the move came after the taps; 005399a7 then re-anchored the effects
   * from a closure array that only `prependMany` emptied, so every observed
   * `addMany` retained one deep clone per added row, and a nested `prependMany`
   * in a tap emptied the outer call's list (its redo threw).
   */
  function addRows(
    method: string,
    entities: E[],
    opts: AddManyOptions<E, K> | undefined,
    front?: boolean
  ): K[] {
    const frontier = structuralStore.activeOrderFrontier();
    const mode = opts?.mode ?? 'strict';

    // First pass: validate/filter based on mode. The rows apply as if one
    // at a time, so an earlier copy of an id in this call counts as
    // existing: strict throws (before anything is intercepted or written),
    // skip keeps the first copy, overwrite keeps the last in the first copy's
    // place. Two rows under one key was the 15.4.3 result in every mode.
    type Add = {
      id: K;
      entity: E;
      /** The existing row's subject; a fresh row's once planned. */
      subjectId?: number;
      /** The value an overwrite replaces; undefined exactly for a fresh row. */
      prev?: E;
      anchors?: { beforeSubject?: number; afterSubject?: number };
    };
    const rows: Add[] = [];
    // Every copy that applies, in input order.
    const copies: Array<[Add, E]> = [];
    const earlier = new Map<K, Add>();
    for (const entity of entities) {
      const id = deriveId(entity, opts);
      const subjectId = structuralStore.subjectIdForKey(id);
      let row = earlier.get(id);
      if (subjectId !== undefined || row) {
        if (mode === 'strict') {
          throw new Error(`Entity with id ${String(id)} already exists`);
        } else if (mode === 'skip') {
          continue;
        }
        // 'overwrite': fall through — the row is replaced in place below
      }
      if (!row) {
        earlier.set(id, (row = { id, entity, subjectId }));
        rows.push(row);
      }
      copies.push([row, entity]);
    }

    if (rows.length === 0) return [];

    // Interceptors run once per applied copy, in input order, as successive
    // single calls would; the last intercepted value wins (778f86ef
    // intercepted only the last copy). Staged before mutating runtime state so
    // a block cannot partially allocate fresh subject lifetimes.
    for (const [row, entity] of copies) {
      row.entity = interceptAddedEntity(entity);
    }
    refuseTopologyChange(method, frontier, rows);
    // The value an overwrite replaces in place, announced below as the
    // previous value (an active row always has one); then fresh subjects.
    for (const row of rows) {
      if (row.subjectId !== undefined)
        row.prev = valueStore.backingForSubject(row.subjectId);
    }
    const fresh = rows.filter(({ prev }) => prev === undefined);
    const planned = structuralStore.planFreshSubjectIds(fresh.length);
    fresh.forEach((row, i) => (row.subjectId = planned[i]));

    // addMany appends: an added row's predecessor is the previous added row,
    // or for the first one the last row before the call. Only that key is
    // needed, not a copy of every key. Read after the interceptors, as
    // addOne's is.
    const lastPreviousKey = structuralStore.lastActiveKey();

    // prependMany: an OVERWRITTEN row that moves to the front is an order
    // change no anchor expresses, published as one order delta under setAll's
    // condition (surviving rows changed relative order). Unrecorded, it stayed
    // at the front on undo and rollback (15.4.3). Only a call that overwrites
    // an existing row can move one, so only it walks the order: fresh rows
    // alone never reorder the survivors, and prependOne stays O(1) (bf64f92e
    // walked it twice per call under any capture).
    const beforeSubjects: number[] = [];
    const consumed = front && fresh.length < rows.length && orderConsumed();
    if (consumed) structuralStore.snapshotActiveOrder([], beforeSubjects);

    const frame = createEntityMutationFrame();
    for (const { id, entity, subjectId, prev } of rows) {
      if (prev === undefined) {
        frame.stageFreshSubject({
          kind: 'create-fresh-subject',
          key: id,
          subjectId: subjectId as number,
          nextValue: entity,
        });
      } else {
        frame.stageValueReplacement({
          kind: 'replace-value',
          key: id,
          subjectId: subjectId as number,
          nextValue: entity,
        });
      }
    }

    commitAndProjectEntityMutationFrame(frame);

    // Process all entities without triggering per-entity signal updates.
    const ids = rows.map(({ id }) => id);
    for (const id of ids) {
      invalidateNodeCache(id);
      syncEntitySignal(id);
    }

    if (front) {
      moveToFront(ids);
      if (consumed) {
        const afterSubjects: number[] = [];
        structuralStore.snapshotActiveOrder([], afterSubjects);
        if (survivingOrderChanged(beforeSubjects, afterSubjects)) {
          publishOrderChange(frontier, beforeSubjects, afterSubjects);
        }
      }
    } else {
      // Single signal update after all entities are processed
      updateSignals();
    }
    lastSubjectIds = rows.map(({ subjectId }) => subjectId as number);

    // Notify PathNotifier for each processed entity.
    //
    // An 'overwrite' replaces an existing row in place (`replace-value`
    // above), so it is announced as every other replacement is — the new
    // value with the previous one and no structural effect. Announced as an
    // `add`, undo and rollback removed the row (npm 15.4.3).
    //
    // Reproduced on 15.3.1: indexing the pre-add key list at
    // `i + previous - added` anchored [x, y] after k4 and k5 instead of
    // after k5 and x, so redo reinserted them out of order. A fresh row's
    // predecessor is the previous FRESH row of this call, else the last row
    // before it: an overwritten row stays where it was. A prepended row's
    // anchors are its neighbours at the front. Every anchor is read from the
    // committed order BEFORE anything is announced: a synchronous subscriber
    // may write, and a later row's live neighbours would then be stale.
    if (pathObserved()) {
      const meta = ambientMeta();
      let beforeSubject =
        front || lastPreviousKey === undefined
          ? undefined
          : allocateSubjectId(lastPreviousKey);
      for (const row of fresh) {
        row.anchors = front ? getNeighborSubjects(row.id) : { beforeSubject };
        beforeSubject = row.subjectId;
      }
      for (const { id, entity, prev, subjectId, anchors } of rows) {
        const subject = subjectId as number;
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          entity,
          prev,
          basePath,
          [subject],
          getPositionIdsForNotify(),
          anchors
            ? effectMeta(meta, {
                kind: 'add',
                subject,
                key: id,
                value: deepClone(entity),
                ...anchors,
              })
            : meta
        );
      }
    }

    // Run tap handlers for each processed entity
    for (const { id, entity } of rows) {
      emitTap('onAdd', entity, id);
    }

    return ids;
  }

  /**
   * Sync one entity's signal from storage after a mutation. No-op if the
   * entity was never materialized (nothing is observing it yet), keeping
   * single-entity writes O(1) regardless of collection size.
   */
  function syncEntitySignal(id: K): void {
    // Nothing realized, nothing to stage — and no key lookup either.
    if (subjectEpochs.size === 0) return;
    const subjectId = resolveSubjectId(id);
    if (subjectId === undefined) {
      return;
    }

    stageSubjectEpoch(subjectId);
  }

  /**
   * Release one subject's entity signal on removal: notify current observers
   * that the entity is gone (set undefined). The signal itself is kept keyed by
   * SubjectId so held field references stay valid (they read undefined) and a
   * restore of the same subject re-publishes through the same signal.
   */
  function tombstoneSubjectSignal(subjectId: number): void {
    stageSubjectEpoch(subjectId);
  }

  // TOMBSTONE: `resetEntitySignals()` — a bulk `forEach(set(undefined))` +
  // `clear()` of the signal map, once called by `clear()`. It is gone because
  // dropping the MAP ENTRY is what made `clear()` un-undoable: a held reference
  // reads through the signal it was given, and a restore into a fresh signal is
  // a different subject wearing the same key. `clear()` now tombstones
  // per-subject exactly as `removeOne` does. Do not reintroduce a bulk reset as
  // a memory optimization — reclamation at the retirement boundary already
  // sheds zero-owner entries, and it sheds only the ones nothing can restore.

  /**
   * Cache for entity nodes (deep access proxies), held WEAKLY.
   *
   * `byId()` materialises a per-entity node so that row can be bound and
   * written independently — the whole point of granular reactivity. It used to
   * be a strong `Map`, which meant READING permanently allocated: entries were
   * removed on mutation or removal, but nothing bounded growth from reads.
   *
   * Measured at 10,000 entities: 315 B/entity for the collection, and
   * **4,149 B/entity once `byId()` has been called on every row** — 3.0 MB
   * against 39.6 MB, 46x the data. That is the documented pattern for granular
   * updates, so the recommended usage was the expensive one, and on a low-end
   * device it is the shape that runs a list out of memory.
   *
   * A node should live exactly as long as someone holds it. A `WeakRef` gives
   * that: a node no component retains becomes collectable, and a node nobody
   * holds cannot observe its own identity changing, so the next `byId()` simply
   * builds a fresh one. The `FinalizationRegistry` sweeps the dead map entry so
   * the Map itself does not grow with empty refs.
   *
   * ⚠️ A HELD reference must still survive churn — see
   * entity-granular-reactivity.spec.ts, which pins that a node held across
   * remove -> re-add keeps working. Weakness must not weaken THAT: while a
   * caller holds the node, the WeakRef cannot be cleared, so the existing
   * behaviour is unchanged for every reference anyone can actually observe.
   */
  const nodeCache = new Map<number, WeakRef<EntityNode<E>>>();
  const nodeFinalizer =
    typeof FinalizationRegistry === 'function'
      ? new FinalizationRegistry<number>((subjectId) => {
          // Only drop the slot if it is still the dead ref — a later byId()
          // may already have installed a live replacement.
          if (nodeCache.get(subjectId)?.deref() === undefined) {
            nodeCache.delete(subjectId);
          }
        })
      : null;

  function invalidateNodeCache(id: K): void {
    const subjectId = resolveSubjectId(id);
    if (subjectId !== undefined) {
      nodeCache.delete(subjectId);
    }
  }

  /** Cached `empty` computed — created on first access. */
  let cachedEmpty: ReadableCell<boolean> | null = null;

  /** Function to extract key from entity */
  const selectId: (entity: E) => K =
    config.selectId ??
    ((entity: E) => (entity as unknown as Record<string, K>)['id']);

  // Dev-mode guard state: warn once if entities resolve to a null/undefined id.
  let warnedMissingId = false;
  let warnedDuplicateSetAllId = false;

  /**
   * Resolve an entity's id (per-call selectId override → config selectId →
   * default `.id`). Dev-mode guardrail: a null/undefined id means the entity
   * has no `id` field and no `selectId` was provided, so every such entity
   * collides under one key — a common mistake (especially in AI-generated
   * code). Warn once with an actionable fix.
   */
  function deriveId(entity: E, opts?: { selectId?: (e: E) => K }): K {
    const id = opts?.selectId?.(entity) ?? selectId(entity);
    if (
      id == null &&
      (typeof ngDevMode === 'undefined' || ngDevMode) &&
      !warnedMissingId
    ) {
      warnedMissingId = true;
      console.warn(
        `SignalTree entityMap${
          basePath ? ` at "${basePath}"` : ''
        }: an entity ` +
          `resolved to id=${String(
            id
          )}. Entities need a stable key — give them ` +
          `an \`id\` field or pass entityMap({ selectId: (e) => e.yourKey }). ` +
          `Without it, entities collide under a single key. [ST2001]`
      );
    }
    return id;
  }

  /** Handlers for observation */
  const tapHandlers: TapHandlers<E, K>[] = [];
  /** A re-adding write's removal of retained rows: no tap sees it (v16 8e). */
  let silentClear = 0;
  /** A re-adding write already ran this call's interceptors (v16 8f). */
  let interceptsSuppressed = 0;
  /** A re-adding write is running on this collection (v16 8f). */
  let reAdding = false;
  /** It has written its rows and not yet re-added its path. */
  let pendingReAdd = false;
  /**
   * One tap event, run on every tap and counted as a user callback: a write a
   * tap makes during a replay of recorded state is forward work, and is
   * intercepted (write-context.ts). A tap reads collections as any consumer
   * does: absent-aware, even while a reversal is applied to their tree and
   * its own row writes read hidden rows physically (`taps`, v16 8f).
   */
  function emitTap<N extends 'onAdd' | 'onUpdate' | 'onRemove'>(
    name: N,
    ...args: Parameters<NonNullable<TapHandlers<E, K>[N]>>
  ): void {
    if (tapHandlers.length)
      runUserCallback(() => {
        // A re-adding write re-adds its path before anyone hears of its
        // rows: a tap reads the collection present, as on an empty one.
        if (pendingReAdd) {
          pendingReAdd = false;
          reactivatePathOnWrite(api);
        }
        // A tap's own writes are ordinary writes: interceptors run for them,
        // even inside a re-adding write that already ran its own.
        const suppressed = interceptsSuppressed;
        const nested = reAdding;
        interceptsSuppressed = 0;
        reAdding = false;
        taps.depth++;
        try {
          for (const handler of tapHandlers)
            (handler[name] as ((...a: typeof args) => void) | undefined)?.(
              ...args
            );
        } finally {
          taps.depth--;
          interceptsSuppressed = suppressed;
          reAdding = nested;
        }
      });
  }

  /** Handlers for blocking/transforming */
  const interceptHandlers: InterceptHandlers<E, K>[] = [];

  // ==================
  // INTERNAL HELPERS
  // ==================

  /** Mark the collection dirty. O(1) — see the `version` docs above. */
  function updateSignals(includeOmission = false): void {
    const pending = [...pendingSubjectEpochs];
    pendingSubjectEpochs.clear();
    // An absent collection reads empty before and after: nothing a consumer
    // reads changed. Its membership hook wakes them when it comes back, so a
    // reversal writing its hidden rows re-runs nobody while those rows are
    // read physically (v16 8e).
    if (absent() && !includeOmission) return;
    locations.runInvalidationGroup(() => {
      for (const epoch of pending) {
        advanceEpochHandle(epoch);
      }
      deriveLocation(version, (value) => value + 1);
      markOwnerInvalidated(ownerId);
    });
  }

  function createEntityNode(
    subjectId: number,
    initialKey: K,
    entity: E
  ): EntityNode<E> {
    // Entity-level callable:
    //   node()           → reads current entity (reactive via mapSignal)
    //   node(value)      → full entity REPLACE (throws if entity removed)
    //   node(updater)    → replace with the updater's return (throws if removed)
    //
    // These replace, and they always claimed to. Until 14.1.1 they delegated to
    // `updateOne`, which spreads (`{ ...entity, ...changes }`) — so the docs said
    // replace and the code merged. The updater form was the worse half: the
    // updater returns a full `E`, it was spread as `Partial<E>`, so an updater
    // that REMOVED a key left the old value in place and nothing said so.
    //
    // Fixed by changing the CODE, not the comment, and the updater form is why
    // there was no other choice: an updater returns a full `E`, so under merge
    // semantics it is IMPOSSIBLE to express removing a key — the spread puts the
    // old value straight back. Merge cannot host this signature. Either the
    // callable replaces or the updater form has to be deleted.
    //
    // Not `setOne(entity)`: that would derive the key via `selectId(entity)`, and
    // `changeId` can leave `entity.id` disagreeing with the storage key, so it has
    // a silent wrong-slot write built in. The explicit form is `replaceOne(id, next)`,
    // which is public and is what this delegates to.
    //
    // MERGE is still available and still positional: `updateOne(id, changes)` for
    // a patch, or `byId(id).field.set(v)` for one field.
    // Resolve the per-entity signal on EVERY read rather than capturing it
    // once. Capturing it made a held node reference permanently dead across a
    // remove -> re-add of the same id: `removeEntitySignal` deletes the signal
    // from the map, the re-add creates a NEW one, and the captured reference
    // kept reading the orphaned signal — `undefined` forever, while a fresh
    // `byId()` worked. Holding a reference to a nested position is the
    // capability this library has and its competitors do not, so it must
    // survive the collection churning underneath it.
    //
    // Subject reachability is now independent from subject retention. A
    // removed subject becomes structurally unreachable by clearing its active
    // key binding, while the retained subject id, signal, and cached node can
    // survive until a separate restoration or reclamation decision.
    const handle = acquireEntityHandleForTesting(initialKey);
    if (handle === undefined || handle.subjectId !== subjectId) {
      throw new Error(
        `Entity with id ${String(initialKey)} has no acquired subject handle`
      );
    }

    // `SUBJECT-STATE-SEMANTIC-0`. The registry is weak, so THIS closure is what
    // keeps the activation carrier alive: while a caller holds this node, its
    // carrier cannot be collected out from under a pending bump. Captured on
    // first read rather than at node creation, so `byId` alone still realizes
    // nothing.
    let activationCarrier: Location<number> | undefined;
    const currentKey = (): K | undefined => {
      (activationCarrier ??= getSubjectStateSignal(subjectId))();
      const resolved = structuralStore.resolveSubjectHandle(handle);
      return resolved.state === 'active' ? resolved.key : undefined;
    };

    const entitySig = () => {
      const key = currentKey();
      return key === undefined ? undefined : readEntityByKey(key);
    };

    const node = ((valueOrUpdater?: E | ((current: E) => E)): E | undefined => {
      if (valueOrUpdater === undefined) {
        return entitySig();
      }
      const key = currentKey();
      if (key === undefined) {
        throw new Error(`Entity with subject ${String(subjectId)} not found`);
      }
      const current = presentEntity(key);
      if (current === undefined) {
        throw new Error(`Entity with id ${String(key)} not found`);
      }
      const next =
        typeof valueOrUpdater === 'function'
          ? (valueOrUpdater as (c: E) => E)(current)
          : (valueOrUpdater as E);
      api.replaceOne(key, next);
      return undefined;
    }) as unknown as EntityNode<E>;

    // Field projections derive their read from the subject-owned entity location.
    // Writes delegate to api.updateOne so interceptors and tap handlers still run.
    for (const key of Object.keys(entity)) {
      const fieldKey = key as keyof E;
      const computeField = () => entitySig()?.[fieldKey];
      const writeField = (value: E[typeof fieldKey] | undefined) => {
        const key = currentKey();
        if (key === undefined) {
          throw new Error(`Entity with subject ${String(subjectId)} not found`);
        }
        api.updateOne(key, { [fieldKey]: value } as Partial<E>);
      };
      const fieldSignal = locations.createWritableProjection
        ? locations.createWritableProjection(computeField, writeField)
        : createWritableProjection(
            locations.createDerived(computeField),
            writeField
          );

      if (ownerMetadataEnabled) {
        Object.defineProperty(fieldSignal, '__ownerPath', {
          get: () => {
            const key = currentKey();
            return key === undefined ? undefined : `${basePath}.${String(key)}`;
          },
          enumerable: false,
          configurable: true,
        });
      }
      if (subjectMetadataEnabled) {
        Object.defineProperty(fieldSignal, '__subjectIds', {
          get: () => [subjectId],
          enumerable: false,
          configurable: true,
        });
      }
      if (positionMetadataEnabled) {
        Object.defineProperty(fieldSignal, '__positionIds', {
          get: getPositionIds,
          enumerable: false,
          configurable: true,
        });
      }

      Object.defineProperty(node, key, {
        get: () => fieldSignal,
        enumerable: true,
        configurable: true,
      });
    }

    return node;
  }

  function getOrCreateNode(id: K, entity: E): EntityNode<E> {
    const subjectId = requireSubjectId(id);

    let node = nodeCache.get(subjectId)?.deref();
    if (!node) {
      node = createEntityNode(subjectId, id, entity);
      nodeCache.set(subjectId, new WeakRef(node));
      nodeFinalizer?.register(node, subjectId);
    }
    return node;
  }

  function inspectSubjectResources(
    subjectId: number
  ): EntitySubjectPhysicalInventory<K> | undefined {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState) {
      return undefined;
    }

    const node = nodeCache.get(subjectId)?.deref();
    const fieldFacadesMaterialized =
      node === undefined
        ? []
        : Object.keys(node as Record<string, unknown>)
            .filter(
              (key) =>
                typeof (node as Record<string, unknown>)[key] === 'function'
            )
            .sort((left, right) => left.localeCompare(right));

    return {
      subjectId,
      state: subjectState.active ? 'active' : 'tombstoned',
      subjectRevision: getSubjectRevision(subjectId),
      activeKey: subjectState.active ? subjectState.key : undefined,
      retainedSubjectState: structuralStore.hasSubject(subjectId),
      entitySignal: subjectEpochs.has(subjectId),
      activationToken: subjectStateSignals.get(subjectId)?.deref() !== undefined,
      nodeFacadeMaterialized: node !== undefined,
      fieldFacadesMaterialized,
      positionIds: getPositionIds(),
      retainedValueBacking: valueStore.hasRetainedValueBacking(subjectId)
        ? { kind: 'retained-entity-signal' }
        : undefined,
    };
  }

  function listSubjectReclamationCandidates(): readonly number[] {
    return structuralStore
      .tombstonedSubjectsSnapshot()
      .filter((subjectId) => valueStore.hasRetainedValueBacking(subjectId));
  }

  function prepareSubjectReclamation(
    subjectId: number,
    options: EntitySubjectReclamationPlanningOptions
  ): PreparedEntitySubjectReclamation | undefined {
    const inventory = inspectSubjectResources(subjectId);
    if (!inventory) {
      return undefined;
    }

    const plan = planEntitySubjectReclamation(inventory, options);
    if (!plan.eligible) {
      return undefined;
    }

    return {
      subjectId,
      expectedLifetime: 'tombstoned',
      expectedSubjectRevision: inventory.subjectRevision,
      retire: plan.retire,
      retain: plan.retain,
    };
  }

  function applyPreparedSubjectReclamation(
    prepared: PreparedEntitySubjectReclamation
  ): void {
    const state = resolveSubjectState(prepared.subjectId);
    if (prepared.expectedLifetime !== 'tombstoned') {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} has an unsupported expected lifetime.`
      );
    }
    if (!state) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }
    if (
      getSubjectRevision(prepared.subjectId) !==
      prepared.expectedSubjectRevision
    ) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} is stale.`
      );
    }
    if (state.active) {
      throw new Error(
        `Prepared reclamation for subject ${String(
          prepared.subjectId
        )} no longer matches active lifetime state.`
      );
    }

    const frame = createEntityMutationFrame();
    const forgetLifetime = prepared.retire.includes('subject-lifetime-record');
    const retiresValue = prepared.retire.includes('retained-value-backing');
    if (forgetLifetime || retiresValue) {
      // ONE mutation covers both: `retire-retained-value` deletes the value and
      // then either `retireSubject` (keep a `{active:false,
      // restoreAllowed:false}` record) or `forgetSubject` (drop it entirely).
      // Staging it even when there is no value left is what lets a subject
      // whose bytes went earlier still lose its ledger entry.
      const retirement: PreparedRetainedValueRetirement = {
        kind: 'retire-retained-value',
        subjectId: prepared.subjectId,
        forgetLifetime,
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(prepared.subjectId);
    }

    const result = commitAndProjectEntityMutationFrame(frame);
    for (const changedSubjectId of result.physicallyChangedSubjectIds) {
      if (forgetLifetime && changedSubjectId === prepared.subjectId) {
        // NO PUBLISH for a forgotten subject, and this is load-bearing rather
        // than an optimization. `publishSubjectPhysicalChange` ->
        // `bumpSubjectRevision` does `subjectRevisions.set(id, ...)`, which
        // RE-INTERNS the entry `forgetSubject` just deleted. Deleting from a
        // Map does not stay deleted if a later step in the same operation
        // interns by the same key.
        //
        // `reclaimRetiredSubjectsWithoutOwner` documents this as the 79 B
        // versus 6 B measurement, and the sink reintroduced it here: with the
        // publish in place `subjectRevisions` grew to one entry per subject
        // ever created — 64,200 at 320 rounds while every other structure sat
        // at 4,200 — and it was the whole remaining retention slope.
        //
        // Nothing is left to notify either: the entity signal was deleted
        // above, and the activation channel is interned lazily, so a subject
        // nobody read has none.
        continue;
      }
      publishSubjectPhysicalChange(changedSubjectId);
    }
  }

  /**
   * ZERO-OWNER RECLAMATION — the only reclamation that runs automatically.
   *
   * When the tree has no restoration authority, a tombstoned subject's retained
   * value backing is unreachable: nothing can undo, roll back, or re-project it,
   * so the bytes are held against a restore that cannot be requested. This
   * releases them at the moment of retirement.
   *
   * ## Why this needs no causal assessment
   *
   * `runPhysicalMaintenance` exists for the hard case and asks a real question —
   * is any turn, pending turn, applied-restoration history entry or redo entry still
   * referencing this subject? Answering it requires a `TurnStore` and an
   * `AppliedTurnProjection`, which a tree without `causal-runtime` does not have. That
   * absence is not a gap to work around; it IS the answer. With no owner there
   * are no turns, so there is nothing a turn could be holding.
   *
   * This is therefore NOT a bypass of the coordinator, and must not grow into
   * one. The moment a tree has restoration authority this function returns
   * immediately, and reclaiming there stays the coordinator's problem — it needs
   * history-aware eligibility, which is a separate piece of work.
   *
   * ## What it reclaims: EVERYTHING physical, the lifetime ledger included
   *
   * The value backing, the entity signal, the subject lifetime record and the
   * revision entry. Retention is 6 B per retired subject, down from 249 B before
   * any reclamation and 117 B when the ledger was kept — and it no longer grows
   * with the number of retirements at all.
   *
   * Keeping the ledger was believed to be what stale-handle isolation rested on.
   * It is not, and that was FALSIFIED rather than assumed: every semantic gate,
   * including the four GC-dependent properties in
   * `check-signal-identity-durability.mjs`, passes with it deleted.
   *
   * Isolation is anchored in SUBJECT identity, not key identity. `nextSubjectId`
   * only increases and `tombstoneSubject` already removed the key -> subject
   * mapping, so a re-add of the same business key is a different subject by
   * construction. A held reference keeps reading `undefined` because the
   * CONSUMER holds the orphaned signal and, with the map entry gone, nothing can
   * ever write to it again.
   *
   * The price, both on internal surfaces: `resolveSubjectHandle` reports
   * `missing` rather than `tombstoned` for a forgotten subject, and the subject
   * leaves `__listSubjectReclamationCandidates` — correct, since it has nothing
   * left to reclaim. `entity-lifetime-ledger-null.spec.ts` pins both.
   *
   * ⚠️ `planRestore`'s "has retired backing and cannot be restored" guard loses
   * its input for a forgotten subject. Acceptable ONLY because a tree with no
   * restoration authority has no reachable restore at all, so the guard becomes
   * unreachable rather than unenforced. If a restorer can exist, none of this
   * runs.
   *
   * See docs/architecture/retired-subject-churn.md and
   * docs/architecture/restoration-ownership-inventory.md.
   */
  function reclaimRetiredSubjectsWithoutOwner(
    subjectIds: readonly number[]
  ): void {
    if (hasRestorationAuthority || subjectIds.length === 0) {
      return;
    }

    const frame = createEntityMutationFrame();
    let staged = 0;
    for (const subjectId of subjectIds) {
      const state = resolveSubjectState(subjectId);
      // Still active means this was not a retirement after all. A missing state
      // means the subject is already gone. Neither is reclaimable.
      if (!state || state.active) {
        continue;
      }
      if (!valueStore.hasRetainedValueBacking(subjectId)) {
        continue;
      }
      const retirement: PreparedRetainedValueRetirement = {
        kind: 'retire-retained-value',
        subjectId,
        forgetLifetime: true,
      };
      frame.stageRetainedValueRetirement(retirement);
      subjectEpochs.delete(subjectId);
      // The lifetime is forgotten and its id is never reused, so nothing can
      // bump this subject again; keeping the entry was ~100 B per retired
      // subject once its node had been read (now guarded directly by retired-lifetime-cleanup).
      // A node still held by a caller keeps its own carrier in its closure.
      subjectStateSignals.delete(subjectId);
      staged += 1;
    }

    if (staged === 0) {
      return;
    }

    commitAndProjectEntityMutationFrame(frame);

    // DELIBERATELY NO PUBLISH, and this is load-bearing rather than an omission.
    // `publishSubjectPhysicalChange` -> `bumpSubjectRevision` writes
    // `subjectRevisions.set(id, 1)`, which RESURRECTS the entry the forget just
    // deleted — measured at 79 B/retired instead of 6 B until it was found.
    // Deleting from a Map does not stay deleted if a later step in the same
    // operation interns by the same key.
    //
    // There is also nothing left to notify: the entity signal was deleted in the
    // loop above, and the activation token is interned lazily, so a subject
    // nobody read has none.
  }

  function retireSubjectRetainedValueBackingForTesting(
    subjectId: number
  ): void {
    const subjectState = resolveSubjectState(subjectId);
    if (!subjectState || subjectState.active) {
      throw new Error(
        `Subject ${String(
          subjectId
        )} must be tombstoned before retiring retained value backing.`
      );
    }

    valueStore.retireSubjectValue(subjectId);
    subjectEpochs.delete(subjectId);
  }

  // ==================
  // API OBJECT
  // ==================

  // Caches for predicate-based queries. Uses WeakMap keyed by function
  // reference so callers that pass the same function object will receive the
  // same computed Signal instance (reduces redundant computed creation).
  // NOTE: This only works reliably when callers pass stable, named
  // predicate references. Inline anonymous predicates will not be cached.
  const whereCache: WeakMap<
    (entity: E) => boolean,
    ReadableCell<E[]>
  > = new WeakMap();
  const findCache: WeakMap<
    (entity: E) => boolean,
    ReadableCell<E | undefined>
  > = new WeakMap();

  const api = {
    // ==================
    // EXPLICIT ACCESS
    // ==================

    byId(id: K): EntityNode<E> | undefined {
      if (!rowAbsent() && structuralStore.hasActiveKey(id)) {
        // Present: subscribe to the PER-ENTITY signal only, so callers re-run
        // when THIS entity changes but not when others do (body-granular).
        // Materialized lazily here — bounded by the number of live entities.
        const entity = readEntityByKey(id);
        return entity ? getOrCreateNode(id, entity) : undefined;
      }
      // Absent: subscribe to the shared ids signal for "appears later"
      // reactivity WITHOUT materializing a permanent per-entity signal for an
      // id that may never exist (which would leak one signal per probed id).
      idsSignal();
      return undefined;
    },

    byIdOrFail(id: K): EntityNode<E> {
      const node = api.byId(id);
      if (!node) {
        throw new Error(`Entity with id ${String(id)} not found`);
      }
      return node;
    },

    // ==================
    // QUERIES (return Signals)
    // ==================

    get all(): ReadableCell<E[]> {
      return allSignal;
    },

    get count(): ReadableCell<number> {
      return countSignal;
    },

    get ids(): ReadableCell<K[]> {
      return idsSignal;
    },

    /**
     * The collection as a `ReadonlyMap`, keyed by id.
     *
     * Named `asMap` since 14.1.1. It was `map`, which read as a PROJECTION beside
     * `all()` — every JS developer expects `.map(fn)` to transform elements, and an
     * agent or newcomer reaching for that is a documented failure class (see
     * `WRONG_ENTITY_METHODS`). `asMap` says what it returns.
     */
    get asMap(): ReadableCell<ReadonlyMap<K, E>> {
      return mapSignal;
    },

    // ── Active entity ───────────────────────────────────────────────────────
    get activeId(): ReadableCell<K | undefined> {
      return activeIdSignal.asReadonly();
    },

    /**
     * Resolved through the per-entity signal, NOT through `mapSignal`.
     *
     * That is the whole reason to build this here rather than leave it to the
     * app: a hand-rolled `getDerivedRuntime().createDerived(() => all().find(e => id(e) === activeId()))`
     * depends on the entire collection, so it recomputes when ANY row changes.
     * This depends on the active row's own signal, so it recomputes only when
     * that row changes — which is what `byId` exists for.
     */
    get activeEntity(): ReadableCell<E | undefined> {
      const read = () => {
        const id = activeIdSignal();
        if (id === undefined) return undefined;
        return readEntityByKey(id);
      };
      return (cachedActiveEntity ??= locations.createDerived(read));
    },

    setActiveId(id: K | undefined): void {
      // Not an error when the id is absent: selection frequently outlives the
      // row (a delete arriving from a socket while a detail pane is open), and
      // `activeEntity` already resolves to undefined in that case.
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, id);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },

    clearActiveId(): void {
      const previous = activeIdSignal();
      replaceLocation(activeIdSignal, undefined);
      if (!Object.is(previous, activeIdSignal())) markOwnerInvalidated(ownerId);
    },

    has(id: K): ReadableCell<boolean> {
      const read = () => !absent() && structuralStore.hasActiveKey(id);
      return createVersionedProjection(read);
    },

    // Bare canonical name (the `.isEmpty` alias was removed in v11).
    get empty(): ReadableCell<boolean> {
      return (cachedEmpty ??= locations.createDerived(
        () => countSignal() === 0
      ));
    },

    where(predicate: (entity: E) => boolean): ReadableCell<E[]> {
      const cached = whereCache.get(predicate);
      if (cached) return cached;

      if (typeof ngDevMode === 'undefined' || ngDevMode) {
        warnOnPredicateChurn('where', predicate);
      }
      // Filter DURING iteration rather than materialising `all` and discarding
      // most of it. `allSignal()` builds an array of every entity; `.filter()`
      // then walks it again and keeps a few. Iterating `storage.values()`
      // straight into the result array skips the intermediate entirely.
      //
      // MEASURED in situ, one process per arm, updateOne baseline subtracted.
      // Ranges because the spread across runs is wide — quote the shape, not a
      // point figure:
      //     N=100      1.2us -> 1.3us   (neutral; not worth it at this size)
      //     N=1,000    6.9us -> 2.6us
      //     N=10,000  67-73us -> 24-47us
      //     N=100,000  826us -> 328us
      // So roughly 2-3x from N=1,000 up, and nothing below a few hundred.
      //
      // ⚠️ Measured on a machine running other work. Alternating order
      // (after/before/after) held the ordering and the two `after` runs
      // agreed, so the DIRECTION is sound and the ranges do not overlap —
      // but treat the magnitudes as indicative and re-measure quiet before
      // publishing any of them.
      //
      // Only valid WITHOUT `sortComparer`. With one, `allSignal()` sorts, so
      // bypassing it would silently return insertion order instead of sorted
      // order — a behaviour change, not an optimisation. Without one,
      // `allSignal()` is `Array.from(storage.values())`, so the fast path is
      // order-IDENTICAL rather than merely order-equivalent.
      //
      // `version()` is read directly for the same invalidation `allSignal()`
      // has; the sorted branch gets it transitively.
      const s = createQueryProjection(() => {
        if (config.sortComparer) return allSignal().filter(predicate);
        const out: E[] = [];
        for (const entity of presentEntities()) {
          if (predicate(entity)) out.push(entity);
        }
        return out;
      });
      whereCache.set(predicate, s);
      return s;
    },

    find(predicate: (entity: E) => boolean): ReadableCell<E | undefined> {
      const cached = findCache.get(predicate);
      if (cached) return cached;

      if (typeof ngDevMode === 'undefined' || ngDevMode) {
        warnOnPredicateChurn('find', predicate);
      }
      // Same bypass as `where`, and the win here is algorithmic rather than a
      // constant factor: `allSignal().find()` builds the WHOLE array before
      // looking at the first element, so a match at index 5 of 10,000 still
      // costs O(N). Iterating stops at the match.
      //
      // MEASURED in situ at 10k, updateOne baseline subtracted:
      //     match at the END    52-61us -> 12-20us   (~3-5x)
      //     match at index 5      13.6us -> 0.2us    (~50x)
      // The second is the point: `find` goes from O(N) ALWAYS to O(position).
      // The first is the same intermediate-array saving as `where`.
      //
      // Sorted collections keep the old path: `find` returns the FIRST match,
      // which is order-dependent, so with a `sortComparer` the sorted array is
      // the only correct thing to scan. See the note on `where` above.
      const s = createQueryProjection(() => {
        if (config.sortComparer) return allSignal().find(predicate);
        for (const entity of presentEntities()) {
          if (predicate(entity)) return entity;
        }
        return undefined;
      });
      findCache.set(predicate, s);
      return s;
    },

    // ==================
    // MUTATIONS: ADD
    // ==================

    addOne(entity: E, opts?: AddOptions<E, K>): K {
      return addOneRow(entity, opts);
    },

    /**
     * Insert at the FRONT: `prependMany` of one row, so duplicate detection,
     * interceptors, notifier and taps stay on exactly one path.
     *
     * Moving the entry rebuilds the order — O(n) in the number of entities, and
     * still markedly cheaper than the `setAll([entity, ...existing])` this
     * replaces: only the newcomer's signal changes, so held nodes survive and no
     * unrelated row's consumers are invalidated.
     */
    prependOne(entity: E, opts?: AddOptions<E, K>): K {
      // Strict, reading only what AddOptions defines: forwarded whole, a cast
      // `{ mode }` reached addRows (skip returned undefined, overwrite
      // replaced silently).
      return withMembershipGroup(() =>
        addRows('prependOne', [entity], { selectId: opts?.selectId }, true)
      )[0];
    },

    prependMany(entities: E[], opts?: AddManyOptions<E, K>): K[] {
      // Front, in the order given — so `prependMany([a, b])` reads back as
      // [a, b, ...existing], which is what the call site looks like.
      return withMembershipGroup(() =>
        addRows('prependMany', entities, opts, true)
      );
    },

    /**
     * Change an entity's id in place — the missing half of optimistic creation.
     *
     * Insert with a temp id, then adopt the id the server assigned. Everything
     * keyed by the old id moves together: storage (keeping list position), the
     * per-entity signal, the node cache, and the active-entity selection.
     *
     * Held row/field references follow the rekey by SUBJECT identity rather than
     * by the old key. The old lookup disappears, but already-materialized row
     * state, metadata, and field signals remain attached to the same subject.
     * That keeps list position, active selection, and row-local reactivity while
     * still allowing the freed id to be reused by a different subject.
     */
    changeId(from: K, to: K): void {
      const planned = planRekey(from, to);
      planned.commit();
      // `publish` only notifies, so an unobserved rekey skips it whole.
      if (pathObserved()) planned.publish();
    },

    addMany(entities: E[], opts?: AddManyOptions<E, K>): K[] {
      return addRows('addMany', entities, opts);
    },

    // ==================
    // MUTATIONS: UPDATE
    // ==================

    updateOne(id: K, changes: Partial<E>): void {
      const entity = requireEntity(id);

      const prev = entity;

      // Run interceptors
      const transformedChanges = interceptUpdatedEntity(id, changes);

      const finalUpdated = { ...entity, ...transformedChanges };
      // One value replacement, no structural consequence — commit it directly.
      // See `commitExistingSubjectValue` for why this is the whole case.
      const subjectIdForWrite = rememberSubjectId(id);
      commitExistingSubjectValue(subjectIdForWrite, finalUpdated);
      syncEntitySignal(id);
      updateSignals();

      // Notify PathNotifier
      if (pathObserved()) {
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          finalUpdated,
          prev,
          basePath,
          lastSubjectIds,
          getPositionIdsForNotify(),
          ambientMeta()
        );
      }

      // Run tap handlers
      emitTap('onUpdate', id, transformedChanges, finalUpdated);
    },

    /**
     * Replace, not merge — and the write path behind `byId(id)(next)`.
     *
     * Identical to `updateOne` except the one line that matters: assign the whole
     * entity instead of spreading it over the current one. That single difference
     * is the only way to REMOVE a key, which `updateOne` cannot express at all.
     *
     * **Why `replaceOne(id, entity)` and not `setOne(entity)`.** The id comes from
     * the caller on purpose. A `setOne` deriving it via `selectId(entity)` writes
     * to whatever slot the entity's own id field names — and `changeId` can leave
     * `entity.id` disagreeing with the storage key, so that form has a silent
     * wrong-slot write built into it. This one cannot drift.
     */
    replaceOne(id: K, entity: E): void {
      const prev = requireEntity(id);

      const next = interceptReplacedEntity(id, entity);

      const subjectId = requireSubjectId(id);

      const replacement: PreparedValueReplacement<K, E> = {
        kind: 'replace-value',
        key: id,
        subjectId,
        nextValue: next,
      };
      const frame = createEntityMutationFrame();
      frame.stageValueReplacement(replacement);
      commitAndProjectEntityMutationFrame(frame);
      syncEntitySignal(id);
      updateSignals();
      if (pathObserved()) pathNotifier.notify(
        `${basePath}.${String(id)}`,
        next,
        prev,
        basePath,
        // REPLACE-ONE-SUBJECT-1. This was `undefined`, and it was the ONLY
        // entity notification in this file that dropped subject identity —
        // `updateOne`, `updateMany` and `removeOne` all pass theirs. The id
        // above is DATA; `subjectId` is IDENTITY, and it was already resolved
        // from `structuralStore` a few lines up, so nothing new is looked up
        // here.
        //
        // Without it, reversal effects arrive with `subjectId: undefined`,
        // `hasInlineSubjectAddress` is false, no inline subject address is
        // derived, and no fallback descriptor can be keyed — so rollback and
        // undo both REFUSE, at TOP level as well as nested.
        [subjectId],
        getPositionIdsForNotify(),
        ambientMeta()
      );
      emitTap('onUpdate', id, next as Partial<E>, next);
    },

    updateMany(ids: K[], changes: Partial<E>): void {
      if (ids.length === 0) return;
      const frontier = structuralStore.activeOrderFrontier();

      // Collect entities and run interceptors first
      const updatedEntities = ids.map((id) => {
        requireEntity(id);
        return {
          id,
          subjectId: requireSubjectId(id),
          transformedChanges: interceptUpdatedEntity(id, changes),
        } as {
          id: K;
          subjectId: number;
          transformedChanges: Partial<E>;
          prev: E;
          finalUpdated: E;
        };
      });
      // As the add calls: an interceptor that changed membership, order or a
      // named row's key leaves this plan stale (a rename was lost, a vanished
      // row announced) - refuse before writing.
      refuseTopologyChange('updateMany', frontier, updatedEntities);
      // Every row merges over its value as ALL the interceptors left it, as
      // upsertMany does: read per row, right after its own interceptors, a
      // later row's interceptor writing an earlier row was lost (85db805e).
      for (const row of updatedEntities)
        row.finalUpdated = {
          ...(row.prev = getProjectedEntity(row.id) as E),
          ...row.transformedChanges,
        };

      const frame = createEntityMutationFrame();
      for (const { id, subjectId, finalUpdated } of updatedEntities) {
        frame.stageValueReplacement({
          kind: 'replace-value',
          key: id,
          subjectId,
          nextValue: finalUpdated,
        });
      }
      commitAndProjectEntityMutationFrame(frame);

      for (const { id } of updatedEntities) {
        syncEntitySignal(id);
      }

      // Single signal update after all entities are updated
      updateSignals();

      lastSubjectIds = updatedEntities.map(({ subjectId }) => subjectId);

      // Notify PathNotifier for each updated entity
      if (pathObserved()) {
        const meta = ambientMeta();
        for (const { id, subjectId, prev, finalUpdated } of updatedEntities) {
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            finalUpdated,
            prev,
            basePath,
            [subjectId],
            getPositionIdsForNotify(),
            meta
          );
        }
      }

      // Run tap handlers for each updated entity
      for (const { id, transformedChanges, finalUpdated } of updatedEntities) {
        emitTap('onUpdate', id, transformedChanges, finalUpdated);
      }
    },

    updateWhere(
      predicate: (entity: E) => boolean,
      changes: Partial<E>
    ): number {
      const idsToUpdate: K[] = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToUpdate.push(id);
        }
      }
      if (idsToUpdate.length > 0) {
        api.updateMany(idsToUpdate, changes);
      }
      return idsToUpdate.length;
    },

    // ==================
    // MUTATIONS: REMOVE
    // ==================

    removeOne(id: K): void {
      const entity = requireEntity(id);
      // Run interceptors
      interceptRemovedEntity(id, entity);

      // Interceptors may install observers. Decide demand after they return,
      // while the removed row and its neighbours are still available.
      const observed = pathObserved();
      const { beforeSubject, afterSubject } = observed
        ? getNeighborSubjects(id)
        : NO_NEIGHBORS;

      // Delete and update signals
      const subjectIdsForWrite = [rememberSubjectId(id)];
      const structuralEffect: PendingStructuralEffect | undefined = observed
        ? {
            kind: 'remove',
            subject: subjectIdsForWrite[0],
            key: id,
            value: deepClone(entity),
            beforeSubject,
            afterSubject,
          }
        : undefined;
      const currentState = resolveSubjectState(subjectIdsForWrite[0]);
      const tombstone: PreparedSubjectTombstone<K> = {
        kind: 'tombstone-subject',
        key: id,
        subjectId: subjectIdsForWrite[0],
        restoreAllowed: currentState?.restoreAllowed ?? true,
      };
      const frame = createEntityMutationFrame();
      frame.stageSubjectTombstone(tombstone);
      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }
      tombstoneSubjectSignal(subjectIdsForWrite[0]);
      reclaimRetiredSubjectsWithoutOwner([subjectIdsForWrite[0]]);
      updateSignals();

      // Notify PathNotifier
      if (structuralEffect) {
        pathNotifier.notify(
          `${basePath}.${String(id)}`,
          undefined,
          entity,
          basePath,
          subjectIdsForWrite,
          getPositionIdsForNotify(),
          createStructuralEffectMeta(structuralEffect)
        );
      }

      // Run tap handlers
      emitTap('onRemove', id, entity);
    },

    removeMany(ids: K[]): void {
      if (ids.length === 0) return;
      const frontier = structuralStore.activeOrderFrontier();

      // Collect entities and run interceptors first
      const preparedRemovals: Array<{
        id: K;
        entity: E;
        subjectId: number;
        beforeSubject?: number;
        afterSubject?: number;
      }> = ids.map((id) => {
        const entity = requireEntity(id);
        const subjectId = requireSubjectId(id);
        interceptRemovedEntity(id, entity);
        return { id, entity, subjectId };
      });
      refuseTopologyChange('removeMany', frontier, preparedRemovals);

      // The last interceptor can subscribe to the entire atomic removal.
      // Capture every row's neighbours before any tombstones are committed.
      const observed = pathObserved();
      if (observed) {
        for (const removal of preparedRemovals) {
          Object.assign(removal, getNeighborSubjects(removal.id));
        }
      }

      const subjectIdsForWrite = preparedRemovals.map(
        ({ subjectId }) => subjectId
      );
      lastSubjectIds = subjectIdsForWrite;

      const frame = createEntityMutationFrame();

      for (const { id, subjectId } of preparedRemovals) {
        const currentState = resolveSubjectState(subjectId);
        frame.stageSubjectTombstone({
          kind: 'tombstone-subject',
          key: id,
          subjectId,
          restoreAllowed: currentState?.restoreAllowed ?? true,
        });
      }

      const result = commitAndProjectEntityMutationFrame(frame);
      for (const changedSubjectId of result.physicallyChangedSubjectIds) {
        publishSubjectPhysicalChange(changedSubjectId);
      }

      subjectIdsForWrite.forEach(tombstoneSubjectSignal);
      reclaimRetiredSubjectsWithoutOwner(subjectIdsForWrite);

      // Single signal update after all entities are removed
      updateSignals();

      // Notify PathNotifier for each removed entity
      if (observed) {
        const meta = ambientMeta();
        for (const {
          id,
          entity,
          subjectId,
          beforeSubject,
          afterSubject,
        } of preparedRemovals) {
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            undefined,
            entity,
            basePath,
            [subjectId],
            getPositionIdsForNotify(),
            effectMeta(meta, {
              kind: 'remove',
              subject: subjectId,
              key: id,
              value: deepClone(entity),
              beforeSubject,
              afterSubject,
            })
          );
        }
      }

      // Run tap handlers for each removed entity
      for (const { id, entity } of preparedRemovals) {
        emitTap('onRemove', id, entity);
      }
    },

    removeWhere(predicate: (entity: E) => boolean): number {
      const idsToRemove: K[] = [];
      for (const [id, entity] of presentEntries()) {
        if (predicate(entity)) {
          idsToRemove.push(id);
        }
      }
      if (idsToRemove.length > 0) {
        api.removeMany(idsToRemove);
      }
      return idsToRemove.length;
    },

    // ==================
    // MUTATIONS: UPSERT
    // ==================

    upsertOne(entity: E, opts?: AddOptions<E, K>): K {
      const id = deriveId(entity, opts);
      if (structuralStore.hasActiveKey(id)) {
        api.updateOne(id, entity);
      } else {
        api.addOne(entity, opts);
      }
      return id;
    },

    upsertMany(entities: E[], opts?: AddOptions<E, K>): K[] {
      if (entities.length === 0) return [];
      const frontier = structuralStore.activeOrderFrontier();

      // Upserted one at a time, as successive upsertOne calls would be: every
      // id is resolved first (nothing intercepted or written yet), then the
      // interceptors run once per COPY, in input order — onAdd for a new id's
      // first copy, onUpdate for each later copy (the raw copy), merged over
      // the running value. 778f86ef intercepted only the merged copy. Each
      // key is still announced and tapped once, with its final value.
      type Upsert = {
        id: K;
        prev?: E;
        /** Set for a row that exists; a fresh row's once it is committed. */
        subjectId?: number;
        /** A new row's running value: its first copy, then each later one. */
        entity?: E;
        changes?: Partial<E>;
      };
      const toAdd: Upsert[] = [];
      const toUpdate: Upsert[] = [];
      const copies: Array<[Upsert, E]> = [];
      const earlier = new Map<K, Upsert>();
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        let row = earlier.get(id);
        if (!row) {
          row = { id, subjectId: structuralStore.subjectIdForKey(id) };
          (row.subjectId === undefined ? toAdd : toUpdate).push(row);
          earlier.set(id, row);
        }
        copies.push([row, entity]);
      }
      for (const [row, entity] of copies) {
        if (row.subjectId === undefined && row.entity === undefined) {
          row.entity = interceptAddedEntity(entity);
        } else {
          const changes = interceptUpdatedEntity(row.id, entity);
          // A single copy hands on the interceptor's own object (tap identity).
          row.changes = row.changes ? { ...row.changes, ...changes } : changes;
          if (row.subjectId === undefined) row.entity = { ...row.entity, ...changes } as E;
        }
      }
      const rows = [...toAdd, ...toUpdate];
      refuseTopologyChange('upsertMany', frontier, rows);
      // An updated row merges over its value AFTER the interceptors, which may
      // have written its fields; read before, those writes were lost.
      for (const row of toUpdate) {
        row.entity = { ...(row.prev = getProjectedEntity(row.id)), ...row.changes } as E;
      }

      // Read after the interceptors, as addOne's is.
      const lastPreviousKey = structuralStore.lastActiveKey();
      const membershipUnit = beginMembershipUnit();
      try {
      // Ids are unique, so the fresh subjects index-align.
      const freshSubjectIds = commitFreshSubjects(toAdd.map(({ id }) => id));
      toAdd.forEach((row, i) => (row.subjectId = freshSubjectIds[i]));
      for (const { subjectId, prev, entity } of rows) {
        valueStore.retainSubjectValue(subjectId as number, entity as E);
        captureCommittedEntity(
          subjectId as number,
          prev,
          entity as E,
          prev === undefined
        );
      }

      membershipUnit.commit(membershipInventory.observed()
        ? toAdd.map(({ id, subjectId }) => membershipAddition(subjectId as number, id))
        : []);
      for (const { id } of toAdd) { invalidateNodeCache(id); syncEntitySignal(id); }
      for (const { id } of toUpdate) syncEntitySignal(id);

      // Single signal update after all entities are processed
      updateSignals();

      lastSubjectIds = rows.map(({ subjectId }) => subjectId as number);

      if (pathObserved()) {
        // An added row is announced as a structural add, anchored like
        // addMany's appended rows. Announced as a bare value, its undo threw
        // ("Unsupported scoped undo effect at rows.x") and its rollback left
        // the row — and the call's updates — in place (15.4.3).
        const meta = ambientMeta();
        let beforeSubject =
          lastPreviousKey === undefined
            ? undefined
            : allocateSubjectId(lastPreviousKey);
        for (const { id, entity, subjectId } of toAdd) {
          const subject = subjectId as number;
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            entity,
            undefined,
            basePath,
            [subject],
            getPositionIdsForNotify(),
            effectMeta(meta, {
              kind: 'add',
              subject,
              key: id,
              value: deepClone(entity),
              beforeSubject,
            })
          );
          beforeSubject = subject;
        }

        // Notify PathNotifier for updated entities
        for (const { id, prev, entity, subjectId } of toUpdate) {
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            entity,
            prev,
            basePath,
            [subjectId as number],
            getPositionIdsForNotify()
          );
        }
      }

      // Run tap handlers for added entities, then updated ones
      for (const { id, entity } of toAdd) {
        emitTap('onAdd', entity as E, id);
      }
      for (const { id, changes, entity } of toUpdate) {
        emitTap('onUpdate', id, changes as Partial<E>, entity as E);
      }

      return rows.map(({ id }) => id);
      } finally { membershipUnit.cancel(); }
    },

    // ==================
    // MUTATIONS: CLEAR/RESET
    // ==================

    clear(): void {
      // AUTHORS THE SAME STRUCTURAL REMOVALS `removeMany` DOES, and that is the
      // whole fix. Until 15.0 this tombstoned subjects and told the notifier
      // nothing, so the turn restoration recorded carried no structural effect:
      // `canUndo()` reported true, the first undo silently restored nothing, and
      // the next threw "Unsupported scoped undo effect at structural-drift".
      // Removing the same rows one at a time and undoing worked correctly, which
      // is what made it a defect rather than a limitation — see
      // `clear-not-undoable.spec.ts`.
      //
      // The entity VALUES and the neighbour subjects have to be captured BEFORE
      // anything is tombstoned: a `remove` effect carries the value it removed
      // and where it sat, and after the tombstone neither is reachable.
      const observed = pathObserved();
      const activeIds = structuralStore.activeKeysSnapshot();
      const activeSubjects = activeIds.map((id) => {
        const subjectId = requireSubjectId(id);
        const entity = getProjectedEntity(id);
        const { beforeSubject, afterSubject } = observed
          ? getNeighborSubjects(id)
          : NO_NEIGHBORS;
        return { id, subjectId, entity, beforeSubject, afterSubject };
      });

      const membershipUnit = beginMembershipUnit();
      const frontier = structuralStore.activeOrderFrontier();
      try {
      for (const { id, subjectId, entity } of activeSubjects) {
        const currentState = resolveSubjectState(subjectId);
        structuralStore.tombstoneSubject(
          subjectId,
          id,
          currentState?.restoreAllowed ?? true
        );
        captureCommittedEntity(subjectId, entity, undefined, true);
      }
      publishFrontier(frontier);

      membershipUnit.commit(membershipInventory.observed()
        ? activeSubjects.map(({ id, subjectId }) => ({ kind: 'remove' as const, lifetimeId: subjectId, key: id }))
        : []);
      for (const { subjectId } of activeSubjects) publishSubjectPhysicalChange(subjectId);

      // Per-subject, exactly as `removeOne` does — never a bulk reset (see the
      // tombstone above). A held reference has to keep reading through the SAME
      // signal so an undo re-publishes into it, which is the property
      // `check-signal-identity-durability.mjs` pins for `removeOne`. Zero-owner
      // trees still shed the entries, one line below.
      for (const { subjectId } of activeSubjects) {
        tombstoneSubjectSignal(subjectId);
      }
      reclaimRetiredSubjectsWithoutOwner(
        activeSubjects.map(({ subjectId }) => subjectId)
      );
      replaceLocation(activeIdSignal, undefined);
      lastSubjectIds = activeSubjects.map(({ subjectId }) => subjectId);
      updateSignals();

      if (observed) {
        const meta = ambientMeta();
        for (const {
          id,
          subjectId,
          entity,
          beforeSubject,
          afterSubject,
        } of activeSubjects) {
          if (!entity) continue;
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            undefined,
            entity,
            basePath,
            [subjectId],
            getPositionIdsForNotify(),
            effectMeta(meta, {
              kind: 'remove',
              subject: subjectId,
              key: id,
              value: deepClone(entity),
              beforeSubject,
              afterSubject,
            })
          );
        }
      }

      for (const { id, entity } of activeSubjects) {
        if (!entity || silentClear) continue;
        emitTap('onRemove', id, entity);
      }
      } finally { membershipUnit.cancel(); }
    },

    setAll(entities: E[], opts?: AddOptions<E, K>): void {
      // Pre-state from ONE walk of the structural order: each row's key and
      // subject come off its node, so nothing below re-resolves a current row.
      // (This used to build [key, value] tuples, then a Set of keys, then a
      // second lookup pass for the subjects — ~20 hash operations per row.)
      const currentKeys: K[] = [];
      const currentSubjects: number[] = [];
      structuralStore.snapshotActiveOrder(currentKeys, currentSubjects);
      const beforeOrderFrontier = structuralStore.activeOrderFrontier();
      const intercepting = activeInterceptors().length > 0;

      // The incoming order, deduplicated (last value wins), in parallel
      // arrays. `incomingSubjects` holds the existing subject of an update and
      // is filled in for each add once its fresh subject exists.
      const incomingIndex = new Map<K, number>();
      const incomingIds: K[] = [];
      const incomingEntities: E[] = [];
      const incomingSubjects: Array<number | undefined> = [];
      for (const entity of entities) {
        const id = deriveId(entity, opts);
        const existing = structuralStore.subjectIdForKey(id);
        const transformedEntity = !intercepting
          ? entity
          : existing !== undefined
          ? interceptReplacedEntity(id, entity)
          : interceptAddedEntity(entity);

        const index = incomingIndex.get(id);
        if (index === undefined) {
          incomingIndex.set(id, incomingIds.length);
          incomingIds.push(id);
          incomingEntities.push(transformedEntity);
          incomingSubjects.push(existing);
          continue;
        }
        if (
          (typeof ngDevMode === 'undefined' || ngDevMode) &&
          !warnedDuplicateSetAllId
        ) {
          warnedDuplicateSetAllId = true;
          console.warn(
            'SignalTree entityMap.setAll: duplicate keys; last value wins. ' +
              'Supply unique IDs instead of a shared fallback. [ST2001]'
          );
        }
        incomingEntities[index] = transformedEntity;
      }

      const stagedRemovals: Array<{
        id: K;
        entity: E;
        subjectId: number;
        /** Position in the pre-state order, for the removal's neighbours. */
        index: number;
      }> = [];
      for (let index = 0; index < currentKeys.length; index += 1) {
        const id = currentKeys[index];
        if (incomingIndex.has(id)) continue;
        const subjectId = currentSubjects[index];
        const entity = valueStore.backingForSubject(subjectId);
        if (entity === undefined) continue;
        interceptRemovedEntity(id, entity);
        stagedRemovals.push({ id, entity, subjectId, index });
      }

      // A callback may have changed membership, keys, or order. Those writes
      // stand, but this operation must not commit its now-stale topology plan.
      refuseTopologyChange(
        'setAll',
        beforeOrderFrontier,
        [],
        currentKeys.some(
          (key, index) =>
            structuralStore.subjectIdForKey(key) !== currentSubjects[index]
        )
      );

      const stagedUpdates: Array<{
        id: K;
        prev: E;
        entity: E;
        subjectId: number;
      }> = [];
      const stagedAdds: Array<{ id: K; entity: E; index: number }> = [];
      for (let index = 0; index < incomingIds.length; index += 1) {
        const id = incomingIds[index];
        const entity = incomingEntities[index];
        const subjectId = incomingSubjects[index];
        if (subjectId === undefined) {
          stagedAdds.push({ id, entity, index });
          continue;
        }
        const prev = valueStore.backingForSubject(subjectId);
        if (prev === undefined) {
          throw new Error(`Entity with id ${String(id)} not found`);
        }
        stagedUpdates.push({ id, prev, entity, subjectId });
      }

      const membershipUnit = beginMembershipUnit();
      try {
      // Index-aligned with `stagedAdds`.
      const addedSubjectIds = commitFreshSubjects(
        stagedAdds.map(({ id }) => id)
      );
      for (let k = 0; k < stagedAdds.length; k += 1) {
        incomingSubjects[stagedAdds[k].index] = addedSubjectIds[k];
      }
      // Every incoming row now has its subject: this IS the after-order.
      const afterSubjects = incomingSubjects as number[];

      // Everything from here to the notify loops that exists only to be
      // published is built only when something can receive it.
      const observed = pathObserved();
      const stagedRemovalStructuralEffects: PendingStructuralEffect[] = [];
      if (observed) {
        for (const { id, entity, subjectId, index } of stagedRemovals) {
          // Immediate pre-state neighbours, removed or surviving, exactly as
          // clear() and removeMany() record them. Anchoring only to survivors
          // left adjacent removals with identical anchors, so their reversal
          // order depended on replay order: [a,b,c] -> [q,a] rolled back to
          // [a,c,b], and replacing every row undid to [c,b,a].
          stagedRemovalStructuralEffects.push({
            kind: 'remove',
            subject: subjectId,
            key: id,
            value: deepClone(entity),
            beforeSubject: index > 0 ? currentSubjects[index - 1] : undefined,
            afterSubject: currentSubjects[index + 1],
          });
        }
      }

      for (const { id, subjectId, entity } of stagedRemovals) {
        const currentState = resolveSubjectState(subjectId);
        structuralStore.tombstoneSubject(
          subjectId,
          id,
          currentState?.restoreAllowed ?? true
        );
        captureCommittedEntity(subjectId, entity, undefined, true);
      }

      for (const { subjectId, entity, prev } of stagedUpdates) {
        valueStore.retainSubjectValue(subjectId, entity);
        captureCommittedEntity(subjectId, prev, entity, false);
      }

      for (let k = 0; k < stagedAdds.length; k += 1) {
        const entity = stagedAdds[k].entity;
        valueStore.retainSubjectValue(addedSubjectIds[k], entity);
        captureCommittedEntity(addedSubjectIds[k], undefined, entity, true);
      }

      structuralStore.reorderActiveKeys(incomingIds);

      // Only `__subjectIds` reads this, and it exists only with subject
      // metadata.
      if (subjectMetadataEnabled) {
        const participants: number[] = [];
        for (const { subjectId } of stagedRemovals) participants.push(subjectId);
        for (const { subjectId } of stagedUpdates) participants.push(subjectId);
        appendAll(participants, addedSubjectIds);
        lastSubjectIds = participants;
      }

      const membershipChanges: EntityMembershipChange[] = [];
      if (membershipInventory.observed()) {
        appendAll(membershipChanges, stagedRemovals.map(({ id, subjectId }) => ({ kind: 'remove' as const, lifetimeId: subjectId, key: id })));
        appendAll(membershipChanges, stagedAdds.map(({ id }, index) => membershipAddition(addedSubjectIds[index], id)));
      }
      if (membershipInventory.observed(true) && survivingOrderChanged(currentSubjects, afterSubjects)) membershipChanges.push({ kind: 'reorder', before: currentSubjects, after: afterSubjects });

      // Captured whenever SURVIVING subjects change relative order, not only
      // for a pure reorder. Neighbour hints on the structural effects cannot
      // restore survivors that moved: reversing [a,b,c] -> [c,a] yielded
      // [b,c,a]. The order delta carries both endpoints, including subjects
      // present at only one of them. Membership-only changes keep relying on
      // the structural effects.
      //
      // The comparison walks the whole collection twice, so it runs only when
      // an order consumer is installed. Computed unconditionally, it made every
      // plain-tree setAll pay for it: refetch +8% at 10k rows and +11% at 50k
      // against 15.3.1 in benchmarks/store-comparison.
      if (
        orderConsumed() &&
        survivingOrderChanged(currentSubjects, afterSubjects)
      ) {
        publishOrderChange(beforeOrderFrontier, currentSubjects, afterSubjects);
      } else publishFrontier(beforeOrderFrontier);

      membershipUnit.commit(membershipChanges);
      for (const { subjectId } of stagedRemovals) { tombstoneSubjectSignal(subjectId); publishSubjectPhysicalChange(subjectId); }
      if (!hasRestorationAuthority && stagedRemovals.length > 0) {
        reclaimRetiredSubjectsWithoutOwner(
          stagedRemovals.map(({ subjectId }) => subjectId)
        );
      }
      // Only a realized subject has an epoch to stage.
      if (subjectEpochs.size > 0) {
        for (const subjectId of addedSubjectIds) stageSubjectEpoch(subjectId);
        for (const { subjectId } of stagedUpdates) stageSubjectEpoch(subjectId);
      }

      const stagedAddStructuralEffects: PendingStructuralEffect[] = [];
      if (observed) {
        for (let k = 0; k < stagedAdds.length; k += 1) {
          const { id, entity, index } = stagedAdds[k];
          stagedAddStructuralEffects.push({
            kind: 'add',
            subject: addedSubjectIds[k],
            key: id,
            value: deepClone(entity),
            // Every incoming row is active by now, so the nearest neighbour
            // with a subject is the adjacent one.
            beforeSubject: index > 0 ? afterSubjects[index - 1] : undefined,
            afterSubject: afterSubjects[index + 1],
          });
        }
      }

      updateSignals();

      if (observed) {
        const meta = ambientMeta();
        for (let index = 0; index < stagedRemovals.length; index += 1) {
          const { id, entity, subjectId } = stagedRemovals[index];
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            undefined,
            entity,
            basePath,
            [subjectId],
            getPositionIdsForNotify(),
            effectMeta(meta, stagedRemovalStructuralEffects[index])
          );
        }

        for (const { id, prev, entity, subjectId } of stagedUpdates) {
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            entity,
            prev,
            basePath,
            [subjectId],
            getPositionIdsForNotify(),
            meta
          );
        }

        for (let k = 0; k < stagedAdds.length; k++) {
          const { id, entity } = stagedAdds[k];
          pathNotifier.notify(
            `${basePath}.${String(id)}`,
            entity,
            undefined,
            basePath,
            [addedSubjectIds[k]],
            getPositionIdsForNotify(),
            effectMeta(meta, stagedAddStructuralEffects[k])
          );
        }
      }

      if (tapHandlers.length > 0) {
        for (const { id, entity } of stagedRemovals) {
          emitTap('onRemove', id, entity);
        }

        for (const { id, entity } of stagedAdds) {
          emitTap('onAdd', entity, id);
        }

        for (const { id, entity } of stagedUpdates) {
          emitTap('onUpdate', id, entity as Partial<E>, entity);
        }
      }
      } finally { membershipUnit.cancel(); }
    },

    // ==================
    // HOOKS
    // ==================

    tap(handlers: TapHandlers<E, K>): () => void {
      tapHandlers.push(handlers);
      return () => {
        const idx = tapHandlers.indexOf(handlers);
        if (idx > -1) tapHandlers.splice(idx, 1);
      };
    },

    intercept(handlers: InterceptHandlers<E, K>): () => void {
      assertSynchronousInterceptors(handlers);
      interceptHandlers.push(handlers);
      return () => {
        const idx = interceptHandlers.indexOf(handlers);
        if (idx > -1) interceptHandlers.splice(idx, 1);
      };
    },
  };

  // HISTORY SCOPE — removed in 15.0 with `recordHistory`. A collection is no
  // longer excludable from history by location; eligibility belongs to the
  // authored operation. See `undoable()` and the tombstone in utils.ts.
  if (subjectMetadataEnabled) {
    Object.defineProperty(api, '__subjectIds', {
      get: () => lastSubjectIds,
      enumerable: false,
      configurable: true,
    });
  }
  defineEntityMembershipSource(api, {
    install(create) {
      const inventory = create(readMembers);
      membershipInventory = inventory;
      defineEntityMembershipInventory(api, inventory);
      return inventory;
    },
  });
  defineEntityObservation(api, () => {
    if (positionId !== undefined) return;
    const registry = getPositionRegistry(api);
    if (!registry) return;
    positionId = registry.allocate();
    registry.registerCollectionPath(positionId, basePath);
    // No structured address here, unlike v16: this lazy allocation happens
    // only in a tree without position topology (`positionIdAllocator`
    // allocates eagerly otherwise, and materialization registers that
    // position's address), and only restoration and transactions read
    // addresses, which always enable topology (15.4.4 port, 8b).
    defineOwnedPositionIds(api, [positionId]);
  });
  if (positionMetadataEnabled) {
    Object.defineProperty(api, '__positionIds', {
      get: getPositionIds,
      enumerable: false,
      configurable: true,
    });
  }
  if (ownerMetadataEnabled) {
    defineOwnedOwnerPath(api, basePath);
  }

  // ⚠️ A ROW-ADDING WRITE TO AN ABSENT COLLECTION RE-ADDS ITS PATH, CARRYING
  // ONLY THE WRITTEN ROWS (v16 8e). The collection reads empty while it is
  // absent, so the write applies to an empty collection:
  // 1. it is validated and intercepted as on an empty collection, before
  //    anything changes, so a block or bad input (a strict duplicate
  //    included) changes nothing (v16 8f, ported; 8e intercepted after the
  //    removal below, which then stayed);
  // 2. the retained rows are removed through the ordinary `clear()`, which
  //    records them, so a reversal restores them; no tap sees it;
  // 3. the write runs with the rows already intercepted, interceptors
  //    suppressed, so each runs exactly once;
  // 4. every omitted member on its path comes back with only that path
  //    (`reactivatePathOnWrite`).
  // Retained rows never resurface, and undo, redo, jumpTo and rollback
  // reverse all of it. Writes that name an existing row refuse instead, as on
  // an empty collection. Only a structural write on this collection's own
  // tree (the whole value hydrating it, a reversal) writes it as it is.
  const clearRetained = api.clear;
  /**
   * The call's rows after its interceptors, as the write would intercept them
   * on an empty collection: ids resolved first (a strict duplicate throws
   * before any interceptor runs), then once per applied copy in input order —
   * `onAdd` for a key's first copy; for upserts, `onUpdate` with each later
   * raw copy, merged; otherwise the last copy wins in the first copy's place.
   * Ids stay those the raw rows give (`selectId`), as the write would key them.
   */
  const interceptAsEmpty = (
    name: string,
    args: unknown[]
  ): [unknown, AddManyOptions<E, K>] => {
    const opts = args[1] as AddManyOptions<E, K> | undefined;
    const many = name.endsWith('Many') || name === 'setAll';
    const input = (many ? args[0] : [args[0]]) as E[];
    const upsert = name.startsWith('upsert');
    const mode =
      name === 'addMany' || name === 'prependMany'
        ? opts?.mode ?? 'strict'
        : 'overwrite';
    const copies: Array<[K, E]> = [];
    const firsts = new Set<K>();
    for (const row of input) {
      const id = deriveId(row, opts);
      if (firsts.has(id)) {
        if (mode === 'strict')
          throw new Error(`Entity with id ${String(id)} already exists`);
        if (mode === 'skip') continue;
      }
      firsts.add(id);
      copies.push([id, row]);
    }
    const rows = new Map<K, E>();
    for (const [id, row] of copies) {
      const running = rows.get(id);
      rows.set(
        id,
        upsert && running !== undefined
          ? { ...running, ...interceptUpdatedEntity(id, row) }
          : interceptAddedEntity(row)
      );
    }
    const keys = new Map<E, K>();
    const out: E[] = [];
    for (const [id, row] of rows) {
      // One object for two ids (an interceptor that returns a shared object):
      // each id writes its own copy, keyed as the interceptors were.
      const own = keys.has(row) ? ({ ...row } as E) : row;
      keys.set(own, id);
      out.push(own);
    }
    const resolved = {
      ...opts,
      selectId: (row: E) => keys.get(row) ?? deriveId(row, opts),
    };
    return [many ? out : out[0], resolved];
  };
  for (const name of [
    'addOne',
    'prependOne',
    'addMany',
    'prependMany',
    'upsertOne',
    'upsertMany',
    'setAll',
    'clear',
  ] as const) {
    const write = api[name] as (...args: unknown[]) => unknown;
    (api as Record<string, unknown>)[name] = (...args: unknown[]) => {
      if (reAdding || !absent() || inStructuralWrite(proxy))
        return write(...args);
      const frontier = structuralStore.activeOrderFrontier();
      const prepared = name === 'clear' ? [] : interceptAsEmpty(name, args);
      // v15: an interceptor may not change the collection's topology, as in
      // every add call (15.4.0); one that wrote it refuses the write here.
      refuseTopologyChange(name, frontier, []);
      const writePrepared = () => {
        interceptsSuppressed++;
        try {
          return write(...prepared);
        } finally {
          interceptsSuppressed--;
        }
      };
      // An interceptor may have re-added it; and a call that adds nothing
      // (`addMany([])`) changes nothing, as on an empty collection. Either
      // way the write is an ordinary one now, its interceptors already run.
      if (
        !absent() ||
        (name !== 'setAll' &&
          Array.isArray(prepared[0]) &&
          !(prepared[0] as unknown[]).length)
      )
        return writePrepared();
      reAdding = pendingReAdd = true;
      try {
        // The retained rows were never visible, so their removal is no row
        // change to observe: taps do not see it (`silentClear`).
        silentClear++;
        try {
          clearRetained();
        } finally {
          silentClear--;
        }
        const result = writePrepared();
        // Re-added already if a tap was told of a row (`emitTap`).
        if (pendingReAdd) {
          pendingReAdd = false;
          reactivatePathOnWrite(api);
        }
        return result;
      } finally {
        reAdding = pendingReAdd = false;
      }
    };
  }
  // Its presence changed (it, or a member above it, was omitted or re-added):
  // every query and every held row re-reads (`republishMembers`).
  const wake = () =>
    locations.runInvalidationGroup(() => {
      for (const epoch of subjectEpochs.values()) advanceEpochHandle(epoch);
      deriveLocation(version, (value) => value + 1);
      markOwnerInvalidated(ownerId);
    });
  // Inside a structural write it wakes them once, after the write has closed
  // (`structuralWrites.end`, chained in order): a reversal being applied reads
  // rows physically (`physicalRows`), so a consumer re-run inside it would
  // cache what storage holds rather than the collection's absence. Installed
  // by the first such change, so a tree without collections carries none of
  // this. Every queued wake runs even if an earlier one throws.
  let wakeQueued = false;
  Object.defineProperty(api, MEMBERSHIP_CHANGED, {
    value: () => {
      if (!structuralWrites.depth) return wake();
      if (wakeQueued) return;
      wakeQueued = true;
      const earlier = structuralWrites.end;
      structuralWrites.end = (failed) => {
        structuralWrites.end = undefined;
        wakeQueued = false;
        // Every queued wake runs; the first consumer error is kept.
        let caught: { error: unknown } | undefined;
        for (const run of [() => earlier?.(failed), wake]) {
          try {
            run();
          } catch (error) {
            caught ??= { error };
          }
        }
        if (!caught) return;
        // Closing a reversal that threw: its own error is what surfaces, and
        // a consumer's is reported asynchronously.
        if (!failed) throw caught.error;
        const { error } = caught;
        queueMicrotask(() => {
          throw error;
        });
      };
    },
  });
  // ⚠️ THE PROJECTION SEED — internal, WeakMap-carried, never public.
  //
  // Built from the SAME ordered active-key snapshot `getProjectedEntries()`
  // uses, and the SAME `getProjectedEntity` row path, so a consumer's seeded
  // projection cannot drift from `all()` by construction.
  //
  // `key` is carried explicitly alongside `subjectId` because it is genuinely
  // separate information: after `changeId(1, 77)` the row payload still reads
  // `{ id: 1 }` while the address is 77, so `selectId(row)` cannot recover it.
  defineEntityProjectionSeed(api as object, () => {
    const seed: Array<{ subjectId: number; key: K; row: E }> = [];
    // An absent collection seeds an empty projection, as `all()` reads.
    for (const key of absent() ? [] : structuralStore.activeKeysSnapshot()) {
      const subjectId = structuralStore.subjectIdForKey(key);
      if (subjectId === undefined) continue;
      const row = getProjectedEntity(key);
      if (row === undefined) continue;
      seed.push({ subjectId, key, row });
    }
    return seed as readonly {
      subjectId: number;
      key: string | number;
      row: unknown;
    }[];
  }, config.sortComparer as EntityProjectionOrder | undefined);

  Object.defineProperty(api, '__findKeyBySubjectId', {
    value: findKeyBySubjectId,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planFreshAdd', {
    value: planFreshAdd,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__restoreOne', {
    value: restoreOne,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planRekey', {
    value: planRekey,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planPreparedRekey', {
    value: planPreparedRekey,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planRemove', {
    value: planRemove,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planRestore', {
    value: planRestore,
    enumerable: false,
    configurable: true,
  });
  if (positionId !== undefined) {
    Object.defineProperty(api, '__prepareTransitionTarget', {
      value: {
        owner: positionId,
        ownerPath: basePath,
        readSource: readTransitionSource,
        prepareTarget: prepareTransitionTarget,
        orderFrontier: structuralStore.activeOrderFrontier,
      } satisfies CollectionTransitionTargetBinding,
      enumerable: false,
      configurable: true,
    });
  }
  Object.defineProperty(api, '__inspectSubjectResources', {
    value: inspectSubjectResources,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__listSubjectReclamationCandidates', {
    value: listSubjectReclamationCandidates,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__planSubjectReclamation', {
    value: (
      subjectId: number,
      options: EntitySubjectReclamationPlanningOptions
    ) => {
      const inventory = inspectSubjectResources(subjectId);
      return inventory
        ? planEntitySubjectReclamation(inventory, options)
        : undefined;
    },
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__prepareSubjectReclamation', {
    value: prepareSubjectReclamation,
    enumerable: false,
    configurable: true,
  });
  Object.defineProperty(api, '__applyPreparedSubjectReclamation', {
    value: applyPreparedSubjectReclamation,
    enumerable: false,
    configurable: true,
  });
  // Testing seams, folded out of production builds (ngDevMode false) like
  // every other dev-only surface: nothing outside specs and tools reads them.
  if (typeof ngDevMode === 'undefined' || ngDevMode) {
    for (const [name, value] of Object.entries({
      __acquireEntityHandleForTesting: acquireEntityHandleForTesting,
      __resolveEntityHandleForTesting: resolveEntityHandleForTesting,
      __rebuildActiveProjectionFromOwnersForTesting:
        rebuildActiveProjectionFromOwners,
      __retireSubjectRetainedValueBackingForTesting:
        retireSubjectRetainedValueBackingForTesting,
    })) {
      Object.defineProperty(api, name, {
        value,
        enumerable: false,
        configurable: true,
      });
    }
  }

  // ==================
  // PROXY FOR BRACKET NOTATION
  // ==================

  // The Proxy only handles bracket notation access (signal[id])
  // All methods are direct properties on api - no binding needed
  const warnedWrongMethods = new Set<string>();
  const proxy = new Proxy(api as unknown as EntitySignal<E, K>, {
    get: (target: EntitySignal<E, K>, prop: string | symbol) => {
      // Handle string/number bracket access: signal[123] or signal['abc']
      if (typeof prop === 'string' && !isNaN(Number(prop))) {
        return api.byId(Number(prop) as K);
      }
      // Dev-mode guardrail: a known wrong-method name from another state
      // library → actionable hint instead of a later "undefined is not a
      // function". Only fires for names that are NOT real api members.
      if (
        (typeof ngDevMode === 'undefined' || ngDevMode) &&
        typeof prop === 'string' &&
        !(prop in (target as object)) &&
        WRONG_ENTITY_METHODS[prop] &&
        !warnedWrongMethods.has(prop)
      ) {
        warnedWrongMethods.add(prop);
        console.warn(
          `SignalTree entityMap has no \`.${prop}()\`. Did you mean: ` +
            `${WRONG_ENTITY_METHODS[prop]}? [ST2002]`
        );
      }
      // All other access goes directly to api
      return (target as unknown as Record<string | symbol, unknown>)[prop];
    },
  });
  return proxy;
}

Object.defineProperty(
  createEntitySignal,
  '__setPositionIdAllocatorForTesting',
  {
    value: setEntityPositionIdAllocatorForTesting,
    enumerable: false,
    configurable: true,
  }
);
Object.defineProperty(
  createEntitySignal,
  '__setPositionIdNotifyEnabledForTesting',
  {
    value: setEntityPositionIdNotifyEnabledForTesting,
    enumerable: false,
    configurable: true,
  }
);
