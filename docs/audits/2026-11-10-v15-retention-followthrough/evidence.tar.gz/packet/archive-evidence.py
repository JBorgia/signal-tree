from pathlib import Path
import os,hashlib,json,tarfile,gzip,io,shutil
q=Path(__file__).resolve().parent
roots=[Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-followthrough/docs/audits/2026-11-10-v15-v16-followthrough'),Path('/Users/jonathanborgia/code/signaltree/.worktrees/v15-retention-backport/docs/audits/2026-11-10-v15-retention-followthrough')]
files={}
for base,dirs,names in os.walk(q,followlinks=False):
 dirs[:]=sorted(d for d in dirs if d not in ('npm-cache','.angular','.git') and not (Path(base)/d).is_symlink())
 for name in sorted(names):
  p=Path(base)/name
  if not p.is_file() or p.is_symlink():continue
  files['packet/'+str(p.relative_to(q))]=p
manifest={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in files.items()}
archive=roots[0]/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
   def add(name,data):
    item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(data))
   add('MANIFEST.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
   for name,p in sorted(files.items()):
    data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==manifest[name]['sha256'];add(name,data)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
for root in roots:
 if root!=roots[0]:shutil.copy2(archive,root/'evidence.tar.gz')
 (root/'evidence.sha256').write_text(digest+'  evidence.tar.gz\n')
print(json.dumps({'payloads':len(files),'archiveBytes':archive.stat().st_size,'sha256':digest}))
