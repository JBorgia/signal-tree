import {s as se}from'./chunk-Boh1FAyR.js';import'./chunk-DQ4lmcJ1.js';import {h as aw,r as rd,Q as Qv,Z as Zo,a as XI,n as nc,z as zf,b as DI,l as ly,B as Bf,v as np,w as wI,i as ic,t as tp}from'./main-7PT5AKPJ.js';var v=(s,e)=>e.id;function x(s,e){if(s&1&&(Zo(0,"li")(1,"span",8),XI(2),nc(),Zo(3,"span",9),XI(4),nc(),Zo(5,"span",10),XI(6),nc()()),s&2){let t=e.$implicit,o=e.$index;ly(2),ic("#",o+1),ly(2),tp(t.name),ly(2),tp(t.score);}}var _=class s{codeFiles=[{label:"Keep scores sorted",language:"typescript",source:`import { entityMap, signalTree } from '@signal-tree/angular';

const store = signalTree({
  players: entityMap<Player, number>({
    selectId: (p) => p.id,
    sortComparer: (a, b) => b.score - a.score,
  }),
});
store.$.players.addMany(initialPlayers);
const player = store.$.players.byId(id)?.();
if (player) store.$.players.updateOne(id, { score: player.score + 50 });
store.$.players.all(); // highest score first
// Call store.destroy() when its owner is torn down.`},{label:"Read inside a transaction",language:"typescript",source:`import { entityMap, signalTree, transactions } from '@signal-tree/angular';

type Player = { id: number; score: number };
const store = signalTree({
  players: entityMap<Player, number>({
    sortComparer: (a, b) => b.score - a.score,
  }),
}, { enhancers: [transactions()] });
const all = store.$.players.all; // keep the same reader
const pending = store.transaction(() => {
  store.$.players.addOne({ id: 1, score: 120 });
  all(); // [{ id: 1, score: 120 }] immediately
  store.$.players.addOne({ id: 2, score: 150 });
  all(); // player 2, then player 1
  // Observers receive coherent publication when this group ends.
});
pending.confirm();
// External Angular computed/effect timing is unchanged.
store.destroy();`}];ngOnDestroy(){this.store.destroy();}nextId=5;names=["Ada","Bjarne","Carmack","Dijkstra","Euler","Fermat","Grace","Hopper"];store=aw({players:rd({selectId:e=>e.id,sortComparer:(e,t)=>t.score-e.score})});players=this.store.$.players.all;constructor(){this.store.$.players.addMany([{id:1,name:"Ada",score:120},{id:2,name:"Grace",score:90},{id:3,name:"Hopper",score:150},{id:4,name:"Euler",score:60}]);}addRandom(){let e=this.nextId++;this.store.$.players.addOne({id:e,name:this.names[e%this.names.length]+" "+e,score:Math.floor(Math.random()*200)});}bumpRandom(){let e=this.store.$.players.ids();if(!e.length)return;let t=e[Math.floor(Math.random()*e.length)],o=this.store.$.players.byId(t)?.();o&&this.store.$.players.updateOne(t,{score:o.score+50});}reset(){this.store.$.players.setAll([{id:1,name:"Ada",score:120},{id:2,name:"Grace",score:90},{id:3,name:"Hopper",score:150},{id:4,name:"Euler",score:60}]),this.nextId=5;}static \u0275fac=function(t){return new(t||s)};static \u0275cmp=Qv({type:s,selectors:[["app-entity-sort-comparer-demo"]],decls:22,vars:4,consts:[[1,"layout-frame"],["heading","Auto-sorted collection \u2014 sortComparer",3,"headingLevel","code"],["intro","",1,"muted"],[1,"demo"],[1,"controls"],["type","button",3,"click"],[1,"board"],[1,"muted"],[1,"rank"],[1,"name"],[1,"score"]],template:function(t,o){t&1&&(Zo(0,"div",0)(1,"st-example",1)(2,"p",2)(3,"code"),XI(4),nc(),XI(5," keeps "),Zo(6,"code"),XI(7,"all()"),nc(),XI(8," highest-score-first on every read. "),nc(),Zo(9,"div",3)(10,"div",4)(11,"button",5),zf("click",function(){return o.addRandom()}),XI(12,"+ Add player"),nc(),Zo(13,"button",5),zf("click",function(){return o.bumpRandom()}),XI(14,"\u2191 Bump a score"),nc(),Zo(15,"button",5),zf("click",function(){return o.reset()}),XI(16,"Reset"),nc()(),Zo(17,"ol",6),DI(18,x,7,3,"li",null,v),nc(),Zo(20,"p",7),XI(21," Rows reorder automatically \u2014 no manual sort runs after mutations. Held SignalTree readers stay fresh inside grouped writes too. Native computed values and effects keep Angular\u2019s timing. "),nc()()()()),t&2&&(ly(),Bf("headingLevel",1)("code",o.codeFiles),ly(3),np("entityMap<Player>(","{"," sortComparer: (a, b) => b.score - a.score ","}",")"),ly(14),wI(o.players()));},dependencies:[se],styles:[".demo[_ngcontent-%COMP%]{max-width:28rem}.muted[_ngcontent-%COMP%]{color:var(--color-neutral-500, #6b7280);font-size:.85rem}.controls[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:.5rem;margin:.75rem 0}.controls[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{flex:1 1 7rem}.board[_ngcontent-%COMP%]{list-style:none;padding:0;margin:0}.board[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.75rem;padding:.4rem .6rem;border-bottom:1px solid var(--color-neutral-200, #e5e7eb)}.rank[_ngcontent-%COMP%]{width:2.5rem;color:var(--color-neutral-500, #6b7280)}.name[_ngcontent-%COMP%]{flex:1;font-weight:600}.score[_ngcontent-%COMP%]{font-variant-numeric:tabular-nums}"]})};export{_ as EntitySortComparerDemoComponent};