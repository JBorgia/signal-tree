# Persistence Guide

The old `stored(key, default, options?)` marker is deleted, along with its
storage-key helpers and cache-aware loader persistence path (`STORED-RETIRE-0`,
closed — see `docs/architecture/v15-production-surface-audit.md`'s final
disposition ledger). This is not an open question waiting on a future
contract; it is a decided decomposition:

```text
BEFORE                          AFTER
stored() [deleted]               ordinary state location
  state                            + Link              (relationship authority)
  persistence                      + persistence policy (endpoint, codec, key,
  authority                                              lifecycle)
  lifecycle
```

`link()` is the general successor for external acquisition/synchronization —
the same primitive the removed `loader()` decomposed into for collections.
Persistence is just the case where the endpoint is storage instead of HTTP:

```typescript
import { link, signalTree, type Link, type Location } from '@signal-tree/kernel';

function attachLocalStorageSync<T>(location: Location<T>, key: string): Link {
  const connection = link(location, {
    get: () => {
      const raw = localStorage.getItem(key);
      return raw === null ? location() : (JSON.parse(raw) as T);
    },
    set: (value) => localStorage.setItem(key, JSON.stringify(value)),
  });
  void connection.retrieve(); // the deleted marker hydrated synchronously at
  // construction; link() only reads on retrieve(), so pull once to match.
  return connection;
}

const tree = signalTree({ theme: 'light' as 'light' | 'dark' });
attachLocalStorageSync(tree.$.theme, 'app-theme');
```

`link()` only exists once the tree is built — it operates on a resolved
`tree.$.<path>` location, not a marker literal — so wiring moves out of the
state factory and into wherever you construct the tree (or a lazily-called
site right after, the same shape §2's Ops base uses for its own acquisition).

### What SignalTree owns vs. what you own

Same split the removed `loader()` resolved into:

```text
the relationship (does this location have a live sync to an external
  authority, and is a write to it authored or external)     -> link()
codec, storage key, migration, debounce, write scheduling    -> your endpoint
staleTime, SWR, eviction, retry, auth                         -> application
```

None of that policy needs a marker to express — `get`/`set` are ordinary
functions, so debounce, versioning, or a custom serializer are just more code
in them.

### Executable examples (already in this repo, not invented)

- [`packages/kernel/src/enhancers/serialization/persistence-as-link-swap-0.spec.ts`](../../packages/kernel/src/enhancers/serialization/persistence-as-link-swap-0.spec.ts) —
  the exact swap this guide describes, proven.
- [`packages/kernel/src/lib/link-persistence-conformance.spec.ts`](../../packages/kernel/src/lib/link-persistence-conformance.spec.ts) —
  persistence-shaped `link()` usage against the general `Link` contract.
- [`packages/kernel/src/lib/persistence-decompose-0.spec.ts`](../../packages/kernel/src/lib/persistence-decompose-0.spec.ts) —
  the decomposition itself, as a falsifiable spec rather than prose.

### A persistent remote relationship (not storage) is the same shape

`link()` doesn't care whether the endpoint is `localStorage`, an HTTP
resource, or a WebSocket — only `get`/`set`/`subscribe` differ. See
[composition-recipes.md](composition-recipes.md) for the sibling recipes this
guide shares its model with (staged editing, optimistic writes with server
reconciliation).

## Transaction and durability limits

Read [Transaction failure policy and the 15.3.1 failure inventory](transaction-failures-v15.md)
before relying on settlement to gate storage. Explicit rollback refusal leaves
state unchanged and the handle pending but releases consequences in existing
v15. In 15.3.1, automatic refusal before a handle returns
records surviving writes as committed, retains eligible undo history,
releases consequences, and still throws. Successful automatic rollback reverses
recorded writes and discards deferred consequences. Error does not guarantee
undo or backend rejection; never blindly retry the whole operation.

The [15.3.1 failure inventory](transaction-failures-v15.md#known-failures-in-published-1531)
records missed restored rows, omitted branch keys, same-tick notifications and
asynchronous Link settlement gaps in that version, each marked with the version
that repaired it (15.4.0 for all of these). It also lists Link order and
`destroy()` failures found later, which 15.4.4 repairs. Check the
[changelog](../../CHANGELOG.md) for versioned repairs.
Direct framework effects writing storage have no transaction settlement gate. Applications must
own reconciliation, idempotency, and durable acknowledgements; neither an error
nor `settled()` is proof of the remote outcome. A recovery handle that keeps
consequences pending until confirmation is a v16 target, not a v15 API.
