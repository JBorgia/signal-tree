import type { ObservationAdapter } from '@signal-tree/kernel/adapter';
/**
 * Solid observation for kernel-owned state.
 *
 * Solid's `createSignal` returns exactly the two halves this seam asks for — a
 * tracked getter and a setter — so the adapter is close to a direct expression
 * of the contract rather than an adaptation of it.
 *
 * Signals are created with `equals: false` because the kernel, not Solid, owns
 * equality. The value a consumer reads comes from the kernel; the signal here
 * is a dependency edge, and letting Solid suppress a notification on value
 * equality would drop invalidations the kernel had decided to publish.
 */
export declare const createSolidObservationAdapter: () => ObservationAdapter;
