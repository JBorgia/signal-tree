import hashlib,json,os,shutil,stat,subprocess,sys,time
from pathlib import Path
q=Path(__file__).resolve().parent
line,mode=sys.argv[1:3]
assert line in ('v15','v16') and mode in ('mutation','post')
root=Path('/Users/jonathanborgia/code/signaltree/.worktrees')/('v15-retention-backport' if line=='v15' else 'v16-followthrough')
os.chdir(root)
os.environ.update(NX_DAEMON='false',NX_ISOLATE_PLUGINS='false',NG_BUILD_MAX_WORKERS='1',npm_config_cache=str(q/'npm-cache'))
expected={'v15':'sha256-8f11180b4410a9402ee28aafcdcb8f5e01ee60def75bffddeb6d8a5f5e5edda9','v16':'sha256-ba5c01b75cd74e50293262f2a324cfe4072353dc845211e5c95e19948b126e05'}[line]

def run(label,command,allow=False,extra=None):
 env={**os.environ,**(extra or {})}
 result=subprocess.run(['python3',str(q/'run-check.py'),line+'-'+label,*command],env=env)
 if not allow:assert result.returncode==0,(label,result.returncode)
 return result.returncode

def source_manifest():
 paths=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
 result={}
 for name in filter(None,paths):
  p=root/name
  if p.is_symlink():result[name]={'link':os.readlink(p)}
  else:
   assert p.is_file(),name
   result[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'executeBits':stat.S_IMODE(p.stat().st_mode)&0o111}
 return result

def write(name,value):
 p=q/'checks'/(line+'-'+name+'.json');assert not p.exists()
 p.write_text(json.dumps(value,indent=2)+'\n')

if mode=='mutation':
 before=source_manifest(); status=subprocess.check_output(['git','status','--porcelain'],text=True)
 write('mutation-source-before',{'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':status,'files':before})
 code=run('mutation',['node','tools/verify-gates.mjs','--self-test','--release'],allow=True)
 after=source_manifest(); after_status=subprocess.check_output(['git','status','--porcelain'],text=True)
 write('mutation-restoration',{'files':len(before),'equal':before==after,'statusBefore':status,'statusAfter':after_status,'gateExit':code})
 assert before==after and status==after_status,'Mutation source restoration failed'
 assert code==0,'Inspect preserved mutation failure'
else:
 dist=root/'dist';assert dist.parent==root and dist.name=='dist'
 if dist.exists():shutil.rmtree(dist)
 run('post-build',['pnpm','run','build:all','--skip-nx-cache','--parallel=1'])
 helper=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-followthrough/scripts/publish-artifact-integrity.mjs')
 js=f'import {{buildIntegrity}} from {json.dumps(helper.as_uri())}; console.log(buildIntegrity(process.argv[1],["kernel","angular","react","vue","solid"]));'
 actual=subprocess.check_output(['node','--input-type=module','-e',js,str(root)],text=True).strip()
 original=q/('lazy-v15-kernel' if line=='v15' else 'lazy-v16-kernel')
 files={str(p.relative_to(original)):hashlib.sha256(p.read_bytes()).hexdigest() for p in original.rglob('*') if p.is_file()}
 final={str(p.relative_to(dist/'packages/kernel')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (dist/'packages/kernel').rglob('*') if p.is_file()}
 write('post-build-equivalence',{'seal':actual,'expectedSeal':expected,'kernelFiles':len(files),'kernelEqual':files==final})
 assert actual==expected and files==final,'Final artifacts differ from measured candidate'
 for tool in ['verify-tarball-consumer','verify-consumer-typecheck','verify-angular-aot-consumer']:
  run('final-'+tool,['node','tools/'+tool+'.mjs'])
 if line=='v16':
  run('final-coordinated',['node','tools/release-economics/coordinated.mjs','selftest',str(dist/'packages/kernel'),'1000'])
  for witness in ['built-witnesses','public-reentry','clone-reentry-review','frame-packet-witness']:
   run('final-'+witness,['node',str(q/'qualification-witnesses'/(witness+'.mjs')),str(dist/'packages/kernel/dist')])
 run('final-point',['node',str(q/'qualification-witnesses/replay/counter-child.mjs'),line,str(dist/'packages/kernel/dist/index.js')])
 point=json.loads((q/'checks'/(line+'-final-point.log')).read_text());assert all(x['total']<2000 and x['passesOriginalBound'] for x in point['rows'])
 code=run('demo-strict',['pnpm','nx','build','demo','--configuration=production','--skip-nx-cache'],allow=True)
 if code:
  assert line=='v16','Unexpected v15 production build failure'
  log=(q/'checks'/(line+'-demo-strict.log')).read_text()
  assert 'exceeded maximum budget' in log,'Non-budget production failure requires investigation'
  config=root/'apps/demo/project.json'; before=config.read_bytes(); data=json.loads(before)
  budgets=data['targets']['build']['configurations']['production']['budgets'];assert budgets
  data['targets']['build']['configurations']['production']['budgets']=[]
  try:
   config.write_text(json.dumps(data,indent=2)+'\n')
   run('demo-owner-size-disposition',['pnpm','nx','build','demo','--configuration=production','--skip-nx-cache'])
  finally:config.write_bytes(before)
  assert config.read_bytes()==before
  write('demo-budget-restoration',{'sha256':hashlib.sha256(before).hexdigest(),'restored':True,'ceilings':budgets})
 browser=q/'checks'/(line+'-browser-results.json')
 run('browser',['pnpm','exec','playwright','test','--config','scripts/playwright/route-smoke.config.ts','--workers=1','--retries=0','--reporter=list,json'],allow=True,extra={'CI':'true','PLAYWRIGHT_JSON_OUTPUT_FILE':str(browser)})
 assert browser.is_file()
 for label,command in [('version-claims',['node','scripts/verify-version-claims.js']),('release-state',['node','scripts/verify-release-state.js']),('changelog',['bash','scripts/verify-changelog-entry.sh',json.loads((root/'package.json').read_text())['version']])]:run('final-'+label,command)
 subprocess.run(['git','diff','--check'],check=True)
 print('Post checks finished; inspect browser disposition and receipts before release signoff',flush=True)
