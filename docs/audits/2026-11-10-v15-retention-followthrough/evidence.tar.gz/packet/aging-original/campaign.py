import hashlib, json, pathlib, statistics, subprocess, sys

root = pathlib.Path(__file__).resolve().parent
node = sys.argv[1]
arms = {'C': 'candidate-kernel', 'P': 'prototype-kernel'}
profiles = ('wide-8', 'wide-32', 'steady', 'promote')
order = ('C', 'C', 'C', 'P', 'P', 'C', 'C', 'P')
schedule = [(profile, arm) for profile in profiles for arm in order]
runs = root / 'runs'
runs.mkdir()
def input_hashes():
    paths = [root / name for name in ('aging.mjs', 'campaign.py', 'heap-quiescence.mjs', 'prototype-source.txt')]
    for name in arms.values():
        paths.extend(p for p in (root / name).rglob('*') if p.is_file())
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

before = input_hashes()
(runs / 'plan.json').write_text(json.dumps({
    'node': node, 'schedule': schedule, 'inputs': before, 'timeoutSeconds': 120,
    'maxOldSpaceMiB': 768, 'runs': 'two C A/A then three alternating comparison pairs, fresh serial children, stop on first failure',
    'primary': 'second live heap minus baseline by profile; cold, primed, first and promoted checkpoints descriptive',
    'direction': 'both comparison ranges disjoint and median difference exceeds the largest range of C, P or A/A',
}, indent=2))

def metrics(sample):
    base = sample['heap']['baseline']['heapUsed']
    values = {f'heap.{k}': v['heapUsed'] - base for k, v in sample['heap'].items() if k != 'baseline'}
    for phase, timing in sample['metrics'].items():
        for metric in ('syncCpu', 'totalCpu', 'syncWall'):
            values[f'{phase}.{metric}'] = timing[metric]
    return values

observations = {}
for i, (profile, arm) in enumerate(schedule):
    prefix = runs / f'{i:02}-{profile}-{arm}'
    receipt = prefix.with_suffix('.json')
    dist = root / arms[arm] / 'dist'
    argv = [node, '--expose-gc', '--max-old-space-size=768', str(root / 'aging.mjs'), str(dist), profile, str(receipt)]
    with prefix.with_suffix('.log').open('w') as log:
        subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, timeout=120, check=True)
    sample = json.loads(receipt.read_text())
    assert sample['entry'] == (dist / 'index.js').as_uri()
    assert sample['profile'] == profile and sample['weakAlive'] == 0
    slot = 'AA' if i % len(order) < 2 else arm
    observations.setdefault(profile, {}).setdefault(slot, []).append(metrics(sample))
    print(i, profile, arm, metrics(sample)['heap.second'], flush=True)

assert before == input_hashes()
summary = {}
for profile, grouped in observations.items():
    summary[profile] = {}
    for key in grouped['C'][0]:
        aa, c, p = ([row[key] for row in grouped[arm]] for arm in ('AA', 'C', 'P'))
        cm, pm = statistics.median(c), statistics.median(p)
        spread = max(max(v) - min(v) for v in (aa, c, p))
        direction = 'unresolved'
        if abs(cm - pm) > spread:
            if max(p) < min(c): direction = 'lower'
            if max(c) < min(p): direction = 'higher'
        summary[profile][key] = {'AA': aa, 'C': c, 'P': p, 'CMedian': cm, 'PMedian': pm,
                                 'delta': pm - cm, 'direction': direction}
(runs / 'summary.json').write_text(json.dumps(summary, indent=2))
