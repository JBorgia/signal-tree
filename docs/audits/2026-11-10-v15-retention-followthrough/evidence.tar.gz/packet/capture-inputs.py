from pathlib import Path
import os,json,hashlib,shutil
q=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
index={}
for base,dirs,files in os.walk(q,followlinks=False):
 dirs[:]=[d for d in dirs if d not in ('npm-cache','.angular','.git','input-payloads') and not (Path(base)/d).is_symlink()]
 for n in files:
  p=Path(base)/n
  if p.is_file() and not p.is_symlink():index.setdefault(sha(p.read_bytes()),p)
plans=[q/n for n in ['aging-runs/plan.json','lazy-aging/plan.json','lazy-demand/plan.json','v15-lazy-demand/plan.json','final-ordinary/ordinary-runs/plan.json','angular-attempt-01/angular-profile/plan.json','angular-attempt-02/angular-profile/plan.json','angular-final/angular-profile/plan.json']]
out=q/'input-payloads';out.mkdir(exist_ok=True);bindings=[];missing=[]
for plan in plans:
 if not plan.exists():continue
 for name,digest in json.loads(plan.read_text())['inputs'].items():
  assert isinstance(digest,str) and len(digest)==64,(name,digest)
  p=Path(name);local=index.get(digest)
  if local is None and p.is_file() and sha(p.read_bytes())==digest:
   local=out/digest;local.write_bytes(p.read_bytes());index[digest]=local
  if local is None:missing.append({'plan':str(plan.relative_to(q)),'originalPath':name,'sha256':digest});continue
  bindings.append({'plan':str(plan.relative_to(q)),'originalPath':name,'sha256':digest,'packetPath':str(local.relative_to(q))})
result={'bindings':bindings,'missing':missing,'scope':'Registered measurement input payloads resolved by content hash, including preserved earlier copies when paths were reused. Does not claim whole repository/dependency-history completeness.'}
(out/'bindings.json').write_text(json.dumps(result,indent=2)+'\n');print('Input bindings:',len(bindings),'missing:',len(missing));print(json.dumps(missing,indent=2))
assert not missing
