from pathlib import Path
import subprocess,json,hashlib,sys
p=Path(__file__).resolve().parent;c=Path('/Users/jonathanborgia/code/signaltree/.worktrees/v16-sparse-responsibility-0');sha=lambda raw:hashlib.sha256(raw).hexdigest()
controls=[
 ('omit-exposure','packages/kernel/src/lib/internals/entity-publication.ts','      if (nativeUnit) native?.expose?.(nativeUnit.completion);','      // CONTROL intentionally omits native exposure.','integrated-field-facts.spec.ts','seals an unread native completion'),
 ('stale-window-membership','packages/kernel/src/lib/experimental-publication/lifecycle.ts','pending.add(cell);pendingSnapshot=undefined;','pending.add(cell);','integrated-late-history.spec.ts','late consumer preserves earlier ordinary history'),
 ('stale-row-revision','packages/kernel/src/lib/experimental-publication/entity.ts','target.revision=revision;','/* CONTROL intentionally leaves row revision stale. */','integrated-field-facts.spec.ts','invalidates only the exact retained retirement row'),
 ('forged-point-admission','packages/kernel/src/lib/internals/entity-publication.ts','native && this.admission.ownsPoint(packet) &&','native && true &&','integrated-point-source.spec.ts','authenticates point membership per source'),
 ('lost-realized-version','packages/kernel/src/lib/entity-signal.ts','if (versionCell) deriveLocation(versionCell, value => value + 1);','if (versionCell) { /* CONTROL intentionally loses realized invalidation. */ }','integrated-collection-version.spec.ts','realizes a collection query after cold writes'),
]
reg={'purpose':'Independent known-bad counterfactuals;eachonce;nevercostsamples','controls':[{'name':n,'file':f,'replacement':old,'mutant':new,'test':test,'requiredFailure':required} for n,f,old,new,test,required in controls],'restoration':'byteexactfinally;fullsourceboundpermutation;abortonguardsetuporsurvivor','noThresholdOrOracleChanges':True}
(p/'CONTROL-PREREGISTRATION.json').write_text(json.dumps(reg,indent=2)+'\n')
originalManifest=(p/'MANIFEST.json').read_bytes();originalMap=json.loads(originalManifest);originals={f:(c/f).read_bytes() for _,f,_,_,_,_ in controls};results=[]
try:
 for name,file,old,new,test,required in controls:
  source=originals[file].decode();assert source.count(old)==1,(name,source.count(old));(c/file).write_text(source.replace(old,new,1))
  mutated={n:sha((c/n).read_bytes()) for n in originalMap};(p/'MANIFEST.json').write_text(json.dumps(mutated,indent=2)+'\n')
  try:
   cmd=['python3',str(p/'guard.py'),'control-'+name,'900','corepack','pnpm','nx','test','kernel','--skip-nx-cache','--maxWorkers=1','--testFile=src/lib/'+test]
   run=subprocess.run(cmd,cwd=c,check=False);d=p/'runs'/('control-'+name);r=json.loads((d/'RESULT.json').read_text());log=(d/'first.log').read_text();killed=r['exit']!=0 and not r['guardReason'] and not r['sourceMismatches'] and not r['remainingOwned'] and 'AssertionError' in log and required in log
   results.append({'name':name,'killed':killed,'result':r,'requiredFailure':required,'logSha256':sha((d/'first.log').read_bytes())});(p/'CONTROL-RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print('CONTROL',name,'killed' if killed else 'NOT_KILLED_OR_INVALID',flush=True)
   if not killed:sys.exit(1)
  finally:(c/file).write_bytes(originals[file])
finally:
 for file,raw in originals.items():assert (c/file).read_bytes()==raw,file
 (p/'MANIFEST.json').write_bytes(originalManifest)
 (p/'CONTROL-RESTORATION.json').write_text(json.dumps({'restoredAllRuntimeBytes':True,'sourceManifestSha256':sha(originalManifest),'files':{f:sha(raw) for f,raw in originals.items()}},indent=2)+'\n')
