from pathlib import Path
import json,hashlib,shutil,tarfile,os
p=Path(__file__).resolve().parent;d=p/'sealed-evidence';d.mkdir(exist_ok=False)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def copy(src,target):
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
for name in ['PLAN.json','COST-INTENT.json','MANIFEST.json','CONTROL-PREREGISTRATION.json','CONTROL-RESULTS.json','CONTROL-RESTORATION.json','guard.py','run-controls.py','prepare-cost.py','seal-evidence.py','public-surface-checks.py','EXECUTION-INDEX.json','independent-topology-review.md','independent-implementation-review.md','independent-cost-protocol-review.md','independent-cost-interpretation.md','field-layout-cost-explanation.md','solid-fault-fixture.before.ts','solid-fault-fixture.corrected.ts']:
 copy(p/name,d/name)
for name in ['manifests','source-checkpoint','surface-checks','cost']:
 shutil.copytree(p/name,d/name)
for folder in ['runs','baseline-fault/runs']:
 for src in (p/folder).rglob('*'):
  if src.is_file() and 'tmp' not in src.relative_to(p/folder).parts:copy(src,d/src.relative_to(p))
for name in ['MANIFEST.json','guard.py']:
 copy(p/'baseline-fault'/name,d/'baseline-fault'/name)
b=json.loads((p/'cost/BINDINGS.json').read_text())
for arm,a in b['artifacts'].items():
 root=Path(a['root']);m=json.loads(Path(a['manifest']).read_text())
 for n,h in m.items():
  src=root/n;assert sha(src)==h['sha256'] and src.stat().st_mode&0o111==h['executable'],(arm,n)
  copy(src,d/'artifacts'/arm/n)
 for k in ['command','result']:copy(Path(b['buildReceipts'][arm][k]),d/'build-receipts'/arm/(k.upper()+'.json'))
omissions={'baseCommit':'f165d28e55dce241ff6466a58c9b850f1bbc20f3','scope':'Source replay uses base Git checkout plus source-checkpoint patch and new files. Full source manifests bind verified files; unchanged historical payloads, node_modules and caches are not included. This archive is not a full Git repository/history or all-test reproducibility claim.','artifactScope':'Both exact193file package outputs included; framework demo output excluded; generating command/log/result included.','pathReplay':'Original command paths preserved; remap arm roots/dependency paths in a NEW packet, never overwrite sealed registrations. No install scripts needed to inspect artifacts.'}
(d/'SCOPE.json').write_text(json.dumps(omissions,indent=2)+'\n')
m={str(f.relative_to(d)):{'sha256':sha(f),'bytes':f.stat().st_size,'executable':f.stat().st_mode&0o111} for f in sorted(d.rglob('*')) if f.is_file()};(d/'FILE-MAP.json').write_text(json.dumps(m,indent=2)+'\n')
archive=p/'integrated-point-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(d.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(d)),recursive=False)
record={'sha256':sha(archive),'bytes':archive.stat().st_size,'verifiedPayloads':len(m),'mapSha256':sha(d/'FILE-MAP.json')};(p/'EVIDENCE-SEAL.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
